#define main original_draw_main
#include "cr_draw_test.c"
#undef main
#include <assert.h>
int main(void)
{
    cr_screen_t s;
    uint32_t y, x, k, before;
    palette_set(mod_index());
    cr_screen_clear(&s);
    s.kind = CR_K_BOOT;
    cr_draw_invalidate();
    cr_draw(&s, 65535u);
    for (y = 0; y < 240; ++y) {
        x = 0;
        for (k = cr_boot_rows[y]; k < cr_boot_rows[y+1]; ++k) {
            uint32_t n = (cr_boot_rle[k] >> 4) + 1;
            while (n--) {
                assert(x < 240);
                assert(host_screen[y*240+x++] == swap16(cr_boot_palette[cr_boot_rle[k]&15]));
            }
        }
        assert(x == 240);
    }
    before = host_blits;
    cr_draw(&s, 65535u);
    assert(before == host_blits);
    write_ppm("build/boot-art", "startup");
    puts("PASS: 57600 startup pixels, row bounds and unchanged-frame cache");
    return nfail ? 1 : 0;
}
