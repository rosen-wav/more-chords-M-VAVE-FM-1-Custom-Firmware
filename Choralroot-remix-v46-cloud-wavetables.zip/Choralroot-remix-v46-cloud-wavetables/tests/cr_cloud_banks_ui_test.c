#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(int argc,char **argv){assert(argc==2);emu_fw_options(0,1,0,1);emu_fw_init(0);
 cu_load(&trk[0],ENGI_CLOUD,0,0);engine_block(&trk[0]);ce_open(0);ce_group(CE_ENV);
 ce_scr_t sc;assert(ce_scr(&trk[0],CE_ENV,0,&sc)==2);ce_view_t vw;ce_view(&trk[0],0,&vw);
 for(unsigned c=0;c<4;c++){assert(vw.ref[0][c].a==CLOUD_EXTRA_IDS[c]);int old=trk[0].p[CLOUD_EXTRA_IDS[c]];ce_knob(c,1,1);assert(trk[0].p[CLOUD_EXTRA_IDS[c]]>old);}
 for(unsigned b=0;b<5;b++){
  trk[0].p[P_CBANK]=b;trk[0].p[P_CSCAN]=b%4;trk[0].p[P_CRATE]=83;trk[0].p[P_CDEPTH]=91;trk[0].p[P_ATK]=37;
  assert(!cb_store(&trk[0],0,b?32:0,"Cloud bank",0));
  unsigned slot=b?32:0;cu_load(&trk[0],ENGI_CLOUD,1,0);cu_load_user(&trk[0],slot,0);engine_block(&trk[0]);
  assert(trk[0].p[P_CBANK]==b&&trk[0].p[P_CSCAN]==b%4&&trk[0].p[P_CRATE]==83&&trk[0].p[P_CDEPTH]==91&&trk[0].p[P_ATK]==37);
  cr_screen_t s;cr_build_screen(&s,cu_now());assert(s.wide==CR_W_CLOUD && s.wv[8]==2);
  char path[512];snprintf(path,sizeof path,"%s/bank-%u.bin",argv[1],b);FILE *f=fopen(path,"wb");assert(f);assert(fwrite(&s,sizeof s,1,f)==1);fclose(f);
 }
 cx.scr[0][CE_ENV]=1;ce_view(&trk[0],0,&vw);assert(vw.wide==CR_W_ENV);assert(vw.ref[0][0].a==P_ATK);
 int old=trk[0].p[P_ATK];ce_knob(0,1,1);assert(trk[0].p[P_ATK]>old);
 cu_load(&trk[0],ENGI_SWARM,0,0);assert(track_desc(&trk[0],P_CBANK)==&TP[P_CBANK]);
 assert(sizeof(up_rec_t)==192 && P_COUNT==91);
 puts("PASS: CLOUD ENV knobs, two-page navigation, unchanged ADSR, five bank presets base/extension USER reload, descriptors isolated, 192-byte layout unchanged");return 0;
}
