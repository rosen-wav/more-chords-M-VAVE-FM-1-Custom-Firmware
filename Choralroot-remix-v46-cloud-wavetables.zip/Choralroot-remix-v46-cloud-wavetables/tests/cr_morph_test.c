/* Actual Morph engine through ChoralRoot's shared allocator/mixer and editor. */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static int32_t pcm[2*CTL];
static uint64_t energy;
static unsigned start_position;
static void load_morph(unsigned src,unsigned preset,unsigned amount){
 setup(MORPH_SOURCE[src],preset,ENGI_FM6,0,0,0);
 cu_load(&trk[0],ENGI_MORPH,0,0);engine_block(&trk[0]);panic_req=0;
 trk[0].p[P_E2]=start_position;trk[0].p[P_E0]=src;trk[0].p[P_E1]=preset;trk[0].p[P_E5]=amount;trk[0].p[P_E7]=(int16_t)(0x1200u|((preset+1u)%ENGINES[MORPH_SOURCE[src]]->npresets));
 trk[0].p[P_CHOR]=trk[0].p[P_REV]=trk[0].p[P_DLY]=trk[0].p[P_DIST]=0;
 trk[0].p[P_LD_PIT]=trk[0].p[P_LD_FLT]=0;trk[0].p[P_M1AMT]=0;
 morph_sync(&trk[0]);
 formant_nz=0x2545F491;
 for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],48+i*3,100);
 energy=0;
}
static void render(unsigned n){for(unsigned j=0;j<n;j++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);assert(!morph.inside);for(unsigned i=0;i<2*CTL;i++){int64_t a=pcm[i];energy+=a<0?-a:a;assert(abs(pcm[i])<2000000);}}}
static void load_reference(unsigned src,unsigned preset){
 setup(MORPH_SOURCE[src],preset,ENGI_FM6,0,0,0);
 cu_load(&trk[0],MORPH_SOURCE[src],preset,0);engine_block(&trk[0]);panic_req=0;
 trk[0].p[P_CHOR]=trk[0].p[P_REV]=trk[0].p[P_DLY]=trk[0].p[P_DIST]=0;
 trk[0].p[P_LD_PIT]=trk[0].p[P_LD_FLT]=0;trk[0].p[P_M1AMT]=0;
 formant_nz=0x2545F491;
 for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],48+i*3,100);
}
static int32_t original_pcm[64][2*CTL];
static void screenshot(const char *path){
 cr_screen_t s;cr_build_screen(&s,cu_now());cr_draw(&s,CR_ANIM_SETTLED);
 FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned i=0;i<240*240;i++){uint16_t c=emu_hal.lcd[i];c=(c>>8)|(c<<8);uint8_t rgb[3]={(uint8_t)(((c>>11)&31)*255/31),(uint8_t)(((c>>5)&63)*255/63),(uint8_t)((c&31)*255/31)};fwrite(rgb,1,3,f);}fclose(f);
}
static morph_field_t *field(unsigned kind,unsigned id){
 for(unsigned i=0;i<morph.n;i++)if(morph.f[i].kind==kind&&morph.f[i].id==id)return &morph.f[i];
 assert(!"missing morph field");return 0;
}
static void test_parameter_progression(void){
 /* Semantic regressions: named numeric ranges are not topology switches. */
 load_morph(2,0,100); /* VA */
 assert(MORPH_SOURCE[2]==ENGI_VA);
 assert(!field(3,VA_FTYPE)->discrete);
 assert(!field(3,VA_OSC(0,VO_FINE))->discrete);
 assert(!field(3,VA_OSC(0,VO_COARSE))->discrete);
 assert(field(3,VA_OSC(0,VO_WAVE))->discrete);
 load_morph(1,0,100); /* QUAD */
 assert(!field(4,QP_DTUN)->discrete&&!field(4,QP_OFSC)->discrete);
 assert(field(4,QP_ALGO)->discrete&&field(4,QP_RC)->discrete);
 unsigned moving=0;
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  for(unsigned pr=0;pr<ENGINES[MORPH_SOURCE[src]]->npresets;pr++){
   load_morph(src,pr,100);
   for(unsigned f=0;f<morph.n;f++){
    morph_field_t *x=&morph.f[f];if(x->discrete||abs(x->b-x->a)<4)continue;
    int last=x->a,interior=0;
    for(unsigned pos=0;pos<=127;pos++){
     morph.pos=pos*256;morph_apply_position(CTL);
     int v=x->current;
     if(!x->soften)assert(x->b>x->a?v>=last:v<=last);
     assert(v>=x->lo&&v<=x->hi);
     if(v!=x->a&&v!=x->b)interior++;
     if(!pos)assert(v==x->a);
     if(pos==127)assert(v==x->b);
     last=v;
    }
    assert(interior>16);moving++;
   }
  }
 }
 /* Sounding carriers must follow the patch, with no note-off on transpose.
  * Set a sustained voice so the assertion is independent of factory decay. */
 load_morph(0,0,100);morph_begin(&trk[0],0);
 fm6_sync(&trk[0],0);
 voice_t *v=&trk[0].v[0];fm6_voice_t *voice=fm6_state(&trk[0],v);
 unsigned carriers=fm6_carriers(fm6_ed(&trk[0])[FP_ALG]),op=0;
 while(!(carriers&(1u<<op)))op++;
 voice->down=1;voice->frozen=0;v->active=v->gate=1;
 voice->eg[op].ix=3;voice->eg[op].hold=0;
 int32_t level=voice->eg[op].level;
 morph_field_t *ol=field(2,op*FP_OP+FP_OL);
 ol->current=ol->current>50?20:90;
 morph_field_t *tr=field(2,FP_TRNSP);assert(!tr->discrete);
 tr->current=tr->current<48?tr->current+1:tr->current-1;
 field(2,FP_PR1)->current=42;field(2,FP_PL1)->current=61;
 morph.revision++;fm6_sync(&trk[0],0);
 assert(v->active&&v->gate&&!voice->frozen);
 assert(voice->eg[op].ix==2&&voice->eg[op].level==level);
 fm6_eg_t expected=voice->eg[op];
 fm6_eg_go(&expected,&fm6_ed(&trk[0])[op*FP_OP],voice->ol[op],voice->rs[op],2);
 assert(voice->eg[op].target==expected.target);
 assert(voice->pe.pr[0]==42&&voice->pe.pv[0]==61);
 assert(field(2,FP_FC)->discrete&&field(2,FP_FF)->discrete);
 morph_end(&trk[0]);
 printf("PASS: %u numeric parameter sweeps, named continuous controls, live FM6 carriers/pitch envelopes/transpose\n",moving);
}
static void test_gentle_morph(void){
 int32_t eased=0;
 for(int32_t u=0;u<=32768;u++){int32_t next=morph_ease(u);assert(next>=eased);eased=next;}
 assert(eased==32768);
 load_morph(0,0,100);morph_deep_set(&trk[0],1,3,127);
 unsigned previous=0,maxstep=0;
 for(unsigned i=0;i<1600;i++){
  render(1);assert(morph.pos>=previous);
  unsigned delta=morph.pos-previous;if(delta>maxstep)maxstep=delta;
  if(i<10)assert(morph.pos<100);
  previous=morph.pos;
 }
 assert(morph.pos==32512&&maxstep<64);
 /* Reversing a moving knob starts a new curve at its current position. */
 morph_deep_set(&trk[0],1,3,0);render(100);
 previous=morph.pos;morph_deep_set(&trk[0],1,3,110);render(1);
 assert(abs((int)morph.pos-(int)previous)<64);
 render(1600);assert(morph.pos==110u*256u);
 /* Long Random sweeps must ease correctly, including the 8-second range. */
 morph_deep_set(&trk[0],0,3,2);morph_deep_set(&trk[0],1,2,1);
 morph_deep_set(&trk[0],1,0,127);morph_sync(&trk[0]);
 morph.target=0;previous=morph.pos;
 unsigned duration=morph_duration(&trk[0]);
 for(unsigned i=0;i<(duration+CTL-1)/CTL+1;i++){
  morph_tick(&trk[0],CTL);assert(morph.pos<=previous);previous=morph.pos;
 }
 assert(!morph.pos);
 morph_deep_set(&trk[0],1,3,127);render(1600);assert(morph.pos==32512);
 /* Amount cannot introduce an instantaneous endpoint/topology change. */
 unsigned old_amount=morph.amount_q8;
 morph_deep_set(&trk[0],1,1,0);render(1);
 assert(morph.amount_q8<old_amount&&morph.amount_q8>old_amount-100);
 render(800);assert(!morph.amount_q8);
 for(unsigned f=0;f<morph.n;f++)assert(morph.f[f].current==morph.f[f].a);
 unsigned softened=0;
 for(unsigned pr=0;pr<ENG_FM6.npresets;pr++){
  load_morph(0,pr,100);
  unsigned carriers=fm6_carriers(field(2,FP_ALG)->a)|fm6_carriers(field(2,FP_ALG)->b);
  for(unsigned pos=0;pos<=127;pos++){
   morph.pos=pos*256;morph_apply_position(CTL);
   for(unsigned op=0;op<6;op++){
    static const unsigned ids[]={FP_MODE,FP_FC,FP_FF};
    for(unsigned k=0;k<NELEM(ids);k++){
     morph_field_t *x=field(2,op*FP_OP+ids[k]);
     assert(x->current==(morph.discrete_b?x->b:x->a));
    }
    if(carriers&(1u<<op))assert(!field(2,op*FP_OP+FP_OL)->soften);
   }
  }
  morph.pos=16256;morph_apply_position(CTL);
  for(unsigned f=0;f<morph.n;f++){
   morph_field_t *x=&morph.f[f];
   if(x->soften && x->a+x->b>4){
    assert(x->current*2<x->a+x->b);softened++;
   }
  }
 }
 assert(softened);
 /* Identical patches must not acquire a dip merely by moving Position. */
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  load_morph(src,0,100);trk[0].p[P_E7]=0;morph_sync(&trk[0]);
  for(unsigned pos=0;pos<=127;pos++){
   morph.pos=pos*256;morph_apply_position(CTL);
   for(unsigned f=0;f<morph.n;f++)assert(!morph.f[f].soften&&morph.f[f].current==morph.f[f].a);
  }
 }
 printf("PASS: gentle manual motion (%u max Q8 step), reversal, Amount slew, coherent FM ratios, %u softened controls, identical-patch invariance\n",maxstep,softened);
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_c1_test_serial=1;audio_worker_online=0;
 assert(ENGI_MORPH==19 && ENGI_KR106==20 && NENGINES==21 && CR_NVOICE<=32);
 assert(eng_ok(ENGI_MORPH));
 test_parameter_progression();
 test_gentle_morph();
 load_morph(0,0,60);assert(trk[0].p[P_E4]==62&&trk[0].p[P_E5]==60);
 assert(morph_duration(&trk[0])>=FS*195u/100u && morph_duration(&trk[0])<=FS*205u/100u);
 unsigned cases=0;
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  assert(MORPH_SOURCE[src]!=ENGI_CZ && MORPH_SOURCE[src]!=ENGI_PROPHET && MORPH_SOURCE[src]!=ENGI_BASS);
  for(unsigned pr=0;pr<ENGINES[MORPH_SOURCE[src]]->npresets;pr++){
   load_reference(src,pr);
   for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(original_pcm[k],CTL);}
   load_morph(src,pr,0);
   for(unsigned k=0;k<64;k++){
    engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);
    if(memcmp(original_pcm[k],pcm,sizeof pcm)){fprintf(stderr,"Morph bypass mismatch source%u preset%u block%u\n",MORPH_SOURCE[src],pr,k);abort();}
   }
   int16_t config[8];memcpy(config,&trk[0].p[P_E0],sizeof config);
   render(100);
   for(unsigned f=0;f<morph.n;f++)assert(morph.f[f].base==morph.f[f].a && morph.f[f].base==morph.f[f].current);
   assert(!memcmp(config,&trk[0].p[P_E0],sizeof config));
   trk[0].p[P_E5]=100;trk[0].p[P_E3]=1;trk[0].p[P_E4]=0;render(300);
   for(unsigned f=0;f<morph.n;f++){
    morph_field_t *x=&morph.f[f];assert(x->a>=x->lo&&x->a<=x->hi&&x->b>=x->lo&&x->b<=x->hi);
    
    assert(x->current>=x->lo&&x->current<=x->hi);
   }
   trk_all_off(&trk[0]);render(30);cases++;
  }
 }
 /* Full-depth B renders the native factory B from the first note. */
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++)for(unsigned pa=0;pa<ENGINES[MORPH_SOURCE[src]]->npresets;pa++){
  unsigned pb=(pa+1u)%ENGINES[MORPH_SOURCE[src]]->npresets;
  load_reference(src,pb);for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(original_pcm[k],CTL);}
  start_position=127;load_morph(src,pa,100);start_position=0;
  for(unsigned k=0;k<64;k++){
   engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);
   if(memcmp(original_pcm[k],pcm,sizeof pcm)){fprintf(stderr,"Endpoint B PCM mismatch src%u pa%u pb%u block%u\n",src,pa,pb,k);abort();}
  }
 }
 printf("PASS: factory B native PCM endpoint oracle\n");
 /* B is the next real factory patch, not a synthetic variant. Compare its
  * full native/generic editor values after full-depth manual interpolation. */
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++)for(unsigned pr=0;pr<ENGINES[MORPH_SOURCE[src]]->npresets;pr++){
  unsigned pb=(pr+1u)%ENGINES[MORPH_SOURCE[src]]->npresets;
  load_reference(src,pb);const engine_t *e=ENGINES[MORPH_SOURCE[src]];
  int16_t expected[192];unsigned n=0;
  static const unsigned common[]={P_ATK,P_DEC,P_SUS,P_REL,P_ED_FLT};
  for(unsigned i=0;i<NELEM(common);i++)expected[n++]=trk[0].p[common[i]];
  if(e==&ENG_FM6){expected[n++]=trk[0].p[P_E2];expected[n++]=trk[0].p[P_E6];fm6_eff_build(&trk[0]);for(unsigned i=0;i<FP_NAME;i++)expected[n++]=fm6_eff[0].p[i];}
  else if(e==&ENG_VA){for(unsigned i=0;i<VA_NP;i++){va_rng_t d=va_range(i);if(d.max>d.min)expected[n++]=va_patch[0][i];}}
  else if(e==&ENG_QUAD){for(unsigned i=0;i<QP_NP;i++){quad_rng_t d=quad_range(i);if(d.max>d.min)expected[n++]=quad_patch[0][i];}}
  else if(e->deep){for(unsigned pg=0;pg<e->deep->npages;pg++)for(unsigned c=0;c<4;c++){
   const param_desc_t *d=e->deep->desc?e->deep->desc(&trk[0],pg,c):0;if(!d)d=&e->deep->pages[pg].col[c];
   if(d->max>d->min)expected[n++]=e->deep->get(&trk[0],pg,c);
  }}else for(unsigned i=0;i<8;i++){
   const param_desc_t *d=e->desc?e->desc(&trk[0],i):0;if(!d)d=&e->edit[i];
   if(d->max>d->min)expected[n++]=trk[0].p[P_E0+i];
  }
  load_morph(src,pr,100);morph_deep_set(&trk[0],1,3,127);render(1600);
  assert(morph.preset_b==pb && morph.pos==32512 && morph.n==n);
  for(unsigned f=0;f<n;f++)if(morph.f[f].b!=expected[f] || morph.f[f].current!=expected[f]){
   fprintf(stderr,"Endpoint B mismatch src%u pr%u field%u B%d current%d expected%d\n",src,pr,f,morph.f[f].b,morph.f[f].current,expected[f]);abort();
  }
 }
 printf("PASS: all real factory patch B endpoints\n");
 /* Actual editor knobs, native block persistence and A/B audio contrast. */
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++) {
  load_morph(src,0,60);ce.part=0;cx.grp[0]=CE_OSC;cx.scr[0][CE_OSC]=0;cu.page=PG_EDIT;
  cx.grp[0]=CE_LFO;ce_knob(3,127,0);assert(trk[0].p[P_E2]==127 && !trk[0].p[P_E3]);
  render(1600);assert(morph.pos==32512);
  
  if(MORPH_SOURCE[src]==ENGI_QUAD||MORPH_SOURCE[src]==ENGI_VA) {
   for(unsigned k=0;k<64;k++) {
    morph_begin(&trk[0],CTL);const engine_t *e=eng_audio(&trk[0]);e->block(&trk[0]);
    for(unsigned f=0;f<morph.n;f++){
     morph_field_t *x=&morph.f[f];
     if(x->kind==3)assert(va_patch[0][x->id]==x->current);
     if(x->kind==4)assert(quad_patch[0][x->id]==x->current);
    }
    morph_end(&trk[0]);
   }
  }
  load_morph(src,0,60);render(300);
  for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(original_pcm[k],CTL);}
  load_morph(src,0,60);morph_deep_set(&trk[0],1,3,127);render(1600);
  unsigned changed=0;
  for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);for(unsigned j=0;j<2*CTL;j++)changed+=pcm[j]!=original_pcm[k][j];}
  assert(changed);printf("PASS: %s Manual A/B PCM differs in %u samples\n",MORPH_SOURCE_NAMES[src],changed);
  load_morph(src,0,60);render(300);
  for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(original_pcm[k],CTL);}
  load_morph(src,0,60);ce.part=0;cx.grp[0]=CE_OSC;cx.scr[0][CE_OSC]=0;cu.page=PG_EDIT;
  ce_knob(3,1,0);assert(trk[0].p[P_E3]==1);morph_deep_set(&trk[0],1,0,0);render(300);
  changed=0;
  for(unsigned k=0;k<64;k++){engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);for(unsigned j=0;j<2*CTL;j++)changed+=pcm[j]!=original_pcm[k][j];}
  assert(changed);printf("PASS: %s Up and Down changes PCM (%u samples)\n",MORPH_SOURCE_NAMES[src],changed);

 }
 assert(!strcmp(MORPH_MODE[1],"Up and Down"));
 load_morph(0,0,30);trk[0].p[P_E3]=1;trk[0].p[P_E4]=0;morph_sync(&trk[0]);
 unsigned top=0,bottom=0;uint16_t previous=morph.pos;
 for(unsigned i=0;i<400;i++) {
  uint8_t up=morph.going_up;render(1);
  if(up){assert(morph.pos>=previous);if(!morph.going_up){assert(morph.pos==32512);top++;}}
  else {assert(morph.pos<=previous);if(morph.going_up){assert(morph.pos==0);bottom++;}}
  previous=morph.pos;
 }
 assert(top&&bottom);
 load_morph(0,0,30);morph_publish(&trk[0]);
 morph_begin(&trk[0],CTL);assert(morph.inside);
 assert(morph_deep_get(&trk[0],0,0)==0);
 assert(!strcmp(morph_desc(&trk[0],MP_PRESET)->names[0],ENGINES[ENGI_FM6]->presets[0].name));
 ce.part=0;cx.grp[0]=CE_OSC;cx.morph_focus[0]=0;
 cr_screen_t stable={0};ce_screen(&stable,cu_now());
 assert(stable.kind==CR_K_KNOBROW && !strcmp(stable.item[0],"FM6"));
 morph_end(&trk[0]);
 trk[0].p[P_E0]=NELEM(MORPH_SOURCE);morph_sync(&trk[0]);
 assert(trk[0].p[P_E0]==0 && morph_deep_get(&trk[0],0,0)==0);
 load_morph(0,1,30);trk[0].p[P_E3]=2;trk[0].p[P_E6]=1;morph_sync(&trk[0]);
 uint32_t before=morph.chord_events;
 morph_chord(0,2);assert(morph.chord_events==before+1);
 morph_chord(0,2);assert(morph.chord_events==before+1);
 render(300);uint16_t seed=morph.seed;
 for(unsigned i=0;i<30;i++){trk_note_on(&trk[0],60+i%5,90);render(1);}assert(morph.chord_events==before+1 && morph.seed==seed);
 morph_chord(0,4);assert(morph.chord_events==before+2);
 /* Random changes the position and preserves both selected patches. */
 int16_t a[MORPH_FIELDS],b[MORPH_FIELDS];for(unsigned f=0;f<morph.n;f++){a[f]=morph.f[f].a;b[f]=morph.f[f].b;}
 morph_chord(1,123);for(unsigned f=0;f<morph.n;f++){assert(a[f]==morph.f[f].a);assert(b[f]==morph.f[f].b);}
 morph_deep_set(&trk[0],1,3,1);morph_sync(&trk[0]);for(unsigned f=0;f<morph.n;f++)assert(b[f]==morph.f[f].b);
 /* Routing switches atomically between valid endpoints, with a history overlap
  * rather than a mute. Continuous fields still reach the exact endpoint. */
 unsigned switches=0;
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  load_morph(src,0,100);morph_deep_set(&trk[0],1,3,127);
  for(unsigned block=0;block<1600;block++){
   int16_t old[MORPH_FIELDS];for(unsigned f=0;f<morph.n;f++)old[f]=morph.f[f].current;
   render(1);assert(morph.gain==32768);
   for(unsigned f=0;f<morph.n;f++)if(morph.f[f].discrete){
    assert(morph.f[f].current==morph.f[f].a || morph.f[f].current==morph.f[f].b);
    if(old[f]!=morph.f[f].current){assert(morph_history.left);switches++;}
   }
  }
  assert(morph.pos==32512 && morph.gain==32768);
  for(unsigned f=0;f<morph.n;f++)assert(morph.f[f].current==morph.f[f].b);
 }
 assert(switches);
 /* Opposite-polarity stereo: smooth, bounded overlap, no forced mute,
  * exact new PCM at the end, including a restart during an active overlap. */
 load_morph(0,0,100);int32_t faded[CTL],stereo[CTL];morph.inside=1;
 for(unsigned i=0;i<MORPH_HISTORY;i++){morph_history.pcm[i][0]=10000;morph_history.pcm[i][1]=-10000;}
 morph_history.count=MORPH_HISTORY;morph_history.write=0;
 morph_history.last[0]=morph_history.previous[0]=10000;morph_history.last[1]=morph_history.previous[1]=-10000;
 morph_history.request=1;int32_t prev_pcm=10000;unsigned frames=0;
 while(frames<MORPH_FADE_FRAMES+CTL){
  for(unsigned k=0;k<CTL;k++){faded[k]=-10000;stereo[k]=10000;}
  morph_fade_pcm(&trk[0],faded,stereo,CTL);
  for(unsigned k=0;k<CTL;k++){assert(abs(faded[k])<=10000&&abs(stereo[k]+faded[k])<=1);assert(abs(faded[k]-prev_pcm)<=40);prev_pcm=faded[k];}
  frames+=CTL;
 }
 assert(!morph_history.left && faded[CTL-1]==-10000 && stereo[CTL-1]==10000);
 morph_history.request=1;
 for(unsigned k=0;k<CTL;k++){faded[k]=10000;stereo[k]=-10000;}
 morph_fade_pcm(&trk[0],faded,stereo,CTL);assert(morph_history.left && !morph_history.request);
 morph_history.request=1;morph_fade_pcm(&trk[0],faded,stereo,CTL);assert(morph_history.left);
 morph.inside=0;
 /* Hovering within the midpoint band cannot repeatedly flip routing. */
 load_morph(0,0,100);morph.pos=16100;morph_apply_position(CTL);unsigned latch=morph.discrete_b;
 for(unsigned j=0;j<100;j++){morph.pos=j&1?16350:16100;morph_apply_position(CTL);assert(morph.discrete_b==latch);}
 morph.pos=32512;morph_apply_position(CTL);assert(morph.discrete_b==1);
 for(unsigned j=0;j<100;j++){morph.pos=j&1?16350:16100;morph_apply_position(CTL);assert(morph.discrete_b==1);}
 printf("Morph stereo history %zu bytes in pool; runtime %zu bytes\n",sizeof morph_history,sizeof morph);
 printf("PASS: %u valid discrete transitions, 20 ms stereo history overlap/restart and exact settled endpoints\n",switches);
 /* Real worker compares Morph chord sources + BASS source engines against serial render. */
 pthread_t th;assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 static const unsigned basses[]={ENGI_FM6,ENGI_VA,ENGI_QUAD,ENGI_CZ,ENGI_BASS,5};unsigned concurrent=0;
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++)for(unsigned bi=0;bi<NELEM(basses);bi++){
  cr_c1_test_serial=1;load_morph(src,1%ENGINES[MORPH_SOURCE[src]]->npresets,30);
  cu_load(&trk[1],basses[bi],0,1);engine_block(&trk[1]);panic_req=0;trk_note_on(&trk[1],36,100);
  trk[0].p[P_E3]=1;trk[0].p[P_E4]=0;
  for(unsigned k=0;k<64;k++){if(k==24)trk_note_off(&trk[0],48);if(k==32)trk_note_on(&trk[0],48,90);engine_block(&trk[0]);engine_block(&trk[1]);mix_block(original_pcm[k],CTL);}
  memcpy(states,eng_state,sizeof states);memcpy(va_states,va_vs,sizeof va_states);memcpy(quad_states,quad_vs,sizeof quad_states);
  cr_c1_test_serial=0;load_morph(src,1%ENGINES[MORPH_SOURCE[src]]->npresets,30);
  cu_load(&trk[1],basses[bi],0,1);engine_block(&trk[1]);panic_req=0;trk_note_on(&trk[1],36,100);
  trk[0].p[P_E3]=1;trk[0].p[P_E4]=0;
  for(unsigned k=0;k<64;k++){if(k==24)trk_note_off(&trk[0],48);if(k==32)trk_note_on(&trk[0],48,90);engine_block(&trk[0]);engine_block(&trk[1]);mix_block(pcm,CTL);assert(!AW_C1_BUSY());assert(!morph.inside);assert(!memcmp(pcm,original_pcm[k],sizeof pcm));}
  assert(!memcmp(states,eng_state,sizeof states));assert(!memcmp(va_states,va_vs,sizeof va_states));assert(!memcmp(quad_states,quad_vs,sizeof quad_states));concurrent++;
 }
 pthread_cancel(th);pthread_join(th,0);audio_worker_online=0;cr_c1_test_serial=1;
 printf("PASS: Morph %u actual CPU1/serial PCM + native state comparisons\n",concurrent);
 load_morph(0,1,30);
 /* Real queued chord input through the emulator ISR. Held voicing/arp steps are not new chords. */
 int16_t half[HALF_WORDS];load_morph(0,1,30);trk_all_off(&trk[0]);cr_panic(&cr);panic_req=0;
 trk[0].p[P_E3]=2;trk[0].p[P_E6]=1;morph_sync(&trk[0]);uint32_t count=morph.chord_events;
 assert(cr_post(CRE_MOD,CR_MOD_MAJ,0,1));assert(cr_post(CRE_KEY,60,100,1));emu_fw_audio(half,HALF_FRAMES);
 assert(morph.chord_events==count+1);count=morph.chord_events;
 assert(cr_post(CRE_VOICING,0,0,1));emu_fw_audio(half,HALF_FRAMES);assert(morph.chord_events==count);
 assert(cr_post(CRE_PERFORM_MODE,0,0,CR_PM_ARP));assert(cr_post(CRE_PERFORM,0,0,1));
 for(unsigned i=0;i<100;i++)emu_fw_audio(half,HALF_FRAMES);assert(morph.chord_events==count);
 assert(cr_post(CRE_KEY,60,0,0));emu_fw_audio(half,HALF_FRAMES);
 assert(cr_post(CRE_KEY,60,100,1));emu_fw_audio(half,HALF_FRAMES);assert(morph.chord_events==count+1);
 count=morph.chord_events;assert(cr_loop_event(&cr,0,65,CR_Q_MAJ,0,100,1));assert(morph.chord_events==count+1);
 cr_set_loop_transpose(&cr,3);assert(morph.chord_events==count+1);
 cr_loop_event(&cr,0,65,CR_Q_MAJ,0,100,0);assert(cr_loop_event(&cr,0,67,CR_Q_MIN,0,100,1));assert(morph.chord_events==count+2);
 cr_rosen_mode=1;cr_rosen_pending=0;morph_chord(0,4);assert(!cr_rosen_pending);cr_rosen_mode=0;
 /* Enter/leave Morph with live voices and queued notes during the normal fade. */
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  load_morph(src,0,30);render(12);cu_engine_switch(0,ENGI_FM6);trk_note_on(&trk[0],69,100);render(20);
  assert(trk[0].engine==ENGI_FM6&&!morph.inside);
  cu_engine_switch(0,ENGI_MORPH);trk_note_on(&trk[0],72,100);render(20);assert(trk[0].engine==ENGI_MORPH&&!morph.inside);
 }
 load_morph(0,1,30);
 /* The existing packed record retains patch B and the random seed; no layout/version changes. */
 up_rec_t rec={0};rec.used=UP_USED;rec.ver=UP_VER;rec.engine=ENGI_MORPH;rec.np=P_COUNT;str_cpy(rec.name,"MORPH TEST",sizeof rec.name);
 for(unsigned i=0;i<P_COUNT;i++)up_set_value(&rec,i,trk[0].p[i]);
 assert(up_valid(&rec));int16_t loaded[P_COUNT];up_values(&rec,loaded);assert(loaded[P_E7]==trk[0].p[P_E7]);
 /* Every factory B id and maximum packed seed roundtrips as a valid record. */
 for(unsigned pb=0;pb<256;pb++){
  up_set_value(&rec,P_E7,(int16_t)(0x3f00u|pb));assert(up_valid(&rec));assert(up_value(&rec,P_E7)==(int16_t)(0x3f00u|pb));
 }
 up_set_value(&rec,P_E7,trk[0].p[P_E7]);
 up_rec_t legacy=rec;legacy.packed[140]=0x34;legacy.packed[141]=0x12;legacy.packed[142]=0x4d;legacy.packed[143]=0x38;
 int16_t migrated[P_COUNT];up_values(&legacy,migrated);assert(((uint16_t)migrated[P_E7]&255u)==(uint16_t)migrated[P_E1]);
 assert(sizeof(rec)==192 && sizeof(persist_t)==764);
 for(unsigned f=0;f<morph.n;f++){a[f]=morph.f[f].a;b[f]=morph.f[f].b;}
 memcpy(trk[0].p,loaded,sizeof loaded);fm6_track_loaded(&trk[0]);morph_sync(&trk[0]);
 for(unsigned f=0;f<morph.n;f++){assert(a[f]==morph.f[f].a);assert(b[f]==morph.f[f].b);}

 /* Only two editor groups and exact knob mapping. */
 ce.part=0;cu.page=PG_EDIT;cx.grp[0]=CE_OSC;cx.scr[0][CE_OSC]=0;
 assert(ce_has(&trk[0],CE_OSC)&&ce_has(&trk[0],CE_LFO));for(unsigned g=0;g<CE_NSEC;g++)if(g!=CE_OSC&&g!=CE_LFO)assert(!ce_has(&trk[0],g));
 ce_knob(0,1,0);assert(trk[0].p[P_E0]==1 && trk[0].p[P_E1]==0);
 ce_group(CE_LFO);ce_knob(2,1,0);assert(trk[0].p[P_E6]==1);
 if(getenv("MORPH_SCREENSHOTS")){
  ce_group(CE_OSC);screenshot("build/morph-tests/oscillator.ppm");
  morph_deep_set(&trk[0],0,3,1);cx.morph_focus[0]=3;screenshot("build/morph-tests/ping-pong.ppm");
  ce_group(CE_LFO);screenshot("build/morph-tests/settings.ppm");
 }
 uint8_t bass_engine=trk[1].eng_req;cu_engine_switch(1,ENGI_MORPH);assert(trk[1].eng_req==bass_engine);
 cu_load(&trk[1],ENGI_MORPH,0,1);assert(trk[1].eng_req==bass_engine);
 printf("PASS: Morph %u source/preset fixtures; real patch pairs, PCM guards, releases, exact zero amount, config restore, packed pair migration, stable endpoints, chord-only trigger, two-page UI, bass rejection; runtime %zu bytes\n",cases,sizeof morph);
 return 0;
}
