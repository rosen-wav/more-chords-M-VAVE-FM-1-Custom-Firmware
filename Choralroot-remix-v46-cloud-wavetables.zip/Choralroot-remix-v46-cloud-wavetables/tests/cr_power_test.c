#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#define FM1_POWER_MOCK
static uint8_t regs[256]; static unsigned writes,delay;
static uint8_t fm1_p33_read(uint32_t a) { return regs[a]; }
static void fm1_p33_write(uint32_t a,uint8_t d) { if (!writes)assert(a==6);regs[a]=d;writes++; }
static void fm1_delay_us(uint32_t t) { delay+=t; }
#include "../firmware/hal/fm1_power.h"
int main(void) {
 regs[9]=0xab;regs[6]=0x5b;regs[5]=4;fm1_power_init();
 assert(regs[9]==0xae && regs[6]==0x5c && regs[5]==4 && writes==4 && delay==1400);
 assert(fm1_power.boot[0]==11 && fm1_power.boot[1]==3);
 fm1_power_raise(FM1_RAIL_SYSVDD,99);fm1_power_raise(FM1_RAIL_VDC14,99);assert(writes==4);
 fm1_power_raise(FM1_RAIL_SYSVDD,0);assert(writes==4 && regs[9]==0xae);
 fm1_power_raise(FM1_RAIL_VDDIO,99);assert(regs[5]==4 && writes==4);
 puts("PASS: official CPU1 rails, VDC14 first, bounded one-step ramp, caps, no lowering, VDDIO untouched");
}
