/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cu_collection_choice=1;unsigned cases=0;
 for(unsigned p=0;p<ENGINES[ENGI_PROPHET]->npresets;p++){
  cu_pool_load(0,ENGI_PROPHET,pool_pos_factory(ENGI_PROPHET,p));unsigned n=cu_bass_count();
  cu_collection_toggle();assert(cu_bass_count()==n);assert(strstr(cu.msg.text,"can't be saved as bass"));cases++;
 }
 cu_pool_load(0,ENGI_PROPHET,pool_pos_factory(ENGI_PROPHET,3));assert(cb_store(&trk[0],0,31,"Prophet USER",0)==0);
 cu_pool_load(0,ENGI_PROPHET,pool_pos_slot(ENGI_PROPHET,31));unsigned n=cu_bass_count();cu_collection_toggle();assert(cu_bass_count()==n);cases++;
 cu_collection_choice=0;cu_collection_toggle();assert(favorite_has(ENG_USER_REF,31));cu_collection_choice=1;cases++;
 cu_init_load(1,ENGI_BASS);unsigned before=trk[1].eng_req;
 cu_load(&trk[1],ENGI_PROPHET,0,1);assert(trk[1].eng_req==before);
 cu_load_user(&trk[1],31,1);assert(trk[1].eng_req==before);
 cu_init_load(1,ENGI_PROPHET);assert(trk[1].eng_req==before);
 cu_engine_switch(1,ENGI_PROPHET);assert(trk[1].eng_req==before);cases+=4;
 assert(!crs_sound(1,(ENGI_PROPHET<<8)|1));assert(trk[1].eng_req==before);cases++;
 for(unsigned user=0;user<2;user++){
  cu_bass_ref(0)[0]=user?ENG_USER_REF:ENGI_PROPHET;cu_bass_ref(0)[1]=user?31:3;cu_bass_ref(1)[0]=255;
  cs.bass_sound=1;cs.bass_on=1;cu_bass_pick(0);assert(!cs.bass_on&&!cs.bass_sound&&trk[1].eng_req==before);cases++;
  cu_pool_load(0,ENGI_PROPHET,user?pool_pos_slot(ENGI_PROPHET,31):pool_pos_factory(ENGI_PROPHET,3));cu_collection_toggle();assert(!cu_bass_count());cases++;
 }
 cu.page=PG_NONE;trk[1].eng_req=ENGI_PROPHET;cu_save_open(1);assert(cu.page==PG_NONE);trk[1].eng_req=before;cases++;
 assert(!cu_bass_engine_block(1,ENGI_CLUSTER));assert(!cu_bass_engine_block(1,ENGI_CZ));assert(!cu_bass_engine_block(1,ENGI_SWARM));cases+=3;
 assert(sizeof(up_rec_t)==192&&sizeof(cr_settings_t)==192);
 printf("PASS: %u Prophet Bass restriction cases; all factories, USER, favourites preserved, guarded load/init/editor/boot, stale factory/USER references safely off and removable; other Bass engines retained\n",cases);
}
