/* Bit-exact PCM and full voice-state comparison against frozen Stage35 kernels. */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
#include "prophet_stage35_reference.h"
static uint32_t seed=0x12345678u;
static uint32_t next(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
int main(void){
 const uint32_t increments[]={0,1,32767,32768,1932735280u};
 for(unsigned k=0;k<NELEM(increments);k++)for(uint32_t f=0;f<=32768u;f++)
  assert(p5_phase_fraction(increments[k],f)==(uint32_t)(((uint64_t)increments[k]*f)>>15));
 unsigned cases=0; int16_t wheel[CTL*P5_OVERSAMPLE];uint16_t pitch[CTL*P5_OVERSAMPLE];
 for(unsigned preset=0;preset<P5_FACTORY_N+1001u;preset++){
  p5_patch_t patch; p5_patch_init(&patch);
  if(preset && preset<=P5_FACTORY_N)patch=P5_FACTORY[preset-1];
  if(preset>P5_FACTORY_N)for(unsigned j=0;j<55;j++)patch.raw[j]=next()%128;
  p5_voice_t a={0},b={0};a.phase[0]=next();a.phase[1]=next();a.noise=next();a.triangle=32767;a.amp_drift=(int32_t)(next()%1000)-500;b=a;
  for(unsigned block=0;block<64;block++){
   for(unsigned j=0;j<CTL*P5_OVERSAMPLE;j++){wheel[j]=(int32_t)(next()%32768)-16384;pitch[j]=16384+next()%16384;}
   p5_render_params_t c={0};
   c.f0=next()%32768;c.f1=next()%32768;c.a0=next()%32768;c.a1=next()%32768;
   c.ia=1+next()%500000000;c.ib=1+next()%500000000;
   c.cut=next()%(127*256);c.k=next()%19000;c.filter_gain=next()%32768;
   c.filter_velocity=next()%32768;c.amp_velocity=next()%32768;c.env_amount=next()%21000;
   c.pa_env=next()%11000;c.pa_b=next()%4500;c.pf_env=next()%29000;c.pf_b=next()%29000;
   c.pw_env=next()%8200;c.pw_b=next()%33000;c.pwm_a=next()%32768;c.pwm_b=next()%32768;
   c.la=next()%32767;c.lb=next()%32767;c.ln=next()%32767;c.wheel=wheel;c.wheel_pitch=pitch;
   vmod_t m={0};m.amp0=next()%32768;m.amp1=next()%32768;
   int32_t outa[CTL]={0},outb[CTL]={0};
   p5_reference_samples(&a,patch.raw,outa,CTL,&m,&c);p5_samples(&b,patch.raw,outb,CTL,&m,&c);
   assert(!memcmp(outa,outb,sizeof outa));assert(!memcmp(&a,&b,sizeof a));cases++;
  }
 }
 printf("PASS: Prophet Stage35 PCM + complete voice state, %u blocks (factory + randomized patches)\n",cases);
 return 0;
}
