/* SPDX-License-Identifier: GPL-3.0-only */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 unsigned cases=0,over=0;int32_t worst=0;uint64_t total=0;
#ifdef REQUIRE_DECLICK
 /* Other mixed voices are untouched; the transient expires exactly at 128 samples. */
 p5_voice_t smooth={0};smooth.retrigger_pending=1;int32_t raw[CTL];
 for(unsigned block=0;block<5;block++){
  for(unsigned i=0;i<CTL;i++)raw[i]=111-2048;
  p5_retrigger_smooth(&smooth,raw,CTL,8192,111);
  for(unsigned i=0;i<CTL;i++){unsigned pos=block*CTL+i;int32_t expected=111-2048;
   if(pos<128)expected+=(10240*(int32_t)(128-pos))>>7;assert(raw[i]==expected);}
 }
 assert(!smooth.retrigger_left&&!smooth.retrigger_pending&&!smooth.retrigger_offset);
#endif
 for(unsigned pr=0;pr<=P5_FACTORY_N;pr++){
  track_t *t=&trk[0];memset(t->v,0,sizeof t->v);t->engine=t->eng_req=ENGI_PROPHET;
  for(unsigned j=0;j<P_COUNT;j++)t->p[j]=TP[j].def;
  t->p[P_GLIDE]=0;t->p[P_VOICE]=V_POLY;t->mw=t->at=0;
  p5_preset_loaded(t,pr);memset(p5_part(0),0,sizeof(p5_part_t));
  voice_t *v=&t->v[0];v->active=v->gate=1;v->stage=1;v->age=1;v->vel=100;v->note=48;v->pitch16=v->pitch_cur=48*16;
  vmod_t m={0};m.pitch16=48*16;m.amp0=m.amp1=32767;
  voice_was=0;p5_note_on(t,v);
  int32_t pcm[CTL];
  for(unsigned k=0;k<256;k++){p5_block(t);memset(pcm,0,sizeof pcm);p5_render(t,v,pcm,CTL,&m);}
  for(unsigned hit=0;hit<24;hit++){
   int32_t before=pcm[CTL-1];
   v->gate=1;v->age++;v->note=(hit&1)?48:55;v->pitch16=v->pitch_cur=v->note*16;m.pitch16=v->pitch16;
   v->vel=(hit%3)?100:70;
#ifdef CONSTANT_VELOCITY
   v->vel=100;
#endif
   voice_was=(hit%2)?2:1;p5_note_on(t,v);
   p5_block(t);memset(pcm,0,sizeof pcm);p5_render(t,v,pcm,CTL,&m);
   int32_t jump=abs(pcm[0]-before);if(jump>worst)worst=jump;total+=jump;over+=jump>2048;cases++;
#ifdef REQUIRE_DECLICK
   assert(jump==0);
#endif
   for(unsigned k=0;k<8;k++){p5_block(t);memset(pcm,0,sizeof pcm);p5_render(t,v,pcm,CTL,&m);}
  }
 }
 printf("Prophet retrigger: %u factory transitions; first-sample max jump %d, total %llu, >2048 %u; serial native DSP (no USB/CPU1/FX)\n",cases,worst,(unsigned long long)total,over);
 return 0;
}
