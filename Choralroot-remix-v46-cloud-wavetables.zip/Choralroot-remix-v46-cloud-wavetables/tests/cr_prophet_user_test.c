/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void identical(const p5_patch_t *p){
 const p5_patch_t *now=p5_patch_of(&trk[0]);assert(!memcmp(p,now,sizeof *p));
}
static int32_t pcm_a[2*CTL],pcm_b[2*CTL];
static void render_native(int32_t *out){
 memset(trk[0].v,0,sizeof trk[0].v);trk[0].xf_on=trk[0].xp_n=trk[0].nmono=0;
 memset(p5_part(0),0,sizeof(p5_part_t)); /* reset native states for exact comparison */
 vage=0;unison_seed=0x1234567u;rng_state=0x1234567u;
 trk_note_on(&trk[0],60,100);engine_block(&trk[0]);
 memset(out,0,2*CTL*sizeof *out);vmod_t m={0};m.pitch16=60*16;
 for(unsigned i=0;i<NVOICE;i++)if(trk[0].v[i].active){p5_render(&trk[0],&trk[0].v[i],out,CTL,&m);break;}
 trk_all_off(&trk[0]);
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);unsigned checks=0;
 assert(P_COUNT==91&&sizeof(up_rec_t)==192&&sizeof(up_bank_t)==3080);
 for(unsigned pi=0;pi<=P5_FACTORY_N;pi++){
  cu_pool_load(0,ENGI_PROPHET,pool_pos_factory(ENGI_PROPHET,pi));
  p5_patch_t *p=p5_patch_of(&trk[0]);
  for(unsigned j=0;j<57;j++){unsigned k=j<55?j:j==55?P5_BEND:P5_RETRIGGER;p->raw[k]=(uint8_t)((p->raw[k]+1u+j%5u)&127u);}
  p5_patch_t expected=*p;render_native(pcm_a);int16_t params[P_COUNT];memcpy(params,trk[0].p,sizeof params);
  assert(cb_store(&trk[0],0,31,"PROP NATIVE",pi+1)==0);assert(up_valid(up_rec(31))&&up_p5_has(up_rec(31)));
  for(unsigned neighbor=0;neighbor<2;neighbor++){
   cu_load(&trk[0],ENGI_PROPHET,(pi+P5_FACTORY_N+(neighbor?1u:0u))%(P5_FACTORY_N+1u),0);
   cu_load_user(&trk[0],31,0);identical(&expected);assert(!memcmp(params,trk[0].p,sizeof params));render_native(pcm_b);assert(!memcmp(pcm_a,pcm_b,sizeof pcm_a));checks++;
  }
  /* Both records survive a flash read and USER-to-USER overwrite. */
  memset(up_bank,0,sizeof up_bank);up_boot();cu_load(&trk[0],ENGI_PROPHET,(pi+1)%(P5_FACTORY_N+1u),0);cu_load_user(&trk[0],31,0);identical(&expected);checks++;
  p5_patch_of(&trk[0])->raw[0]^=1u;expected=*p5_patch_of(&trk[0]);assert(cb_store(&trk[0],0,31,"OVERWRITE",pi+1)==0);
  assert(up_rename(31,"RENAMED")==0);cu_load(&trk[0],ENGI_PROPHET,0,0);cu_load_user(&trk[0],31,0);identical(&expected);checks++;
  assert(cb_store(&trk[0],0,30,"NEW USER",0)==0);cu_load(&trk[0],ENGI_PROPHET,pi,0);cu_load_user(&trk[0],30,0);identical(&expected);checks++;
  song.sel=0;assert(up_store(29,"OLD STORE")==0);cu_load(&trk[0],ENGI_PROPHET,0,0);up_load(29);identical(&expected);checks++;
 }
 /* Exercise actual UI Overwrite and naming paths rather than only cb_store. */
 cu_pool_load(0,ENGI_PROPHET,pool_pos_factory(ENGI_PROPHET,3));p5_patch_of(&trk[0])->raw[0]^=3u;p5_patch_t expected=*p5_patch_of(&trk[0]);
 cu_edited(0);cu_save_open(0);ce.save_choice=0;cu_save_take();unsigned slot=psnd[0].slot;assert(slot<UP_SLOTS);cu_load(&trk[0],ENGI_PROPHET,4,0);cu_load_user(&trk[0],slot,0);identical(&expected);checks++;
 cu_save_open(0);ce.save_choice=1;cu_save_take();assert(ce.save_step);cn_open("NEW PROPHET");cu_save_commit();slot=psnd[0].slot;cu_load(&trk[0],ENGI_PROPHET,2,0);cu_load_user(&trk[0],slot,0);identical(&expected);checks++;
 /* A legacy bound record restores the factory; an unbound legacy record
  * uses INIT explicitly, never the neighboring patch. */
 up_rec_t old=*up_rec(31);memset(old.packed+91,0,53);old.note[15]=0xA6;old.flags[15]=5;assert(up_put(31,&old)==0);
 cu_load(&trk[0],ENGI_PROPHET,9,0);cu_load_user(&trk[0],31,0);identical(&P5_FACTORY[3]);checks++;
 old.note[15]=old.flags[15]=0;assert(up_put(31,&old)==0);cu_load(&trk[0],ENGI_PROPHET,7,0);cu_load_user(&trk[0],31,0);p5_patch_t init;p5_patch_init(&init);identical(&init);checks++;
 cu_init_load(0,ENGI_PROPHET);identical(&init);checks++;
 /* Invalid native 8-bit values must refuse the save, without changing slot. */
 old=*up_rec(31);p5_patch_of(&trk[0])->raw[0]=255;assert(cb_store(&trk[0],0,31,"BAD",0)==2&&!memcmp(&old,up_rec(31),sizeof old));checks++;
 printf("PASS: Prophet USER %u checks; all factory/INIT patches edited and saved, both adjacent reloads, simulated reboot, overwrite/rename/new USER, old store/load, real UI overwrite/naming, legacy explicit fallback, native range guard; unchanged 192/3080-byte records\n",checks);
}
