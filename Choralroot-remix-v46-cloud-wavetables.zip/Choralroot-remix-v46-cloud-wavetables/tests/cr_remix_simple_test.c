/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void drain(void){cr_audio_block(CTL);cr_snapshot();}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);unsigned cases=0;
 /* Simple and Advanced have identical live quality/extension edits. Only
  * the following root gesture resets Simple's extensions. */
 for(unsigned root=48;root<72;root++)for(unsigned q=0;q<2;q++)for(unsigned mask=0;mask<16;mask++){
  if((mask&6)==6)continue;
  cr_t s,a;cr_init(&s,0);cr_init(&a,0);cr_set_playstyle(&s,CR_PS_SIMPLE);cr_set_playstyle(&a,CR_PS_ADVANCED);
  cr_mod(&s,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&a,q?CR_MOD_MIN:CR_MOD_MAJ,1);
  for(unsigned j=0;j<4;j++)if(mask&(1u<<j)){cr_mod(&s,(cr_mod_t)(CR_MOD_6+j),1);cr_mod(&a,(cr_mod_t)(CR_MOD_6+j),1);}
  cr_key(&s,root,100,1);cr_key(&a,root,100,1);assert(s.v[0].sx==a.v[0].sx&&s.v[0].rq==a.v[0].rq);
  cr_mod(&s,q?CR_MOD_MAJ:CR_MOD_MIN,1);cr_mod(&a,q?CR_MOD_MAJ:CR_MOD_MIN,1);
  assert(s.v[0].rq==a.v[0].rq&&s.v[0].sx==a.v[0].sx); /* no reset for MAJ/MIN */
  cr_mod(&s,CR_MOD_9,1);cr_mod(&a,CR_MOD_9,1);assert(s.v[0].sx==a.v[0].sx);
  uint8_t old=s.v[0].sx;cr_key(&s,root+1,100,1);cr_key(&a,root+1,100,1);
  assert(s.v[1].sx==0&&a.v[1].sx==a.v[0].sx&&s.v[0].sx==old);assert(s.simple_reset_serial==1);
  cr_key(&s,root+1,100,1);assert(s.v[1].sx==0&&s.simple_reset_serial==2);cases++;
 }
 /* Both seventh buttons still replace each other immediately. */
 cr_t s;cr_init(&s,0);cr_mod(&s,CR_MOD_MAJ,1);cr_key(&s,60,100,1);cr_mod(&s,CR_MOD_M7,1);cr_mod(&s,CR_MOD_MAJ7,1);
 assert(s.v[0].sx==CR_EXT_MAJ7);cr_mod(&s,CR_MOD_M7,1);assert(s.v[0].sx==CR_EXT_M7);cases++;
 /* Loop replay and pads cannot consume the next-key reset. */
 uint32_t serial=s.simple_reset_serial;cr_loop_event(&s,0,65,CR_Q_MIN,CR_EXT_6,100,1);assert(s.simple_reset_serial==serial&&s.mods_down&(1u<<CR_MOD_M7));
 cr_loop_event(&s,0,65,0,0,0,0);cr_pad_set(&s,0,1,67,CR_Q_MAJ,CR_EXT_9,100);cr_pad_down(&s,0);cr_pad_up(&s,0);assert(s.simple_reset_serial==serial);cases++;
 cr_set_keys_only(&s,1);cr_key(&s,68,100,1);assert(s.simple_reset_serial==serial);cases++;
 /* LOCK LEDs and virtual holds expire only at the next note; physical stale
  * releases cannot relatch. New modifier downs after that note remain valid. */
 clear(ENGI_FM6,0,0);cr_set_playstyle(&cr,CR_PS_SIMPLE);memset(cu.key_note,0,sizeof cu.key_note);cu.kheld=cu.mlatch=cu.mkill=0;cu.clock=1;cr_mlock=1;cu.simple_reset_seen=cr.simple_reset_serial;
 cu_mod_press(5);drain();cu_mod_release(5);drain();cu_mod_press(2);drain();cu_mod_release(2);drain();assert(cu.mlatch&(1u<<CR_MOD_M7));
 cu_key_press(CU_ROOT0);drain();assert(cr.v[0].sx==CR_EXT_M7);cu_key_release(CU_ROOT0);drain();
 cu_key_press(CU_ROOT0+2);drain();cr_ui_frame();assert(cr.v[0].sx==0&&!(cu.mlatch&(1u<<CR_MOD_M7)));cases++;
 cu_key_release(CU_ROOT0+2);drain();
 cu_key_press(2);drain();cu_key_press(CU_ROOT0+4);drain();cr_ui_frame();cu_key_release(2);drain();assert(!(cu.mlatch&(1u<<CR_MOD_M7)));cases++;
 cu_key_release(CU_ROOT0+4);drain();
 /* Fast root + fresh modifier batch must preserve the newly selected extension. */
 cu_key_press(CU_ROOT0);cu_key_press(4);drain();cr_ui_frame();assert(cr.v[0].sx==CR_EXT_MAJ7);cu_key_release(4);drain();assert(cu.mlatch&(1u<<CR_MOD_MAJ7));cases++;
 printf("PASS: Simple %u cases; Advanced-equivalent live edits, next-key reset only, overlapping/repeated roots, exclusive sevenths, no loop/pad/keys-only reset, LOCK expiration/held release/fresh modifier queue\n",cases);
}
