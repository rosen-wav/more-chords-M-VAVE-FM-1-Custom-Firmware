/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void drain(void){cr_audio_block(CTL);cr_snapshot();}
static void wait_start(void){unsigned n=0;while(crl.play_armed==1u&&n++<5000u)drain();assert(crl.play_armed!=1u);}
static void tap(unsigned b){cu_btn_press(b);cu_btn_release(b);drain();if(b==BT_LOOP)wait_start();}
static void scanned_hold(unsigned b){
 uint32_t t=fm1_ms+20u;emu_hal.buttons=1u<<panel.btn[b];emu_fw_tick(t);cr_ui_input();
 emu_fw_tick(t+HOLD_MS[settings_hold%4u]+1u);cr_ui_input();drain();
}
static void scanned_release(void){emu_hal.buttons=0;emu_fw_tick(fm1_ms+20u);cr_ui_input();drain();}
static unsigned previews(void){unsigned n=0;for(unsigned i=CR_MAX_VOICES;i<CR_MAX_VOICES+CR_MAX_PADS;i++)n+=cr.v[i].used&&cr.v[i].loop==255u;return n;}
static void shot(const char *path){
 cr_screen_t s;cu.pop.until=cu.msg.until=0;cr_build_screen(&s,cu_now());cr_draw(&s,CR_ANIM_SETTLED);
 FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned i=0;i<240*240;i++){uint16_t c=emu_hal.lcd[i];c=(c>>8)|(c<<8);uint8_t rgb[3]={(uint8_t)(((c>>11)&31)*255/31),(uint8_t)(((c>>5)&63)*255/63),(uint8_t)((c&31)*255/31)};fwrite(rgb,1,3,f);}fclose(f);
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);clear(ENGI_FM6,0,0);cr_loop_clear(&crl,&cr);drain();
 cs.loop_len=2;crl.sync=2;crl.mode=CRL_MODE_OVERDUB;cs.loop_mode=CRL_MODE_OVERDUB;unsigned checks=0;
 scanned_hold(BT_METRO);assert(cu.step_editor&&crl.grid_editor);scanned_release();assert(!cu_layer_keys(L_METRO));
 assert(cr_snap.grid_count==8&&cr_snap.grid_rate[0]==2&&crl.d.grid_n==0);checks++;
 tap(BT_FX);assert(!crl.d.nev&&!crl.d.grid_n);
 cu_key_press(5);drain();cu_key_press(CU_ROOT0);drain();cr_mod(&cr,CR_MOD_MIN,1);cr_mod(&cr,CR_MOD_9,1);
 tap(BT_FX);assert(crl.d.nev==1&&crl.d.len==768&&crl.d.grid_n==8&&crl.d.grid_global&&crl.state==CRL_STOPPED);
 assert(crl.d.ev[0].t==0&&crl.d.ev[0].dur==96&&crl.d.ev[0].qx>>4==CR_Q_MIN&&(crl.d.ev[0].qx&15)==CR_EXT_9);checks+=2;
 cu_key_release(CU_ROOT0);cu_key_release(5);drain();
 for(unsigned i=0;i<32;i++)drain();assert(crl.state==CRL_STOPPED);checks++;
 tap(BT_LOOP);assert(crl.state==CRL_PLAYING&&cu.step_editor);tap(BT_LOOP);assert(crl.state==CRL_STOPPED);tap(BT_LOOP);assert(crl.state==CRL_PLAYING);checks+=3;
 /* Real queued USB/TRS realtime messages share the loop transport. */
 cr_route.clock_in=1;drain();
 for(unsigned source=1;source<=2;source++){
  assert(midi_enqueue(0xFCu<<8|0x0Fu,source));drain();assert(crl.state==CRL_STOPPED);
  assert(midi_enqueue(0xF8u<<8|0x0Fu,source));drain();assert(crl.state==CRL_STOPPED);
  assert(midi_enqueue(0xFAu<<8|0x0Fu,source));drain();assert(crl.state==CRL_PLAYING);
  assert(midi_enqueue(0xFAu<<8|0x0Fu,source));drain();assert(crl.state==CRL_PLAYING);
  assert(midi_enqueue(0xFCu<<8|0x0Fu,source));drain();assert(crl.state==CRL_STOPPED);
  assert(midi_enqueue(0xFBu<<8|0x0Fu,source));drain();assert(crl.state==CRL_PLAYING);checks+=6;
 }
 cr_route.clock_in=0;drain();

 for(unsigned k=1;k<8;k++){tap(CU_GRID_BTN[k]);assert(crl.d.nev==k+1&&crl.d.ev[k].t==k*96&&crl.d.ev[k].dur==96);checks++;}
 cr_leds();for(unsigned k=0;k<8;k++){unsigned q=cu_led_pos[panel.btn[CU_GRID_BTN[k]]];assert(fm1_led[q>>3]&(1u<<(q&7)));checks++;}
 /* Held preview is independent of playback, gestures, pad data and randomization. */
 crl_data_t original=crl.d;cr_chord_t pads[CR_MAX_PADS];memcpy(pads,cr.pads,sizeof pads);
 uint32_t simple=cr.simple_reset_serial,rosen=cr_rosen_generation,serial=crl.gen;int voicing=cr.voicing;
 scanned_hold(BT_FX);assert(cu.grid_hold&&!previews()&&crl.state==CRL_PLAYING);
 assert(!memcmp(&original,&crl.d,sizeof original)&&!memcmp(pads,cr.pads,sizeof pads));
 assert(cr.simple_reset_serial==simple&&cr_rosen_generation==rosen&&cr.voicing==voicing&&crl.gen==serial);checks+=3;
 /* SELECT changes note duration only; no timestamp, other gate or total-length change. */
 cu_knob(EN_SELECT,1);drain();assert(crl.d.ev[0].dur==192&&crl.d.ev[1].dur==96&&crl.d.ev[1].t==96&&crl.d.len==768&&cu.grid_sel==0);
 assert(!previews());shot("build/host/remix-step-preview.ppm");scanned_release();assert(!previews()&&crl.d.nev==8);checks+=3;
 /* SEQ is the eighth preview, no longer the exit button. */
 scanned_hold(BT_METRO);assert(cu.grid_hold&&cu.grid_sel==7&&!previews());
 emu_fw_tick(fm1_ms+1500u);cr_ui_input();drain();assert(cu.step_editor);scanned_release();assert(!previews()&&crl.d.nev==8);checks+=2;
 /* Starting via MIDI or local queued PLAY ends an existing stopped audition. */
 tap(BT_LOOP);assert(crl.state==CRL_STOPPED);scanned_hold(BT_FX);assert(previews()==1);checks++;
 cr_route.clock_in=1;assert(midi_enqueue(0xFAu<<8|0x0Fu,2u));drain();assert(crl.state==CRL_PLAYING&&!previews()&&cu.grid_hold);checks++;
 assert(midi_enqueue(0xFCu<<8|0x0Fu,2u));drain();assert(crl.state==CRL_STOPPED&&!previews());scanned_release();cr_route.clock_in=0;checks++;
 scanned_hold(BT_FX);assert(previews()==1);assert(cr_post(CRE_LOOP,LP_PLAY,0,0));drain();wait_start();assert(crl.state==CRL_PLAYING&&!previews());scanned_release();checks++;
 tap(BT_LOOP);assert(crl.state==CRL_STOPPED);checks++;
 /* Release safety even when the control queue is saturated. */
 scanned_hold(BT_FX);assert(previews()==1);while(cr_post(CRE_LOOP,LP_CONF,LC_VOL,70));
 scanned_release();assert(!previews()&&crl.d.nev==8);tap(BT_LOOP);assert(crl.state==CRL_PLAYING);checks++;
 /* Hold PLAY exits to its menu and never toggles playing. Re-enter via SEQ. */
 scanned_hold(BT_LOOP);assert(!cu.step_editor&&cu_layer()==L_LOOP&&crl.state==CRL_PLAYING);scanned_release();
 scanned_hold(BT_METRO);scanned_release();assert(cu.step_editor&&crl.state==CRL_PLAYING);
 scanned_hold(BT_EDIT);assert(!cu.step_editor&&cu.lock==L_NONE&&cu.page==PG_NONE&&crl.state==CRL_PLAYING);scanned_release();
 scanned_hold(BT_METRO);scanned_release();scanned_hold(BT_OPT);assert(!cu.step_editor&&!cu.opt_open&&crl.state==CRL_PLAYING);scanned_release();
 scanned_hold(BT_METRO);scanned_release();checks+=5;
 /* A grid change must not release active loop voices or restart their scan. */
 {unsigned char voices[sizeof cr.v],owners[sizeof crl.pv];memcpy(voices,cr.v,sizeof voices);memcpy(owners,crl.pv,sizeof owners);
  uint32_t cyc=crl.cyc0,scan=crl.scan,t=crl.t;assert(cr_loop_grid_edit(&crl,&cr,0,1)>0);
  assert(!memcmp(voices,cr.v,sizeof voices)&&!memcmp(owners,crl.pv,sizeof owners)&&crl.cyc0==cyc&&crl.scan==scan&&crl.t==t&&crl.state==CRL_PLAYING);
  assert(cr_loop_grid_edit(&crl,&cr,0,2)>0);drain();checks++;}
 /* ALGORITHM changes the grid only: musical onset, gate and bars remain exact. */
 cu_knob(EN_ALGO,-1);drain();assert(crl.d.len==768&&crl.d.grid_n==16);
 for(unsigned k=0;k<8;k++)assert(crl.d.ev[k].t==k*96&&crl.d.grid_dur[k]==1);
 assert(crl.d.ev[0].dur==192&&crl.d.ev[1].dur==96);checks++;
 cu_knob(EN_ALGO,-1);cu_knob(EN_ALGO,1);drain();assert(crl.d.grid_dur[0]==1);checks++;
 /* EDIT back / GLOBAL forward; OCT buttons change only keyboard octave. */
 tap(BT_OPT);assert(cu.grid_sel==8);tap(BT_EDIT);assert(cu.grid_sel==0&&cu.step_editor);int octave=cu.octave;
 tap(B_OCTUP);assert(cu.grid_sel==0&&cu.octave==octave+1&&cu.step_editor);tap(B_OCTDN);assert(cu.grid_sel==0&&cu.octave==octave);
 for(unsigned i=0;i<6;i++)tap(B_OCTUP);assert(cu.octave==2&&cu.grid_sel==0);cu_key_press(CU_ROOT0);assert(cu.key_note[CU_ROOT0]==53+CU_ROOT0+24+1);cu_key_release(CU_ROOT0);drain();
 for(unsigned i=0;i<6;i++)tap(B_OCTDN);assert(cu.octave==-2&&cu.grid_sel==0);cu.octave=(int8_t)octave;cu.pop.until=0;checks+=3;
 cu_knob(EN_SELECT,1000);drain();assert(cu.grid_sel==15);checks+=3;
 crl_data_t exact=crl.d;cr_ui_frame();cu_knob(EN_ALGO,2);drain();assert(cr_grid_result==1&&crl.d.grid_dur[0]==3);
 assert(crl.d.grid_n==4&&crl.d.len==exact.len&&crl.d.nev==exact.nev&&!memcmp(crl.d.ev,exact.ev,exact.nev*sizeof(crl_ev_t))&&crl.state==CRL_PLAYING);
 cu_knob(EN_ALGO,-2);drain();assert(crl.d.grid_dur[0]==1&&!memcmp(crl.d.ev,exact.ev,exact.nev*sizeof(crl_ev_t)));checks++;
 /* Page navigation stops a held audition, without leaving or changing transport. */
 cu.grid_sel=0;scanned_hold(BT_FX);assert(!previews());tap(BT_OPT);assert(cu.step_editor&&cu.grid_sel==8&&!previews()&&crl.state==CRL_PLAYING);scanned_release();scanned_hold(BT_EDIT);scanned_release();checks++;
 /* Stop, choose eight bars in PLAY, then grid 1/16 -> all 128 cells, 16 pages. */
 cr_loop_clear(&crl,&cr);cr_panic(&cr);cs.loop_len=4;crl.sync=4;drain();scanned_hold(BT_METRO);scanned_release();
 cu_knob(EN_ALGO,-2);drain();assert(cr_snap.grid_count==128&&crl.d.len==3072&&crl.d.grid_dur[0]==0);
 cr_key(&cr,60,100,1);tap(BT_FX);cr_key(&cr,60,0,0);drain();
 cu_knob(EN_SELECT,1000);drain();assert(cu.grid_sel==127);tap(BT_METRO);assert(crl.d.nev==2&&crl.d.ev[1].t==3048);
 cr_screen_t sc;cu.pop.until=cu.msg.until=0;cr_build_screen(&sc,cu_now());assert(sc.kr_band==2&&sc.wv[2]==15&&strstr(sc.label,"16/16"));
 shot("build/host/remix-step-page16.ppm");checks+=3;
 /* Four SEQ knobs stay in place and PRESET is still the normal browser. */
 unsigned p=trk[0].preset;cu_knob(EN_PRESET,1);drain();assert(trk[0].preset!=p&&cu.step_editor);
 cu_knob(EN_K1,-4);drain();assert(cs.metro&&crl.metro);cr_route.clock_in=0;cu_knob(EN_K2,1);drain();assert(cr.bpm==cs.bpm);
 unsigned bpm=cr.bpm;cr_route.clock_in=1;cu_knob(EN_K2,3);drain();assert(cr.bpm==bpm);cr_route.clock_in=0;
 cu_knob(EN_K3,1);drain();assert(cr_sidechain_on);cu_knob(EN_K4,7);drain();assert(cr.loop_transpose==7);checks+=6;
 /* The exact same save/load path as loops, including second-bank slot 20. */
 assert(crl.state==CRL_STOPPED);tap(BT_LOOP);assert(crl.state==CRL_PLAYING);tap(BT_LOOP);assert(crl.state==CRL_STOPPED);assert(cu_loop_save_now(19));
 crl_data_t saved=crl.d;cr_loop_clear(&crl,&cr);drain();cu_loop_load(19);drain();assert(!memcmp(&saved,&crl.d,crl_data_size(saved.nev))&&crl.sync==4&&cs.loop_len==4&&cu.loop_bank==1);checks++;
 /* Keys-only held triad inserts all three notes; preview does not replace them. */
 cr_loop_clear(&crl,&cr);cr_panic(&cr);cr_set_keys_only(&cr,1);crl.sync=2;cs.loop_len=2;cu.grid_sel=0;
 cr_key(&cr,60,100,1);cr_key(&cr,64,90,1);cr_key(&cr,67,80,1);drain();tap(BT_FX);assert(crl.d.nev==3);
 cr_key(&cr,60,0,0);cr_key(&cr,64,0,0);cr_key(&cr,67,0,0);drain();scanned_hold(BT_FX);assert(previews()==3);scanned_release();assert(!previews()&&crl.d.nev==3);checks+=2;
 /* Visible gate spans distinguish a sustained rest from an occupied onset. */
 cr_loop_clear(&crl,&cr);cr_panic(&cr);cs.loop_len=4;crl.sync=4;cu.grid_sel=7;drain();
 tap(BT_METRO);assert(crl.state==CRL_STOPPED);scanned_hold(BT_METRO);cu_knob(EN_SELECT,2);drain();
 cr_screen_t held;cu.pop.until=cu.msg.until=0;cr_build_screen(&held,cu_now());assert(held.wv[5]==128u&&held.wv[4]==0u);checks++;
 scanned_release();tap(BT_OPT);assert(cu.grid_sel==15);cr_build_screen(&held,cu_now());
 assert(held.wv[4]==3u&&held.wv[5]==1u&&held.wv[0]==0u&&crl.state==CRL_STOPPED);checks++;
 shot("build/host/remix-step-sustain-page2.ppm");
 /* Overlapping onsets retain occupancy while showing the held note underneath. */
 cu.grid_sel=8;tap(BT_FX);cr_build_screen(&held,cu_now());assert(held.wv[4]==3u&&held.wv[0]==1u);checks++;
 shot("build/host/remix-step-sustain-overlap.ppm");
 tap(BT_FX);tap(BT_EDIT);scanned_hold(BT_METRO);cu_knob(EN_SELECT,-2);drain();scanned_release();tap(BT_OPT);
 cr_build_screen(&held,cu_now());assert(!held.wv[4]&&!held.wv[5]&&!held.wv[0]);checks++;
 /* Playhead follows actual transport ticks, independently of selection and occupancy. */
 tap(BT_LOOP);assert(crl.state==CRL_PLAYING);cu.grid_sel=15;
 crl.t=crl.cyc0+8u*96u;cr_snapshot();cr_build_screen(&held,cu_now());
 assert(held.wv[6]==1u&&held.wv[7]==9u&&held.wv[8]==32u&&cu.grid_sel==15);checks++;
 shot("build/host/remix-step-playhead.ppm");
 crl.t=crl.cyc0+9u*96u-1u;cr_snapshot();cr_build_screen(&held,cu_now());assert(held.wv[6]==1u&&held.wv[7]==9u);checks++;
 crl.t++;cr_snapshot();cr_build_screen(&held,cu_now());assert(held.wv[6]==2u&&held.wv[7]==10u);checks++;
 cu.grid_sel=0;cr_build_screen(&held,cu_now());assert(!held.wv[6]&&held.wv[7]==10u);checks++;
 crl.t=crl.cyc0+crl.d.len;cr_snapshot();cr_build_screen(&held,cu_now());assert(held.wv[6]==1u&&held.wv[7]==1u);checks++;
 tap(BT_LOOP);cr_build_screen(&held,cu_now());assert(!held.wv[6]&&!held.wv[7]);checks++;
 cr_route.clock_in=1;assert(midi_enqueue(0xFAu<<8|0x0Fu,2u));drain();cr_build_screen(&held,cu_now());
 assert(held.wv[6]==1u&&held.wv[7]==1u&&crl.state==CRL_PLAYING);checks++;
 assert(midi_enqueue(0xFCu<<8|0x0Fu,2u));drain();cr_build_screen(&held,cu_now());assert(!held.wv[6]&&!held.wv[7]);checks++;
 printf("PASS: paged Step %u checks; global quarter defaults, PLAY bars, 128 cells, EDIT/GLOBAL pages, keyboard OCT +/-, stopped-only preview/live SELECT length, SEQ preview, held EDIT/GLO/PLAY exit, no auto start, queued USB/TRS Start/Continue/Stop, release overflow guard, V3 loop slot20 save/load, live keys/presets, four knobs/MIDI tempo, no randomization/pad mutation, visible sustained rests/overlap across pages, transport playhead/boundaries/wrap/stop/MIDI\n",checks);
}
