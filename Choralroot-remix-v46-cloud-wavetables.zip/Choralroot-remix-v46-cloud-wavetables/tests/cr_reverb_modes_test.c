/* Church is the only algorithm in Remix V42; controls covered by real firmware integration. */
#include "cr_v42_features_test.c"
