/* Automatic rosen changes keep live FX, even across favourite engines/users. */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
int main(void) {
 unsigned mode,on,source,step,i,model,checks=0;int16_t global[G_COUNT],bass_fx[4];
 const uint8_t amounts[4]={103,47,81,29};
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 /* A real user record, included in favourites and mixed with factory engines. */
 {up_rec_t *r=up_rec(0);memset(r,0,sizeof *r);r->used=UP_USED;r->ver=UP_VER;r->np=P_COUNT;r->engine=ENGI_CZ;
  memcpy(r->name,"FX TEST",7);for(i=0;i<P_COUNT;i++)up_set_value(r,i,TP[i].def);
  for(i=0;i<8;i++)up_set_value(r,P_E0+i,ENG_CZ.edit[i].def);assert(up_used(0));}
 for(mode=1;mode<=3;mode++)for(on=0;on<2;on++)for(source=0;source<2;source++)for(model=0;model<4;model++) {
  memset(&favorites,0,sizeof favorites);favorite_set(ENGI_FM6,1,1);favorite_set(ENGI_CZ,1,1);favorite_set(ENG_USER_REF,0,1);
  cu_pool_load(0,ENGI_FM6,0);cu_fav_browser=source;cu_fav_index=0;
  cr_rosen_mode=mode;cu_ping_valid=0;cr_rosen_pending=0;
  cs.fx_on=on;cs.fx_sel=2;memcpy(cs.fx_amt,amounts,sizeof amounts);cu_fx_apply();
  song.g[G_RTYPE]=model;song.g[G_RSIZE]=93;song.g[G_RDAMP]=72;
  song.g[G_DTIME]=9;song.g[G_DFDBK]=67;song.g[G_DCOLOR]=41;
  song.g[G_CRATE]=38;song.g[G_CDEPTH]=65;memcpy(global,song.g,sizeof global);
  for(i=0;i<4;i++)bass_fx[i]=trk[1].p[P_DIST+i];
  for(step=0;step<12;step++) {
   cu_popup("keep", "manual overlay", "FX", CR_COL_GREEN, 3, 0, 10, 10);
   unsigned char popup[sizeof cu.pop];memcpy(popup,&cu.pop,sizeof popup);
   cr_rosen_generation++;cr_rosen_pending=1;cu_rosen_service();
   assert(!memcmp(popup,&cu.pop,sizeof popup));
   assert(cr_rosen_pending==2);assert(cs.fx_on==on&&cs.fx_sel==2);
   assert(!memcmp(cs.fx_amt,amounts,sizeof amounts));assert(!memcmp(song.g,global,sizeof global));
   for(i=0;i<4;i++){assert(trk[0].p[CU_FX[i].send]==(on?amounts[i]:0));assert(trk[1].p[P_DIST+i]==bass_fx[i]);}
   if(source&&mode==1&&step==2)assert(trk[0].user==1); /* full favourite wrap includes USER */
   checks++;
  }
 }
 /* Manual loads still import their preset mix. */
 cu_fav_browser=0;cs.fx_on=1;memcpy(cs.fx_amt,amounts,sizeof amounts);
 cu_pool_load(0,ENGI_CZ,0);cu_sends_to_fx();assert(memcmp(cs.fx_amt,amounts,sizeof amounts));checks++;
 /* Manual favourite selection continues to show the sound popup. */
 cu.pop.until=0;cu_fav_load(0);assert(cu.pop.until && !strncmp(cu.pop.label,"FAVOURITES",10));checks++;
 printf("rosen FX: %u checks PASS (Next/Random/Ping Pong, On/Off, four reverb models, factory/user/cross-engine favourites, globals, BASS, manual load, automatic popup suppression/manual popup retained)\n",checks);return 0;
}
