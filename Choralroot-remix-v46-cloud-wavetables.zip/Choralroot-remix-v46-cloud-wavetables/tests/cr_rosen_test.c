/* Host integration test. Linux uses a pthread substitute for macOS os/lock.h. */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
static int has(uint32_t n) { unsigned i; for(i=0;i<NVOICE;i++) if(trk[0].v[i].gate && trk[0].v[i].note==n) return 1; return 0; }
int main(void) {
 unsigned e,i; int notes[6]={60,64,67,70,74,81};
 emu_fw_options(0,1,0,1); emu_fw_init(0);
 cu.armed=BT_OPT; cu.combo=0; cu.page=PG_NONE; cu_opened(BT_OPT);
 assert(cu.page==PG_NONE);
 cu.armed=NB;cu_tap(BT_SWAG);assert(cu.page==PG_SWAG);
 cu_knob(EN_K2,1);assert(cr_rosen_mode==1);
 cu_knob(EN_K2,1);assert(cr_rosen_mode==2);
 cu_oct_tap(B_OCTDN);assert(cu.page==PG_NONE);
 cu_tap(BT_OPT);assert(cu.opt_open && cu.page==PG_NONE);
 cu.opt_open=0;cr_rosen_mode=0;
 for(e=0;e<2;e++) {
  cr_cb_all_off(0,CR_STREAM_MAIN); memset(&cr.v,0,sizeof cr.v);
  trk[0].eng_req=trk[0].engine=e?ENGI_PROPHET:ENGI_CZ; trk[0].p[P_VOICE]=V_POLY;
  cr.v[0].used=1; cr.v[0].rq=CR_Q_MAJ; cr.v[0].root=60; cr.v[0].nnotes=6;
  for(i=0;i<6;i++) cr.v[0].notes[i]=notes[i];
  for(i=0;i<6;i++) {cr.reg[0][notes[i]]=1;cr_cb_note_on(0,CR_STREAM_MAIN,notes[i],100);}
  { unsigned omitted=81u, removed=70u,j=0;
    assert(!has(omitted)); assert(has(64)&&has(67));
    cr.reg[0][removed]=0; cr_cb_note_off(0,CR_STREAM_MAIN,removed);
    for(i=0;i<6;i++)if((unsigned)notes[i]!=removed)cr.v[0].notes[j++]=notes[i];
    cr.v[0].nnotes=5; cr_chord_reconcile(); assert(has(omitted));
    for(i=0;i<6;i++)cr.v[0].notes[i]=notes[i];
    cr.v[0].nnotes=6; cr.reg[0][removed]=1; cr_cb_note_on(0,CR_STREAM_MAIN,removed,100);
    cr_chord_reconcile(); assert(!has(omitted));
    cr.v[0].root=48; assert(cr_chord_omit_tone(0,omitted));
  }
 }
 /* Prophet + two-unit bass: 16 - 2 leaves four three-unit voices. */
 cr.bass_on=1;cr.stream_on[CR_STREAM_BASS]=1;
 trk[CR_PART_BASS].engine=ENGI_CZ;
 assert(cr_chord_omit_tone(0,70));assert(cr_chord_omit_tone(0,81));
 trk[CR_PART_BASS].engine=ENGI_FM6;
 assert(cr_chord_omit_tone(0,81));assert(!cr_chord_omit_tone(0,64));
 trk[0].engine=trk[0].eng_req=ENGI_CZ;
 assert(!cr_chord_omit_tone(0,70));assert(cr_chord_omit_tone(0,81));
 trk[0].engine=trk[0].eng_req=ENGI_PROPHET;
 assert(!cr_chord_omit_tone(0,64));assert(!cr_chord_omit_tone(0,67));
 cr.bass_on=0;assert(cr_chord_omit_tone(0,81));assert(!cr_chord_omit_tone(0,70));
 cr_cb_all_off(0,CR_STREAM_MAIN); memset(cr.reg,0,sizeof cr.reg); memset(cr.v,0,sizeof cr.v);
 cr_rosen_mode=1; cr_cb_prepare(0,60,CR_Q_MAJ,0); assert(cr_rosen_pending==1);
 cr_cb_note_on(0,CR_STREAM_MAIN,60,90); assert(cr_rosen_notes[60]==90);
 cr_cb_note_off(0,CR_STREAM_MAIN,60); assert(!cr_rosen_notes[60]);
 i=cr_rosen_generation;cr_cb_prepare(0,60,CR_Q_MAJ,0);assert(cr_rosen_generation==i);
 cr_cb_prepare(0,60,CR_Q_MIN,0);assert(cr_rosen_generation==i+1);
 assert(cu_rosen_pick(0,3)==1); assert(cu_rosen_pick(2,3)==0);
 cr_rosen_mode=2;for(i=0;i<1000;i++) assert(cu_rosen_pick(2,5)!=2);
 assert(cu_rosen_pick(0,1)==0);
 cr_rosen_mode=3;cu_ping_valid=0;cu_fav_browser=0;
 assert(cu_rosen_pick(2,5)==2);assert(cu_rosen_pick(2,5)==3);
 assert(cu_rosen_pick(3,5)==2);assert(cu_rosen_pick(2,5)==3);
 cu_ping_valid=0;assert(cu_rosen_pick(4,5)==4);assert(cu_rosen_pick(4,5)==0);
 assert(cu_rosen_pick(0,5)==4);
 /* Manual preset selection starts a new pair. */
 assert(cu_rosen_pick(1,5)==1);assert(cu_rosen_pick(1,5)==2);
 cu_fav_browser=1;cu_ping_valid=0;
 assert(cu_rosen_pick(1,3)==1);
 trk[0].eng_req=ENGI_CZ;assert(cu_rosen_pick(1,3)==2);
 trk[0].eng_req=ENGI_PROPHET;assert(cu_rosen_pick(2,3)==1);
 cu_fav_browser=0;cu_ping_valid=0;
 cr_rosen_pending=0;cr_rosen_mode=1;cr_rosen_valid=0;
 cu_fav_browser=0;cu_pool_load(0,ENGI_FM6,0);
 cr_cb_prepare(0,62,CR_Q_MAJ,0);cr_cb_note_on(0,CR_STREAM_MAIN,62,90);
 cu_rosen_service();assert(cu_part_pos(0)==1);assert(cr_rosen_pending==2);
 events_block(64);assert(!cr_rosen_pending && !cr_rosen_notes[62]);
 cr_cb_note_off(0,CR_STREAM_MAIN,62);
 cr_rosen_pending=0;cr_rosen_mode=3;cr_rosen_valid=0;cu_ping_valid=0;
 cu_pool_load(0,ENGI_FM6,2);
 cr_cb_prepare(0,60,CR_Q_MAJ,0);cu_rosen_service();assert(cu_part_pos(0)==2);
 cr_cb_prepare(0,62,CR_Q_MAJ,0);cu_rosen_service();assert(cu_part_pos(0)==3);
 cr_cb_prepare(0,64,CR_Q_MAJ,0);cu_rosen_service();assert(cu_part_pos(0)==2);
 cr_rosen_pending=0;cr_rosen_mode=0;
 puts("PASS: SELECT knob 2, CZ / Prophet sixth-first priority and restoration, ROSEN queue, harmony dedup, Next/Random/Ping Pong");
 return 0;
}
