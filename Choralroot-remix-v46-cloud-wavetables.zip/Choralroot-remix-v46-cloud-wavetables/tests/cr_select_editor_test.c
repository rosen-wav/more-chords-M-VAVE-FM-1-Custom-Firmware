#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void) {
 emu_fw_options(0,1,0,1);emu_fw_init(0);clear(ENGI_VA,0,0);
 cu.armed=NB;cu.lock=L_NONE;cu.opt_open=0;cu_edit_open(0);
 assert(cu.page==PG_EDIT);cu_tap(BT_SWAG);assert(cu.page==PG_EDIT && cx.grp[0]==CE_FILT);
 cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(!strstr(screen.label,"rosen"));
 cu_opened(BT_SWAG);assert(cu.page==PG_EDIT && cx.grp[0]==CE_FILT);
 cu.armed=BT_SWAG;cu.open=0;cu.combo=0;cu_activity();assert(cu.page==PG_EDIT && cu.open && cu.combo);
 cu.armed=NB;cu_knob(EN_SELECT,1);assert(cu.page==PG_EDIT);
 cu_tap(BT_EDIT);assert(cu.page==PG_NONE);cu_tap(BT_SWAG);assert(cu.page==PG_SWAG);
 cu_tap(BT_SWAG);assert(cu.page==PG_NONE);cu_opened(BT_SWAG);assert(cu.page==PG_SWAG);
 puts("PASS: SELECT opens engine filter, stays in editor on hold/knob gestures, retains performance menu outside EDIT");return 0;
}
