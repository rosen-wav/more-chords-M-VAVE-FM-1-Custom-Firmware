/* SPDX-License-Identifier: GPL-3.0-only */
/* Compare integer-only velocity against the original Monk float curve. */
#include <assert.h>
#include <stdio.h>
#include "../firmware/src/cr_fastmath.h"
#include "../firmware/src/cr_sense.c"
static uint8_t sense_velocity_d_before(uint32_t d, uint32_t fl, uint32_t cl)
{
    float top = (float)(sn_cfg.vmax ? sn_cfg.vmax : 1u), r, r0, r1, t, c;
    if (d <= fl)
        return (uint8_t)top;
    if (d >= cl || cl <= fl + 1u)
        return 1;
    r = (float)(d > SN_DBASE ? d - SN_DBASE : 1u);
    r0 = (float)(fl > SN_DBASE ? fl - SN_DBASE : 1u);
    r1 = (float)(cl - SN_DBASE);
    t = fm_log2f(r / r0) / fm_log2f(r1 / r0);
    t = fm_clampf(t, 0.0f, 1.0f);
    c = (float)(sn_cfg.d_curve ? sn_cfg.d_curve : 1u) * 0.01f;
    return (uint8_t)(1.0f + (top - 1.0f) * fm_powf(1.0f - t, c) + 0.5f);
}

static unsigned count, different, max_error;
static void compare(unsigned d, unsigned floor, unsigned ceil)
{
 unsigned actual=sense_velocity_d(d,floor,ceil), original=sense_velocity_d_before(d,floor,ceil);
 unsigned error=actual>original ? actual-original : original-actual;
 if(error>1u){fprintf(stderr,"d=%u floor=%u ceil=%u curve=%u top=%u got=%u original=%u\n",d,floor,ceil,sn_cfg.d_curve,sn_cfg.vmax,actual,original);assert(error<=1u);}
 if(error){different++;if(error>max_error)max_error=error;}
 assert(actual>=1u && actual<=(sn_cfg.vmax ? sn_cfg.vmax : 1u));count++;
}
int main(void){
 const unsigned curve[]={0,1,20,70,100,180,500,65535};
 for(unsigned top=1;top<=255;top+=63)for(unsigned c=0;c<sizeof curve/sizeof *curve;c++){
  sn_cfg.vmax=top;sn_cfg.d_curve=curve[c];
  for(unsigned floor=201;floor<1000;floor+=37)for(unsigned ceil=floor+32;ceil<=1023;ceil+=111)for(unsigned d=0;d<=1023;d++)compare(d,floor,ceil);
  for(unsigned d=0;d<=65535;d+=31)compare(d,400,65535);
 }
 uint32_t seed=713u;
 for(unsigned j=0;j<1000000u;++j){
  seed=seed*1664525u+1013904223u;unsigned floor=201u+(seed%65000u);
  seed=seed*1664525u+1013904223u;unsigned ceil=floor+2u+(seed%(65534u-floor));
  seed=seed*1664525u+1013904223u;unsigned d=floor+(seed%(ceil-floor+1u));
  sn_cfg.vmax=1u+(seed%255u);sn_cfg.d_curve=curve[j%8u];compare(d,floor,ceil);
 }
 for(unsigned c=0;c<8u;++c){
  sn_cfg.vmax=127;sn_cfg.d_curve=curve[c];unsigned prev=127;
  for(unsigned d=0;d<=1023u;++d){unsigned v=sense_velocity_d(d,201,1023);assert(v<=prev);prev=v;}
 }
 printf("PASS: %u velocity comparisons, %u differ, maximum MIDI velocity error %u\n",count,different,max_error);
 return 0;
}
