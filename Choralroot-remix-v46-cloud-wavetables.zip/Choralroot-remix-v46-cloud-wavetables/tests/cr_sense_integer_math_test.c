/* SPDX-License-Identifier: GPL-3.0-only */
/* Independent libm references for the integer-only sensing helpers. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../firmware/src/cr_sense_math.h"
int main(void)
{
    uint32_t seed=71u;
    double max_log_error=0.0, max_exp_error=0.0;
    for(unsigned i=0;i<200000u;++i){
        seed=seed*1664525u+1013904223u;
        uint32_t x=seed ? seed : 1u;
        double err=fabs((double)sense_log2_q24(x)/SN_LOG_ONE-log2((double)x));
        if(err>max_log_error)max_log_error=err;
        assert(err<0.0000003);
        uint32_t e=seed%(32u*1048576u);
        err=fabs((double)sense_exp2_neg_q31(e)/2147483648.0-exp2(-(double)e/1048576.0));
        if(err>max_exp_error)max_exp_error=err;
        assert(err<0.00000001);
        uint32_t denominator=1u+(seed%(32u*SN_LOG_ONE));
        uint32_t numerator=x%denominator;
        assert(sense_ratio_q24(numerator,denominator)==
            (uint32_t)(((uint64_t)numerator<<24)/denominator));
    }
    printf("PASS: 200000 integer log/exp/ratio fixtures; max log error %.9g, exp error %.9g\n",max_log_error,max_exp_error);
    return 0;
}
