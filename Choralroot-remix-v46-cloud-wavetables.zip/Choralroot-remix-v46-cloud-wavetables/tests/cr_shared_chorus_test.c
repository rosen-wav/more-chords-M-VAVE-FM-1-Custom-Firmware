#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 clear(ENGI_KR106,1,0);song.g[G_BPM]=120;
 int32_t input[CTL],zero[CTL]={0},wet[CTL];uint64_t hashes[3];
 assert(GP[G_CRATE].max==2);assert(KR106_DEEP.npages==6);
 for(unsigned mode=0;mode<3;mode++){
  memset(&fx,0,sizeof fx);memset(cho_buf,0,sizeof cho_buf);memset(dly_buf,0,sizeof dly_buf);
  song.g[G_CRATE]=mode;song.g[G_CDEPTH]=127;song.g[G_RTYPE]=0;
  uint64_t energy=0,side=0,hash=1469598103934665603ull;
  for(unsigned k=0;k<1000;k++){
   for(unsigned i=0;i<CTL;i++)input[i]=k<500?((int32_t)((k*CTL+i)*977u%24000)-12000):0;
   fx_buses(input,zero,zero,wet,CTL);
   for(unsigned i=0;i<CTL;i++){energy+=llabs(wet[i]);side+=llabs(cho_stereo[i]);assert(llabs(wet[i])<131072);hash=(hash^(uint32_t)wet[i])*1099511628211ull;}
  }
  assert(energy&&side);assert(!fx.cho_tail);
  fx_buses(zero,zero,zero,wet,CTL);for(unsigned i=0;i<CTL;i++)assert(!wet[i]&&!cho_stereo[i]);hashes[mode]=hash;
 }
 assert(hashes[0]!=hashes[1]&&hashes[1]!=hashes[2]&&hashes[0]!=hashes[2]);
 puts("PASS: shared BBD I/II/I+II distinct stereo returns, bounded output, tail cleanup and exact silent bypass; six KR106 pages");return 0;
}
