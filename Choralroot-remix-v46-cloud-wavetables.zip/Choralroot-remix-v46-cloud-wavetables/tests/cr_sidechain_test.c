/* Actual master pump and UI. No legacy golden generation. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void fill(int32_t *b) {unsigned i;for(i=0;i<CTL;i++){b[2*i]=30000;b[2*i+1]=-30000;}}
int main(void) {
 int32_t buf[CTL*2],bypass[CTL*2];cr_screen_t screen;unsigned i,k,sig;int beat,tail,last;uint32_t master;
 emu_fw_options(0,1,0,1);emu_fw_init(0);master=song.master_q12;
 cu_opened(BT_METRO);cu_knob(EN_K3,1);cr_audio_block(CTL);assert(cs.sidechain&&cr_sidechain_on);
 cr_build_screen(&screen,cu_now());assert(!strcmp(screen.cell[0][2].label,"Sidechain")&&!strcmp(screen.cell[0][2].value,"On"));
 assert(screen.cell[0][2].glyph==CR_G_SIDECHAIN&&screen.cell[0][2].pct==255);
 cu_knob(EN_K3,-1);cr_audio_block(CTL);assert(!cs.sidechain&&!cr_sidechain_on);
 cr_build_screen(&screen,cu_now());assert(screen.cell[0][2].glyph==CR_G_SIDECHAIN&&screen.cell[0][2].pct==0);
 fill(buf);memcpy(bypass,buf,sizeof buf);cr_sidechain_mix(buf,CTL);assert(!memcmp(buf,bypass,sizeof buf));
 for(sig=0;sig<CRL_NSIG;sig++) {
  crl.sig=sig;crl.state=CRL_PLAYING;crl.cyc0=crl.t=0;crl.acc=0;cr.bpm=120;
  cr_sidechain_on=1;cr_sidechain_running=0;cr_sidechain_gain=32768;
  for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}
  beat=buf[0];assert(beat>=1873&&beat<=1875);
  crl.t=CRL_PPQN*3/4;crl.acc=0;fill(buf);cr_sidechain_mix(buf,CTL);
  for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}tail=buf[0];assert(tail==30000);
  /* Next quarter, irrespective of the selected signature. */
  crl.t=CRL_PPQN;for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(buf[0]<=1875);
 }
 /* A free loop wrap cannot reset the quarter-note clock. */
 cr_sidechain_running=0;crl.t=crl.cyc0=0;fill(buf);cr_sidechain_mix(buf,CTL);
 crl.t=150;crl.cyc0=150;crl.acc=0;cr_sidechain_gain=32768;fill(buf);cr_sidechain_mix(buf,CTL);assert(cr_sidechain_gain>2048);
 /* OFF restores unity; stopping the loop leaves the internal-clock pump active. */
 crl.state=CRL_PLAYING;crl.t=0;crl.cyc0=0;cr_sidechain_running=0;cr_sidechain_on=1;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}
 cr_sidechain_on=0;last=cr_sidechain_gain;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);assert(cr_sidechain_gain>=last);last=cr_sidechain_gain;}
 assert(cr_sidechain_gain==32768);fill(buf);cr_sidechain_mix(buf,CTL);assert(!memcmp(buf,bypass,sizeof buf));
 cr_sidechain_on=1;crl.state=CRL_PLAYING;crl.t=0;cr_sidechain_running=0;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}
 cr_loop_stop(&crl,&cr);for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(cr_sidechain_gain==2048);
 cr_sidechain_on=1;crl.state=CRL_PLAYING;crl.t=crl.cyc0=0;cr_sidechain_running=0;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}
 cr_loop_panic(&crl);for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(cr_sidechain_gain==2048);
 assert(song.master_q12==master);
 /* Stereo gain equality, bounded sample steps and tempo sync at 20/120/300. */
 for(k=20;k<=300;k+=(k==20?100:180)) {
  cr.bpm=k;crl.state=CRL_PLAYING;crl.cyc0=crl.t=0;crl.acc=0;cr_sidechain_on=1;cr_sidechain_running=0;cr_sidechain_gain=32768;
  fill(buf);cr_sidechain_mix(buf,CTL);
  for(i=1;i<CTL;i++)assert(abs(buf[2*i]-buf[2*(i-1)])<=119);
  for(i=0;i<CTL;i++)assert(abs(buf[2*i]+buf[2*i+1])<=1&&abs(buf[2*i])<=30000);
 }
 /* Follow the actual millisecond loop clock for two beats at each tempo. */
 for(k=20;k<=300;k+=(k==20?100:180)) {
  unsigned ms,period=60000u/k;int first=30000,second=30000,recovered=0;
  cr.bpm=k;memset(&crl,0,sizeof crl);crl.state=CRL_PLAYING;crl.d.len=CRL_PPQN*16u;
  cr_sidechain_on=1;cr_sidechain_running=0;cr_sidechain_gain=32768;
  for(ms=0;ms<period*2u;ms++) {
   cr_loop_tick(&crl,&cr,ms);fill(buf);cr_sidechain_mix(buf,CTL);
   if(ms<20u&&buf[CTL*2u-2u]<first)first=buf[CTL*2u-2u];
   if(ms>=period&&ms<period+20u&&buf[CTL*2u-2u]<second)second=buf[CTL*2u-2u];
   if(ms==period*3u/4u)recovered=buf[CTL*2u-2u];
  }
  assert(first<2500&&second<2500&&recovered==30000);
 }
 /* Internal grid still pulses with no loop content, no click and no MIDI OUT. */
 cr_sidechain_on=1;cr_route.clock_in=cr_route.clock_out=0;crl.state=CRL_EMPTY;crl.d.len=0;
 crl.t=crl.met0=0;crl.acc=0;crl.metro=0;cr_sidechain_running=0;cr_sidechain_gain=32768;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(cr_sidechain_gain==2048);
 /* Actual queued MIDI Clock, USB and UART, no FA required and no loop present.
  * HAL timestamps deliberately have a different origin from the engine clock. */
 for(k=20;k<=300;k+=(k==20?100:180)) {
  unsigned samples,pulse=0,period=60000u/k,base=100000u+k*1000u;int duck=30000,recovery=0;
  cr_route.clock_in=0;cr_audio_block(CTL);cr_route.clock_in=1;cr_audio_block(CTL);
  cr_sidechain_on=1;cr_sidechain_gain=32768;cr_sidechain_running=0;cr.bpm=120;
  for(samples=0;samples<FS*period*3u/1000u;samples+=CTL) {
   unsigned elapsed=(uint32_t)((uint64_t)samples*1000u/FS);
   while(pulse*60000u/(k*24u)<=elapsed) {
    unsigned stamp=pulse*60000u/(k*24u);fm1_ms=base+stamp;
    assert(midi_enqueue(0xF8u<<8|0x0Fu,(pulse&1u)?1u:2u));pulse++;
   }
   fm1_ms=base+elapsed;cr_audio_block(CTL);fill(buf);cr_sidechain_mix(buf,CTL);
   if(elapsed>=period*2u&&elapsed<period*2u+20u&&buf[CTL*2u-2u]<duck)duck=buf[CTL*2u-2u];
   if(elapsed>=period*2u+period*4u/5u&&elapsed<period*2u+period*4u/5u+2u)recovery=buf[CTL*2u-2u];
  }
  assert(abs((int)cr.bpm-(int)k)<=1);assert(duck<2500&&recovery>29000);
  assert(crl.state==CRL_EMPTY&&crl.d.len==0);
  /* A stopped/disconnected external clock never leaves the master attenuated. */
  for(samples=0;samples<FS*350u/1000u;samples+=CTL){cr_audio_block(CTL);fill(buf);cr_sidechain_mix(buf,CTL);}
  assert(cr_sidechain_gain==32768);fill(buf);cr_sidechain_mix(buf,CTL);assert(!memcmp(buf,bypass,sizeof buf));
  /* Re-acquisition and Start reset phase, duplicate F8 does not advance it. */
  fm1_ms=base+period*3u+400u;assert(midi_enqueue(0xFAu<<8|0x0Fu,1u));assert(midi_enqueue(0xF8u<<8|0x0Fu,1u));cr_audio_block(CTL);
  assert(cr_sidechain_midi_seen&&cr_sidechain_midi_step==0);
  fm1_ms+=60000u/(k*24u);assert(midi_enqueue(0xF8u<<8|0x0Fu,2u));cr_audio_block(CTL);assert(cr_sidechain_midi_step==1);
  assert(midi_enqueue(0xF8u<<8|0x0Fu,2u));cr_audio_block(CTL);assert(cr_sidechain_midi_step==1);
 }
 /* IN selected but no source: bypass; returning to internal immediately resumes. */
 cr_route.clock_in=0;cr_audio_block(CTL);cr_route.clock_in=1;cr_audio_block(CTL);
 assert(!cr_sidechain_midi_seen);cr_sidechain_gain=32768;fill(buf);cr_sidechain_mix(buf,CTL);assert(!memcmp(buf,bypass,sizeof buf));
 cr_route.clock_in=0;cr_audio_block(CTL);crl.t=crl.met0=0;crl.acc=0;cr_sidechain_running=0;
 for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(cr_sidechain_gain==2048);
 cr_sidechain_on=0;for(k=0;k<(512u+CTL-1u)/CTL;k++){fill(buf);cr_sidechain_mix(buf,CTL);}assert(cr_sidechain_gain==32768);
 assert(song.master_q12==master);
 puts("PASS: SEQ KNOB3 On/Off, exact bypass, beat duck/recovery, stereo smoothing, all signatures, free-loop wraps, EMPTY/STOPPED internal pumping, real queued USB/UART clock at 20/120/300, phase restart, duplicate filtering, dropout bypass, master unchanged");return 0;
}
