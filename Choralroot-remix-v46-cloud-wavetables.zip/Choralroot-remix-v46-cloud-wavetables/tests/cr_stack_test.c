/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#include <stdio.h>
#include "../firmware/src/cr_stack.h"
int main(void){uint32_t p[16];for(unsigned i=0;i<16;i++)p[i]=CR_STACK_MARK;
assert(cr_stack_used(p,16)==0);assert(cr_stack_guard_ok(p,16));
p[15]=1;assert(cr_stack_used(p,16)==4);p[9]=2;assert(cr_stack_used(p,16)==28);
p[1]=3;assert(cr_stack_used(p,16)==60);assert(!cr_stack_guard_ok(p,16));
p[1]=CR_STACK_MARK;p[0]=4;assert(cr_stack_used(p,16)==64);assert(!cr_stack_guard_ok(p,16));
assert(!cr_stack_guard_ok(p,0));puts("CPU1 stack marker: empty, partial/full use and damaged guard PASS");return 0;}
