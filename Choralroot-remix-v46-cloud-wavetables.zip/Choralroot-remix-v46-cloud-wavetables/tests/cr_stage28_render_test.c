#define main legacy_draw_main
#include "cr_draw_test.c"
#undef main
#include <assert.h>
int main(int argc,char **argv){
 assert(argc==4);cr_screen_t s;FILE *f=fopen(argv[1],"rb");assert(f);assert(fread(&s,sizeof s,1,f)==1);assert(fgetc(f)==EOF);fclose(f);
 palette_set(mod_index());render(&s,0);write_ppm(argv[2],argv[3]);assert(!nfail);return 0;
}
