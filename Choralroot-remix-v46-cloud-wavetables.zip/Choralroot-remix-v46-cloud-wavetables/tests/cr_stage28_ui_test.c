#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void capture(const char *file){cr_screen_t s;cr_build_screen(&s,cu_now());FILE *f=fopen(file,"wb");assert(f);assert(fwrite(&s,sizeof s,1,f)==1);fclose(f);}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cu.page=PG_NONE;cu.armed=NB;cu_tap(BT_SWAG);
 cu_knob(EN_K3,3);cr_audio_block(CTL);capture("build/host/stage28-gate.screen");
 cu_knob(EN_K3,3);cr_audio_block(CTL);capture("build/host/stage28-wah.screen");
 cu.page=PG_NONE;cu.lock=L_NONE;cu.opt_open=1;cu.opt_sel=O_CRYSTAL_BASS;
 opt_set(O_CRYSTAL_BASS,1);cr_audio_block(CTL);capture("build/host/stage28-crystal.screen");
 cr_screen_t s;cr_build_screen(&s,cu_now());assert(!strcmp(s.item[0],"crystal castles bass mode"));assert(!strcmp(s.value,"On"));
 puts("PASS: real firmware screen captures, full Crystal name, first option and On value");
}
