#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(HALF_FRAMES==192u&&EMU_BLOCK==HALF_FRAMES&&CTL==32u);
 assert(sizeof abuf==3072u&&HALF_WORDS==384u);
 // Old collection is reset without touching ordinary/user favourites.
 memset(&favorites,0,sizeof favorites);
 for(unsigned i=0;i<16;i++)for(unsigned j=0;j<32;j++)favorites.factory[i][j]=(uint8_t)(i+j);
 favorites.factory[4][0]=0xB3;favorites.factory[4][1]=0x30;
 favorites.user=0x80000001u;
 favorites_t before=favorites;
 cu_bass_reset_pending=0;cs.bass_sound=9;cs.bass_on=1;
 cu_bass_go(0);assert(cu_bass_count()==0&&!cs.bass_on&&!cs.bass_sound&&cu_bass_reset_pending);
 assert(favorites.factory[4][0]==0xB3&&favorites.factory[4][1]==CU_BASS_MARK);
 for(unsigned row=0;row<16;row++)for(unsigned col=0;col<32;col++){
  if(row==8||row==10)assert(favorites.factory[row][col]==255);
  else if(row==4&&col<2)continue;
  else assert(favorites.factory[row][col]==before.factory[row][col]);
 }
 assert(favorites.user==before.user);
 // Once marked, new entries survive another initialization / persisted capture.
 cu_bass_ref(0)[0]=ENGI_BASS;cu_bass_ref(0)[1]=1;
 cu_bass_reset_pending=0;cu_bass_init();assert(!cu_bass_reset_pending&&cu_bass_count()==1);
 cr_settings_save();persist_t stored=crs_rec;
 assert(stored.favorites.factory[4][1]==CU_BASS_MARK);
 assert(stored.favorites.factory[8][0]==ENGI_BASS);
 memcpy(&favorites,&stored.favorites,sizeof favorites);cu_bass_init();assert(cu_bass_count()==1);
 // Actual ISR/emulator path fills both enlarged halves without overrunning output.
 struct {int16_t pre[8],pcm[4*HALF_FRAMES],post[8];} b;
 memset(&b,0x55,sizeof b);song.master_q12=4096;
 cu_load(&trk[0],ENGI_FM6,0,0);settle();panic_req=0;trk_note_on(&trk[0],60,100);
 while(emu_stall_blocks)emu_fw_audio(b.pcm,2*HALF_FRAMES);
 for(unsigned j=0;j<10;j++)emu_fw_audio(b.pcm,2*HALF_FRAMES);
 for(unsigned i=0;i<8;i++){assert(b.pre[i]==0x5555&&b.post[i]==0x5555);}
 int sound=0;for(unsigned i=0;i<4*HALF_FRAMES;i++){assert(b.pcm[i]!=0x5555);sound|=b.pcm[i]!=0;}assert(sound);
 assert(sizeof(cr_settings_t)==192&&sizeof(favorites_t)==520);
 puts("PASS: 192-frame halves, 512-byte extra DMA RAM over Stage34, 32-frame control blocks; real ISR output/guards; one-time BASS collection reset, OFF, other favourites preserved, persisted marker/new entries retained");
}
