/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/src/cr_loop.h"
static cr_t c;static cr_loop_t l;static crl_data_t decoded,before;
static uint8_t buf[CRL_REC_MAX],bad[CRL_REC_MAX];static unsigned rng=0x12345678u;
static unsigned random_u(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
int main(void){
 cr_init(&c,0);cr_loop_init(&l);l.sync=4;unsigned checks=0;
 for(unsigned i=0;i<12000;i++){
  unsigned step=random_u()%cr_loop_grid_count(&l),mode=random_u()%4u;
  cr_loop_gesture(&l,i,48+random_u()%36u,CR_Q_MAJ,random_u()%16u,100,1);before=l.d;
  int rc=mode==0?cr_loop_grid_edit(&l,&c,step,-1):mode==1?cr_loop_grid_gate_edit(&l,&c,step,(int)(random_u()%5)-2):mode==2?cr_loop_grid_edit(&l,&c,step,(int)(random_u()%5)):cr_loop_grid_resize(&l,&c,1+random_u()%4);
  if(rc<0)assert(!memcmp(&before,&l.d,sizeof before));
  if(mode==2 && rc>0)assert(l.d.nev==before.nev && l.d.nlayers==before.nlayers && !memcmp(l.d.ev,before.ev,l.d.nev*sizeof(crl_ev_t)));
  assert(l.d.len<=CRL_MAX_LEN);
  if(l.d.grid_n){assert(l.d.grid_global&&l.d.grid_n==cr_loop_grid_count(&l));for(unsigned j=0;j<l.d.grid_n;j++)assert(l.d.grid_dur[j]==l.d.grid_dur[0]);}
  uint8_t masks[CRL_GRID_MAX/8u],carry[CRL_GRID_MAX/8u],outgoing[CRL_GRID_MAX/8u];uint16_t gates[CRL_GRID_MAX];cr_loop_grid_snapshot_ex(&l,masks,gates,carry,outgoing);
  unsigned ticks=24u<<cr_loop_grid_rate(&l,0);
  for(unsigned k=0;k<l.d.nev;k++){
   const crl_ev_t *e=&l.d.ev[k];assert(e->t<l.d.len&&e->dur&&e->t+e->dur<=l.d.len);
   unsigned cell=e->t/ticks;assert(masks[cell/8]&(1u<<(cell%8)));assert(gates[cell]>=e->dur);
  }
  for(unsigned cell=0;cell<cr_loop_grid_count(&l);cell++){
   unsigned held=0,continuing=0;
   for(unsigned k=0;k<l.d.nev;k++){
    const crl_ev_t *e=&l.d.ev[k];unsigned end=e->t+e->dur;
    held|=e->t<cell*ticks&&end>cell*ticks;
    continuing|=e->t<(cell+1u)*ticks&&end>(cell+1u)*ticks;
   }
   assert(((carry[cell/8]>>(cell%8))&1u)==held);
   assert(((outgoing[cell/8]>>(cell%8))&1u)==continuing);
  }
  unsigned n=cr_loop_pack(&l.d,buf,sizeof buf);
  if(l.d.nev){
   assert(n&&n<=CRL_REC_MAX&&buf[4]==3&&cr_loop_unpack(buf,n,&decoded));
   assert(decoded.nev==l.d.nev&&decoded.len==l.d.len&&decoded.grid_n==l.d.grid_n&&decoded.grid_global);
   assert(!memcmp(decoded.grid_dur,l.d.grid_dur,l.d.grid_n));assert(!memcmp(decoded.ev,l.d.ev,l.d.nev*sizeof(crl_ev_t)));
   assert(!cr_loop_unpack(buf,n-1,&decoded));memcpy(bad,buf,n);bad[n-1]=255;assert(!cr_loop_unpack(bad,n,&decoded));
  }else assert(!n);
  cr_loop_gesture(&l,i,60,CR_Q_MAJ,0,100,0);checks++;
 }
 /* Coarse grids retain sub-step onsets/gates exactly, including actual carry offset. */
 cr_loop_clear(&l,&c);l.sync=2;cr_loop_gesture(&l,0,60,CR_Q_MAJ,0,100,1);
 assert(cr_loop_grid_edit(&l,&c,0,-1)>0);l.d.ev[0].t=24;l.d.ev[0].dur=96;before=l.d;
 for(unsigned rate=0;rate<5;rate++){
  assert(cr_loop_grid_edit(&l,&c,0,(int)rate)>0 && l.d.ev[0].t==24 && l.d.ev[0].dur==96 && l.d.len==768);
  unsigned packed=cr_loop_pack(&l.d,buf,sizeof buf);assert(packed&&cr_loop_unpack(buf,packed,&decoded)&&decoded.ev[0].t==24&&decoded.ev[0].dur==96);
 }
 assert(cr_loop_grid_edit(&l,&c,0,2)>0);
 uint8_t masks[16],carry[16],outgoing[16];uint16_t gates[128];
 cr_loop_grid_snapshot_ex(&l,masks,gates,carry,outgoing);assert(masks[0]==1 && carry[0]==2 && outgoing[0]==1 && gates[0]==96);
 assert(cr_loop_grid_edit(&l,&c,2,-1)>0 && l.d.ev[0].t==24 && l.d.ev[0].dur==96);
 assert(cr_loop_grid_edit(&l,&c,0,-1)>0 && l.d.nev==1 && l.d.ev[0].t==192);
 /* V1 and old variable-duration V2 remain readable within eight bars. */
 crl_data_t old={0};old.len=384;old.nlayers=1;old.nev=1;old.ev[0]=(crl_ev_t){0,48,60,100,0,0};
 unsigned n=cr_loop_pack(&old,buf,sizeof buf);assert(n&&buf[4]==1&&cr_loop_unpack(buf,n,&decoded));
 old.grid_n=8;for(unsigned i=0;i<8;i++)old.grid_dur[i]=1;
 n=cr_loop_pack(&old,buf,sizeof buf);assert(n&&buf[4]==2&&cr_loop_unpack(buf,n,&decoded)&&!decoded.grid_global);
 old.len=CRL_MAX_LEN+1;assert(!cr_loop_pack(&old,buf,sizeof buf));
 printf("PASS: grid stress %u edits; exact event timing on rate changes, independent gates, fixed bar length, atomic refusal, 128-cell occupancy/carry/outgoing oracle, V1/V2/V3, malformed/truncated records, eight-bar cap; %u-byte maximum within 3840-byte sector payload\n",checks,(unsigned)CRL_REC_MAX);
}
