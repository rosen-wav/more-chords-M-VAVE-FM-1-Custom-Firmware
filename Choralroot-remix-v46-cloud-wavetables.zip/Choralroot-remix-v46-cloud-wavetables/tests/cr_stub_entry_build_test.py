"""Mock only toolchain I/O; exercise the actual build_stub validation, not target code."""
import hashlib
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import build

with tempfile.TemporaryDirectory(dir=build.OUT) as td:
    root=Path(td).resolve(); src=root/'stub'; out=root/'out'; src.mkdir(); out.mkdir()
    image=bytes.fromhex('04818000')+bytes(4)+b'CRSTUB'+(3).to_bytes(2,'little')+bytes(48)
    padded=image+b'\xff'*(build.STUB_LEN-len(image))
    (src/'stub.lock').write_text('3 '+hashlib.sha256(padded).hexdigest()+'\n')
    def tc_all(*commands):
        if len(commands)==2:
            return None,None
        (out/'stub.bin').write_bytes(image)
        return '', '', '0 .text 00000040 02000120', '02000120 g F .text 00000040 _start'
    with patch.multiple(build,STB=out,FW=root,SRC=root,VERSION='test'), patch.object(build,'tc',lambda *args:None), patch.object(build,'tc_all',tc_all):
        assert build.build_stub()==padded
        image=b'BAD!'+image[4:]
        try:
            build.build_stub()
        except SystemExit as error:
            assert 'not the entry' in str(error)
        else:
            raise AssertionError('Corrupt entry accepted')
print('PASS: actual stub build validation accepts correct offset-zero entry and rejects corrupt entry; no toolchain/flash')
