/* Real UI, chord engine and synth integration. Reuse the independent gate oracle. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"

static void drain(void) {cr_audio_block(CTL);}
static void modkey(unsigned k,int down) {if(down)cu_key_press(k);else cu_key_release(k);drain();}
int main(void) {
 unsigned mode,e,bass,q,i,style;int last,seen[9]={0};cr_t c;cr_settings_t st;cr_screen_t screen;
 const int path[]={0,1,0,-1,0,1,0,-1,0};
 const int tennis[]={0,1,2,3,4,5,4,3,2,1,0,-1,-2,-3,-2,-1,0,1};
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 /* SELECT opens the new menu; encoders post mode changes to the audio side. */
 cu.page=PG_NONE;cu.lock=0;cu.opt_open=0;cu_tap(BT_SWAG);assert(cu.page==PG_SWAG);
 cu_knob(EN_K1,1);drain();assert(cs.swag_mode==1&&cr.swag_mode==1);
 cu_knob(EN_SELECT,1);drain();assert(cs.swag_mode==2&&cr.swag_mode==2);
 cu_knob(EN_SELECT,1);drain();assert(cs.swag_mode==3&&cr.swag_mode==3);
 cu_knob(EN_SELECT,1);drain();assert(cs.swag_mode==3);
 cr_build_screen(&screen,cu_now());assert(!strcmp(screen.label,"swag mode"));
 assert(screen.kind==CR_K_KNOBROW && !strcmp(screen.cell[0][0].value,"Tennis"));
 assert(!strcmp(screen.cell[0][1].label,"rosen"));
 cu_knob(EN_K2,1);assert(cr_rosen_mode==1 && cs.swag_mode==3);
 cu_knob(EN_K2,2);assert(cr_rosen_mode==3 && cs.swag_mode==3);
 cu_knob(EN_K1,-1);drain();assert(cs.swag_mode==2 && cr_rosen_mode==3);
 cu_knob(EN_K2,-10);assert(cr_rosen_mode==0 && cs.swag_mode==2);
 cu_knob(EN_K1,1);drain();assert(cs.swag_mode==3);
 cu_oct_tap(B_OCTDN);assert(cu.page==PG_NONE);cu_opened(BT_SWAG);assert(cu.page==PG_SWAG);cu_home_tap();assert(cu.page==PG_NONE);
 opt_set(O_TRANSPOSE,-12);assert(cs.transpose==-12);opt_set(O_TRANSPOSE,0);drain();
 /* Retired settings and API cannot quantise any root, including black keys. */
 cr_settings_defaults(&st);st.key_on=1;st.tonic=9;st.scale=1;cr_settings_apply(&st,&cr,0);
 assert(!cr.key_on&&!cr.tonic&&!cr.scale&&cr_scale_mask(&cr)==0);
 for(i=0;i<12;i++) {cr_init(&c,0);cr_set_key(&c,1,i,CR_SCALE_MINOR);cr_key(&c,60+i,100,1);assert(c.v[0].root==60+(int)i&&c.v[0].rq==CR_Q_NONE);}
 /* All playstyles: replacing the seventh immediately removes the other one. */
 for(style=0;style<3;style++) {
  cr_init(&c,0);cr_set_playstyle(&c,(cr_playstyle_t)style);cr_mod(&c,CR_MOD_MAJ,1);cr_mod(&c,CR_MOD_M7,1);cr_key(&c,60,100,1);
  assert(c.v[0].sx==CR_EXT_M7);cr_mod(&c,CR_MOD_MAJ7,1);assert(c.v[0].sx==CR_EXT_MAJ7);
  assert(!(c.mods_down&(1u<<CR_MOD_M7)));cr_mod(&c,CR_MOD_M7,0);assert(c.v[0].sx==CR_EXT_MAJ7);
  cr_mod(&c,CR_MOD_M7,1);assert(c.v[0].sx==CR_EXT_M7);assert(!(c.mods_down&(1u<<CR_MOD_MAJ7)));
  cr_key(&c,60,0,0);cr_panic(&c);
 }
 /* LOCK: switch latched seventh, and release a physically superseded key. */
 clear(ENGI_CZ,0,0);memset(cu.key_note,0,sizeof cu.key_note);cu.kheld=0;cu.mlatch=0;cu.mkill=0;cu.clock=1;cr_mlock=1;
 modkey(5,1);modkey(5,0);modkey(2,1);modkey(2,0);assert(cu.mlatch&(1u<<CR_MOD_M7));
 modkey(4,1);modkey(4,0);assert(!(cu.mlatch&(1u<<CR_MOD_M7)));assert(cu.mlatch&(1u<<CR_MOD_MAJ7));
 cr_key(&cr,60,100,1);assert(cr.v[0].sx==CR_EXT_MAJ7);
 modkey(2,1);modkey(4,1);modkey(2,0);modkey(4,0);assert(cr.v[0].sx==CR_EXT_MAJ7);assert(!(cu.mlatch&(1u<<CR_MOD_M7)));
 cu.clock=0;cr_mlock=0;cu_unlatch();drain();cr_panic(&cr);
 /* Ping Pong's exact sequence, including repeat presses of the same root. */
 cr_init(&c,0);cr_mod(&c,CR_MOD_MAJ,1);cr_set_swag(&c,1);
 for(i=0;i<sizeof path/sizeof path[0];i++) {cr_key(&c,60,100,1);assert(c.voicing==path[i]);assert(c.v[0].voicing==path[i]);cr_key(&c,60,0,0);}
 cr_init(&c,0);cr_mod(&c,CR_MOD_MAJ,1);cr_set_swag(&c,3);
 for(i=0;i<sizeof tennis/sizeof tennis[0];i++) {cr_key(&c,60,100,1);assert(c.voicing==tennis[i]);assert(c.v[0].voicing==tennis[i]);cr_key(&c,60,0,0);}
 /* A mode switch or manual inversion outside the range clamps the first chord. */
 cr_set_swag(&c,1);cr_voicing_step(&c,5-c.voicing);cr_key(&c,60,100,1);assert(c.voicing==1);cr_key(&c,60,0,0);
 cr_key(&c,60,100,1);assert(c.voicing==0);cr_key(&c,60,0,0);
 cr_set_swag(&c,3);cr_voicing_step(&c,-9-c.voicing);cr_key(&c,60,100,1);assert(c.voicing==-3);cr_key(&c,60,0,0);
 cr_key(&c,60,100,1);assert(c.voicing==-2);cr_key(&c,60,0,0);
 cr_init(&c,0);cr_mod(&c,CR_MOD_MAJ,1);cr_set_swag(&c,1);
 cr_key_ex(&c,60,0,100,1);assert(c.voicing==0);cr_key_ex(&c,60,1,100,1);assert(c.voicing==1);
 cr_key_ex(&c,60,0,0,0);assert(c.v[0].used);cr_key_ex(&c,60,1,0,0);assert(!c.v[0].used);
 /* Single notes / modifier edits / tick steps / replay do not advance the cycle. */
 cr_init(&c,0);cr_set_swag(&c,1);cr_key(&c,60,100,1);assert(!c.swag_started);cr_key(&c,60,0,0);
 cr_mod(&c,CR_MOD_MAJ,1);cr_key(&c,60,100,1);last=c.voicing;
 cr_mod(&c,CR_MOD_MAJ7,1);assert(c.voicing==last);cr_tick(&c,1000);assert(c.voicing==last);
 cr_loop_event(&c,0,65,CR_Q_MAJ,0,100,1);assert(c.voicing==last);cr_loop_event(&c,0,65,0,0,0,0);
 cr_panic(&c);cr_pad_set(&c,0,1,60,CR_Q_MIN,0,100);cr_pad_down(&c,0);assert(c.voicing==1);cr_pad_up(&c,0);
 cr_set_swag(&c,0);cr_key(&c,60,100,1);assert(c.voicing==1);cr_key(&c,60,0,0);
 /* A new gesture keeps an older held chord's own inversion and notes. */
 cr_init(&c,0);cr_set_playstyle(&c,CR_PS_ADVANCED);cr_mod(&c,CR_MOD_MAJ,1);cr_set_swag(&c,1);
 cr_key(&c,60,100,1);assert(c.v[0].voicing==0);
 cr_key(&c,65,100,1);assert(c.v[0].voicing==0&&c.v[1].voicing==1);
 {uint8_t oldnotes[CR_CHORD_MAX];unsigned count=c.v[0].nnotes;memcpy(oldnotes,c.v[0].notes,count);
  cr_mod(&c,CR_MOD_M7,1);assert(c.voicing==1&&c.v[0].voicing==0&&c.v[1].voicing==1);
  for(i=0;i<count;i++)assert(c.v[0].notes[i]==oldnotes[i]);
 }
 cr_key(&c,60,0,0);cr_key(&c,65,0,0);assert(cr_voices(&c)==0);
 /* Arpeggio steps are independent of gestures, including retrigger-off. */
 cr_init(&c,0);cr_mod(&c,CR_MOD_MAJ,1);cr_set_swag(&c,1);cr_set_perform_mode(&c,CR_PM_ARP);cr_set_perform(&c,1);
 cr_set_param(&c,CR_PM_ARP,CR_P_RETRIG,0);cr_key(&c,60,100,1);
 for(i=0;i<100;i++)cr_tick(&c,10*i);assert(c.voicing==0);
 cr_key_ex(&c,60,1,100,1);assert(c.voicing==1);
 for(i=0;i<100;i++)cr_tick(&c,1000+10*i);assert(c.voicing==1);
 cr_key_ex(&c,60,0,0,0);cr_key_ex(&c,60,1,0,0);cr_panic(&c);
 /* Random remains in range, does not immediately repeat, reaches all nine. */
 cr_set_swag(&c,2);last=c.voicing;
 for(i=0;i<1000;i++) {cr_key(&c,60,100,1);assert(c.voicing>=-3&&c.voicing<=5&&c.voicing!=last);seen[c.voicing+3]++;last=c.voicing;cr_key(&c,60,0,0);}
 for(i=0;i<9;i++)assert(seen[i]);
 /* Both independent modes together: sound A/B/A while inversion walks 0/1/2. */
 clear(ENGI_FM6,0,0);cu_fav_browser=0;cu_ping_valid=0;cr_rosen_pending=0;cr_rosen_valid=0;
 cu_pool_load(0,ENGI_FM6,2);settle();cr_set_swag(&cr,3);cr_rosen_mode=3;cr_mod(&cr,CR_MOD_MAJ,1);
 for(i=0;i<3;i++) {
  unsigned root=60+2*i;cr_key(&cr,root,100,1);assert(cr.voicing==(int)i);cu_rosen_service();settle();
  assert(cu_part_pos(0)==(i==1?3:2));assert(!cr_rosen_pending);
  cr_key(&cr,root,0,0);settle();assert(all_released());
 }
 cr_rosen_mode=0;
 /* Exact synth retained-tone checks at every auto inversion and either seventh. */
 for(mode=1;mode<=3;mode++)for(e=0;e<2;e++)for(bass=0;bass<2;bass++)for(q=0;q<2;q++) {
  clear(e?ENGI_PROPHET:ENGI_CZ,bass,0);cr_set_swag(&cr,mode);
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
  for(i=0;i<90;i++) {
   unsigned root=60+i%12;cr_key(&cr,root,100,1);settle();assert(complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,root));
   last=cr.voicing;cr_mod(&cr,CR_MOD_MAJ7,1);settle();assert(cr.voicing==last&&cr.v[0].sx==(CR_EXT_6|CR_EXT_MAJ7|CR_EXT_9));assert(complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,root));
   cr_mod(&cr,CR_MOD_M7,1);settle();assert(complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,root));cr_key(&cr,root,0,0);settle();assert(all_released());
  }
 }
 puts("PASS: SELECT menu, retired scales/settings, exclusive sevenths in Simple/Advanced/Free and LOCK, exact Ping Pong/Tennis, Random, release/retrigger/pads, third protection on CZ/Prophet with BASS");
 printf("Host structure sizes: chord engine %zu, chord voice %zu; target sizes require device build\n",sizeof(cr_t),sizeof(cr_voice_t));
 return 0;
}
