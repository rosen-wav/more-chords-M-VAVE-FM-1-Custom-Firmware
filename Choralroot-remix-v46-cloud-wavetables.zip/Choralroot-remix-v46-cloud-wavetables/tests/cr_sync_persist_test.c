/* SPDX-License-Identifier: GPL-3.0-only */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
static void fixture(void)
{
    crl_data_t d; memset(&d,0,sizeof d);d.len=384;d.nev=1;d.nlayers=1;
    d.ev[0]=(crl_ev_t){0,48,60,100,(CR_Q_MAJ<<4),0};
    cr_loop_set(&crl,&cr,&d);crl.met0=0;crl.t=23;crl.acc=0;
    crl.clk_on=1;crl.last_ms=cr_now_ms;crl.played=0;cr_route.clock_in=0;cr_midi_in();
}
static void drain(void){cr_audio_block(CTL);cr_snapshot();}
static void request(void){assert(cr_post(CRE_LOOP,LP_PLAY,0,0));drain();}
static void pulse(unsigned source){fm1_ms+=21;assert(midi_enqueue(0xF8u<<8|0x0Fu,source));drain();}
int main(void)
{
    unsigned cases=0;emu_fw_options(0,1,0,1);emu_fw_init(0);
    assert(cs.out_clean==1&&cs.usb48==0);
    for(unsigned tempo=20;tempo<=300;tempo+=7)for(unsigned tick=1;tick<96;tick+=5){
        fixture();cr.bpm=(uint16_t)tempo;crl.t=tick;
        assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_PLAY_ARMED);
        assert(crl.state==CRL_STOPPED && !crl.played);
        uint32_t time=cr_now_ms;
        while(crl.state==CRL_STOPPED && time<cr_now_ms+3100u)cr_loop_tick(&crl,&cr,++time);
        assert(crl.state==CRL_PLAYING && crl.cyc0==96 && !crl.play_armed);cases++;
        assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_STOP);
        assert(crl.state==CRL_STOPPED);
    }
    fixture();assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_PLAY_ARMED);
    assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_CANCEL);assert(!crl.play_armed);cases++;
    fixture();crl.t=96;crl.acc=0;assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_PLAY);assert(crl.cyc0==96);cases++;
    fixture();crl.t=96;crl.acc=1;assert(cr_loop_play_synced(&crl,&cr,0)==CRL_DID_PLAY_ARMED);cases++;
    for(unsigned action=0;action<4;action++){
        fixture();cr_loop_play_synced(&crl,&cr,0);
        if(action==0)cr_loop_stop(&crl,&cr);else if(action==1)cr_loop_clear(&crl,&cr);
        else if(action==2)cr_loop_set(&crl,&cr,0);else{cr_panic(&cr);cr_loop_panic(&crl);}
        assert(!crl.play_armed);cases++;
    }
    for(unsigned source=1;source<=2;source++){
        fixture();cr_route.clock_in=1;request();assert(crl.play_armed==2 && crl.state==CRL_STOPPED);
        for(unsigned i=0;i<1600;i++)drain();assert(crl.state==CRL_STOPPED); /* Never the internal substitute. */
        for(unsigned i=0;i<24;i++){pulse(source);assert(crl.state==CRL_STOPPED);}
        assert(cr_cin.bpm && cr_sidechain_midi_step==23);pulse(source);
        assert(crl.state==CRL_PLAYING && !crl.play_armed && cr_sidechain_midi_step==0);cases++;
        assert(midi_enqueue(0xFCu<<8|0x0Fu,source));drain();assert(crl.state==CRL_STOPPED);
        request();assert(crl.play_armed==2);assert(midi_enqueue(0xFCu<<8|0x0Fu,source));drain();assert(!crl.play_armed);
        assert(midi_enqueue(0xFAu<<8|0x0Fu,source));drain();assert(crl.state==CRL_PLAYING);
        assert(midi_enqueue(0xFCu<<8|0x0Fu,source));drain();assert(crl.state==CRL_STOPPED);
        assert(midi_enqueue(0xFBu<<8|0x0Fu,source));drain();assert(crl.state==CRL_PLAYING);cases+=3;
    }
    fixture();request();assert(crl.play_armed==1);cr_route.clock_in=1;drain();assert(!crl.play_armed);cases++;
    cr_route.clock_in=0;cr_midi_in();cr_loop_clear(&crl,&cr);cr_panic(&cr);cr_snapshot();
    /* Real emulated NOR writes and re-reading, not just a JSON/struct round trip. */
    for(unsigned record=0;record<2;record++)for(unsigned level=0;level<2;level++)for(unsigned rate=0;rate<2;rate++){
        opt_set(O_USB_IN,record);opt_set(O_USB_LEVEL,level);opt_set(O_USB_RATE,rate);opt_set(O_OUTPUT,1);
        cr_settings_save();persist_t saved;int n=st_load(OBJ_SETTINGS,&saved,sizeof saved);
        assert(n>0&&settings_import(&saved,n));assert(saved.cr.usb_in==record && saved.cr.usb_level==level && CRS_USB48(&saved.cr)==rate && CRS_OUT_CLEAN(&saved.cr));
        cs.usb_in=cs.usb_fixed=cs.usb48=cs.out_clean=0;cr_settings_boot();cr_settings_load();
        assert(cs.usb_in==record && cs.usb_fixed==level && cs.usb48==rate && cs.out_clean==1);cases++;
    }
    /* Automatic saving after the normal settling/quiet interval, no SAVE gesture. */
    for(unsigned p=0;p<NPART;p++)memset(trk[p].v,0,sizeof trk[p].v);
    memset(scope_buf,0,sizeof scope_buf);cr_panic(&cr);cr_loop_clear(&crl,&cr);cr_snapshot();
    opt_set(O_USB_RATE,0);opt_set(O_USB_IN,1);fm1_ms+=2000;cr_settings_poll();fm1_ms+=2000;cr_settings_poll();
    persist_t auto_saved;int n=st_load(OBJ_SETTINGS,&auto_saved,sizeof auto_saved);assert(n>0&&settings_import(&auto_saved,n));assert(!CRS_USB48(&auto_saved.cr)&&auto_saved.cr.usb_in==1);cases++;
    printf("PASS: sync/persist %u cases: next-quarter onset across tempos, stop/cancel/boundary/fraction, clear/load/panic, USB+TRS clock-only/manual and Start/Continue/Stop, source change, Clean default, USB NOR save/reload and automatic persistence\n",cases);
    return 0;
}
