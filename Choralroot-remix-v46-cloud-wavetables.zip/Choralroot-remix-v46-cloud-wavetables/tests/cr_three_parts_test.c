/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);
 for(unsigned p=0;p<NTRK;p++)assert(pf.mg[p]==32768);
 assert(NPART==3&&NTRK==3);assert(NELEM(trk)==3&&NELEM(eng_state)==3);
 assert(NELEM(kr106_patch)==3&&NELEM(fm6_patch)==3&&NELEM(vsq)==3);
 assert(sizeof(up_rec_t)==192&&sizeof(up_bank_t)==3080&&sizeof(cr_settings_t)==192&&sizeof(persist_t)==764);
 assert(trk[2].p[P_MUTE]);
 printf("PASS: exactly three runtime parts; track %zu and shared native state %zu host bytes per part removed; USER/bank/settings layouts unchanged, Morph B starts muted\n",sizeof trk[0],sizeof eng_state[0]);return 0;}
