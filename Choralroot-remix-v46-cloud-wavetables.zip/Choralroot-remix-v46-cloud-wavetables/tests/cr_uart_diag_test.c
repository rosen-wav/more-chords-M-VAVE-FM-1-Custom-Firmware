#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint32_t r[17], q[64], nq;
#define FM1_UT1_CON0 r[0]
#define FM1_UT1_CON1 r[1]
#define FM1_UT1_BAUD r[2]
#define FM1_UT1_OTCNT r[3]
#define FM1_UT1_RXSADR r[4]
#define FM1_UT1_RXEADR r[5]
#define FM1_UT1_RXCNT r[6]
#define FM1_UT1_HRXCNT r[7]
#define FM1_UM_CLK_CON1 r[8]
#define FM1_UM_IOMAP2 r[9]
#define FM1_UM_IOMAP3 r[10]
#define FM1_UM_PH_IN r[11]
#define FM1_UM_PH_DIR r[12]
#define FM1_UM_PH_DIE r[13]
#define FM1_UM_PH_PU r[14]
#define FM1_UM_PH_PD r[15]
#define FM1_UART_SYNC() __asm__ volatile("" ::: "memory")
static uint8_t midi_in_overflow;
static int midi_enqueue(uint32_t packet,uint32_t source){assert(source==2);assert(nq<64);q[nq++]=packet;return 1;}
#include "../firmware/src/midi_uart.c"
int main(void){
 uart_midi_init();assert(um.init_calls==1);assert(r[2]==383&&r[6]==UM_RING&&(r[0]&1));
 assert(r[4]==(uint32_t)(uintptr_t)um_ring&&r[5]-r[4]==UM_RING);
 assert((r[9]&0x3f00)==49u<<8&&(r[10]&0x70)==5u<<4);
 fm1_uart1_diag_t d;uint32_t before[17];memcpy(before,r,sizeof r);fm1_uart1_diag(&d);assert(!memcmp(before,r,sizeof r));
 assert(d.rx_start==r[4]&&d.rx_end==r[5]&&d.baud==383&&d.iomap2==r[9]);
 r[11]=1u<<8;r[7]=0;uart_midi_poll();assert(um.polls==1&&um.rx_high==1&&!um.bytes&&um.rx_changes==1);
 r[11]=0;um_ring[0]=0xF8;um_ring[1]=0x90;um_ring[2]=60;um_ring[3]=100;r[7]=4;
 uart_midi_poll();assert(um.polls==2&&um.rx_low==1&&um.rx_changes==2);
 assert(um.dma_bytes==4&&um.dma_last==4&&um.dma_max==4&&um.bytes==4&&nq==2);
 assert(q[0]==(0xfu|0xf8u<<8)&&q[1]==(9u|0x90u<<8|60u<<16|100u<<24));
 r[7]=0;uart_midi_poll();assert(um.polls==3&&um.dma_bytes==4&&um.bytes==4);
 puts("PASS: UART read-only register snapshot, pin samples/changes, init/poll/DMA counters, clock and note parser; mocked MMIO, physical input still unknown");
}
