#include <assert.h>
/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_BACKUP_TEST_HELPERS_ONLY
#include "cr_backup_test.c"
int main(void){
 emu_flash_open();memset(emu_flash,255,sizeof emu_flash);st_ext_ready=0;cr_bank_boot();cr_settings_boot();cr_ui_init();usb.config=1;
 uint8_t banks[7680],read[3840];FILE *f=fopen("build/user64-fixture.bin","rb");assert(f&&fread(banks,sizeof banks,1,f)==1);fclose(f);
 for(unsigned b=0;b<2;b++){
  assert(!t_put(70+b,banks+3840*b,3840));
  assert(!t_list());
  for(unsigned i=0;i<3840;i+=256)assert(!t_get(70+b,i,256,read+i));
  assert(!memcmp(read,banks+b*3840,3840));
 }
 for(unsigned k=32;k<64;k++)assert(up_used(k));
 uint8_t before[3840];memcpy(before,banks,3840);banks[1]=9;
 assert(t_put(70,banks,3840)==2);assert(!t_list());for(unsigned i=0;i<3840;i+=256)assert(!t_get(70,i,256,read+i));assert(!memcmp(read,before,3840));
 assert(!t_put(70,0,0));for(unsigned k=32;k<48;k++)assert(!up_used(k));for(unsigned k=48;k<64;k++)assert(up_used(k));
 puts("PASS: USER extension SysEx PUT/LIST/GET 3840-byte staging, exact records, malformed restore refused, bank deletion isolated");
}
