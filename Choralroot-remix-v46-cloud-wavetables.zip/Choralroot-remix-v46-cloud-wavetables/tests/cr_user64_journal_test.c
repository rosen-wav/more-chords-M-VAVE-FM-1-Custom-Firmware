/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#define FELUCCA_CZ 1
#define FELUCCA_QUAD 1
static uint8_t nor[0x100000],baseline[0x100000];static int cut=-1;
static int st_read(uint32_t a,void *p,uint32_t n){assert(a+n<=sizeof nor);memcpy(p,nor+a,n);return 0;}
static int st_erase(uint32_t a){assert(a>=0xf9000&&a<0xfc000);memset(nor+a,255,4096);return 0;}
static int st_prog(uint32_t a,const void *p,uint32_t n){assert(a>=0xf9000&&a+n<=0xfc000);const uint8_t *s=p;for(unsigned i=0;i<n;i++){if(!cut)return -9;if(cut>0)cut--;nor[a+i]&=s[i];}return 0;}
#include "../firmware/src/storage.c"
int main(void){
 uint8_t old[2][3840],next[3840],read[3840];memset(nor,255,sizeof nor);
 memset(old[0],0x35,3840);memset(old[1],0x6b,3840);memset(next,0x9d,3840);
 assert(!st_save(OBJ_UPEXT0,old[0],3840));assert(!st_save(OBJ_UPEXT1,old[1],3840));
 for(unsigned i=0;i<9;i++){assert(!st_save(OBJ_UPEXT0+i%2,old[i%2],3840));}
 memcpy(baseline,nor,sizeof nor);
 unsigned cases=0;
 for(unsigned bank=0;bank<2;bank++)for(int limit=0;limit<=3888;limit++){
  /* Every byte of payload and commit header, plus complete writes. */
  memcpy(nor,baseline,sizeof nor);st_ext_ready=0;cut=limit;
  int rc=st_save(OBJ_UPEXT0+bank,next,3840);cut=-1;st_ext_ready=0;
  assert(st_load(OBJ_UPEXT0+bank,read,3840)==3840);assert(!memcmp(read,old[bank],3840)||!memcmp(read,next,3840));
  if(!rc)assert(!memcmp(read,next,3840));
  assert(st_load(OBJ_UPEXT0+1-bank,read,3840)==3840&&!memcmp(read,old[1-bank],3840));
  assert(!memcmp(nor,baseline,0xf9000)&&!memcmp(nor+0xfc000,baseline+0xfc000,0x4000));cases++;
 }
 printf("PASS: %u byte-level torn journal writes; both banks recover, legacy/loop/settings sectors untouched\n",cases);
}
