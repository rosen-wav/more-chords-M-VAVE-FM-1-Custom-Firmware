/* SPDX-License-Identifier: GPL-3.0-only */
/* V23 chorus kernel, test-only reference for timing/level comparisons. */
static int16_t reference_buf[1024];
static struct {uint32_t cho_w,cho_ph,cho_tail;int32_t cho_depth;fm106_bbd_filter_t cho_fl,cho_fr;} reference_fx;
static int32_t reference_tap(uint32_t wr, int32_t delay)
{
    uint32_t rd=(wr-1u-(uint32_t)(delay>>16))&(CHO_LEN-1u);
    return fm106_hermite((delay>>1)&32767,reference_buf[(rd+1u)&(CHO_LEN-1u)],
        reference_buf[rd],reference_buf[(rd-1u)&(CHO_LEN-1u)],reference_buf[(rd-2u)&(CHO_LEN-1u)]);
}
static int32_t reference_return(int32_t in, int32_t *side, uint32_t mode, int32_t depth)
{
    static const uint32_t inc[3]={50098u,82068u,765109u};
    static const int32_t swing[3]={94,75,10};
    *side=0;
    if(in)reference_fx.cho_tail=4096;
    if(!reference_fx.cho_tail)return 0;
    reference_fx.cho_tail--;
    uint32_t wr=reference_fx.cho_w++&(CHO_LEN-1u);
    reference_buf[wr]=(int16_t)fm106_soft_limit(clamp(in/2,-32768,32767));
    reference_fx.cho_ph+=inc[mode];
    int32_t tri=(int32_t)(reference_fx.cho_ph>>16)-32768;
    if(tri<0)tri=-tri;
    tri=(tri-16384)*2;
    /* Slew width/mode changes, leaving phase continuous. Q8 sample depth. */
    int32_t target=swing[mode]*depth*256/127;
    reference_fx.cho_depth+=(target-reference_fx.cho_depth)/256;
    int32_t mod=(int32_t)(((int64_t)tri*reference_fx.cho_depth)>>8);
    int32_t l=fm106_bbd_filter_process(&reference_fx.cho_fl,reference_tap(wr,(154<<16)+mod));
    int32_t r=fm106_bbd_filter_process(&reference_fx.cho_fr,reference_tap(wr,(154<<16)-mod));
    *side=l-r;
    if(!reference_fx.cho_tail){fm106_bbd_filter_init(&reference_fx.cho_fl);fm106_bbd_filter_init(&reference_fx.cho_fr);}
    return l+r;
}
