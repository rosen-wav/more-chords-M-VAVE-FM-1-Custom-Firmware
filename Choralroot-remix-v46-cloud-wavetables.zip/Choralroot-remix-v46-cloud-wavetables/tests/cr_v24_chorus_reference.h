/* SPDX-License-Identifier: GPL-3.0-only */
/* V24 test-only kernel reference, never linked into firmware. */
static int16_t v24_buf[1024];
static struct {uint32_t cho_w,cho_ph,cho_tail,cho_inc;int32_t cho_depth,cho_target;fm106_bbd_filter_t cho_fl,cho_fr;}v24_fx;
static int32_t v24_tap(uint32_t wr,int32_t delay){
 uint32_t rd=(wr-1u-(uint32_t)(delay>>16))&(CHO_LEN-1u);
 int32_t a=v24_buf[rd],b=v24_buf[(rd-1u)&(CHO_LEN-1u)];
 return a+(((b-a)*((delay>>1)&32767))>>15);
}
/* Exact original soft knee for the bounded input, using a read-only table
 * instead of rational integer division on loud samples. No extra RAM. */
static const int16_t V24_KNEE[257]={24576,24607,24639,24670,24701,24732,24763,24793,24823,24853,24882,24912,24941,24969,24998,25026,25054,25082,25110,25137,25165,25192,25219,25245,25272,25298,25324,25349,25375,25400,25426,25451,25475,25500,25524,25549,25573,25597,25620,25644,25667,25690,25713,25736,25759,25782,25804,25826,25848,25870,25892,25913,25935,25956,25977,25998,26019,26040,26060,26081,26101,26121,26141,26161,26181,26200,26220,26239,26258,26277,26296,26315,26334,26352,26371,26389,26407,26425,26443,26461,26479,26497,26514,26532,26549,26566,26583,26600,26617,26634,26651,26667,26684,26700,26716,26732,26748,26764,26780,26796,26812,26827,26843,26858,26873,26889,26904,26919,26934,26949,26963,26978,26993,27007,27022,27036,27050,27064,27078,27092,27106,27120,27134,27148,27161,27175,27188,27202,27215,27228,27242,27255,27268,27281,27294,27306,27319,27332,27344,27357,27369,27382,27394,27407,27419,27431,27443,27455,27467,27479,27491,27502,27514,27526,27537,27549,27560,27572,27583,27594,27606,27617,27628,27639,27650,27661,27672,27683,27694,27704,27715,27726,27736,27747,27757,27768,27778,27788,27799,27809,27819,27829,27839,27849,27859,27869,27879,27889,27899,27908,27918,27928,27937,27947,27956,27966,27975,27985,27994,28003,28013,28022,28031,28040,28049,28058,28067,28076,28085,28094,28103,28112,28120,28129,28138,28146,28155,28163,28172,28181,28189,28197,28206,28214,28222,28231,28239,28247,28255,28263,28271,28279,28288,28295,28303,28311,28319,28327,28335,28343,28350,28358,28366,28373,28381,28389,28396,28404,28411,28419,28426,28434,28441,28448,28456,28463,28470};
static int32_t v24_input(int32_t in){
 int32_t x=clamp(in/2,-32768,32767),a=x<0?-x:x;
 if(a>24576)a=V24_KNEE[(uint32_t)(a-24576)>>5];
 return x<0?-a:a;
}
static void v24_prepare(uint32_t mode,int32_t depth){
 static const uint32_t inc[3]={50098u,82068u,765109u};
 static const int32_t swing[3]={94,75,10};
 v24_fx.cho_inc=inc[mode];v24_fx.cho_target=swing[mode]*depth*256/127;
}
/* Light BBD reconstruction: two cascaded RC poles. Gain3/4 uses only
 * additions/shifts; unity DC gain, bounded monotonic states, warmer top end. */
static int32_t v24_filter(fm106_bbd_filter_t *f,int32_t x){
 f->ic1+=((x-f->ic1)*3)>>2;
 f->ic2+=((f->ic1-f->ic2)*3)>>2;
 return f->ic2;
}
static int32_t v24_return(int32_t in,int32_t *side){
 *side=0;
 if(in)v24_fx.cho_tail=4096;
 if(!v24_fx.cho_tail)return 0;
 v24_fx.cho_tail--;
 uint32_t wr=v24_fx.cho_w++&(CHO_LEN-1u);
 v24_buf[wr]=(int16_t)v24_input(in);
 v24_fx.cho_ph+=v24_fx.cho_inc;
 int32_t tri=(int32_t)(v24_fx.cho_ph>>16)-32768;
 if(tri<0)tri=-tri;
 tri=(tri-16384)*2;
 /* Keep the original full-rate width slew: no stepped delay changes.
  * Q8 depth max 24064: triangle*depth fits signed 32 bits. */
 v24_fx.cho_depth+=(v24_fx.cho_target-v24_fx.cho_depth)/256;
 int32_t mod=(tri*v24_fx.cho_depth)>>8;
 int32_t l=v24_filter(&v24_fx.cho_fl,v24_tap(wr,(154<<16)+mod));
 int32_t rr=v24_filter(&v24_fx.cho_fr,v24_tap(wr,(154<<16)-mod));
 *side=l-rr;
 if(!v24_fx.cho_tail){fm106_bbd_filter_init(&v24_fx.cho_fl);fm106_bbd_filter_init(&v24_fx.cho_fr);}
 return l+rr;
}
