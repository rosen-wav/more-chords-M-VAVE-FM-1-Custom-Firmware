#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include <time.h>
static uint64_t energy;
int main(void){
 clear(ENGI_KR106,1,0);song.g[G_BPM]=120;
 for(int32_t x=-65536;x<65536;x++)assert(chorus_input(x)==fm106_soft_limit(clamp(x/2,-32768,32767)));
 assert(chorus_input(INT32_MIN)==fm106_soft_limit(-32768));assert(chorus_input(INT32_MAX)==fm106_soft_limit(32767));
 uint64_t hashes[3],side_energy;int32_t side;
 for(unsigned mode=0;mode<3;mode++){
  memset(&fx,0,sizeof fx);memset(cho_buf,0,sizeof cho_buf);uint64_t hash=1469598103934665603ull;side_energy=0;
  for(unsigned k=0;k<100000;k++){
   if(!(k%CTL))chorus_prepare(mode,(k/8192)%2?0:127);
   int32_t in=(int32_t)(k*977u%80000)-40000;
   int32_t mid=chorus_return(in,&side);assert(llabs(mid)<131072&&llabs(side)<131072);
   energy+=llabs(mid);side_energy+=llabs(side);hash=(hash^(uint32_t)mid)*1099511628211ull;
  }
  hashes[mode]=hash;assert(side_energy);
  for(unsigned k=0;k<5000;k++)chorus_return(0,&side);
  assert(!fx.cho_tail);assert(!chorus_return(0,&side)&&!side);
 }
 assert(energy&&hashes[0]!=hashes[1]&&hashes[1]!=hashes[2]&&hashes[0]!=hashes[2]);
 /* Moving from silence to a full-scale DC send must stay bounded during live mode/width changes. */
 memset(&fx,0,sizeof fx);memset(cho_buf,0,sizeof cho_buf);int32_t prev=0;uint32_t seed=17;
 for(unsigned k=0;k<500000;k++){
  if(!(k%CTL)){seed=seed*1664525u+1013904223u;chorus_prepare(seed%3,(seed>>8)%128);}
  int32_t out=chorus_return(k<10000?0:65534,&side);assert(llabs(out)<131072&&llabs(side)<131072);
  if(k>20000)assert(llabs(out-prev)<2000);prev=out;
 }
 puts("PASS: chorus exact 131072-point soft-knee comparison, three distinct stereo modes, 800000 samples, live control changes, bounded levels, smooth DC, tail/silent bypass");
 return 0;
}
