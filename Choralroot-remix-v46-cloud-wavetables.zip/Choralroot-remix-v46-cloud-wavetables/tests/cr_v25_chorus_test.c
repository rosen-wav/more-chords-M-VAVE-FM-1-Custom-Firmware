#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include "cr_v24_chorus_reference.h"
int main(void){
 for(unsigned mode=0;mode<3;mode++)for(unsigned wide=0;wide<2;wide++){
  memset(&fx,0,sizeof fx);memset(cho_buf,0,sizeof cho_buf);memset(&v24_fx,0,sizeof v24_fx);memset(v24_buf,0,sizeof v24_buf);
  uint64_t err=0,energy=0;uint32_t ph=0,ph2=0;int32_t side,oldside;
  for(unsigned k=0;k<100000;k++){
   if(!(k%CTL)){chorus_prepare(mode,wide?127:0);v24_prepare(mode,wide?127:0);}
   ph+=21426141u;ph2+=292174647u;
   int32_t in=osc_sine(ph)+osc_sine(ph2)/3;
   int32_t a=chorus_return(in,&side),b=v24_return(in,&oldside);
   if(!wide){assert(a==b);assert(side==oldside);}
   int64_t dm=(int64_t)a-b,ds=(int64_t)side-oldside;
   err+=(uint64_t)(dm*dm+ds*ds);energy+=(uint64_t)((int64_t)b*b+(int64_t)oldside*oldside);
  }
  assert(energy&&err*16u<energy);
  printf("PASS: shared input-filter mode%u width%u, relative squared error %llu ppm; width0 exactly V24\n",mode,wide?127:0,(unsigned long long)(err*1000000u/energy));
 }
 return 0;
}
