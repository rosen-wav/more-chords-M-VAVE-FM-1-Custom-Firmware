/* SPDX-License-Identifier: GPL-3.0-only */
/* Unchanged V25 DCO kernel for exact prepared-PWM comparison. */
static inline int32_t reference_dco(
    fm106_dco_t *d,
    uint32_t eff_inc,
    uint8_t pw_slider,
    uint8_t pw_mode,
    int32_t lfo_tri,
    int32_t env_q15)
{
    uint32_t prev_ph = d->ph;
    uint32_t next_ph = prev_ph + eff_inc;
    d->ph = next_ph;

    /* Detect phase wrap: toggle sub-oscillator flip-flop */
    if (next_ph < prev_ph) {
        d->sub_state = !d->sub_state;
    }

    /* Shared PolyBLEP residual at phase reset */
    int32_t blep_reset = fm106_poly_blep(next_ph, eff_inc);

    int32_t total = 0;

    /* 1. Sawtooth: amp 0.6 (19660 in Q15) */
    if (d->saw_on) {
        int32_t saw = fm106_osc_saw(next_ph, eff_inc, blep_reset);
        total += (saw * 19660) >> 15;
    }

    /* 2. Pulse with Juno-106 inverted duty cycle: amp 0.5 (16384 in Q15) */
    if (d->pulse_on) {
        /* Compute pulse width duty (0.50..0.95) from fader / LFO / ENV */
        int32_t mod_pw;
        if (pw_mode == 0) {   /* LFO PWM */
            mod_pw = ((int32_t)pw_slider * (32768 + lfo_tri)) >> 16;
        } else {              /* Manual PWM */
            mod_pw = pw_slider;
        }
        if (mod_pw < 0) mod_pw = 0;
        if (mod_pw > 105) mod_pw = 105;

        /* Range: 50% to 95% -> 0x80000000 to 0xF3333333 (Juno-106 hardware panel limit: byte 105 = 95%) */
        uint32_t pw32 = 0x80000000u + ((uint32_t)mod_pw * 18407003u);

        /* Juno-106 inverted comparator: narrow dip sits at end of ramp */
        uint32_t eff_pw = 0xFFFFFFFFu - pw32;

        /* Comparator + dual PolyBLEP */
        int32_t pulse = (next_ph < eff_pw) ? -32767 : 32767;
        pulse -= blep_reset;
        uint32_t pw_edge = next_ph - eff_pw;
        pulse += fm106_poly_blep(pw_edge, eff_inc);

        /* DC is removed downstream by the authentic 1.59 Hz analog coupling filter (fm106_dc_block),
         * matching hardware Juno-106 and reference KR106Oscillators.h */
        total += (pulse * 16384) >> 15;
    }

    /* 3. Sub-oscillator: 1 octave down square, amp 0.75 * FM106_SUB_LEVEL_J106 (24576 in Q15) */
    if ((d->sub_on || d->sub_level > 0) && d->sub_level > 0) {
        int32_t sub_sign = d->sub_state ? -32767 : 32767;
        int32_t abs_blep = blep_reset < 0 ? -blep_reset : blep_reset;
        if (abs_blep > 32768) abs_blep = 32768;
        int32_t sub = (sub_sign * (32768 - abs_blep)) >> 15;
        int32_t taper = FM106_SUB_LEVEL_J106[d->sub_level > 127u ? 127u : d->sub_level];
        int32_t sub_scaled = (sub * taper) >> 15;
        total += (sub_scaled * 24576) >> 15;
    }

    /* 4. Analog Noise Generator: 5.3 kHz 1-pole RC filtered (Roland 2SC945 noise path), calibrated to reference RMS */
    if (d->noise_level > 0) {
        uint32_t nr = fm106_noise32(&d->noise_seed);
        int32_t raw_n = (int32_t)(nr >> 16) - 32768;   /* Q15 bipolar noise */
        /* 1-pole RC lowpass at 5305 Hz: g1 ~= 0.284 in Q15 = 9300 */
        d->noise_lpf += (9300 * (raw_n - d->noise_lpf)) >> 15;
        int32_t n_level = FM106_NOISE_LEVEL_J106[d->noise_level > 127u ? 127u : d->noise_level];
        int32_t noise_scaled = (d->noise_lpf * n_level) >> 15;
        /* Gain 2.776x (91000 in Q15) matches PC reference CLT + flicker RMS (kNoiseAmpJ106 = 1.2) */
        total += (int32_t)(((int64_t)noise_scaled * 91000LL) >> 15);
    }

    return total;
}
