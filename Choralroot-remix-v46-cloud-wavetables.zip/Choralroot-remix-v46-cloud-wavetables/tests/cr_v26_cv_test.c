#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include "../firmware/src/fm106_vcf.h"
int main(void){unsigned s=7;
 for(unsigned k=0;k<1000000;k++){
  s=s*1664525u+1013904223u;uint16_t cutoff=s&65535u,lfo=(s>>16)&65535u;
  s=s*1664525u+1013904223u;uint16_t bend=s&65535u,pitch=(s>>16)&65535u;
  s=s*1664525u+1013904223u;uint16_t env=s&16383u;uint8_t depth=(s>>16)&255u,key=(s>>24)&255u;
  unsigned lp=k&1,bp=(k>>1)&1,ep=(k>>2)&1;uint16_t ps=(pitch>>2)+(pitch>>3);unsigned up=ps>0x1680u;
  uint16_t kd=fm106_mul8x16_hi(key,up?ps-0x1680u:0x1680u-ps);
  uint16_t ref=fm106_calc_vcf_freq(cutoff,lfo,bend,depth,key,lp,bp,ep,env,pitch);
  uint16_t now=fm106_vcf_voice_cv(fm106_vcf_base(cutoff,lfo,bend,lp,bp),depth,ep,env,kd,up);
  assert(ref==now);
 }
 puts("PASS:1000000 split/full DAC comparisons exact, including wrap, overflow, polarity, envelope/key tracking");return 0;
}
