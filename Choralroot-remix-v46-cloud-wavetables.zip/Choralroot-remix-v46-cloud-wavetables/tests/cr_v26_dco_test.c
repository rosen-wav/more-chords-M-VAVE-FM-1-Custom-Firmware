#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/src/fm106_osc.h"
#include "cr_v25_dco_reference.h"
int main(void){fm106_dco_t a,b;fm106_dco_init(&a,0);b=a;unsigned seed=17;
 for(unsigned k=0;k<1000000;k++){
  seed=seed*1664525u+1013904223u;
  if(!(k&255u)){a.saw_on=b.saw_on=seed&1;a.pulse_on=b.pulse_on=1;a.sub_on=b.sub_on=(seed>>1)&1;a.sub_level=b.sub_level=(seed>>3)%128;a.noise_level=b.noise_level=(seed>>10)%128;}
  int32_t lfo=(int32_t)(seed&65535u)-32768;uint8_t slider=(seed>>16)%128,mode=(seed>>25)&1;
  uint32_t inc=2000000u+(seed%0x17000000u);
  assert(reference_dco(&a,inc,slider,mode,lfo,12345)==fm106_dco_prepared(&b,inc,fm106_pwm_edge(slider,mode,lfo)));
  assert(!memcmp(&a,&b,sizeof a));
 }
 puts("PASS: prepared PWM is sample/state exact to V25 in1000000 DCO samples, LFO/manual PWM, wave/sub/noise panels");return 0;
}
