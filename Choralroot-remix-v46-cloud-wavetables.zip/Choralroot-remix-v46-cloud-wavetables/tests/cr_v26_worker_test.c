#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static int32_t pcm[2*CTL];static unsigned char fx_state[sizeof fx];
static _Atomic uint32_t busy_hold,busy_entered;
static void busy_job(void *p){(void)p;AW_STORE(&busy_entered,1);while(AW_LOAD(&busy_hold))sched_yield();}
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);pthread_t th;
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 const unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_VA,ENGI_QUAD,ENGI_CZ,ENGI_PROPHET,ENGI_KR106};unsigned cases=0;
 for(unsigned preset=0;preset<129;preset+=16)for(unsigned bass=0;bass<7;bass++)for(unsigned rev=0;rev<4;rev++)for(unsigned model=0;model<3;model++){
  cr_c1_test_serial=1;setup(ENGI_KR106,preset,basses[bass],0,6,rev);song.g[G_CRATE]=model;song.g[G_CDEPTH]=127;
  trk[0].p[P_CHOR]=trk[1].p[P_CHOR]=110;uint32_t jobs=c1_chorus_jobs;
  for(unsigned k=0;k<128;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);memcpy(fx_state,&fx,sizeof fx);
  assert(c1_chorus_jobs==jobs);
  cr_c1_test_serial=0;setup(ENGI_KR106,preset,basses[bass],0,6,rev);song.g[G_CRATE]=model;song.g[G_CDEPTH]=127;trk[0].p[P_CHOR]=trk[1].p[P_CHOR]=110;
  for(unsigned k=0;k<128;k++){block(k,pcm);assert(!AW_C1_BUSY()&&!chorus_async);assert(!memcmp(pcm,reference[k],sizeof pcm));}
  assert(!memcmp(states,eng_state,sizeof states)&&!memcmp(fx_state,&fx,sizeof fx));assert(c1_chorus_jobs>jobs);cases++;
 }
 /* Offline fallback remains the exact same same-block mix. */
 cr_c1_test_serial=1;setup(ENGI_KR106,32,ENGI_BASS,0,6,3);for(unsigned k=0;k<128;k++)block(k,reference[k]);
 audio_worker_online=0;cr_c1_test_serial=0;setup(ENGI_KR106,32,ENGI_BASS,0,6,3);uint32_t jobs=c1_chorus_jobs;
 for(unsigned k=0;k<128;k++){block(k,pcm);assert(!memcmp(pcm,reference[k],sizeof pcm));}assert(c1_chorus_jobs==jobs);audio_worker_online=1;
 /* A busy mailbox is never overwritten; chorus safely stays serial. */
 int32_t in[CTL],zero[CTL]={0},wetbuf[CTL];for(unsigned i=0;i<CTL;i++)in[i]=10000;
 setup(ENGI_KR106,1,ENGI_BASS,0,0,0);jobs=c1_chorus_jobs;AW_STORE(&busy_hold,1);AW_STORE(&busy_entered,0);
 assert(audio_worker_submit(busy_job,0));while(!AW_LOAD(&busy_entered))sched_yield();
 fx_buses(in,zero,zero,wetbuf,CTL);assert(c1_chorus_jobs==jobs&&AW_C1_BUSY()&&!chorus_async);
 AW_STORE(&busy_hold,0);audio_worker_join();assert(!AW_C1_BUSY());
 /* No extra worker dispatch for an unused chorus. */
 setup(ENGI_KR106,1,ENGI_BASS,0,0,0);jobs=c1_chorus_jobs;fx_buses(zero,zero,zero,wetbuf,CTL);assert(c1_chorus_jobs==jobs);
 pthread_cancel(th);pthread_join(th,0);audio_worker_online=0;
 printf("PASS: %u KR106+7Bass/4reverb/3chorus serial-vs-CPU1 FX PCM/state fixtures, joined same block, offline/busy/silent fallbacks\n",cases);return 0;
}
