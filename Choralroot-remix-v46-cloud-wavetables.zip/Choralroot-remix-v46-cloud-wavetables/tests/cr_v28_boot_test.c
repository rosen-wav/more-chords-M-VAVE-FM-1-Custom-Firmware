#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void)
{
    cr_screen_t s;
    emu_fw_options(0,1,0,1); emu_fw_init(0);
    assert(chord_worker_voices(ENGI_KR106)==2);
    assert(chord_worker_voices(ENGI_PROPHET)==2);
    assert(chord_worker_voices(ENGI_CZ)==2);
    assert(chord_worker_voices(ENGI_CLOUD)==2);
    cu.page=PG_NONE; cu.opt_open=0; cu.epk_on=0;
    cu.bheld=cu.kheld=0; cc.on=0; cr_safe=0;
    memset(&cu.msg,0,sizeof cu.msg); memset(&cu.pop,0,sizeof cu.pop);
    memset(&cr_snap,0,sizeof cr_snap);
    cu_boot_ms=cu_now();
    cr_build_screen(&s,cu_boot_ms+100);
    assert(s.kind==CR_K_BOOT);
    cr_build_screen(&s,cu_boot_ms+CR_SPLASH_MS+1);
    assert(s.kind!=CR_K_BOOT);
    cr_safe=1;
    cr_build_screen(&s,cu_boot_ms+100);
    assert(s.kind==CR_K_BIG && !strcmp(s.value,"SAFE MODE"));
    cr_safe=0;cu.bheld=1;
    cr_build_screen(&s,cu_boot_ms+100);
    assert(s.kind!=CR_K_BOOT);
    puts("PASS: KR106 4+2 policy; startup visible before saved Home; expiry, button dismissal and safe-mode priority");
    return 0;
}
