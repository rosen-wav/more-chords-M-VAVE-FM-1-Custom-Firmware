#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void)
{
    int32_t state=0;
    for(unsigned i=0;i<1000000;i++) {
        int32_t in=(i&1)?INT32_MAX:INT32_MIN;
        int32_t y=kr106_dc_light(in,&state);
        assert(y>=-4194302&&y<=4194302);
        assert(state>=-536870656&&state<=536870656);
    }
    for(int sign=-1;sign<=1;sign+=2) {
        state=0;int32_t y=0;
        for(unsigned i=0;i<100000;i++)y=kr106_dc_light(sign*10000,&state);
        assert(y>=-20&&y<=20);
    }
    puts("PASS: 1000000 extreme DC-filter inputs and constant-input convergence, signed 32-bit bounds");
    return 0;
}
