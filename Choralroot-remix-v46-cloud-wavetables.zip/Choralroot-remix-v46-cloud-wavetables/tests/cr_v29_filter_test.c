#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include "../firmware/src/fm106_vcf.h"
#include "cr_v29_vcf_reference.h"
int main(void)
{
    fm106_vcf_t f;
    reference_vcf_t ref;
    uint32_t seed=12345;
    uint64_t energy=0,err=0;
    for(unsigned i=0;i<1000000;i++) {
        seed=seed*1664525u+1013904223u;
        int32_t a=(int32_t)(seed%16000001u)-8000000;
        int32_t b=(seed>>16)%32769;
        uint32_t shift=10u+(seed%6);
        assert(fm106_mul32_shift(a,b,shift)==(int32_t)(((int64_t)a*b)>>shift));
    }
    puts("PASS: 1000000 bounded 32-bit fixed-point products exact against int64 reference");
    for (unsigned setting=0;setting<128;setting++) {
        fm106_vcf_init(&f); reference_vcf_init(&ref);
        f.noise_seed=ref.noise_seed=12345;
        for (unsigned i=0;i<8192;i++) {
            seed=seed*1664525u+1013904223u;
            int32_t input=(int32_t)(seed>>18)-8192;
            uint16_t dac=512+setting*120u;
            int32_t a=fm106_vcf_process(&f,input,dac,setting);
            int32_t b=reference_vcf_process(&ref,input,dac,setting);
            assert(a>-4000000&&a<4000000);
            for(unsigned j=0;j<4;j++)assert(f.z[j]>=-2097152&&f.z[j]<=2097151);
            energy+=(uint64_t)(b<0?-(int64_t)b:b);
            err+=(uint64_t)(a>b?(int64_t)a-b:(int64_t)b-a);
        }
    }
    fm106_vcf_init(&f);
    for(unsigned i=0;i<1000000;i++) {
        int32_t input=(i&1)?1000000:-1000000;
        int32_t out=fm106_vcf_process(&f,input,(uint16_t)((i*7919u)%16384u),(uint8_t)(i%128u));
        assert(out>-4000000&&out<4000000);
    }
    puts("PASS: 1000000 extreme-input/modulated-cutoff/resonance samples under UBSan");
    assert(energy);
    printf("PASS: 1048576 reduced-precision filter samples, 128 cutoff/resonance panels; mean abs difference %.3f (Q15), reference mean abs %.3f\n",(double)err/1048576,(double)energy/1048576);
    return 0;
}
