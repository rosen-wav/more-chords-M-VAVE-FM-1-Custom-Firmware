/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void original_chorus_test(void) {
 int16_t reference_ring[CHO_LEN];int32_t input[CTL],zero[CTL]={0},output[CTL];
 for(unsigned rate=0;rate<128;rate+=17)for(unsigned depth=0;depth<128;depth+=31) {
  memset(&fx,0,sizeof fx);memset(cho_buf,0,sizeof cho_buf);memset(dly_buf,0,sizeof dly_buf);
  memset(rev_comb,0,sizeof rev_comb);memset(&rev_u,0,sizeof rev_u);memset(reference_ring,0,sizeof reference_ring);
  song.g[G_CRATE]=rate;song.g[G_CDEPTH]=depth;song.g[G_DMIX]=0;song.g[G_RTYPE]=0;
  uint32_t wr=0,phase=0;
  for(unsigned block=0;block<128;block++) {
   for(unsigned i=0;i<CTL;i++)input[i]=(int32_t)((block*7919u+i*977u)%150001u)-75000;
   fx_buses(input,zero,zero,output,CTL);
   for(unsigned i=0;i<CTL;i++) {
    reference_ring[wr&(CHO_LEN-1)]=(int16_t)clamp(input[i]>>1,-32768,32767);
    phase+=LFO_INC[rate]/CTL;
    int32_t d=(400<<8)+((osc_sine(phase)+32768)*(int32_t)(depth*6)>>8);
    unsigned tap=(unsigned)d>>8;int32_t a=reference_ring[(wr-tap)&(CHO_LEN-1)],b=reference_ring[(wr-tap-1)&(CHO_LEN-1)];
    assert(output[i]==(a+(((b-a)*(d&255))>>8))*2);wr++;
   }
  }
 }
 assert(GP[G_CRATE].max==127 && GP[G_CRATE].def==40);
 puts("PASS: original chorus delay/interpolation PCM exact, 40 rate/depth panels and 163840 samples; original controls restored");
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);original_chorus_test();cu_collection_choice=1;
 unsigned cases=0;unsigned engines[]={ENGI_SWARM,ENGI_CLUSTER};
 for(unsigned ei=0;ei<2;ei++){
  unsigned e=engines[ei];assert(!cu_bass_engine_block(1,e));
  for(unsigned pi=0;pi<ENGINES[e]->npresets;pi++){
   cu_pool_load(0,e,pool_pos_factory(e,pi));unsigned n=cu_bass_count();
   cu_collection_toggle();assert(cu_bass_count()==n+1);cu_bass_go(n+1);
   assert(cs.bass_on && trk[1].eng_req==e && trk[1].p[P_VOICE]==V_MONO);
   for(unsigned j=0;j<8;j++)assert(trk[1].p[P_E0+j]==trk[0].p[P_E0+j]);
   cu_collection_toggle();assert(cu_bass_count()==n);cases++;
  }
  cu_pool_load(0,e,pool_pos_factory(e,1));
  if(e==ENGI_CLUSTER){trk[0].p[P_E0]=17408;trk[0].p[P_E1]=-20001;trk[0].p[P_E2]=23501;trk[0].p[P_E3]=12345;}
  assert(!cb_store(&trk[0],0,31,"BASS USER",0));
  cu_pool_load(0,e,pool_pos_slot(e,31));unsigned n=cu_bass_count();cu_collection_toggle();assert(cu_bass_count()==n+1);
  cu_bass_go(n+1);assert(trk[1].eng_req==e);
  for(unsigned j=0;j<8;j++)assert(trk[1].p[P_E0+j]==trk[0].p[P_E0+j]);
  assert(!cb_store(&trk[1],1,30,"BASS SAVED",0));
  cu_load_user(&trk[1],30,1);assert(trk[1].eng_req==e);
  for(unsigned j=0;j<8;j++)assert(trk[1].p[P_E0+j]==trk[0].p[P_E0+j]);
  cu_bass_go(n+1);cr_settings_save();cr_settings_load();
  assert(trk[1].eng_req==e); /* boot restores sound, intentionally Bass OFF */
  for(unsigned j=0;j<8;j++)assert(trk[1].p[P_E0+j]==trk[0].p[P_E0+j]);
  assert(crs_sound(1,(e<<8)|pool_pos_slot(e,31)));
  cu_init_load(1,e);assert(trk[1].eng_req==e);
  cu_load_user(&trk[1],31,1);assert(trk[1].eng_req==e);
  for(unsigned j=0;j<8;j++)assert(trk[1].p[P_E0+j]==trk[0].p[P_E0+j]);
  cu_engine_switch(1,e);assert(trk[1].eng_req==e);
  cu_collection_toggle();assert(cu_bass_count()==n);cases+=5;
 }
 unsigned before=trk[1].eng_req;cu_load(&trk[1],ENGI_CLOUD,0,1);assert(trk[1].eng_req==before);
 assert(cu_bass_engine_block(1,ENGI_CLOUD)&&!crs_sound(1,(ENGI_CLOUD<<8)|1));
 cu_pool_load(0,ENGI_CLOUD,pool_pos_factory(ENGI_CLOUD,0));unsigned n=cu_bass_count();cu_collection_toggle();assert(cu_bass_count()==n);
 assert(!eng_ok(ENGI_KR106)&&!eng_ok(ENGI_CS1));
 printf("PASS: %u SWARM/CLUSTER Bass factory/USER/raw16/load/init/settings/selection cases; CLOUD remains blocked; original chorus exact\n",cases);
}
