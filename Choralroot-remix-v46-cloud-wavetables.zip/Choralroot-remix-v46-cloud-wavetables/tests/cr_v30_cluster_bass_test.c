/* Bass coverage is shared for both engines. */
#include "cr_v30_bass_test.c"
