/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../build/gen/felucca_tables.h"
/* This fixture tests DSP only; concurrency has separate real worker tests. */
#define CR_CPU1 0
/* Mach-O has no firmware ELF sections; this is a host-only DSP fixture. */
#if defined(__APPLE__)
#define __attribute__(x)
#endif
#include "../firmware/src/core.h"
#if defined(__APPLE__)
#undef __attribute__
#endif
#include "../firmware/src/dsp.c"
static uint32_t cloud_cap(const track_t *t){(void)t;return 6;}
static uint32_t cloud_units(const track_t *t){(void)t;return 3;}
#include "../firmware/src/eng_swarm.c"
#include "../firmware/src/eng_cluster.c"
#ifndef V31_REFERENCE
static swarm_part_t swarm_arena[NPART];
static swarm_part_t *swarm_part(uint32_t p){return &swarm_arena[p%NPART];}
#endif
static cluster_part_t arena[NPART];
static cluster_part_t *cluster_part(uint32_t p){return &arena[p%NPART];}
int main(void){uint64_t energy=0;unsigned samples=0;
 for(unsigned engine=0;engine<2;engine++)for(unsigned preset=0;preset<(engine?16u:4u);preset++)for(unsigned stress=0;stress<3;stress++)for(unsigned note=0;note<128;note+=7){
  memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);track_t *t=&trk[0];voice_t *v=&t->v[0];
  const engine_t *e=engine?&ENG_CLUSTER:&ENG_SWARM;
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=e->presets[preset].e[j];
  if(engine)cluster_preset_to(t,preset);
  if(stress)for(unsigned j=0;j<8;j++)t->p[P_E0+j]=stress==1?e->edit[j].max:e->edit[j].min;
  v->active=v->gate=1;e->note_on(t,v);
  vmod_t m={0};m.inc=pitch_inc(note*16);m.envq15=32767;m.shape=stress==1?127*256:64*256;m.cutoff=stress==1?127*256:-127*256;m.amp0=m.amp1=32767;
  for(unsigned b=0;b<128;b++){
   int32_t out[CTL+2]={0};out[0]=123456789;out[CTL+1]=987654321;
   if(b==96)v->gate=0;
   e->render(t,v,out+1,CTL,&m);
   assert(out[0]==123456789&&out[CTL+1]==987654321);
   for(unsigned j=1;j<=CTL;j++){assert(llabs(out[j])<=60430);energy+=llabs(out[j]);}
   samples+=CTL;
  }
 }
 assert(energy);printf("PASS: %u Swarm/Cluster DSP samples under UBSan, all presets, extreme controls, MIDI notes 0..126, gates/releases and PCM bounds\n",samples);
 puts("PASS: lightweight Cluster factories/extremes checked under UBSan; native exact-PCM contract intentionally replaced by bounded lightweight synthesis");return 0;
}
