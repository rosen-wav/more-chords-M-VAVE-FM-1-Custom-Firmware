#include <pthread.h>
static int observe;static pthread_t worker_id;static unsigned observed[2][3];
static void observe_cloud(void *p);
#define CLOUD_RENDER_OBSERVER(t) observe_cloud(t)
#define SWARM_RENDER_OBSERVER(t) observe_cloud(t)
#define CLUSTER_RENDER_OBSERVER(t) observe_cloud(t)
#define CR_V8_HELPERS_ONLY
#include "cr_v8_audit_test.c"
#undef main
static void observe_cloud(void *p){if(!observe)return;track_t *t=p;unsigned cpu=pthread_equal(pthread_self(),worker_id)?1:0;
 assert(t>=trk&&t<trk+NPART);observed[cpu][t-trk]++;
 assert((t==&trk[0]&&!cpu)||((t==&trk[2]||t==&trk[1])&&cpu));
}
static void nudge_test(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_out_init();cu.armed=NB;
 unsigned bpm=cr.bpm,st=crl.state;int oct=cu.octave;
 /* A complete tap between audio blocks still has an effect. */
 cu_btn_press(BT_LOOP);cu_btn_press(B_OCTUP);cu_btn_release(B_OCTUP);cu_btn_release(BT_LOOP);
 assert(!cr_nudge_request);for(unsigned i=0;i<100;i++)cr_audio_block(CTL);
 assert(cr_nudge_phase_samples==(int32_t)(FS/500u)&&!cr_nudge_debt);
 assert(cr.bpm==bpm&&crl.state==st&&cu.octave==oct);
 int32_t phase=cr_nudge_phase_samples;
 for(unsigned i=0;i<100;i++)cr_audio_block(CTL);assert(cr_nudge_phase_samples==phase);
 cu_btn_press(BT_LOOP);cu_btn_press(B_OCTDN);cu_btn_release(BT_LOOP);cu_btn_release(B_OCTDN);
 for(unsigned i=0;i<100;i++)cr_audio_block(CTL);assert(!cr_nudge_phase_samples&&!cr_nudge_request&&cu.octave==oct);
 /* Immediate hold is15%, long hold reaches25%. */
 cu_btn_press(BT_LOOP);cu_btn_press(B_OCTUP);
 for(unsigned i=0;i<100;i++)cr_audio_block(CTL);
 assert(cr_nudge_phase_samples==(int32_t)(FS/500u+CTL*15u));
 for(unsigned i=0;i<1500;i++)cr_audio_block(CTL);
 phase=cr_nudge_phase_samples;for(unsigned i=0;i<100;i++)cr_audio_block(CTL);
 assert(cr_nudge_phase_samples-phase==(int32_t)(CTL*25u));
 cu_btn_release(B_OCTUP);cu_btn_release(BT_LOOP);assert(!cr_nudge_request&&cu.octave==oct&&cr.bpm==bpm);
 /* No clock rewind even during the initial backwards impulse. */
 cr_out_init();cu.armed=NB;cu_btn_press(BT_LOOP);cu_btn_press(B_OCTDN);
 uint32_t prev=cr_now_ms;for(unsigned i=0;i<2000;i++){cr_audio_block(CTL);assert(cr_now_ms>=prev);prev=cr_now_ms;}
 assert(cr_nudge_phase_samples<0&&cr.bpm==bpm);cu_btn_release(BT_LOOP);cu_btn_release(B_OCTDN);
 for(unsigned i=0;i<20;i++)cr_audio_block(CTL);assert(!cr_nudge_debt&&!cr_nudge_request);
 /* Queue saturation cannot lose the UI release. */
 cu_btn_press(BT_LOOP);cu_btn_press(B_OCTUP);while(cr_post(CRE_LOOP,LP_CONF,LC_VOL,70));
 cu_btn_release(B_OCTUP);cu_btn_release(BT_LOOP);cr_audio_block(CTL);assert(!cr_nudge_request);
 cr_route.clock_in=1;cr_audio_block(CTL);cu_btn_press(BT_LOOP);cu_btn_press(B_OCTUP);
 for(unsigned i=0;i<100;i++)cr_audio_block(CTL);assert(cr_nudge_phase_samples>0&&cr.bpm==bpm&&cr_nudge_external_phase()>0);
 cu_btn_release(BT_LOOP);cu_btn_release(B_OCTUP);assert(!cr_nudge_request);
 cr_route.clock_in=0;cr_audio_block(CTL);crl.d.len=CRL_PPQN*4u;crl.d.nev=0;crl.state=CRL_PLAYING;
 crl.cyc0=crl.t;crl.scan=0;crl_data_t data=crl.d;uint32_t before=crl.t;
 cu_btn_press(BT_LOOP);cu_btn_press(B_OCTUP);for(unsigned i=0;i<1000;i++)cr_audio_block(CTL);
 cu_btn_release(B_OCTUP);cu_btn_release(BT_LOOP);cr_audio_block(CTL);
 assert(crl.state==CRL_PLAYING&&crl.t>before&&cr.bpm==bpm&&!memcmp(&data,&crl.d,sizeof data));
 puts("PASS: improved nudge: captured 2ms taps, immediate 15/25% hold, monotonic backwards bend, retained phase, safe release/full queue, external phase and playing-loop integrity");
}

int main(int argc,char **argv){
 nudge_test();unsigned wanted=argc>1&&!strcmp(argv[1],"cloud")?ENGI_CLOUD:argc>1&&!strcmp(argv[1],"cluster")?ENGI_CLUSTER:ENGI_SWARM;
 unsigned src=0;while(src<NELEM(MORPH_SOURCE)&&MORPH_SOURCE[src]!=wanted)src++;assert(src<NELEM(MORPH_SOURCE));
 unsigned presets=ENGINES[MORPH_SOURCE[src]]->npresets;
 pthread_t th;assert(!pthread_create(&th,0,worker,0));worker_id=th;
 while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_QUAD,ENGI_VA,ENGI_CZ,ENGI_PROPHET,ENGI_SWARM,ENGI_CLUSTER};
 unsigned cases=0;
 for(unsigned pa=0;pa<presets;pa++)for(unsigned bi=0;bi<NELEM(basses);bi++){
  cr_c1_test_serial=1;init_morph(src,basses[bi]);trk[0].p[P_E1]=pa;trk[0].p[P_E7]=((pa+1)%presets)|0x1200;morph_sync(&trk[0]);
  for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],48+i*3,100);
  for(unsigned k=0;k<160;k++)render_morph(k,ref[k]);memcpy(states,eng_state,sizeof states);
  cr_c1_test_serial=0;init_morph(src,basses[bi]);trk[0].p[P_E1]=pa;trk[0].p[P_E7]=((pa+1)%presets)|0x1200;morph_sync(&trk[0]);
  for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],48+i*3,100);
  assert(trk_nvoice(&trk[0])==6&&trk_nvoice(&trk[2])==6);
  observe=1;
  for(unsigned k=0;k<160;k++){render_morph(k,pcm);assert(!memcmp(pcm,ref[k],sizeof pcm));assert(!c1_chord_split);}
  observe=0;assert(!memcmp(states,eng_state,sizeof states));cases++;
 }
 /* Generated six-tone chords and repeated overlaps reach both patch banks. */
 for(unsigned pa=0;pa<presets;pa++){
  cr_c1_test_serial=0;init_morph(src,ENGI_BASS);trk_all_off(&trk[0]);cr_panic(&cr);panic_req=0;
  cr_set_bass(&cr,1);cr_set_stream(&cr,CR_STREAM_BASS,1);
  voice_chord_rank=cr_synth_chord_rank;
  cr_mod(&cr,CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
  for(unsigned step=0;step<4;step++){
   cr_key(&cr,48+step,100,1);
   for(unsigned k=0;k<16;k++){cr_audio_block(CTL);for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);}
   const cr_voice_t *newest=0;
   for(unsigned v=0;v<CR_NVOICE;v++)if(cr.v[v].used&&cr.v[v].rq&&(!newest||cr.v[v].serial>newest->serial))newest=&cr.v[v];
   assert(newest&&newest->nnotes==6);
   for(unsigned j=0;j<6;j++)for(unsigned part=0;part<3;part+=2){unsigned found=0;
    for(unsigned v=0;v<NVOICE;v++)found|=trk[part].v[v].active&&trk[part].v[v].gate&&trk[part].v[v].note==cr_tr_note(0,newest->notes[j]);
    assert(found);
   }
  }
 }
 puts("PASS: Cloud/Swarm/Cluster Morph overlapping generated six-tone chords reach A and B banks");
 assert(observed[0][0]&&observed[1][2]&&!observed[0][2]&&!observed[1][0]);
 pthread_cancel(th);pthread_join(th,0);audio_worker_online=0;
 /* Standalone Cloud continues to expose six voices only with its normal split. */
 cu_load(&trk[0],ENGI_CLOUD,0,0);for(unsigned i=0;i<200;i++){engine_block(&trk[0]);mix_block(pcm,CTL);}assert(cloud_units(&trk[0])==3);
 printf("PASS: Cloud/Swarm/Cluster Morph %u A/B+Bass fixtures: 6+6 voices, exact serial/CPU1 PCM/state, actual thread ownership, standalone cost unchanged\n",cases);

 return 0;
}
