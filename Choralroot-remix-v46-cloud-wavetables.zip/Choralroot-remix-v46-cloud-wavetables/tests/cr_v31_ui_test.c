/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static void dump(const cr_screen_t *s,const char *dir,unsigned index){char b[512];snprintf(b,sizeof b,"%s/screen-%u.bin",dir,index);FILE *f=fopen(b,"wb");assert(f);assert(fwrite(s,sizeof *s,1,f)==1);fclose(f);}
int main(int argc,char **argv){assert(argc==2);emu_fw_options(0,1,0,1);emu_fw_init(0);cr_screen_t s;
 for(unsigned e=0;e<2;e++){
  const engine_t *eng=e?&ENG_CLUSTER:&ENG_SWARM;
  cu_load(&trk[0],e?ENGI_CLUSTER:ENGI_SWARM,0,0);engine_block(&trk[0]);ce_open(0);
  for(unsigned group=0;group<2;group++){
   cu_load(&trk[0],e?ENGI_CLUSTER:ENGI_SWARM,0,0);engine_block(&trk[0]);
   ce_group(group?CE_FILT:CE_OSC);int16_t before[8];memcpy(before,&trk[0].p[P_E0],sizeof before);
   cr_build_screen(&s,cu_now());assert(s.wide==(e?CR_W_CLUSTER:CR_W_SWARM)&&s.n_rows==1);assert(!memcmp(before,&trk[0].p[P_E0],sizeof before));
   dump(&s,argv[1],e*6+group*3);
   for(unsigned edge=0;edge<2;edge++){
    for(unsigned j=0;j<5;j++)trk[0].p[P_E0+j]=edge?eng->edit[j].max:eng->edit[j].min;
    cr_build_screen(&s,cu_now());dump(&s,argv[1],e*6+group*3+edge+1);
   }
   for(unsigned j=0;j<(e||!group?4u:1u);j++){
    unsigned idx=e||!group?j:4;trk[0].p[P_E0+idx]=eng->edit[idx].min;
    ce_knob(j,1,0);assert(trk[0].p[P_E0+idx]>eng->edit[idx].min);
   }
  }
  if(e){
   ce_group(CE_OSC);
   for(unsigned count=1;count<=8;count++){
    trk[0].p[P_E0]=(int16_t)(count*2048);cr_build_screen(&s,cu_now());
    assert(s.wv[4]==(count>6?6:count));
   }
   ce_knob(0,1,0);assert((trk[0].p[P_E0]>>11)==6);
   ce_knob(0,-1,0);assert((trk[0].p[P_E0]>>11)==5);
  }
  ce_close();
 }
 puts("PASS: SWARM/CLUSTER real UI, all visible knob mappings, raw parameters preserved during display");return 0;
}
