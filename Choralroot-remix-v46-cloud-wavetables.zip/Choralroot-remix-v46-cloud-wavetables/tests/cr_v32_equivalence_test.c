/* Compare optimized DSP against V31 with two CLOUD grains and the requested per-engine output scales.
 * References are frozen V31 sources, not generated expected PCM. */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../build/gen/felucca_tables.h"
#define CR_CPU1 0
#if defined(__APPLE__)
#define __attribute__(x)
#endif
#include "../firmware/src/core.h"
#if defined(__APPLE__)
#undef __attribute__
#endif
#include "../firmware/src/dsp.c"

#ifdef V31_REFERENCE
#undef VOICE_FS
#define VOICE_FS 24000
static int32_t reference_level=24000;
static int32_t reference_amp(int32_t x,const vmod_t *m,unsigned i){return mulq15(mulq15(x,amp_at(m,i)),reference_level);}
#define voice_amp reference_amp
#include "reference-v31/eng_cloud.c"
#include "reference-v31/eng_swarm.c"
#include "reference-v31/eng_cluster.c"
#else
#include "../firmware/src/eng_cloud.c"
#include "../firmware/src/eng_swarm.c"
#include "../firmware/src/eng_cluster.c"
#endif
#ifndef V31_REFERENCE
static swarm_part_t swarm_arena[NPART];
static swarm_part_t *swarm_part(uint32_t p){return &swarm_arena[p%NPART];}
#endif
static cloud_part_t ca[NPART];static cluster_part_t cl[NPART];
static cloud_part_t *cloud_part(uint32_t p){return &ca[p%NPART];}
static cluster_part_t *cluster_part(uint32_t p){return &cl[p%NPART];}
static uint64_t hash=1469598103934665603ull;
static void fold(const void *p,size_t n){const unsigned char *s=p;while(n--){hash^=*s++;hash*=1099511628211ull;}}
int main(void){unsigned samples=0;
 const engine_t *engs[]={&ENG_CLOUD,&ENG_SWARM,&ENG_CLUSTER};
 for(unsigned e=0;e<2;e++)for(unsigned preset=0;preset<engs[e]->npresets;preset++)for(unsigned mode=0;mode<2;mode++)for(unsigned note=0;note<128;note+=11){
  memset(trk,0,sizeof trk);memset(ca,0,sizeof ca);memset(cl,0,sizeof cl);
#ifdef V31_REFERENCE
  reference_level=e==2?12028:24000;
#endif
  track_t *t=&trk[mode%NPART];voice_t *v=&t->v[mode%NVOICE];const engine_t *en=engs[e];
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=en->presets[preset].e[j];if(e==2)cluster_preset_to(t,preset);
  if(mode)for(unsigned j=0;j<8;j++)t->p[P_E0+j]=mode==1?en->edit[j].max:en->edit[j].min;
  v->active=v->gate=1;en->note_on(t,v);
  for(unsigned b=0;b<160;b++){
   vmod_t m={0};m.inc=pitch_inc(note*16+(b/32));m.envq15=32767-(b%32)*900;m.shape=(b%128)*256;m.cutoff=((int)b-80)*256;
   m.amp0=1000+(b*193)%31767;m.amp1=1000+(b*997)%31767;
   if(b==120)v->gate=0;
   unsigned n=b%9==0?7:CTL;int32_t out[CTL+2]={0};out[0]=123456789;out[n+1]=987654321;
   en->render(t,v,out+1,n,&m);assert(out[0]==123456789&&out[n+1]==987654321);
   for(unsigned i=1;i<=n;i++)assert(llabs(out[i])<=(e?60430:120860));
   fold(out+1,n*sizeof out[0]);samples+=n;
  }
  fold(v,sizeof *v);
  for(unsigned p=0;p<NPART;p++)for(unsigned j=0;j<NVOICE;j++){
    fold(ca[p].voice[j].g,sizeof ca[p].voice[j].g);fold(&ca[p].voice[j].rng,sizeof ca[p].voice[j].rng);
    fold(&cl[p].note[j].state,sizeof cl[p].note[j].state);fold(&cl[p].note[j].global,sizeof cl[p].note[j].global);
    fold(cl[p].note[j].pcm,sizeof cl[p].note[j].pcm);fold(&cl[p].note[j].cursor,sizeof cl[p].note[j].cursor);
  }
 }
 printf("%u samples PCM+native-state hash %016llx\n",samples,(unsigned long long)hash);
}
