/* Real engine adapter retriggers must anchor to last PCM, add over other voices,
 * finish after exactly128 samples and leave un-retriggered audio unmodified. */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);
 unsigned engines[]={ENGI_CLOUD,ENGI_SWARM,ENGI_CLUSTER},cases=0;
 for(unsigned e=0;e<3;e++)for(unsigned part=0;part<NPART;part++){
  memset(eng_state,0,sizeof eng_state);memset(trk,0,sizeof trk);
  track_t *t=&trk[part];voice_t *v=&t->v[0];cu_load(t,engines[e],0,part==1);t->engine=t->eng_req;
  const engine_t *en=ENGINES[engines[e]];v->active=v->gate=1;voice_was=0;en->note_on(t,v);
  orbit_bridge_t *b=e==0?&cloud_state(t,v)->bridge:e==1?&swarm_part(part)->voice[0]:&cluster_part(part)->note[0].bridge;
  vmod_t m={0};m.inc=pitch_inc(60*16);m.amp0=m.amp1=m.envq15=32767;m.shape=64*256;
  for(unsigned k=0;k<32;k++){int32_t out[CTL]={0};en->render(t,v,out,CTL,&m);}
  int32_t previous=b->last;voice_was=2;en->note_on(t,v);assert(b->pending);
  m.inc=pitch_inc(73*16);
  for(unsigned k=0;k<128;k+=CTL){
   int32_t out[CTL];for(unsigned i=0;i<CTL;i++)out[i]=12345;
   en->render(t,v,out,CTL,&m);if(!k)assert(out[0]-12345==previous);
   assert(b->last==out[CTL-1]-12345);assert(b->left==128-k-CTL);
  }
  assert(!b->pending&&!b->left&&!b->offset);
  /* Released voice reuse and another retrigger during its correction. */
  voice_was=1;en->note_on(t,v);int32_t out[CTL]={0};previous=b->last;en->render(t,v,out,CTL,&m);assert(out[0]==previous&&b->left==128-CTL);
  voice_was=2;en->note_on(t,v);previous=b->last;memset(out,0,sizeof out);en->render(t,v,out,CTL,&m);assert(out[0]==previous&&b->left==128-CTL);
  voice_was=0;en->note_on(t,v);assert(!b->pending&&!b->left&&!b->last&&!b->offset);cases++;
 }
 /* Irregular block sizes preserve the128-sample correction endpoint. */
 orbit_bridge_t b={.last=7000,.pending=1};unsigned elapsed=0;
 while(elapsed<145){unsigned n=elapsed%7+1;int32_t out[8];for(unsigned i=0;i<n;i++)out[i]=1000;
  orbit_bridge_apply(&b,out,n,1000,1000);elapsed+=n;assert(b.left==(elapsed<128?128-elapsed:0));assert(b.last==out[n-1]-1000);
 }
 assert(!b.left&&!b.offset);printf("PASS: %u real CLOUD/SWARM/CLUSTER retrigger adapters, chords/Bass/Morph banks, exact128-sample bridge, additive mix, rapid/released reuse and fresh reset\n",cases);
}
