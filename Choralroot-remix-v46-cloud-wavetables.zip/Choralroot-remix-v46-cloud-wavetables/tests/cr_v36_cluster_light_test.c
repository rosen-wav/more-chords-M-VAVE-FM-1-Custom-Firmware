/* Compare saturation incidence and host cost against the retained native core.
 * Sound intentionally differs: signal bounds and no clipping, not native equality. */
#define main stress_main
#include "cr_v30_dsp_test.c"
#undef main
#include <time.h>
int main(void){
 uint64_t oldclip=0,newclip=0,samples=0;clock_t oldticks=0,newticks=0;
 for(unsigned preset=0;preset<16;preset++)for(unsigned note=36;note<=84;note+=12){
  memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);track_t *t=&trk[0];voice_t *v=&t->v[0];v->gate=1;voice_was=0;
  cluster_preset_to(t,preset);cluster_note_on(t,v);cluster_note_t *s=&arena[0].note[0];
  cls_voice oldv=s->state;cls_global oldg=s->global;uint32_t inc=pitch_inc(note*16);int16_t pcm[128];
  for(unsigned block=0;block<256;block++){
   if(block && block%31u==0)t->p[P_E0]=(int16_t)((block/31u%8u+1u)*2048u);
   if(block && block%64u==0){t->p[P_E1]=block&64u?32767:-32768;t->p[P_E3]=block&64u?-32768:32767;t->p[P_E2]=(int16_t)((block/64u*7u%24u)*1024u);}
   clock_t a=clock();cls_render_constant(&oldv,&oldg,&OP1_CLUSTER_TABLES,pcm,inc,&t->p[P_E0]);oldticks+=clock()-a;
   a=clock();cluster_light_kernel(s,inc,&t->p[P_E0]);newticks+=clock()-a;
   int32_t sum=0;for(unsigned j=0;j<7;j++)sum+=s->global.gain[j];assert(sum<=16384);
   for(unsigned i=0;i<128;i++){
    oldclip+=pcm[i]==32767||pcm[i]==-32768;
    newclip+=s->pcm[i]==32767||s->pcm[i]==-32768;
    assert(s->pcm[i]>=-16384&&s->pcm[i]<=16383);samples++;
   }
  }
 }
 assert(!newclip);printf("PASS: %llu CLUSTER kernel samples; native saturated endpoints %llu, light %llu; normalized gain bound across16 factories/5 pitches and live COUNT/wave/spread/curve changes\n",(unsigned long long)samples,(unsigned long long)oldclip,(unsigned long long)newclip);
 printf("Host CPU ticks only (not FM1): native %ld, light %ld\n",(long)oldticks,(long)newticks);
 return stress_main();
}
