#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(int argc,char **argv){
 emu_fw_options(0,1,0,1);emu_fw_init(0);assert(UP_SLOTS==64);
 if(argc>1){printf("[");for(unsigned i=0;i<P_E0;i++)printf("%s[%d,%d,%d]",i?",":"",TP[i].min,TP[i].max,TP[i].def);puts("]");return 0;}
 unsigned engs[]={ENGI_VA,ENGI_FM6,ENGI_CZ,ENGI_QUAD,ENGI_PROPHET,ENGI_CLUSTER,ENGI_SWARM,ENGI_CLOUD,ENGI_MORPH};
 up_rec_t expected[64];uint8_t blobs[32][144],lens[32];
 for(unsigned k=0;k<64;k++){
  unsigned e=engs[k%NELEM(engs)];cu_load(&trk[0],e,0,0);engine_block(&trk[0]);
  char name[13];snprintf(name,sizeof name,"SLOT %02u",k+1);
  assert(cb_store(&trk[0],0,k,name,0)==0);assert(up_used(k));expected[k]=*up_rec(k);
  if(k>=32){lens[k-32]=upx_len[k-32];memcpy(blobs[k-32],upx_aux[k-32],144);assert(favorite_set(ENG_USER_REF,k,1));assert(favorite_has(ENG_USER_REF,k));}
 }
 assert(up_count()==64&&cb_free_slot()==64);
 st_ext_ready=0;up_boot();
 for(unsigned k=0;k<64;k++){
  assert(up_used(k));for(unsigned i=0;i<P_COUNT;i++)assert(up_value(up_rec(k),i)==up_value(&expected[k],i));
  assert(!memcmp(up_rec(k)->name,expected[k].name,12));
  if(up_p5_has(&expected[k]))assert(!memcmp(up_rec(k)->packed+91,expected[k].packed+91,53));
  if(k>=32){assert(upx_len[k-32]==lens[k-32]);assert(!memcmp(upx_aux[k-32],blobs[k-32],lens[k-32]));assert(favorite_has(ENG_USER_REF,k));}
  cu_load_user(&trk[0],k,0);engine_block(&trk[0]);assert(trk[0].eng_req==expected[k].engine);
 }
 for(unsigned j=0;j<48;j++){unsigned k=32+j%32;assert(!cb_store(&trk[0],0,k,"ROTATE",0));st_ext_ready=0;upx_boot();assert(up_used(k));}
 assert(up_put(63,0)==0&&!up_used(63)&&!favorite_has(ENG_USER_REF,63));
 st_ext_ready=0;upx_boot();assert(!up_used(63));for(unsigned k=0;k<32;k++)assert(!memcmp(up_rec(k),&expected[k],sizeof(up_rec_t)));
 puts("PASS:64 USER slots,9 engines, all native blobs/Prophet tails/raw Cluster values, reboot,48 journal rotations, high favourites, delete, original32 preserved");
}
