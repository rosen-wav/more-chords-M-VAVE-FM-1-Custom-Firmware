/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../build/gen/felucca_tables.h"
/* This fixture tests DSP only; concurrency has separate real worker tests. */
#define CR_CPU1 0
/* Mach-O has no firmware ELF sections; this is a host-only DSP fixture. */
#if defined(__APPLE__)
#define __attribute__(x)
#endif
#include "../firmware/src/core.h"
#if defined(__APPLE__)
#undef __attribute__
#endif
#include "../firmware/src/dsp.c"
#include "../firmware/src/eng_cloud.c"
static cloud_part_t arena[NPART];
static cloud_part_t *cloud_part(uint32_t p){return &arena[p%NPART];}

#include "../firmware/src/eng_novel.c"
static novel_part_t n_arena[NPART];
static novel_part_t *novel_part(uint32_t p){return &n_arena[p%NPART];}
int main(void){uint64_t energy=0;unsigned samples=0;
 const engine_t *engines[]={&ENG_DRIFT,&ENG_TERRAIN};
 for(unsigned e=0;e<2;e++)for(unsigned pi=0;pi<engines[e]->npresets;pi++)for(unsigned stress=0;stress<257;stress++)for(unsigned note=0;note<128;note++){
  memset(trk,0,sizeof trk);memset(n_arena,0,sizeof n_arena);track_t *t=&trk[0];voice_t *v=&t->v[0];
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=stress?(((stress-1u)&(1u<<j))?engines[e]->edit[j].max:engines[e]->edit[j].min):engines[e]->presets[pi].e[j];
  vmod_t m={0};m.inc=pitch_inc(note*16);m.cutoff=stress==1?127*256:-127*256;m.amp0=m.amp1=32767;v->active=1;
  voice_was=0;novel_note(t,v);unsigned audible=0;
  for(unsigned b=0;b<12;b++){
   int32_t out[CTL+2]={0};out[0]=123456789;out[CTL+1]=987654321;
   if(b==40){voice_was=1;novel_note(t,v);}
   engines[e]->render(t,v,out+1,CTL,&m);assert(out[0]==123456789&&out[CTL+1]==987654321);
   for(unsigned j=1;j<=CTL;j++){if(llabs(out[j])>=262144){fprintf(stderr,"bound e=%u preset=%u stress=%u note=%u block=%u i=%u out=%d\n",e,pi,stress,note,b,j,out[j]);abort();}energy+=llabs(out[j]);audible+=out[j]!=0;samples++;}
  }
  assert(audible);
 }
 for(unsigned e=0;e<2;e++){
  memset(trk,0,sizeof trk);memset(n_arena,0,sizeof n_arena);track_t *t=&trk[0];voice_t *v=&t->v[0];
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=engines[e]->presets[0].e[j];t->p[P_E1]=127;t->p[P_E2]=127;t->p[P_E3]=127;
  vmod_t m={0};m.inc=pitch_inc(48*16);m.amp0=m.amp1=32767;voice_was=0;novel_note(t,v);
  n_arena[0].voice[0].age=UINT32_MAX-500u;for(unsigned k=0;k<5;k++)n_arena[0].voice[0].deadline[k]=UINT32_MAX-501u;
  for(unsigned b=0;b<30000;b++){int32_t pcm[CTL]={0};engines[e]->render(t,v,pcm,CTL,&m);for(unsigned i=0;i<CTL;i++){assert(llabs(pcm[i])<262144);samples++;}}
 }
 assert(energy);printf("PASS: %u integer DSP samples, every MIDI note/factory/all 256 panel corners, steals, 21-second slow motion/age wrap, PCM guards, UBSan\n",samples);
}