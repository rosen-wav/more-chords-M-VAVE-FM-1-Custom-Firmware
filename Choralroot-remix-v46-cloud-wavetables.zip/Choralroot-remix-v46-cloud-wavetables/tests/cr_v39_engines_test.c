/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);assert(NENGINES==28);assert(!eng_ok(ENGI_GFORM));for(unsigned i=0;i<NENG_SHOWN;i++)assert(eng_vis(i)!=ENGI_GFORM);for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)assert(MORPH_SOURCE[i]!=ENGI_GFORM);
 pthread_t th;assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_QUAD,ENGI_VA,ENGI_PROPHET};unsigned cases=0;
 for(unsigned e=ENGI_DRIFT;e<=ENGI_TERRAIN;e++){
  assert(eng_ok(e)&&eng_vis(eng_rank(e))==e);unsigned np=ENGINES[e]->npresets;
  for(unsigned pi=0;pi<np;pi++)for(unsigned b=0;b<NELEM(basses);b++){
   cr_c1_test_serial=1;setup(e,pi,basses[b],0,6,b%4);
   for(unsigned k=0;k<128;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);
   cr_c1_test_serial=0;setup(e,pi,basses[b],0,6,b%4);assert(trk_nvoice(&trk[0])==6);
   int32_t pcm[2*CTL];uint64_t energy=0;
   for(unsigned k=0;k<128;k++){block(k,pcm);assert(!memcmp(pcm,reference[k],sizeof pcm));if(k==10)assert(c1_chord_split&&c1_chord_count==2);for(unsigned j=0;j<2*CTL;j++)energy+=llabs(pcm[j]);}
   assert(energy>1000);assert(!memcmp(states,eng_state,sizeof states));cases++;
  }
  for(unsigned pi=0;pi<np;pi++){
   setup(e,pi,ENGI_BASS,0,6,0);assert(!cb_store(&trk[0],0,31,"NEW ENGINE",0));int16_t p[8];memcpy(p,trk[0].p+P_E0,sizeof p);cu_load_user(&trk[0],31,0);engine_block(&trk[0]);assert(trk[0].eng_req==e);assert(!memcmp(p,trk[0].p+P_E0,sizeof p));
  }
  cu_load(&trk[0],e,0,0);engine_block(&trk[0]);ce_open(0);ce_group(CE_OSC);
  cr_screen_t screen;cr_build_screen(&screen,cu_now());
  for(unsigned j=0;j<4;j++){int before=trk[0].p[P_E0+j];assert(screen.cell[0][j].label[0]);ce_knob(j,1,0);assert(trk[0].p[P_E0+j]>before);}
  ce_close();
  trk[0].p[P_REL]=0;trk_all_off(&trk[0]);
  for(unsigned k=0;k<2000;k++){int32_t tmp[2*CTL];engine_block(&trk[0]);mix_block(tmp,CTL);}
  for(unsigned j=0;j<NVOICE;j++)assert(!trk[0].v[j].active);
  printf("PASS: %s factories, six voices 4+2, native USER and exact serial/worker PCM+state\n",ENGINES[e]->name);
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: %u new-engine CPU fixtures; voice state %zu bytes, arena %zu bytes\n",cases,sizeof(novel_voice_t),sizeof(novel_part_t));
}
