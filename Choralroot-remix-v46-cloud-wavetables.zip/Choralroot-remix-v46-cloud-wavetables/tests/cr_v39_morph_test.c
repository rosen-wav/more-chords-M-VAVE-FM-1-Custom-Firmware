#define CR_V8_HELPERS_ONLY
#include "cr_v8_audit_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);pthread_t th;assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned cases=0;
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++){
  if(!eng_novel(MORPH_SOURCE[src]))continue;
  for(unsigned b=0;b<3;b++){
   unsigned bass=b==0?ENGI_BASS:b==1?ENGI_FM6:ENGI_QUAD;
   cr_c1_test_serial=1;init_morph(src,bass);for(unsigned k=0;k<160;k++)render_morph(k,ref[k]);memcpy(states,eng_state,sizeof states);
   cr_c1_test_serial=0;init_morph(src,bass);for(unsigned k=0;k<160;k++){render_morph(k,pcm);assert(!memcmp(pcm,ref[k],sizeof pcm));assert(!c1_chord_split);}assert(!memcmp(states,eng_state,sizeof states));cases++;
  }
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: %u new-engine Morph 6+6+Bass exact serial/worker PCM+state fixtures\n",cases);
}
