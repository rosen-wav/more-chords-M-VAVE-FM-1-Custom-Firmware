/* SPDX-License-Identifier: GPL-3.0-only */
#define main legacy_draw_main
#include "cr_draw_test.c"
#undef main
#include <assert.h>
static cr_screen_t frames[16];static uint16_t expected[240*240];
int main(int argc,char **argv){assert(argc==2);palette_set(mod_index());rep=stderr;
 for(unsigned k=0;k<16;k++){char path[512],name[32];snprintf(path,sizeof path,"%s/screen-%u.bin",argv[1],k);FILE *f=fopen(path,"rb");assert(f);assert(fread(&frames[k],sizeof frames[k],1,f)==1);fclose(f);render(&frames[k],0);snprintf(name,sizeof name,"novel-%u",k);lint(name,&frames[k]);write_ppm(argv[1],name);assert(!nfind&&!nfail);
  unsigned lit=0;
  /* Antialiased strokes blend with the theme: count chromatic pixels. */
  for(unsigned y=50;y<156;y++)for(unsigned x=10;x<230;x++){
   unsigned c=swap16(host_screen[y*240+x]),r=(c>>11)*255/31,g=((c>>5)&63)*255/63,b=(c&31)*255/31;
   unsigned hi=r>g?r:g;hi=hi>b?hi:b;unsigned lo=r<g?r:g;lo=lo<b?lo:b;
   lit+=hi-lo>25;
  }
  assert(lit>20);
  cr_draw(&frames[k],0);assert(!cr_dc.blits);
 }
 for(unsigned a=0;a<16;a++)for(unsigned b=0;b<16;b++){
  render(&frames[b],0);memcpy(expected,host_screen,sizeof expected);
  render(&frames[a],0);cr_draw(&frames[b],0);assert(!memcmp(expected,host_screen,sizeof expected));
 }
 puts("PASS: DRIFT/TERRAIN OSC+SEL sixteen real screen states, text bounds/overlap, 256 cached/full redraw comparisons, unchanged screen bypass");return 0;
}
