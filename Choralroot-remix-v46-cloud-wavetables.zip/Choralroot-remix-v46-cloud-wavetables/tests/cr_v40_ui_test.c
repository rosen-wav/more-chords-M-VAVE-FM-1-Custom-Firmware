#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"

#ifndef UI_ENTRY
#define UI_ENTRY main
#endif
int UI_ENTRY(int argc,char **argv){assert(argc==2);emu_fw_options(0,1,0,1);emu_fw_init(0);
 unsigned index=0;
 for(unsigned e=ENGI_DRIFT;e<=ENGI_TERRAIN;e++){
  cu_load(&trk[0],e,0,0);engine_block(&trk[0]);ce_open(0);ce_group(CE_OSC);
  for(unsigned page=0;page<2;page++){ce_group(page?CE_FILT:CE_OSC);
  for(unsigned mode=0;mode<4;mode++){
   if(mode)for(unsigned j=0;j<4;j++)trk[0].p[P_E0+page*4+j]=mode==1?ENGINES[e]->edit[j+page*4].min:mode==2?ENGINES[e]->edit[j+page*4].max:(ENGINES[e]->edit[j+page*4].max/2);
   cr_screen_t s;cr_build_screen(&s,cu_now());assert(s.wide==(page?CR_W_DRIFT_SEL:CR_W_DRIFT)+e-ENGI_DRIFT&&s.n_rows==1);
   for(unsigned j=0;j<4;j++)assert(s.wv[j]==trk[0].p[P_E0+page*4+j]+(page&&ENGINES[e]->edit[j+4].min<0?64:0)&&s.cell[0][j].label[0]);
   char path[512];snprintf(path,sizeof path,"%s/screen-%u.bin",argv[1],index++);FILE *f=fopen(path,"wb");assert(f);assert(fwrite(&s,sizeof s,1,f)==1);fclose(f);
  }
  }
  ce_close();
 }
 puts("PASS: 16 real new-engine UI states, all four control bindings and wide-band snapshots");return 0;
}
