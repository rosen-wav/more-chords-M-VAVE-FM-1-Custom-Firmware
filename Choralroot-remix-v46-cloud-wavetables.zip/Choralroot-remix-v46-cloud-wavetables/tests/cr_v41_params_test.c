#define main legacy_dsp_main
#include "cr_v39_dsp_test.c"
#undef main
static int32_t base[4096],other[4096];
static void capture(unsigned e,unsigned control,int value,int32_t *pcm){
 const engine_t *en=e?&ENG_TERRAIN:&ENG_DRIFT;
 memset(trk,0,sizeof trk);memset(n_arena,0,sizeof n_arena);track_t *t=&trk[0];voice_t *v=&t->v[0];
 for(unsigned j=0;j<8;j++)t->p[P_E0+j]=en->presets[0].e[j];
 t->p[P_E0+control]=value;
 vmod_t m={0};m.inc=pitch_inc(60*16);m.amp0=m.amp1=32767;voice_was=0;novel_note(t,v);
 for(unsigned b=0;b<4096/CTL;b++){memset(pcm+b*CTL,0,CTL*sizeof *pcm);en->render(t,v,pcm+b*CTL,CTL,&m);}
}
int main(void){for(unsigned e=0;e<2;e++)for(unsigned j=4;j<8;j++){
 capture(e,j,0,base);capture(e,j,63,other);
 assert(memcmp(base,other,sizeof base));
 }puts("PASS: all eight SEL controls alter deterministic PCM");}
