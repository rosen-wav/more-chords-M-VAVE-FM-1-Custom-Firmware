/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static void tick(void){cr_audio_block(CTL);int32_t pcm[2*CTL];for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);}
static const cr_voice_t *newest(void){const cr_voice_t *v=0;for(unsigned i=0;i<CR_NVOICE;i++)if(cr.v[i].used&&cr.v[i].rq&&(!v||(int32_t)(cr.v[i].serial-v->serial)>0))v=&cr.v[i];return v;}
static void check(unsigned eng){
 emu_fw_options(0,1,0,1);emu_fw_init(0);pthread_t th;
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned cases=0;
 for(unsigned preset=0;preset<ENGINES[eng]->npresets;preset++)for(int rotation=-3;rotation<=5;rotation+=4)for(unsigned minor=0;minor<2;minor++){
  setup(eng,preset,ENGI_BASS,0,0,0);cr_set_bass(&cr,1);cr_set_stream(&cr,CR_STREAM_BASS,1);
  cr_mod(&cr,minor?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);cr.voicing=rotation;
  voice_chord_rank=cr_synth_chord_rank;cr_key(&cr,48,100,1);for(unsigned i=0;i<12;i++)tick();
  const cr_voice_t *first=newest();assert(first&&first->nnotes==6);for(unsigned z=0;z<6;z++){if(!held(first->notes[z]))fprintf(stderr,"FIRST missing %u\n",first->notes[z]);assert(held(first->notes[z]));}
  for(unsigned step=0;step<3;step++){
   unsigned root=step==0?49u:step==1?46u:53u;
   cr_key(&cr,root,100,1);for(unsigned i=0;i<12;i++)tick();
   const cr_voice_t *v=newest();assert(v&&v->root==(int)root&&v->nnotes==6);
   for(unsigned j=0;j<6;j++)if(!held(cr_tr_note(0,v->notes[j]))){fprintf(stderr,"missing CZ-1 preset=%u inversion=%d minor=%u root=%u note=%u\n",preset,rotation,minor,root,v->notes[j]);for(unsigned z=0;z<NVOICE;z++)fprintf(stderr,"v%u note%u active%u gate%u stage%u rank%u\n",z,trk[0].v[z].note,trk[0].v[z].active,trk[0].v[z].gate,trk[0].v[z].stage,chord_rank(&trk[0],z));fprintf(stderr,"queue=%u busy=%u cap=%u\n",vsq[0].n,voices_busy_of(&trk[0]),trk_nvoice(&trk[0]));for(unsigned z=0;z<6;z++)fprintf(stderr,"want %u rank%u omitted%u\n",v->notes[z],cr_synth_chord_rank(&trk[0],v->notes[z]),cr_chord_skipped[v->notes[z]]);abort();}
   unsigned n=0;for(unsigned j=0;j<NVOICE;j++)n+=trk[0].v[j].active&&trk[0].v[j].gate&&trk[0].v[j].stage!=4u;
   assert(n==6);assert(c1_chord_count==2);cases++;
   if(step==0u){cr_key(&cr,48,100,0);for(unsigned i=0;i<4;i++)tick();for(unsigned j=0;j<6;j++)assert(held(cr_tr_note(0,v->notes[j])));}

  }
  /* Rapid retrigger while previous fades are still queued. */
  cr_key(&cr,57,100,1);tick();cr_key(&cr,59,100,1);tick();cr_key(&cr,62,100,1);
  for(unsigned i=0;i<16;i++)tick();
  const cr_voice_t *last=newest();assert(last&&last->root==62);
  for(unsigned j=0;j<6;j++)assert(held(cr_tr_note(0,last->notes[j])));
  cases++;
  cr_panic(&cr);for(unsigned i=0;i<8;i++)tick();
  for(unsigned j=0;j<NVOICE;j++)assert(!trk[0].v[j].gate);
 }
 for(unsigned preset=0;preset<ENGINES[eng]->npresets;preset++){
  setup(eng,preset,ENGI_BASS,0,6,0);for(unsigned i=0;i<12;i++)tick();
  for(unsigned note=61;note<67;note++)trk_note_on(&trk[0],note,100);
  for(unsigned i=0;i<24;i++)tick();
  for(unsigned note=61;note<67;note++)assert(held(note));
  trk_all_off(&trk[0]);for(unsigned i=0;i<8;i++)tick();cases++;
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: %u CZ-1 overlapping six-note chords, all factories, major/minor, inversions, ascending/descending roots, rapid queued retriggers, shared-note release, raw MIDI/keys, Bass, two CPU1 voices, release cleanup\n",cases);
}

int main(void){check(ENGI_CZ);return 0;}
