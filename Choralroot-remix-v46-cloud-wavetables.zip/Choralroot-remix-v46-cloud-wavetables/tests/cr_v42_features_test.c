#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include "../firmware/src/output_start.h"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(!eng_ok(ENGI_GFORM));for(unsigned i=0;i<NENG_SHOWN;i++)assert(eng_vis(i)!=ENGI_GFORM);
 cu_load(&trk[0],ENGI_MORPH,0,0);engine_block(&trk[0]);assert(morph_control(&trk[0],MP_MODE)==1);
 assert(GP[G_RTYPE].max==127&&GP[G_RTYPE].min==0);
 int64_t side_energy[3]={0},mid_energy[3]={0};
 for(unsigned w=0;w<3;w++){
  rev_clear();memset(&fx,0,sizeof fx);song.g[G_RTYPE]=w? w==1?64:127:0;song.g[G_RSIZE]=96;song.g[G_RDAMP]=64;
  int32_t in[CTL]={0},zero[CTL]={0},out[CTL];in[0]=32767;
  for(unsigned b=0;b<44100/CTL;b++){
   fx_buses(zero,zero,in,out,CTL);memset(in,0,sizeof in);
   for(unsigned i=0;i<CTL;i++){assert(llabs(out[i])<300000);assert(llabs(rev_stereo[i])<300000);side_energy[w]+=llabs(rev_stereo[i]);mid_energy[w]+=llabs(out[i]);}
  }
 }
 assert(!side_energy[0]&&side_energy[1]>0&&side_energy[2]>side_energy[1]);assert(mid_energy[0]==mid_energy[1]&&mid_energy[1]==mid_energy[2]);
 uint32_t before=church_w;int32_t zero[CTL]={0},out[CTL];song.g[G_RTYPE]=20;fx_buses(zero,zero,zero,out,CTL);assert(church_w>before&&fx.rtype==3);
 uint32_t f=0;int32_t previous=0;
 for(unsigned i=0;i<11000;i++){int32_t g=output_start_gain(&f);assert(g>=previous&&g<=32768);if(i<8820)assert(g==0);if(i>=9702)assert(g==32768);previous=g;}assert(f==9702);
 assert(cloud_pow2_fine(63*3)>=cloud_pow2_q16(7)&&cloud_pow2_fine(63*3)<=cloud_pow2_q16(8));
 cu_load(&trk[0],ENGI_CLUSTER,0,0);engine_block(&trk[0]);ce_open(0);assert(!ce_has(&trk[0],CE_FILT));ce_group(CE_OSC);
 for(unsigned i=0;i<12;i++)ce_knob(0,1,0);assert(trk[0].p[P_E0]>>11==7);ce_close();
 cluster_note_t *cs42=&cluster_part(0)->note[0];cluster_note_on(&trk[0],&trk[0].v[0]);for(unsigned i=0;i<80;i++)cluster_light_kernel(cs42,pitch_inc(60*16),&trk[0].p[P_E0]);assert(cs42->global.gain[6]>0);
 for(unsigned rank=0;rank<NENG_SHOWN;rank++){
  unsigned e=eng_vis(rank);cu_load(&trk[0],e,0,0);engine_block(&trk[0]);
  if(!ce_deep(&trk[0]))for(unsigned g=CE_OSC;g<=CE_FILT;g++)if(ce_has(&trk[0],g)){
   unsigned n=0;for(unsigned j=g*4;j<g*4+4;j++)n+=ENGINES[e]->edit[j].max>ENGINES[e]->edit[j].min;assert(n);
  }
 }
 for(int32_t x=INT32_MIN;x<INT32_MAX-100000000;x+=100000000)for(unsigned g=0;g<=65536;g+=4096)assert(mulq16(x,g)==(int32_t)(((int64_t)x*g)>>16));
 int32_t level_out[4];unsigned balanced[]={2,ENGI_PROPHET,ENGI_CZ,ENGI_BASS};
 for(unsigned k=0;k<4;k++){
  memset(&trk[0],0,sizeof trk[0]);for(unsigned p=0;p<P_COUNT;p++)trk[0].p[p]=TP[p].def;
  trk[0].engine=trk[0].eng_req=balanced[k];trk[0].p[P_LEVEL]=100;trk[0].p[P_DIST]=trk[0].p[P_SLCR]=trk[0].p[P_CHOR]=trk[0].p[P_REV]=trk[0].p[P_DLY]=0;trk[0].p[P_PAN]=0;
  int32_t raw[CTL],side[CTL]={0};for(unsigned j=0;j<CTL;j++)raw[j]=16384;
  memset(mix_l,0,sizeof mix_l);memset(mix_r,0,sizeof mix_r);pf.mute=0;mix_part_out(&trk[0],raw,side,0,1,CTL);level_out[k]=mix_l[CTL-1];
 }
 for(unsigned k=1;k<4;k++)assert(llabs((int64_t)level_out[k]*32768-(int64_t)level_out[0]*24573)<(int64_t)level_out[0]*40);
 for(unsigned e=ENGI_DRIFT;e<=ENGI_TERRAIN;e++)for(unsigned edge=0;edge<2;edge++)for(unsigned bank=0;bank<2;bank++){
  cu_load(&trk[0],e,0,0);engine_block(&trk[0]);int16_t expected42[8];
  for(unsigned j=0;j<8;j++)expected42[j]=trk[0].p[P_E0+j]=edge?ENGINES[e]->edit[j].max:ENGINES[e]->edit[j].min;
  unsigned slot=bank?63:31;assert(!cb_store(&trk[0],0,slot,"SEL CORNERS",0));cu_load_user(&trk[0],slot,0);engine_block(&trk[0]);
  assert(trk[0].eng_req==e);assert(!memcmp(expected42,trk[0].p+P_E0,sizeof expected42));
 }
 puts("PASS: Church width changes side only, continuous tail; Morph Up/Down default; retired Grain Formant; seven Cluster oscillators; generic pages nonempty; DAC settling envelope");
}
