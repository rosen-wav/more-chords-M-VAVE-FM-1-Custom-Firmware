#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);unsigned checked=0,empty=0;
 for(unsigned rank=0;rank<NENG_SHOWN;rank++){
  unsigned e=eng_vis(rank);cu_load(&trk[0],e,0,0);engine_block(&trk[0]);ce_open(0);
  for(unsigned g=0;g<CE_NSEC;g++)if(ce_has(&trk[0],g)){
   ce_group(g);ce_scr_t sc;unsigned ns=ce_scr(&trk[0],g,0,&sc);
   for(unsigned k=0;k<ns;k++){cx.scr[0][g]=k;ce_view_t vw;ce_view(&trk[0],0,&vw);unsigned live=0;
    for(unsigned r=0;r<vw.n;r++)for(unsigned c=0;c<4;c++){int32_t v;const param_desc_t *d=ce_param(&trk[0],vw.ref[r][c],&v);live+=d&&d->max>d->min;live+=vw.ref[r][c].k==CE_R_TXT;}
    if(!live){fprintf(stderr,"EMPTY %s group%u screen%u kind%u rows%u\n",ENGINES[e]->name,g,k,vw.kind,vw.n);empty++;}checked++;
   }
  }ce_close();
 }
 assert(!empty);printf("PASS: %u selectable editor screens have editable parameters\n",checked);
}
