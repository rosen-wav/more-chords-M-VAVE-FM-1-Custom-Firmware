#define UI_ENTRY legacy_ui_main
#include "cr_v40_ui_test.c"
#undef main
static unsigned index42=16;
static void snapshot42(const char *dir){cr_screen_t s;cr_build_screen(&s,cu_now());char path[512];snprintf(path,sizeof path,"%s/screen-%u.bin",dir,index42++);FILE *f=fopen(path,"wb");assert(f);assert(fwrite(&s,sizeof s,1,f)==1);fclose(f);}
int main(int argc,char **argv){assert(!legacy_ui_main(argc,argv));
 cu_load(&trk[0],ENGI_MORPH,0,0);engine_block(&trk[0]);ce_open(0);
 for(unsigned page=0;page<2;page++){ce_group(page?CE_LFO:CE_OSC);for(unsigned mode=0;mode<3;mode++)for(unsigned pos=0;pos<2;pos++){
 morph_deep_set(&trk[0],0,3,pos?127:0);morph_deep_set(&trk[0],1,3,mode);morph.pos=pos?32512:0;assert(morph_control(&trk[0],MP_MODE)==mode);snapshot42(argv[1]);}}
 ce_close();unsigned engines[]={2,ENGI_FM6,ENGI_PROPHET,ENGI_CZ};
 for(unsigned j=0;j<4;j++){cu_load(&trk[0],engines[j],0,0);engine_block(&trk[0]);ce_open(0);ce_group(CE_OSC);snapshot42(argv[1]);ce_close();}
 cu_load(&trk[0],ENGI_CLOUD,0,0);engine_block(&trk[0]);ce_open(0);
 for(unsigned page=0;page<2;page++){ce_group(page?CE_FILT:CE_OSC);for(unsigned edge=0;edge<2;edge++){
  for(unsigned j=0;j<4;j++)trk[0].p[P_E0+page*4+j]=edge?ENG_CLOUD.edit[page*4+j].max:ENG_CLOUD.edit[page*4+j].min;snapshot42(argv[1]);}}
 ce_close();cu_load(&trk[0],ENGI_CLUSTER,0,0);engine_block(&trk[0]);ce_open(0);ce_group(CE_OSC);
 for(unsigned edge=0;edge<4;edge++){trk[0].p[P_E0]=(edge&1?7:1)*2048;trk[0].p[P_E1]=edge&2?32767:-32768;trk[0].p[P_E3]=edge&2?32767:-32768;snapshot42(argv[1]);}ce_close();
 assert(index42==40);puts("PASS: 40 engine screen states including all Morph modes and both pages");return 0;
}
