/* Regression: real parallel Morph including Bass; live regeneration. */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static int32_t pcm[2*CTL],ref[160][2*CTL];
static void init_morph(unsigned src,unsigned bass){
 setup(ENGI_FM6,0,bass,0,0,0);
 memset(&morph,0,sizeof morph);morph_dual=0;
 cu_load(&trk[0],ENGI_MORPH,0,0);engine_block(&trk[0]);panic_req=0;
 trk[0].p[P_E0]=src;trk[0].p[P_E1]=0;trk[0].p[P_E2]=64;trk[0].p[P_E5]=100;
 trk[0].p[P_E7]=0x1201;morph_sync(&trk[0]);
 for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],48+i*3,30+i*15);
 unsigned held[2]={0,0};
 for(unsigned i=0;i<NVOICE;i++){held[0]+=trk[0].v[i].gate!=0;held[1]+=trk[2].v[i].gate!=0;}
 assert(held[0]==6&&held[1]==6);
 const engine_t *e=ENGINES[MORPH_SOURCE[src]];
 for(unsigned i=0;i<8;i++)assert(trk[2].p[P_E0+i]==(MORPH_SOURCE[src]==ENGI_CLUSTER?OP1_CLUSTER_KNOBS[1][i]:e->presets[1].e[i]));

}
static void render_morph(unsigned k,int32_t *out){
 if(k==20){midi_bend_target[0]=256;trk[0].bend_raw=2048;trk[0].mw=37;trk[0].at=51;}
 if(k==30)trk[0].p[P_E2]=127;
 if(k==55)trk[0].p[P_E2]=0;
 if(k==80){for(unsigned i=0;i<6;i++)trk_note_off(&trk[0],48+i*3);}
 if(k==110){for(unsigned i=0;i<6;i++)trk_note_on(&trk[0],50+i*3,90);}
 for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(out,CTL);
 assert(!AW_C1_BUSY());
 if(trk[0].engine==ENGI_MORPH && morph_dual){assert(midi_bend_q8[0]==midi_bend_q8[2]);assert(trk[2].mw==trk[0].mw&&trk[2].at==trk[0].at&&trk[2].bend_raw==trk[0].bend_raw);}
}
#ifndef CR_V8_HELPERS_ONLY
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(!eng_ok(3)&&!eng_ok(5));
 for(unsigned i=0;i<NENG_SHOWN;i++)assert(eng_vis(i)!=3&&eng_vis(i)!=5);
 for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)assert(MORPH_SOURCE[i]!=3&&MORPH_SOURCE[i]!=5);
 pthread_t th;assert(!pthread_create(&th,0,worker,0));
 while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned cases=0;
 const unsigned bass_engines[]={ENGI_FM6,ENGI_QUAD,ENGI_VA,2u,ENGI_CZ,ENGI_PROPHET,ENGI_BASS};
 for(unsigned src=0;src<NELEM(MORPH_SOURCE);src++)for(unsigned bass=0;bass<NELEM(bass_engines);bass++){
  cr_c1_test_serial=1;init_morph(src,bass_engines[bass]);
  for(unsigned k=0;k<160;k++)render_morph(k,ref[k]);
  cr_c1_test_serial=0;init_morph(src,bass_engines[bass]);
  for(unsigned k=0;k<160;k++){
   render_morph(k,pcm);
   if(memcmp(pcm,ref[k],sizeof pcm)){fprintf(stderr,"Morph mismatch src %u bass %u block %u\n",src,bass_engines[bass],k);return 1;}
  }
  cu_engine_switch(0,ENGI_FM6);
  for(unsigned k=0;k<16;k++)render_morph(159,pcm);
  assert(trk[0].engine==ENGI_FM6&&!morph_dual);
  for(unsigned k=0;k<NVOICE;k++)assert(!trk[2].v[k].active&&!trk[2].v[k].gate);
  assert(!vsq[2].n);
  cases++;
 }
 pthread_cancel(th);pthread_join(th,0);audio_worker_online=0;cr_dbg.c1=C1_FAILED;cr_c1_test_serial=1;
 setup(ENGI_FM6,0,ENGI_CZ,0,0,0);cr_perform_forget();cr_panic(&cr);cr_loop_clear(&crl,&cr);
 cr_snapshot();cu.page=PG_NONE;cu.lock=L_NONE;crl_stage_busy=0;creative_ideas.ready=0;cs.loop_len=2;
 creative_open_ideas();assert(creative_ideas.ready);creative_preview_play();cr_audio_block(CTL);
 cr_idea_boundary();cr_idea_tick();assert(cr_idea.active&&cr_idea.voice);
 uint32_t origin=cr_idea.origin;uint8_t index=cr_idea.index;unsigned color=0;uint32_t roots=0;
 for(unsigned scale=0;scale<3;scale++)for(unsigned pat=0;pat<NELEM(IDEA_NAMES);pat++)for(unsigned seed=1;seed<=30;seed++){
  creative_ideas.minor=scale;creative_ideas.pattern=pat;creative_ideas.rng=seed;creative_generate();
  assert(cr_idea.active&&cr_idea.voice&&cr_idea.origin==origin&&cr_idea.index==index);
  assert(crl_stage.nev==4&&crl_stage.grid_global&&crl_stage.len<=CRL_MAX_LEN);
  for(unsigned i=0;i<4;i++){
   const crl_ev_t *v=&crl_stage.ev[i];assert(v->root>=48&&v->root<72&&v->dur>0&&v->t==i*crl_stage.len/4);
   unsigned ext=v->qx&15;assert(!(ext&CR_EXT_M7)||!(ext&CR_EXT_MAJ7));
   if(scale==2)roots|=1u<<(v->root%12);color|=1u<<(v->qx>>4);
  }
 }
 assert(roots==4095u);assert(color&(1u<<CR_Q_DIM));assert(color&(1u<<CR_Q_SUS));
 crl.t=origin+crl_stage.ev[1].t;cr_idea_tick();assert(cr_idea.active&&cr_idea.index==1);
 creative_cancel_ideas();assert(!cr_idea.active&&!cr_idea.voice);
 /* A physical tap released during sensing must not vanish. */
 cu.page=PG_NONE;cu.lock=L_NONE;cu.step_editor=cu.opt_open=0;cs.keys_only=1;cr_set_keys_only(&cr,1);
 unsigned key=CU_ROOT0;cu.kheld=0;cu_vel_pending=1u<<key;
 emu_hal.keys=0;fm1_in.notes=0;host_notes=0;
 uint32_t queued=cr_evq_w;cr_ui_input();
 assert(cr_evq_w>=queued+2u&&!(cu_vel_pending&(1u<<key))&&!cu.key_note[key]);
 /* MIDI/recorded velocity must survive the physical velocity switch. */
 for(unsigned on=0;on<2;on++){
  cr_dynamic_velocity=on;cr_chord_skipped[60]=0;cr_cb_note_on(0,CR_STREAM_MAIN,60,37);
  assert(trk[0].m_vel==37);cr_cb_note_off(0,CR_STREAM_MAIN,60);
 }
 printf("PASS: %u real serial/CPU1 Morph+Bass PCM cases; 990 live regenerated ideas, chromatic all 12 roots, retired engines, MIDI velocity preserved\n",cases);
 return 0;
}

#endif
