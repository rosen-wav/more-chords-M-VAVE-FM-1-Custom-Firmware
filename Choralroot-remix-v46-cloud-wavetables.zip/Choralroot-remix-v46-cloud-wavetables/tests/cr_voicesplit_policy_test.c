/* Uses the same actual pthread worker and audio path as the PCM/state suite. */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"

int main(void){
 pthread_t th;unsigned checks=0;int32_t out[2*CTL];
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();
 for(unsigned online=0;online<2;online++){
  audio_worker_online=online;cr_dbg.c1=online?C1_OK:C1_FAILED;
  cr_c1_test_serial=!online;
  for(unsigned e=0;e<2;e++)for(unsigned bass=0;bass<2;bass++)
  for(unsigned root=48;root<60;root++)for(int inv=-3;inv<=5;inv++)for(int tp=-12;tp<=12;tp+=12)
  for(unsigned minor=0;minor<2;minor++)for(unsigned maj7=0;maj7<2;maj7++){
   clear(engines[e],bass,tp);
   cr_mod(&cr,minor?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);
   cr_mod(&cr,maj7?CR_MOD_MAJ7:CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
   cr.voicing=inv;cr_key(&cr,root,100,1);
   for(unsigned k=0;k<8;k++){for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(out,CTL);}
   unsigned expected=online?6u:(e&&bass?4u:5u),n=0;
   for(unsigned j=0;j<cr.v[0].nnotes;j++){
    unsigned note=cr.v[0].notes[j],pc=(note+12u-root%12u)%12u;
    int keep=expected==6u || (pc!=9u && !(expected==4u && (pc==10u||pc==11u)));
    assert(held(cr_tr_note(0,note))==keep);
   }
   for(unsigned j=0;j<NVOICE;j++)n+=trk[0].v[j].active&&trk[0].v[j].gate&&trk[0].v[j].stage!=4u;
   assert(n==expected);assert(third_present());
   assert(voices_busy_of(&trk[0])<=VBUDGET);assert(voices_busy_of(&trk[1])<=VBUDGET);
   if(online){
    assert(chord_plan.count==6u && c1_chord_count==2u);
    /* Actual overload guard: sixth first, seventh second, in every inversion. */
    shed_voice();assert(third_present());
    for(unsigned j=0;j<cr.v[0].nnotes;j++)if((cr.v[0].notes[j]+12u-root%12u)%12u==9u)assert(!held(cr_tr_note(0,cr.v[0].notes[j])));
    shed_voice();assert(third_present());
    for(unsigned j=0;j<cr.v[0].nnotes;j++){unsigned pc=(cr.v[0].notes[j]+12u-root%12u)%12u;if(pc==10u||pc==11u)assert(!held(cr_tr_note(0,cr.v[0].notes[j])));}
   }
   cr_key(&cr,root,0,0);assert(all_released());checks++;
  }
 }
 assert(c1_chord_jobs>0);pthread_cancel(th);pthread_join(th,0);
 printf("Voice split policy: %u fixtures PASS; 6 online, 5/4 fallback, exact tones, sixth then seventh, thirds, roots/inversions/transpose, note-offs and both budgets\n",checks);return 0;
}
