/* Execute the real worker on a thread, injecting a corrupt publication. */
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sched.h>
#define AW_WORD _Atomic uint32_t
#define AW_LOAD(p) atomic_load_explicit(p,memory_order_acquire)
#define AW_STORE(p,v) atomic_store_explicit(p,v,memory_order_release)
#define AW_TICKS() 0u
#define AW_TIMEOUT_TICKS 10000u
#define AW_FAULT() abort()
#define AW_RAM_LOOP static
#define AW_IDLE() pthread_testcancel()
#include "../firmware/src/audio_worker.h"
static _Atomic uint32_t calls;
static void cb(void *p) { assert(p==&calls);calls++; }
static void *run(void *p) { (void)p;audio_worker_loop();return 0; }
int main(void) {
 audio_worker_online=1;
 assert(audio_worker_submit(cb,&calls));
 AW_STORE(&audio_worker.check,AW_LOAD(&audio_worker.check)^0x00200000u);
 pthread_t thread;assert(!pthread_create(&thread,0,run,0));
 for(unsigned i=0;i<10000000 && !AW_LOAD(&audio_worker.fault);i++)sched_yield();
 assert(AW_LOAD(&audio_worker.fault)==1 && calls==0);
 assert(AW_LOAD(&audio_worker.complete)==AW_LOAD(&audio_worker.request));
 pthread_cancel(thread);pthread_join(thread,0);
 puts("PASS: corrupted CPU1 mailbox rejected, zero callback executions, completion returned for CPU0 reset");
}
