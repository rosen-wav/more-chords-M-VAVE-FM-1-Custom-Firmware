"""Native CS-1 record stays exact through the existing visual librarian format."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import fm1_install as f
r=bytearray(192);r[:4]=bytes([165,6,21,91]);r[4:7]=b'CS1';r[16:159]=bytes([64])*143;r[159]=3
for i,v in ((0,1),(26,1),(1,0),(27,0),(53,0),(62,0),(72,0)):r[16+i]=v
assert f.sound_record_valid(r)
m={};f._set_record(m,1,bytes(r));file=f.export_sound(m,1,'CS1 host');sound=f.read_sound_file(file)
assert sound[0]==r and f.ENGINE_NAMES[21]=='CS-1' and len(f.FACTORY_PRESETS['21'])==52
r[16]=6;assert not f.sound_record_valid(r);r[16]=1;r[2]=20;assert not f.sound_record_valid(r)
print('PASS: Python CS-1 native record export/read, factory pool and malformed records')
