from pathlib import Path
import subprocess, os, hashlib
r=Path(__file__).resolve().parents[1]
os.chdir(r)
paths=[]
for name,header in [('before',r/'tests/reference/cs1_v14_native.h'),('after',r/'firmware/src/cs1_native.h')]:
 exe=r/'build/host'/('cs1_opt_'+name)
 subprocess.run([os.environ.get('CC','cc'),'-O2','-w','-Ifirmware/src','-DCS1_NATIVE_HEADER="'+str(header)+'"','tests/cr_cs1_opt_probe.c','-o',str(exe)],check=True)
 out=exe.with_suffix('.bin')
 subprocess.run([str(exe),str(out)],check=True)
 paths.append(out)
a,b=[p.read_bytes() for p in paths]
assert a==b, 'V14 PCM/state mismatch'
print('PASS:',len(a),'PCM/state bytes identical to V14; SHA256',hashlib.sha256(a).hexdigest())
