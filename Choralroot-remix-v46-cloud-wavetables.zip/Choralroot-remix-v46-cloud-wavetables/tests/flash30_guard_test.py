"""Compile the actual HAL range macros on host, without executing device SFR code."""
import os, pathlib, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
cc=os.environ.get('CC','cc')
macros=subprocess.check_output([cc,'-dM','-E','-x','c','-Ifirmware/hal','-'],input=b'#include "fm1_flash.h"\n',cwd=root).decode()
defs='\n'.join(x for x in macros.splitlines() if x.startswith('#define FL_') and not x.startswith('#define FL_FAR'))
code='#include <stdint.h>\n'+defs+'\nint main(void){\n'
checks=[]
for k in range(10):
 for copy in range(2):checks.append(f'FL_STORE_OK({0xE5000+(2*k+copy)*4096}u,4096u)')
for off,size in [(0,4096),(0x4000,4096),(0x92000,4096),(0xE0000,4096),(0xE4000,4096),(0xF9000,4096),(0xFB000,4096),(0xFF000,4096),(0xE4FFF,2),(0xF8FFF,2),(0xFFFFFFFF,4096),(0xE5000,0xFFFFFFFF)]:
 checks.append(f'!FL_STORE_OK({off}u,{size}u)')
for i,check in enumerate(checks):code+=f'if(!({check}))return {i+1};\n'
code+='return 0;}\n'
with tempfile.TemporaryDirectory() as t:
 src=pathlib.Path(t)/'guard.c';out=pathlib.Path(t)/'guard';src.write_text(code)
 subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Werror',str(src),'-o',str(out)],check=True)
 subprocess.run([str(out)],check=True)
print(f'PASS: {len(checks)} actual HAL range checks; 20 new sectors, app/boot/updater/globals boundaries and overflow refusal')
