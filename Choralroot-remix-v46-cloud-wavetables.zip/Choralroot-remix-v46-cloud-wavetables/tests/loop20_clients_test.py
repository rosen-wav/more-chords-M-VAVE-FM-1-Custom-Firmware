"""Fake MIDI only: client labels, full 30-slot backup and restore (no hardware)."""
import json
from install_test import I, BackupSide, FakeFM1, cli, TMP, fill
assert I.CR_IDS[-32:-2] == list(range(40,70)) and I.CR_IDS[-2:]==[70,71] and len(I.CR_IDS)==50
for k in range(30):
    assert I.object_name(40+k)==f'loop slot {k+1}'
objects={40:fill(46,1),50:fill(46,2),69:fill(46,3)}
side=BackupSide('ChoralRoot 0.14',I.CR_IDS,objects.items())
path=TMP/'loop20.json'
rc,out,err=cli(['--backup',str(path)],FakeFM1(b'',identity='FM-1_920',bk=lambda _i:side))
assert rc==0,(out,err)
archive=json.loads(path.read_text());assert [o['id'] for o in archive['objects']]==I.CR_IDS
assert 'loop slot 30' in out
blank=BackupSide('ChoralRoot 0.14',I.CR_IDS)
rc,out,err=cli(['--restore',str(path),'--yes'],FakeFM1(b'',identity='FM-1_920',bk=lambda _i:blank))
assert rc==0,(out,err)
for k,data in objects.items():assert blank.objs[k]==data
print('PASS: Python client 30 labels and full 50-object backup/restore, including loop slots 11 and 30; mocked MIDI')

import shutil
shutil.rmtree(TMP,ignore_errors=True)
