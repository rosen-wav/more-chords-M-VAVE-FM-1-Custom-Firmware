/* Frozen Stage35 waveform/sample kernels: regression oracle only. */
static inline __attribute__((always_inline)) int32_t p5_reference_wave(uint32_t phase, uint32_t inc, uint32_t pw, int saw, int pulse, int tri, int32_t *triangle)
{
    /* Simultaneous waveforms share their discontinuity correction. */
    int32_t y=0, a=p5_fast_osc_saw(phase,inc), square=0;
    if(saw)y+=a>>1;
    if(pulse){square=(a-p5_fast_osc_saw(phase+pw,inc))>>1;y+=square;}
    if(tri){
        if(!pulse || pw!=0x80000000u)square=(a-p5_fast_osc_saw(phase+0x80000000u,inc))>>1;
        *triangle=p5_fast_clamp(p5_fast_mulq15(*triangle,32767)+
            (int32_t)(((int64_t)square*2*(int32_t)(inc>>15))>>15),-40000,40000);
        y+=*triangle>>1;
    }
    return y;
}

static __attribute__((section(".dsp_text"))) void p5_reference_samples(p5_voice_t *restrict s, const uint8_t *restrict p, int32_t *restrict out, uint32_t n, const vmod_t *m, const p5_render_params_t *c)
{
    int32_t f0=c->f0;
    int32_t a0=c->a0;
    int32_t f1=c->f1;
    int32_t a1=c->a1;
    int32_t ia=c->ia;
    int32_t ib=c->ib;
    int32_t cut=c->cut;
    int32_t k=c->k, filter_gain=c->filter_gain;
    int32_t filter_velocity=c->filter_velocity;
    int32_t amp_velocity=c->amp_velocity;
    int32_t env_amount=c->env_amount;
    int32_t pa_env=c->pa_env, pa_b=c->pa_b, pf_env=c->pf_env, pf_b=c->pf_b, pw_env=c->pw_env, pw_b=c->pw_b;
    int32_t pwm_a=c->pwm_a;
    int32_t pwm_b=c->pwm_b;
    int32_t la=c->la;
    int32_t lb=c->lb;
    int32_t ln=c->ln;
    int32_t last=0;
    for (uint32_t i=0; i<n; i++) {
        int32_t fe=f0+(((f1-f0)*(int32_t)i)>>CTL_LOG2);
        int32_t ae=a0+(((a1-a0)*(int32_t)i)>>CTL_LOG2);
        int32_t sum=0;
        for (uint32_t os=0; os<P5_OVERSAMPLE; os++) {
            int32_t noise=(int32_t)(p5_fast_noise32(&s->noise)>>17)-16384;
            int32_t lfo=c->wheel[i*P5_OVERSAMPLE+os];
            uint16_t wheel_pitch=c->wheel_pitch[i*P5_OVERSAMPLE+os];
            uint32_t db=p[P5_WHEEL_FREQ_B]?p5_wheel_inc(ib,wheel_pitch):(uint32_t)ib;
            int32_t b=p5_reference_wave(s->phase[1],db,p5_pw(pwm_b+(p[P5_WHEEL_PW_B]?lfo:0)),p[P5_SAW_B],p[P5_PULSE_B],p[P5_TRI_B],&s->triangle);
            int32_t bn=b*2;   /* one full oscillator B wave: +-32768 */
            uint32_t da=p[P5_POLY_FREQ]?p5_inc(ia,p5_fast_mulq15(fe,pa_env)+p5_wave_gain(bn,pa_b)):(uint32_t)ia;
            if(p[P5_WHEEL_FREQ_A])da=p5_wheel_inc(da,wheel_pitch);
            uint32_t pw=p5_pw(pwm_a+(p[P5_POLY_PW]?p5_fast_mulq15(fe,pw_env)+p5_wave_gain(b,pw_b):0)+(p[P5_WHEEL_PW_A]?lfo:0));
            int32_t unused=0;
            int32_t a=p5_reference_wave(s->phase[0],da,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused)+s->sync_tail;
            s->sync_tail=0;
            uint32_t nb=s->phase[1]+db, na=s->phase[0]+da;
            if (p[P5_SYNC] && nb<s->phase[1] && db) {
                uint32_t frac=p5_sync_fraction(0u-s->phase[1],db);
                uint32_t at=s->phase[0]+(uint32_t)(((uint64_t)da*frac)>>15);
                int32_t before=p5_reference_wave(at,da,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused);
                int32_t after=p5_reference_wave(0,da,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused);
                int32_t jump=after-before, remain=32768-(int32_t)frac;
                /* Fractional discontinuity correction over this/next sub-sample. */
                a += p5_fast_mulq15((jump>>1),p5_fast_mulq15(remain,remain));
                s->sync_tail=-p5_fast_mulq15((jump>>1),p5_fast_mulq15((int32_t)frac,(int32_t)frac));
                na=(uint32_t)(((uint64_t)da*(uint32_t)remain)>>15);
            }
            s->phase[0]=na; s->phase[1]=nb;
            int32_t x=p5_wave_gain(a,la)+p5_wave_gain(b,lb)+p5_fast_mulq15(noise,ln);
            int32_t fc=cut+p5_fast_mulq15(p5_fast_mulq15(fe,filter_velocity),env_amount);
            if (p[P5_POLY_FILTER]) fc+=p5_fast_mulq15(fe,pf_env)+p5_wave_gain(bn,pf_b);
            if (p[P5_WHEEL_FILTER]) fc+=(lfo*7)>>3;   /* +-4 octaves at full amount */
            sum+=p5_filter_core(s,p5_fast_softclip(x),fc,k,filter_gain,!!p[P5_FILTER_REV]);
        }
        #if P5_OVERSAMPLE == 2
        sum >>= 1;
        #endif
        int32_t gain=p5_fast_mulq15(p5_fast_mulq15(ae,amp_velocity),32767+s->amp_drift);
        last=p5_fast_voice_amp(p5_fast_mulq15(sum,gain),m,i)*2;
        out[i]+=last;
    }
    s->last_pcm=last;
}