#!/bin/sh
# Host tests only: no flash, no package generation, no golden regeneration.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/audio019-tests/os build/host
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/audio019-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/audio019-tests"
fi
for name in cr_output_test cr_usbtap_test; do
 "$CC" -std=gnu11 -O2 -w -Ibuild/gen -Ifirmware/src -Itests "tests/$name.c" -lm -o "build/audio019-tests/$name"
 "build/audio019-tests/$name" > "build/host/audio019-$name.log"
 tail -n 1 "build/host/audio019-$name.log"
done
for name in cr_usbaudio_test cr_usbaudio48_test cr_usbrate_test; do
 "$CC" -std=gnu11 -O2 -w "tests/$name.c" -lm -o "build/audio019-tests/$name"
 "build/audio019-tests/$name" > "build/host/audio019-$name.log"
 tail -n 1 "build/host/audio019-$name.log"
done
"$CC" -std=gnu11 -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_audio019_integration_test.c -lm -o build/audio019-tests/cr_audio019_integration_test
"$CC" -std=gnu11 -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_sync_persist_test.c -lm -o build/audio019-tests/cr_sync_persist_test
build/audio019-tests/cr_sync_persist_test
build/audio019-tests/cr_audio019_integration_test
"$CC" -std=c11 -Wall -Wextra -Werror -pedantic -O2 tests/cr_settings_test.c firmware/src/cr_settings.c firmware/src/cr_engine.c -o build/audio019-tests/cr_settings_test
build/audio019-tests/cr_settings_test
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
printf 'PASS: audio019 tests; target syntax with CPU1 disabled/enabled (JL linking and hardware still required)\n'
