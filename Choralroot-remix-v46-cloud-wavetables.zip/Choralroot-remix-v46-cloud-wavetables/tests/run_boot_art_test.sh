#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/host build/boot-art/ppm
${CC:-cc} -std=c99 -O1 -w -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src -Itests tests/cr_boot_art_test.c -o build/host/boot-art
build/host/boot-art
