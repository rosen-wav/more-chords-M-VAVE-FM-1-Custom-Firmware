#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/cloud-banks/os build/cloud-banks/ppm
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/cloud-banks/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/cloud-banks"
fi
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src tests/cr_cloud_banks_dsp_test.c -o build/cloud-banks/dsp
build/cloud-banks/dsp
for name in cr_cloud_banks_ui_test cr_cloud_banks_cpu_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/cloud-banks/$name
 build/cloud-banks/$name build/cloud-banks
done
${CC:-cc} -O1 -w -Ibuild/gen -Ifirmware/src -Itests tests/cr_cloud_banks_render_test.c -o build/cloud-banks/render
build/cloud-banks/render build/cloud-banks
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
sh tests/run_morph_tests.sh
