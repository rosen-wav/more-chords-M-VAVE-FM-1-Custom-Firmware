#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/cloud-tests/os build/host
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/cloud-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/cloud-tests"
fi
for name in cr_cloud_test cr_cloud_overlap_test cr_cloud_bass_block_test cr_cloud_ui_test cr_cs1_retired_test; do
 ${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/cloud-tests/$name
 build/cloud-tests/$name
done
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=undefined tests/cr_cloud_dsp_test.c -o build/cloud-tests/cr_cloud_dsp_test
build/cloud-tests/cr_cloud_dsp_test
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
${CC:-cc} -std=gnu11 -O1 -w $extra -Ibuild/gen -Ifirmware/src -Itests -o build/cloud-tests/sound_templates tests/sound_templates.c -lm
build/cloud-tests/sound_templates --check web/fm1sounds.js tools/fm1_install.py
if command -v node >/dev/null 2>&1; then
 node web/test_sounds.mjs
else
 echo "SKIP: web sounds tests require Node.js; firmware tests completed"
fi
