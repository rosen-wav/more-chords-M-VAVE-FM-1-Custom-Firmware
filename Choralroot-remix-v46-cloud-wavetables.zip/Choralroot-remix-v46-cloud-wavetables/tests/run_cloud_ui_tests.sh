#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/cloud-ui/ppm build/cloud-ui/os build/host
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/cloud-ui/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/cloud-ui"
fi
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_cloud_ui_test.c -lm -o build/host/cloud_ui
build/host/cloud_ui build/cloud-ui
${CC:-cc} -O1 -w -Ibuild/gen -Ifirmware/src -Itests tests/cr_cloud_render_test.c -o build/host/cloud_render
build/host/cloud_render build/cloud-ui
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
