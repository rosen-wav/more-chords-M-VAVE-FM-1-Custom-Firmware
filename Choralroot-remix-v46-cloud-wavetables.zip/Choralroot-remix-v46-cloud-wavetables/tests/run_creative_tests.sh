#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/creative-tests/os build/host
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/creative-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/creative-tests"
fi
"$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_creative_test.c -lm -o build/creative-tests/cr_creative_test
build/creative-tests/cr_creative_test
"$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_creative_next_test.c -lm -o build/creative-tests/cr_creative_next_test
build/creative-tests/cr_creative_next_test
"$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_jazz_ideas_test.c -lm -o build/creative-tests/cr_jazz_ideas_test
build/creative-tests/cr_jazz_ideas_test
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
