#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/cs1-tests/os build/host
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/cs1-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/cs1-tests"
fi
${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_cs1_test.c -lm -o build/cs1-tests/cr_cs1_test
build/cs1-tests/cr_cs1_test
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=undefined tests/cr_cs1_dsp_test.c -o build/cs1-tests/cr_cs1_dsp_test
build/cs1-tests/cr_cs1_dsp_test
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done

python3 tests/cs1_client_test.py
if command -v node >/dev/null 2>&1; then node web/test_sounds.mjs; fi
