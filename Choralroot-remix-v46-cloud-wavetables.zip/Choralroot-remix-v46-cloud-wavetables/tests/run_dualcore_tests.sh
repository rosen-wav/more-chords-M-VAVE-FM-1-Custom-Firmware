#!/bin/sh
# Host-only validation: does not build a package, flash, or touch golden audio.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/dualcore-tests
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 mkdir -p build/dualcore-tests/os
 cat > build/dualcore-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/dualcore-tests"
fi
"$CC" -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_dualcore_test.c -lm -o build/dualcore-tests/cr_dualcore_test
build/dualcore-tests/cr_dualcore_test
"$CC" -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_bass_cpu1_test.c -lm -o build/dualcore-tests/cr_bass_cpu1_test
build/dualcore-tests/cr_bass_cpu1_test
"$CC" -O2 -Wall -Wextra -Wno-unused-function tests/audio_worker_test.c -o build/dualcore-tests/audio_worker_test
build/dualcore-tests/audio_worker_test
"$CC" -O2 -Wall -Wextra -Werror tests/cr_stack_test.c -o build/dualcore-tests/cr_stack_test
build/dualcore-tests/cr_stack_test
for name in cr_cpu1_fallback_test cr_loop_modes_ui_test cr_voicesplit_policy_test; do
 "$CC" -O2 -w $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/dualcore-tests/$name"
 "build/dualcore-tests/$name"
done
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
printf 'PASS: target C syntax, dual-core disabled/enabled (assembly/linking still require JL toolchain)\n'
