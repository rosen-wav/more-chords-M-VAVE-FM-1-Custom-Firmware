#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/keys-bass-tests/os
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
cat > build/keys-bass-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
extra="-Ibuild/keys-bass-tests"
fi
for name in cr_keys_only_test cr_keys_bass_test; do
 "$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/keys-bass-tests/$name"
 "build/keys-bass-tests/$name"
done
