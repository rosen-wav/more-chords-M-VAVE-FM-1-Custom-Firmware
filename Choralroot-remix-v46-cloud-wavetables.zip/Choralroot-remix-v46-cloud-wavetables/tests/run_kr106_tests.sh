#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/kr106-tests/os build/host
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/kr106-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/kr106-tests"
fi
${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_kr106_test.c -lm -o build/kr106-tests/cr_kr106_test
build/kr106-tests/cr_kr106_test
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=undefined tests/cr_kr106_dsp_test.c -o build/kr106-tests/cr_kr106_dsp_test
build/kr106-tests/cr_kr106_dsp_test
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
