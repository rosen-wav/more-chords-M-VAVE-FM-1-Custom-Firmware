#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/remix-tests/os build/host
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/remix-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/remix-tests"
fi
for name in cr_midi_perform_test cr_midi_chord_controls_test cr_midi_chord_base_test cr_midi_shared_lock_test; do
 "$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/remix-tests/$name
 build/remix-tests/$name
done
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
