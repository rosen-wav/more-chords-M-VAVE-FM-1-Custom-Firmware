#!/bin/sh
# True dual-patch PCM Morph replaces the historical parameter/overlap model.
# QUAD contains legacy signed left shifts: shift-base is excluded; eng_quad.c stays untouched.
set -eu
cd "$(dirname "$0")/.."
sh tests/test_velocity_dual_morph.sh
${CC:-cc} -O1 -w -fsanitize=undefined -fno-sanitize=shift-base -fno-sanitize-recover=all -Ibuild/new-feature-tests -Ibuild/gen -Itools/emu -pthread tests/cr_v8_audit_test.c -lm -o build/new-feature-tests/cr_v8_audit_test
build/new-feature-tests/cr_v8_audit_test
