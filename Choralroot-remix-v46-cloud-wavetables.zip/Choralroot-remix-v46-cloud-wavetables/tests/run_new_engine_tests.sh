#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/new-feature-tests/os
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/new-feature-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/new-feature-tests"
fi
for name in cr_v39_engines_test cr_v39_overlap_test cr_v39_morph_test cr_v39_user64_test cr_user64_backup_test cr_backup_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/new-feature-tests/$name
 build/new-feature-tests/$name
done
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=undefined tests/cr_v39_dsp_test.c -o build/new-feature-tests/cr_v39_dsp_test
build/new-feature-tests/cr_v39_dsp_test
${CC:-cc} -O2 -w tests/cr_user64_journal_test.c -o build/new-feature-tests/cr_user64_journal_test
build/new-feature-tests/cr_user64_journal_test
python3 tests/user64_clients_test.py
python3 tests/install_test.py
if command -v node >/dev/null 2>&1; then
 node tests/user64_clients_test.mjs
 node web/test_sounds.mjs
else
 echo 'SKIP: JavaScript client tests require Node.js'
fi
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
