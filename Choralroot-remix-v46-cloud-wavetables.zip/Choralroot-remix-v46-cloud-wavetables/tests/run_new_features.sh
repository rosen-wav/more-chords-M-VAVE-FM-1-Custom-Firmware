#!/bin/sh
# Selected host checks; no flashing and no legacy golden regeneration.
# Exercise the serial fallback here; run_dualcore_tests.sh covers six-voice CPU1 routing.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/new-feature-tests
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 mkdir -p build/new-feature-tests/os
 cat > build/new-feature-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/new-feature-tests"
fi
for name in cr_stage34_audio_reset_test cr_prophet_bass_test cr_fx_selection_test cr_crystal_bass_test cr_bass_engine_test cr_select_editor_test cr_hall_chain_test cr_gate_path_test cr_keys_only_test cr_keys_bass_test cr_keys_loop_bass_test cr_gate_test cr_sidechain_test cr_loop_transpose_test cr_swag_test cr_rosen_test cr_rosen_fx_test cr_chord_intelligence_test cr_cz_preset_repro_test cr_cz_overload_test cr_reverb_modes_test cr_backup_test cr_trans_test; do
 "$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/new-feature-tests/$name"
 "build/new-feature-tests/$name"
done
"$CC" -O2 -w -Ibuild/gen -Ifirmware/src tests/reverb_test.c -lm -o build/new-feature-tests/reverb_test
build/new-feature-tests/reverb_test build/new-feature-tests/reverb-demo

"$CC" -O2 -Wall -Wextra -Werror -std=c11 -pedantic tests/cr_settings_test.c firmware/src/cr_settings.c firmware/src/cr_engine.c -o build/new-feature-tests/cr_settings_test
build/new-feature-tests/cr_settings_test
"$CC" -O2 -Wall -Wextra -Werror tests/cr_midi_test.c -o build/new-feature-tests/cr_midi_test
build/new-feature-tests/cr_midi_test
"$CC" -O2 -Wall -Wextra -Werror tests/cr_bootguard_test.c -o build/new-feature-tests/cr_bootguard_test
build/new-feature-tests/cr_bootguard_test

"$CC" -std=c11 -Wall -Wextra -Werror -pedantic -O2 tests/cr_loop_test.c firmware/src/cr_loop.c firmware/src/cr_engine.c -o build/new-feature-tests/cr_loop_test
build/new-feature-tests/cr_loop_test

"$CC" -O2 -Wall -Wextra -Werror -Wno-unused-function tests/cr_uart_diag_test.c -o build/new-feature-tests/cr_uart_diag_test
build/new-feature-tests/cr_uart_diag_test

"$CC" -O1 -w -Ibuild/gen -Ifirmware/src tests/audio_test.c -lm -o build/new-feature-tests/audio_test
build/new-feature-tests/audio_test
