#!/bin/sh
# Host only: no flash and no golden regeneration.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/prophet-retrigger-tests/os build/host
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/prophet-retrigger-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/prophet-retrigger-tests"
fi
for velocity in fixed varied; do
 flag=""
 if [ "$velocity" = fixed ]; then flag="-DCONSTANT_VELOCITY"; fi
 "$CC" -O2 -w -DREQUIRE_DECLICK $flag -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread tests/cr_prophet_retrigger_test.c -lm -o "build/prophet-retrigger-tests/$velocity"
 "build/prophet-retrigger-tests/$velocity"
done
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
