#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/host
cc -std=c99 -Wall -Wextra -Werror -pedantic -O2 -fsanitize=signed-integer-overflow -fno-sanitize-recover=all -DFELUCCA_QUAD=1 -Ibuild/gen -o build/host/cr_quad_patchdiff tests/cr_quad_patchdiff.c -lm
./build/host/cr_quad_patchdiff | grep -E 'PATCHDIFF|cr_quad_test:'
