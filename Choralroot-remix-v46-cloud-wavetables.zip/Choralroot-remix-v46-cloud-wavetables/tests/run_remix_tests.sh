#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/remix-tests/os build/host
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/remix-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/remix-tests"
fi
for name in cr_remix_step_test cr_remix_simple_test cr_prophet_user_test cr_prophet_bass_test cr_keys_loop_bass_test cr_loop20_storage_test; do
 "$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/remix-tests/$name"
 "build/remix-tests/$name"
done
"$CC" -std=c11 -Wall -Wextra -Werror -pedantic -O2 tests/cr_step_grid_test.c firmware/src/cr_loop.c firmware/src/cr_engine.c -o build/remix-tests/cr_step_grid_test
build/remix-tests/cr_step_grid_test
python3 tests/loop20_clients_test.py
if command -v node >/dev/null 2>&1; then node tests/loop20_clients_test.mjs; fi
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
