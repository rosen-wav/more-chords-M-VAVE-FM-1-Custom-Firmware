#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/host
${CC:-cc} -std=c11 -O2 -w -ffp-contract=off tests/cr_sense_cast_compat_test.c -lm -o build/host/cr_sense_cast_compat_test
build/host/cr_sense_cast_compat_test
${CC:-cc} -std=c11 -O2 -w -ffp-contract=off tests/cr_velocity_sense_test.c -lm -o build/host/cr_velocity_sense_test
build/host/cr_velocity_sense_test
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done

${CC:-cc} -std=c11 -O2 -w -fsanitize=undefined -fno-sanitize-recover=all tests/cr_sense_integer_math_test.c -lm -o build/host/cr_sense_integer_math_test
build/host/cr_sense_integer_math_test
${CC:-cc} -std=c11 -O2 -w -fsanitize=undefined -fno-sanitize-recover=all tests/cr_velocity_sense_test.c -lm -o build/host/cr_velocity_sense_ubsan
build/host/cr_velocity_sense_ubsan
