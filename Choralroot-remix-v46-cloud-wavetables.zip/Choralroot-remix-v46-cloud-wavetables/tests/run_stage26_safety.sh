#!/bin/sh
# Host models only; never flashes, never regenerates golden audio.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/host
CC=${CC:-cc}
for name in cr_stub_test cr_usbaudio_test cr_power_test midi_uart_test; do
 "$CC" -O2 -w "tests/$name.c" -o "build/host/$name"
 "build/host/$name"
done
"$CC" -O2 -w -pthread tests/cr_worker_mailbox_test.c -o build/host/cr_worker_mailbox_test
build/host/cr_worker_mailbox_test
python3 tests/stub_pkg_test.py
python3 tests/stage26_fixture_packages.py
"$CC" -O2 -w tests/ldr_test.c -o build/host/ldr_test
build/host/ldr_test build/host/rescue-fixtures/old.fwsc build/host/rescue-fixtures/new.fwsc build/host/rescue-fixtures/same.fwsc build/host/rescue-fixtures/other.fwsc build/host/rescue-fixtures/old-stub.fwsc
"$CC" -O2 -w -DOWN_PKG tests/ota_test.c -o build/host/ota_test
build/host/ota_test build/host/rescue-fixtures/new.fwsc
