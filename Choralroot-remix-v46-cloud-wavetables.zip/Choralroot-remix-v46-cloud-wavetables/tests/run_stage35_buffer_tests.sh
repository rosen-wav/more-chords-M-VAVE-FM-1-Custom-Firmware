#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/stage35-tests/os
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/stage35-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/stage35-tests"
fi
for name in cr_stage34_audio_reset_test cr_gate_path_test cr_sidechain_test cr_loop_transpose_test; do
 "$CC" -O2 -w -DCHORALROOT_DUAL_CORE=0 $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/stage35-tests/$name"
 "build/stage35-tests/$name"
done
"$CC" -O1 -w -Ibuild/gen -Ifirmware/src tests/audio_test.c -lm -o build/stage35-tests/audio_test
build/stage35-tests/audio_test
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
printf 'PASS: target C syntax dual-core 0/1; assembly/linking and hardware timing need Mac target build\n'
