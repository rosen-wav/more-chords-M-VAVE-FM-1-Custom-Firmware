#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/stage36-tests/os
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/stage36-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/stage36-tests"
fi
for name in cr_prophet_optimization_test cr_gate_test cr_fx_selection_test; do
 "$CC" -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/stage36-tests/$name
 build/stage36-tests/$name
done
for flag in 0 1; do
 "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
