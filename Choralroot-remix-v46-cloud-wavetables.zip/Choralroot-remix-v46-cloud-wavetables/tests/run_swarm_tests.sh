#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/host build/new-feature-tests/os
extra=""
if [ "$(uname -s)" != Darwin ]; then
cat > build/new-feature-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
extra="-Ibuild/new-feature-tests"
fi
for name in cr_v30_swarm_test cr_v30_cloud_test cr_v30_cluster_test cr_v30_bass_test cr_v30_overlap_test cr_v30_cluster_overlap_test cr_v30_morph_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/host/$name
 build/host/$name
 if [ "$name" = cr_v30_morph_test ]; then build/host/$name cloud; build/host/$name cluster; fi
done
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
sh tests/run_boot_art_test.sh

${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src tests/cr_v30_dsp_test.c -o build/host/v30-dsp
build/host/v30-dsp
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all tests/cr_v30_cluster_math_test.c -o build/host/v30-math
build/host/v30-math
${CC:-cc} -std=gnu11 -O1 -w $extra -Ibuild/gen -Ifirmware/src -Itests tests/sound_templates.c -lm -o build/host/v30-templates
build/host/v30-templates --check web/fm1sounds.js tools/fm1_install.py
