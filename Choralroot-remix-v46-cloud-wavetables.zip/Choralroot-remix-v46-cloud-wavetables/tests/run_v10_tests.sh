#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_cs1_tests.sh
sh tests/run_kr106_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/cs1-tests"; fi
for name in cr_cs1_overlap_test cr_cs1_ui_test cr_engine_level_probe; do
 ${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/host/$name"
 "build/host/$name"
done
