#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_cs1_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/cs1-tests"; fi
for name in cr_cs1_overlap_test cr_cs1_bass_block_test cr_prophet_bass_test; do
 ${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/host/$name"
 "build/host/$name"
done
