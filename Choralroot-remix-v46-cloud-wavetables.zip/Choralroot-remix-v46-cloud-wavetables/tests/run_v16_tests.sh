#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_cs1_tests.sh
for test in cr_cs1_overlap_test cr_cs1_bass_block_test; do
 ${CC:-cc} -O2 -w -Ibuild/cs1-tests -Ibuild/gen -Itools/emu -pthread tests/$test.c -lm -o build/host/$test
 build/host/$test
done
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=undefined tests/cr_cs1_light_stress_test.c -o build/host/cs1_light_stress
build/host/cs1_light_stress
