#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_remix_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/remix-tests"; fi
${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_cs1_retired_test.c -lm -o build/host/cs1_retired
build/host/cs1_retired
${CC:-cc} -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_dualcore_test.c -lm -o build/host/v17_dualcore
build/host/v17_dualcore
node web/test_sounds.mjs
