#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_kr106_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
for name in cr_kr106_overlap_bass_test cr_three_parts_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/host/$name
 build/host/$name
done
${CC:-cc} -O1 -w -DKR_BASS_MATRIX $extra -Ibuild/gen -Itools/emu -pthread tests/cr_kr106_overlap_bass_test.c -lm -o build/host/kr_bass_matrix
build/host/kr_bass_matrix
sh tests/run_morph_tests.sh
sh tests/run_cloud_tests.sh
sh tests/run_remix_tests.sh
