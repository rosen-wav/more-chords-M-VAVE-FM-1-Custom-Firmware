#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_kr106_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
for name in cr_shared_chorus_test cr_kr106_overlap_bass_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread "tests/$name.c" -lm -o "build/host/$name"
 "build/host/$name"
done
