#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_kr106_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
mkdir -p build/v23-ui/ppm
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v23_test.c -lm -o build/host/v23-test
build/host/v23-test build/v23-ui
${CC:-cc} -O1 -w -Ibuild/gen -Ifirmware/src -Itests tests/cr_cloud_render_test.c -o build/host/v23-render
build/host/v23-render build/v23-ui
