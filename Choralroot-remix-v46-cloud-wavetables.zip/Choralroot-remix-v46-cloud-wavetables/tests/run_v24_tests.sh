#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v23_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
${CC:-cc} -O1 -w -fsanitize=undefined -fno-sanitize=shift-base -fno-sanitize-recover=all $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v24_chorus_test.c -lm -o build/host/v24-chorus-ubsan
build/host/v24-chorus-ubsan
