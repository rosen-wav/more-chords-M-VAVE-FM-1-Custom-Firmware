#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v24_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v25_chorus_test.c -lm -o build/host/v25-chorus
build/host/v25-chorus
