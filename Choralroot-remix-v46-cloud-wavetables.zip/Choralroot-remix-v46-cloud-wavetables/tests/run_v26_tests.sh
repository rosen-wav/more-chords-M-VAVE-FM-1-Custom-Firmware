#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v25_tests.sh
for name in cr_v26_cv_test cr_v26_dco_test; do
 ${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all "tests/$name.c" -o "build/host/$name"
 "build/host/$name"
done
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v26_worker_test.c -lm -o build/host/v26-worker
build/host/v26-worker
