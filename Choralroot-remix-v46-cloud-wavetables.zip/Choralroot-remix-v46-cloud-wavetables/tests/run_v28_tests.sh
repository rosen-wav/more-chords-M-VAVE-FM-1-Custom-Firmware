#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_kr106_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
for test in cr_v28_boot_test cr_v26_worker_test cr_kr106_overlap_bass_test; do
 ${CC:-cc} -O1 -w $extra -DKR_BASS_MATRIX -Ibuild/gen -Itools/emu -pthread tests/$test.c -lm -o build/host/$test
 build/host/$test
done
sh tests/run_boot_art_test.sh
