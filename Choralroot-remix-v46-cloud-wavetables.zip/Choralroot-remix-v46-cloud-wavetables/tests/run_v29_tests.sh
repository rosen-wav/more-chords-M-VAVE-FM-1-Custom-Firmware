#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v28_tests.sh
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ifirmware/src tests/cr_v29_filter_test.c -o build/host/v29-filter
build/host/v29-filter
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/kr106-tests"; fi
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v29_dc_test.c -lm -o build/host/v29-dc
build/host/v29-dc
