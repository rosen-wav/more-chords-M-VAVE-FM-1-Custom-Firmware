#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_swarm_tests.sh
for variant in optimized reference; do
 extra=""
 if [ "$variant" = reference ]; then extra="-DV31_REFERENCE"; fi
 ${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all $extra -Ibuild/gen -Ifirmware/src tests/cr_v32_equivalence_test.c -o build/host/v32-$variant
 build/host/v32-$variant > build/v32-$variant.log
done
diff -u build/v32-reference.log build/v32-optimized.log
cat build/v32-optimized.log
sh tests/run_v31_ui_tests.sh
