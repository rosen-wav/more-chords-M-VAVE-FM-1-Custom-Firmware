#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v32_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/new-feature-tests"; fi
for name in cr_v35_bridge_test cr_v35_cloud_overlap_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/host/$name
 build/host/$name
done
