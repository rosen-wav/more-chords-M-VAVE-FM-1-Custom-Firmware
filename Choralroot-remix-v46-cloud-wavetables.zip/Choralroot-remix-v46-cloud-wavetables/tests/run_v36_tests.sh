#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v35_tests.sh
${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src tests/cr_v36_cluster_light_test.c -o build/host/v36-light
build/host/v36-light
