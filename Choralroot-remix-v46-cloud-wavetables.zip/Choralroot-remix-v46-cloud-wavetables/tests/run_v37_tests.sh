#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_v36_tests.sh
