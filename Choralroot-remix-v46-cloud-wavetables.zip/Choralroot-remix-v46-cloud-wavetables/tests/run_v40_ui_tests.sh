#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/v40-ui/ppm build/v40-ui/os build/host
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/v40-ui/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/v40-ui"
fi
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v40_ui_test.c -lm -o build/host/v40_ui
build/host/v40_ui build/v40-ui
${CC:-cc} -O1 -w -Ibuild/gen -Ifirmware/src -Itests tests/cr_v40_render_test.c -o build/host/v40_render
build/host/v40_render build/v40-ui
for flag in 0 1; do
 ${CC:-cc} -DCHORALROOT_DUAL_CORE=$flag -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
