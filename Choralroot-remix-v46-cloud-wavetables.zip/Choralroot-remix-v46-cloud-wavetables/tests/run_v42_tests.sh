#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/run_new_engine_tests.sh
sh tests/run_v42_ui_tests.sh
sh tests/run_morph_tests.sh
extra=""
if [ "$(uname -s)" != Darwin ]; then extra="-Ibuild/new-feature-tests"; fi
for name in cr_v42_orbit_cpu_test cr_v42_cz_overlap_test cr_v42_features_test cr_v42_pages_test cr_keys_loop_bass_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/new-feature-tests/$name
 build/new-feature-tests/$name
done
for name in cr_cloud_dsp_test cr_v36_cluster_light_test cr_v41_params_test; do
 ${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src tests/$name.c -o build/new-feature-tests/$name
 build/new-feature-tests/$name
done
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/sound_templates.c -lm -o build/new-feature-tests/sound_templates
build/new-feature-tests/sound_templates --check web/fm1sounds.js tools/fm1_install.py
