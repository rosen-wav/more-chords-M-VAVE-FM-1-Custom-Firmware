#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/v43/os
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/v43/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/v43"
fi
for name in cr_cluster_register_test terrain_smooth_test; do
 ${CC:-cc} -O1 -fsanitize=undefined -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src tests/$name.c -o build/v43/$name
 build/v43/$name
done
${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_v42_orbit_cpu_test.c -lm -o build/v43/cpu
build/v43/cpu
sh tests/run_morph_tests.sh
