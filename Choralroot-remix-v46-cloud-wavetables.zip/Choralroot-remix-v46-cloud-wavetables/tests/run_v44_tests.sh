#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/v44/os
extra=""
if [ "$(uname -s)" != Darwin ]; then
 cat > build/v44/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
 extra="-Ibuild/v44"
fi
for name in cr_prophet_bass_test cr_cloud_bass_block_test; do
 ${CC:-cc} -O1 -w $extra -Ibuild/gen -Itools/emu -pthread tests/$name.c -lm -o build/v44/$name
 build/v44/$name
done
