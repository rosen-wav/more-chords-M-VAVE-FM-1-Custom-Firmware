#!/bin/sh
# Host validation only. No device access, flash, or golden regeneration.
set -eu
cd "$(dirname "$0")/.."
sh tests/run_morph_tests.sh
sh tests/run_remix_tests.sh
sh tests/run_creative_tests.sh
if command -v node >/dev/null 2>&1; then node web/test_sounds.mjs; fi
python3 tests/flash30_guard_test.py
sh tests/run_stage26_safety.sh
${CC:-cc} -std=c11 -Wall -Wextra -Werror -pedantic -O2 tests/cr_settings_test.c firmware/src/cr_settings.c firmware/src/cr_engine.c -o build/host/cr_settings_test
build/host/cr_settings_test
${CC:-cc} -std=c99 -Wall -Wextra -Werror -pedantic -O2 tests/cr_bootguard_test.c -o build/host/cr_bootguard_test
build/host/cr_bootguard_test
printf 'PASS: V8 host validation complete (target memory, analog ADC and hardware timing still require FM1 verification)\n'
