#!/bin/sh
# Complete host checks; no flash, hardware access or golden regeneration.
set -eu
cd "$(dirname "$0")/.."
sh tests/run_cs1_tests.sh
sh tests/run_v8_tests.sh
printf 'PASS: V9 CS-1 + inherited V8 host validation; FM1 target memory/timing remain unmeasured\n'
