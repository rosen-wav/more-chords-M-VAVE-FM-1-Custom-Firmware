"""Portable flash model fixtures only: synthetic stub code, NEVER flash these."""
from pathlib import Path
import sys, struct
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import fm1pkg_make as P
P.SDK=ROOT/'tools/sdk'
out=ROOT/'build/host/rescue-fixtures';out.mkdir(parents=True,exist_ok=True)
import build as B
# Synthetic loader image for protocol/CRC modelling only, not executable.
ota=B.ldr_wrap(bytes.fromhex('04818000')+b'FELUCCA-LOADER-1'+__import__('random').Random(26).randbytes(2000)*4)
stub=bytearray(b'\xff'*P.STUB_LEN);stub[:4]=bytes.fromhex('04818000');stub[8:14]=P.STUB_SIG;struct.pack_into('<H',stub,14,3)
body=bytes.fromhex('04818000')+bytes((i*17+3)&255 for i in range(320000))
for name,app in [('new',bytes(stub)+body),('same',bytes(stub)+bytes(x^0x5a for x in body)),('old',body),('other',bytes(x^0x5a for x in body))]:
 (out/(name+'.fwsc')).write_bytes(P.ufw(P.flash_image(app,P.KEY),ota,'FM-1_920'))
stub[-1]^=255;struct.pack_into('<H',stub,14,2)
(out/'old-stub.fwsc').write_bytes(P.ufw(P.flash_image(bytes(stub)+bytes(x^0x5a for x in body),P.KEY),ota,'FM-1_920'))
print('Created SYNTHETIC host fixtures; no executable device firmware.')
