/* SPDX-License-Identifier: GPL-3.0-only; V42 reference for regression testing. */
static void terrain_raw_reference(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 novel_voice_t *s=novel_state(t,v);unsigned map=(unsigned)clamp(t->p[P_E0],0,3);
 int32_t orbit=clamp(t->p[P_E1],0,127),motion=clamp(t->p[P_E2],0,127),depth=clamp(t->p[P_E3],0,127);
 uint32_t inc=m->inc;
 int32_t xoff=clamp(t->p[P_E4],-64,63)*16777216,yoff=clamp(t->p[P_E5],-64,63)*16777216;
 int32_t skew=clamp(t->p[P_E6],-64,63),smooth=clamp(t->p[P_E7],0,127);
 int32_t soften=inc>0x08000000u?(int32_t)((inc-0x08000000u)>>13):0;soften=clamp(soften,0,32767);
 for(uint32_t i=0;i<n;i++){
  int32_t cx=sine_i(s->ph[0]),cy=sine_i(s->ph[0]+0x40000000u+(uint32_t)(orbit*1048576));
  int32_t ox=sine_i(s->ph[1]),oy=sine_i(s->ph[1]+0x40000000u);
  uint32_t x=0x80000000u+(uint32_t)xoff+(uint32_t)(cx*(2048+orbit*96))+(uint32_t)(ox*depth*64);
  uint32_t y=0x80000000u+(uint32_t)yoff+(uint32_t)(cx*skew*128)+(uint32_t)(cy*(2048+orbit*64))+(uint32_t)(oy*depth*64);
  int32_t sample=novel_surface(map,x,y);sample=novel_lerp(sample,sine_i(s->ph[0]),(uint32_t)soften);s->tone+=(sample-s->tone)>>9;sample-=s->tone;
  if(smooth){s->target[0]+=((sample-s->target[0])*(32768-smooth*240))>>15;sample=s->target[0];}else s->target[0]=sample;novel_emit(out,i,sample,m);
  s->ph[0]+=inc;s->ph[1]+=10000u+(uint32_t)motion*1800u;
 }
}
