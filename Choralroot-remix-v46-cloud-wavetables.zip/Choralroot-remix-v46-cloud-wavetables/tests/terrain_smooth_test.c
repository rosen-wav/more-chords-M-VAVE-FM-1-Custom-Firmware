/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "felucca_tables.h"
#define CR_CPU1 0
#if defined(__APPLE__)
#define __attribute__(x)
#endif
#include "core.h"
#if defined(__APPLE__)
#undef __attribute__
#endif
#include "dsp.c"
#include "eng_cloud.c"
static cloud_part_t cp[NPART];
static cloud_part_t *cloud_part(uint32_t p){return &cp[p%NPART];}
#include "eng_novel.c"
static novel_part_t arena[NPART];
static novel_part_t *novel_part(uint32_t p){return &arena[p%NPART];}
#include "terrain_reference.h"
static void init(unsigned map,int x,int y){
 memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);
 for(unsigned p=0;p<2;p++){
  track_t *t=&trk[p];for(unsigned j=0;j<8;j++)t->p[P_E0+j]=TERRAIN_PRESETS[0].e[j];
  t->p[P_E0]=map;t->p[P_E4]=x;t->p[P_E5]=y;voice_was=0;novel_note(t,&t->v[0]);
  for(unsigned j=0;j<6;j++)arena[p].voice[0].ph[j]=0x12345678u+j*0x16543210u;
 }
}
int main(void){
 _Static_assert(sizeof(novel_voice_t)==132,"no per-voice RAM growth");
 uint64_t samples=0,old_jump=0,new_jump=0;
 vmod_t m={0};m.amp0=m.amp1=32767;m.shape=64*256;
 /* Static controls must produce exactly the V42 samples, across every surface/note. */
 for(unsigned map=0;map<4;map++)for(unsigned note=0;note<128;note++){
  init(map,17,-31);m.inc=pitch_inc(note*16);
  for(unsigned b=0;b<40;b++){int32_t a[CTL]={0},r[CTL]={0};terrain_raw(&trk[0],&trk[0].v[0],a,CTL,&m);terrain_raw_reference(&trk[1],&trk[1].v[0],r,CTL,&m);assert(!memcmp(a,r,sizeof a));samples+=CTL;}
 }
 /* At a nearly static trajectory, isolate the discontinuity introduced by editing. */
 m.inc=0;
 for(unsigned kind=0;kind<3;kind++)for(unsigned map=0;map<4;map++){
  init(map,-64,-64);int32_t before=0,old_before=0;
  for(unsigned b=0;b<128;b++){int32_t a=0,r=0;terrain_raw(&trk[0],&trk[0].v[0],&a,1,&m);terrain_raw_reference(&trk[1],&trk[1].v[0],&r,1,&m);assert(a==r);before=a;old_before=r;}
  unsigned k=kind==0?P_E0:kind==1?P_E4:P_E5;int value=kind==0?(map+2)%4:63;
  trk[0].p[k]=trk[1].p[k]=value;
  int32_t a=0,r=0;terrain_raw(&trk[0],&trk[0].v[0],&a,1,&m);terrain_raw_reference(&trk[1],&trk[1].v[0],&r,1,&m);
  new_jump+=llabs(a-before);old_jump+=llabs(r-old_before);
  for(unsigned i=0;i<10000;i++){int32_t out=0;terrain_raw(&trk[0],&trk[0].v[0],&out,1,&m);assert(llabs(out)<262144);samples++;}
  assert(arena[0].voice[0].drift[0]==trk[0].p[P_E0]*65536);
  assert(arena[0].voice[0].drift[1]==trk[0].p[P_E4]*65536);
  assert(arena[0].voice[0].drift[2]==trk[0].p[P_E5]*65536);
 }
 assert(old_jump && new_jump*10<old_jump);
 /* Rapid edits, every corner of all eight controls, all notes; PCM bounds under UBSan. */
 for(unsigned note=0;note<128;note++){
  init(0,0,0);m.inc=pitch_inc(note*16);
  for(unsigned b=0;b<1024;b++){
   for(unsigned j=0;j<8;j++)trk[0].p[P_E0+j]=(b&(1u<<j))?ENG_TERRAIN.edit[j].max:ENG_TERRAIN.edit[j].min;
   int32_t out[CTL+2]={0};out[0]=123456;out[CTL+1]=654321;terrain_raw(&trk[0],&trk[0].v[0],out+1,CTL,&m);
   assert(out[0]==123456&&out[CTL+1]==654321);for(unsigned j=1;j<=CTL;j++)assert(llabs(out[j])<262144);samples+=CTL;
  }
 }
 printf("PASS: %llu samples, unchanged static PCM, rapid control extremes, exact endpoints; edit-boundary jumps %llu -> %llu;132-byte voice state\n",(unsigned long long)samples,(unsigned long long)old_jump,(unsigned long long)new_jump);
}
