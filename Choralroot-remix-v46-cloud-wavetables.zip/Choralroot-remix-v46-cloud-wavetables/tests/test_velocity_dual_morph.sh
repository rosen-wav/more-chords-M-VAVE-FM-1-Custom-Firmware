#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/new-feature-tests/os
CC=${CC:-cc}
extra=""
if [ "$(uname -s)" != Darwin ]; then
  cat > build/new-feature-tests/os/lock.h <<'HEADER'
#include <pthread.h>
typedef pthread_mutex_t os_unfair_lock;
#define OS_UNFAIR_LOCK_INIT PTHREAD_MUTEX_INITIALIZER
#define os_unfair_lock_lock pthread_mutex_lock
#define os_unfair_lock_unlock pthread_mutex_unlock
#define os_unfair_lock_trylock(x) (!pthread_mutex_trylock(x))
HEADER
  extra="-Ibuild/new-feature-tests"
fi
"$CC" -O2 -w tests/cr_velocity_sense_test.c -lm -o build/new-feature-tests/cr_velocity_sense_test
build/new-feature-tests/cr_velocity_sense_test
"$CC" -O2 -w $extra -Ibuild/gen -Itools/emu -pthread tests/cr_dual_morph_test.c -lm -o build/new-feature-tests/cr_dual_morph_test
build/new-feature-tests/cr_dual_morph_test
for flag in 0 1; do
  "$CC" -DCHORALROOT_DUAL_CORE="$flag" -fsyntax-only -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal firmware/src/choralroot.c
done
printf 'PASS: sensor, available dual Morph engines, and both firmware C configurations (syntax only)\n'
