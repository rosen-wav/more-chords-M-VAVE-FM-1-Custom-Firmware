import assert from 'node:assert/strict';import fs from 'node:fs';
import {extDecode,extEncode,extGet,extKind} from '../web/fm1user64.js';
import {SOUND_IDS,SOUND_SLOTS,importSound,renameSound,deleteSound,exportSound,parseSoundObjects} from '../web/fm1sounds.js';
const raw=new Uint8Array(fs.readFileSync('build/user64-fixture.bin')),records=new Uint8Array(fs.readFileSync('build/user64-records.bin'));
let m=new Map(SOUND_IDS.map(i=>[i,new Uint8Array(0)]));m.set(70,raw.slice(0,3840));m.set(71,raw.slice(3840));assert.equal(SOUND_SLOTS,64);
for(let j=0;j<32;j++){
 const slot=33+j,p=raw.slice(j*240,(j+1)*240),{record,patch}=extDecode(p);
 assert.deepEqual(record,records.slice(j*192,(j+1)*192));assert.deepEqual(extEncode(record,patch),p);
 assert.equal(parseSoundObjects(m).slots[slot-1].used,true);exportSound(m,slot);
 m=renameSound(m,slot,'RENAMED').objs;assert.equal(String.fromCharCode(...extGet(m,slot).record.slice(4,11)),'RENAMED');
 m=importSound(m,slot,{record,patch:patch.length?patch:null}).objs;assert.deepEqual(extGet(m,slot).record,record);
 m=deleteSound(m,slot).objs;assert.equal(extGet(m,slot).record[0],0);
}
assert.equal(m.get(6).length,0);assert.equal(m.get(7).length,0);
console.log('PASS: JS USER64 codec matches 32 firmware records; all native patch kinds, export/import/rename/delete');
