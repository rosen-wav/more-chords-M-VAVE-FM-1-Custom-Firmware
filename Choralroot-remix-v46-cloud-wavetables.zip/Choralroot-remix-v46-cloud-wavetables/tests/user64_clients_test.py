from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import fm1_install as f
import user64_codec as c
raw=Path('build/user64-fixture.bin').read_bytes();records=Path('build/user64-records.bin').read_bytes();objs={i:b'' for i in f.SOUND_IDS};objs.update({70:raw[:3840],71:raw[3840:]})
assert f.SOUND_SLOTS==64
for j in range(32):
 slot=33+j;p=raw[j*240:(j+1)*240];r,b=c.decode(p);expected=records[j*192:(j+1)*192]
 assert r==expected,(slot,r[2])
 assert c.encode(r,b)==p
 assert f._record(objs,slot)==r
 kind=c.KINDS.get(r[2]);assert not kind or f._store_blob(objs,kind,slot)==b
 exported=f.export_sound(objs,slot,"test")
 for ident,data in f.rename_sound(objs,slot,'RENAMED'):objs[ident]=data
 assert f._record(objs,slot)[4:11]==b'RENAMED'
 patch=(kind,b) if kind else None
 for ident,data in f.import_sound(objs,slot,(r,'name',r[2],patch)):objs[ident]=data
 assert f._record(objs,slot)==r
 for ident,data in f.delete_sound(objs,slot):objs[ident]=data
 assert not f._record(objs,slot)[0]
assert not objs[6] and not objs[7]
print('PASS: Python USER64 codec matches 32 firmware records; all native patch kinds, export/import/rename/delete')
