#!/usr/bin/env python3
"""Compile the real physical-key wrapper against deterministic sensor stubs."""
from pathlib import Path
import subprocess, os
root=Path(__file__).resolve().parents[1]
s=(root/'firmware/src/choralroot.c').read_text()
a=s.index('static uint8_t cr_velocity_key(');b=s.index('\n}\n',a)+3
wrapper=s[a:b]
code=r'''#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "cr_velocity_curve.h"
enum{SN_DOWN=2};
static struct{uint8_t st,vel;}sn_key[27];
static uint8_t analog[27],probe[27];
static int sense_is_analog(uint32_t k){return analog[k];}
static uint8_t sense_probe_velocity(uint32_t k){return probe[k];}
''' +wrapper+r'''
int main(void){
 assert(cr_velocity_soft(0)==0);assert(cr_velocity_soft(1)==25);
 assert(cr_velocity_soft(32)==50);assert(cr_velocity_soft(64)==76);
 assert(cr_velocity_soft(96)==102);assert(cr_velocity_soft(127)==127);
 for(unsigned v=1;v<=127;v++){assert(cr_velocity_soft(v)>=v);assert(cr_velocity_soft(v)>=cr_velocity_soft(v-1));}
 unsigned cases=0;
 for(unsigned k=0;k<27;k++)for(unsigned mode=0;mode<2;mode++){
  analog[k]=mode;sn_key[k].st=SN_DOWN;
  for(unsigned v=1;v<=127;v++){sn_key[k].vel=probe[k]=v;assert(cr_velocity_key(k,100)==cr_velocity_soft(v));cases++;}
  sn_key[k].vel=probe[k]=0;assert(cr_velocity_key(k,100)==100);
  sn_key[k].st=0;sn_key[k].vel=127;if(mode)assert(cr_velocity_key(k,100)==100);
 }
 assert(cr_velocity_key(27,83)==83);
 printf("PASS: %u physical sensor-wrapper fixtures; monotonic soft curve, exact endpoints, zero/fallback, analog/probe keys\n",cases);
}
'''
out=root/'build/host';out.mkdir(parents=True,exist_ok=True)
p=out/'velocity_soft_test.c';p.write_text(code)
subprocess.run([os.environ.get('CC','cc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(root/'firmware/src'),str(p),'-o',str(out/'velocity_soft_test')],check=True)
subprocess.run([str(out/'velocity_soft_test')],check=True)
