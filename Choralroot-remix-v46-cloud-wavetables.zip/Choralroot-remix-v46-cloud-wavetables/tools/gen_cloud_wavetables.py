#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Offline only; float math never enters firmware or PI32V2 linking.
import math
from pathlib import Path
spectra=[[[1, 0.18, 0.08, 0, 0, 0], [1, 0.35, 0.16, 0.05, 0, 0], [1, 0.5, 0.28, 0.12, 0.05, 0], [1, 0.65, 0.38, 0.2, 0.1, 0.04]], [[1, 0, 0.5, 0, 0.3, 0], [0.7, 0.4, 0, 0.6, 0, 0.3], [0.5, 0, 0.8, 0.2, 0, 0.6], [0.4, 0.6, 0.2, 0.8, 0.3, 0.5]], [[1, 0, 0.33, 0, 0.2, 0], [1, 0, 0.7, 0, 0.12, 0], [0.6, 0, 1, 0, 0.5, 0], [1, 0.08, 0.5, 0, 0.8, 0]], [[1, 0.6, -0.3, 0.2, 0, 0.1], [0.8, -0.5, 0.7, 0, 0.4, 0], [0.5, 0.4, -0.8, 0.6, 0, 0.5], [0.8, -0.7, 0.6, -0.5, 0.4, -0.3]]]
tables=[]
for bank in spectra:
 bands=[]
 for harmonics in [6,2]:
  frames=[]
  for spec in bank:
   v=[sum(spec[h-1]*math.sin(2*math.pi*h*i/32) for h in range(1,harmonics+1)) for i in range(32)]
   peak=max(map(abs,v));frames.append([round(x*28000/peak) for x in v])
  bands.append(frames)
 tables.append(bands)
def braces(v):return '{'+','.join(braces(x) if isinstance(x,list) else str(x) for x in v)+'}'
p=Path(__file__).resolve().parents[1]/'firmware/src/cloud_wavetables.h'
p.write_text("#pragma once\n/* SPDX-License-Identifier: GPL-3.0-only\n * Original additive CLOUD spectra. Offline-generated, 2048 bytes.\n * 4 banks x 2 pitch bands x 4 frames x 32 samples; max 6 / 2 partials. */\nstatic const int16_t CLOUD_TABLES[4][2][4][32]="+braces(tables)+';\n')
print('Generated',p)
