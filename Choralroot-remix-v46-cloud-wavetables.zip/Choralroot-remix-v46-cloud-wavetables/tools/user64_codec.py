# SPDX-License-Identifier: GPL-3.0-only
"""UPX layout 1: firmware/src/user_ext.c. Original 32 records stay unchanged."""
SCHEMA = [[0,127,104],[0,127,10],[0,127,70],[0,127,90],[0,127,60],[-64,63,0],[-64,63,0],[-64,63,0],[-64,63,0],[0,127,60],[0,4,0],[0,127,0],[0,127,0],[-64,63,0],[-64,63,0],[-64,63,0],[0,127,0],[0,6,0],[0,9,2],[1,4,1],[1,127,64],[0,100,0],[0,127,127],[0,1,0],[0,1,0],[0,11,0],[0,15,0],[0,3,0],[-24,24,0],[1,64,16],[0,9,2],[0,100,0],[1,127,64],[0,127,0],[0,127,0],[0,127,0],[0,127,0],[0,3,0],[0,127,0],[-64,63,0],[0,1,0],[0,1,0],[0,2,0],[0,1,0],[0,127,40],[0,2,0],[1,16,1],[0,5,1],[0,127,127],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,9,0],[0,4,0]]  # generated below from firmware descriptors
KINDS = {12:'fm6',13:'va',14:'cz',15:'quad'}
SIZES = {12:128,13:110,14:144,15:80}
def _value(r,k):
    if r[2]==24 and k>=r[3]-8 and r[158:160]==b'CL':
        a=128+2*(k-(r[3]-8));return int.from_bytes(r[a:a+2],'little',signed=True)
    if r[2]==19 and k==r[3]-1 and r[158:160]==b'M9':return r[156]|r[157]<<7
    return r[16+k]-64 if r[1]>=4 else (r[16+k] if r[16+k]<128 else r[16+k]-256)
def _set(r,k,v):
    if r[2]==24 and k>=83:
        a=128+2*(k-83);r[a:a+2]=int(v).to_bytes(2,'little',signed=True);r[158:160]=b'CL';v=0
    if r[2]==19 and k==90:
        v=max(0,min(16383,v));r[156:160]=bytes((v&127,v>>7,77,57));v=min(127,v)
    r[16+k]=(v+64)&255
def decode(p):
    if not p or len(p)!=240 or not p[0]:return bytes(192),b''
    if p[0]!=165 or p[1]!=1 or p[3]!=91:raise ValueError('Unknown extended USER record')
    r=bytearray(192);r[:16]=p[:16];r[1]=4;r[175]=p[16];r[191]=p[17]
    bits=int.from_bytes(p[18:77],'little');at=0
    for k,(lo,hi,default) in enumerate(SCHEMA):
        width=(hi-lo).bit_length();v=(bits>>at)&((1<<width)-1);at+=width
        if v>hi-lo:raise ValueError('Invalid extended USER parameter')
        _set(r,k,lo+v)
    for k in range(8):_set(r,83+k,int.from_bytes(p[77+2*k:79+2*k],'little',signed=True))
    n=p[93]
    if n>144:raise ValueError('Invalid extended USER patch length')
    aux=bytes(p[94:94+n])
    if r[2]==16 and n==53:r[107:160]=aux;aux=b''
    elif n and n!=SIZES.get(r[2]):raise ValueError('Wrong native patch in extended USER record')
    return bytes(r),aux
def encode(r,aux=b''):
    p=bytearray(240)
    if not r or not r[0]:return bytes(p)
    if len(r)!=192 or r[1] not in (1,2,4) or not 8<=r[3]<=144:raise ValueError('Save this legacy sound on the FM-1 before moving it to U33..U64')
    if any(r[160:175]) or any(r[176:191]):raise ValueError('U33..U64 store sounds, not legacy Felucca patterns')
    p[:16]=r[:16];p[1]=1;p[3]=91;p[16]=r[175];p[17]=r[191];nc=r[3]-8;bits=at=0
    for k,(lo,hi,default) in enumerate(SCHEMA):
        v=_value(r,k) if k<nc else default
        if not lo<=v<=hi:raise ValueError('USER common parameter out of range')
        width=(hi-lo).bit_length();bits|=(v-lo)<<at;at+=width
    p[18:77]=bits.to_bytes(59,'little')
    for k in range(8):p[77+2*k:79+2*k]=_value(r,nc+k).to_bytes(2,'little',signed=True)
    if r[2]==16 and r[158:160]==b'P5':aux=r[107:160]
    if len(aux)>144 or (aux and not (r[2]==16 and len(aux)==53) and len(aux)!=SIZES.get(r[2])):raise ValueError('Wrong native USER patch')
    p[93]=len(aux);p[94:94+len(aux)]=aux;return bytes(p)
def get(objs,slot):
    raw=objs.get(70+(slot-33)//16,b'');off=((slot-33)%16)*240
    return decode(raw[off:off+240]) if len(raw)==3840 else (bytes(192),b'')
def put(objs,slot,rec,aux=None):
    i=70+(slot-33)//16
    if i not in objs:raise ValueError('Connected firmware does not offer U33..U64; update it first')
    if aux is None:aux=get(objs,slot)[1]
    raw=bytearray(objs[i]) if len(objs[i])==3840 else bytearray(3840);off=((slot-33)%16)*240
    raw[off:off+240]=encode(rec,aux);objs[i]=bytes(raw)
