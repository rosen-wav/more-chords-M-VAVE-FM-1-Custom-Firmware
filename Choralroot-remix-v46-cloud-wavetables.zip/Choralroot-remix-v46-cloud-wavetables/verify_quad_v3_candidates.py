#!/usr/bin/env python3
"""Read-only verification of 12 QUAD v3 patch candidates; NOT an audio validation."""
import json, pathlib, hashlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
LEGACY=ROOT/'tests'/'quad_goldens'
PRE=ROOT/'quad_v3_preset_candidates'
ALG=ROOT/'quad_v3_algo_candidates'
CHANGES={
'ep':{3:(35,3),5:(10,12),7:(0,-30),13:(80,78),14:(24,20),15:(72,66),17:(46,52),19:(44,62),28:(0,40),29:(40,30),36:(0,1)},
'bass':{3:(22,3),6:(30,24),7:(0,-64),14:(30,34),15:(86,88),19:(40,0),36:(0,1)},
'glass_pad':{3:(25,6),15:(60,36),19:(40,50),23:(1,0),36:(0,1),46:(92,88),50:(1,11)},
'wobble':{3:(22,3),6:(20,10),7:(0,-64),19:(30,0),36:(0,3),50:(11,15),58:(7,25)}}
TAIL={'ep':[16,30],'bass':[3,0],'glass_pad':[6,0],'wobble':[3,0]}
def main():
    count=0
    for name in [f'algo{i}' for i in range(1,9)]+list(CHANGES):
        raw=(LEGACY/(name+'.json')).read_bytes()
        old=json.loads(raw)['patch']
        folder=PRE if name in CHANGES else ALG
        obj=json.loads((folder/(name+'.patch.json')).read_text())
        new=obj['patch']
        assert len(old)==71 and len(new)==73, f'{name}: wrong patch size'
        if name in CHANGES:
            expected=list(old)
            for idx,(before,after) in CHANGES[name].items():
                assert expected[idx]==before, f'{name}: old index {idx} mismatch'
                expected[idx]=after
            expected+=TAIL[name]
        else:
            expected=list(old)+[3,0]
        assert new==expected, f'{name}: unexpected patch modification'
        hash_key='source_legacy_sha256' if name in CHANGES else 'legacy_sha256'
        assert obj.get(hash_key)==hashlib.sha256(raw).hexdigest(), f'{name}: source hash mismatch'
        assert obj.get('audio_validated') is False, f'{name}: must be explicitly unvalidated'
        print(f'PATCHCHECK {name}: OK 73 params; audio NOT validated')
        count+=1
    print(f'PATCHCHECK RESULT: {count}/12 candidates consistent. NO audio validation performed.')
    print('READ ONLY: no firmware, tables, golden, or candidate files changed.')
if __name__=='__main__':
    try: main()
    except Exception as e:
        print('PATCHCHECK FAIL:',e,file=sys.stderr)
        sys.exit(1)
