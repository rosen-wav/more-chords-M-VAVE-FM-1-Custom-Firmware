// SPDX-License-Identifier: GPL-3.0-only
// UPX layout 1, kept in sync with firmware/src/user_ext.c.
const SCHEMA = [[0,127,104],[0,127,10],[0,127,70],[0,127,90],[0,127,60],[-64,63,0],[-64,63,0],[-64,63,0],[-64,63,0],[0,127,60],[0,4,0],[0,127,0],[0,127,0],[-64,63,0],[-64,63,0],[-64,63,0],[0,127,0],[0,6,0],[0,9,2],[1,4,1],[1,127,64],[0,100,0],[0,127,127],[0,1,0],[0,1,0],[0,11,0],[0,15,0],[0,3,0],[-24,24,0],[1,64,16],[0,9,2],[0,100,0],[1,127,64],[0,127,0],[0,127,0],[0,127,0],[0,127,0],[0,3,0],[0,127,0],[-64,63,0],[0,1,0],[0,1,0],[0,2,0],[0,1,0],[0,127,40],[0,2,0],[1,16,1],[0,5,1],[0,127,127],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,8,0],[0,19,0],[-64,63,0],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,127,0],[0,127,0],[0,127,127],[0,127,0],[0,127,127],[0,9,0],[0,4,0]];
const sizes={12:128,13:110,14:144,15:80};
export const extKind={12:'fm6',13:'va',14:'cz',15:'quad'};
const val=(r,k)=>{
 if(r[2]===24&&k>=r[3]-8&&r[158]===67&&r[159]===76){const a=128+2*(k-r[3]+8);return new DataView(r.buffer,r.byteOffset).getInt16(a,true);}
 if(r[2]===19&&k===r[3]-1&&r[158]===77&&r[159]===57)return r[156]|r[157]<<7;
 return r[1]>=4?r[16+k]-64:r[16+k]<128?r[16+k]:r[16+k]-256;
};
function set(r,k,v){
 if(r[2]===24&&k>=83){new DataView(r.buffer).setInt16(128+2*(k-83),v,true);r[158]=67;r[159]=76;v=0;}
 if(r[2]===19&&k===90){v=Math.max(0,Math.min(16383,v));r.set([v&127,v>>7,77,57],156);v=Math.min(127,v);}
 r[16+k]=(v+64)&255;
}
const width=(lo,hi)=>hi===lo?0:32-Math.clz32(hi-lo);
function bits(p,at,n,v){let x=0;for(let j=0;j<n;j++){const byte=(at+j)>>3,mask=1<<((at+j)&7);if(v===undefined){if(p[byte]&mask)x|=1<<j;}else if(v&(1<<j))p[byte]|=mask;else p[byte]&=~mask;}return x;}
export function extDecode(p){
 const r=new Uint8Array(192);if(!p||p.length!==240||!p[0])return {record:r,patch:new Uint8Array(0)};
 if(p[0]!==165||p[1]!==1||p[3]!==91)throw Error('Unknown extended USER record');
 r.set(p.subarray(0,16));r[1]=4;r[175]=p[16];r[191]=p[17];let at=144;
 SCHEMA.forEach(([lo,hi],k)=>{const n=width(lo,hi),v=bits(p,at,n);at+=n;if(v>hi-lo)throw Error('Invalid extended USER parameter');set(r,k,lo+v);});
 const view=new DataView(p.buffer,p.byteOffset,p.byteLength);for(let k=0;k<8;k++)set(r,83+k,view.getInt16(77+2*k,true));
 const n=p[93];if(n>144)throw Error('Invalid extended USER patch length');let patch=p.slice(94,94+n);
 if(r[2]===16&&n===53){r.set(patch,107);patch=new Uint8Array(0);}else if(n&&n!==sizes[r[2]])throw Error('Wrong native patch');
 return {record:r,patch};
}
export function extEncode(r,patch=new Uint8Array(0)){
 const p=new Uint8Array(240);if(!r||!r[0])return p;
 if(r.length!==192||![1,2,4].includes(r[1])||r[3]<8||r[3]>144)throw Error('Save this legacy sound on the FM-1 before moving it to U33..U64');
 if(r.slice(160,175).some(x=>x)||r.slice(176,191).some(x=>x))throw Error('U33..U64 store sounds, not legacy Felucca patterns');
 p.set(r.subarray(0,16));p[1]=1;p[3]=91;p[16]=r[175];p[17]=r[191];let at=144;const nc=r[3]-8;
 SCHEMA.forEach(([lo,hi,def],k)=>{const v=k<nc?val(r,k):def;if(v<lo||v>hi)throw Error('USER parameter out of range');const n=width(lo,hi);bits(p,at,n,v-lo);at+=n;});
 const view=new DataView(p.buffer);for(let k=0;k<8;k++)view.setInt16(77+2*k,val(r,nc+k),true);
 if(r[2]===16&&r[158]===80&&r[159]===53)patch=r.slice(107,160);
 if(patch.length>144||(patch.length&&!(r[2]===16&&patch.length===53)&&patch.length!==sizes[r[2]]))throw Error('Wrong native USER patch');
 p[93]=patch.length;p.set(patch,94);return p;
}
export function extGet(m,slot){const p=m.get(70+Math.floor((slot-33)/16)),at=((slot-33)%16)*240;return extDecode(p?.length===3840?p.subarray(at,at+240):null);}
export function extPut(m,slot,r,patch){const id=70+Math.floor((slot-33)/16);if(!m.has(id))throw Error('Update firmware for U33..U64');if(patch===undefined)patch=extGet(m,slot).patch;const old=m.get(id),p=old?.length===3840?old.slice():new Uint8Array(3840);p.set(extEncode(r,patch),((slot-33)%16)*240);m.set(id,p);}
