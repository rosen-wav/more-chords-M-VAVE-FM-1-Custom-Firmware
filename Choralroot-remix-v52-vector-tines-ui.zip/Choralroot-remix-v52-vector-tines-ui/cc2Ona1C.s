	.file	"cr_loop.c"
	.text
	.type	crl_zero, @function
crl_zero:
.LFB0:
	.cfi_startproc
	testl	%esi, %esi
	je	.L8
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	leal	-1(%rsi), %eax
	movl	%eax, %eax
	leaq	1(%rdi,%rax), %rdx
	jmp	.L5
.L6:
	movq	%rax, %rdi
.L5:
	leaq	1(%rdi), %rax
	cmpq	$-1, %rdi
	jnb	.L11
	leaq	1(%rdi), %rax
	testq	%rdi, %rdi
	je	.L12
	movb	$0, -1(%rax)
	cmpq	%rdx, %rax
	jne	.L6
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L11:
	.cfi_restore_state
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data37(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L12:
	movl	$0, %esi
	leaq	.Lubsan_data38(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L8:
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE0:
	.size	crl_zero, .-crl_zero
	.type	crl_hide, @function
crl_hide:
.LFB9:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L14
	testb	$7, %dil
	jne	.L14
	leaq	14(%rdi), %rdx
	cmpq	$-14, %rdi
	jnb	.L21
	movzbl	14(%rdi), %eax
	cmpl	$511, %esi
	ja	.L22
	orl	$-128, %eax
	movl	%esi, %edx
	leaq	153(%rdi,%rdx,8), %rdx
	cmpq	%rdi, %rdx
	jb	.L23
	movl	%esi, %esi
	movb	%al, 153(%rdi,%rsi,8)
	leaq	4700(%rdi), %rdx
	cmpq	$-4700, %rdi
	jnb	.L24
	addw	$1, 4700(%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L14:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data39(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L21:
	movq	%rdi, %rsi
	leaq	.Lubsan_data40(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L22:
	movl	%esi, %esi
	leaq	.Lubsan_data41(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L23:
	movq	%rdi, %rsi
	leaq	.Lubsan_data42(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L24:
	movq	%rdi, %rsi
	leaq	.Lubsan_data43(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE9:
	.size	crl_hide, .-crl_hide
	.type	crl_lev0_scan, @function
crl_lev0_scan:
.LFB11:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rsi
	movl	$4616, %r9d
	movl	$0, %edx
	movl	$0, %edi
	movq	%rsi, %r10
	andl	$7, %r10d
	leaq	12(%rsi), %r11
	jmp	.L26
.L44:
	movl	%edx, %esi
	leaq	.Lubsan_data44(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L29:
	cmpq	%rcx, %rsi
	jb	.L31
.L30:
	movzbl	(%rsi,%rax), %ecx
	andl	$31, %ecx
	cmpl	%edi, %ecx
	jnb	.L27
	addl	$1, %edx
	addq	$8, %rax
	cmpl	%r8d, %edx
	je	.L42
.L41:
	cmpl	$511, %edx
	ja	.L44
	leaq	(%rsi,%rax), %rcx
	testq	%rax, %rax
	js	.L29
	cmpq	%rsi, %rcx
	jnb	.L30
.L31:
	movq	%rcx, %rdx
	leaq	.Lubsan_data45(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L42:
	movl	%r8d, %edx
.L27:
	cmpl	$31, %edi
	ja	.L45
	movl	%edx, %ecx
	leaq	(%rsi,%r9), %rax
	testq	%r9, %r9
	js	.L34
	cmpq	%rsi, %rax
	jnb	.L35
.L36:
	movq	%rax, %rdx
	leaq	.Lubsan_data47(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L45:
	movl	%edi, %esi
	leaq	.Lubsan_data46(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L34:
	cmpq	%rax, %rsi
	jb	.L36
.L35:
	movw	%cx, (%rsi,%r9)
	addl	$1, %edi
	addq	$2, %r9
	cmpl	$32, %edi
	je	.L25
.L26:
	testq	%rsi, %rsi
	je	.L38
	testq	%r10, %r10
	jne	.L38
	cmpq	$-12, %rsi
	jnb	.L46
	movzwl	12(%rsi), %r8d
	cmpl	%r8d, %edx
	jnb	.L27
	movl	%edx, %eax
	leaq	153(,%rax,8), %rax
	jmp	.L41
.L38:
	leaq	.Lubsan_data48(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L46:
	movq	%r11, %rdx
	leaq	.Lubsan_data49(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L25:
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11:
	.size	crl_lev0_scan, .-crl_lev0_scan
	.type	crl_restore, @function
crl_restore:
.LFB12:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rax
	testq	%rdi, %rdi
	je	.L48
	movl	%esi, %r11d
	testb	$7, %dil
	jne	.L48
	leaq	12(%rdi), %rdx
	cmpq	$-12, %rdi
	jnb	.L74
	movzwl	12(%rdi), %edx
	movzwl	%dx, %r9d
	testw	%dx, %dx
	je	.L47
	leal	-1(%rsi), %ebx
	movl	%ebx, %edx
	leaq	4616(%rdx,%rdx), %rbp
	movl	$153, %edi
	movl	$0, %esi
	movl	%r11d, %r10d
	orl	$-128, %r10d
	leaq	4700(%rax), %r12
	jmp	.L69
.L48:
	movq	%rax, %rsi
	leaq	.Lubsan_data50(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L74:
	movq	%rdi, %rsi
	leaq	.Lubsan_data51(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L76:
	movl	%esi, %esi
	leaq	.Lubsan_data52(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L53:
	cmpq	%rdx, %rax
	jb	.L55
.L54:
	cmpb	%r10b, (%rax,%rdi)
	je	.L75
.L56:
	addl	$1, %esi
	addq	$8, %rdi
	cmpl	%r9d, %esi
	je	.L47
.L69:
	cmpl	$511, %esi
	ja	.L76
	leaq	(%rax,%rdi), %rdx
	testq	%rdi, %rdi
	js	.L53
	cmpq	%rax, %rdx
	jnb	.L54
.L55:
	movq	%rax, %rsi
	leaq	.Lubsan_data53(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L75:
	testl	%r11d, %r11d
	je	.L70
	testl	%ebx, %ebx
	je	.L77
	movq	%rbp, %rdx
	movl	%ebx, %ecx
	jmp	.L58
.L77:
	movl	%ebx, %ecx
	jmp	.L57
.L78:
	movl	%ecx, %esi
	leaq	.Lubsan_data54(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L60:
	cmpq	%r8, %rax
	jb	.L62
.L61:
	movzwl	(%rax,%rdx), %r8d
	cmpl	%r8d, %esi
	jnb	.L57
	subq	$2, %rdx
	subl	$1, %ecx
	je	.L57
.L58:
	cmpl	$31, %ecx
	ja	.L78
	leaq	(%rax,%rdx), %r8
	testq	%rdx, %rdx
	js	.L60
	cmpq	%rax, %r8
	jnb	.L61
.L62:
	movq	%r8, %rdx
	movq	%rax, %rsi
	leaq	.Lubsan_data55(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L70:
	movl	%r11d, %ecx
.L57:
	cmpl	$511, %esi
	ja	.L79
	leaq	(%rax,%rdi), %rdx
	testq	%rdi, %rdi
	js	.L65
	cmpq	%rax, %rdx
	jnb	.L66
.L67:
	movq	%rax, %rsi
	leaq	.Lubsan_data57(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L79:
	movl	%esi, %esi
	leaq	.Lubsan_data56(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L65:
	cmpq	%rdx, %rax
	jb	.L67
.L66:
	movb	%cl, (%rax,%rdi)
	cmpq	$-4700, %rax
	jnb	.L80
	addw	$1, 4700(%rax)
	jmp	.L56
.L80:
	movq	%r12, %rdx
	movq	%rax, %rsi
	leaq	.Lubsan_data58(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L47:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE12:
	.size	crl_restore, .-crl_restore
	.type	crl_take_start, @function
crl_take_start:
.LFB18:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L82
	testb	$7, %dil
	jne	.L82
	leaq	4680(%rdi), %rdx
	cmpq	$-4680, %rdi
	jnb	.L89
	cmpb	$0, 4680(%rdi)
	je	.L81
	movb	$0, 4680(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 16(%rdi)
	movw	$0, 12(%rdi)
	movl	$0, 8(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 4244(%rdi)
	leaq	4712(%rdi), %rdx
	cmpq	$-4712, %rdi
	jnb	.L90
	movb	$0, 4712(%rdi)
	leaq	4713(%rdi), %rdx
	cmpq	$-4713, %rdi
	jnb	.L91
	movb	$1, 4713(%rdi)
	addw	$1, 4700(%rdi)
.L81:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L82:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data59(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L89:
	movq	%rdi, %rsi
	leaq	.Lubsan_data60(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L90:
	movq	%rdi, %rsi
	leaq	.Lubsan_data61(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L91:
	movq	%rdi, %rsi
	leaq	.Lubsan_data62(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE18:
	.size	crl_take_start, .-crl_take_start
	.type	crl_put16, @function
crl_put16:
.LFB43:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L97
	movb	%sil, (%rdi)
	shrl	$8, %esi
	leaq	1(%rdi), %rdx
	cmpq	$-1, %rdi
	jnb	.L98
	je	.L99
	movb	%sil, 1(%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L97:
	.cfi_restore_state
	movl	$0, %esi
	leaq	.Lubsan_data63(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L98:
	movq	%rdi, %rsi
	leaq	.Lubsan_data64(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L99:
	movl	$0, %esi
	leaq	.Lubsan_data65(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
	.cfi_endproc
.LFE43:
	.size	crl_put16, .-crl_put16
	.type	crl_get16, @function
crl_get16:
.LFB45:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L105
	movzbl	(%rdi), %edx
	leaq	1(%rdi), %rax
	cmpq	$-1, %rdi
	jnb	.L106
	je	.L107
	movzbl	1(%rdi), %eax
	sall	$8, %eax
	orl	%edx, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L105:
	.cfi_restore_state
	movl	$0, %esi
	leaq	.Lubsan_data66(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L106:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data67(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L107:
	movl	$0, %esi
	leaq	.Lubsan_data68(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
	.cfi_endproc
.LFE45:
	.size	crl_get16, .-crl_get16
	.type	crl_grid_len, @function
crl_grid_len:
.LFB50:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L109
	testb	$7, %dil
	jne	.L109
	movzbl	(%rdi), %edx
	leal	-1(%rdx), %eax
	cmpb	$3, %al
	ja	.L115
	movzbl	%dl, %ecx
	cmpb	$4, %dl
	ja	.L117
	movzbl	%dl, %eax
	leaq	CRL_BARS(%rip), %rsi
	leaq	(%rax,%rsi), %rsi
	leaq	1(%rax), %rax
	cmpq	$5, %rax
	ja	.L118
.L113:
	leaq	CRL_BARS(%rip), %rax
	movzbl	%dl, %edx
	addq	%rax, %rdx
	jc	.L119
	movslq	%ecx, %rcx
	leaq	CRL_BARS(%rip), %rax
	movzbl	(%rax,%rcx), %eax
.L111:
	leal	(%rax,%rax,2), %eax
	sall	$7, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L109:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data69(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L117:
	movslq	%ecx, %rsi
	leaq	.Lubsan_data70(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L118:
	addq	%rsi, %rax
	jc	.L113
	leaq	.Lubsan_data71(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L119:
	movq	%rax, %rsi
	leaq	.Lubsan_data72(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L115:
	movl	$2, %eax
	jmp	.L111
	.cfi_endproc
.LFE50:
	.size	crl_grid_len, .-crl_grid_len
	.type	crl_write, @function
crl_write:
.LFB17:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	testq	%rdi, %rdi
	je	.L121
	movl	%edx, %r10d
	movl	%ecx, %r11d
	testb	$7, %dil
	jne	.L121
	leaq	4245(%rdi), %rdx
	cmpq	$-4245, %rdi
	jnb	.L164
	movzbl	4245(%rdi), %ebx
	cmpb	$3, %bl
	je	.L165
	cmpb	$5, %bl
	je	.L166
	cmpb	$6, %bl
	jne	.L120
	leaq	4688(%rdi), %rdx
	cmpq	$-4688, %rdi
	jnb	.L167
	movzwl	4688(%rdi), %ebp
	leaq	4692(%rdi), %rdx
	cmpq	$-4692, %rdi
	jnb	.L168
	movzbl	4692(%rdi), %eax
	imull	%eax, %ebp
	movl	4252(%rdi), %esi
	subl	%eax, %esi
.L131:
	movzwl	12(%rdi), %eax
	cmpw	$511, %ax
	ja	.L169
	leaq	4252(%rdi), %rdx
	cmpq	$-4252, %rdi
	jnb	.L170
	movl	4252(%rdi), %edx
	subl	%esi, %edx
	movl	$3072, %esi
	cmpl	%esi, %edx
	cmova	%esi, %edx
	testl	%edx, %edx
	movl	$1, %esi
	cmove	%esi, %edx
	cmpb	$6, %bl
	je	.L171
.L144:
	leaq	4700(%rdi), %rsi
	cmpq	$-4700, %rdi
	jnb	.L172
	addw	$1, 4700(%rdi)
	leal	1(%rax), %ebx
	movw	%bx, 12(%rdi)
	movzwl	%ax, %esi
	cmpw	$512, %ax
	ja	.L173
	movzwl	%ax, %esi
	leaq	146(%rdi,%rsi,8), %rsi
	cmpq	%rdi, %rsi
	jb	.L174
	movzwl	%ax, %eax
	salq	$3, %rax
	leaq	146(%rdi,%rax), %rsi
	testq	%rsi, %rsi
	je	.L149
	testb	$1, %sil
	jne	.L149
	addq	%rdi, %rax
	movw	%bp, 146(%rax)
	leaq	2(%rsi), %rbp
	cmpq	$-2, %rsi
	jnb	.L175
	movw	%dx, 148(%rax)
	movl	$0, %edx
	testw	%r10w, %r10w
	js	.L152
	cmpw	$127, %r10w
	movl	$127, %edx
	cmovle	%r10d, %edx
.L152:
	leaq	4(%rsi), %r10
	cmpq	$-4, %rsi
	jnb	.L176
	movb	%dl, 150(%rax)
	testb	%r9b, %r9b
	movl	$1, %edx
	cmove	%edx, %r9d
	leaq	5(%rsi), %rdx
	cmpq	$-5, %rsi
	jnb	.L177
	movb	%r9b, 151(%rax)
	cmpb	$8, %cl
	movl	$0, %edx
	cmovnb	%edx, %r11d
	sall	$4, %r11d
	andl	$15, %r8d
	orl	%r8d, %r11d
	leaq	6(%rsi), %rdx
	cmpq	$-6, %rsi
	jnb	.L178
	movb	%r11b, 152(%rax)
	movzbl	14(%rdi), %edx
	leaq	7(%rsi), %rcx
	cmpq	$-7, %rsi
	jnb	.L179
	movb	%dl, 153(%rax)
	cmpw	$511, %bx
	jbe	.L120
	movb	$1, 4246(%rdi)
	jmp	.L120
.L121:
	movq	%rdi, %rsi
	leaq	.Lubsan_data73(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L164:
	movq	%rdi, %rsi
	leaq	.Lubsan_data74(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L165:
	leaq	4252(%rdi), %rdx
	cmpq	$-4252, %rdi
	jnb	.L180
	movl	4252(%rdi), %edx
	leaq	4276(%rdi), %rax
	cmpq	$-4276, %rdi
	jnb	.L181
	movl	4276(%rdi), %eax
	cmpl	%eax, %edx
	js	.L120
	cmpl	%eax, %esi
	cmovs	%eax, %esi
	movl	%esi, %ebp
	subl	%eax, %ebp
	leaq	4280(%rdi), %rdx
	cmpq	$-4280, %rdi
	jnb	.L182
	movl	4280(%rdi), %eax
	testl	%eax, %eax
	je	.L130
	cmpl	%eax, %ebp
	jnb	.L120
.L130:
	cmpl	$3071, %ebp
	jbe	.L131
	jmp	.L120
.L180:
	movq	%rdi, %rsi
	leaq	.Lubsan_data75(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L181:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data76(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L182:
	movq	%rdi, %rsi
	leaq	.Lubsan_data77(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L166:
	movl	8(%rdi), %r12d
	testl	%r12d, %r12d
	je	.L120
	leaq	4288(%rdi), %rdx
	cmpq	$-4288, %rdi
	jnb	.L183
	movl	4288(%rdi), %eax
	cmpl	%eax, %esi
	cmovs	%eax, %esi
	movl	%r12d, %r13d
	movl	%esi, %eax
	subl	4268(%rdi), %eax
	cmpl	$-2147483648, %eax
	jne	.L135
	cmpl	$-1, %r12d
	je	.L184
.L135:
	cltd
	idivl	%r13d
	movl	%edx, %ebp
	testl	%edx, %edx
	jns	.L131
	addl	%edx, %r13d
	jo	.L185
	movl	%r13d, %ebp
	jmp	.L131
.L183:
	movq	%rdi, %rsi
	leaq	.Lubsan_data78(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L184:
	movq	$-1, %rdx
	movq	$-2147483648, %rsi
	leaq	.Lubsan_data1(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L185:
	movslq	%edx, %rdx
	movslq	%r12d, %rsi
	leaq	.Lubsan_data93(%rip), %rdi
	call	__ubsan_handle_add_overflow_abort@PLT
.L167:
	movq	%rdi, %rsi
	leaq	.Lubsan_data79(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L168:
	movq	%rdi, %rsi
	leaq	.Lubsan_data80(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L169:
	leaq	4246(%rdi), %rdx
	cmpq	$-4246, %rdi
	jnb	.L186
	movb	$1, 4246(%rdi)
.L120:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L186:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data81(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L170:
	movq	%rdi, %rsi
	leaq	.Lubsan_data82(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L171:
	leaq	4693(%rdi), %rsi
	cmpq	$-4693, %rdi
	jnb	.L187
	movb	$1, 4693(%rdi)
	movzwl	4688(%rdi), %ebx
	movzwl	%bx, %esi
	addl	$1, %esi
	movzwl	4690(%rdi), %r12d
	cmpl	%esi, %r12d
	jnb	.L144
	addl	$1, %ebx
	movw	%bx, 4690(%rdi)
	jmp	.L144
.L187:
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data83(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L172:
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data84(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L173:
	movslq	%esi, %rsi
	leaq	.Lubsan_data85(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L174:
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data86(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L149:
	leaq	.Lubsan_data87(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L175:
	movq	%rbp, %rdx
	leaq	.Lubsan_data88(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L176:
	movq	%r10, %rdx
	leaq	.Lubsan_data89(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L177:
	leaq	.Lubsan_data90(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L178:
	leaq	.Lubsan_data91(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L179:
	movq	%rcx, %rdx
	leaq	.Lubsan_data92(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE17:
	.size	crl_write, .-crl_write
	.type	crl_close_open, @function
crl_close_open:
.LFB21:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movl	$4300, %ebp
	movl	$0, %r12d
	movq	%rdi, %r13
	andl	$7, %r13d
	jmp	.L211
.L217:
	movl	%r12d, %esi
	leaq	.Lubsan_data94(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L190:
	movq	%rbx, %rsi
	leaq	.Lubsan_data95(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L218:
	movq	%rbx, %rsi
	leaq	.Lubsan_data96(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L219:
	movl	%r12d, %esi
	leaq	.Lubsan_data97(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L220:
	movq	%rbx, %rsi
	leaq	.Lubsan_data98(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L221:
	movl	%r12d, %esi
	leaq	.Lubsan_data99(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L222:
	movq	%rbx, %rsi
	leaq	.Lubsan_data100(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L223:
	movl	%r12d, %esi
	leaq	.Lubsan_data101(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L224:
	movq	%rbx, %rsi
	leaq	.Lubsan_data102(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L225:
	movl	%r12d, %esi
	leaq	.Lubsan_data103(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L226:
	movq	%rbx, %rsi
	leaq	.Lubsan_data104(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L227:
	movl	%r12d, %esi
	leaq	.Lubsan_data105(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L203:
	cmpq	%rdx, %rbx
	jb	.L205
.L204:
	movl	(%rbx,%rbp), %esi
	movl	%eax, %edx
	movq	%rbx, %rdi
	call	crl_write
	cmpl	$15, %r12d
	ja	.L214
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L215
	movl	4252(%rbx), %eax
	leaq	(%rbx,%rbp), %rdx
	testq	%rbp, %rbp
	js	.L208
	cmpq	%rbx, %rdx
	jnb	.L209
.L210:
	movq	%rbx, %rsi
	leaq	.Lubsan_data109(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L214:
	movl	%r12d, %esi
	leaq	.Lubsan_data107(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L215:
	movq	%rbx, %rsi
	leaq	.Lubsan_data108(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L208:
	cmpq	%rdx, %rbx
	jb	.L210
.L209:
	movl	%eax, (%rbx,%rbp)
.L193:
	addl	$1, %r12d
	addq	$16, %rbp
	cmpl	$16, %r12d
	je	.L216
.L211:
	cmpl	$15, %r12d
	ja	.L217
	testq	%rbx, %rbx
	je	.L190
	testq	%r13, %r13
	jne	.L190
	leaq	6(%rbx,%rbp), %rdx
	cmpq	%rbx, %rdx
	jb	.L218
	cmpb	$0, 6(%rbx,%rbp)
	je	.L193
	cmpl	$15, %r12d
	ja	.L219
	leaq	9(%rbx,%rbp), %rdx
	cmpq	%rbx, %rdx
	jb	.L220
	movzbl	9(%rbx,%rbp), %r9d
	cmpl	$15, %r12d
	ja	.L221
	leaq	8(%rbx,%rbp), %rdx
	cmpq	%rbx, %rdx
	jb	.L222
	movzbl	8(%rbx,%rbp), %r8d
	cmpl	$15, %r12d
	ja	.L223
	leaq	7(%rbx,%rbp), %rdx
	cmpq	%rbx, %rdx
	jb	.L224
	movzbl	7(%rbx,%rbp), %ecx
	cmpl	$15, %r12d
	ja	.L225
	leaq	4(%rbx,%rbp), %rdx
	cmpq	%rbx, %rdx
	jb	.L226
	movswl	4(%rbx,%rbp), %eax
	cmpl	$15, %r12d
	ja	.L227
	leaq	(%rbx,%rbp), %rdx
	testq	%rbp, %rbp
	js	.L203
	cmpq	%rbx, %rdx
	jnb	.L204
.L205:
	movq	%rbx, %rsi
	leaq	.Lubsan_data106(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L216:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE21:
	.size	crl_close_open, .-crl_close_open
	.type	crl_quantize, @function
crl_quantize:
.LFB22:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	testq	%rdi, %rdi
	je	.L229
	movl	%esi, %r8d
	testb	$7, %dil
	jne	.L229
	leaq	1(%rdi), %rdx
	cmpq	$-1, %rdi
	jnb	.L252
	movzbl	1(%rdi), %edx
	cmpb	$6, %dl
	ja	.L228
	movzbl	%dl, %ecx
	ja	.L253
	movzbl	%dl, %eax
	leaq	CRL_QGRID(%rip), %rsi
	leaq	(%rax,%rsi), %rsi
	leaq	1(%rax), %rax
	cmpq	$7, %rax
	ja	.L254
.L234:
	leaq	CRL_QGRID(%rip), %rax
	movzbl	%dl, %edx
	addq	%rax, %rdx
	jc	.L255
	movslq	%ecx, %rcx
	leaq	CRL_QGRID(%rip), %rax
	movzbl	(%rax,%rcx), %r10d
	testl	%r10d, %r10d
	je	.L228
	leaq	8(%rdi), %rdx
	cmpq	$-8, %rdi
	jnb	.L256
	movl	8(%rdi), %r11d
	testl	%r11d, %r11d
	je	.L228
	leaq	12(%rdi), %rdx
	cmpq	$-12, %rdi
	jnb	.L257
	movzwl	12(%rdi), %ebx
	cmpl	%ebx, %r8d
	jnb	.L228
	movl	%r10d, %ebp
	shrl	%ebp
	movl	%r8d, %eax
	leaq	146(,%rax,8), %r9
	leaq	(%rdi,%r9), %rcx
	movl	$1, %r12d
	jmp	.L248
.L229:
	movq	%rdi, %rsi
	leaq	.Lubsan_data110(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L252:
	movq	%rdi, %rsi
	leaq	.Lubsan_data111(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L253:
	movslq	%ecx, %rsi
	leaq	.Lubsan_data112(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L254:
	addq	%rsi, %rax
	jc	.L234
	leaq	.Lubsan_data113(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L255:
	movq	%rax, %rsi
	leaq	.Lubsan_data114(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L256:
	movq	%rdi, %rsi
	leaq	.Lubsan_data115(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L257:
	movq	%rdi, %rsi
	leaq	.Lubsan_data116(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L260:
	movl	%r8d, %esi
	leaq	.Lubsan_data117(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L239:
	cmpq	%rdx, %rdi
	jb	.L241
.L240:
	movq	%rcx, %rsi
	movq	%rcx, %rax
	testq	%rcx, %rcx
	je	.L242
	testb	$1, %cl
	jne	.L242
	movzwl	(%rcx), %r13d
	leal	0(%r13,%rbp), %eax
	movl	$0, %edx
	divl	%r10d
	imull	%r10d, %eax
	leaq	2(%rcx), %rdx
	cmpq	$-2, %rcx
	jnb	.L258
	movzwl	2(%rcx), %edx
	cmpl	%r11d, %eax
	jnb	.L259
	movzwl	%dx, %edx
	addl	%r13d, %edx
	movl	%edx, %r13d
	subl	%eax, %r13d
	cmpl	%edx, %eax
	movl	%r13d, %edx
	cmovnb	%r12d, %edx
	movw	%ax, (%rcx)
	movl	$3072, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movw	%dx, 2(%rcx)
.L246:
	addl	$1, %r8d
	addq	$8, %r9
	addq	$8, %rcx
	cmpl	%ebx, %r8d
	je	.L228
.L248:
	cmpl	$512, %r8d
	ja	.L260
	leaq	(%rdi,%r9), %rdx
	testq	%r9, %r9
	js	.L239
	cmpq	%rdi, %rdx
	jnb	.L240
.L241:
	movq	%rdi, %rsi
	leaq	.Lubsan_data118(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L242:
	movq	%rax, %rsi
	leaq	.Lubsan_data119(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L258:
	leaq	.Lubsan_data120(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L259:
	movw	$0, (%rcx)
	jmp	.L246
.L228:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE22:
	.size	crl_quantize, .-crl_quantize
	.type	crl_fire, @function
crl_fire:
.LFB10:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbx
	movq	%rsi, 16(%rsp)
	movl	%ecx, 8(%rsp)
	testq	%rdi, %rdi
	je	.L262
	movl	%edx, %r15d
	testb	$7, %dil
	jne	.L262
	leaq	4245(%rdi), %rdx
	cmpq	$-4245, %rdi
	jnb	.L326
	movl	$0, 12(%rsp)
	cmpb	$5, 4245(%rdi)
	je	.L327
.L265:
	cmpw	$0, 12(%rbx)
	je	.L261
	movl	$146, %r12d
	movl	$0, %r13d
	leaq	4252(%rbx), %rax
	movq	%rax, 24(%rsp)
	jmp	.L314
.L262:
	movq	%rbx, %rsi
	leaq	.Lubsan_data121(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L326:
	movq	%rdi, %rsi
	leaq	.Lubsan_data122(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L327:
	leaq	4681(%rdi), %rdx
	cmpq	$-4681, %rdi
	jnb	.L328
	cmpb	$0, 4681(%rdi)
	je	.L316
	leaq	4682(%rdi), %rdx
	cmpq	$-4682, %rdi
	jnb	.L329
	cmpb	$0, 4682(%rdi)
	setne	%al
	movzbl	%al, %eax
	movl	%eax, 12(%rsp)
	jmp	.L265
.L328:
	movq	%rdi, %rsi
	leaq	.Lubsan_data123(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L329:
	movq	%rdi, %rsi
	leaq	.Lubsan_data124(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L316:
	movl	$0, 12(%rsp)
	jmp	.L265
.L345:
	movl	%r13d, %esi
	leaq	.Lubsan_data125(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L270:
	cmpq	%rdx, %rbx
	jb	.L272
.L271:
	movq	%rbx, %rsi
	addq	%r12, %rsi
	je	.L273
	testb	$1, %sil
	jne	.L273
	leaq	7(%rsi), %rdx
	cmpq	$-7, %rsi
	jnb	.L330
	movl	%r13d, %eax
	leaq	(%rbx,%rax,8), %r14
	cmpb	$0, 153(%r14)
	js	.L276
	movzwl	146(%r14), %eax
	cmpl	%r15d, %eax
	jb	.L276
	cmpl	%eax, 8(%rsp)
	jb	.L276
	cmpl	$0, 12(%rsp)
	je	.L277
	leaq	4248(%rbx), %rdx
	cmpq	$-4248, %rbx
	jnb	.L331
	movzwl	4248(%rbx), %eax
	cmpl	%eax, %r13d
	jb	.L332
.L277:
	movzbl	151(%r14), %esi
	movzbl	3(%rbx), %eax
	imull	%eax, %esi
	cmpl	$99, %esi
	jbe	.L276
	movl	$0, %ebp
	jmp	.L286
.L273:
	leaq	.Lubsan_data127(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L330:
	leaq	.Lubsan_data128(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L331:
	movq	%rbx, %rsi
	leaq	.Lubsan_data129(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L332:
	movl	%r13d, %esi
	movq	%rbx, %rdi
	call	crl_hide
	jmp	.L276
.L335:
	movq	%rax, %rsi
	leaq	.Lubsan_data130(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L280:
	cmpq	%rdx, %rbx
	jb	.L282
.L281:
	movslq	%ebp, %rax
	cmpb	$0, 4558(%rbx,%rax,8)
	je	.L283
	movl	%ebp, %eax
	addl	$1, %eax
	jo	.L333
	movl	%eax, %ebp
	cmpl	$7, %eax
	jg	.L334
.L286:
	movslq	%ebp, %rax
	cmpq	$8, %rax
	jnb	.L335
	movslq	%ebp, %rax
	leaq	4558(,%rax,8), %rax
	leaq	(%rbx,%rax), %rdx
	testq	%rax, %rax
	js	.L280
	cmpq	%rbx, %rdx
	jnb	.L281
.L282:
	movq	%rbx, %rsi
	leaq	.Lubsan_data131(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L333:
	movslq	%ebp, %rsi
	movl	$1, %edx
	leaq	.Lubsan_data144(%rip), %rdi
	call	__ubsan_handle_add_overflow_abort@PLT
.L334:
	movl	$-1, %ebp
.L287:
	movl	$0, %eax
	jmp	.L298
.L283:
	testl	%ebp, %ebp
	js	.L287
.L288:
	movzbl	152(%r14), %r8d
	movl	%esi, %r9d
	imulq	$1374389535, %r9, %r9
	shrq	$37, %r9
	movl	%r8d, %ecx
	shrb	$4, %cl
	movzbl	%cl, %ecx
	movzbl	150(%r14), %edx
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	pushq	$1
	.cfi_def_cfa_offset 112
	movzbl	%r9b, %r9d
	andl	$15, %r8d
	movl	%ebp, %esi
	movq	32(%rsp), %rdi
	call	cr_loop_event@PLT
	movslq	%ebp, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 96
	cmpq	$8, %rax
	jnb	.L336
	movslq	%ebp, %rax
	salq	$3, %rax
	leaq	4558(%rax), %rcx
	leaq	(%rbx,%rcx), %rdx
	testq	%rcx, %rcx
	js	.L300
	cmpq	%rbx, %rdx
	jnb	.L301
.L302:
	movq	%rbx, %rsi
	leaq	.Lubsan_data137(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L340:
	movq	%rdx, %rsi
	leaq	.Lubsan_data132(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L291:
	cmpq	%rdx, %rbx
	jb	.L293
.L292:
	movslq	%eax, %rdx
	movl	4552(%rbx,%rdx,8), %ecx
	movslq	%ebp, %rdx
	cmpq	$8, %rdx
	jnb	.L337
	movslq	%ebp, %rdx
	leaq	4552(%rbx,%rdx,8), %rdx
	cmpq	%rbx, %rdx
	jb	.L338
	movslq	%ebp, %rdx
	cmpl	4552(%rbx,%rdx,8), %ecx
	cmovs	%eax, %ebp
.L289:
	movl	%eax, %edx
	addl	$1, %edx
	jo	.L339
	movl	%edx, %eax
	cmpl	$7, %edx
	jg	.L288
.L298:
	testl	%ebp, %ebp
	js	.L317
	movslq	%eax, %rdx
	cmpq	$8, %rdx
	jnb	.L340
	leal	569(%rax), %ecx
	movslq	%ecx, %rcx
	salq	$3, %rcx
	leaq	(%rbx,%rcx), %rdx
	js	.L291
	cmpq	%rbx, %rdx
	jnb	.L292
.L293:
	movq	%rbx, %rsi
	leaq	.Lubsan_data133(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L337:
	movq	%rdx, %rsi
	leaq	.Lubsan_data134(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L338:
	movq	%rbx, %rsi
	leaq	.Lubsan_data135(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L317:
	movl	%eax, %ebp
	jmp	.L289
.L339:
	movslq	%eax, %rsi
	movl	$1, %edx
	leaq	.Lubsan_data145(%rip), %rdi
	call	__ubsan_handle_add_overflow_abort@PLT
.L336:
	movq	%rax, %rsi
	leaq	.Lubsan_data136(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L300:
	cmpq	%rdx, %rbx
	jb	.L302
.L301:
	leaq	(%rbx,%rax), %rcx
	movb	$1, 4558(%rcx)
	movslq	%ebp, %rdx
	cmpq	$8, %rdx
	jnb	.L341
	movl	%r13d, %edi
	leaq	4556(%rax), %rsi
	leaq	(%rbx,%rsi), %rdx
	testq	%rsi, %rsi
	js	.L304
	cmpq	%rbx, %rdx
	jnb	.L305
.L306:
	movq	%rbx, %rsi
	leaq	.Lubsan_data139(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L341:
	movq	%rdx, %rsi
	leaq	.Lubsan_data138(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L304:
	cmpq	%rdx, %rbx
	jb	.L306
.L305:
	movw	%di, 4556(%rcx)
	cmpq	$-4252, %rbx
	jnb	.L342
	movl	4252(%rbx), %esi
	movzwl	148(%r14), %edi
	movzwl	%di, %edx
	testw	%di, %di
	movl	$1, %edi
	cmove	%edi, %edx
	movslq	%ebp, %rdi
	cmpq	$8, %rdi
	jnb	.L343
	addl	%edx, %esi
	addq	$4552, %rax
	leaq	(%rbx,%rax), %rdx
	js	.L310
	cmpq	%rbx, %rdx
	jnb	.L311
.L312:
	movq	%rbx, %rsi
	leaq	.Lubsan_data142(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L342:
	movq	24(%rsp), %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data140(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L343:
	movq	%rdi, %rsi
	leaq	.Lubsan_data141(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L310:
	cmpq	%rdx, %rbx
	jb	.L312
.L311:
	movl	%esi, 4552(%rcx)
	leaq	4724(%rbx), %rdx
	cmpq	$-4724, %rbx
	jnb	.L344
	addl	$1, 4724(%rbx)
.L276:
	addl	$1, %r13d
	addq	$8, %r12
	movzwl	12(%rbx), %eax
	cmpl	%eax, %r13d
	jnb	.L261
.L314:
	cmpl	$512, %r13d
	ja	.L345
	leaq	(%rbx,%r12), %rdx
	testq	%r12, %r12
	js	.L270
	cmpq	%rbx, %rdx
	jnb	.L271
.L272:
	movq	%rbx, %rsi
	leaq	.Lubsan_data126(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L344:
	movq	%rbx, %rsi
	leaq	.Lubsan_data143(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L261:
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10:
	.size	crl_fire, .-crl_fire
	.type	crl_voices_off, @function
crl_voices_off:
.LFB7:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbp
	movq	%rsi, %r14
	movl	$0, %ebx
	movq	%rdi, %r13
	andl	$7, %r13d
	jmp	.L360
.L367:
	movq	%rax, %rsi
	leaq	.Lubsan_data146(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L348:
	movq	%rbp, %rsi
	leaq	.Lubsan_data147(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L350:
	cmpq	%rdx, %rbp
	jb	.L352
.L351:
	movslq	%ebx, %rax
	cmpb	$0, 4558(%rbp,%rax,8)
	jne	.L364
.L353:
	movl	%ebx, %eax
	addl	$1, %eax
	jo	.L365
	movl	%eax, %ebx
	cmpl	$7, %eax
	jg	.L366
.L360:
	movslq	%ebx, %rax
	cmpq	$8, %rax
	jnb	.L367
	testq	%rbp, %rbp
	je	.L348
	testq	%r13, %r13
	jne	.L348
	movslq	%ebx, %rax
	leaq	4558(,%rax,8), %r12
	leaq	0(%rbp,%r12), %rdx
	testq	%r12, %r12
	js	.L350
	cmpq	%rbp, %rdx
	jnb	.L351
.L352:
	movq	%rbp, %rsi
	leaq	.Lubsan_data148(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L364:
	subq	$8, %rsp
	.cfi_def_cfa_offset 56
	pushq	$0
	.cfi_def_cfa_offset 64
	movl	$0, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$0, %edx
	movl	%ebx, %esi
	movq	%r14, %rdi
	call	cr_loop_event@PLT
	movslq	%ebx, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 48
	cmpq	$8, %rax
	jnb	.L368
	leaq	0(%rbp,%r12), %rdx
	testq	%r12, %r12
	js	.L355
	cmpq	%rbp, %rdx
	jnb	.L356
.L357:
	movq	%rbp, %rsi
	leaq	.Lubsan_data150(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L368:
	movq	%rax, %rsi
	leaq	.Lubsan_data149(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L355:
	cmpq	%rdx, %rbp
	jb	.L357
.L356:
	movslq	%ebx, %rax
	movb	$0, 4558(%rbp,%rax,8)
	jmp	.L353
.L365:
	movslq	%ebx, %rsi
	movl	$1, %edx
	leaq	.Lubsan_data151(%rip), %rdi
	call	__ubsan_handle_add_overflow_abort@PLT
.L366:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE7:
	.size	crl_voices_off, .-crl_voices_off
	.type	crl_drop_take, @function
crl_drop_take:
.LFB23:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L370
	testb	$7, %dil
	jne	.L370
	leaq	8(%rdi), %rdx
	cmpq	$-8, %rdi
	jnb	.L375
	leaq	8(%rdi), %rdi
	movl	$138, %esi
	call	crl_zero
	leaq	4244(%rbx), %rdx
	cmpq	$-4244, %rbx
	jnb	.L376
	movb	$0, 4244(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L370:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data152(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L375:
	movq	%rdi, %rsi
	leaq	.Lubsan_data153(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L376:
	movq	%rbx, %rsi
	leaq	.Lubsan_data154(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE23:
	.size	crl_drop_take, .-crl_drop_take
	.type	crl_take_next, @function
crl_take_next:
.LFB14:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L378
	testb	$7, %dil
	jne	.L378
	leaq	4704(%rdi), %rdx
	cmpq	$-4704, %rdi
	jnb	.L401
	movq	4704(%rdi), %rsi
	movq	$0, 4704(%rdi)
	testq	%rsi, %rsi
	je	.L381
	movq	%rsi, %rax
	je	.L382
	testb	$3, %sil
	jne	.L382
	cmpl	$0, (%rsi)
	je	.L381
	leaq	4(%rsi), %rdx
	cmpq	$-4, %rsi
	jnb	.L402
	movzwl	4(%rsi), %edx
	testw	%dx, %dx
	jne	.L403
.L381:
	leaq	8(%rbx), %rdi
	movl	$138, %esi
	call	crl_zero
.L390:
	cmpb	$0, 17(%rbx)
	je	.L391
	movl	8(%rbx), %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$40, %rax
	movl	$2, %edx
	cmpl	$2, %eax
	je	.L392
	movl	$3, %edx
	cmpl	$4, %eax
	je	.L392
	cmpl	$1, %eax
	setne	%dl
	leal	1(%rdx,%rdx,2), %edx
.L392:
	movb	%dl, (%rbx)
.L391:
	movq	%rbx, %rdi
	call	crl_lev0_scan
	addw	$1, 4700(%rbx)
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L404
	movb	$0, 4713(%rbx)
	leaq	4714(%rbx), %rdx
	cmpq	$-4714, %rbx
	jnb	.L405
	addb	$1, 4714(%rbx)
	cmpl	$0, 8(%rbx)
	jne	.L377
	movb	$0, 4244(%rbx)
.L377:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L378:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data155(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L401:
	movq	%rdi, %rsi
	leaq	.Lubsan_data156(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L382:
	movq	%rax, %rsi
	leaq	.Lubsan_data157(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L402:
	leaq	.Lubsan_data158(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L403:
	leaq	8(%rdi), %rax
	movzwl	%dx, %edx
	leaq	138(%rsi,%rdx,8), %rdi
	jmp	.L389
.L396:
	movq	%rcx, %rax
	movq	%rdx, %rsi
.L389:
	leaq	1(%rsi), %rdx
	cmpq	$-1, %rsi
	jnb	.L406
	leaq	1(%rsi), %rdx
	leaq	1(%rax), %rcx
	cmpq	$-1, %rax
	jnb	.L407
	leaq	1(%rax), %rcx
	testq	%rsi, %rsi
	je	.L408
	movzbl	-1(%rdx), %esi
	testq	%rax, %rax
	je	.L409
	movb	%sil, -1(%rcx)
	cmpq	%rdi, %rdx
	jne	.L396
	jmp	.L390
.L406:
	leaq	.Lubsan_data159(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L407:
	movq	%rcx, %rdx
	movq	%rax, %rsi
	leaq	.Lubsan_data160(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L408:
	leaq	.Lubsan_data161(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L409:
	movl	$0, %esi
	leaq	.Lubsan_data162(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L404:
	movq	%rbx, %rsi
	leaq	.Lubsan_data163(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L405:
	movq	%rbx, %rsi
	leaq	.Lubsan_data164(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE14:
	.size	crl_take_next, .-crl_take_next
	.type	crl_play_upto, @function
crl_play_upto:
.LFB15:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L411
	movq	%rsi, %r12
	testb	$7, %dil
	jne	.L411
	leaq	4244(%rdi), %rdx
	cmpq	$-4244, %rdi
	jnb	.L426
	cmpb	$2, 4244(%rdi)
	jne	.L410
	movl	8(%rdi), %ecx
	testl	%ecx, %ecx
	je	.L410
	leaq	4252(%rdi), %rdx
	cmpq	$-4252, %rdi
	jnb	.L427
	movl	4252(%rdi), %ebp
	leaq	4268(%rdi), %rdx
	cmpq	$-4268, %rdi
	jnb	.L428
	subl	4268(%rdi), %ebp
	cmpl	%ecx, %ebp
	jb	.L417
	leaq	4272(%rdi), %r13
	jmp	.L422
.L411:
	movq	%rbx, %rsi
	leaq	.Lubsan_data165(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L426:
	movq	%rdi, %rsi
	leaq	.Lubsan_data166(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L427:
	movq	%rdi, %rsi
	leaq	.Lubsan_data167(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L428:
	movq	%rdi, %rsi
	leaq	.Lubsan_data168(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L429:
	movq	%r13, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data169(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L430:
	subl	$1, %ecx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	crl_fire
	jmp	.L419
.L431:
	movq	%rbx, %rsi
	leaq	.Lubsan_data170(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L421:
	movl	8(%rbx), %ecx
	cmpl	%ecx, %ebp
	jb	.L417
.L422:
	cmpq	$-4272, %rbx
	jnb	.L429
	movl	4272(%rbx), %edx
	cmpl	%ecx, %edx
	jb	.L430
.L419:
	movl	8(%rbx), %eax
	subl	%eax, %ebp
	addl	%eax, 4268(%rbx)
	movl	$0, 4272(%rbx)
	leaq	4712(%rbx), %rdx
	cmpq	$-4712, %rbx
	jnb	.L431
	cmpb	$0, 4712(%rbx)
	je	.L421
	movb	$0, 4712(%rbx)
	movq	%rbx, %rdi
	call	crl_take_next
	cmpb	$2, 4244(%rbx)
	jne	.L410
	movl	8(%rbx), %esi
	testl	%esi, %esi
	je	.L410
	cmpl	%esi, %ebp
	jb	.L421
	movl	%ebp, %eax
	movl	$0, %edx
	divl	%esi
	movl	%edx, %ebp
	jmp	.L421
.L417:
	leaq	4272(%rbx), %rdx
	cmpq	$-4272, %rbx
	jnb	.L432
	movl	4272(%rbx), %edx
	cmpl	%edx, %ebp
	jnb	.L433
.L410:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L432:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data171(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L433:
	movl	%ebp, %ecx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	crl_fire
	addl	$1, %ebp
	movl	%ebp, 4272(%rbx)
	jmp	.L410
	.cfi_endproc
.LFE15:
	.size	crl_play_upto, .-crl_play_upto
	.type	crl_start, @function
crl_start:
.LFB16:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L435
	testb	$7, %dil
	jne	.L435
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L441
	movb	$0, 4715(%rdi)
	movb	$2, 4244(%rdi)
	movl	4252(%rdi), %eax
	movl	%eax, 4268(%rdi)
	movl	$0, 4272(%rdi)
	call	crl_play_upto
	cmpb	$0, 5(%rbx)
	je	.L434
	leaq	4716(%rbx), %rdx
	cmpq	$-4716, %rbx
	jnb	.L442
	movb	$2, 4716(%rbx)
.L434:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L435:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data172(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L441:
	movq	%rdi, %rsi
	leaq	.Lubsan_data173(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L442:
	movq	%rbx, %rsi
	leaq	.Lubsan_data174(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE16:
	.size	crl_start, .-crl_start
	.globl	cr_loop_bar
	.type	cr_loop_bar, @function
cr_loop_bar:
.LFB3:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L444
	testb	$7, %dil
	jne	.L444
	leaq	4(%rdi), %rdx
	cmpq	$-4, %rdi
	jnb	.L450
	cmpb	$1, 4(%rdi)
	sbbl	%eax, %eax
	andl	$96, %eax
	addl	$288, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L444:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data175(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L450:
	movq	%rdi, %rsi
	leaq	.Lubsan_data176(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE3:
	.size	cr_loop_bar, .-cr_loop_bar
	.type	crl_step_commit, @function
crl_step_commit:
.LFB24:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movq	%rsi, %r13
	movl	%edx, %r12d
	call	cr_loop_bar
	movl	%eax, %ebp
	movq	%rbx, %rdi
	call	crl_close_open
	testq	%rbx, %rbx
	je	.L452
	testb	$7, %bl
	jne	.L452
	leaq	4245(%rbx), %rdx
	cmpq	$-4245, %rbx
	jnb	.L485
	movb	$0, 4245(%rbx)
	leaq	4246(%rbx), %rdx
	cmpq	$-4246, %rbx
	jnb	.L486
	movb	$0, 4246(%rbx)
	movzwl	12(%rbx), %eax
	leaq	4248(%rbx), %rdx
	cmpq	$-4248, %rbx
	jnb	.L487
	movzwl	4248(%rbx), %edx
	cmpw	%ax, %dx
	jnb	.L457
	movzwl	%ax, %edi
	movzwl	%dx, %ecx
	subl	%ecx, %edi
	jo	.L488
	leaq	4700(%rbx), %rax
	cmpq	$-4700, %rbx
	jnb	.L489
	addw	$1, 4700(%rbx)
	testl	%edi, %edi
	je	.L477
	movzwl	%dx, %edx
	movl	$146, %eax
	movl	$0, %ecx
	jmp	.L471
.L452:
	movq	%rbx, %rsi
	leaq	.Lubsan_data177(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L485:
	movq	%rbx, %rsi
	leaq	.Lubsan_data178(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L486:
	movq	%rbx, %rsi
	leaq	.Lubsan_data179(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L487:
	movq	%rbx, %rsi
	leaq	.Lubsan_data180(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L488:
	movzwl	%dx, %edx
	movzwl	%ax, %esi
	leaq	.Lubsan_data190(%rip), %rdi
	call	__ubsan_handle_sub_overflow_abort@PLT
.L489:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data181(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L494:
	movl	%edx, %esi
	leaq	.Lubsan_data182(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L495:
	movl	%ecx, %esi
	leaq	.Lubsan_data183(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L465:
	cmpq	%rsi, %rbx
	jb	.L467
.L466:
	movl	%edx, %esi
	leaq	146(%rbx,%rsi,8), %rsi
	cmpq	%rbx, %rsi
	jb	.L490
	movl	%edx, %esi
	movq	146(%rbx,%rsi,8), %rsi
	movq	%rsi, (%rbx,%rax)
	cmpl	$511, %ecx
	ja	.L491
	leaq	7(%rbx,%rax), %rsi
	cmpq	%rbx, %rsi
	jb	.L492
	movb	$0, 7(%rbx,%rax)
	addl	$1, %ecx
	addl	$1, %edx
	addq	$8, %rax
	cmpl	%ecx, %edi
	je	.L493
.L471:
	cmpl	$511, %edx
	ja	.L494
	cmpl	$511, %ecx
	ja	.L495
	leaq	(%rbx,%rax), %rsi
	testq	%rax, %rax
	js	.L465
	cmpq	%rbx, %rsi
	jnb	.L466
.L467:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data184(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L490:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data185(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L491:
	movl	%ecx, %esi
	leaq	.Lubsan_data186(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L492:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data187(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L493:
	movw	%di, 12(%rbx)
	movb	$1, 14(%rbx)
	movw	$0, 4616(%rbx)
	movw	$0, 4248(%rbx)
	movl	4696(%rbx), %eax
	testl	%eax, %eax
	jne	.L472
	movzwl	4690(%rbx), %eax
	movzwl	%ax, %edx
	testw	%ax, %ax
	movl	$1, %eax
	cmove	%eax, %edx
	movzbl	4692(%rbx), %eax
	imull	%edx, %eax
	leal	-1(%rbp,%rax), %eax
	testl	%ebp, %ebp
	je	.L496
	movl	$0, %edx
	divl	%ebp
	imull	%ebp, %eax
	cmpl	$3072, %eax
	jbe	.L472
	movl	$3072, %eax
	movl	$0, %edx
	divl	%ebp
	imull	%ebp, %eax
.L472:
	movb	$0, 17(%rbx)
	movb	$0, 16(%rbx)
	movl	%eax, 8(%rbx)
	movzbl	4(%rbx), %eax
	movb	%al, 15(%rbx)
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L497
	movb	$1, 4713(%rbx)
	movb	$0, 4712(%rbx)
	movb	$1, 4244(%rbx)
	movl	$15, %eax
	testl	%r12d, %r12d
	jne	.L498
.L451:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L496:
	.cfi_restore_state
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data7(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L497:
	movq	%rbx, %rsi
	leaq	.Lubsan_data188(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L498:
	movq	%r13, %rsi
	movq	%rbx, %rdi
	call	crl_start
	movl	$15, %eax
	jmp	.L451
.L457:
	leaq	4700(%rbx), %rax
	cmpq	$-4700, %rbx
	jnb	.L499
	addw	$1, 4700(%rbx)
.L477:
	movw	%dx, 12(%rbx)
	movl	$12, %eax
	testl	%r12d, %r12d
	je	.L451
	cmpb	$1, 4244(%rbx)
	jne	.L451
	movq	%r13, %rsi
	movq	%rbx, %rdi
	call	crl_start
	movl	$12, %eax
	jmp	.L451
.L499:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data189(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE24:
	.size	crl_step_commit, .-crl_step_commit
	.type	crl_commit, @function
crl_commit:
.LFB25:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movq	%rsi, %r12
	call	cr_loop_bar
	testq	%rbx, %rbx
	je	.L501
	movl	%eax, %ebp
	testb	$7, %bl
	jne	.L501
	leaq	4245(%rbx), %rdx
	cmpq	$-4245, %rbx
	jnb	.L530
	movzbl	4245(%rbx), %eax
	cmpl	$3, %eax
	je	.L531
	cmpl	$5, %eax
	je	.L532
	cmpl	$6, %eax
	je	.L533
	movb	$0, 4245(%rbx)
	leaq	4680(%rbx), %rdx
	cmpq	$-4680, %rbx
	jnb	.L534
	movb	$0, 4680(%rbx)
	movl	$4, %eax
.L500:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L501:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data191(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L530:
	movq	%rbx, %rsi
	leaq	.Lubsan_data192(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L531:
	movq	%rbx, %rdi
	call	crl_close_open
	movb	$0, 4245(%rbx)
	leaq	4246(%rbx), %rdx
	cmpq	$-4246, %rbx
	jnb	.L535
	movb	$0, 4246(%rbx)
	cmpw	$0, 12(%rbx)
	je	.L536
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L537
	movl	4252(%rbx), %r13d
	leaq	4276(%rbx), %rdx
	cmpq	$-4276, %rbx
	jnb	.L538
	subl	4276(%rbx), %r13d
	leaq	4280(%rbx), %rdx
	cmpq	$-4280, %rbx
	jnb	.L539
	movl	4280(%rbx), %eax
	testl	%eax, %eax
	je	.L511
	cmpl	%eax, %r13d
	jnb	.L512
	leal	-1(%rbp,%r13), %eax
	testl	%ebp, %ebp
	je	.L540
	movl	$0, %edx
	divl	%ebp
	imull	%ebp, %eax
.L512:
	cmpl	%ebp, %eax
	cmovb	%ebp, %eax
.L514:
	movl	%eax, 8(%rbx)
	movb	$1, 14(%rbx)
	leaq	4616(%rbx), %rdx
	cmpq	$-4616, %rbx
	jnb	.L541
	movw	$0, 4616(%rbx)
	movzbl	4(%rbx), %eax
	movb	%al, 15(%rbx)
	movl	$0, %esi
	movq	%rbx, %rdi
	call	crl_quantize
	leaq	4700(%rbx), %rdx
	cmpq	$-4700, %rbx
	jnb	.L542
	addw	$1, 4700(%rbx)
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L543
	movb	$1, 4713(%rbx)
	movb	$2, 4244(%rbx)
	movl	4276(%rbx), %eax
	movl	%eax, 4268(%rbx)
	addl	$1, %r13d
	movl	%r13d, 4272(%rbx)
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	crl_play_upto
	movl	$5, %eax
	jmp	.L500
.L535:
	movq	%rbx, %rsi
	leaq	.Lubsan_data193(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L536:
	movq	%rbx, %rdi
	call	crl_drop_take
	movl	$12, %eax
	jmp	.L500
.L537:
	movq	%rbx, %rsi
	leaq	.Lubsan_data194(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L538:
	movq	%rbx, %rsi
	leaq	.Lubsan_data195(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L539:
	movq	%rbx, %rsi
	leaq	.Lubsan_data196(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L540:
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data9(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L511:
	movl	$3072, %eax
	cmpl	%eax, %r13d
	cmovbe	%r13d, %eax
	movl	$24, %edx
	cmpl	%edx, %eax
	cmovb	%edx, %eax
	jmp	.L514
.L541:
	movq	%rbx, %rsi
	leaq	.Lubsan_data197(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L542:
	movq	%rbx, %rsi
	leaq	.Lubsan_data198(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L543:
	movq	%rbx, %rsi
	leaq	.Lubsan_data199(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L532:
	movq	%rbx, %rdi
	call	crl_close_open
	movb	$0, 4245(%rbx)
	leaq	4246(%rbx), %rdx
	cmpq	$-4246, %rbx
	jnb	.L544
	movb	$0, 4246(%rbx)
	leaq	4682(%rbx), %rdx
	cmpq	$-4682, %rbx
	jnb	.L545
	movb	$0, 4682(%rbx)
	movb	$0, 4681(%rbx)
	movzwl	4248(%rbx), %esi
	cmpw	12(%rbx), %si
	jnb	.L521
	movzwl	%si, %esi
	movq	%rbx, %rdi
	call	crl_quantize
	movzbl	14(%rbx), %eax
	movzbl	%al, %edx
	cmpb	$31, %al
	ja	.L546
	movzwl	4248(%rbx), %esi
	movzbl	%al, %ecx
	leaq	4616(%rbx,%rcx,2), %rcx
	cmpq	%rbx, %rcx
	jb	.L547
	movslq	%edx, %rdx
	movw	%si, 4616(%rbx,%rdx,2)
	addl	$1, %eax
	movb	%al, 14(%rbx)
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L548
	movb	$1, 4713(%rbx)
.L525:
	leaq	4700(%rbx), %rdx
	cmpq	$-4700, %rbx
	jnb	.L549
	addw	$1, 4700(%rbx)
	movl	$7, %eax
	jmp	.L500
.L544:
	movq	%rbx, %rsi
	leaq	.Lubsan_data200(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L545:
	movq	%rbx, %rsi
	leaq	.Lubsan_data201(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L546:
	movslq	%edx, %rsi
	leaq	.Lubsan_data202(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L547:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data203(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L548:
	movq	%rbx, %rsi
	leaq	.Lubsan_data204(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L521:
	movzbl	14(%rbx), %esi
	movq	%rbx, %rdi
	call	crl_restore
	jmp	.L525
.L549:
	movq	%rbx, %rsi
	leaq	.Lubsan_data205(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L533:
	movl	$0, %edx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	crl_step_commit
	jmp	.L500
.L534:
	movq	%rbx, %rsi
	leaq	.Lubsan_data206(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE25:
	.size	crl_commit, .-crl_commit
	.globl	cr_loop_beat
	.type	cr_loop_beat, @function
cr_loop_beat:
.LFB4:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L551
	testb	$7, %dil
	jne	.L551
	leaq	4(%rdi), %rdx
	cmpq	$-4, %rdi
	jnb	.L557
	cmpb	$2, 4(%rdi)
	movl	$96, %eax
	movl	$48, %edx
	cmove	%edx, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L551:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data207(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L557:
	movq	%rdi, %rsi
	leaq	.Lubsan_data208(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE4:
	.size	cr_loop_beat, .-cr_loop_beat
	.type	crl_tick1, @function
crl_tick1:
.LFB26:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbp
	movq	%rsi, %r14
	call	cr_loop_bar
	movl	%eax, 12(%rsp)
	movq	%rbp, %rdi
	call	cr_loop_beat
	testq	%rbp, %rbp
	je	.L559
	movl	%eax, %r15d
	testb	$7, %bpl
	jne	.L559
	leaq	4715(%rbp), %rdx
	cmpq	$-4715, %rbp
	jnb	.L604
	cmpb	$1, 4715(%rbp)
	je	.L605
.L562:
	cmpb	$2, 4245(%rbp)
	je	.L606
.L564:
	cmpb	$3, 4245(%rbp)
	je	.L607
.L565:
	cmpb	$5, 4245(%rbp)
	je	.L608
.L568:
	movl	$0, %ebx
	jmp	.L589
.L559:
	movq	%rbp, %rsi
	leaq	.Lubsan_data209(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L604:
	movq	%rbp, %rsi
	leaq	.Lubsan_data210(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L605:
	cmpb	$1, 4244(%rbp)
	jne	.L562
	movl	4252(%rbp), %eax
	subl	4292(%rbp), %eax
	testl	%r15d, %r15d
	je	.L609
	movl	$0, %edx
	divl	%r15d
	testl	%edx, %edx
	jne	.L562
	movq	%r14, %rsi
	movq	%rbp, %rdi
	call	crl_start
	jmp	.L562
.L609:
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data10(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L606:
	movl	4252(%rbp), %eax
	subl	4284(%rbp), %eax
	movl	12(%rsp), %ecx
	cmpl	%ecx, %eax
	jb	.L564
	movq	%rbp, %rdi
	call	crl_take_start
	movb	$3, 4245(%rbp)
	movl	12(%rsp), %eax
	addl	4284(%rbp), %eax
	movl	%eax, 4276(%rbp)
	movw	$0, 4248(%rbp)
	jmp	.L564
.L607:
	movl	4280(%rbp), %eax
	testl	%eax, %eax
	je	.L566
	movl	4252(%rbp), %edx
	subl	4276(%rbp), %edx
	cmpl	%eax, %edx
	jnb	.L567
.L599:
	cmpb	$0, 4246(%rbp)
	je	.L565
.L567:
	movq	%r14, %rsi
	movq	%rbp, %rdi
	call	crl_commit
	jmp	.L565
.L608:
	cmpb	$0, 4246(%rbp)
	je	.L568
	movq	%r14, %rsi
	movq	%rbp, %rdi
	call	crl_commit
	jmp	.L568
.L613:
	movq	%rax, %rsi
	leaq	.Lubsan_data211(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L570:
	cmpq	%rdx, %rbp
	jb	.L572
.L571:
	movslq	%ebx, %rax
	cmpb	$0, 4558(%rbp,%rax,8)
	je	.L573
	movl	%ebx, %esi
	movq	%r14, %rdi
	call	cr_loop_busy@PLT
	testl	%eax, %eax
	jne	.L574
	movslq	%ebx, %rax
	cmpq	$8, %rax
	jnb	.L610
	leaq	0(%rbp,%r13), %rdx
	testq	%r13, %r13
	js	.L576
	cmpq	%rbp, %rdx
	jnb	.L577
.L578:
	movq	%rbp, %rsi
	leaq	.Lubsan_data214(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L610:
	movq	%rax, %rsi
	leaq	.Lubsan_data213(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L576:
	cmpq	%rdx, %rbp
	jb	.L578
.L577:
	movslq	%ebx, %rax
	movb	$0, 4558(%rbp,%rax,8)
.L573:
	movl	%ebx, %eax
	addl	$1, %eax
	jo	.L611
	movl	%eax, %ebx
	cmpl	$7, %eax
	jg	.L612
.L589:
	movslq	%ebx, %rax
	cmpq	$8, %rax
	jnb	.L613
	movslq	%ebx, %r12
	salq	$3, %r12
	leaq	4558(%r12), %r13
	leaq	0(%rbp,%r13), %rdx
	testq	%r13, %r13
	js	.L570
	cmpq	%rbp, %rdx
	jnb	.L571
.L572:
	movq	%rbp, %rsi
	leaq	.Lubsan_data212(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L574:
	movl	4252(%rbp), %ecx
	movslq	%ebx, %rax
	cmpq	$8, %rax
	jnb	.L614
	addq	$4552, %r12
	leaq	0(%rbp,%r12), %rdx
	js	.L580
	cmpq	%rbp, %rdx
	jnb	.L581
.L582:
	movq	%rbp, %rsi
	leaq	.Lubsan_data216(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L614:
	movq	%rax, %rsi
	leaq	.Lubsan_data215(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L580:
	cmpq	%rdx, %rbp
	jb	.L582
.L581:
	movslq	%ebx, %rax
	cmpl	4552(%rbp,%rax,8), %ecx
	js	.L573
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	pushq	$0
	.cfi_def_cfa_offset 96
	movl	$0, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$0, %edx
	movl	%ebx, %esi
	movq	%r14, %rdi
	call	cr_loop_event@PLT
	movslq	%ebx, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 80
	cmpq	$8, %rax
	jnb	.L615
	leaq	0(%rbp,%r13), %rdx
	testq	%r13, %r13
	js	.L584
	cmpq	%rbp, %rdx
	jnb	.L585
.L586:
	movq	%rbp, %rsi
	leaq	.Lubsan_data218(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L615:
	movq	%rax, %rsi
	leaq	.Lubsan_data217(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L584:
	cmpq	%rdx, %rbp
	jb	.L586
.L585:
	movslq	%ebx, %rax
	movb	$0, 4558(%rbp,%rax,8)
	jmp	.L573
.L611:
	movslq	%ebx, %rsi
	movl	$1, %edx
	leaq	.Lubsan_data220(%rip), %rdi
	call	__ubsan_handle_add_overflow_abort@PLT
.L612:
	movq	%r14, %rsi
	movq	%rbp, %rdi
	call	crl_play_upto
	movzbl	4245(%rbp), %eax
	cmpb	$2, %al
	je	.L616
	cmpb	$0, 5(%rbp)
	je	.L558
	cmpb	$3, %al
	je	.L617
	cmpb	$2, 4244(%rbp)
	je	.L618
	movl	4292(%rbp), %eax
	jmp	.L591
.L616:
	movl	4284(%rbp), %eax
.L591:
	movl	4252(%rbp), %esi
	subl	%eax, %esi
	testl	%r15d, %r15d
	je	.L619
	movl	%esi, %eax
	movl	$0, %edx
	divl	%r15d
	testl	%edx, %edx
	jne	.L558
	cmpl	$0, 12(%rsp)
	je	.L620
	movl	%esi, %eax
	movl	$0, %edx
	divl	12(%rsp)
	cmpl	$1, %edx
	movl	$1, %eax
	adcb	$0, %al
	leaq	4716(%rbp), %rdx
	cmpq	$-4716, %rbp
	jnb	.L621
	movb	%al, 4716(%rbp)
.L558:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L617:
	.cfi_restore_state
	movl	4276(%rbp), %eax
	jmp	.L591
.L618:
	movl	4268(%rbp), %eax
	jmp	.L591
.L619:
	movl	%esi, %esi
	movl	$0, %edx
	leaq	.Lubsan_data11(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L620:
	movl	%esi, %esi
	movl	$0, %edx
	leaq	.Lubsan_data12(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L621:
	movq	%rbp, %rsi
	leaq	.Lubsan_data219(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L566:
	movl	4252(%rbp), %eax
	subl	4276(%rbp), %eax
	cmpl	$3071, %eax
	ja	.L567
	jmp	.L599
	.cfi_endproc
.LFE26:
	.size	crl_tick1, .-crl_tick1
	.globl	cr_loop_layers
	.type	cr_loop_layers, @function
cr_loop_layers:
.LFB5:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L623
	testb	$7, %dil
	jne	.L623
	leaq	14(%rdi), %rdx
	cmpq	$-14, %rdi
	jnb	.L627
	movzbl	14(%rdi), %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L623:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data221(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L627:
	movq	%rdi, %rsi
	leaq	.Lubsan_data222(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE5:
	.size	cr_loop_layers, .-cr_loop_layers
	.globl	cr_loop_init
	.type	cr_loop_init, @function
cr_loop_init:
.LFB6:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movl	$4728, %esi
	call	crl_zero
	testq	%rbx, %rbx
	je	.L629
	testb	$7, %bl
	jne	.L629
	leaq	2(%rbx), %rdx
	cmpq	$-2, %rbx
	jnb	.L636
	movb	$1, 2(%rbx)
	leaq	3(%rbx), %rdx
	cmpq	$-3, %rbx
	jnb	.L637
	movb	$100, 3(%rbx)
	leaq	6(%rbx), %rdx
	cmpq	$-6, %rbx
	jnb	.L638
	movb	$70, 6(%rbx)
	leaq	4244(%rbx), %rdx
	cmpq	$-4244, %rbx
	jnb	.L639
	movb	$0, 4244(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L629:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data223(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L636:
	movq	%rbx, %rsi
	leaq	.Lubsan_data224(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L637:
	movq	%rbx, %rsi
	leaq	.Lubsan_data225(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L638:
	movq	%rbx, %rsi
	leaq	.Lubsan_data226(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L639:
	movq	%rbx, %rsi
	leaq	.Lubsan_data227(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE6:
	.size	cr_loop_init, .-cr_loop_init
	.globl	cr_loop_gesture
	.type	cr_loop_gesture, @function
cr_loop_gesture:
.LFB20:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	movl	%esi, %edi
	movl	%edx, %r10d
	cmpb	$7, %cl
	setbe	%dl
	testb	%r9b, %r9b
	setne	%al
	testb	%al, %dl
	je	.L641
	cmpw	$127, %r10w
	jbe	.L742
.L641:
	testq	%rbx, %rbx
	je	.L648
	testb	$7, %bl
	jne	.L648
	leaq	4717(%rbx), %rdx
	cmpq	$-4717, %rbx
	jnb	.L743
	cmpb	$0, 4717(%rbx)
	je	.L651
	cmpb	$6, 4245(%rbx)
	je	.L640
.L651:
	movl	$4306, %eax
	movl	$0, %esi
	cmpl	$0, 48(%rsp)
	je	.L653
	movl	$0, %ebp
	jmp	.L659
.L742:
	testq	%rbx, %rbx
	je	.L642
	testb	$7, %bl
	jne	.L642
	leaq	4718(%rbx), %rdx
	cmpq	$-4718, %rbx
	jnb	.L744
	movb	$1, 4718(%rbx)
	leaq	4719(%rbx), %rdx
	cmpq	$-4719, %rbx
	jnb	.L745
	movb	%r10b, 4719(%rbx)
	movl	%ecx, %eax
	sall	$4, %eax
	movl	%r8d, %edx
	andl	$15, %edx
	orl	%edx, %eax
	leaq	4720(%rbx), %rdx
	cmpq	$-4720, %rbx
	jnb	.L746
	movb	%al, 4720(%rbx)
	leaq	4721(%rbx), %rdx
	cmpq	$-4721, %rbx
	jnb	.L747
	movb	%r9b, 4721(%rbx)
	jmp	.L641
.L642:
	movq	%rbx, %rsi
	leaq	.Lubsan_data228(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L744:
	movq	%rbx, %rsi
	leaq	.Lubsan_data229(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L745:
	movq	%rbx, %rsi
	leaq	.Lubsan_data230(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L746:
	movq	%rbx, %rsi
	leaq	.Lubsan_data231(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L747:
	movq	%rbx, %rsi
	leaq	.Lubsan_data232(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L648:
	movq	%rbx, %rsi
	leaq	.Lubsan_data233(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L743:
	movq	%rbx, %rsi
	leaq	.Lubsan_data234(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L749:
	movl	%ebp, %esi
	leaq	.Lubsan_data235(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L655:
	cmpq	%rdx, %rbx
	jb	.L657
.L656:
	cmpb	$0, (%rbx,%rax)
	je	.L658
	addl	$1, %ebp
	addq	$16, %rax
	cmpl	$16, %ebp
	je	.L748
.L659:
	cmpl	$15, %ebp
	ja	.L749
	leaq	(%rbx,%rax), %rdx
	testq	%rax, %rax
	js	.L655
	cmpq	%rbx, %rdx
	jnb	.L656
.L657:
	movq	%rbx, %rsi
	leaq	.Lubsan_data236(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L748:
	movl	$4300, %esi
	movl	$0, %ebp
	movl	$0, %eax
	jmp	.L667
.L752:
	movl	%eax, %esi
	leaq	.Lubsan_data237(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L661:
	cmpq	%rdx, %rbx
	jb	.L663
.L662:
	movl	(%rbx,%rsi), %r11d
	cmpl	$15, %ebp
	ja	.L750
	movl	%ebp, %edx
	salq	$4, %rdx
	leaq	4300(%rbx,%rdx), %rdx
	cmpq	%rbx, %rdx
	jb	.L751
	movl	%ebp, %edx
	salq	$4, %rdx
	cmpl	4300(%rbx,%rdx), %r11d
	cmovs	%eax, %ebp
	addl	$1, %eax
	addq	$16, %rsi
	cmpl	$16, %eax
	je	.L658
.L667:
	cmpl	$15, %eax
	ja	.L752
	leaq	(%rbx,%rsi), %rdx
	testq	%rsi, %rsi
	js	.L661
	cmpq	%rbx, %rdx
	jnb	.L662
.L663:
	movq	%rbx, %rsi
	leaq	.Lubsan_data238(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L750:
	movl	%ebp, %esi
	leaq	.Lubsan_data239(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L751:
	movq	%rbx, %rsi
	leaq	.Lubsan_data240(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L658:
	cmpl	$15, %ebp
	ja	.L753
	movl	%ebp, %eax
	salq	$4, %rax
	leaq	4306(%rbx,%rax), %rdx
	cmpq	%rbx, %rdx
	jb	.L754
	leaq	(%rbx,%rax), %r12
	movb	$1, 4306(%r12)
	cmpl	$15, %ebp
	ja	.L755
	leaq	4296(%rbx,%rax), %rdx
	cmpq	%rbx, %rdx
	jb	.L756
	movl	%edi, 4296(%r12)
	cmpl	$15, %ebp
	ja	.L757
	movl	4252(%rbx), %edx
	leaq	4300(%rax), %r13
	movq	%rbx, %rsi
	addq	%r13, %rsi
	jc	.L758
	movl	%edx, 4300(%r12)
	cmpl	$15, %ebp
	ja	.L759
	leaq	4304(%rbx,%rax), %rsi
	cmpq	%rbx, %rsi
	jb	.L760
	movw	%r10w, 4304(%r12)
	cmpl	$15, %ebp
	ja	.L761
	leaq	4307(%rbx,%rax), %rsi
	cmpq	%rbx, %rsi
	jb	.L762
	movb	%cl, 4307(%r12)
	cmpl	$15, %ebp
	ja	.L763
	leaq	4308(%rbx,%rax), %rcx
	cmpq	%rbx, %rcx
	jb	.L764
	movb	%r8b, 4308(%r12)
	cmpl	$15, %ebp
	ja	.L765
	leaq	4309(%rbx,%rax), %rcx
	cmpq	%rbx, %rcx
	jb	.L766
	movb	%r9b, 4309(%r12)
	cmpl	$15, %ebp
	ja	.L767
	leaq	4310(%rax), %r14
	movq	%rbx, %rax
	addq	%r14, %rax
	jc	.L768
	movb	$0, 4310(%r12)
	movzbl	4245(%rbx), %eax
	cmpb	$1, %al
	je	.L769
	cmpb	$4, %al
	je	.L770
.L687:
	cmpb	$5, 4245(%rbx)
	je	.L771
.L688:
	cmpb	$0, 4245(%rbx)
	je	.L640
	addw	$1, 4700(%rbx)
	jmp	.L640
.L753:
	movl	%ebp, %esi
	leaq	.Lubsan_data241(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L754:
	movq	%rbx, %rsi
	leaq	.Lubsan_data242(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L755:
	movl	%ebp, %esi
	leaq	.Lubsan_data243(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L756:
	movq	%rbx, %rsi
	leaq	.Lubsan_data244(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L757:
	movl	%ebp, %esi
	leaq	.Lubsan_data245(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L758:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data246(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L759:
	movl	%ebp, %esi
	leaq	.Lubsan_data247(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L760:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data248(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L761:
	movl	%ebp, %esi
	leaq	.Lubsan_data249(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L762:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data250(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L763:
	movl	%ebp, %esi
	leaq	.Lubsan_data251(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L764:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data252(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L765:
	movl	%ebp, %esi
	leaq	.Lubsan_data253(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L766:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data254(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L767:
	movl	%ebp, %esi
	leaq	.Lubsan_data255(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L768:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data256(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L769:
	movq	%rbx, %rdi
	call	crl_take_start
	movb	$3, 4245(%rbx)
	movl	4252(%rbx), %eax
	movl	%eax, 4276(%rbx)
	movl	$0, 4280(%rbx)
	movw	$0, 4248(%rbx)
	cmpl	$15, %ebp
	ja	.L772
	addq	%rbx, %r13
	jc	.L773
	movl	%eax, 4300(%r12)
	jmp	.L687
.L772:
	movl	%ebp, %esi
	leaq	.Lubsan_data257(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L773:
	movq	%r13, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data258(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L770:
	movb	$5, 4245(%rbx)
	movl	%edx, 4288(%rbx)
	movzwl	12(%rbx), %eax
	movw	%ax, 4248(%rbx)
	jmp	.L687
.L771:
	cmpb	$0, 4681(%rbx)
	je	.L688
	cmpb	$2, 4244(%rbx)
	jne	.L688
	movl	8(%rbx), %ecx
	testl	%ecx, %ecx
	je	.L688
	cmpl	$15, %ebp
	ja	.L774
	movq	%r14, %rdx
	addq	%rbx, %rdx
	jc	.L775
	movb	$1, 4310(%r12)
	movzbl	4682(%rbx), %eax
	leal	1(%rax), %edx
	movb	%dl, 4682(%rbx)
	testb	%al, %al
	jne	.L691
	movl	4252(%rbx), %eax
	subl	4268(%rbx), %eax
	movl	$0, %edx
	divl	%ecx
	movl	%edx, 4684(%rbx)
.L691:
	movl	4252(%rbx), %eax
	subl	4268(%rbx), %eax
	movl	$0, %edx
	divl	%ecx
	movl	%edx, %r14d
	movzwl	4248(%rbx), %r13d
	testl	%r13d, %r13d
	je	.L688
	leaq	146(%rbx), %rbp
	movl	$0, %r12d
	jmp	.L716
.L774:
	movl	%ebp, %esi
	leaq	.Lubsan_data259(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L775:
	movq	%rbx, %rsi
	leaq	.Lubsan_data260(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L782:
	movl	%r12d, %esi
	leaq	.Lubsan_data261(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L783:
	movq	%rbx, %rsi
	leaq	.Lubsan_data262(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L694:
	movq	%rax, %rsi
	leaq	.Lubsan_data263(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L784:
	leaq	.Lubsan_data264(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L785:
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data3(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L786:
	movb	$1, 4246(%rbx)
	jmp	.L688
.L787:
	movslq	%ecx, %rsi
	leaq	.Lubsan_data265(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L788:
	movq	%r8, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data266(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L789:
	leaq	.Lubsan_data267(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L790:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data268(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L791:
	movq	%rdx, %rsi
	leaq	.Lubsan_data269(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L792:
	movq	%rbx, %rsi
	leaq	.Lubsan_data270(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L779:
	movl	%edx, %esi
	leaq	.Lubsan_data271(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L707:
	cmpq	%rcx, %rbx
	jb	.L709
.L708:
	cmpb	$0, (%rbx,%rax)
	je	.L710
	cmpl	$7, %edx
	ja	.L776
	leaq	-2(%rbx,%rax), %rcx
	cmpq	%rbx, %rcx
	jb	.L777
	movzwl	-2(%rbx,%rax), %ecx
	cmpl	%ecx, %r12d
	je	.L778
.L710:
	addl	$1, %edx
	addq	$8, %rax
	cmpl	$8, %edx
	je	.L697
.L715:
	cmpl	$7, %edx
	ja	.L779
	leaq	(%rbx,%rax), %rcx
	testq	%rax, %rax
	js	.L707
	cmpq	%rbx, %rcx
	jnb	.L708
.L709:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data272(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L776:
	movl	%edx, %esi
	leaq	.Lubsan_data273(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L777:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data274(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L778:
	cmpl	$7, %edx
	ja	.L780
	movl	4252(%rbx), %esi
	leaq	-6(%rbx,%rax), %rcx
	cmpq	%rbx, %rcx
	jb	.L781
	movl	%esi, -6(%rbx,%rax)
	jmp	.L710
.L780:
	movl	%edx, %esi
	leaq	.Lubsan_data275(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L781:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data276(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L697:
	addl	$1, %r12d
	addq	$8, %rbp
	cmpl	%r12d, %r13d
	je	.L688
.L716:
	cmpl	$512, %r12d
	ja	.L782
	movq	%rbp, %rdx
	cmpq	%rbx, %rbp
	jb	.L783
	movq	%rbp, %rsi
	movq	%rbp, %rax
	testq	%rbp, %rbp
	je	.L694
	testb	$1, %bpl
	jne	.L694
	leaq	7(%rbp), %rdx
	cmpq	$-7, %rbp
	jnb	.L784
	cmpb	$0, 7(%rbp)
	js	.L697
	movl	8(%rbx), %ecx
	leal	(%r14,%rcx), %eax
	movzwl	0(%rbp), %edx
	subl	%edx, %eax
	testl	%ecx, %ecx
	je	.L785
	movl	$0, %edx
	divl	%ecx
	testl	%edx, %edx
	je	.L697
	movzwl	2(%rbp), %eax
	cmpl	%eax, %edx
	jnb	.L697
	movzwl	12(%rbx), %eax
	cmpw	$511, %ax
	ja	.L786
	movzwl	%ax, %ecx
	ja	.L787
	movzwl	%ax, %edi
	salq	$3, %rdi
	leaq	146(%rbx,%rdi), %r8
	cmpq	%rbx, %r8
	jb	.L788
	movzwl	%ax, %r8d
	leaq	(%rbx,%r8,8), %r8
	movq	0(%rbp), %rsi
	movq	%rsi, 146(%r8)
	movslq	%ecx, %rsi
	cmpq	$512, %rsi
	jnb	.L789
	leaq	148(%rbx,%rdi), %rsi
	cmpq	%rbx, %rsi
	jb	.L790
	movw	%dx, 148(%r8)
	movslq	%ecx, %rdx
	cmpq	$512, %rdx
	jnb	.L791
	movzbl	14(%rbx), %ecx
	leaq	153(%rbx,%rdi), %rdx
	cmpq	%rbx, %rdx
	jb	.L792
	movb	%cl, 153(%r8)
	addl	$1, %eax
	movw	%ax, 12(%rbx)
	movl	%r12d, %esi
	movq	%rbx, %rdi
	call	crl_hide
	movl	$4558, %eax
	movl	$0, %edx
	jmp	.L715
.L796:
	movl	%esi, %esi
	leaq	.Lubsan_data277(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L718:
	cmpq	%rdx, %rbx
	jb	.L720
.L719:
	cmpb	$0, (%rbx,%rax)
	je	.L721
	cmpl	$15, %esi
	ja	.L793
	leaq	-10(%rbx,%rax), %rdx
	cmpq	%rbx, %rdx
	jb	.L794
	cmpl	%edi, -10(%rbx,%rax)
	je	.L795
.L721:
	addl	$1, %esi
	addq	$16, %rax
	cmpl	$16, %esi
	je	.L640
.L653:
	cmpl	$15, %esi
	ja	.L796
	leaq	(%rbx,%rax), %rdx
	testq	%rax, %rax
	js	.L718
	cmpq	%rbx, %rdx
	jnb	.L719
.L720:
	movq	%rbx, %rsi
	leaq	.Lubsan_data278(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L793:
	movl	%esi, %esi
	leaq	.Lubsan_data279(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L794:
	movq	%rbx, %rsi
	leaq	.Lubsan_data280(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L795:
	cmpl	$15, %esi
	ja	.L797
	leaq	(%rbx,%rax), %rdx
	testq	%rax, %rax
	js	.L725
	cmpq	%rbx, %rdx
	jnb	.L726
.L727:
	movq	%rbx, %rsi
	leaq	.Lubsan_data282(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L797:
	movl	%esi, %esi
	leaq	.Lubsan_data281(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L725:
	cmpq	%rdx, %rbx
	jb	.L727
.L726:
	movl	%esi, %edx
	movq	%rdx, %rdi
	salq	$4, %rdi
	addq	%rbx, %rdi
	movb	$0, 4306(%rdi)
	cmpq	$16, %rdx
	jnb	.L798
	leaq	4(%rbx,%rax), %rdx
	cmpq	%rbx, %rdx
	jb	.L799
	cmpb	$0, 4310(%rdi)
	je	.L730
	movzbl	4682(%rbx), %edx
	testb	%dl, %dl
	je	.L730
	subl	$1, %edx
	movb	%dl, 4682(%rbx)
.L730:
	movzbl	%r9b, %r9d
	movzbl	%r8b, %r8d
	movzbl	%cl, %ecx
	movswl	%r10w, %edx
	cmpl	$15, %esi
	ja	.L800
	leaq	-6(%rbx,%rax), %rax
	cmpq	%rbx, %rax
	jb	.L801
	movl	4300(%rdi), %esi
	movq	%rbx, %rdi
	call	crl_write
.L640:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L798:
	.cfi_restore_state
	movl	%esi, %esi
	leaq	.Lubsan_data283(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L799:
	movq	%rbx, %rsi
	leaq	.Lubsan_data284(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L800:
	movl	%esi, %esi
	leaq	.Lubsan_data285(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L801:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data286(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE20:
	.size	cr_loop_gesture, .-cr_loop_gesture
	.globl	cr_loop_tick
	.type	cr_loop_tick, @function
cr_loop_tick:
.LFB27:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, %rbp
	testq	%rsi, %rsi
	je	.L803
	movq	%rdi, %rbx
	testb	$7, %sil
	jne	.L803
	leaq	20(%rsi), %rax
	cmpq	$-20, %rsi
	jnb	.L816
	movzwl	20(%rsi), %ecx
	movzwl	%cx, %eax
	testw	%cx, %cx
	movl	$120, %ecx
	cmovne	%eax, %ecx
	testq	%rdi, %rdi
	je	.L807
	testb	$7, %dil
	jne	.L807
	leaq	4264(%rdi), %rax
	cmpq	$-4264, %rdi
	jnb	.L817
	cmpb	$0, 4264(%rdi)
	je	.L818
	movl	%edx, %eax
	subl	4260(%rdi), %eax
	movl	%edx, 4260(%rdi)
	movl	$1000, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	imull	%ecx, %eax
	leal	(%rax,%rax,2), %eax
	sall	$5, %eax
	addl	4256(%rdi), %eax
	movl	%eax, 4256(%rdi)
	cmpl	$59999, %eax
	jbe	.L802
.L812:
	subl	$60000, %eax
	movl	%eax, 4256(%rbx)
	addl	$1, 4252(%rbx)
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	crl_tick1
	movl	4256(%rbx), %eax
	cmpl	$59999, %eax
	ja	.L812
.L802:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L803:
	.cfi_restore_state
	movq	%rbp, %rsi
	leaq	.Lubsan_data287(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L816:
	movq	%rax, %rdx
	leaq	.Lubsan_data288(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L807:
	movq	%rbx, %rsi
	leaq	.Lubsan_data289(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L817:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data290(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L818:
	movb	$1, 4264(%rdi)
	movl	%edx, 4260(%rdi)
	call	crl_tick1
	jmp	.L802
	.cfi_endproc
.LFE27:
	.size	cr_loop_tick, .-cr_loop_tick
	.globl	cr_loop_stop
	.type	cr_loop_stop, @function
cr_loop_stop:
.LFB28:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L820
	movq	%rsi, %rbp
	testb	$7, %dil
	jne	.L820
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L826
	movb	$0, 4715(%rdi)
	movzbl	4245(%rdi), %eax
	leal	-3(%rax), %edx
	testb	$-3, %dl
	je	.L823
	cmpb	$6, %al
	jne	.L824
.L823:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	crl_commit
.L824:
	movb	$0, 4245(%rbx)
	movb	$0, 4680(%rbx)
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	crl_voices_off
	movb	$0, 4712(%rbx)
	cmpl	$0, 8(%rbx)
	setne	4244(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L820:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data291(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L826:
	movq	%rdi, %rsi
	leaq	.Lubsan_data292(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE28:
	.size	cr_loop_stop, .-cr_loop_stop
	.globl	cr_loop_rec
	.type	cr_loop_rec, @function
cr_loop_rec:
.LFB29:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L828
	testb	$7, %dil
	jne	.L828
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L874
	movb	$0, 4715(%rdi)
	movzbl	7(%rdi), %eax
	cmpb	$4, %al
	ja	.L831
	movzbl	4245(%rdi), %edx
	cmpb	$3, %dl
	je	.L832
	ja	.L833
	testb	%dl, %dl
	jne	.L835
	movzbl	%al, %ebp
	cmpb	$4, %al
	je	.L875
	movzbl	4244(%rdi), %edx
	testb	%dl, %dl
	je	.L849
	cmpb	$1, %al
	jbe	.L850
	cmpb	$31, 14(%rdi)
	ja	.L860
	cmpw	$511, 12(%rdi)
	ja	.L860
	cmpb	$1, %dl
	je	.L876
.L862:
	movb	$0, 4712(%rbx)
	movb	$4, 4245(%rbx)
	cmpl	$3, %ebp
	sete	4681(%rbx)
	movb	$0, 4682(%rbx)
	movl	$6, %eax
	movl	$13, %edx
	cmove	%edx, %eax
	jmp	.L827
.L828:
	movq	%rbx, %rsi
	leaq	.Lubsan_data293(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L874:
	movq	%rdi, %rsi
	leaq	.Lubsan_data294(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L833:
	subl	$5, %edx
	cmpb	$1, %dl
	ja	.L835
.L832:
	movq	%rbx, %rdi
	call	crl_commit
.L827:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L875:
	.cfi_restore_state
	cmpb	$2, 4244(%rdi)
	je	.L877
.L837:
	movb	$0, 4712(%rbx)
	movb	$6, 4245(%rbx)
	movzwl	12(%rbx), %eax
	movw	%ax, 4248(%rbx)
	movw	$0, 4690(%rbx)
	movw	$0, 4688(%rbx)
	movb	$0, 4693(%rbx)
	movzbl	1(%rbx), %eax
	cmpb	$6, %al
	ja	.L838
	movzbl	%al, %ecx
	ja	.L878
	movzbl	%al, %edx
	leaq	CRL_QGRID(%rip), %rsi
	leaq	(%rdx,%rsi), %rsi
	leaq	1(%rdx), %rdx
	cmpq	$7, %rdx
	ja	.L879
.L840:
	leaq	CRL_QGRID(%rip), %rsi
	movzbl	%al, %eax
	addq	%rsi, %rax
	jc	.L880
	movslq	%ecx, %rcx
	leaq	CRL_QGRID(%rip), %rax
	movzbl	(%rax,%rcx), %eax
	movb	%al, 4692(%rbx)
	testb	%al, %al
	je	.L863
.L842:
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	je	.L867
	movzbl	%dl, %eax
	cmpb	$5, %dl
	movl	$1, %edx
	cmovnb	%edx, %eax
	movslq	%eax, %rdx
	cmpq	$5, %rdx
	jnb	.L881
	movslq	%eax, %rcx
	leaq	CRL_BARS(%rip), %rdx
	leaq	(%rcx,%rdx), %rsi
	leaq	1(%rcx), %rdx
	cmpq	$5, %rdx
	ja	.L882
.L846:
	leaq	CRL_BARS(%rip), %rdx
	addq	%rcx, %rdx
	jc	.L883
	cltq
	leaq	CRL_BARS(%rip), %rdx
	movzbl	(%rdx,%rax), %ebp
	movq	%rbx, %rdi
	call	cr_loop_bar
	imull	%ebp, %eax
	jmp	.L843
.L877:
	call	crl_voices_off
	movb	$1, 4244(%rbx)
	jmp	.L837
.L878:
	movslq	%ecx, %rsi
	leaq	.Lubsan_data295(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L879:
	addq	%rsi, %rdx
	jc	.L840
	leaq	.Lubsan_data296(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L880:
	movq	%rax, %rdx
	leaq	.Lubsan_data297(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L881:
	movq	%rdx, %rsi
	leaq	.Lubsan_data298(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L882:
	addq	%rsi, %rdx
	jc	.L846
	leaq	.Lubsan_data299(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L883:
	leaq	CRL_BARS(%rip), %rsi
	leaq	.Lubsan_data300(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L867:
	movl	$0, %eax
.L843:
	movl	%eax, 4696(%rbx)
	cmpw	$511, 12(%rbx)
	seta	4246(%rbx)
	addw	$1, 4700(%rbx)
	movl	$14, %eax
	jmp	.L827
.L885:
	movb	$1, 4245(%rbx)
	movl	$1, %eax
	jmp	.L827
.L886:
	movq	%rdx, %rsi
	leaq	.Lubsan_data301(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L887:
	addq	%rsi, %rdx
	jc	.L855
	leaq	.Lubsan_data302(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L888:
	leaq	CRL_BARS(%rip), %rsi
	leaq	.Lubsan_data303(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L889:
	movq	%rbx, %rsi
	leaq	.Lubsan_data304(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L857:
	movq	%rbx, %rdi
	call	crl_take_start
	movb	$3, 4245(%rbx)
	movl	4252(%rbx), %eax
	movl	%eax, 4276(%rbx)
	cmpb	$0, 5(%rbx)
	je	.L870
	leaq	4716(%rbx), %rdx
	cmpq	$-4716, %rbx
	jnb	.L884
	movb	$2, 4716(%rbx)
	movl	$3, %eax
	jmp	.L827
.L884:
	movq	%rbx, %rsi
	leaq	.Lubsan_data305(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L860:
	movb	$1, 4246(%rbx)
	movl	$0, %eax
	jmp	.L827
.L876:
	call	crl_start
	jmp	.L862
.L870:
	movl	$3, %eax
	jmp	.L827
.L838:
	movb	$0, 4692(%rbx)
.L863:
	movb	$24, 4692(%rbx)
	jmp	.L842
.L850:
	movq	%rbx, %rdi
	call	crl_voices_off
	movb	$1, 4244(%rbx)
	movb	$0, 4712(%rbx)
	movl	$1, %eax
.L864:
	movb	%al, 4680(%rbx)
	movb	$0, 4246(%rbx)
	movw	$0, 4248(%rbx)
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	je	.L885
	movzbl	%dl, %eax
	cmpb	$5, %dl
	movl	$1, %edx
	cmovnb	%edx, %eax
	movslq	%eax, %rdx
	cmpq	$5, %rdx
	jnb	.L886
	movslq	%eax, %rcx
	leaq	CRL_BARS(%rip), %rdx
	leaq	(%rcx,%rdx), %rsi
	leaq	1(%rcx), %rdx
	cmpq	$5, %rdx
	ja	.L887
.L855:
	leaq	CRL_BARS(%rip), %rdx
	addq	%rcx, %rdx
	jc	.L888
	cltq
	leaq	CRL_BARS(%rip), %rdx
	movzbl	(%rdx,%rax), %ebp
	movq	%rbx, %rdi
	call	cr_loop_bar
	imull	%eax, %ebp
	movl	%ebp, 4280(%rbx)
	cmpb	$0, 2(%rbx)
	je	.L857
	movb	$2, 4245(%rbx)
	movl	4252(%rbx), %eax
	movl	%eax, 4284(%rbx)
	leaq	4716(%rbx), %rdx
	cmpq	$-4716, %rbx
	jnb	.L889
	movb	$2, 4716(%rbx)
	movl	$2, %eax
	jmp	.L827
.L831:
	movzbl	4245(%rdi), %eax
	cmpb	$3, %al
	je	.L832
	ja	.L865
	testb	%al, %al
	jne	.L835
	cmpb	$0, 4244(%rdi)
	jne	.L850
.L849:
	movq	%rbx, %rdi
	call	crl_drop_take
	movl	$0, %eax
	jmp	.L864
.L865:
	subl	$5, %eax
	cmpb	$1, %al
	jbe	.L832
.L835:
	movb	$0, 4245(%rbx)
	movb	$0, 4680(%rbx)
	movb	$0, 4681(%rbx)
	movl	$4, %eax
	jmp	.L827
	.cfi_endproc
.LFE29:
	.size	cr_loop_rec, .-cr_loop_rec
	.globl	cr_loop_play
	.type	cr_loop_play, @function
cr_loop_play:
.LFB30:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L891
	movq	%rsi, %rbp
	testb	$7, %dil
	jne	.L891
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L905
	movb	$0, 4715(%rdi)
	movzbl	4245(%rdi), %eax
	cmpb	$5, %al
	ja	.L894
	cmpb	$3, %al
	ja	.L895
	cmpb	$2, %al
	jbe	.L906
	call	crl_commit
	jmp	.L890
.L891:
	movq	%rbx, %rsi
	leaq	.Lubsan_data306(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L905:
	movq	%rdi, %rsi
	leaq	.Lubsan_data307(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L906:
	testb	%al, %al
	je	.L898
	movb	$0, 4245(%rdi)
	movb	$0, 4680(%rdi)
	movl	$4, %eax
.L890:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L894:
	.cfi_restore_state
	cmpb	$6, %al
	jne	.L898
	movl	$1, %edx
	call	crl_step_commit
	cmpb	$2, 4244(%rbx)
	movl	$8, %edx
	cmove	%edx, %eax
	jmp	.L890
.L895:
	call	crl_commit
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	cr_loop_stop
	movl	$9, %eax
	jmp	.L890
.L898:
	movzbl	4244(%rbx), %edx
	cmpb	$2, %dl
	je	.L907
	movl	$0, %eax
	cmpb	$1, %dl
	jne	.L890
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	crl_start
	movl	$8, %eax
	jmp	.L890
.L907:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	cr_loop_stop
	movl	$9, %eax
	jmp	.L890
	.cfi_endproc
.LFE30:
	.size	cr_loop_play, .-cr_loop_play
	.globl	cr_loop_play_synced
	.type	cr_loop_play_synced, @function
cr_loop_play_synced:
.LFB31:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L909
	movq	%rsi, %r12
	movl	%edx, %ebp
	testb	$7, %dil
	jne	.L909
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L922
	cmpb	$0, 4715(%rdi)
	jne	.L923
	cmpb	$6, 4245(%rdi)
	je	.L924
.L914:
	cmpw	$1, 4244(%rbx)
	jne	.L925
	movl	$2, %eax
	testl	%ebp, %ebp
	je	.L926
.L916:
	movb	%al, 4715(%rbx)
	movl	$16, %eax
.L908:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L909:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data308(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L922:
	movq	%rdi, %rsi
	leaq	.Lubsan_data309(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L923:
	movb	$0, 4715(%rdi)
	movl	$4, %eax
	jmp	.L908
.L924:
	movl	$0, %edx
	call	crl_step_commit
	jmp	.L914
.L925:
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	cr_loop_play
	jmp	.L908
.L926:
	movq	%rbx, %rdi
	call	cr_loop_beat
	movl	%eax, %ecx
	movl	4252(%rbx), %eax
	subl	4292(%rbx), %eax
	testl	%ecx, %ecx
	je	.L927
	movl	$0, %edx
	divl	%ecx
	testl	%edx, %edx
	jne	.L919
	movl	$1, %eax
	cmpl	$0, 4256(%rbx)
	jne	.L916
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	cr_loop_play
	jmp	.L908
.L927:
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data13(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L919:
	movl	$1, %eax
	jmp	.L916
	.cfi_endproc
.LFE31:
	.size	cr_loop_play_synced, .-cr_loop_play_synced
	.globl	cr_loop_play_boundary
	.type	cr_loop_play_boundary, @function
cr_loop_play_boundary:
.LFB32:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L929
	testb	$7, %dil
	jne	.L929
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L934
	cmpb	$2, 4715(%rdi)
	je	.L935
.L928:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L929:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data310(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L934:
	movq	%rdi, %rsi
	leaq	.Lubsan_data311(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L935:
	cmpw	$1, 4244(%rdi)
	jne	.L928
	call	crl_start
	jmp	.L928
	.cfi_endproc
.LFE32:
	.size	cr_loop_play_boundary, .-cr_loop_play_boundary
	.globl	cr_loop_undo
	.type	cr_loop_undo, @function
cr_loop_undo:
.LFB33:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L937
	testb	$7, %dil
	jne	.L937
	leaq	4245(%rdi), %rdx
	cmpq	$-4245, %rdi
	jnb	.L957
	movzbl	4245(%rdi), %eax
	leal	-4(%rax), %edx
	cmpb	$1, %dl
	jbe	.L958
	testb	%al, %al
	jne	.L954
	movzbl	14(%rdi), %esi
	cmpb	$1, %sil
	jbe	.L955
	movzbl	%sil, %eax
	leal	-1(%rax), %edx
	cmpl	$31, %edx
	ja	.L959
	addl	$2307, %eax
	movl	%eax, %eax
	leaq	(%rdi,%rax,2), %rax
	cmpq	%rdi, %rax
	jb	.L960
	movl	%edx, %edx
	movzwl	12(%rdi), %eax
	movzwl	4616(%rdi,%rdx,2), %edx
	cmpw	%dx, %ax
	cmova	%edx, %eax
	movw	%ax, 12(%rdi)
	subl	$1, %esi
	movb	%sil, 14(%rdi)
	movzbl	%sil, %esi
	call	crl_restore
	leaq	4700(%rbx), %rdx
	cmpq	$-4700, %rbx
	jnb	.L961
	addw	$1, 4700(%rbx)
	movb	$0, 4246(%rbx)
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L962
	movb	$1, 4713(%rbx)
	movb	$0, 4712(%rbx)
	movl	$10, %eax
.L936:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L937:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data312(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L957:
	movq	%rdi, %rsi
	leaq	.Lubsan_data313(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L958:
	movl	$0, %ebp
	cmpb	$5, %al
	je	.L963
.L941:
	leaq	4248(%rbx), %rdx
	cmpq	$-4248, %rbx
	jnb	.L964
	movzwl	4248(%rbx), %eax
	movw	%ax, 12(%rbx)
	movzbl	14(%rbx), %esi
	movq	%rbx, %rdi
	call	crl_restore
	movb	$0, 4245(%rbx)
	leaq	4682(%rbx), %rdx
	cmpq	$-4682, %rbx
	jnb	.L965
	movb	$0, 4682(%rbx)
	movb	$0, 4681(%rbx)
	movb	$0, 4246(%rbx)
	leaq	4700(%rbx), %rdx
	cmpq	$-4700, %rbx
	jnb	.L966
	addw	$1, 4700(%rbx)
	cmpl	$1, %ebp
	sbbl	%eax, %eax
	andl	$-6, %eax
	addl	$10, %eax
	jmp	.L936
.L963:
	movzwl	12(%rdi), %eax
	leaq	4248(%rdi), %rdx
	cmpq	$-4248, %rdi
	jnb	.L967
	cmpw	%ax, 4248(%rdi)
	setb	%bpl
	movzbl	%bpl, %ebp
	jmp	.L941
.L967:
	movq	%rdi, %rsi
	leaq	.Lubsan_data314(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L964:
	movq	%rbx, %rsi
	leaq	.Lubsan_data315(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L965:
	movq	%rbx, %rsi
	leaq	.Lubsan_data316(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L966:
	movq	%rbx, %rsi
	leaq	.Lubsan_data317(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L959:
	movl	%edx, %esi
	leaq	.Lubsan_data318(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L960:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data319(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L961:
	movq	%rbx, %rsi
	leaq	.Lubsan_data320(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L962:
	movq	%rbx, %rsi
	leaq	.Lubsan_data321(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L954:
	movl	$0, %eax
	jmp	.L936
.L955:
	movl	$0, %eax
	jmp	.L936
	.cfi_endproc
.LFE33:
	.size	cr_loop_undo, .-cr_loop_undo
	.globl	cr_loop_clear
	.type	cr_loop_clear, @function
cr_loop_clear:
.LFB34:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L969
	testb	$7, %dil
	jne	.L969
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L973
	movb	$0, 4715(%rdi)
	movb	$0, 4245(%rdi)
	movb	$0, 4682(%rdi)
	movb	$0, 4681(%rdi)
	movb	$0, 4680(%rdi)
	call	crl_voices_off
	movq	%rbx, %rdi
	call	crl_drop_take
	addw	$1, 4700(%rbx)
	movb	$0, 4246(%rbx)
	movb	$0, 4712(%rbx)
	movb	$1, 4713(%rbx)
	movl	$11, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L969:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data322(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L973:
	movq	%rdi, %rsi
	leaq	.Lubsan_data323(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE34:
	.size	cr_loop_clear, .-cr_loop_clear
	.globl	cr_loop_panic
	.type	cr_loop_panic, @function
cr_loop_panic:
.LFB35:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L975
	testb	$7, %dil
	jne	.L975
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L993
	movb	$0, 4715(%rdi)
	movb	$0, 4558(%rdi)
	movb	$0, 4566(%rdi)
	movb	$0, 4574(%rdi)
	movb	$0, 4582(%rdi)
	movb	$0, 4590(%rdi)
	movb	$0, 4598(%rdi)
	movb	$0, 4606(%rdi)
	movb	$0, 4614(%rdi)
	movzbl	4245(%rdi), %eax
	cmpb	$3, %al
	je	.L994
	cmpb	$5, %al
	je	.L995
	leal	-4(%rax), %edx
	cmpb	$2, %dl
	jbe	.L996
.L979:
	movb	$0, 4682(%rbx)
	movb	$0, 4681(%rbx)
	movb	$0, 4680(%rbx)
	addw	$1, 4700(%rbx)
	movl	$4306, %eax
	movl	$0, %edx
	jmp	.L988
.L975:
	movq	%rbx, %rsi
	leaq	.Lubsan_data325(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L993:
	movq	%rdi, %rsi
	leaq	.Lubsan_data326(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L994:
	call	crl_drop_take
	jmp	.L979
.L995:
	movzwl	4248(%rdi), %eax
	cmpw	12(%rdi), %ax
	jb	.L997
	movzwl	4248(%rdi), %eax
	movw	%ax, 12(%rdi)
.L989:
	movzbl	14(%rbx), %esi
	movq	%rbx, %rdi
	call	crl_restore
	jmp	.L979
.L997:
	movzwl	%ax, %esi
	call	crl_quantize
	movzbl	14(%rbx), %eax
	movzbl	%al, %edx
	cmpb	$31, %al
	ja	.L998
	movzwl	4248(%rbx), %esi
	movzbl	%al, %ecx
	leaq	4616(%rbx,%rcx,2), %rcx
	cmpq	%rbx, %rcx
	jb	.L999
	movslq	%edx, %rdx
	movw	%si, 4616(%rbx,%rdx,2)
	addl	$1, %eax
	movb	%al, 14(%rbx)
	movb	$1, 4713(%rbx)
	jmp	.L979
.L998:
	movslq	%edx, %rsi
	leaq	.Lubsan_data327(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L999:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data328(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L996:
	movzwl	4248(%rdi), %edx
	movw	%dx, 12(%rdi)
	cmpb	$6, %al
	je	.L979
	jmp	.L989
.L1001:
	movl	%edx, %esi
	leaq	.Lubsan_data329(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L985:
	cmpq	%rcx, %rbx
	jb	.L987
.L986:
	movb	$0, (%rbx,%rax)
	addl	$1, %edx
	addq	$16, %rax
	cmpl	$16, %edx
	je	.L1000
.L988:
	cmpl	$15, %edx
	ja	.L1001
	leaq	(%rbx,%rax), %rcx
	testq	%rax, %rax
	js	.L985
	cmpq	%rbx, %rcx
	jnb	.L986
.L987:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data330(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1000:
	movb	$0, 4245(%rbx)
	movb	$0, 4246(%rbx)
	movb	$0, 4712(%rbx)
	cmpl	$0, 8(%rbx)
	setne	4244(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE35:
	.size	cr_loop_panic, .-cr_loop_panic
	.globl	cr_loop_set
	.type	cr_loop_set, @function
cr_loop_set:
.LFB36:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L1003
	movq	%rdx, %rbp
	testb	$7, %dil
	jne	.L1003
	leaq	4715(%rdi), %rdx
	cmpq	$-4715, %rdi
	jnb	.L1007
	movb	$0, 4715(%rdi)
	movb	$0, 4245(%rdi)
	movb	$0, 4682(%rdi)
	movb	$0, 4681(%rdi)
	movb	$0, 4680(%rdi)
	call	crl_voices_off
	movq	%rbp, 4704(%rbx)
	movb	$0, 4712(%rbx)
	movq	%rbx, %rdi
	call	crl_take_next
	movb	$0, 4246(%rbx)
	cmpl	$0, 8(%rbx)
	setne	4244(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1003:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data331(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1007:
	movq	%rdi, %rsi
	leaq	.Lubsan_data332(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE36:
	.size	cr_loop_set, .-cr_loop_set
	.globl	cr_loop_queue
	.type	cr_loop_queue, @function
cr_loop_queue:
.LFB37:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	je	.L1009
	movq	%rdx, %rbp
	testb	$7, %dil
	jne	.L1009
	leaq	4244(%rdi), %rdx
	cmpq	$-4244, %rdi
	jnb	.L1020
	cmpb	$2, 4244(%rdi)
	jne	.L1021
	leaq	4245(%rdi), %rdx
	cmpq	$-4245, %rdi
	jnb	.L1022
	cmpb	$5, 4245(%rdi)
	je	.L1023
.L1015:
	movb	$0, 4245(%rbx)
	leaq	4682(%rbx), %rdx
	cmpq	$-4682, %rbx
	jnb	.L1024
	movb	$0, 4682(%rbx)
	movb	$0, 4681(%rbx)
	movb	$0, 4680(%rbx)
	leaq	4704(%rbx), %rdx
	cmpq	$-4704, %rbx
	jnb	.L1025
	movq	%rbp, 4704(%rbx)
	leaq	4712(%rbx), %rdx
	cmpq	$-4712, %rbx
	jnb	.L1026
	movb	$1, 4712(%rbx)
.L1008:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1009:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data333(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1020:
	movq	%rdi, %rsi
	leaq	.Lubsan_data334(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1021:
	movq	%rbp, %rdx
	call	cr_loop_set
	jmp	.L1008
.L1022:
	movq	%rdi, %rsi
	leaq	.Lubsan_data335(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1023:
	call	crl_commit
	jmp	.L1015
.L1024:
	movq	%rbx, %rsi
	leaq	.Lubsan_data336(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1025:
	movq	%rbx, %rsi
	leaq	.Lubsan_data337(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1026:
	movq	%rbx, %rsi
	leaq	.Lubsan_data338(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE37:
	.size	cr_loop_queue, .-cr_loop_queue
	.globl	cr_loop_step
	.type	cr_loop_step, @function
cr_loop_step:
.LFB38:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rdi, %rcx
	testq	%rdi, %rdi
	je	.L1028
	movl	%esi, %edi
	testb	$7, %cl
	jne	.L1028
	leaq	4245(%rcx), %rdx
	cmpq	$-4245, %rcx
	jnb	.L1045
	cmpb	$6, 4245(%rcx)
	jne	.L1027
	leaq	4692(%rcx), %rdx
	cmpq	$-4692, %rcx
	jnb	.L1046
	movzbl	4692(%rcx), %eax
	testb	%al, %al
	je	.L1027
	leaq	4696(%rcx), %rdx
	cmpq	$-4696, %rcx
	jnb	.L1047
	movl	4696(%rcx), %r8d
	testl	%r8d, %r8d
	je	.L1034
	movzbl	%al, %esi
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%esi
.L1035:
	movzwl	4688(%rcx), %esi
	movzwl	%si, %r9d
	testl	%edi, %edi
	jne	.L1036
	cmpb	$0, 4693(%rcx)
	je	.L1027
.L1037:
	leal	1(%r9), %edx
	movzwl	4690(%rcx), %edi
	cmpl	%edx, %edi
	jnb	.L1040
	addl	$1, %esi
	movw	%si, 4690(%rcx)
.L1040:
	cmpl	%eax, %edx
	jb	.L1039
	testl	%r8d, %r8d
	movl	$0, %edx
	cmove	%r9d, %edx
.L1039:
	movw	%dx, 4688(%rcx)
	movb	$0, 4693(%rcx)
	leaq	4700(%rcx), %rdx
	cmpq	$-4700, %rcx
	jnb	.L1048
	addw	$1, 4700(%rcx)
.L1027:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1028:
	.cfi_restore_state
	movq	%rcx, %rsi
	leaq	.Lubsan_data339(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1045:
	movq	%rcx, %rsi
	leaq	.Lubsan_data340(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1046:
	movq	%rcx, %rsi
	leaq	.Lubsan_data341(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1047:
	movq	%rcx, %rsi
	leaq	.Lubsan_data342(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1034:
	movzbl	%al, %esi
	movl	$3072, %eax
	movl	$0, %edx
	divl	%esi
	jmp	.L1035
.L1036:
	cmpl	$2, %edi
	jne	.L1037
	leal	-1(%r9), %edx
	testl	%r9d, %r9d
	jne	.L1039
	subl	$1, %eax
	testl	%r8d, %r8d
	movl	%r8d, %edx
	cmovne	%eax, %edx
	jmp	.L1039
.L1048:
	movq	%rcx, %rsi
	leaq	.Lubsan_data343(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE38:
	.size	cr_loop_step, .-cr_loop_step
	.globl	cr_loop_pos
	.type	cr_loop_pos, @function
cr_loop_pos:
.LFB39:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L1050
	testb	$7, %dil
	jne	.L1050
	leaq	4245(%rdi), %rdx
	cmpq	$-4245, %rdi
	jnb	.L1061
	cmpb	$3, 4245(%rdi)
	je	.L1062
	movl	$0, %edx
	cmpb	$2, 4244(%rdi)
	je	.L1063
.L1049:
	movl	%edx, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1050:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data344(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1061:
	movq	%rdi, %rsi
	leaq	.Lubsan_data345(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1062:
	leaq	4252(%rdi), %rdx
	cmpq	$-4252, %rdi
	jnb	.L1064
	movl	4252(%rdi), %edx
	leaq	4276(%rdi), %rax
	cmpq	$-4276, %rdi
	jnb	.L1065
	subl	4276(%rdi), %edx
	jmp	.L1049
.L1064:
	movq	%rdi, %rsi
	leaq	.Lubsan_data346(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1065:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data347(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1063:
	movl	8(%rdi), %edx
	testl	%edx, %edx
	je	.L1049
	leaq	4252(%rdi), %rax
	cmpq	$-4252, %rdi
	jnb	.L1066
	movl	4252(%rdi), %eax
	leaq	4268(%rdi), %rcx
	cmpq	$-4268, %rdi
	jnb	.L1067
	subl	4268(%rdi), %eax
	movl	%edx, %esi
	movl	$0, %edx
	divl	%esi
	jmp	.L1049
.L1066:
	movq	%rax, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data348(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1067:
	movq	%rcx, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data349(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE39:
	.size	cr_loop_pos, .-cr_loop_pos
	.type	crl_grid_changed, @function
crl_grid_changed:
.LFB58:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	movq	%rsi, %r13
	movl	%edx, %ebp
	call	cr_loop_pos
	testq	%rbx, %rbx
	je	.L1069
	movl	%eax, %r12d
	testb	$7, %bl
	jne	.L1069
	leaq	4244(%rbx), %rdx
	cmpq	$-4244, %rbx
	jnb	.L1078
	movzbl	4244(%rbx), %r14d
	movq	%r13, %rsi
	movq	%rbx, %rdi
	call	crl_voices_off
	movl	%ebp, 8(%rbx)
	movb	$0, 4(%rbx)
	movb	$0, 15(%rbx)
	movq	%rbx, %rdi
	call	crl_lev0_scan
	leaq	4713(%rbx), %rdx
	cmpq	$-4713, %rbx
	jnb	.L1079
	movb	$1, 4713(%rbx)
	addw	$1, 4700(%rbx)
	cmpw	$0, 12(%rbx)
	jne	.L1073
	movb	$0, 4244(%rbx)
.L1068:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L1069:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data350(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1078:
	movq	%rbx, %rsi
	leaq	.Lubsan_data351(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1079:
	movq	%rbx, %rsi
	leaq	.Lubsan_data352(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1073:
	testb	%r14b, %r14b
	jne	.L1075
	movb	$1, 4244(%rbx)
	movl	4252(%rbx), %eax
	movl	%eax, 4268(%rbx)
	movl	$0, 4272(%rbx)
	jmp	.L1068
.L1075:
	movb	%r14b, 4244(%rbx)
	testl	%ebp, %ebp
	je	.L1080
	movl	%r12d, %eax
	movl	$0, %edx
	divl	%ebp
	movl	4252(%rbx), %eax
	subl	%edx, %eax
	movl	%eax, 4268(%rbx)
	addl	$1, %edx
	movl	%edx, 4272(%rbx)
	jmp	.L1068
.L1080:
	movl	%r12d, %esi
	movl	$0, %edx
	leaq	.Lubsan_data33(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
	.cfi_endproc
.LFE58:
	.size	crl_grid_changed, .-crl_grid_changed
	.globl	cr_loop_metro
	.type	cr_loop_metro, @function
cr_loop_metro:
.LFB40:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testl	%esi, %esi
	setne	%al
	testq	%rdi, %rdi
	je	.L1082
	testb	$7, %dil
	jne	.L1082
	leaq	5(%rdi), %rdx
	cmpq	$-5, %rdi
	jnb	.L1089
	movb	%al, 5(%rdi)
	leaq	4252(%rdi), %rdx
	cmpq	$-4252, %rdi
	jnb	.L1090
	movl	4252(%rdi), %edx
	leaq	4292(%rdi), %rcx
	cmpq	$-4292, %rdi
	jnb	.L1091
	movl	%edx, 4292(%rdi)
	addl	%eax, %eax
	leaq	4716(%rdi), %rdx
	cmpq	$-4716, %rdi
	jnb	.L1092
	movb	%al, 4716(%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1082:
	.cfi_restore_state
	movq	%rdi, %rsi
	leaq	.Lubsan_data353(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1089:
	movq	%rdi, %rsi
	leaq	.Lubsan_data354(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1090:
	movq	%rdi, %rsi
	leaq	.Lubsan_data355(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1091:
	movq	%rcx, %rdx
	movq	%rdi, %rsi
	leaq	.Lubsan_data356(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1092:
	movq	%rdi, %rsi
	leaq	.Lubsan_data357(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE40:
	.size	cr_loop_metro, .-cr_loop_metro
	.globl	cr_loop_ring
	.type	cr_loop_ring, @function
cr_loop_ring:
.LFB41:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	cr_loop_bar
	testq	%rbx, %rbx
	je	.L1094
	movl	%eax, %esi
	testb	$7, %bl
	jne	.L1094
	leaq	4245(%rbx), %rdx
	cmpq	$-4245, %rbx
	jnb	.L1115
	movzbl	4245(%rbx), %eax
	cmpb	$2, %al
	je	.L1116
	cmpb	$3, %al
	je	.L1117
	movl	$0, %ecx
	cmpb	$2, 4244(%rbx)
	jne	.L1108
	movl	8(%rbx), %ecx
	testl	%ecx, %ecx
	je	.L1108
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1118
	movl	4252(%rbx), %eax
	leaq	4268(%rbx), %rdx
	cmpq	$-4268, %rbx
	jnb	.L1119
	subl	4268(%rbx), %eax
	movl	$0, %edx
	divl	%ecx
	movl	%edx, %eax
	sall	$8, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %ecx
	jmp	.L1103
.L1094:
	movq	%rbx, %rsi
	leaq	.Lubsan_data358(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1115:
	movq	%rbx, %rsi
	leaq	.Lubsan_data359(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1116:
	testl	%esi, %esi
	je	.L1120
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1121
	movl	4252(%rbx), %eax
	leaq	4284(%rbx), %rdx
	cmpq	$-4284, %rbx
	jnb	.L1122
	subl	4284(%rbx), %eax
	sall	$8, %eax
	movl	$0, %edx
	divl	%esi
	movl	%eax, %ecx
.L1103:
	movl	$256, %eax
	cmpl	$256, %ecx
	ja	.L1093
.L1108:
	movl	%ecx, %eax
.L1093:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1120:
	.cfi_restore_state
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1123
	movl	4252(%rbx), %eax
	leaq	4284(%rbx), %rdx
	cmpq	$-4284, %rbx
	jnb	.L1124
	subl	4284(%rbx), %eax
	movl	%eax, %esi
	sall	$8, %esi
	movl	%esi, %esi
	movl	$0, %edx
	leaq	.Lubsan_data17(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L1123:
	movq	%rbx, %rsi
	leaq	.Lubsan_data360(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1124:
	movq	%rbx, %rsi
	leaq	.Lubsan_data361(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1121:
	movq	%rbx, %rsi
	leaq	.Lubsan_data362(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1122:
	movq	%rbx, %rsi
	leaq	.Lubsan_data363(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1117:
	leaq	4280(%rbx), %rdx
	cmpq	$-4280, %rbx
	jnb	.L1125
	movl	4280(%rbx), %ecx
	testl	%ecx, %ecx
	je	.L1106
	movl	4252(%rbx), %eax
	subl	4276(%rbx), %eax
	sall	$8, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %ecx
	jmp	.L1103
.L1125:
	movq	%rbx, %rsi
	leaq	.Lubsan_data364(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1106:
	testl	%esi, %esi
	je	.L1126
	movl	4252(%rbx), %eax
	subl	4276(%rbx), %eax
	movl	$0, %edx
	divl	%esi
	movl	%edx, %eax
	sall	$8, %eax
	movl	$0, %edx
	divl	%esi
	movl	%eax, %ecx
	jmp	.L1103
.L1126:
	movl	4252(%rbx), %esi
	subl	4276(%rbx), %esi
	movl	$0, %edx
	leaq	.Lubsan_data19(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L1118:
	movq	%rbx, %rsi
	leaq	.Lubsan_data365(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1119:
	movq	%rbx, %rsi
	leaq	.Lubsan_data366(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE41:
	.size	cr_loop_ring, .-cr_loop_ring
	.globl	cr_loop_where
	.type	cr_loop_where, @function
cr_loop_where:
.LFB42:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movq	%rsi, %r13
	movq	%rdx, %rbp
	call	cr_loop_bar
	movl	%eax, %r12d
	movq	%rbx, %rdi
	call	cr_loop_beat
	testq	%rbx, %rbx
	je	.L1128
	movl	%eax, %ecx
	testb	$7, %bl
	jne	.L1128
	leaq	4245(%rbx), %rdx
	cmpq	$-4245, %rbx
	jnb	.L1154
	movzbl	4245(%rbx), %eax
	cmpb	$2, %al
	je	.L1155
	cmpb	$3, %al
	je	.L1156
	movl	$0, %esi
	cmpb	$2, 4244(%rbx)
	je	.L1157
.L1143:
	testl	%r12d, %r12d
	je	.L1158
	movl	%esi, %eax
	movl	$0, %edx
	divl	%r12d
	addl	$1, %eax
	testq	%r13, %r13
	je	.L1147
	testb	$3, %r13b
	jne	.L1147
	movl	%eax, 0(%r13)
	movl	%esi, %eax
	movl	$0, %edx
	divl	%r12d
	movl	%edx, %eax
	testl	%ecx, %ecx
	je	.L1159
	movl	$0, %edx
	divl	%ecx
	addl	$1, %eax
	testq	%rbp, %rbp
	je	.L1150
	testb	$3, %bpl
	jne	.L1150
.L1139:
	movl	%eax, 0(%rbp)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1128:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.Lubsan_data367(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1154:
	movq	%rbx, %rsi
	leaq	.Lubsan_data368(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1155:
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1160
	movl	4252(%rbx), %edx
	leaq	4284(%rbx), %rax
	cmpq	$-4284, %rbx
	jnb	.L1161
	movl	4284(%rbx), %eax
	movl	%edx, %esi
	subl	%eax, %esi
	testq	%r13, %r13
	je	.L1134
	testb	$3, %r13b
	jne	.L1134
	movl	$0, 0(%r13)
	cmpl	%r12d, %esi
	jnb	.L1151
	subl	$1, %eax
	subl	%edx, %eax
	addl	%r12d, %eax
	addl	%ecx, %eax
	testl	%ecx, %ecx
	je	.L1162
	movl	$0, %edx
	divl	%ecx
.L1136:
	testq	%rbp, %rbp
	je	.L1138
	testb	$3, %bpl
	je	.L1139
.L1138:
	movq	%rbp, %rsi
	leaq	.Lubsan_data372(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1160:
	movq	%rbx, %rsi
	leaq	.Lubsan_data369(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1161:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data370(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1134:
	movq	%r13, %rsi
	leaq	.Lubsan_data371(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1162:
	movl	%eax, %esi
	movl	$0, %edx
	leaq	.Lubsan_data23(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L1151:
	movl	$0, %eax
	jmp	.L1136
.L1156:
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1163
	movl	4252(%rbx), %esi
	leaq	4276(%rbx), %rdx
	cmpq	$-4276, %rbx
	jnb	.L1164
	subl	4276(%rbx), %esi
	jmp	.L1143
.L1163:
	movq	%rbx, %rsi
	leaq	.Lubsan_data373(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1164:
	movq	%rbx, %rsi
	leaq	.Lubsan_data374(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1157:
	movl	8(%rbx), %esi
	testl	%esi, %esi
	je	.L1143
	leaq	4252(%rbx), %rdx
	cmpq	$-4252, %rbx
	jnb	.L1165
	movl	4252(%rbx), %eax
	leaq	4268(%rbx), %rdx
	cmpq	$-4268, %rbx
	jnb	.L1166
	subl	4268(%rbx), %eax
	movl	$0, %edx
	divl	%esi
	movl	%edx, %esi
	jmp	.L1143
.L1165:
	movq	%rbx, %rsi
	leaq	.Lubsan_data375(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1166:
	movq	%rbx, %rsi
	leaq	.Lubsan_data376(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1158:
	movl	%esi, %esi
	movl	$0, %edx
	leaq	.Lubsan_data25(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L1147:
	movq	%r13, %rsi
	leaq	.Lubsan_data377(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1159:
	movl	%edx, %esi
	movl	$0, %edx
	leaq	.Lubsan_data27(%rip), %rdi
	call	__ubsan_handle_divrem_overflow_abort@PLT
.L1150:
	movq	%rbp, %rsi
	leaq	.Lubsan_data378(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
	.cfi_endproc
.LFE42:
	.size	cr_loop_where, .-cr_loop_where
	.globl	cr_loop_grid_rate
	.type	cr_loop_grid_rate, @function
cr_loop_grid_rate:
.LFB51:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	je	.L1168
	testb	$7, %dil
	jne	.L1168
	leaq	16(%rdi), %rdx
	cmpq	$-16, %rdi
	jnb	.L1178
	movzbl	16(%rdi), %eax
	testb	%al, %al
	je	.L1176
	movzbl	%al, %eax
	cmpl	%eax, %esi
	jnb	.L1172
	cmpl	$127, %esi
	ja	.L1179
	movl	%esi, %eax
	leaq	18(%rdi,%rax), %rdx
	cmpq	%rdi, %rdx
	jb	.L1180
	movl	%esi, %esi
	movzbl	18(%rdi,%rsi), %eax
	jmp	.L1167
.L1168:
	movq	%rdi, %rsi
	leaq	.Lubsan_data379(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1178:
	movq	%rdi, %rsi
	leaq	.Lubsan_data380(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1179:
	movl	%esi, %esi
	leaq	.Lubsan_data381(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1180:
	movq	%rdi, %rsi
	leaq	.Lubsan_data382(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1176:
	movl	$2, %eax
.L1167:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1172:
	.cfi_restore_state
	leaq	18(%rdi), %rdx
	cmpq	$-18, %rdi
	jnb	.L1181
	movzbl	18(%rdi), %eax
	jmp	.L1167
.L1181:
	movq	%rdi, %rsi
	leaq	.Lubsan_data383(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE51:
	.size	cr_loop_grid_rate, .-cr_loop_grid_rate
	.globl	cr_loop_grid_tick
	.type	cr_loop_grid_tick, @function
cr_loop_grid_tick:
.LFB52:
	.cfi_startproc
	endbr64
	movl	$128, %r8d
	cmpl	%r8d, %esi
	cmovbe	%esi, %r8d
	testl	%esi, %esi
	je	.L1192
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rax
	movl	$0, %edi
	movl	$0, %esi
	movq	%rax, %r11
	andl	$3, %r11d
	leaq	8(%rax), %rbp
	movl	$2, %r10d
	movl	$0, %ebx
	movl	$24, %r9d
	jmp	.L1191
.L1184:
	movq	%rax, %rsi
	leaq	.Lubsan_data384(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1202:
	movq	%rbp, %rdx
	movq	%rax, %rsi
	leaq	.Lubsan_data385(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1203:
	movl	%ecx, %esi
	leaq	.Lubsan_data386(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1204:
	movq	%rax, %rsi
	leaq	.Lubsan_data387(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1193:
	movl	%r10d, %ecx
.L1187:
	movl	%r9d, %edx
	sall	%cl, %edx
	addl	%edx, %edi
	addl	$1, %esi
	cmpl	%r8d, %esi
	jnb	.L1201
.L1191:
	testq	%rax, %rax
	je	.L1184
	testq	%r11, %r11
	jne	.L1184
	cmpq	$-8, %rax
	jnb	.L1202
	movzbl	8(%rax), %edx
	testb	%dl, %dl
	je	.L1193
	movzbl	%dl, %edx
	cmpl	%edx, %esi
	movl	%ebx, %ecx
	cmovb	%esi, %ecx
	cmpl	$127, %ecx
	ja	.L1203
	leal	10(%rcx), %edx
	addq	%rax, %rdx
	jc	.L1204
	movl	%ecx, %ecx
	movzbl	10(%rax,%rcx), %ecx
	cmpl	$5, %ecx
	cmovnb	%r10d, %ecx
	jmp	.L1187
.L1192:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	movl	%esi, %eax
	ret
.L1201:
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movl	%edi, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE52:
	.size	cr_loop_grid_tick, .-cr_loop_grid_tick
	.globl	cr_loop_pack
	.type	cr_loop_pack, @function
cr_loop_pack:
.LFB47:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbx
	movl	%edx, 4(%rsp)
	testq	%rdi, %rdi
	je	.L1206
	movq	%rsi, %rbp
	testb	$3, %dil
	jne	.L1206
	leaq	4(%rdi), %rdx
	cmpq	$-4, %rdi
	jnb	.L1308
	movzwl	4(%rdi), %eax
	movzwl	%ax, %esi
	testw	%ax, %ax
	je	.L1209
	movl	$145, %edx
	movl	$0, %r13d
	movl	$0, %ecx
	jmp	.L1213
.L1206:
	movq	%rbx, %rsi
	leaq	.Lubsan_data388(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1308:
	movq	%rdi, %rsi
	leaq	.Lubsan_data389(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1210:
	cmpq	%rax, %rbx
	jb	.L1212
.L1211:
	movsbl	(%rbx,%rdx), %eax
	notl	%eax
	shrl	$31, %eax
	addl	%eax, %r13d
	addl	$1, %ecx
	addq	$8, %rdx
	cmpl	$511, %ecx
	ja	.L1300
	cmpl	%esi, %ecx
	jnb	.L1300
.L1213:
	leaq	(%rbx,%rdx), %rax
	testq	%rdx, %rdx
	js	.L1210
	cmpq	%rbx, %rax
	jnb	.L1211
.L1212:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data390(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1300:
	leaq	6(%rbx), %rdx
	cmpq	$-6, %rbx
	jnb	.L1309
	movzbl	6(%rbx), %r15d
	leaq	8(%rbx), %rdx
	cmpq	$-8, %rbx
	jnb	.L1310
	movzbl	8(%rbx), %r8d
	movzbl	%r8b, %r14d
	testb	%r8b, %r8b
	je	.L1217
.L1284:
	leaq	8(%rbx), %rdx
	cmpq	$-8, %rbx
	jnb	.L1311
	cmpb	$-128, %r8b
	ja	.L1285
	movl	$0, %eax
	leaq	9(%rbx), %r10
	leaq	10(%rbx), %r9
	jmp	.L1227
.L1309:
	movq	%rbx, %rsi
	leaq	.Lubsan_data391(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1310:
	movq	%rbx, %rsi
	leaq	.Lubsan_data392(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1311:
	movq	%rbx, %rsi
	leaq	.Lubsan_data393(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1313:
	movl	%eax, %esi
	leaq	.Lubsan_data394(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1314:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data395(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1315:
	movq	%r10, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data396(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1316:
	movl	%eax, %esi
	leaq	.Lubsan_data397(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1317:
	movq	%rbx, %rsi
	leaq	.Lubsan_data398(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1318:
	movq	%r9, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data399(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1223:
	addq	$1, %rax
	cmpl	%r14d, %eax
	jnb	.L1312
.L1227:
	cmpl	$127, %eax
	ja	.L1313
	leal	10(%rax), %edx
	movq	%rbx, %rcx
	addq	%rdx, %rcx
	jc	.L1314
	movzbl	10(%rbx,%rax), %ecx
	cmpb	$4, %cl
	ja	.L1286
	cmpq	$-9, %rbx
	jnb	.L1315
	movzbl	9(%rbx), %esi
	testb	%sil, %sil
	je	.L1223
	cmpl	$127, %eax
	ja	.L1316
	addq	%rbx, %rdx
	jc	.L1317
	cmpq	$-10, %rbx
	jnb	.L1318
	cmpb	10(%rbx), %cl
	je	.L1223
	movl	$0, %r12d
	jmp	.L1205
.L1312:
	testb	%sil, %sil
	jne	.L1319
	movl	$0, %r12d
	testb	$7, %r8b
	jne	.L1205
	movl	%r14d, %esi
	movq	%rbx, %rdi
	call	cr_loop_grid_tick
	cmpl	(%rbx), %eax
	jne	.L1291
.L1217:
	movl	(%rbx), %eax
	subl	$1, %eax
	cmpl	$3071, %eax
	ja	.L1292
	testl	%r13d, %r13d
	je	.L1292
	leaq	6(%rbx), %rdx
	cmpq	$-6, %rbx
	jnb	.L1320
	movzbl	6(%rbx), %eax
	testb	%al, %al
	je	.L1293
	cmpb	$32, %al
	ja	.L1294
	movzbl	%r15b, %r15d
	leal	16(%r14,%r15,2), %r12d
	leal	0(,%r13,8), %eax
	subl	%r13d, %eax
	addl	%eax, %r12d
	cmpw	$512, 4(%rbx)
	ja	.L1295
	cmpl	%r12d, 4(%rsp)
	jnb	.L1321
.L1295:
	movl	$0, %r12d
	jmp	.L1205
.L1319:
	movl	%r14d, %esi
	movq	%rbx, %rdi
	call	cr_loop_grid_tick
	movl	$0, %r12d
	cmpl	(%rbx), %eax
	jb	.L1205
	movzbl	8(%rbx), %esi
	subl	$1, %esi
	movq	%rbx, %rdi
	call	cr_loop_grid_tick
	cmpl	(%rbx), %eax
	jb	.L1217
	movl	$0, %r12d
	jmp	.L1205
.L1320:
	movq	%rbx, %rsi
	leaq	.Lubsan_data400(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1321:
	movl	$827085379, %esi
	movq	%rbp, %rdi
	call	crl_put16
	leaq	2(%rbp), %rdx
	cmpq	$-2, %rbp
	jnb	.L1322
	leaq	2(%rbp), %rdi
	movl	$12620, %esi
	call	crl_put16
	leaq	8(%rbx), %rdx
	cmpq	$-8, %rbx
	jnb	.L1323
	cmpb	$0, 8(%rbx)
	je	.L1296
	leaq	9(%rbx), %rdx
	cmpq	$-9, %rbx
	jnb	.L1324
	cmpb	$1, 9(%rbx)
	movl	$2, %eax
	sbbb	$-1, %al
	jmp	.L1232
.L1322:
	movq	%rbp, %rsi
	leaq	.Lubsan_data401(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1323:
	movq	%rbx, %rsi
	leaq	.Lubsan_data402(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1324:
	movq	%rbx, %rsi
	leaq	.Lubsan_data403(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1296:
	movl	$1, %eax
.L1232:
	leaq	4(%rbp), %rdx
	cmpq	$-4, %rbp
	jnb	.L1325
	je	.L1326
	movb	%al, 4(%rbp)
	leaq	5(%rbp), %rdx
	cmpq	$-5, %rbp
	jnb	.L1327
	movzbl	7(%rbx), %eax
	je	.L1328
	movb	%al, 5(%rbp)
	leaq	6(%rbp), %rdx
	cmpq	$-6, %rbp
	jnb	.L1329
	movzbl	6(%rbx), %eax
	je	.L1330
	movb	%al, 6(%rbp)
	leaq	7(%rbp), %rdx
	cmpq	$-7, %rbp
	jnb	.L1331
	movzbl	8(%rbx), %eax
	je	.L1332
	movb	%al, 7(%rbp)
	movl	(%rbx), %r14d
	leaq	8(%rbp), %rdx
	cmpq	$-8, %rbp
	jnb	.L1333
	leaq	8(%rbp), %r15
	movl	%r14d, %esi
	movq	%r15, %rdi
	call	crl_put16
	movl	%r14d, %esi
	shrl	$16, %esi
	leaq	10(%rbp), %rdx
	cmpq	$-2, %r15
	jnb	.L1334
	leaq	10(%rbp), %rdi
	call	crl_put16
	leaq	12(%rbp), %rdx
	cmpq	$-12, %rbp
	jnb	.L1335
	leaq	12(%rbp), %rdi
	movl	%r13d, %esi
	call	crl_put16
	leaq	14(%rbp), %rdx
	cmpq	$-14, %rbp
	jnb	.L1336
	leaq	14(%rbp), %rdi
	movl	$96, %esi
	call	crl_put16
	cmpb	$0, 6(%rbx)
	je	.L1246
	movl	$0, %r13d
.L1248:
	leal	16(%r13,%r13), %edi
	movl	%edi, %edi
	movq	%rbp, %rdx
	addq	%rdi, %rdx
	jc	.L1337
	addq	%rbp, %rdi
	movl	$0, %esi
	call	crl_put16
	addl	$1, %r13d
	movzbl	6(%rbx), %eax
	cmpl	%eax, %r13d
	jb	.L1248
.L1246:
	cmpw	$0, 4(%rbx)
	je	.L1249
	movl	$0, %r13d
	jmp	.L1257
.L1325:
	movq	%rbp, %rsi
	leaq	.Lubsan_data404(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1326:
	movl	$0, %esi
	leaq	.Lubsan_data405(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1327:
	movq	%rbp, %rsi
	leaq	.Lubsan_data406(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1328:
	movl	$0, %esi
	leaq	.Lubsan_data407(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1329:
	movq	%rbp, %rsi
	leaq	.Lubsan_data408(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1330:
	movl	$0, %esi
	leaq	.Lubsan_data409(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1331:
	movq	%rbp, %rsi
	leaq	.Lubsan_data410(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1332:
	movl	$0, %esi
	leaq	.Lubsan_data411(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1333:
	movq	%rbp, %rsi
	leaq	.Lubsan_data412(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1334:
	movq	%r15, %rsi
	leaq	.Lubsan_data413(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1335:
	movq	%rbp, %rsi
	leaq	.Lubsan_data414(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1336:
	movq	%rbp, %rsi
	leaq	.Lubsan_data415(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1337:
	movq	%rbp, %rsi
	leaq	.Lubsan_data416(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1339:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data417(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1340:
	movq	%rax, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data418(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1254:
	movzbl	%cl, %eax
.L1255:
	leal	(%rax,%rax), %eax
	addq	$16, %rax
	movq	%rbp, %rdx
	addq	%rax, %rdx
	jc	.L1338
	leaq	0(%rbp,%rax), %r14
	movq	%r14, %rdi
	call	crl_get16
	leal	1(%rax), %esi
	movq	%r14, %rdi
	call	crl_put16
.L1251:
	addq	$1, %r13
	movzwl	4(%rbx), %eax
	cmpl	%eax, %r13d
	jnb	.L1249
.L1257:
	leaq	145(,%r13,8), %rdx
	movq	%rbx, %rax
	addq	%rdx, %rax
	jc	.L1339
	movl	%r13d, %eax
	movzbl	145(%rbx,%rax,8), %ecx
	testb	%cl, %cl
	js	.L1251
	movq	%rbx, %rax
	addq	%rdx, %rax
	jc	.L1340
	movzbl	6(%rbx), %eax
	cmpb	%al, %cl
	jnb	.L1253
	addq	%rbx, %rdx
	jnc	.L1254
	movq	%rbx, %rsi
	leaq	.Lubsan_data419(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1253:
	movzbl	%al, %eax
	subl	$1, %eax
	jmp	.L1255
.L1338:
	movq	%rbp, %rsi
	leaq	.Lubsan_data420(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1249:
	movzbl	6(%rbx), %eax
	leal	16(%rax,%rax), %r15d
	cmpw	$0, 4(%rbx)
	je	.L1258
	movl	$138, %r13d
	movl	$0, 4(%rsp)
	jmp	.L1274
.L1259:
	cmpq	%rdx, %rbx
	jb	.L1261
.L1260:
	movq	%rbx, %rsi
	addq	%r13, %rsi
	je	.L1262
	testb	$1, %sil
	jne	.L1262
	leaq	7(%rsi), %rdx
	cmpq	$-7, %rsi
	jnb	.L1341
	movl	4(%rsp), %eax
	leaq	(%rbx,%rax,8), %r14
	cmpb	$0, 145(%r14)
	js	.L1265
	movzwl	138(%r14), %esi
	movl	%r15d, %eax
	movq	%rax, 8(%rsp)
	movq	%rax, %rdx
	addq	%rbp, %rdx
	jc	.L1342
	movq	8(%rsp), %rax
	leaq	0(%rbp,%rax), %rdi
	call	crl_put16
	movzwl	140(%r14), %esi
	movq	8(%rsp), %rax
	addq	$2, %rax
	movq	%rbp, %rdx
	addq	%rax, %rdx
	jc	.L1343
	leaq	0(%rbp,%rax), %rdi
	call	crl_put16
	leal	4(%r15), %eax
	movq	%rbp, %rdx
	addq	%rax, %rdx
	jc	.L1344
	movzbl	142(%r14), %edx
	addq	%rbp, %rax
	je	.L1345
	movb	%dl, (%rax)
	leal	5(%r15), %eax
	movq	%rbp, %rdx
	addq	%rax, %rdx
	jc	.L1346
	movzbl	143(%r14), %edx
	addq	%rbp, %rax
	je	.L1347
	movb	%dl, (%rax)
	leal	6(%r15), %eax
	movq	%rbp, %rdx
	addq	%rax, %rdx
	jc	.L1348
	movzbl	144(%r14), %edx
	addq	%rbp, %rax
	je	.L1349
	movb	%dl, (%rax)
	addl	$7, %r15d
.L1265:
	addl	$1, 4(%rsp)
	movl	4(%rsp), %edi
	addq	$8, %r13
	movzwl	4(%rbx), %eax
	cmpl	%eax, %edi
	jnb	.L1258
.L1274:
	leaq	(%rbx,%r13), %rdx
	testq	%r13, %r13
	js	.L1259
	cmpq	%rbx, %rdx
	jnb	.L1260
.L1261:
	movq	%rbx, %rsi
	leaq	.Lubsan_data421(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1262:
	leaq	.Lubsan_data422(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1341:
	leaq	.Lubsan_data423(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1342:
	movq	%rbp, %rsi
	leaq	.Lubsan_data424(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1343:
	movq	%rbp, %rsi
	leaq	.Lubsan_data425(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1344:
	movq	%rbp, %rsi
	leaq	.Lubsan_data426(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1345:
	movl	$0, %esi
	leaq	.Lubsan_data427(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1346:
	movq	%rbp, %rsi
	leaq	.Lubsan_data428(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1347:
	movl	$0, %esi
	leaq	.Lubsan_data429(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1348:
	movq	%rbp, %rsi
	leaq	.Lubsan_data430(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1349:
	movl	$0, %esi
	leaq	.Lubsan_data431(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1258:
	cmpb	$0, 8(%rbx)
	je	.L1205
	movl	$0, %ecx
.L1281:
	leal	(%rcx,%r15), %eax
	cmpl	$127, %ecx
	ja	.L1350
	leal	10(%rcx), %edx
	movq	%rbx, %rsi
	addq	%rdx, %rsi
	jc	.L1351
	movl	%ecx, %esi
	movzbl	10(%rbx,%rsi), %esi
	cmpb	$4, %sil
	ja	.L1298
	cmpl	$127, %ecx
	ja	.L1352
	movl	%eax, %eax
	movq	%rbp, %rdi
	addq	%rax, %rdi
	jc	.L1353
	addq	%rbp, %rax
	addq	%rbx, %rdx
	jc	.L1354
	testq	%rax, %rax
	je	.L1355
	movb	%sil, (%rax)
	addl	$1, %ecx
	movzbl	8(%rbx), %eax
	cmpl	%eax, %ecx
	jb	.L1281
	jmp	.L1205
.L1350:
	movl	%ecx, %esi
	leaq	.Lubsan_data432(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1351:
	movq	%rsi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data433(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1352:
	movl	%ecx, %esi
	leaq	.Lubsan_data434(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1353:
	movq	%rdi, %rdx
	movq	%rbp, %rsi
	leaq	.Lubsan_data435(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1354:
	movq	%rbx, %rsi
	leaq	.Lubsan_data436(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1355:
	movl	$0, %esi
	leaq	.Lubsan_data437(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1285:
	movl	$0, %r12d
	jmp	.L1205
.L1286:
	movl	$0, %r12d
	jmp	.L1205
.L1291:
	movl	$0, %r12d
	jmp	.L1205
.L1292:
	movl	$0, %r12d
.L1205:
	movl	%r12d, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1293:
	.cfi_restore_state
	movl	$0, %r12d
	jmp	.L1205
.L1294:
	movl	$0, %r12d
	jmp	.L1205
.L1298:
	movl	$0, %r12d
	jmp	.L1205
.L1209:
	leaq	6(%rdi), %rdx
	cmpq	$-6, %rdi
	jnb	.L1356
	movzbl	6(%rdi), %r15d
	leaq	8(%rdi), %rdx
	cmpq	$-8, %rdi
	jnb	.L1357
	movzbl	8(%rdi), %r8d
	movl	$0, %r12d
	testb	%r8b, %r8b
	je	.L1205
	movzbl	%r8b, %r14d
	movl	$0, %r13d
	jmp	.L1284
.L1356:
	movq	%rdi, %rsi
	leaq	.Lubsan_data438(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1357:
	movq	%rdi, %rsi
	leaq	.Lubsan_data439(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
	.cfi_endproc
.LFE47:
	.size	cr_loop_pack, .-cr_loop_pack
	.globl	cr_loop_unpack
	.type	cr_loop_unpack, @function
cr_loop_unpack:
.LFB48:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdi, %rbx
	movl	%esi, %r12d
	movq	%rdx, %rbp
	movl	$138, %esi
	movq	%rdx, %rdi
	call	crl_zero
	testq	%rbx, %rbx
	je	.L1427
	cmpl	$15, %r12d
	jbe	.L1427
	movq	%rbx, %rdi
	call	crl_get16
	movl	%eax, %r13d
	leaq	2(%rbx), %rdx
	cmpq	$-2, %rbx
	jnb	.L1446
	leaq	2(%rbx), %rdi
	call	crl_get16
	sall	$16, %eax
	orl	%r13d, %eax
	cmpl	$827085379, %eax
	jne	.L1428
	leaq	4(%rbx), %rdx
	cmpq	$-4, %rbx
	jnb	.L1447
	je	.L1448
	movzbl	4(%rbx), %eax
	subl	$1, %eax
	cmpb	$2, %al
	ja	.L1429
	leaq	5(%rbx), %rdx
	cmpq	$-5, %rbx
	jnb	.L1449
	je	.L1450
	movl	$0, %eax
	cmpb	$2, 5(%rbx)
	ja	.L1358
	leaq	14(%rbx), %rdx
	cmpq	$-14, %rbx
	jnb	.L1451
	leaq	14(%rbx), %rdi
	call	crl_get16
	cmpl	$96, %eax
	jne	.L1431
	movzbl	4(%rbx), %eax
	cmpb	$1, %al
	jbe	.L1366
	cmpq	$-7, %rbx
	je	.L1452
	movzbl	7(%rbx), %edx
	movl	%edx, %ecx
	subb	$1, %cl
	js	.L1432
	cmpb	$2, %al
	je	.L1453
.L1368:
	testq	%rbp, %rbp
	je	.L1369
	testb	$3, %bpl
	jne	.L1369
	leaq	8(%rbp), %rax
	cmpq	$-8, %rbp
	jnb	.L1454
	movb	%dl, 8(%rbp)
	cmpb	$3, 4(%rbx)
	sete	%al
	leaq	9(%rbp), %rdx
	cmpq	$-9, %rbp
	jnb	.L1455
	movb	%al, 9(%rbp)
.L1366:
	cmpq	$-6, %rbx
	je	.L1456
	movzbl	6(%rbx), %eax
	movb	%al, 27(%rsp)
	movzbl	%al, %eax
	movl	%eax, 16(%rsp)
	leaq	8(%rbx), %r13
	movq	%r13, %rdi
	call	crl_get16
	movl	%eax, %r14d
	leaq	10(%rbx), %rdx
	cmpq	$-2, %r13
	jnb	.L1457
	leaq	10(%rbx), %rdi
	call	crl_get16
	movl	%eax, %r13d
	leaq	12(%rbx), %rdi
	call	crl_get16
	movl	16(%rsp), %esi
	leal	-1(%rsi), %edx
	cmpl	$31, %edx
	ja	.L1434
	leal	-1(%rax), %ecx
	cmpl	$511, %ecx
	ja	.L1435
	sall	$16, %r13d
	orl	%r14d, %r13d
	movl	%r13d, 20(%rsp)
	leal	-1(%r13), %ecx
	cmpl	$3071, %ecx
	ja	.L1436
	leal	16(%rsi,%rsi), %r15d
	leal	0(,%rax,8), %esi
	subl	%eax, %esi
	testq	%rbp, %rbp
	je	.L1375
	testb	$3, %bpl
	jne	.L1375
	leaq	8(%rbp), %rcx
	cmpq	$-8, %rbp
	jnb	.L1458
	movzbl	8(%rbp), %ecx
	addl	%r15d, %ecx
	addl	%esi, %ecx
	cmpl	%ecx, %r12d
	jb	.L1437
	movl	%edx, %edx
	leaq	18(%rdx,%rdx), %r13
	movl	$16, %r12d
	movl	$0, %r14d
	movl	%eax, 12(%rsp)
	jmp	.L1381
.L1446:
	movq	%rbx, %rsi
	leaq	.Lubsan_data440(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1447:
	movq	%rbx, %rsi
	leaq	.Lubsan_data441(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1448:
	movl	$0, %esi
	leaq	.Lubsan_data442(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1449:
	movq	%rbx, %rsi
	leaq	.Lubsan_data443(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1450:
	movl	$0, %esi
	leaq	.Lubsan_data444(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1451:
	movq	%rbx, %rsi
	leaq	.Lubsan_data445(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1452:
	movl	$0, %esi
	leaq	.Lubsan_data446(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1453:
	testb	$7, %dl
	je	.L1368
	movl	$0, %eax
	jmp	.L1358
.L1369:
	movq	%rbp, %rsi
	leaq	.Lubsan_data447(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1454:
	movq	%rax, %rdx
	movq	%rbp, %rsi
	leaq	.Lubsan_data448(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1455:
	movq	%rbp, %rsi
	leaq	.Lubsan_data449(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1456:
	movl	$0, %esi
	leaq	.Lubsan_data450(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1457:
	movq	%r13, %rsi
	leaq	.Lubsan_data451(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1375:
	movq	%rbp, %rsi
	leaq	.Lubsan_data452(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1458:
	movq	%rcx, %rdx
	movq	%rbp, %rsi
	leaq	.Lubsan_data453(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1378:
	cmpq	%rdx, %rbx
	jb	.L1380
.L1379:
	leaq	(%r12,%rbx), %rdi
	call	crl_get16
	addl	%eax, %r14d
	addq	$2, %r12
	cmpq	%r12, %r13
	je	.L1459
.L1381:
	leaq	(%rbx,%r12), %rdx
	testq	%r12, %r12
	js	.L1378
	cmpq	%rbx, %rdx
	jnb	.L1379
.L1380:
	movq	%rbx, %rsi
	leaq	.Lubsan_data454(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1459:
	movl	12(%rsp), %eax
	cmpl	%r14d, %eax
	jne	.L1438
	movl	$16, %r13d
	movl	$0, 12(%rsp)
	movl	$0, 28(%rsp)
	movl	%r14d, 44(%rsp)
	movq	%r13, %r14
.L1405:
	leaq	(%rbx,%r14), %rdx
	testq	%r14, %r14
	js	.L1382
	cmpq	%rbx, %rdx
	jnb	.L1383
.L1384:
	movq	%rbx, %rsi
	leaq	.Lubsan_data455(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1382:
	cmpq	%rdx, %rbx
	jb	.L1384
.L1383:
	leaq	(%rbx,%r14), %rdi
	call	crl_get16
	testl	%eax, %eax
	je	.L1385
	movl	12(%rsp), %ecx
	addl	%ecx, %eax
	movl	%eax, 40(%rsp)
	movq	%r14, 32(%rsp)
.L1404:
	movl	12(%rsp), %r13d
	salq	$3, %r13
	leaq	138(%r13), %r12
	movq	%rbp, %rdx
	addq	%r12, %rdx
	jc	.L1460
	addq	%rbp, %r12
	movl	%r15d, %r14d
	movq	%rbx, %rdx
	addq	%r14, %rdx
	jc	.L1461
	leaq	(%rbx,%r14), %rdi
	call	crl_get16
	testq	%r12, %r12
	je	.L1388
	testb	$1, %r12b
	jne	.L1388
	addq	%rbp, %r13
	movw	%ax, 138(%r13)
	addq	$2, %r14
	movq	%rbx, %rdx
	addq	%r14, %rdx
	jc	.L1462
	leaq	(%rbx,%r14), %rdi
	call	crl_get16
	movl	%eax, %edx
	leaq	2(%r12), %rax
	cmpq	$-2, %r12
	jnb	.L1463
	movw	%dx, 140(%r13)
	leal	4(%r15), %eax
	movq	%rbx, %rcx
	addq	%rax, %rcx
	jc	.L1464
	addq	%rbx, %rax
	je	.L1465
	movzbl	(%rax), %esi
	leaq	4(%r12), %rax
	cmpq	$-4, %r12
	jnb	.L1466
	movb	%sil, 142(%r13)
	leal	5(%r15), %eax
	movq	%rbx, %rcx
	addq	%rax, %rcx
	jc	.L1467
	addq	%rbx, %rax
	je	.L1468
	movzbl	(%rax), %ecx
	leaq	5(%r12), %rax
	cmpq	$-5, %r12
	jnb	.L1469
	movb	%cl, 143(%r13)
	leal	6(%r15), %eax
	movq	%rbx, %rdi
	addq	%rax, %rdi
	jc	.L1470
	addq	%rbx, %rax
	je	.L1471
	movzbl	(%rax), %eax
	leaq	6(%r12), %rdi
	cmpq	$-6, %r12
	jnb	.L1472
	movb	%al, 144(%r13)
	leaq	7(%r12), %rdi
	cmpq	$-7, %r12
	jnb	.L1473
	movzbl	28(%rsp), %edi
	movb	%dil, 145(%r13)
	movzwl	138(%r13), %edi
	movl	20(%rsp), %r10d
	cmpl	%r10d, %edi
	jnb	.L1402
	testw	%dx, %dx
	je	.L1402
	testb	%sil, %sil
	js	.L1402
	testb	%cl, %cl
	je	.L1402
	js	.L1402
	testb	%al, %al
	js	.L1402
	addl	$1, 12(%rsp)
	movl	12(%rsp), %eax
	addl	$7, %r15d
	movl	40(%rsp), %ecx
	cmpl	%ecx, %eax
	jne	.L1404
	movq	32(%rsp), %r14
	movl	%ecx, 12(%rsp)
.L1385:
	addl	$1, 28(%rsp)
	movl	28(%rsp), %eax
	addq	$2, %r14
	cmpl	%eax, 16(%rsp)
	jne	.L1405
	movl	44(%rsp), %r14d
	movl	$0, %eax
	jmp	.L1406
.L1460:
	movq	%rbp, %rsi
	leaq	.Lubsan_data456(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1461:
	movq	%rbx, %rsi
	leaq	.Lubsan_data457(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1388:
	movq	%r12, %rsi
	leaq	.Lubsan_data458(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1462:
	movq	%rbx, %rsi
	leaq	.Lubsan_data459(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1463:
	movq	%rax, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data460(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1464:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data461(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1465:
	movl	$0, %esi
	leaq	.Lubsan_data462(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1466:
	movq	%rax, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data463(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1467:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data464(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1468:
	movl	$0, %esi
	leaq	.Lubsan_data465(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1469:
	movq	%rax, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data466(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1470:
	movq	%rdi, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data467(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1471:
	movl	$0, %esi
	leaq	.Lubsan_data468(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1472:
	movq	%rdi, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data469(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1473:
	movq	%rdi, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data470(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1402:
	movl	$138, %esi
	movq	%rbp, %rdi
	call	crl_zero
	movl	$0, %eax
	jmp	.L1358
.L1475:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	leaq	.Lubsan_data471(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1476:
	movl	$0, %esi
	leaq	.Lubsan_data472(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1477:
	movl	$138, %esi
	movq	%rbp, %rdi
	call	crl_zero
	movl	$0, %eax
	jmp	.L1358
.L1478:
	movq	%rbx, %rsi
	leaq	.Lubsan_data473(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1479:
	movl	%eax, %esi
	leaq	.Lubsan_data474(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1412:
	movl	%eax, %edx
	movb	%cl, 10(%rbp,%rdx)
	addl	$1, %eax
.L1406:
	movzbl	8(%rbp), %edi
	movzbl	%dil, %esi
	cmpl	%esi, %eax
	jnb	.L1474
	leal	(%rax,%r15), %edx
	movq	%rbx, %rcx
	addq	%rdx, %rcx
	jc	.L1475
	movq	%rbx, %rcx
	addq	%rdx, %rcx
	je	.L1476
	movzbl	(%rcx), %ecx
	cmpb	$4, %cl
	ja	.L1477
	addq	%rbx, %rdx
	jc	.L1478
	cmpl	$127, %eax
	ja	.L1479
	leal	10(%rax), %edx
	addq	%rbp, %rdx
	jnc	.L1412
	movq	%rbp, %rsi
	leaq	.Lubsan_data475(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1474:
	leaq	9(%rbp), %rdx
	cmpq	$-9, %rbp
	jnb	.L1480
	movzbl	9(%rbp), %ecx
	testb	%cl, %cl
	je	.L1415
	movl	20(%rsp), %eax
	cmpl	$384, %eax
	je	.L1439
	cmpl	$768, %eax
	je	.L1439
	cmpl	$1536, %eax
	je	.L1440
	cmpl	$3072, %eax
	jne	.L1481
.L1440:
	movl	$1, %eax
	jmp	.L1416
.L1480:
	movq	%rbp, %rsi
	leaq	.Lubsan_data476(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1481:
	movl	$138, %esi
	movq	%rbp, %rdi
	call	crl_zero
	movl	$0, %eax
	jmp	.L1358
.L1484:
	movl	%edx, %esi
	leaq	.Lubsan_data477(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1418:
	cmpq	%rdx, %rbp
	jb	.L1420
.L1419:
	movzbl	10(%rbp,%rax), %edx
	cmpq	$-10, %rbp
	jnb	.L1482
	addq	$1, %rax
	cmpb	10(%rbp), %dl
	jne	.L1483
.L1422:
	movl	%eax, %edx
	cmpl	%esi, %eax
	jnb	.L1415
	cmpl	$127, %eax
	ja	.L1484
	leaq	10(%rax), %r8
	leaq	0(%rbp,%r8), %rdx
	testq	%r8, %r8
	js	.L1418
	cmpq	%rbp, %rdx
	jnb	.L1419
.L1420:
	movq	%rbp, %rsi
	leaq	.Lubsan_data478(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1482:
	movq	%r9, %rdx
	movq	%rbp, %rsi
	leaq	.Lubsan_data479(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1483:
	movl	$138, %esi
	movq	%rbp, %rdi
	call	crl_zero
	movl	$0, %eax
	jmp	.L1358
.L1439:
	movl	$1, %eax
.L1416:
	leaq	10(%rbp), %r9
	jmp	.L1422
.L1415:
	testb	%dil, %dil
	je	.L1424
	cmpb	$0, 5(%rbx)
	jne	.L1425
	testb	%cl, %cl
	je	.L1426
	movq	%rbp, %rdi
	call	cr_loop_grid_tick
	movl	20(%rsp), %r15d
	cmpl	%r15d, %eax
	jnb	.L1485
.L1425:
	movl	$138, %esi
	movq	%rbp, %rdi
	call	crl_zero
	movl	$0, %eax
	jmp	.L1358
.L1485:
	movzbl	8(%rbp), %esi
	subl	$1, %esi
	movq	%rbp, %rdi
	call	cr_loop_grid_tick
	cmpl	%r15d, %eax
	jb	.L1424
	jmp	.L1425
.L1426:
	movq	%rbp, %rdi
	call	cr_loop_grid_tick
	movl	20(%rsp), %ecx
	cmpl	%ecx, %eax
	jne	.L1425
.L1424:
	movl	20(%rsp), %eax
	movl	%eax, 0(%rbp)
	movw	%r14w, 4(%rbp)
	movzbl	27(%rsp), %eax
	movb	%al, 6(%rbp)
	movzbl	5(%rbx), %eax
	movb	%al, 7(%rbp)
	movl	$1, %eax
	jmp	.L1358
.L1427:
	movl	$0, %eax
.L1358:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1428:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L1358
.L1429:
	movl	$0, %eax
	jmp	.L1358
.L1431:
	movl	$0, %eax
	jmp	.L1358
.L1432:
	movl	$0, %eax
	jmp	.L1358
.L1434:
	movl	$0, %eax
	jmp	.L1358
.L1435:
	movl	$0, %eax
	jmp	.L1358
.L1436:
	movl	$0, %eax
	jmp	.L1358
.L1437:
	movl	$0, %eax
	jmp	.L1358
.L1438:
	movl	$0, %eax
	jmp	.L1358
	.cfi_endproc
.LFE48:
	.size	cr_loop_unpack, .-cr_loop_unpack
	.globl	cr_loop_grid_count
	.type	cr_loop_grid_count, @function
cr_loop_grid_count:
.LFB53:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbp
	movl	$0, %esi
	call	cr_loop_grid_rate
	movl	%eax, %ecx
	cmpl	$5, %eax
	movl	$2, %eax
	cmovnb	%eax, %ecx
	movl	$24, %ebx
	sall	%cl, %ebx
	movq	%rbp, %rdi
	call	crl_grid_len
	leal	-1(%rbx,%rax), %eax
	movl	$0, %edx
	divl	%ebx
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE53:
	.size	cr_loop_grid_count, .-cr_loop_grid_count
	.globl	cr_loop_grid_snapshot_ex
	.type	cr_loop_grid_snapshot_ex, @function
cr_loop_grid_snapshot_ex:
.LFB54:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$872, %rsp
	.cfi_def_cfa_offset 928
	movq	%rdi, %r15
	movq	%rsi, %r9
	movq	%rdx, %r12
	movq	%rcx, %r14
	movq	%r8, 32(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 856(%rsp)
	xorl	%eax, %eax
	leaq	80(%rsp), %rdi
	movl	$32, %ecx
	rep stosq
	movq	%r8, %rcx
	jmp	.L1505
.L1491:
	cmpq	%rdx, %r9
	jb	.L1493
.L1492:
	movq	%r9, %rdi
	addq	%rax, %rdi
	je	.L1601
	movb	$0, (%r9,%rax)
	testq	%r14, %r14
	je	.L1495
	leaq	(%r14,%rax), %rdx
	testq	%rax, %rax
	js	.L1496
	cmpq	%r14, %rdx
	jnb	.L1497
.L1498:
	movq	%r14, %rsi
	leaq	.Lubsan_data482(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1601:
	movl	$0, %esi
	leaq	.Lubsan_data481(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1496:
	cmpq	%rdx, %r14
	jb	.L1498
.L1497:
	movq	%r14, %rdi
	addq	%rax, %rdi
	je	.L1602
	movb	$0, (%r14,%rax)
.L1495:
	testq	%rcx, %rcx
	je	.L1500
	leaq	(%rcx,%rax), %rdx
	testq	%rax, %rax
	js	.L1501
	cmpq	%rcx, %rdx
	jnb	.L1502
.L1503:
	movq	32(%rsp), %rsi
	leaq	.Lubsan_data484(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1602:
	movl	$0, %esi
	leaq	.Lubsan_data483(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1501:
	cmpq	%rdx, %rcx
	jb	.L1503
.L1502:
	movq	%rcx, %rdi
	addq	%rax, %rdi
	je	.L1603
	movb	$0, (%rcx,%rax)
.L1500:
	addq	$1, %rax
	cmpq	$16, %rax
	je	.L1604
.L1505:
	leaq	(%r9,%rax), %rdx
	testq	%rax, %rax
	js	.L1491
	cmpq	%r9, %rdx
	jnb	.L1492
.L1493:
	movq	%r9, %rsi
	leaq	.Lubsan_data480(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1603:
	movl	$0, %esi
	leaq	.Lubsan_data485(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1604:
	movl	$0, %eax
	movl	$0, %r13d
	movl	$0, %ebx
	leaq	336(%rsp), %rbp
	movq	%r9, 8(%rsp)
	movq	%r12, 16(%rsp)
	jmp	.L1512
.L1606:
	movl	%ebx, %esi
	leaq	.Lubsan_data486(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1607:
	movq	%rsi, %rdi
	addq	%r12, %rdi
	jc	.L1507
	leaq	.Lubsan_data487(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1508:
	cmpq	%rdx, %rbp
	jb	.L1510
.L1509:
	movl	%r13d, (%rax,%rbp)
	movl	%ebx, %esi
	movq	%r15, %rdi
	call	cr_loop_grid_rate
	movl	%eax, %ecx
	cmpl	$5, %eax
	movl	$2, %eax
	cmovnb	%eax, %ecx
	movl	$24, %eax
	sall	%cl, %eax
	addl	%eax, %r13d
	addl	$1, %ebx
	cmpl	$128, %ebx
	je	.L1605
	movq	%r12, %rax
.L1512:
	cmpl	$128, %ebx
	ja	.L1606
	leaq	0(%rbp,%rax), %rsi
	leaq	4(%rax), %r12
	cmpq	$516, %r12
	ja	.L1607
.L1507:
	leaq	0(%rbp,%rax), %rdx
	testq	%rax, %rax
	js	.L1508
	cmpq	%rbp, %rdx
	jnb	.L1509
.L1510:
	leaq	336(%rsp), %rsi
	leaq	.Lubsan_data488(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1605:
	movq	8(%rsp), %r9
	movq	16(%rsp), %r12
	movl	%r13d, 848(%rsp)
	testq	%r12, %r12
	je	.L1513
	movl	$0, %eax
	jmp	.L1519
.L1514:
	cmpq	%rdx, %r12
	jb	.L1516
.L1515:
	movq	%r12, %rsi
	addq	%rax, %rsi
	je	.L1517
	testb	$1, %sil
	jne	.L1517
	movw	$0, (%r12,%rax)
	addq	$2, %rax
	cmpq	$256, %rax
	je	.L1513
.L1519:
	leaq	(%r12,%rax), %rdx
	testq	%rax, %rax
	js	.L1514
	cmpq	%r12, %rdx
	jnb	.L1515
.L1516:
	movq	%r12, %rsi
	leaq	.Lubsan_data489(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1517:
	leaq	.Lubsan_data490(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1513:
	testq	%r15, %r15
	je	.L1520
	testb	$7, %r15b
	jne	.L1520
	leaq	12(%r15), %rdx
	cmpq	$-12, %r15
	jnb	.L1608
	cmpw	$0, 12(%r15)
	je	.L1523
	movl	$4, %eax
	subq	%rbp, %rax
	movq	%rax, %rdi
	movl	$148, %r10d
	movl	$0, %r11d
	leaq	336(%rsp), %rbp
	movq	32(%rsp), %rax
	orq	%r14, %rax
	movq	%rax, 40(%rsp)
	leaq	80(%rsp), %rcx
	movq	%rcx, 56(%rsp)
	movl	$2, %eax
	subq	%rcx, %rax
	movq	%rax, 64(%rsp)
	movl	%r13d, 28(%rsp)
	movl	%ebx, 52(%rsp)
	movq	%r12, 16(%rsp)
	movq	%rdi, %r12
	movq	%r14, 72(%rsp)
	jmp	.L1565
.L1520:
	movq	%r15, %rsi
	leaq	.Lubsan_data491(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1608:
	movq	%r15, %rsi
	leaq	.Lubsan_data492(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1622:
	movl	%r11d, %esi
	leaq	.Lubsan_data493(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1623:
	movq	%r15, %rsi
	leaq	.Lubsan_data494(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1624:
	movl	%r11d, %esi
	leaq	.Lubsan_data495(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1625:
	movq	%r15, %rsi
	leaq	.Lubsan_data496(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1626:
	movl	%eax, %esi
	leaq	.Lubsan_data497(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1627:
	addq	%r8, %r11
	jc	.L1530
	movq	%r8, %rsi
	leaq	.Lubsan_data498(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1628:
	leaq	336(%rsp), %rsi
	leaq	.Lubsan_data499(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1629:
	movl	48(%rsp), %r11d
	movl	%r11d, %esi
	leaq	.Lubsan_data500(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1630:
	movq	%r13, %rdx
	movq	%r15, %rsi
	leaq	.Lubsan_data501(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1631:
	movq	%rax, %rdx
	movq	%r9, %rsi
	leaq	.Lubsan_data502(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1632:
	movl	$0, %esi
	leaq	.Lubsan_data503(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1633:
	movq	%r9, %rsi
	leaq	.Lubsan_data504(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1634:
	movl	%r11d, %esi
	leaq	.Lubsan_data505(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1541:
	cmpq	%rdx, %r15
	jb	.L1543
.L1542:
	movzwl	148(%rbx), %ecx
	movl	%esi, %edx
	addq	%rdx, %rdx
	movq	16(%rsp), %rax
	addq	%rdx, %rax
	jc	.L1609
	movq	16(%rsp), %rax
	addq	%rdx, %rax
	je	.L1545
	testb	$1, %al
	jne	.L1545
	cmpw	%cx, (%rax)
	jnb	.L1539
	cmpl	$511, %r11d
	ja	.L1610
	movq	16(%rsp), %rdi
	addq	%rdi, %rdx
	jc	.L1611
	leaq	(%r15,%r10), %rdx
	testq	%r10, %r10
	js	.L1549
	cmpq	%r15, %rdx
	jnb	.L1550
.L1551:
	movq	%r15, %rsi
	leaq	.Lubsan_data511(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1609:
	movq	16(%rsp), %r12
	movq	%rax, %rdx
	movq	%r12, %rsi
	leaq	.Lubsan_data507(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1545:
	movq	%rax, %rsi
	leaq	.Lubsan_data508(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1610:
	movl	%r11d, %esi
	leaq	.Lubsan_data509(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1611:
	movq	%rdi, %rsi
	leaq	.Lubsan_data510(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1549:
	cmpq	%rdx, %r15
	jb	.L1551
.L1550:
	movw	%cx, (%rax)
.L1539:
	cmpq	$0, 40(%rsp)
	je	.L1526
	cmpl	$511, %r11d
	ja	.L1612
	movq	8(%rsp), %rax
	addq	%r15, %rax
	jc	.L1613
	movzwl	146(%rbx), %eax
	cmpl	$511, %r11d
	ja	.L1614
	leaq	(%r15,%r10), %rdx
	testq	%r10, %r10
	js	.L1555
	cmpq	%r15, %rdx
	jnb	.L1556
.L1557:
	movq	%r15, %rsi
	leaq	.Lubsan_data515(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1612:
	movl	%r11d, %esi
	leaq	.Lubsan_data512(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1613:
	movq	%rax, %rdx
	movq	%r15, %rsi
	leaq	.Lubsan_data513(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1614:
	movl	%r11d, %esi
	leaq	.Lubsan_data514(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1555:
	cmpq	%rdx, %r15
	jb	.L1557
.L1556:
	movzwl	148(%rbx), %edx
	leal	(%rdx,%rax), %edx
	movl	8(%r15), %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	cmpl	$127, %esi
	ja	.L1615
	movl	%esi, %eax
	addq	%rax, %rax
	movq	56(%rsp), %rdi
	leaq	(%rdi,%rax), %r8
	movq	64(%rsp), %rdi
	leaq	(%r8,%rdi), %rcx
	cmpq	$256, %rcx
	ja	.L1616
.L1560:
	movq	56(%rsp), %rdi
	addq	%rax, %rdi
	jc	.L1617
	movl	%esi, %edi
	movzwl	80(%rsp,%rdi,2), %edi
	cmpl	%edx, %edi
	jnb	.L1526
	cmpl	$127, %esi
	ja	.L1618
	cmpq	$256, %rcx
	ja	.L1619
.L1563:
	leaq	80(%rsp), %rcx
	addq	%rax, %rcx
	jc	.L1620
	movl	%esi, %esi
	movw	%dx, 80(%rsp,%rsi,2)
.L1526:
	addl	$1, %r11d
	addq	$8, %r10
	movzwl	12(%r15), %eax
	cmpl	%eax, %r11d
	jnb	.L1621
.L1565:
	cmpl	$511, %r11d
	ja	.L1622
	leaq	5(%r15,%r10), %rdx
	cmpq	%r15, %rdx
	jb	.L1623
	movl	%r11d, %eax
	leaq	(%r15,%rax,8), %rbx
	cmpb	$0, 153(%rbx)
	js	.L1526
	cmpl	$511, %r11d
	ja	.L1624
	leaq	-2(%r10), %rax
	movq	%rax, 8(%rsp)
	movq	%rax, %rdx
	addq	%r15, %rdx
	jc	.L1625
	movzwl	146(%rbx), %edi
	movl	28(%rsp), %eax
	cmpl	%eax, %edi
	jnb	.L1526
	movl	52(%rsp), %ecx
	movl	$0, %esi
	movl	%r11d, %r14d
	movq	8(%rsp), %rax
	leaq	(%r15,%rax), %r13
	movl	%r11d, 48(%rsp)
.L1535:
	leal	(%rsi,%rcx), %edx
	movl	%edx, %eax
	shrl	%eax
	cmpl	$257, %edx
	ja	.L1626
	movl	%eax, %edx
	salq	$2, %rdx
	leaq	0(%rbp,%rdx), %r8
	leaq	(%r8,%r12), %r11
	cmpq	$516, %r11
	ja	.L1627
.L1530:
	addq	%rbp, %rdx
	jc	.L1628
	movl	%eax, %edx
	movl	336(%rsp,%rdx,4), %edx
	cmpq	$512, %r14
	jnb	.L1629
	cmpq	%r15, %r13
	jb	.L1630
	cmpl	%edx, %edi
	cmovnb	%eax, %esi
	cmovb	%eax, %ecx
	leal	1(%rsi), %eax
	cmpl	%ecx, %eax
	jb	.L1535
	movl	48(%rsp), %r11d
	movl	%esi, %ecx
	andl	$7, %ecx
	movl	$1, %edi
	sall	%cl, %edi
	movl	%esi, %edx
	shrl	$3, %edx
	movl	%edx, %edx
	movq	%r9, %rax
	addq	%rdx, %rax
	jc	.L1631
	movq	%r9, %rcx
	addq	%rdx, %rcx
	je	.L1632
	movzbl	(%rcx), %eax
	addq	%r9, %rdx
	jc	.L1633
	orl	%edi, %eax
	movb	%al, (%rcx)
	cmpq	$0, 16(%rsp)
	je	.L1539
	cmpl	$511, %r11d
	ja	.L1634
	leaq	(%r15,%r10), %rdx
	testq	%r10, %r10
	js	.L1541
	cmpq	%r15, %rdx
	jnb	.L1542
.L1543:
	movq	%r15, %rsi
	leaq	.Lubsan_data506(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1615:
	movl	%esi, %esi
	leaq	.Lubsan_data516(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1616:
	movq	%r8, %rdi
	addq	%rcx, %rdi
	jc	.L1560
	movq	%r8, %rsi
	leaq	.Lubsan_data517(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1617:
	leaq	80(%rsp), %rsi
	movq	%rdi, %rdx
	leaq	.Lubsan_data518(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1618:
	movl	%esi, %esi
	leaq	.Lubsan_data519(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1619:
	addq	%r8, %rcx
	jc	.L1563
	movq	%r8, %rsi
	leaq	.Lubsan_data520(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1620:
	leaq	80(%rsp), %rsi
	movq	%rcx, %rdx
	leaq	.Lubsan_data521(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1621:
	movq	72(%rsp), %r14
.L1523:
	movq	32(%rsp), %rax
	orq	%r14, %rax
	jne	.L1635
.L1490:
	movq	856(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1636
	addq	$872, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1635:
	.cfi_restore_state
	movq	%r15, %rdi
	call	cr_loop_grid_count
	movl	%eax, %ebp
	testl	%eax, %eax
	je	.L1490
	leaq	340(%rsp), %r9
	leaq	80(%rsp), %r11
	movl	$2, %edi
	movl	$4, %esi
	movl	$0, %ebx
	movl	$0, %eax
	leaq	336(%rsp), %r10
	movl	$1, %r15d
	movq	%r11, %r8
	movq	32(%rsp), %r13
	jmp	.L1589
.L1640:
	movl	%eax, %esi
	leaq	.Lubsan_data522(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1641:
	movq	%rdx, %rcx
	addq	%rsi, %rcx
	jc	.L1569
	movq	%rdx, %rsi
	leaq	.Lubsan_data523(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1642:
	leaq	336(%rsp), %rsi
	leaq	.Lubsan_data524(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1643:
	movq	%rcx, %rdx
	movq	%r14, %rsi
	leaq	.Lubsan_data525(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1644:
	movl	$0, %esi
	leaq	.Lubsan_data526(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1645:
	movq	%r14, %rsi
	leaq	.Lubsan_data527(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1646:
	movl	%eax, %esi
	leaq	.Lubsan_data528(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1647:
	movq	%r11, %rcx
	addq	%rdi, %rcx
	jc	.L1575
	movq	%r11, %rsi
	leaq	.Lubsan_data529(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1648:
	leaq	80(%rsp), %rsi
	movq	%rcx, %rdx
	leaq	.Lubsan_data530(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1649:
	movl	%eax, %esi
	leaq	.Lubsan_data531(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1650:
	movq	%r12, %rbx
	addq	%rdi, %rbx
	jc	.L1579
	movq	%r12, %rsi
	leaq	.Lubsan_data532(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1651:
	leaq	80(%rsp), %rsi
	leaq	.Lubsan_data533(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1652:
	movl	%edx, %esi
	leaq	.Lubsan_data534(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1653:
	addq	%r9, %rdx
	jc	.L1582
	movq	%r9, %rsi
	leaq	.Lubsan_data535(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1583:
	cmpq	%rdx, %r10
	jb	.L1585
.L1584:
	cmpl	%ebx, (%rcx)
	jnb	.L1580
	movl	%eax, %ecx
	andl	$7, %ecx
	movl	%r15d, %edx
	sall	%cl, %edx
	movl	%edx, 8(%rsp)
	movl	%eax, %edx
	shrl	$3, %edx
	movl	%edx, %edx
	movq	%r13, %rcx
	addq	%rdx, %rcx
	jc	.L1637
	movq	%r13, %r12
	addq	%rdx, %r12
	je	.L1638
	movzbl	(%r12), %ecx
	addq	%r13, %rdx
	jc	.L1639
	orb	8(%rsp), %cl
	movb	%cl, (%r12)
.L1580:
	addl	$1, %eax
	addq	$4, %r9
	addq	$4, %rsi
	addq	$2, %r11
	addq	$2, %rdi
	cmpl	%eax, %ebp
	je	.L1490
.L1589:
	testq	%r14, %r14
	je	.L1567
	cmpl	$128, %eax
	ja	.L1640
	leaq	-4(%r9), %rdx
	cmpq	$516, %rsi
	ja	.L1641
.L1569:
	leaq	-4(%r10,%rsi), %rdx
	cmpq	%r10, %rdx
	jb	.L1642
	cmpl	%ebx, -4(%r9)
	jnb	.L1567
	movl	%eax, %ecx
	andl	$7, %ecx
	movl	%r15d, %edx
	sall	%cl, %edx
	movl	%edx, 8(%rsp)
	movl	%eax, %edx
	shrl	$3, %edx
	movl	%edx, %edx
	movq	%r14, %rcx
	addq	%rdx, %rcx
	jc	.L1643
	movq	%r14, %r12
	addq	%rdx, %r12
	je	.L1644
	movzbl	(%r12), %ecx
	addq	%r14, %rdx
	jc	.L1645
	orb	8(%rsp), %cl
	movb	%cl, (%r12)
.L1567:
	cmpl	$127, %eax
	ja	.L1646
	movq	%r11, %r12
	cmpq	$256, %rdi
	ja	.L1647
.L1575:
	leaq	-2(%rdi), %rdx
	movq	%r8, %rcx
	addq	%rdx, %rcx
	jc	.L1648
	movzwl	(%r12), %ecx
	cmpl	%ecx, %ebx
	jnb	.L1577
	cmpl	$127, %eax
	ja	.L1649
	cmpq	$256, %rdi
	ja	.L1650
.L1579:
	addq	%r8, %rdx
	jc	.L1651
	movl	%ecx, %ebx
.L1577:
	testq	%r13, %r13
	je	.L1580
	leal	1(%rax), %edx
	cmpl	$128, %edx
	ja	.L1652
	movq	%r9, %rcx
	leaq	4(%rsi), %rdx
	cmpq	$516, %rdx
	ja	.L1653
.L1582:
	leaq	(%r10,%rsi), %rdx
	testq	%rsi, %rsi
	js	.L1583
	cmpq	%r10, %rdx
	jnb	.L1584
.L1585:
	leaq	336(%rsp), %rsi
	leaq	.Lubsan_data536(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1637:
	movq	%rcx, %rdx
	movq	32(%rsp), %rsi
	leaq	.Lubsan_data537(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1638:
	movl	$0, %esi
	leaq	.Lubsan_data538(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1639:
	movq	32(%rsp), %rsi
	leaq	.Lubsan_data539(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1636:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE54:
	.size	cr_loop_grid_snapshot_ex, .-cr_loop_grid_snapshot_ex
	.globl	cr_loop_grid_snapshot
	.type	cr_loop_grid_snapshot, @function
cr_loop_grid_snapshot:
.LFB55:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$0, %r8d
	movl	$0, %ecx
	call	cr_loop_grid_snapshot_ex
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE55:
	.size	cr_loop_grid_snapshot, .-cr_loop_grid_snapshot
	.globl	cr_loop_grid_masks
	.type	cr_loop_grid_masks, @function
cr_loop_grid_masks:
.LFB56:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$0, %edx
	call	cr_loop_grid_snapshot
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE56:
	.size	cr_loop_grid_masks, .-cr_loop_grid_masks
	.globl	cr_loop_grid_mask
	.type	cr_loop_grid_mask, @function
cr_loop_grid_mask:
.LFB57:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	cmpl	$15, %esi
	jbe	.L1666
.L1658:
	movq	24(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1667
	addq	$32, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L1666:
	.cfi_restore_state
	movl	%esi, %ebx
	movq	%rsp, %rsi
	call	cr_loop_grid_masks
	cmpl	$15, %ebx
	ja	.L1668
	movl	%ebx, %eax
	leaq	(%rsp,%rax), %rsi
	leaq	1(%rax), %rdx
	cmpq	$16, %rdx
	ja	.L1669
.L1661:
	movq	%rsp, %rdx
	addq	%rax, %rdx
	jc	.L1670
	movl	%ebx, %ebx
	movzbl	(%rsp,%rbx), %eax
	jmp	.L1658
.L1668:
	movl	%ebx, %esi
	leaq	.Lubsan_data540(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1669:
	addq	%rsi, %rdx
	jc	.L1661
	leaq	.Lubsan_data541(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1670:
	movq	%rsp, %rsi
	leaq	.Lubsan_data542(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1667:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE57:
	.size	cr_loop_grid_mask, .-cr_loop_grid_mask
	.globl	cr_loop_grid_resize
	.type	cr_loop_grid_resize, @function
cr_loop_grid_resize:
.LFB59:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rbx
	movq	%rsi, %r13
	movl	%edx, %r12d
	movl	$0, %esi
	call	cr_loop_grid_rate
	movl	%eax, %ecx
	cmpl	$5, %eax
	movl	$2, %eax
	cmovnb	%eax, %ecx
	cmpl	$4, %r12d
	ja	.L1711
	testq	%rbx, %rbx
	je	.L1674
	testb	$7, %bl
	jne	.L1674
	leaq	4245(%rbx), %rdx
	cmpq	$-4245, %rbx
	jnb	.L1721
	cmpb	$0, 4245(%rbx)
	jne	.L1712
	leaq	4712(%rbx), %rdx
	cmpq	$-4712, %rbx
	jnb	.L1722
	cmpb	$0, 4712(%rbx)
	jne	.L1713
	testl	%r12d, %r12d
	je	.L1714
	cmpl	$4, %r12d
	ja	.L1723
	movl	%r12d, %eax
	leaq	CRL_BARS(%rip), %rdx
	leaq	(%rax,%rdx), %rsi
	leaq	1(%rax), %rdx
	cmpq	$5, %rdx
	ja	.L1724
.L1680:
	leaq	CRL_BARS(%rip), %rdx
	addq	%rax, %rdx
	jc	.L1725
	movl	%r12d, %eax
	leaq	CRL_BARS(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	leal	(%rax,%rax,2), %ebp
	sall	$7, %ebp
.L1678:
	movzwl	12(%rbx), %eax
	movzwl	%ax, %edi
	testw	%ax, %ax
	je	.L1682
	movl	$153, %eax
	movl	$0, %edx
	jmp	.L1690
.L1674:
	movq	%rbx, %rsi
	leaq	.Lubsan_data543(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1721:
	movq	%rbx, %rsi
	leaq	.Lubsan_data544(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1722:
	movq	%rbx, %rsi
	leaq	.Lubsan_data545(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1723:
	movl	%r12d, %esi
	leaq	.Lubsan_data546(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1724:
	addq	%rsi, %rdx
	jc	.L1680
	leaq	.Lubsan_data547(%rip), %rdi
	call	__ubsan_handle_type_mismatch_v1_abort@PLT
.L1725:
	leaq	CRL_BARS(%rip), %rsi
	leaq	.Lubsan_data548(%rip), %rdi
	call	__ubsan_handle_pointer_overflow_abort@PLT
.L1714:
	movl	$768, %ebp
	jmp	.L1678
.L1728:
	movl	%edx, %esi
	leaq	.Lubsan_data549(%rip), %rdi
	call	__ubsan_handle_out_of_bounds_abort@PLT
.L1684:
	cmpq	%rsi, %rbx
	jb	.L1686
.L1685:
	cmpb	$0, (%rbx,%rax)
	js	.L1687
	cmpl	$511, %edx
	ja	.L1726
	leaq	-7(%rbx,%rax), %rsi
	cmpq	%rbx, %rsi
	jb	.L1727
	movzwl	-7(%rbx,%rax), %esi
	cmpl	%ebp, %esi
	jnb	.L1715
.L1687:
	addl	$1, %edx
	ad