	.file	"cr_backup_test.c"
	.text
	.type	rng, @function
rng:
.LFB78:
	.cfi_startproc
	movl	rng_state(%rip), %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, rng_state(%rip)
	ret
	.cfi_endproc
.LFE78:
	.size	rng, .-rng
	.type	cr_prof_half, @function
cr_prof_half:
.LFB87:
	.cfi_startproc
	cmpb	$0, 2+cr_dbg(%rip)
	je	.L2
	cmpb	$0, 1+cr_dbg(%rip)
	je	.L4
	leaq	cr_dbg(%rip), %rax
	leaq	24(%rax), %rdx
.L5:
	movl	$0, 72(%rax)
	movl	$0, 48(%rax)
	addq	$4, %rax
	cmpq	%rdx, %rax
	jne	.L5
	movl	$0, 96+cr_dbg(%rip)
	movb	$0, 1+cr_dbg(%rip)
.L4:
	leaq	cr_dbg(%rip), %rax
	leaq	24(%rax), %r8
	movq	%rax, %rcx
	jmp	.L8
.L7:
	movl	$0, 24(%rsi)
	addq	$4, %rax
	addq	$8, %rcx
	cmpq	%r8, %rax
	je	.L11
.L8:
	movq	%rax, %rsi
	movl	24(%rax), %edx
	addl	%edx, 48(%rax)
	cmpl	%edx, 72(%rax)
	jnb	.L6
	movl	%edx, 72(%rax)
.L6:
	movl	%edx, %edi
	addq	%rdi, 152(%rcx)
	cmpl	%edx, 200(%rsi)
	jnb	.L7
	movl	%edx, 200(%rsi)
	jmp	.L7
.L11:
	addl	$1, 96+cr_dbg(%rip)
	addl	$1, 224+cr_dbg(%rip)
.L2:
	ret
	.cfi_endproc
.LFE87:
	.size	cr_prof_half, .-cr_prof_half
	.type	bass_note_on, @function
bass_note_on:
.LFB128:
	.cfi_startproc
	endbr64
	movl	32(%rsi), %eax
	leal	1073741824(%rax), %edx
	movl	%edx, 36(%rsi)
	shrl	%eax
	movl	%eax, 40(%rsi)
	movl	$0, 48(%rsi)
	movl	$0, 44(%rsi)
	ret
	.cfi_endproc
.LFE128:
	.size	bass_note_on, .-bass_note_on
	.type	bass_edit_get, @function
bass_edit_get:
.LFB130:
	.cfi_startproc
	endbr64
	movl	%esi, %ecx
	orl	%edx, %ecx
	movl	$0, %eax
	cmpl	$3, %ecx
	ja	.L13
	movl	%edx, %edx
	movl	%esi, %esi
	leaq	BASS_PAGE_ID(%rip), %rax
	leaq	(%rax,%rsi,4), %rax
	movzbl	(%rax,%rdx), %eax
	movswl	(%rdi,%rax,2), %eax
.L13:
	ret
	.cfi_endproc
.LFE130:
	.size	bass_edit_get, .-bass_edit_get
	.type	bass_edit_set, @function
bass_edit_set:
.LFB131:
	.cfi_startproc
	endbr64
	movl	%edx, %eax
	movl	%ecx, %edx
	movl	%esi, %ecx
	orl	%eax, %ecx
	cmpl	$3, %ecx
	ja	.L16
	leaq	BASS_PAGES(%rip), %r10
	movl	%eax, %ecx
	movl	%esi, %r9d
	salq	$5, %rcx
	movq	%r9, %r8
	salq	$4, %r8
	leaq	(%r8,%r9), %r11
	leaq	(%rcx,%r11,8), %r11
	movswl	18(%r10,%r11), %ecx
	movswl	20(%r10,%r11), %r8d
	cmpl	%edx, %r8d
	cmovg	%edx, %r8d
	cmpl	%edx, %ecx
	cmovle	%r8d, %ecx
	movl	%eax, %eax
	movl	%esi, %esi
	leaq	BASS_PAGE_ID(%rip), %rdx
	leaq	(%rdx,%rsi,4), %rdx
	movzbl	(%rdx,%rax), %eax
	movw	%cx, (%rdi,%rax,2)
.L16:
	ret
	.cfi_endproc
.LFE131:
	.size	bass_edit_set, .-bass_edit_set
	.type	pd_setup, @function
pd_setup:
.LFB134:
	.cfi_startproc
	movl	%esi, (%rdi)
	cmpl	$4, %esi
	ja	.L20
	movl	%esi, %esi
	leaq	.L22(%rip), %rcx
	movslq	(%rcx,%rsi,4), %rax
	addq	%rcx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L22:
	.long	.L26-.L22
	.long	.L25-.L22
	.long	.L24-.L22
	.long	.L23-.L22
	.long	.L21-.L22
	.text
.L26:
	movl	%edx, %esi
	sall	$15, %esi
	subl	%edx, %esi
	shrl	$16, %esi
	addl	$32768, %esi
	movl	$1, %ecx
	cmovne	%esi, %ecx
	movl	$-2147483648, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 16(%rdi)
	movl	$65535, %ecx
	subl	%esi, %ecx
	movl	$1, %eax
	cmove	%eax, %ecx
	movl	$2147418112, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 20(%rdi)
.L27:
	movl	%esi, 4(%rdi)
	ret
.L25:
	imull	$31120, %edx, %edx
	shrl	$16, %edx
	movl	$32768, %esi
	subl	%edx, %esi
	movl	$1, %ecx
	cmovne	%esi, %ecx
	movl	$-2147483648, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 16(%rdi)
	movl	$2147418112, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 20(%rdi)
	jmp	.L27
.L24:
	imull	$63487, %edx, %edx
	shrl	$16, %edx
	movl	$65535, %esi
	subl	%edx, %esi
	movl	$1, %ecx
	cmovne	%esi, %ecx
	movl	$-65536, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 16(%rdi)
	jmp	.L27
.L23:
	imull	$49151, %edx, %ecx
	shrl	$16, %ecx
	movl	$65535, %esi
	subl	%ecx, %esi
	movl	$1, %r9d
	cmovne	%esi, %r9d
	movl	$-65536, %r8d
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, 16(%rdi)
	testl	%ecx, %ecx
	movl	$1, %eax
	cmove	%eax, %ecx
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 20(%rdi)
	jmp	.L27
.L21:
	movl	%edx, %eax
	sall	$15, %eax
	subl	%edx, %eax
	shrl	$16, %eax
	movl	$65535, %esi
	subl	%eax, %esi
	imull	$29491, %edx, %ecx
	shrl	$16, %ecx
	addl	$32768, %ecx
	imull	%esi, %ecx
	shrl	$16, %ecx
	movl	$1, %eax
	cmove	%eax, %ecx
	movl	%ecx, 8(%rdi)
	testl	%ecx, %ecx
	movl	$1, %r8d
	cmovne	%ecx, %r8d
	movl	$-2147483648, %eax
	movl	$0, %edx
	divl	%r8d
	movl	%eax, 16(%rdi)
	movl	%esi, %r8d
	subl	%ecx, %r8d
	movl	$1, %eax
	cmove	%eax, %r8d
	movl	$2147418112, %eax
	movl	$0, %edx
	divl	%r8d
	movl	%eax, 20(%rdi)
	jmp	.L27
.L20:
	imull	$44000, %edx, %edx
	shrl	$16, %edx
	movl	%edx, 12(%rdi)
	movl	$0, %esi
	jmp	.L27
	.cfi_endproc
.LFE134:
	.size	pd_setup, .-pd_setup
	.type	phase_note_on, @function
phase_note_on:
.LFB136:
	.cfi_startproc
	endbr64
	movl	$0, 36(%rsi)
	movl	$0, 40(%rsi)
	movl	$0, 44(%rsi)
	movl	$0, 48(%rsi)
	ret
	.cfi_endproc
.LFE136:
	.size	phase_note_on, .-phase_note_on
	.type	fm6_fn_set, @function
fm6_fn_set:
.LFB139:
	.cfi_startproc
	cmpl	$2, %edi
	ja	.L29
	cmpl	$15, %esi
	ja	.L29
	movl	%esi, %esi
	movl	%edi, %edi
	salq	$4, %rdi
	leaq	fm6_fn(%rip), %rcx
	addq	%rdi, %rcx
	leaq	FM6_FNMAX(%rip), %rax
	movzbl	(%rax,%rsi), %eax
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	testl	%edx, %edx
	movl	$0, %eax
	cmovs	%eax, %edx
	movb	%dl, (%rcx,%rsi)
.L29:
	ret
	.cfi_endproc
.LFE139:
	.size	fm6_fn_set, .-fm6_fn_set
	.type	fm6_carriers, @function
fm6_carriers:
.LFB142:
	.cfi_startproc
	andl	$31, %edi
	leaq	(%rdi,%rdi,2), %rdx
	leaq	FM6_ALG(%rip), %rax
	leaq	(%rax,%rdx,2), %rsi
	movl	$0, %ecx
	movl	$0, %edx
.L32:
	testb	$3, (%rsi,%rcx)
	sete	%al
	movzbl	%al, %eax
	sall	%cl, %eax
	orl	%eax, %edx
	addq	$1, %rcx
	cmpq	$6, %rcx
	jne	.L32
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE142:
	.size	fm6_carriers, .-fm6_carriers
	.type	fm6_freq, @function
fm6_freq:
.LFB145:
	.cfi_startproc
	movl	%edi, %edx
	shrl	$14, %edx
	andl	$1023, %edx
	leaq	FM6_FREQ(%rip), %rcx
	movl	%edx, %eax
	movl	(%rcx,%rax,4), %eax
	addl	$1, %edx
	movl	%edx, %edx
	movl	(%rcx,%rdx,4), %edx
	subl	%eax, %edx
	movslq	%edx, %rdx
	movl	%edi, %ecx
	andl	$16383, %ecx
	imulq	%rcx, %rdx
	sarq	$14, %rdx
	addl	%edx, %eax
	sarl	$24, %edi
	movl	$20, %ecx
	subl	%edi, %ecx
	testl	%ecx, %ecx
	jle	.L34
	sarl	%cl, %eax
	cmpl	$32, %ecx
	movl	$0, %edx
	cmovge	%edx, %eax
.L34:
	ret
	.cfi_endproc
.LFE145:
	.size	fm6_freq, .-fm6_freq
	.type	fm6_mulhi, @function
fm6_mulhi:
.LFB148:
	.cfi_startproc
	movq	%rdi, %rcx
	shrq	$32, %rcx
	movq	%rsi, %r9
	shrq	$32, %r9
	movl	%esi, %esi
	movq	%rcx, %rdx
	imulq	%rsi, %rdx
	movl	%edi, %edi
	movq	%r9, %r8
	imulq	%rdi, %r8
	movq	%rsi, %rax
	imulq	%rdi, %rax
	shrq	$32, %rax
	movl	%edx, %esi
	addq	%rsi, %rax
	movl	%r8d, %esi
	addq	%rsi, %rax
	shrq	$32, %rax
	shrq	$32, %rdx
	shrq	$32, %r8
	addq	%r8, %rdx
	imulq	%r9, %rcx
	addq	%rcx, %rdx
	addq	%rdx, %rax
	ret
	.cfi_endproc
.LFE148:
	.size	fm6_mulhi, .-fm6_mulhi
	.type	fm6_scaleout, @function
fm6_scaleout:
.LFB150:
	.cfi_startproc
	cmpl	$19, %edi
	jle	.L39
	leal	28(%rdi), %eax
	ret
.L39:
	testl	%edi, %edi
	movl	$0, %eax
	cmovs	%eax, %edi
	movslq	%edi, %rdi
	leaq	FM6_LEVELLUT(%rip), %rax
	movzbl	(%rax,%rdi), %eax
	ret
	.cfi_endproc
.LFE150:
	.size	fm6_scaleout, .-fm6_scaleout
	.type	fm6_curve, @function
fm6_curve:
.LFB151:
	.cfi_startproc
	testl	%edx, %edx
	je	.L46
	cmpl	$3, %edx
	je	.L46
	movl	$32, %eax
	cmpl	%eax, %edi
	cmovle	%edi, %eax
	movslq	%eax, %rcx
	leaq	FM6_EXPSCALE(%rip), %rax
	movzbl	(%rax,%rcx), %eax
	imull	%esi, %eax
	imull	$329, %eax, %eax
	sarl	$15, %eax
	jmp	.L44
.L46:
	imull	%esi, %edi
	imull	$329, %edi, %eax
	sarl	$12, %eax
.L44:
	movl	%eax, %ecx
	negl	%ecx
	cmpl	$2, %edx
	cmovl	%ecx, %eax
	ret
	.cfi_endproc
.LFE151:
	.size	fm6_curve, .-fm6_curve
	.type	fm6_logfreq, @function
fm6_logfreq:
.LFB154:
	.cfi_startproc
	movq	%rdi, %rdx
	cmpb	$0, 17(%rdi)
	jne	.L52
	imull	$1398101, %esi, %edi
	movzbl	20(%rdx), %eax
	subl	$7, %eax
	cltq
	movl	%esi, %esi
	leaq	FM6_DETUNE(%rip), %rcx
	imulq	(%rcx,%rsi,8), %rax
	sarq	$24, %rax
	movzbl	18(%rdx), %ecx
	andl	$31, %ecx
	leaq	FM6_COARSE(%rip), %rsi
	addl	(%rsi,%rcx,4), %eax
	leal	50857777(%rdi,%rax), %eax
	movzbl	19(%rdx), %ecx
	leaq	FM6_FINE(%rip), %rdx
	addl	(%rdx,%rcx,4), %eax
	ret
.L52:
	movzbl	18(%rdi), %ecx
	andl	$3, %ecx
	imull	$100, %ecx, %ecx
	movzbl	19(%rdi), %eax
	addl	%eax, %ecx
	imull	$4458616, %ecx, %ecx
	sarl	$3, %ecx
	movzbl	20(%rdi), %edx
	movl	$0, %eax
	cmpb	$7, %dl
	jbe	.L49
	movzbl	%dl, %edx
	subl	$7, %edx
	imull	$13457, %edx, %eax
.L49:
	addl	%ecx, %eax
	ret
	.cfi_endproc
.LFE154:
	.size	fm6_logfreq, .-fm6_logfreq
	.type	fm6_eg_go, @function
fm6_eg_go:
.LFB155:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	movb	%r8b, 16(%rdi)
	cmpl	$3, %r8d
	ja	.L53
	movq	%rsi, %r15
	movl	%edx, %r14d
	movl	%ecx, %r12d
	movl	%r8d, %ebp
	leal	4(%r8), %eax
	movzbl	(%rsi,%rax), %r13d
	movzbl	%r13b, %edi
	call	fm6_scaleout
	movl	%ebp, %edx
	addq	%r15, %rdx
	movzbl	(%rdx), %ecx
	leal	(%rcx,%rcx,4), %esi
	leal	(%rcx,%rsi,8), %ecx
	sarl	$6, %ecx
	addl	%r12d, %ecx
	movl	$63, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	testl	%ecx, %ecx
	movl	$0, %esi
	cmovs	%esi, %ecx
	sarl	%eax
	sall	$6, %eax
	leal	-4256(%r14,%rax), %eax
	movl	$16, %esi
	cmpl	%esi, %eax
	cmovl	%esi, %eax
	sall	$16, %eax
	movl	%eax, 4(%rbx)
	movl	(%rbx), %esi
	cmpl	%esi, %eax
	setg	17(%rbx)
	movl	$0, 12(%rbx)
	je	.L55
	movzbl	%r13b, %eax
	orl	%ebp, %eax
	jne	.L57
	movzbl	(%rdx), %eax
	addl	%r12d, %eax
	jns	.L61
	movl	$1764000, %eax
.L60:
	movslq	%eax, %rdx
	imulq	$1717986919, %rdx, %rdx
	sarq	$35, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, 12(%rbx)
	jmp	.L57
.L55:
	movzbl	(%rdx), %eax
	addl	%r12d, %eax
	js	.L62
.L61:
	movl	$99, %edx
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	cmpl	$76, %eax
	jle	.L58
	movl	$99, %eax
	subl	%edx, %eax
	leal	(%rax,%rax,4), %eax
	sall	$2, %eax
	movl	%eax, 12(%rbx)
	jmp	.L57
.L62:
	movl	$0, %edx
.L58:
	movslq	%edx, %rdx
	leaq	FM6_STATICS(%rip), %rax
	movl	(%rax,%rdx,4), %eax
	movzbl	%r13b, %r13d
	orl	%ebp, %r13d
	je	.L60
	movl	%eax, 12(%rbx)
.L57:
	movl	%ecx, %eax
	andl	$3, %eax
	addl	$4, %eax
	sarl	$2, %ecx
	addl	$8, %ecx
	sall	%cl, %eax
	movl	%eax, 8(%rbx)
.L53:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE155:
	.size	fm6_eg_go, .-fm6_eg_go
	.type	fm6_eg_step, @function
fm6_eg_step:
.LFB156:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	movq	%rsi, %r12
	movl	%edx, %r13d
	movl	%ecx, %r14d
	movl	%r8d, %ebp
	movl	12(%rdi), %eax
	testl	%eax, %eax
	je	.L65
	subl	$64, %eax
	movl	%eax, 12(%rdi)
	testl	%eax, %eax
	jle	.L78
	movzbl	16(%rdi), %eax
	cmpb	$2, %al
	jbe	.L68
.L73:
	testl	%ebp, %ebp
	jne	.L68
	cmpb	$3, %al
	ja	.L68
	jmp	.L67
.L78:
	movl	$0, 12(%rdi)
	movzbl	16(%rdi), %r8d
	addl	$1, %r8d
	call	fm6_eg_go
	movzbl	16(%rbx), %eax
	cmpb	$2, %al
	ja	.L73
.L67:
	cmpl	$0, 12(%rbx)
	je	.L71
.L68:
	movl	(%rbx), %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L69:
	.cfi_restore_state
	movl	(%rbx), %edx
	subl	8(%rbx), %edx
	movl	%edx, (%rbx)
	movl	4(%rbx), %ecx
	cmpl	%ecx, %edx
	jg	.L68
	movl	%ecx, (%rbx)
	addl	$1, %eax
	movzbl	%al, %r8d
	movl	%r14d, %ecx
	movl	%r13d, %edx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	fm6_eg_go
	jmp	.L68
.L65:
	movzbl	16(%rdi), %eax
	cmpb	$2, %al
	jbe	.L71
	testl	%r8d, %r8d
	jne	.L68
	cmpb	$3, %al
	ja	.L68
.L71:
	cmpb	$0, 17(%rbx)
	je	.L69
	cmpl	$112459775, (%rbx)
	jg	.L70
	movl	$112459776, (%rbx)
.L70:
	movl	(%rbx), %ecx
	movl	$285212672, %edx
	subl	%ecx, %edx
	sarl	$24, %edx
	imull	8(%rbx), %edx
	addl	%ecx, %edx
	movl	%edx, (%rbx)
	movl	4(%rbx), %ecx
	cmpl	%ecx, %edx
	jl	.L68
	movl	%ecx, (%rbx)
	addl	$1, %eax
	movzbl	%al, %r8d
	movl	%r14d, %ecx
	movl	%r13d, %edx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	fm6_eg_go
	jmp	.L68
	.cfi_endproc
.LFE156:
	.size	fm6_eg_step, .-fm6_eg_step
	.type	fm6_peg_go, @function
fm6_peg_go:
.LFB157:
	.cfi_startproc
	movb	%sil, 12(%rdi)
	cmpl	$3, %esi
	ja	.L79
	movl	%esi, %esi
	movzbl	18(%rdi,%rsi), %eax
	leaq	FM6_PEG_STEP(%rip), %rdx
	movsbl	(%rdx,%rax), %eax
	sall	$19, %eax
	movl	%eax, 4(%rdi)
	cmpl	(%rdi), %eax
	setg	13(%rdi)
	movzbl	14(%rdi,%rsi), %eax
	leaq	FM6_PEG_RATE(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	imull	$1143, %eax, %eax
	movl	%eax, 8(%rdi)
.L79:
	ret
	.cfi_endproc
.LFE157:
	.size	fm6_peg_go, .-fm6_peg_go
	.type	fm6_peg_set, @function
fm6_peg_set:
.LFB158:
	.cfi_startproc
	movl	$0, %eax
.L82:
	movzbl	126(%rsi,%rax), %edx
	movb	%dl, 14(%rdi,%rax)
	movzbl	130(%rsi,%rax), %edx
	movb	%dl, 18(%rdi,%rax)
	addq	$1, %rax
	cmpq	$4, %rax
	jne	.L82
	movzbl	21(%rdi), %eax
	leaq	FM6_PEG_STEP(%rip), %rdx
	movsbl	(%rdx,%rax), %eax
	sall	$19, %eax
	movl	%eax, (%rdi)
	movl	$0, %esi
	call	fm6_peg_go
	ret
	.cfi_endproc
.LFE158:
	.size	fm6_peg_set, .-fm6_peg_set
	.type	fm6_max, @function
fm6_max:
.LFB167:
	.cfi_startproc
	cmpl	$125, %edi
	jbe	.L88
	movl	$126, %eax
	cmpl	$144, %edi
	jbe	.L89
.L84:
	ret
.L88:
	movl	%edi, %edx
	movl	$2249744775, %eax
	imulq	%rax, %rdx
	shrq	$32, %rdx
	movl	%edi, %eax
	subl	%edx, %eax
	shrl	%eax
	addl	%edx, %eax
	shrl	$4, %eax
	leal	(%rax,%rax,4), %edx
	leal	(%rax,%rdx,4), %eax
	subl	%eax, %edi
	leaq	OPMAX.32(%rip), %rax
	movzbl	(%rax,%rdi), %eax
	ret
.L89:
	leal	-126(%rdi), %eax
	leaq	VMAX.31(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	ret
	.cfi_endproc
.LFE167:
	.size	fm6_max, .-fm6_max
	.type	fm6_sanitize, @function
fm6_sanitize:
.LFB168:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbp
	movl	$0, %ebx
	movl	$32, %r12d
	jmp	.L96
.L100:
	movzbl	0(%rbp,%rbx), %eax
	leal	-32(%rax), %edx
	cmpb	$95, %dl
	cmovnb	%r12d, %eax
	movb	%al, 0(%rbp,%rbx)
	addq	$1, %rbx
	cmpq	$155, %rbx
	jne	.L96
	movb	$0, 155(%rbp)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L95:
	.cfi_restore_state
	addq	$1, %rbx
.L96:
	movl	%ebx, %edi
	cmpl	$144, %ebx
	ja	.L100
	call	fm6_max
	movzbl	0(%rbp,%rbx), %edx
	cmpl	%edx, %eax
	jnb	.L95
	movb	%al, 0(%rbp,%rbx)
	jmp	.L95
	.cfi_endproc
.LFE168:
	.size	fm6_sanitize, .-fm6_sanitize
	.type	fm6_unpack, @function
fm6_unpack:
.LFB169:
	.cfi_startproc
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r8, %r10
	movq	%rsi, %r9
	leaq	126(%rsi), %r11
.L103:
	movq	%r10, %rsi
	movq	%r9, %rcx
	movl	$0, %eax
.L102:
	movzbl	(%rsi,%rax), %edx
	andl	$127, %edx
	movb	%dl, (%rcx,%rax)
	addq	$1, %rax
	cmpq	$11, %rax
	jne	.L102
	movzbl	11(%rsi), %eax
	andl	$3, %eax
	movb	%al, 11(%rcx)
	movzbl	11(%rsi), %eax
	shrb	$2, %al
	andl	$3, %eax
	movb	%al, 12(%rcx)
	movzbl	12(%rsi), %eax
	andl	$7, %eax
	movb	%al, 13(%rcx)
	movzbl	12(%rsi), %eax
	shrb	$3, %al
	andl	$15, %eax
	movb	%al, 20(%rcx)
	movzbl	13(%rsi), %eax
	andl	$3, %eax
	movb	%al, 14(%rcx)
	movzbl	13(%rsi), %eax
	shrb	$2, %al
	andl	$7, %eax
	movb	%al, 15(%rcx)
	movzbl	14(%rsi), %eax
	andl	$127, %eax
	movb	%al, 16(%rcx)
	movzbl	15(%rsi), %eax
	andl	$1, %eax
	movb	%al, 17(%rcx)
	movzbl	15(%rsi), %eax
	shrb	%al
	andl	$31, %eax
	movb	%al, 18(%rcx)
	movzbl	16(%rsi), %eax
	andl	$127, %eax
	movb	%al, 19(%rcx)
	addq	$17, %r10
	addq	$21, %r9
	cmpq	%r11, %r9
	jne	.L103
	movl	$0, %eax
.L104:
	movzbl	102(%r8,%rax), %edx
	andl	$127, %edx
	movb	%dl, 126(%rdi,%rax)
	addq	$1, %rax
	cmpq	$9, %rax
	jne	.L104
	andb	$31, 134(%rdi)
	movzbl	111(%r8), %eax
	andl	$7, %eax
	movb	%al, 135(%rdi)
	movzbl	111(%r8), %eax
	shrb	$3, %al
	andl	$1, %eax
	movb	%al, 136(%rdi)
	movl	$0, %eax
.L105:
	movzbl	112(%r8,%rax), %edx
	andl	$127, %edx
	movb	%dl, 137(%rdi,%rax)
	addq	$1, %rax
	cmpq	$4, %rax
	jne	.L105
	movzbl	116(%r8), %eax
	andl	$1, %eax
	movb	%al, 141(%rdi)
	movzbl	116(%r8), %eax
	shrb	%al
	andl	$7, %eax
	movb	%al, 142(%rdi)
	movzbl	116(%r8), %eax
	shrb	$4, %al
	andl	$7, %eax
	movb	%al, 143(%rdi)
	movzbl	117(%r8), %eax
	andl	$127, %eax
	movb	%al, 144(%rdi)
	movl	$0, %eax
.L106:
	movzbl	118(%r8,%rax), %edx
	andl	$127, %edx
	movb	%dl, 145(%rdi,%rax)
	addq	$1, %rax
	cmpq	$10, %rax
	jne	.L106
	call	fm6_sanitize
	ret
	.cfi_endproc
.LFE169:
	.size	fm6_unpack, .-fm6_unpack
	.type	fm6_pack, @function
fm6_pack:
.LFB170:
	.cfi_startproc
	movq	%rsi, %r8
	movq	%rdi, %r9
	movq	%rsi, %r10
	leaq	126(%rdi), %r11
.L114:
	movq	%r9, %rcx
	movq	%r10, %rsi
	movl	$0, %eax
.L113:
	movzbl	(%rcx,%rax), %edx
	andl	$127, %edx
	movb	%dl, (%rsi,%rax)
	addq	$1, %rax
	cmpq	$11, %rax
	jne	.L113
	movzbl	12(%rcx), %eax
	sall	$2, %eax
	andl	$12, %eax
	movzbl	11(%rcx), %edx
	andl	$3, %edx
	orl	%edx, %eax
	movb	%al, 11(%rsi)
	movzbl	20(%rcx), %eax
	sall	$3, %eax
	andl	$120, %eax
	movzbl	13(%rcx), %edx
	andl	$7, %edx
	orl	%edx, %eax
	movb	%al, 12(%rsi)
	movzbl	15(%rcx), %eax
	sall	$2, %eax
	andl	$28, %eax
	movzbl	14(%rcx), %edx
	andl	$3, %edx
	orl	%edx, %eax
	movb	%al, 13(%rsi)
	movzbl	16(%rcx), %eax
	andl	$127, %eax
	movb	%al, 14(%rsi)
	movzbl	18(%rcx), %eax
	addl	%eax, %eax
	andl	$62, %eax
	movzbl	17(%rcx), %edx
	andl	$1, %edx
	orl	%edx, %eax
	movb	%al, 15(%rsi)
	movzbl	19(%rcx), %eax
	andl	$127, %eax
	movb	%al, 16(%rsi)
	addq	$21, %r9
	addq	$17, %r10
	cmpq	%r11, %r9
	jne	.L114
	movl	$0, %eax
.L115:
	movzbl	126(%rdi,%rax), %edx
	andl	$127, %edx
	movb	%dl, 102(%r8,%rax)
	addq	$1, %rax
	cmpq	$9, %rax
	jne	.L115
	andb	$31, 110(%r8)
	movzbl	136(%rdi), %eax
	sall	$3, %eax
	andl	$8, %eax
	movzbl	135(%rdi), %edx
	andl	$7, %edx
	orl	%edx, %eax
	movb	%al, 111(%r8)
	movl	$0, %eax
.L116:
	movzbl	137(%rdi,%rax), %edx
	andl	$127, %edx
	movb	%dl, 112(%r8,%rax)
	addq	$1, %rax
	cmpq	$4, %rax
	jne	.L116
	movzbl	142(%rdi), %eax
	addl	%eax, %eax
	andl	$14, %eax
	movzbl	143(%rdi), %edx
	sall	$4, %edx
	andl	$112, %edx
	orl	%edx, %eax
	movzbl	141(%rdi), %edx
	andl	$1, %edx
	orl	%edx, %eax
	movb	%al, 116(%r8)
	movzbl	144(%rdi), %eax
	andl	$127, %eax
	movb	%al, 117(%r8)
	movl	$0, %eax
.L117:
	movzbl	145(%rdi,%rax), %edx
	andl	$127, %edx
	movb	%dl, 118(%r8,%rax)
	addq	$1, %rax
	cmpq	$10, %rax
	jne	.L117
	ret
	.cfi_endproc
.LFE170:
	.size	fm6_pack, .-fm6_pack
	.type	fm6_pack7, @function
fm6_pack7:
.LFB171:
	.cfi_startproc
	movl	$0, %r9d
	testl	%edx, %edx
	jne	.L124
	ret
.L130:
	addl	$8, %r9d
	addq	$7, %rdi
	addq	$8, %rsi
	cmpl	%edx, %r9d
	jnb	.L123
.L124:
	movl	$0, %ecx
.L126:
	movzbl	7(%rsi), %eax
	sarl	%cl, %eax
	sall	$7, %eax
	movzbl	(%rsi,%rcx), %r8d
	andl	$127, %r8d
	orl	%r8d, %eax
	movb	%al, (%rdi,%rcx)
	addq	$1, %rcx
	cmpq	$7, %rcx
	jne	.L126
	jmp	.L130
.L123:
	ret
	.cfi_endproc
.LFE171:
	.size	fm6_pack7, .-fm6_pack7
	.type	fm6_unpack7, @function
fm6_unpack7:
.LFB172:
	.cfi_startproc
	testl	%edx, %edx
	je	.L131
	movl	$0, %r8d
	jmp	.L134
.L137:
	addl	$8, %r8d
	addq	$8, %rdi
	addq	$7, %rsi
	cmpl	%edx, %r8d
	jnb	.L131
.L134:
	movb	$0, 7(%rdi)
	movl	$0, %ecx
.L133:
	movzbl	(%rsi,%rcx), %eax
	andl	$127, %eax
	movb	%al, (%rdi,%rcx)
	movzbl	(%rsi,%rcx), %eax
	shrb	$7, %al
	movzbl	%al, %eax
	sall	%cl, %eax
	orb	%al, 7(%rdi)
	addq	$1, %rcx
	cmpq	$7, %rcx
	jne	.L133
	jmp	.L137
.L131:
	ret
	.cfi_endproc
.LFE172:
	.size	fm6_unpack7, .-fm6_unpack7
	.type	fm6_note, @function
fm6_note:
.LFB189:
	.cfi_startproc
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	movl	%edi, %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %eax
	subl	%eax, %edi
	imulq	$196, %rdi, %rdi
	leaq	fm6_eff(%rip), %rax
	movzbl	144(%rax,%rdi), %edx
	movzbl	(%rsi), %eax
	leal	-24(%rdx,%rax), %eax
	movl	$127, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	ret
	.cfi_endproc
.LFE189:
	.size	fm6_note, .-fm6_note
	.type	fm6_keyed, @function
fm6_keyed:
.LFB191:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	movq	%rdi, %r14
	movl	%edx, %ebx
	movl	%edx, (%rsp)
	movzbl	347(%rdi), %eax
	movl	$127, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	shrl	%eax
	movl	%eax, %eax
	leaq	FM6_VELOCITY(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	subl	$239, %eax
	movl	%eax, 12(%rsp)
	movslq	%ebx, %rax
	imulq	$1431655766, %rax, %rax
	shrq	$32, %rax
	sarl	$31, %ebx
	subl	%ebx, %eax
	leal	-7(%rax), %ecx
	movl	$31, %eax
	cmpl	%eax, %ecx
	cmovle	%ecx, %eax
	movl	%eax, %ebx
	testl	%eax, %eax
	movl	$0, %eax
	cmovns	%ebx, %eax
	movl	%eax, 8(%rsp)
	movq	%rsi, %rbx
	movl	$0, %ebp
	jmp	.L142
.L140:
	movzbl	11(%rbx), %edx
	movzbl	9(%rbx), %esi
	movl	$1, %eax
	subl	%r15d, %eax
	movslq	%eax, %rdi
	imulq	$1431655766, %rdi, %rdi
	shrq	$32, %rdi
	sarl	$31, %eax
	subl	%eax, %edi
	call	fm6_curve
.L141:
	movzbl	15(%r13), %edx
	movl	12(%rsp), %esi
	imull	%esi, %edx
	addl	$7, %edx
	sarl	$3, %edx
	movl	4(%rsp), %ecx
	addl	%eax, %ecx
	movl	%ecx, %eax
	movl	$127, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	leal	(%rdx,%rax,2), %eax
	sall	$4, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movw	%ax, 288(%r14,%rbp,2)
	movzbl	13(%r13), %eax
	movl	8(%rsp), %ecx
	imull	%ecx, %eax
	sarl	$3, %eax
	movb	%al, 300(%r14,%rbp)
	movl	(%rsp), %esi
	movq	%r13, %rdi
	call	fm6_logfreq
	movl	%eax, 240(%r14,%rbp,4)
	addq	$1, %rbp
	addq	$21, %rbx
	cmpq	$6, %rbp
	je	.L145
.L142:
	movq	%rbx, %r13
	movzbl	8(%rbx), %eax
	movl	(%rsp), %r12d
	subl	%eax, %r12d
	leal	-17(%r12), %r15d
	movzbl	16(%rbx), %edi
	call	fm6_scaleout
	movl	%eax, 4(%rsp)
	testl	%r15d, %r15d
	js	.L140
	movzbl	12(%rbx), %edx
	movzbl	10(%rbx), %esi
	subl	$16, %r12d
	movslq	%r12d, %rdi
	imulq	$1431655766, %rdi, %rdi
	shrq	$32, %rdi
	sarl	$31, %r12d
	subl	%r12d, %edi
	call	fm6_curve
	jmp	.L141
.L145:
	addq	$16, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE191:
	.size	fm6_keyed, .-fm6_keyed
	.type	fm6_units, @function
fm6_units:
.LFB205:
	.cfi_startproc
	endbr64
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE205:
	.size	fm6_units, .-fm6_units
	.type	fm6_blob_read, @function
fm6_blob_read:
.LFB212:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$152, %rsp
	.cfi_def_cfa_offset 192
	movq	%fs:40, %rax
	movq	%rax, 136(%rsp)
	xorl	%eax, %eax
	testq	%rdi, %rdi
	je	.L153
	movq	%rsi, %rbx
	movq	%rdx, %rsi
	cmpb	$70, 112(%rdi)
	jne	.L147
	cmpb	$1, 113(%rdi)
	jne	.L147
	leaq	122(%rdi), %rax
	leaq	128(%rdi), %rdx
.L149:
	cmpb	$0, (%rax)
	jne	.L156
	addq	$1, %rax
	cmpq	%rdx, %rax
	jne	.L149
	movl	$0, %eax
	movl	$0, %r9d
.L150:
	movzbl	114(%rdi,%rax), %edx
	leal	0(,%rax,8), %ecx
	salq	%cl, %rdx
	orq	%rdx, %r9
	addq	$1, %rax
	cmpq	$8, %rax
	jne	.L150
	movl	$0, %edx
	movl	$0, %r8d
	leaq	FM6_FNBITS(%rip), %r12
	movl	$1, %ebp
	leaq	FM6_FNMAX(%rip), %r11
.L151:
	movzbl	(%r12,%rdx), %ecx
	movzbl	%cl, %r10d
	movl	%ebp, %eax
	sall	%cl, %eax
	subl	$1, %eax
	movq	%r9, %r14
	movl	%r8d, %ecx
	shrq	%cl, %r14
	andl	%r14d, %eax
	movb	%al, (%rsi,%rdx)
	addl	%r10d, %r8d
	cmpb	%al, (%r11,%rdx)
	jb	.L157
	addq	$1, %rdx
	cmpq	$16, %rdx
	jne	.L151
	movq	%rsp, %rbp
	movl	$128, %edx
	movq	%rdi, %rsi
	movq	%rbp, %rdi
	call	fm6_unpack7
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	fm6_unpack
	movl	$1, %eax
	jmp	.L147
.L153:
	movl	$0, %eax
.L147:
	movq	136(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L162
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L156:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L147
.L157:
	movl	$0, %eax
	jmp	.L147
.L162:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE212:
	.size	fm6_blob_read, .-fm6_blob_read
	.type	fm6_dref, @function
fm6_dref:
.LFB218:
	.cfi_startproc
	cmpl	$38, %edi
	ja	.L173
	cmpl	$3, %esi
	ja	.L173
	cmpl	$17, %edi
	jbe	.L178
	cmpl	$18, %edi
	je	.L179
	cmpl	$30, %edi
	jbe	.L180
	cmpl	$32, %edi
	jbe	.L181
	cmpl	$33, %edi
	je	.L182
	cmpl	$34, %edi
	je	.L183
	movl	%esi, %esi
	leal	-35(%rdi), %edx
	leaq	FC.27(%rip), %rax
	leaq	(%rax,%rdx,4), %rax
	movzbl	(%rax,%rsi), %eax
	movzbl	%al, %edx
	cmpb	$-1, %al
	je	.L176
	movl	%edx, %eax
	addl	$256, %eax
	cmpl	$254, %edx
	movl	$768, %edx
	cmove	%edx, %eax
	ret
.L178:
	movl	%edi, %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$34, %rax
	leal	(%rax,%rax,2), %edx
	addl	%edx, %edx
	subl	%edx, %edi
	imull	$-21, %edi, %edi
	movl	%esi, %esi
	leal	0(,%rax,4), %edx
	leaq	OPC.30(%rip), %rax
	addq	%rdx, %rax
	movzbl	(%rax,%rsi), %edx
	movzbl	%dl, %ecx
	leal	617(%rdi), %esi
	leal	105(%rdi,%rcx), %eax
	cmpb	$-1, %dl
	cmove	%esi, %eax
	ret
.L179:
	movl	%esi, %esi
	leaq	VC.29(%rip), %rax
	movzbl	(%rax,%rsi), %eax
	ret
.L180:
	subl	$19, %edi
	movl	%edi, %eax
	shrl	%eax
	imull	$-21, %eax, %eax
	leal	105(%rsi,%rax), %eax
	sall	$2, %edi
	andl	$4, %edi
	addl	%edi, %eax
	ret
.L181:
	cmpl	$31, %edi
	setne	%al
	movzbl	%al, %eax
	leal	126(%rsi,%rax,4), %eax
	ret
.L182:
	movl	%esi, %esi
	leaq	VC.29(%rip), %rax
	movzbl	4(%rax,%rsi), %eax
	ret
.L183:
	movl	%esi, %esi
	leaq	LC.28(%rip), %rax
	movzbl	(%rax,%rsi), %edx
	movzbl	%dl, %eax
	cmpb	$-1, %dl
	movl	$-1, %edx
	cmove	%edx, %eax
	ret
.L173:
	movl	$-1, %eax
	ret
.L176:
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE218:
	.size	fm6_dref, .-fm6_dref
	.type	fm6_dget, @function
fm6_dget:
.LFB219:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbx
	movl	%esi, %r12d
	movl	%edx, %ebp
	movl	%edx, %esi
	movl	%r12d, %edi
	call	fm6_dref
	movl	$0, %edx
	testl	%eax, %eax
	js	.L184
	leaq	trk(%rip), %rcx
	subq	%rcx, %rbx
	movq	%rbx, %rdx
	sarq	$5, %rdx
	movabsq	$5749634516480899205, %rcx
	imulq	%rcx, %rdx
	cmpl	$2, %edx
	ja	.L192
	cmpl	$767, %eax
	jg	.L193
	movl	%edx, %ecx
	imulq	$156, %rcx, %rcx
	leaq	fm6_patch(%rip), %rsi
	addq	%rsi, %rcx
	cmpl	$511, %eax
	jg	.L194
	cmpl	$255, %eax
	jg	.L195
	cltq
	movzbl	(%rcx,%rax), %edx
	jmp	.L184
.L192:
	movl	%ebp, %ebp
	movl	%r12d, %r12d
	salq	$5, %rbp
	movq	%r12, %rax
	salq	$4, %rax
	addq	%r12, %rax
	leaq	0(%rbp,%rax,8), %rax
	leaq	FM6_PAGES(%rip), %rdx
	movswl	22(%rdx,%rax), %edx
.L184:
	movl	%edx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L193:
	.cfi_restore_state
	movl	%edx, %edx
	salq	$4, %rdx
	leaq	fm6_fn(%rip), %rax
	movzbl	(%rax,%rdx), %edx
	jmp	.L184
.L194:
	cltq
	movzbl	-501(%rcx,%rax), %edx
	andl	$3, %edx
	movzbl	-500(%rcx,%rax), %eax
	andl	$3, %eax
	leal	(%rax,%rdx,4), %edx
	jmp	.L184
.L195:
	subl	$256, %eax
	cltq
	movl	%edx, %edx
	salq	$4, %rdx
	leaq	fm6_fn(%rip), %rcx
	addq	%rcx, %rdx
	movzbl	(%rdx,%rax), %edx
	jmp	.L184
	.cfi_endproc
.LFE219:
	.size	fm6_dget, .-fm6_dget
	.type	fm6_ddesc, @function
fm6_ddesc:
.LFB221:
	.cfi_startproc
	endbr64
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$5, %esi
	seta	%al
	cmpl	$1, %edx
	setne	%dl
	orb	%dl, %al
	jne	.L198
	cmpl	$2, %edi
	ja	.L198
	imull	$-21, %esi, %esi
	leal	122(%rsi), %edx
	movl	%edi, %edi
	imulq	$156, %rdi, %rdi
	leaq	fm6_patch(%rip), %rax
	addq	%rdi, %rax
	cmpb	$0, (%rax,%rdx)
	leaq	FIX.33(%rip), %rax
	movl	$0, %edx
	cmove	%rdx, %rax
	ret
.L198:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE221:
	.size	fm6_ddesc, .-fm6_ddesc
	.type	fm6_mod_dst, @function
fm6_mod_dst:
.LFB222:
	.cfi_startproc
	endbr64
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE222:
	.size	fm6_mod_dst, .-fm6_mod_dst
	.type	fm4_gone_note_on, @function
fm4_gone_note_on:
.LFB223:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE223:
	.size	fm4_gone_note_on, .-fm4_gone_note_on
	.type	fm4_gone_render, @function
fm4_gone_render:
.LFB224:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE224:
	.size	fm4_gone_render, .-fm4_gone_render
	.type	fm4_lg, @function
fm4_lg:
.LFB226:
	.cfi_startproc
	testl	%edi, %edi
	je	.L210
	movl	$0, %edx
.L205:
	movl	%edx, %esi
	addl	$1, %edx
	movl	%edi, %eax
	movl	%edx, %ecx
	shrl	%cl, %eax
	testl	%eax, %eax
	je	.L211
	cmpl	$31, %edx
	jne	.L205
.L206:
	leal	-8(%rdx), %ecx
	shrl	%cl, %edi
	movzbl	%dil, %edi
.L209:
	imull	$-89, %edi, %eax
	addl	$22784, %eax
	imull	%edi, %eax
	shrl	$16, %eax
	addl	%edi, %eax
	sall	$8, %edx
	addl	%edx, %eax
	ret
.L211:
	cmpl	$7, %esi
	jg	.L212
	movl	$8, %ecx
	subl	%esi, %ecx
	sall	%cl, %edi
	movzbl	%dil, %edi
	movl	%esi, %edx
	jmp	.L209
.L212:
	movl	%esi, %edx
	jmp	.L206
.L210:
	movl	$-100000, %eax
	ret
	.cfi_endproc
.LFE226:
	.size	fm4_lg, .-fm4_lg
	.type	fm4_ms, @function
fm4_ms:
.LFB227:
	.cfi_startproc
	testl	%edi, %edi
	je	.L215
	call	fm4_lg
	subl	$3840, %eax
	ret
.L215:
	movl	$-100000, %eax
	ret
	.cfi_endproc
.LFE227:
	.size	fm4_ms, .-fm4_ms
	.type	fm4_samples, @function
fm4_samples:
.LFB228:
	.cfi_startproc
	andl	$127, %edi
	leaq	TIME_MS_X10(%rip), %rax
	imull	$441, (%rax,%rdi,4), %eax
	imulq	$1374389535, %rax, %rax
	shrq	$37, %rax
	ret
	.cfi_endproc
.LFE228:
	.size	fm4_samples, .-fm4_samples
	.type	fm4_rate, @function
fm4_rate:
.LFB229:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	testl	%edi, %edi
	movl	$1, %eax
	cmovle	%eax, %edi
	call	fm4_lg
	movl	%eax, %r12d
	movl	$2147483647, %ebp
	movl	$0, %r15d
	movl	$0, %ebx
	movl	$22, %r14d
	movl	$1, %r13d
	jmp	.L219
.L218:
	addl	$1, %ebx
	cmpl	$100, %ebx
	je	.L223
.L219:
	leal	(%rbx,%rbx,4), %eax
	leal	(%rbx,%rax,8), %edx
	movl	%edx, %eax
	shrl	$8, %eax
	movl	%r14d, %ecx
	subl	%eax, %ecx
	movl	%r13d, %eax
	sall	%cl, %eax
	shrl	$6, %edx
	andl	$3, %edx
	leal	4(%rdx), %ecx
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %edi
	call	fm4_lg
	subl	%r12d, %eax
	movl	%eax, %edx
	negl	%edx
	cmovns	%edx, %eax
	cmpl	%ebp, %eax
	jge	.L218
	movl	%eax, %ebp
	movl	%ebx, %r15d
	jmp	.L218
.L223:
	movl	%r15d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE229:
	.size	fm4_rate, .-fm4_rate
	.type	fm4_fall, @function
fm4_fall:
.LFB230:
	.cfi_startproc
	testl	%esi, %esi
	jle	.L228
	imull	$111, %edi, %eax
	cltd
	idivl	%esi
	movl	%eax, %edi
	call	fm4_rate
.L224:
	ret
.L228:
	movl	$99, %eax
	cmpl	$-100000, %esi
	jne	.L224
	imull	$100, %edi, %eax
	movslq	%eax, %rdx
	imulq	$827945503, %rdx, %rdx
	sarq	$39, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %edi
	call	fm4_rate
	ret
	.cfi_endproc
.LFE230:
	.size	fm4_fall, .-fm4_fall
	.type	quad_range, @function
quad_range:
.LFB236:
	.cfi_startproc
	cmpl	$3, %edi
	je	.L234
	cmpl	$71, %edi
	je	.L234
	leaq	QUAD_MAP(%rip), %rcx
	movl	$0, %esi
	jmp	.L231
.L237:
	leaq	QUAD_PAGES(%rip), %rcx
	movl	%eax, %eax
	movl	%esi, %esi
	salq	$5, %rax
	movq	%rsi, %rdx
	salq	$4, %rdx
	leaq	(%rdx,%rsi), %rdi
	leaq	(%rax,%rdi,8), %rdi
	movzbl	18(%rcx,%rdi), %r8d
	leaq	(%rdx,%rsi), %rdi
	leaq	(%rax,%rdi,8), %rdi
	movzbl	20(%rcx,%rdi), %edi
	addq	%rsi, %rdx
	leaq	(%rax,%rdx,8), %rax
	movzbl	22(%rcx,%rax), %edx
.L230:
	movb	%r8b, -3(%rsp)
	movb	%dil, -2(%rsp)
	movzbl	%dl, %edx
	salq	$16, %rdx
	movzwl	-3(%rsp), %eax
	orl	%edx, %eax
	ret
.L238:
	addl	$1, %esi
	addq	$4, %rcx
	cmpl	$20, %esi
	je	.L235
.L231:
	movl	$0, %eax
.L233:
	movzbl	(%rcx,%rax), %edx
	cmpl	%edi, %edx
	je	.L237
	addq	$1, %rax
	cmpq	$4, %rax
	jne	.L233
	jmp	.L238
.L234:
	movl	$0, %r8d
	movl	$18, %edi
	movl	$3, %edx
	jmp	.L230
.L235:
	movl	$0, %r8d
	movl	$0, %edi
	movl	$0, %edx
	jmp	.L230
	.cfi_endproc
.LFE236:
	.size	quad_range, .-quad_range
	.type	quad_range_v2, @function
quad_range_v2:
.LFB237:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movl	%edi, %ebx
	call	quad_range
	movslq	%eax, %rdx
	movq	%rdx, %rcx
	shrq	$16, %rcx
	movb	%cl, 12(%rsp)
	movzbl	%ah, %eax
	cmpl	$23, %ebx
	je	.L242
	ja	.L241
	cmpl	$6, %ebx
	je	.L243
	cmpl	$7, %ebx
	movl	$-63, %ecx
	cmove	%ecx, %edx
.L240:
	movb	%dl, 10(%rsp)
	movb	%al, 11(%rsp)
	movzbl	12(%rsp), %edx
	salq	$16, %rdx
	movzwl	10(%rsp), %eax
	orl	%edx, %eax
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L241:
	.cfi_restore_state
	cmpl	$36, %ebx
	jne	.L251
	movl	$2, %eax
	jmp	.L240
.L251:
	subl	$47, %ebx
	cmpl	$23, %ebx
	ja	.L240
	andl	$7, %ebx
	je	.L246
	cmpl	$1, %ebx
	je	.L247
	cmpl	$2, %ebx
	je	.L248
	cmpl	$3, %ebx
	movl	$12, %ecx
	cmove	%ecx, %eax
	jmp	.L240
.L242:
	movl	$1, %eax
	jmp	.L240
.L243:
	movl	$127, %eax
	jmp	.L240
.L246:
	movl	$64, %eax
	jmp	.L240
.L247:
	movl	$11, %eax
	jmp	.L240
.L248:
	movl	$127, %eax
	movl	$0, %edx
	jmp	.L240
	.cfi_endproc
.LFE237:
	.size	quad_range_v2, .-quad_range_v2
	.type	quad_init_patch, @function
quad_init_patch:
.LFB239:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$16, %rsp
	.cfi_def_cfa_offset 40
	movq	%rdi, %rbp
	movl	$0, %ebx
.L253:
	movl	%ebx, %edi
	call	quad_range
	cltq
	shrq	$16, %rax
	movb	%al, 0(%rbp,%rbx)
	addq	$1, %rbx
	cmpq	$73, %rbx
	jne	.L253
	addq	$16, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE239:
	.size	quad_init_patch, .-quad_init_patch
	.type	quad_clampv, @function
quad_clampv:
.LFB240:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movl	%esi, %ebx
	call	quad_range
	movslq	%eax, %rdx
	movzbl	%ah, %eax
	movl	%edx, %ecx
	movsbl	%dl, %edx
	cmpl	%ebx, %edx
	jg	.L256
	movsbl	%al, %edx
	cmpl	%ebx, %edx
	movl	%ebx, %ecx
	cmovl	%eax, %ecx
.L256:
	movl	%ecx, %eax
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE240:
	.size	quad_clampv, .-quad_clampv
	.type	quad_pack, @function
quad_pack:
.LFB242:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %r13
	movq	%rsi, %r12
	movb	$81, (%rsi)
	movb	$3, 1(%rsi)
	movl	$0, %ebx
.L261:
	movsbl	0(%r13,%rbx), %esi
	movl	%ebx, %edi
	call	quad_clampv
	movl	%eax, %ebp
	movl	%ebx, %edi
	call	quad_range
	subl	%eax, %ebp
	movb	%bpl, 2(%r12,%rbx)
	addq	$1, %rbx
	cmpq	$73, %rbx
	jne	.L261
	movb	$0, 75(%r12)
	movb	$0, 76(%r12)
	movb	$0, 77(%r12)
	movb	$0, 78(%r12)
	movb	$0, 79(%r12)
	addq	$16, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE242:
	.size	quad_pack, .-quad_pack
	.type	quad_blob_ok, @function
quad_blob_ok:
.LFB243:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.L278
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	movq	%rdi, %rbx
	movl	$0, %eax
	cmpb	$81, (%rdi)
	jne	.L264
	movzbl	1(%rdi), %edx
	leal	-1(%rdx), %ecx
	cmpb	$2, %cl
	jbe	.L290
.L264:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L290:
	.cfi_restore_state
	movzbl	%dl, %r14d
	movl	$71, %r12d
	cmpb	$1, %dl
	je	.L266
	cmpl	$2, %r14d
	setne	%r12b
	movzbl	%r12b, %r12d
	addl	$72, %r12d
.L266:
	movl	%r12d, %r15d
	movl	$0, %ebp
	jmp	.L273
.L291:
	movl	%ebp, %edi
	call	quad_range
	cltq
	movb	%al, 13(%rsp)
	movzbl	%ah, %edx
	movb	%dl, 14(%rsp)
	shrq	$16, %rax
	movb	%al, 15(%rsp)
	movzbl	2(%rbx,%rbp), %eax
.L268:
	movsbl	14(%rsp), %edx
	movsbl	13(%rsp), %ecx
	subl	%ecx, %edx
	cmpl	%eax, %edx
	jb	.L276
	addq	$1, %rbp
	cmpq	%r15, %rbp
	jne	.L273
	addl	$2, %r12d
	movl	%r12d, %r12d
.L274:
	cmpb	$0, (%rbx,%r12)
	jne	.L283
	addq	$1, %r12
	cmpl	$79, %r12d
	jbe	.L274
	movl	$1, %eax
	jmp	.L264
.L278:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$0, %eax
	ret
.L283:
	.cfi_def_cfa_offset 72
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$0, %eax
	jmp	.L264
.L285:
	addq	$1, %rbp
.L273:
	cmpl	$3, %r14d
	je	.L291
	movl	%ebp, %edi
	call	quad_range_v2
	cltq
	movb	%al, 13(%rsp)
	movzbl	%ah, %ecx
	movb	%cl, 14(%rsp)
	shrq	$16, %rax
	movb	%al, 15(%rsp)
	movzbl	2(%rbx,%rbp), %eax
	cmpl	$1, %r14d
	jne	.L268
	cmpl	$3, %ebp
	jne	.L268
	cmpl	$113, %eax
	jbe	.L285
.L276:
	movl	$0, %eax
	jmp	.L264
	.cfi_endproc
.LFE243:
	.size	quad_blob_ok, .-quad_blob_ok
	.type	quad_rb_v1, @function
quad_rb_v1:
.LFB244:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %rbx
	movslq	%edi, %r11
	imulq	$1808407283, %r11, %r11
	sarq	$35, %r11
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %r11d
	movl	%r11d, %eax
	leal	(%r11,%r11,8), %edx
	leal	(%r11,%rdx,2), %edx
	subl	%edx, %edi
	movl	%edi, %r11d
	cltq
	leaq	QUAD_BR_Q16(%rip), %rdx
	movslq	(%rdx,%rax,4), %r10
	movslq	%edi, %rdx
	leaq	QUAD_RCB_Q16(%rip), %rax
	movslq	(%rax,%rdx,4), %rax
	imulq	%rax, %r10
	sarq	$16, %r10
	movl	%r10d, %r9d
	movl	$1, %edx
	movl	$0, %edi
	leaq	QUAD_RCB_Q16(%rip), %r8
.L294:
	movl	(%r8,%rdx,4), %eax
	subl	%r9d, %eax
	movl	%eax, %esi
	negl	%esi
	cmovs	%eax, %esi
	movslq	%edi, %rax
	movl	(%r8,%rax,4), %eax
	subl	%r9d, %eax
	movl	%eax, %ecx
	negl	%ecx
	cmovns	%ecx, %eax
	cmpl	%eax, %esi
	cmovl	%edx, %edi
	addq	$1, %rdx
	cmpq	$19, %rdx
	jne	.L294
	leaq	QUAD_RCB_Q16(%rip), %rcx
	movslq	%edi, %rax
	movsbl	11(%rbx), %edx
	subl	(%rcx,%rax,4), %r10d
	js	.L295
	imull	$100, %r10d, %r10d
	leal	32768(%r10), %eax
	sarl	$16, %eax
.L296:
	movb	%r11b, 3(%rbx)
	movb	%dil, 71(%rbx)
	addl	%edx, %eax
	movl	$100, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-100, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movb	%al, 11(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L295:
	.cfi_restore_state
	imull	$-100, %r10d, %eax
	addl	$32768, %eax
	sarl	$16, %eax
	negl	%eax
	jmp	.L296
	.cfi_endproc
.LFE244:
	.size	quad_rb_v1, .-quad_rb_v1
	.type	quad_macros_out, @function
quad_macros_out:
.LFB249:
	.cfi_startproc
	movq	%rdi, %rsi
	leaq	trk(%rip), %rax
	movq	%rdi, %rdx
	subq	%rax, %rdx
	sarq	$5, %rdx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdx
	movl	%edx, %ecx
	cmpl	$2, %edx
	ja	.L299
	movl	%edx, %edx
	salq	$4, %rdx
	leaq	quad_mlast(%rip), %rax
	addq	%rax, %rdx
	movl	$0, %eax
	leaq	QUAD_MAC(%rip), %r8
	movl	%ecx, %ecx
	leaq	(%rcx,%rcx,8), %rdi
	leaq	(%rcx,%rdi,8), %rcx
	leaq	quad_patch(%rip), %rdi
	addq	%rcx, %rdi
.L301:
	movzbl	(%r8,%rax), %ecx
	movsbw	(%rdi,%rcx), %cx
	movw	%cx, 166(%rsi,%rax,2)
	movw	%cx, (%rdx,%rax,2)
	addq	$1, %rax
	cmpq	$8, %rax
	jne	.L301
.L299:
	ret
	.cfi_endproc
.LFE249:
	.size	quad_macros_out, .-quad_macros_out
	.type	quad_xs, @function
quad_xs:
.LFB259:
	.cfi_startproc
	testl	%edi, %edi
	movl	$1821285621, %eax
	cmove	%eax, %edi
	movl	%edi, %eax
	sall	$13, %eax
	xorl	%edi, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	ret
	.cfi_endproc
.LFE259:
	.size	quad_xs, .-quad_xs
	.type	quad_exp2, @function
quad_exp2:
.LFB260:
	.cfi_startproc
	movl	%edi, %edx
	andl	$4095, %edx
	imull	$1407, %edx, %eax
	sarl	$12, %eax
	addl	$2689, %eax
	imull	%edx, %eax
	sarl	$12, %eax
	leal	32768(,%rax,8), %eax
	sarl	$12, %edi
	jns	.L311
	movl	%edi, %ecx
	negl	%ecx
	sarl	%cl, %eax
	cmpl	$-31, %edi
	movl	$0, %edx
	cmovle	%edx, %eax
	ret
.L311:
	movl	%edi, %ecx
	sall	%cl, %eax
	cmpl	$15, %edi
	movl	$1073741824, %edx
	cmovge	%edx, %eax
	ret
	.cfi_endproc
.LFE260:
	.size	quad_exp2, .-quad_exp2
	.type	quad_lfo_inc, @function
quad_lfo_inc:
.LFB261:
	.cfi_startproc
	movq	%rdi, %rdx
	leal	48(,%rsi,8), %esi
	movl	%esi, %eax
	movsbl	(%rdi,%rax), %edi
	movl	%edi, %ecx
	movl	$2863311531, %eax
	imulq	%rax, %rcx
	shrq	$36, %rcx
	leal	(%rcx,%rcx,2), %eax
	sall	$3, %eax
	subl	%eax, %edi
	movl	%edi, %ecx
	movl	$120, %eax
	cmpl	$11, %edi
	ja	.L313
	movswl	song(%rip), %eax
	movl	$300, %edi
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	movl	$20, %edi
	cmpl	%edi, %eax
	cmovl	%edi, %eax
.L313:
	leal	-1(%rsi), %esi
	movsbq	(%rdx,%rsi), %rdx
	movl	%ecx, %esi
	movl	$2863311531, %edi
	imulq	%rdi, %rsi
	shrq	$35, %rsi
	leal	(%rsi,%rsi,2), %esi
	sall	$2, %esi
	subl	%esi, %ecx
	movl	$1, %esi
	sall	%cl, %esi
	imulq	%rsi, %rdx
	cltq
	imulq	%rax, %rdx
	imulq	$6648596, %rdx, %rdx
	sarq	$16, %rdx
	movl	$2147483647, %eax
	cmpq	$2147483647, %rdx
	jg	.L312
	cmpq	$-2147483647, %rdx
	movl	$-2147483647, %eax
	cmovge	%edx, %eax
.L312:
	ret
	.cfi_endproc
.LFE261:
	.size	quad_lfo_inc, .-quad_lfo_inc
	.type	quad_env_tick, @function
quad_env_tick:
.LFB269:
	.cfi_startproc
	movl	%edx, %r10d
	movl	%esi, %eax
	movl	24(%rdi,%rax,4), %eax
	cmpl	$0, 24(%rsp)
	je	.L319
	cmpl	$0, 16(%rsp)
	jne	.L319
	movl	%esi, %edx
	movzbl	56(%rdi,%rdx), %edx
	subl	$1, %edx
	cmpb	$2, %dl
	jbe	.L320
	movl	%esi, %edx
	movzbl	56(%rdi,%rdx), %edx
.L328:
	cmpb	$2, %dl
	jbe	.L332
	cmpb	$3, %dl
	jne	.L333
	andl	$127, %ecx
	subl	%eax, %r8d
	movzwl	%r8w, %edx
	leaq	ENV_EXP(%rip), %r9
	movzwl	(%r9,%rcx,2), %ecx
	imull	%ecx, %edx
	shrl	$16, %edx
	sarl	$16, %r8d
	imull	%ecx, %r8d
	addl	%r8d, %edx
	addl	%edx, %eax
.L325:
	movl	%esi, %esi
	movl	%eax, 24(%rdi,%rsi,4)
	sarl	$9, %eax
	ret
.L319:
	movl	%esi, %edx
	movzbl	56(%rdi,%rdx), %edx
	cmpb	$2, %dl
	jne	.L328
	movl	%r10d, %edx
	andl	$127, %edx
	leaq	ENV_LIN(%rip), %rcx
	addl	(%rcx,%rdx,4), %eax
	cmpl	$16777215, %eax
	jle	.L325
	movl	%esi, %eax
	movb	$3, 56(%rdi,%rax)
	movl	$16777216, %eax
	jmp	.L325
.L332:
	cmpb	$1, %dl
	jne	.L334
	movl	8(%rsp), %r8d
	andl	$127, %r8d
	movl	%esi, %ecx
	addq	$8, %rcx
	movl	8(%rdi,%rcx,4), %edx
	leaq	ENV_LIN(%rip), %r9
	addl	(%r9,%r8,4), %edx
	movl	%edx, 8(%rdi,%rcx,4)
	cmpl	$16777215, %edx
	jbe	.L325
	movl	%esi, %edx
	movb	$2, 56(%rdi,%rdx)
	jmp	.L325
.L334:
	movl	$0, %eax
	jmp	.L325
.L333:
	subl	$4, %edx
	cmpb	$1, %dl
	ja	.L335
.L320:
	cmpl	$126, %r9d
	jle	.L327
	movl	%esi, %edx
	movb	$5, 56(%rdi,%rdx)
	jmp	.L325
.L327:
	movl	%esi, %edx
	movb	$4, 56(%rdi,%rdx)
	andl	$127, %r9d
	movzwl	%ax, %edx
	leaq	ENV_EXP(%rip), %rcx
	movzwl	(%rcx,%r9,2), %r8d
	imull	%r8d, %edx
	shrl	$16, %edx
	movl	%eax, %ecx
	sarl	$16, %ecx
	imull	%r8d, %ecx
	addl	%ecx, %edx
	subl	%edx, %eax
	cmpl	$4095, %eax
	jg	.L325
	movl	%esi, %eax
	movb	$0, 56(%rdi,%rax)
	movl	$0, %eax
	jmp	.L325
.L335:
	movl	$0, %eax
	jmp	.L325
	.cfi_endproc
.LFE269:
	.size	quad_env_tick, .-quad_env_tick
	.type	p5_env_tick, @function
p5_env_tick:
.LFB300:
	.cfi_startproc
	movl	%esi, %eax
	movq	24(%rsp), %rsi
	testl	%eax, %eax
	jne	.L337
	cmpb	$0, 4(%rdi)
	je	.L338
	movb	$3, 4(%rdi)
.L338:
	movl	%r9d, %r9d
	movzbl	(%rsi,%r9), %r9d
	sall	$24, %r9d
	movslq	%r9d, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%r9d, %eax
	sarl	$6, %eax
	sarl	$31, %r9d
	subl	%r9d, %eax
	cmpb	$0, 51(%rdx)
	jne	.L350
	movzbl	4(%rdi), %edx
	movl	$16, %r9d
	jmp	.L340
.L337:
	movl	%r9d, %r9d
	movzbl	(%rsi,%r9), %r9d
	sall	$24, %r9d
	movslq	%r9d, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%r9d, %eax
	sarl	$6, %eax
	sarl	$31, %r9d
	subl	%r9d, %eax
	movl	$16, %r9d
	cmpb	$0, 51(%rdx)
	je	.L339
.L350:
	movl	8(%rsp), %edx
	movzbl	(%rsi,%rdx), %r9d
.L339:
	movzbl	4(%rdi), %edx
	cmpb	$1, %dl
	je	.L356
.L340:
	cmpb	$1, %dl
	jbe	.L343
	cmpl	$0, 32(%rsp)
	jne	.L357
.L343:
	cmpb	$2, %dl
	je	.L358
	cmpb	$3, %dl
	je	.L359
.L342:
	movl	(%rdi), %eax
	sarl	$9, %eax
	ret
.L356:
	movl	%ecx, %ecx
	movzbl	(%rsi,%rcx), %edx
	leaq	P5_ENV_ATK(%rip), %rax
	movl	(%rax,%rdx,4), %ecx
	movl	%ecx, %edx
	sarl	$8, %edx
	imull	16(%rsp), %edx
	leal	127(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$7, %eax
	addl	%ecx, %eax
	addl	(%rdi), %eax
	cmpl	$16777215, %eax
	jg	.L341
	movl	%eax, (%rdi)
	jmp	.L342
.L341:
	movl	$16777216, (%rdi)
	movb	$2, 4(%rdi)
	jmp	.L342
.L357:
	cmpb	$2, %dl
	je	.L360
	movl	%r9d, %r9d
	leaq	P5_ENV_SSM(%rip), %rcx
	movl	(%rcx,%r9,4), %r8d
	movl	%r8d, %esi
	sarl	$8, %esi
	imull	16(%rsp), %esi
	leal	127(%rsi), %ecx
	testl	%esi, %esi
	cmovns	%esi, %ecx
	sarl	$7, %ecx
	addl	%r8d, %ecx
	movl	$16777216, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	testl	%ecx, %ecx
	movl	$1, %esi
	cmovle	%esi, %ecx
	cmpb	$3, %dl
	movl	$0, %esi
	cmove	%esi, %eax
.L345:
	movl	(%rdi), %esi
	cmpl	%eax, %esi
	jle	.L346
	subl	%ecx, %esi
	cmpl	%eax, %esi
	cmovge	%esi, %eax
.L347:
	movl	%eax, (%rdi)
	cmpl	$16383, %eax
	jg	.L342
	cmpb	$3, %dl
	jne	.L342
	movl	$0, (%rdi)
	movb	$0, 4(%rdi)
	jmp	.L342
.L360:
	movl	%r8d, %r8d
	movzbl	(%rsi,%r8), %esi
	leaq	P5_ENV_SSM(%rip), %rcx
	movl	(%rcx,%rsi,4), %r8d
	movl	%r8d, %esi
	sarl	$8, %esi
	imull	16(%rsp), %esi
	leal	127(%rsi), %ecx
	testl	%esi, %esi
	cmovns	%esi, %ecx
	sarl	$7, %ecx
	addl	%r8d, %ecx
	movl	$16777216, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	testl	%ecx, %ecx
	movl	$1, %esi
	cmovle	%esi, %ecx
	jmp	.L345
.L346:
	addl	%ecx, %esi
	cmpl	%eax, %esi
	cmovle	%esi, %eax
	jmp	.L347
.L358:
	movl	%r8d, %r8d
	movzbl	(%rsi,%r8), %ecx
	leaq	P5_ENV_EXP(%rip), %rdx
	movzwl	(%rdx,%rcx,2), %esi
	movl	%esi, %ecx
	sarl	$8, %ecx
	imull	16(%rsp), %ecx
	leal	127(%rcx), %edx
	testl	%ecx, %ecx
	cmovns	%ecx, %edx
	sarl	$7, %edx
	addl	%esi, %edx
	movl	$65535, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$1, %ecx
	cmovle	%ecx, %edx
	movl	(%rdi), %esi
	subl	%esi, %eax
	movzwl	%ax, %ecx
	imull	%edx, %ecx
	shrl	$16, %ecx
	sarl	$16, %eax
	imull	%edx, %eax
	addl	%ecx, %eax
	addl	%esi, %eax
	movl	%eax, (%rdi)
	jmp	.L342
.L359:
	movl	%r9d, %r9d
	leaq	P5_ENV_EXP(%rip), %rax
	movzwl	(%rax,%r9,2), %ecx
	movl	%ecx, %edx
	sarl	$8, %edx
	imull	16(%rsp), %edx
	leal	127(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$7, %eax
	addl	%ecx, %eax
	movl	$65535, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$1, %edx
	cmovle	%edx, %eax
	movl	(%rdi), %ecx
	movzwl	%cx, %edx
	imull	%eax, %edx
	shrl	$16, %edx
	movl	%ecx, %esi
	sarl	$16, %esi
	imull	%esi, %eax
	addl	%edx, %eax
	subl	%eax, %ecx
	cmpl	$16383, %ecx
	jle	.L349
	movl	%ecx, (%rdi)
	jmp	.L342
.L349:
	movl	$0, (%rdi)
	movb	$0, 4(%rdi)
	jmp	.L342
	.cfi_endproc
.LFE300:
	.size	p5_env_tick, .-p5_env_tick
	.type	p5_units, @function
p5_units:
.LFB329:
	.cfi_startproc
	endbr64
	movl	$3, %eax
	ret
	.cfi_endproc
.LFE329:
	.size	p5_units, .-p5_units
	.type	orbit_bridge_note, @function
orbit_bridge_note:
.LFB330:
	.cfi_startproc
	movzbl	voice_was(%rip), %eax
	testb	%al, %al
	jne	.L364
	movl	$0, 4(%rdi)
	movl	$0, (%rdi)
	movw	$0, 8(%rdi)
.L363:
	movb	%al, 10(%rdi)
	ret
.L364:
	movl	$1, %eax
	jmp	.L363
	.cfi_endproc
.LFE330:
	.size	orbit_bridge_note, .-orbit_bridge_note
	.type	orbit_bridge_apply, @function
orbit_bridge_apply:
.LFB331:
	.cfi_startproc
	movq	%rsi, %rax
	movl	%edx, %esi
	testl	%edx, %edx
	je	.L365
	leal	-1(%rdx), %edx
	movl	(%rax,%rdx,4), %r9d
	subl	%r8d, %r9d
	cmpb	$0, 10(%rdi)
	je	.L367
	addl	(%rdi), %ecx
	subl	(%rax), %ecx
	movl	%ecx, 4(%rdi)
	movw	$128, 8(%rdi)
	movb	$0, 10(%rdi)
.L367:
	movzwl	8(%rdi), %r8d
	cmpl	%esi, %r8d
	movl	%esi, %ecx
	cmovbe	%r8d, %ecx
	testl	%ecx, %ecx
	je	.L371
	movq	%rax, %rdx
	movl	%ecx, %ecx
	leaq	(%rax,%rcx,4), %rcx
.L369:
	movzwl	8(%rdi), %eax
	imull	4(%rdi), %eax
	sarl	$7, %eax
	addl	%eax, (%rdx)
	subw	$1, 8(%rdi)
	addq	$4, %rdx
	cmpq	%rcx, %rdx
	jne	.L369
.L368:
	cmpl	%esi, %r8d
	movl	$0, %edx
	cmovb	%edx, %eax
	addl	%r9d, %eax
	movl	%eax, (%rdi)
	cmpw	$0, 8(%rdi)
	jne	.L365
	movl	$0, 4(%rdi)
.L365:
	ret
.L371:
	movl	$0, %eax
	jmp	.L368
	.cfi_endproc
.LFE331:
	.size	orbit_bridge_apply, .-orbit_bridge_apply
	.type	cloud_pow2_q16, @function
cloud_pow2_q16:
.LFB332:
	.cfi_startproc
	leal	3072(%rdi), %esi
	movl	%esi, %edx
	movl	$2863311531, %eax
	imulq	%rax, %rdx
	shrq	$39, %rdx
	leal	(%rdx,%rdx,2), %ecx
	sall	$6, %ecx
	movl	%esi, %eax
	subl	%ecx, %eax
	addl	$1664, %eax
	imull	$21846, %eax, %edi
	shrl	$22, %edi
	leal	(%rdi,%rdi,2), %ecx
	sall	$6, %ecx
	subl	%ecx, %eax
	movl	$10, %ecx
	subl	%edi, %ecx
	leaq	PITCH_OCT(%rip), %rdi
	movl	(%rdi,%rax,4), %eax
	shrl	%cl, %eax
	shrl	%eax
	movl	%eax, %eax
	imulq	$1122523357, %rax, %rax
	shrq	$41, %rax
	cmpl	$3071, %esi
	jbe	.L375
	leal	-16(%rdx), %ecx
	sall	%cl, %eax
	ret
.L375:
	movl	$16, %ecx
	subl	%edx, %ecx
	shrl	%cl, %eax
	ret
	.cfi_endproc
.LFE332:
	.size	cloud_pow2_q16, .-cloud_pow2_q16
	.type	cloud_units, @function
cloud_units:
.LFB342:
	.cfi_startproc
	endbr64
	movl	$0, %edx
	cmpb	$19, 182+trk(%rip)
	je	.L380
.L378:
	movl	$3, %eax
	subl	%edx, %eax
	ret
.L380:
	leaq	trk(%rip), %rax
	cmpq	%rax, %rdi
	sete	%dl
	leaq	4928(%rax), %rax
	cmpq	%rax, %rdi
	sete	%al
	orl	%eax, %edx
	movzbl	%dl, %edx
	jmp	.L378
	.cfi_endproc
.LFE342:
	.size	cloud_units, .-cloud_units
	.type	cloud_saw, @function
cloud_saw:
.LFB344:
	.cfi_startproc
	movl	%esi, %esi
	salq	$8, %rsi
	leaq	novel_saw(%rip), %rax
	addq	%rax, %rsi
	movl	%edi, %eax
	shrl	$25, %eax
	movl	%eax, %edx
	movswl	(%rsi,%rdx,2), %edx
	addl	$1, %eax
	andl	$127, %eax
	movswl	(%rsi,%rax,2), %eax
	subl	%edx, %eax
	shrl	$10, %edi
	andl	$32767, %edi
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%edx, %eax
	ret
	.cfi_endproc
.LFE344:
	.size	cloud_saw, .-cloud_saw
	.type	cloud_pow2_fine, @function
cloud_pow2_fine:
.LFB345:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %eax
	movslq	%edi, %rbx
	imulq	$1374389535, %rbx, %rbx
	sarq	$35, %rbx
	cltd
	subl	%edx, %ebx
	leal	(%rbx,%rbx,4), %edx
	leal	(%rdx,%rdx,4), %edx
	subl	%edx, %eax
	movl	%eax, %r12d
	js	.L385
.L383:
	movl	%ebx, %edi
	call	cloud_pow2_q16
	movl	%eax, %ebp
	leal	1(%rbx), %edi
	call	cloud_pow2_q16
	subl	%ebp, %eax
	imull	%r12d, %eax
	imulq	$1374389535, %rax, %rax
	shrq	$35, %rax
	addl	%ebp, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L385:
	.cfi_restore_state
	addl	$25, %r12d
	subl	$1, %ebx
	jmp	.L383
	.cfi_endproc
.LFE345:
	.size	cloud_pow2_fine, .-cloud_pow2_fine
	.type	orbit_emit, @function
orbit_emit:
.LFB351:
	.cfi_startproc
	movl	%edx, %r8d
	movl	8(%rcx), %r9d
	movl	12(%rcx), %edx
	subl	%r9d, %edx
	imull	%esi, %edx
	movl	%esi, %esi
	movl	%edx, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%edx, %eax
	sarl	$5, %eax
	addl	%r9d, %eax
	imull	%r8d, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	addl	%eax, (%rdi,%rsi,4)
	ret
	.cfi_endproc
.LFE351:
	.size	orbit_emit, .-orbit_emit
	.type	cls_s16, @function
cls_s16:
.LFB354:
	.cfi_startproc
	movzwl	%di, %edx
	leal	-65536(%rdx), %eax
	testl	$32768, %edi
	cmove	%edx, %eax
	ret
	.cfi_endproc
.LFE354:
	.size	cls_s16, .-cls_s16
	.type	cls_asr, @function
cls_asr:
.LFB356:
	.cfi_startproc
	movl	%esi, %ecx
	testq	%rdi, %rdi
	js	.L391
	movq	%rdi, %rax
	shrq	%cl, %rax
	ret
.L391:
	notq	%rdi
	shrq	%cl, %rdi
	movq	%rdi, %rax
	notq	%rax
	ret
	.cfi_endproc
.LFE356:
	.size	cls_asr, .-cls_asr
	.type	cls_sat16, @function
cls_sat16:
.LFB357:
	.cfi_startproc
	movl	$32767, %eax
	cmpq	$32767, %rdi
	jg	.L393
	cmpq	$-32768, %rdi
	movl	$-32768, %eax
	cmovge	%edi, %eax
.L393:
	ret
	.cfi_endproc
.LFE357:
	.size	cls_sat16, .-cls_sat16
	.type	cls_mul, @function
cls_mul:
.LFB360:
	.cfi_startproc
	movswl	%di, %edi
	movswl	%si, %esi
	imull	%esi, %edi
	cmpl	$1073741824, %edi
	je	.L403
	addl	%edi, %edi
	js	.L404
.L398:
	movl	%edi, %eax
	shrl	$16, %eax
.L400:
	movzwl	%di, %edx
	cmpw	$-32768, %di
	ja	.L401
	cmpl	$32768, %edx
	jne	.L402
	testb	$1, %al
	je	.L402
.L401:
	addl	$1, %eax
.L402:
	movl	$32767, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	ret
.L403:
	movl	$2147483647, %edi
	jmp	.L398
.L404:
	movl	%edi, %eax
	shrl	$16, %eax
	orl	$-65536, %eax
	jmp	.L400
	.cfi_endproc
.LFE360:
	.size	cls_mul, .-cls_mul
	.type	cls_get32, @function
cls_get32:
.LFB361:
	.cfi_startproc
	movl	%esi, %esi
	addq	%rsi, %rdi
	movzbl	1(%rdi), %eax
	sall	$8, %eax
	movzbl	2(%rdi), %edx
	sall	$16, %edx
	orl	%edx, %eax
	movzbl	(%rdi), %edx
	orl	%edx, %eax
	movzbl	3(%rdi), %edx
	sall	$24, %edx
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE361:
	.size	cls_get32, .-cls_get32
	.type	cls_get16, @function
cls_get16:
.LFB362:
	.cfi_startproc
	movq	%rdi, %rax
	leal	1(%rsi), %edx
	movzbl	(%rdi,%rdx), %edi
	sall	$8, %edi
	movl	%esi, %esi
	movzbl	(%rax,%rsi), %eax
	orl	%eax, %edi
	call	cls_s16
	ret
	.cfi_endproc
.LFE362:
	.size	cls_get16, .-cls_get16
	.type	cls_put32, @function
cls_put32:
.LFB364:
	.cfi_startproc
	movl	%esi, %eax
	movb	%dl, (%rdi,%rax)
	leal	1(%rsi), %eax
	movzbl	%dh, %ecx
	movb	%cl, (%rdi,%rax)
	leal	2(%rsi), %eax
	movl	%edx, %ecx
	shrl	$16, %ecx
	movb	%cl, (%rdi,%rax)
	leal	3(%rsi), %eax
	shrl	$24, %edx
	movb	%dl, (%rdi,%rax)
	ret
	.cfi_endproc
.LFE364:
	.size	cls_put32, .-cls_put32
	.type	cls_index_for, @function
cls_index_for:
.LFB375:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebp
	movswl	%si, %esi
	movswl	%dx, %edi
	call	cls_mul
	movl	%eax, %ebx
	movl	%ebp, %edi
	shrl	$16, %edi
	call	cls_s16
	movswl	%bx, %ebx
	leal	(%rbx,%rax), %edi
	call	cls_s16
	movswq	%ax, %rdi
	movl	$3, %esi
	call	cls_asr
	addl	$4096, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE375:
	.size	cls_index_for, .-cls_index_for
	.type	novel_rand, @function
novel_rand:
.LFB385:
	.cfi_startproc
	movl	76(%rdi), %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, 76(%rdi)
	ret
	.cfi_endproc
.LFE385:
	.size	novel_rand, .-novel_rand
	.type	novel_emit, @function
novel_emit:
.LFB390:
	.cfi_startproc
	movl	%edx, %r8d
	movl	8(%rcx), %r9d
	movl	12(%rcx), %edx
	subl	%r9d, %edx
	imull	%esi, %edx
	movl	%esi, %esi
	movl	%edx, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%edx, %eax
	sarl	$5, %eax
	addl	%r9d, %eax
	imull	%r8d, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	addl	%eax, (%rdi,%rsi,4)
	ret
	.cfi_endproc
.LFE390:
	.size	novel_emit, .-novel_emit
	.type	terrain_slew, @function
terrain_slew:
.LFB393:
	.cfi_startproc
	subl	%edi, %esi
	testl	%esi, %esi
	jle	.L413
	leal	511(%rsi), %eax
	sarl	$9, %eax
.L414:
	addl	%edi, %eax
	ret
.L413:
	movl	$0, %eax
	jns	.L414
	movl	$511, %eax
	subl	%esi, %eax
	sarl	$9, %eax
	negl	%eax
	jmp	.L414
	.cfi_endproc
.LFE393:
	.size	terrain_slew, .-terrain_slew
	.type	vector_read, @function
vector_read:
.LFB405:
	.cfi_startproc
	movl	%edi, %edi
	leaq	(%rdi,%rdi,4), %rax
	movl	%esi, %esi
	addq	%rsi, %rax
	salq	$7, %rax
	leaq	vector_tables(%rip), %rcx
	addq	%rcx, %rax
	movl	%edx, %ecx
	shrl	$26, %ecx
	movl	%ecx, %esi
	movswl	(%rax,%rsi,2), %esi
	addl	$1, %ecx
	andl	$63, %ecx
	movswl	(%rax,%rcx,2), %eax
	subl	%esi, %eax
	shrl	$11, %edx
	andl	$32767, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%esi, %eax
	ret
	.cfi_endproc
.LFE405:
	.size	vector_read, .-vector_read
	.type	kv_get, @function
kv_get:
.LFB407:
	.cfi_startproc
	endbr64
	cmpl	$5, %esi
	ja	.L418
	cmpl	$3, %edx
	ja	.L418
	movl	%edx, %edx
	movl	%esi, %esi
	leaq	KV_IDS(%rip), %rax
	leaq	(%rax,%rsi,4), %rax
	movzbl	(%rax,%rdx), %eax
	movswl	(%rdi,%rax,2), %eax
	ret
.L418:
	leal	-6(%rsi), %eax
	cmpl	$3, %eax
	ja	.L420
	cmpl	$2, %edx
	jbe	.L421
.L420:
	movl	$0, %eax
	ret
.L421:
	leal	(%rsi,%rsi,2), %eax
	leal	31(%rdx,%rax), %eax
	movswl	(%rdi,%rax,2), %eax
	ret
	.cfi_endproc
.LFE407:
	.size	kv_get, .-kv_get
	.type	kv_set, @function
kv_set:
.LFB408:
	.cfi_startproc
	endbr64
	movl	%esi, %eax
	movl	%ecx, %esi
	cmpl	$9, %eax
	ja	.L422
	cmpl	$6, %eax
	setb	%cl
	movzbl	%cl, %ecx
	addl	$3, %ecx
	cmpl	%ecx, %edx
	jnb	.L422
	cmpb	$28, 184(%rdi)
	leaq	VECTOR_PAGES(%rip), %rcx
	leaq	TINES_PAGES(%rip), %r8
	cmove	%r8, %rcx
	movl	%eax, %r8d
	movq	%r8, %r9
	salq	$4, %r9
	addq	%r8, %r9
	movl	%edx, %r8d
	salq	$5, %r8
	leaq	(%r8,%r9,8), %r8
	addq	%r8, %rcx
	movswl	18(%rcx), %r8d
	movswl	20(%rcx), %ecx
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	cmpl	%esi, %r8d
	cmovle	%ecx, %r8d
	cmpl	$5, %eax
	ja	.L427
	movl	%edx, %edx
	movl	%eax, %eax
	leaq	KV_IDS(%rip), %rcx
	leaq	(%rcx,%rax,4), %rax
	movzbl	(%rax,%rdx), %eax
.L428:
	movl	%eax, %eax
	movw	%r8w, (%rdi,%rax,2)
.L422:
	ret
.L427:
	leal	(%rax,%rax,2), %eax
	leal	31(%rdx,%rax), %eax
	jmp	.L428
	.cfi_endproc
.LFE408:
	.size	kv_set, .-kv_set
	.type	kv_mod_dst, @function
kv_mod_dst:
.LFB410:
	.cfi_startproc
	endbr64
	cmpl	$255, %esi
	je	.L436
	cmpl	$1, %esi
	ja	.L435
	cmpl	$3, %edx
	ja	.L435
	leal	12(%rdx,%rsi,4), %eax
	ret
.L436:
	leal	-83(%rdx), %eax
	subl	$71, %edx
	cmpl	$8, %eax
	movl	$-1, %eax
	cmovb	%edx, %eax
	ret
.L435:
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE410:
	.size	kv_mod_dst, .-kv_mod_dst
	.type	fm6_post, @function
fm6_post:
.LFB209:
	.cfi_startproc
	endbr64
	movq	%rsi, %r9
	movl	%edx, %eax
	movl	%ecx, %r10d
	leaq	trk(%rip), %rdx
	subq	%rdx, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rdi
	movl	%edi, %r8d
	movl	$2863311531, %edx
	imulq	%rdx, %r8
	shrq	$33, %r8
	leal	(%r8,%r8,2), %edx
	movl	%edi, %r8d
	subl	%edx, %r8d
	movl	%r8d, %ecx
	imulq	$6884, %rcx, %rcx
	leaq	eng_state(%rip), %rdx
	addq	%rcx, %rdx
	movl	6876(%rdx), %esi
	movl	6880(%rdx), %edx
	testl	%r10d, %r10d
	je	.L438
	testl	%eax, %eax
	je	.L440
	movq	%r9, %rcx
	movl	%eax, %eax
	leaq	(%r9,%rax,4), %r9
.L442:
	movl	%esi, %edi
	movl	(%rcx), %esi
	movl	%esi, %eax
	subl	%edi, %eax
	sall	$8, %eax
	movslq	%edx, %rdx
	imulq	$1070673990, %rdx, %rdx
	sarq	$30, %rdx
	addl	%edx, %eax
	movl	%eax, %edx
	subl	$-128, %eax
	sarl	$8, %eax
	movl	%eax, (%rcx)
	addq	$4, %rcx
	cmpq	%r9, %rcx
	jne	.L442
.L440:
	movl	%r8d, %r8d
	imulq	$6884, %r8, %r8
	leaq	eng_state(%rip), %rax
	addq	%r8, %rax
	movl	%esi, 6876(%rax)
	movl	%edx, 6880(%rax)
	ret
.L438:
	movl	%r8d, %r8d
	imulq	$6884, %r8, %r8
	leaq	eng_state(%rip), %rax
	addq	%r8, %rax
	movl	$0, 6880(%rax)
	movl	$0, 6876(%rax)
	ret
	.cfi_endproc
.LFE209:
	.size	fm6_post, .-fm6_post
	.type	cloud_block, @function
cloud_block:
.LFB340:
	.cfi_startproc
	endbr64
	movq	%rdi, %rcx
	leaq	191(%rdi), %rax
	leaq	trk(%rip), %rsi
	movq	%rdi, %rdx
	subq	%rsi, %rdx
	sarq	$5, %rdx
	movabsq	$5749634516480899205, %rsi
	imulq	%rsi, %rdx
	movl	%edx, %esi
	movl	$2863311531, %edi
	imulq	%rdi, %rsi
	shrq	$33, %rsi
	leal	(%rsi,%rsi,2), %esi
	subl	%esi, %edx
	imulq	$6884, %rdx, %rdx
	leaq	eng_state(%rip), %rsi
	leaq	60(%rsi,%rdx), %rdx
	addq	$1535, %rcx
	jmp	.L446
.L449:
	movb	$0, -32(%rdx)
	movb	$0, (%rdx)
.L445:
	addq	$84, %rax
	addq	$80, %rdx
	cmpq	%rcx, %rax
	je	.L448
.L446:
	cmpb	$0, (%rax)
	jne	.L445
	jmp	.L449
.L448:
	ret
	.cfi_endproc
.LFE340:
	.size	cloud_block, .-cloud_block
	.type	va_range, @function
va_range:
.LFB422:
	.cfi_startproc
	movl	%edi, %eax
	cmpl	$23, %edi
	ja	.L451
	movl	%edi, %edx
	movl	$2863311531, %ecx
	imulq	%rcx, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,2), %ecx
	addl	%ecx, %ecx
	movl	%edi, %edx
	subl	%ecx, %edx
	cmpl	$5, %edx
	ja	.L452
	movl	%edx, %edx
	leaq	.L454(%rip), %rcx
	movslq	(%rcx,%rdx,4), %rdx
	addq	%rcx, %rdx
	notrack jmp	*%rdx
	.section	.rodata
	.align 4
	.align 4
.L454:
	.long	.L464-.L454
	.long	.L457-.L454
	.long	.L456-.L454
	.long	.L455-.L454
	.long	.L452-.L454
	.long	.L453-.L454
	.text
.L452:
	movl	$0, %edx
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L457:
	cmpl	$6, %edi
	sbbl	%edx, %edx
	andl	$100, %edx
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L456:
	movl	$0, %edx
	movl	$24, %eax
	movl	$-24, %ecx
	jmp	.L458
.L455:
	movl	$0, %edx
	movl	$63, %eax
	movl	$-64, %ecx
	jmp	.L458
.L453:
	movl	$1, %edx
	movl	$1, %eax
	movl	$0, %ecx
	jmp	.L458
.L451:
	leal	-24(%rdi), %edx
	cmpl	$1, %edx
	jbe	.L466
	cmpl	$31, %edi
	ja	.L459
	leal	-26(%rdi), %eax
	leaq	(%rax,%rax,2), %rax
	leaq	F.38(%rip), %rdx
	addq	%rax, %rdx
	movzbl	(%rdx), %ecx
	movzbl	1(%rdx), %eax
	movzbl	2(%rdx), %edx
	jmp	.L458
.L459:
	cmpl	$51, %edi
	ja	.L460
	leal	-32(%rdi), %edx
	movl	%edx, %ecx
	movl	$3435973837, %esi
	imulq	%rsi, %rcx
	shrq	$34, %rcx
	leal	(%rcx,%rcx,4), %esi
	movl	%edx, %ecx
	subl	%esi, %ecx
	movl	%ecx, %edx
	leaq	D.37(%rip), %rsi
	movzbl	(%rsi,%rdx), %edx
	cmpl	$36, %edi
	jbe	.L472
	cmpl	$3, %ecx
	je	.L467
.L472:
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L460:
	cmpl	$52, %edi
	je	.L468
	cmpl	$72, %edi
	ja	.L462
	subl	$53, %eax
	movl	%eax, %edx
	movl	$3435973837, %ecx
	imulq	%rcx, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,4), %edx
	subl	%edx, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	L.36(%rip), %rdx
	addq	%rax, %rdx
	movzbl	(%rdx), %ecx
	movzbl	1(%rdx), %eax
	movzbl	2(%rdx), %edx
	jmp	.L458
.L462:
	cmpl	$96, %edi
	ja	.L463
	subl	$73, %eax
	movl	%eax, %edx
	movl	$2863311531, %ecx
	imulq	%rcx, %rdx
	shrq	$33, %rdx
	leal	(%rdx,%rdx,2), %edx
	subl	%edx, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	M.35(%rip), %rdx
	addq	%rax, %rdx
	movzbl	(%rdx), %ecx
	movzbl	1(%rdx), %eax
	movzbl	2(%rdx), %edx
	jmp	.L458
.L463:
	cmpl	$97, %edi
	je	.L469
	leal	-99(%rdi), %edx
	cmpl	$3, %edx
	jbe	.L470
	movl	$0, %edx
	cmpl	$103, %edi
	movl	$0, %eax
	movl	$127, %ecx
	cmovne	%ecx, %eax
	movl	$0, %ecx
	jmp	.L458
.L464:
	movl	$0, %edx
	movl	$5, %eax
	movl	$0, %ecx
	jmp	.L458
.L466:
	movl	$0, %edx
	movl	$1, %eax
	movl	$0, %ecx
.L458:
	movb	%cl, -3(%rsp)
	movb	%al, -2(%rsp)
	movzbl	%dl, %edx
	salq	$16, %rdx
	movzwl	-3(%rsp), %eax
	orl	%edx, %eax
	ret
.L467:
	movl	$0, %edx
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L468:
	movl	$64, %edx
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L469:
	movl	$64, %edx
	movl	$127, %eax
	movl	$0, %ecx
	jmp	.L458
.L470:
	movl	$0, %edx
	movl	$2, %eax
	movl	$0, %ecx
	jmp	.L458
	.cfi_endproc
.LFE422:
	.size	va_range, .-va_range
	.type	va_init_patch, @function
va_init_patch:
.LFB424:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$16, %rsp
	.cfi_def_cfa_offset 40
	movq	%rdi, %rbp
	movl	$0, %ebx
.L474:
	movl	%ebx, %edi
	call	va_range
	cltq
	shrq	$16, %rax
	movb	%al, 0(%rbp,%rbx)
	addq	$1, %rbx
	cmpq	$106, %rbx
	jne	.L474
	addq	$16, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE424:
	.size	va_init_patch, .-va_init_patch
	.type	va_clampv, @function
va_clampv:
.LFB425:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movl	%esi, %ebx
	call	va_range
	movslq	%eax, %rdx
	movzbl	%ah, %eax
	movl	%edx, %ecx
	movsbl	%dl, %edx
	cmpl	%ebx, %edx
	jg	.L477
	movsbl	%al, %edx
	cmpl	%ebx, %edx
	movl	%ebx, %ecx
	cmovl	%eax, %ecx
.L477:
	movl	%ecx, %eax
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE425:
	.size	va_clampv, .-va_clampv
	.type	va_pack, @function
va_pack:
.LFB426:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %r13
	movq	%rsi, %r12
	movb	$86, (%rsi)
	movb	$3, 1(%rsi)
	movl	$0, %ebx
.L482:
	movsbl	0(%r13,%rbx), %esi
	movl	%ebx, %edi
	call	va_clampv
	movl	%eax, %ebp
	movl	%ebx, %edi
	call	va_range
	subl	%eax, %ebp
	movb	%bpl, 2(%r12,%rbx)
	addq	$1, %rbx
	cmpq	$106, %rbx
	jne	.L482
	movb	$0, 108(%r12)
	movb	$0, 109(%r12)
	addq	$16, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE426:
	.size	va_pack, .-va_pack
	.type	va_blob_ok, @function
va_blob_ok:
.LFB427:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.L498
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbp
	movl	$0, %eax
	cmpb	$86, (%rdi)
	jne	.L485
	movzbl	1(%rdi), %r13d
	leal	-1(%r13), %edx
	cmpb	$2, %dl
	ja	.L485
	cmpb	$1, %r13b
	movl	$99, %r15d
	movl	$106, %eax
	cmovne	%eax, %r15d
	movl	$104, %edx
	movl	$110, %eax
	cmove	%edx, %eax
	movl	%eax, 4(%rsp)
	movl	%r15d, %r14d
	movl	$0, %ebx
	jmp	.L493
.L507:
	movzbl	2(%rbp,%rbx), %eax
	movsbl	%dl, %edx
	movsbl	21(%rsp), %ecx
	subl	%ecx, %edx
	cmpl	%eax, %edx
	jb	.L496
	addq	$1, %rbx
	cmpq	%r14, %rbx
	je	.L514
.L493:
	movl	%ebx, %r12d
	movl	%ebx, %edi
	call	va_range
	cltq
	movb	%al, 21(%rsp)
	movzbl	%ah, %edx
	movb	%dl, 22(%rsp)
	shrq	$16, %rax
	movb	%al, 23(%rsp)
	cmpb	$2, %r13b
	setbe	%al
	cmpl	$26, %ebx
	jne	.L506
	testb	%al, %al
	jne	.L502
.L506:
	cmpl	$103, %r12d
	jne	.L507
	testb	%al, %al
	je	.L507
	movl	$127, %eax
	jmp	.L488
.L496:
	movl	$0, %eax
.L485:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L514:
	.cfi_restore_state
	leal	2(%r15), %eax
	movl	4(%rsp), %esi
	cmpl	%esi, %eax
	jnb	.L504
	movl	%eax, %eax
	addq	%rbp, %rax
	leaq	3(%rbp,%rbx), %rdx
	subl	$3, %esi
	movl	%esi, %ecx
	subl	%r15d, %ecx
	addq	%rcx, %rdx
.L494:
	cmpb	$0, (%rax)
	jne	.L505
	addq	$1, %rax
	cmpq	%rdx, %rax
	jne	.L494
	movl	$1, %eax
	jmp	.L485
.L498:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$0, %eax
	ret
.L504:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$1, %eax
	jmp	.L485
.L505:
	movl	$0, %eax
	jmp	.L485
.L502:
	movl	$3, %eax
.L488:
	movzbl	2(%rbp,%rbx), %edx
	movsbl	%al, %eax
	movsbl	21(%rsp), %ecx
	subl	%ecx, %eax
	cmpl	%edx, %eax
	jb	.L496
	addq	$1, %rbx
	jmp	.L493
	.cfi_endproc
.LFE427:
	.size	va_blob_ok, .-va_blob_ok
	.type	va_unpack, @function
va_unpack:
.LFB428:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %r12
	movq	%rsi, %r13
	movq	%rsi, %rdi
	call	va_init_patch
	movq	%r12, %rdi
	call	va_blob_ok
	testl	%eax, %eax
	je	.L515
	cmpb	$1, 1(%r12)
	movl	$106, %r14d
	movl	$99, %eax
	cmove	%eax, %r14d
	movl	%r14d, %r14d
	movl	$0, %ebx
.L518:
	movzbl	2(%r12,%rbx), %ebp
	movl	%ebx, %edi
	call	va_range
	cltq
	movb	%al, 13(%rsp)
	movzbl	%ah, %ecx
	movb	%cl, 14(%rsp)
	movq	%rax, %rdx
	shrq	$16, %rdx
	movb	%dl, 15(%rsp)
	addl	%eax, %ebp
	movb	%bpl, 0(%r13,%rbx)
	addq	$1, %rbx
	cmpq	%r14, %rbx
	jne	.L518
	movzbl	1(%r12), %edx
	movl	$1, %eax
	cmpb	$2, %dl
	ja	.L515
	movzbl	28(%r12), %eax
	sall	$5, %eax
	movl	$0, %ecx
	cmpb	$1, %dl
	je	.L519
	movzbl	105(%r12), %ecx
.L519:
	addl	%ecx, %eax
	andl	$127, %eax
	movb	%al, 26(%r13)
	movb	$0, 103(%r13)
	movl	$1, %eax
.L515:
	addq	$16, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE428:
	.size	va_unpack, .-va_unpack
	.type	va_macros_out, @function
va_macros_out:
.LFB429:
	.cfi_startproc
	movq	%rdi, %rsi
	leaq	trk(%rip), %rax
	movq	%rdi, %rdx
	subq	%rax, %rdx
	sarq	$5, %rdx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdx
	movl	%edx, %ecx
	cmpl	$2, %edx
	ja	.L525
	movl	%edx, %edx
	salq	$4, %rdx
	leaq	va_mlast(%rip), %rax
	addq	%rax, %rdx
	movl	$0, %eax
	leaq	VA_MACRO(%rip), %r8
	movl	%ecx, %ecx
	imulq	$106, %rcx, %rcx
	leaq	va_patch(%rip), %rdi
	addq	%rcx, %rdi
.L527:
	movzbl	(%r8,%rax), %ecx
	movsbw	(%rdi,%rcx), %cx
	movw	%cx, 166(%rsi,%rax,2)
	movw	%cx, (%rdx,%rax,2)
	addq	$1, %rax
	cmpq	$8, %rax
	jne	.L527
.L525:
	ret
	.cfi_endproc
.LFE429:
	.size	va_macros_out, .-va_macros_out
	.type	va_index, @function
va_index:
.LFB431:
	.cfi_startproc
	cmpl	$31, %esi
	ja	.L531
	cmpl	$3, %edx
	ja	.L531
	movl	%edx, %eax
	movl	%esi, %ecx
	leaq	VA_MAP(%rip), %r8
	leaq	(%r8,%rcx,4), %rcx
	movzbl	(%rcx,%rax), %eax
	cmpl	$255, %eax
	je	.L529
	cmpl	$7, %esi
	ja	.L529
	movl	%esi, %ecx
	andl	$1, %ecx
	orl	%edx, %ecx
	jne	.L529
	cmpl	$2, %edi
	ja	.L529
	shrl	%esi
	leal	99(%rsi), %ecx
	movl	%edi, %edi
	imulq	$106, %rdi, %rdi
	leaq	va_patch(%rip), %rdx
	addq	%rdi, %rdx
	cmpb	$1, (%rdx,%rcx)
	jne	.L529
	leal	(%rsi,%rsi,2), %eax
	leal	4(%rax,%rax), %eax
	ret
.L531:
	movl	$255, %eax
.L529:
	ret
	.cfi_endproc
.LFE431:
	.size	va_index, .-va_index
	.type	eng_ok, @function
eng_ok:
.LFB456:
	.cfi_startproc
	cmpl	$29, %edi
	ja	.L534
	cmpl	$17, %edi
	je	.L534
	movl	$-137383932, %eax
	movl	%edi, %ecx
	sarl	%cl, %eax
	andl	$1, %eax
	ret
.L534:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE456:
	.size	eng_ok, .-eng_ok
	.type	eng_rank, @function
eng_rank:
.LFB458:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	call	eng_ok
	testl	%eax, %eax
	movl	$12, %eax
	cmove	%eax, %ebx
	leaq	ENGINE_ORDER(%rip), %rdx
	movl	$0, %eax
.L537:
	movzbl	(%rdx), %ecx
	cmpl	%ebx, %ecx
	je	.L535
	addl	$1, %eax
	addq	$1, %rdx
	cmpl	$14, %eax
	jne	.L537
	movl	$0, %eax
.L535:
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE458:
	.size	eng_rank, .-eng_rank
	.type	param_desc_of, @function
param_desc_of:
.LFB462:
	.cfi_startproc
	cmpl	$22, %edi
	je	.L554
	cmpl	$37, %esi
	jne	.L546
	leaq	BASS_MONO_DESC(%rip), %rax
	cmpl	$18, %edi
	jne	.L546
.L543:
	ret
.L554:
	cmpl	$76, %esi
	je	.L550
	cmpl	$77, %esi
	je	.L551
	cmpl	$79, %esi
	je	.L552
	movl	$3, %eax
	cmpl	$74, %esi
	je	.L545
.L546:
	cmpl	$82, %esi
	jbe	.L549
	movl	%edi, %edi
	leal	-83(%rsi), %eax
	salq	$5, %rax
	leaq	ENGINES(%rip), %rdx
	movq	(%rdx,%rdi,8), %rdx
	leaq	24(%rdx,%rax), %rax
	ret
.L550:
	movl	$0, %eax
.L545:
	movl	%eax, %eax
	salq	$5, %rax
	leaq	CLOUD_EXTRA_DESC(%rip), %rdx
	addq	%rdx, %rax
	ret
.L551:
	movl	$1, %eax
	jmp	.L545
.L552:
	movl	$2, %eax
	jmp	.L545
.L549:
	movl	%esi, %esi
	salq	$5, %rsi
	leaq	TP(%rip), %rax
	addq	%rsi, %rax
	ret
	.cfi_endproc
.LFE462:
	.size	param_desc_of, .-param_desc_of
	.type	morph_rand, @function
morph_rand:
.LFB470:
	.cfi_startproc
	movl	6436+morph(%rip), %eax
	testl	%eax, %eax
	movl	$1821285621, %edx
	cmove	%edx, %eax
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, 6436+morph(%rip)
	ret
	.cfi_endproc
.LFE470:
	.size	morph_rand, .-morph_rand
	.type	morph_publish, @function
morph_publish:
.LFB472:
	.cfi_startproc
	movl	$0, %eax
	leaq	morph(%rip), %rsi
.L558:
	movzwl	166(%rdi,%rax,2), %ecx
	movl	%eax, %edx
	addq	$3128, %rdx
	movw	%cx, (%rsi,%rdx,2)
	addq	$1, %rax
	cmpq	$8, %rax
	jne	.L558
	movb	$1, 6272+morph(%rip)
	ret
	.cfi_endproc
.LFE472:
	.size	morph_publish, .-morph_publish
	.type	eng_audio, @function
eng_audio:
.LFB475:
	.cfi_startproc
	leaq	trk(%rip), %rax
	cmpq	%rax, %rdi
	je	.L569
.L561:
	movzbl	182(%rdi), %eax
	cmpl	$30, %eax
	movl	$0, %edx
	cmovnb	%edx, %eax
	movl	%eax, %eax
	leaq	ENGINES(%rip), %rdx
	movq	(%rdx,%rax,8), %rax
	ret
.L569:
	cmpb	$19, 182+trk(%rip)
	jne	.L561
	cmpb	$0, 6621+morph(%rip)
	jne	.L562
	cmpb	$0, 6620+morph(%rip)
	je	.L563
	cmpb	$19, 184+trk(%rip)
	je	.L563
.L562:
	movzwl	6592+morph(%rip), %eax
.L564:
	movl	%eax, %eax
	leaq	ENGINES(%rip), %rdx
	movq	(%rdx,%rax,8), %rax
	ret
.L563:
	movswl	166+trk(%rip), %eax
	cmpl	$11, %eax
	movl	$0, %edx
	cmovnb	%edx, %eax
	movl	%eax, %eax
	leaq	MORPH_SOURCE(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	jmp	.L564
	.cfi_endproc
.LFE475:
	.size	eng_audio, .-eng_audio
	.type	morph_has, @function
morph_has:
.LFB476:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.L575
	cmpb	$0, (%rdi)
	je	.L576
	movzbl	(%rsi), %r9d
	movl	$0, %r8d
	jmp	.L572
.L581:
	addl	$1, %r8d
	movl	%r8d, %eax
	cmpb	$0, (%rdi,%rax)
	je	.L578
.L572:
	testb	%r9b, %r9b
	je	.L580
	movl	%r9d, %edx
	movl	$0, %eax
.L574:
	leal	(%r8,%rax), %ecx
	cmpb	%dl, (%rdi,%rcx)
	jne	.L581
	addl	$1, %eax
	movl	%eax, %edx
	movzbl	(%rsi,%rdx), %edx
	testb	%dl, %dl
	jne	.L574
	movl	$1, %eax
	ret
.L580:
	movl	$1, %eax
	ret
.L575:
	movl	$0, %eax
	ret
.L576:
	movl	$0, %eax
	ret
.L578:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE476:
	.size	morph_has, .-morph_has
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"ALG"
.LC1:
	.string	"RATIO"
.LC2:
	.string	"WAV#"
.LC3:
	.string	"DCY"
	.text
	.type	morph_protected, @function
morph_protected:
.LFB477:
	.cfi_startproc
	movzbl	8(%rdi), %eax
	cmpb	$8, %al
	je	.L589
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	cmpb	$11, %al
	jne	.L592
	movl	$1, %eax
.L582:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L592:
	.cfi_restore_state
	movq	(%rdi), %rbp
	leaq	.LC0(%rip), %rsi
	movq	%rbp, %rdi
	call	morph_has
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L582
	leaq	.LC1(%rip), %rsi
	movq	%rbp, %rdi
	call	morph_has
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L582
	leaq	.LC2(%rip), %rsi
	movq	%rbp, %rdi
	call	morph_has
	testl	%eax, %eax
	jne	.L587
	cmpq	$0, 16(%rbx)
	je	.L582
	leaq	.LC3(%rip), %rsi
	movq	%rbp, %rdi
	call	morph_has
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	jmp	.L582
.L587:
	movl	$1, %eax
	jmp	.L582
.L589:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE477:
	.size	morph_protected, .-morph_protected
	.type	morph_add, @function
morph_add:
.LFB478:
	.cfi_startproc
	movzwl	6604+morph(%rip), %eax
	cmpl	%r8d, %r9d
	jle	.L598
	movl	%edi, %r10d
	movl	%esi, %edi
	movl	%edx, %esi
	cmpw	$159, %ax
	ja	.L598
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	leaq	morph(%rip), %rbx
	leal	1(%rax), %edx
	movw	%dx, 6604+morph(%rip)
	movzwl	%ax, %r11d
	leaq	(%r11,%r11), %rdx
	leaq	(%rdx,%r11), %rbp
	movb	$0, 20(%rbx,%rbp,8)
	movb	$0, 19(%rbx,%rbp,8)
	movb	%r10b, 16(%rbx,%rbp,8)
	movb	%dil, 17(%rbx,%rbp,8)
	movb	%sil, 18(%rbx,%rbp,8)
	cmpl	%ecx, %r9d
	movl	%ecx, %edx
	cmovle	%r9d, %edx
	cmpl	%ecx, %r8d
	cmovg	%r8d, %edx
	movw	%dx, 10(%rbx,%rbp,8)
	movw	%dx, 8(%rbx,%rbp,8)
	movw	%dx, 6(%rbx,%rbp,8)
	movw	%dx, 4(%rbx,%rbp,8)
	movswl	%dx, %edx
	sall	$8, %edx
	movl	%edx, (%rbx,%rbp,8)
	movw	%r8w, 12(%rbx,%rbp,8)
	movw	%r9w, 14(%rbx,%rbp,8)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L598:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE478:
	.size	morph_add, .-morph_add
	.type	morph_apply_position, @function
morph_apply_position:
.LFB486:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movl	%edi, %r9d
	movzwl	6606+morph(%rip), %eax
	sall	$15, %eax
	movslq	%eax, %rdx
	imulq	$-2130574327, %rdx, %rdx
	shrq	$32, %rdx
	addl	%edx, %eax
	sarl	$14, %eax
	movslq	%eax, %rcx
	movl	$49152, %edx
	subl	%eax, %edx
	addl	%edx, %edx
	movslq	%edx, %rdx
	imulq	%rcx, %rcx
	imulq	%rcx, %rdx
	sarq	$30, %rdx
	imull	$32512, %edx, %edx
	sarl	$15, %edx
	movzwl	6602+morph(%rip), %eax
	imull	%eax, %edx
	movzbl	6628+morph(%rip), %eax
	testl	%edi, %edi
	jne	.L602
	cmpl	$416153599, %edx
	setg	%bpl
	movzbl	%bpl, %ebp
.L603:
	movzwl	6604+morph(%rip), %esi
	testl	%esi, %esi
	je	.L604
	movl	$0, %eax
.L605:
	addl	$1, %eax
	cmpl	%esi, %eax
	jne	.L605
	movb	%bpl, 6628+morph(%rip)
	movl	$32768, 6588+morph(%rip)
	movl	$32768, 6584+morph(%rip)
	cmpb	$0, morph_dual(%rip)
	jne	.L601
	movslq	%edx, %r11
	imulq	$1374389535, %r11, %r11
	sarq	$45, %r11
	sarl	$31, %edx
	subl	%edx, %r11d
	movl	%r11d, %edx
	sall	$15, %edx
	movslq	%edx, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%edx, %eax
	sarl	$14, %eax
	sarl	$31, %edx
	subl	%edx, %eax
	movl	$32768, %edi
	subl	%eax, %edi
	imull	%eax, %edi
	sall	$2, %edi
	sarl	$15, %edi
	imull	%edi, %edi
	sarl	$15, %edi
	leal	(%rdi,%rdi,2), %edx
	sall	$10, %edx
	leal	32767(%rdx), %eax
	cmovns	%edx, %eax
	sarl	$15, %eax
	negl	%eax
	movl	%eax, -4(%rsp)
	movl	6452+morph(%rip), %r14d
	movl	%r14d, -8(%rsp)
	movl	6440+morph(%rip), %r10d
	leaq	morph(%rip), %rcx
	leal	-1(%rsi), %eax
	leaq	(%rax,%rax,2), %rdx
	leaq	24(%rcx), %rax
	leaq	(%rax,%rdx,8), %rbx
	movb	$0, -9(%rsp)
	movl	$32512, %r12d
	subl	%r11d, %r12d
	movl	$128, %r13d
	jmp	.L616
.L602:
	movl	$1, %ebp
	cmpl	$442367999, %edx
	jg	.L603
	movzbl	%al, %eax
	cmpl	$389964799, %edx
	movl	$0, %ebp
	cmovg	%eax, %ebp
	jmp	.L603
.L607:
	imull	%r12d, %r8d
	imull	%r11d, %eax
	addl	%eax, %r8d
	movslq	%r8d, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%r8d, %eax
	sarl	$6, %eax
	sarl	$31, %r8d
	subl	%r8d, %eax
	jmp	.L609
.L626:
	movl	%eax, %r15d
	imull	%edi, %r15d
	leal	131071(%r15), %r8d
	testl	%r15d, %r15d
	cmovns	%r15d, %r8d
	sarl	$17, %r8d
	subl	%r8d, %eax
	jmp	.L611
.L627:
	movl	-4(%rsp), %r15d
	addl	%r15d, %eax
	movl	$0, %r8d
	cmovs	%r8d, %eax
	jmp	.L611
.L612:
	movl	%eax, (%rsi)
	testl	%eax, %eax
	js	.L613
	leal	383(%rax), %edx
	subl	$-128, %eax
	cmovs	%edx, %eax
	sarl	$8, %eax
.L614:
	movswl	10(%rsi), %edx
	cmpl	%eax, %edx
	je	.L615
	movw	%ax, 10(%rsi)
	addl	$1, %r10d
	movb	$1, -9(%rsp)
.L615:
	addq	$24, %rcx
	cmpq	%rbx, %rcx
	je	.L625
.L616:
	movq	%rcx, %rsi
	movswl	6(%rcx), %r8d
	movswl	8(%rcx), %eax
	movzbl	19(%rcx), %edx
	testb	%dl, %dl
	je	.L607
	sall	$8, %eax
	sall	$8, %r8d
	testl	%ebp, %ebp
	cmove	%r8d, %eax
.L609:
	movzbl	20(%rsi), %r8d
	cmpb	$1, %r8b
	je	.L626
	cmpb	$2, %r8b
	je	.L627
.L611:
	testb	%dl, %dl
	jne	.L612
	cmpl	%r14d, %r9d
	jnb	.L612
	movl	(%rsi), %r8d
	subl	%r8d, %eax
	imull	%r9d, %eax
	cltd
	idivl	-8(%rsp)
	addl	%r8d, %eax
	jmp	.L612
.L613:
	movl	%r13d, %edx
	subl	%eax, %edx
	leal	255(%rdx), %eax
	cmovns	%edx, %eax
	sarl	$8, %eax
	negl	%eax
	jmp	.L614
.L625:
	cmpb	$0, -9(%rsp)
	je	.L617
	movl	%r10d, 6440+morph(%rip)
.L617:
	movl	6452+morph(%rip), %eax
	testl	%eax, %eax
	je	.L601
	movl	%eax, %edx
	subl	%r9d, %edx
	cmpl	%eax, %r9d
	movl	$0, %eax
	cmovb	%edx, %eax
	movl	%eax, 6452+morph(%rip)
.L601:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L604:
	.cfi_restore_state
	movb	%bpl, 6628+morph(%rip)
	movl	$32768, 6588+morph(%rip)
	movl	$32768, 6584+morph(%rip)
	cmpb	$0, morph_dual(%rip)
	je	.L617
	jmp	.L601
	.cfi_endproc
.LFE486:
	.size	morph_apply_position, .-morph_apply_position
	.type	morph_fm_key, @function
morph_fm_key:
.LFB490:
	.cfi_startproc
	movl	$0, %eax
	leaq	trk(%rip), %rdx
	cmpq	%rdi, %rdx
	je	.L634
.L628:
	ret
.L634:
	cmpb	$19, 182+trk(%rip)
	jne	.L628
	cmpb	$0, 6621+morph(%rip)
	je	.L628
	cmpw	$12, 6592+morph(%rip)
	jne	.L628
	movl	6440+morph(%rip), %eax
	addl	$1, %eax
	ret
	.cfi_endproc
.LFE490:
	.size	morph_fm_key, .-morph_fm_key
	.section	.rodata.str1.1
.LC4:
	.string	"Patch A"
.LC5:
	.string	"Patch B"
.LC6:
	.string	"-"
	.text
	.type	morph_desc, @function
morph_desc:
.LFB495:
	.cfi_startproc
	endbr64
	movl	%esi, %r8d
	cmpl	$1, %esi
	je	.L648
	movl	%esi, %eax
	salq	$5, %rax
	leaq	ENG_MORPH(%rip), %rdx
	leaq	24(%rdx,%rax), %rax
	cmpl	$8, %esi
	je	.L648
.L635:
	ret
.L648:
	movzbl	6272+morph(%rip), %eax
	testb	%al, %al
	je	.L638
	movzwl	6256+morph(%rip), %eax
	cwtl
.L639:
	cmpl	$11, %eax
	movl	$0, %edx
	cmovnb	%edx, %eax
	movl	%eax, %eax
	leaq	MORPH_SOURCE(%rip), %rdx
	movzbl	(%rdx,%rax), %edx
	leaq	ENGINES(%rip), %rax
	movq	(%rax,%rdx,8), %rcx
	movl	$0, %eax
	leaq	4208+morph(%rip), %rsi
	leaq	.LC6(%rip), %rdi
	jmp	.L644
.L638:
	movswl	166(%rdi), %eax
	jmp	.L639
.L641:
	movq	%rdi, (%rsi,%rax,8)
	addq	$1, %rax
	cmpq	$256, %rax
	je	.L649
.L644:
	movzbl	288(%rcx), %edx
	cmpl	%edx, %eax
	jnb	.L641
	movq	%rax, %rdx
	salq	$5, %rdx
	addq	280(%rcx), %rdx
	movq	(%rdx), %rdx
	movq	%rdx, (%rsi,%rax,8)
	addq	$1, %rax
	jmp	.L644
.L649:
	cmpl	$1, %r8d
	leaq	.LC5(%rip), %rdx
	leaq	.LC4(%rip), %rax
	cmove	%rax, %rdx
	movzbl	288(%rcx), %eax
	subl	$1, %eax
	movq	%rdx, d.42(%rip)
	movb	$8, 8+d.42(%rip)
	movw	$0, 10+d.42(%rip)
	movw	%ax, 12+d.42(%rip)
	movw	$0, 14+d.42(%rip)
	leaq	4208+morph(%rip), %rax
	movq	%rax, 16+d.42(%rip)
	movq	$0, 24+d.42(%rip)
	leaq	d.42(%rip), %rax
	ret
	.cfi_endproc
.LFE495:
	.size	morph_desc, .-morph_desc
	.type	morph_column, @function
morph_column:
.LFB496:
	.cfi_startproc
	testl	%edi, %edi
	sete	%dl
	cmpl	$2, %esi
	jne	.L658
	movl	$8, %eax
	testb	%dl, %dl
	jne	.L650
.L658:
	cmpl	$3, %esi
	sete	%cl
	testb	%dl, %dl
	je	.L659
	movl	$2, %eax
	testb	%cl, %cl
	jne	.L650
.L659:
	cmpl	$1, %edi
	jne	.L660
	movl	$3, %eax
	testb	%cl, %cl
	jne	.L650
.L660:
	leal	(%rsi,%rdi,4), %eax
.L650:
	ret
	.cfi_endproc
.LFE496:
	.size	morph_column, .-morph_column
	.type	morph_deep_set, @function
morph_deep_set:
.LFB498:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%ecx, %ebx
	leaq	trk(%rip), %rcx
	cmpq	%rdi, %rcx
	je	.L672
.L661:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L672:
	.cfi_restore_state
	movl	%esi, %edi
	cmpl	$1, %esi
	ja	.L661
	cmpl	$3, %edx
	ja	.L661
	movl	%edx, %esi
	call	morph_column
	movl	%eax, %ebp
	movl	%eax, %esi
	leaq	trk(%rip), %rdi
	call	morph_desc
	movswl	10(%rax), %edx
	movswl	12(%rax), %eax
	cmpl	%ebx, %eax
	cmovg	%ebx, %eax
	cmpl	%ebx, %edx
	cmovle	%eax, %edx
	cmpl	$8, %ebp
	je	.L673
	leal	83(%rbp), %eax
	leaq	trk(%rip), %rcx
	movw	%dx, (%rcx,%rax,2)
	cmpl	$2, %ebp
	jne	.L666
	movw	$0, 172+trk(%rip)
	jmp	.L669
.L673:
	movzwl	180+trk(%rip), %eax
	andw	$16128, %ax
	orl	%edx, %eax
	movw	%ax, 180+trk(%rip)
.L665:
	movb	$0, 6620+morph(%rip)
.L669:
	leaq	trk(%rip), %rdi
	call	morph_publish
	jmp	.L661
.L666:
	testl	%ebp, %ebp
	jne	.L668
	movw	$0, 168+trk(%rip)
	movw	$257, 180+trk(%rip)
	movb	$0, 6620+morph(%rip)
	jmp	.L669
.L668:
	cmpl	$1, %ebp
	je	.L665
	cmpl	$8, %ebp
	je	.L665
	jmp	.L669
	.cfi_endproc
.LFE498:
	.size	morph_deep_set, .-morph_deep_set
	.type	morph_deep_desc, @function
morph_deep_desc:
.LFB499:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movl	%esi, %edi
	movl	%edx, %esi
	call	morph_column
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	morph_desc
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE499:
	.size	morph_deep_desc, .-morph_deep_desc
	.type	morph_silent_note, @function
morph_silent_note:
.LFB500:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE500:
	.size	morph_silent_note, .-morph_silent_note
	.type	morph_silent_render, @function
morph_silent_render:
.LFB501:
	.cfi_startproc
	endbr64
	ret
	.cfi_endproc
.LFE501:
	.size	morph_silent_render, .-morph_silent_render
	.type	mod_tsrc, @function
mod_tsrc:
.LFB505:
	.cfi_startproc
	cmpl	$7, %esi
	ja	.L679
	movl	%esi, %esi
	leaq	.L681(%rip), %rcx
	movslq	(%rcx,%rsi,4), %rax
	addq	%rcx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L681:
	.long	.L679-.L681
	.long	.L688-.L681
	.long	.L686-.L681
	.long	.L685-.L681
	.long	.L684-.L681
	.long	.L683-.L681
	.long	.L682-.L681
	.long	.L680-.L681
	.text
.L686:
	movl	2452(%rdi), %eax
	ret
.L685:
	movzbl	2444(%rdi), %eax
	imull	$258, %eax, %eax
	ret
.L684:
	movzbl	2445(%rdi), %eax
	subl	$60, %eax
	sall	$9, %eax
	movl	$32767, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-32767, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	ret
.L683:
	movswl	2448(%rdi), %eax
	ret
.L682:
	movzbl	2441(%rdi), %eax
	imull	$258, %eax, %eax
	ret
.L680:
	movzbl	2442(%rdi), %eax
	imull	$258, %eax, %eax
	ret
.L679:
	movzbl	2443(%rdi), %edx
	movl	$127, %eax
	subl	%edx, %eax
	imull	$258, %eax, %eax
	ret
.L688:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE505:
	.size	mod_tsrc, .-mod_tsrc
	.type	mod_voice_add, @function
mod_voice_add:
.LFB507:
	.cfi_startproc
	movl	%edx, %eax
	cmpl	$1, %esi
	je	.L699
	cmpl	$2, %esi
	je	.L700
	cmpl	$3, %esi
	je	.L701
	leal	-4(%rdi), %edx
	cmpl	$1, %edx
	jbe	.L698
	cmpl	$1, %edi
	jne	.L694
.L698:
	addl	$32768, %eax
	sarl	%eax
.L694:
	testl	%ecx, %ecx
	jle	.L696
	movl	$32767, %edx
	movl	%edx, %esi
	subl	%eax, %esi
	imull	%esi, %ecx
	sarl	$6, %ecx
	movl	%edx, %eax
	subl	%ecx, %eax
.L697:
	movl	$32767, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movq	16(%rsp), %rdi
	imull	(%rdi), %eax
	sarl	$15, %eax
	movl	%eax, (%rdi)
	ret
.L699:
	imull	%edx, %ecx
	leal	(%rcx,%rcx,2), %eax
	sarl	$15, %eax
	addl	%eax, (%r8)
	ret
.L700:
	imull	%edx, %ecx
	sarl	$7, %ecx
	addl	%ecx, (%r9)
	ret
.L701:
	imull	%edx, %ecx
	sarl	$7, %ecx
	movq	8(%rsp), %rax
	addl	%ecx, (%rax)
	ret
.L696:
	negl	%ecx
	imull	%eax, %ecx
	sarl	$6, %ecx
	movl	$32767, %eax
	subl	%ecx, %eax
	jmp	.L697
	.cfi_endproc
.LFE507:
	.size	mod_voice_add, .-mod_voice_add
	.type	mod_begin, @function
mod_begin:
.LFB508:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %r12
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	movq	%rdi, %rbx
	subq	%rax, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rdx
	leaq	mod_tab(%rip), %rax
	movb	$0, (%rax,%rdx,4)
	leaq	98(%rdi), %rax
	movl	$0, %edx
	jmp	.L705
.L703:
	addl	$1, %edx
	addq	$6, %rax
	cmpl	$4, %edx
	je	.L731
.L705:
	cmpw	$0, (%rax)
	je	.L703
	cmpw	$0, 2(%rax)
	je	.L703
	cmpw	$0, 4(%rax)
	je	.L703
	movl	1540(%r12), %eax
	imull	1536(%r12), %eax
	sarl	$15, %eax
	movl	%eax, 20(%rsp)
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rcx
	leaq	mod_tab(%rip), %rax
	leaq	(%rax,%rcx,4), %rax
	movb	$1, (%rax)
	movb	$0, 1(%rax)
	movb	$0, 3(%rax)
	movb	$0, 2(%rax)
	movl	$0, 12(%rax)
	movl	$0, 8(%rax)
	movl	$0, 4(%rax)
	movl	$32767, 16(%rax)
	leal	(%rdx,%rdx,2), %eax
	leal	49(%rax), %edx
	leaq	(%r12,%rdx,2), %r14
	leal	51(%rax), %r15d
	leal	50(%rax), %eax
	subq	%rdx, %rax
	movq	%rax, 8(%rsp)
	movq	%r12, (%rsp)
	jmp	.L719
.L731:
	movl	$0, %eax
.L702:
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L732
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L709:
	.cfi_restore_state
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rax
	leaq	0(,%rax,4), %rdi
	movq	%rdi, 24(%rsp)
	movl	20(%rsp), %edx
	movl	%r12d, %esi
	movq	(%rsp), %rdi
	call	mod_tsrc
	movl	%eax, %edx
	leaq	mod_tab(%rip), %rcx
	movq	24(%rsp), %rdi
	leaq	16(%rcx,%rdi), %rax
	pushq	%rax
	.cfi_def_cfa_offset 136
	leaq	12(%rcx,%rdi), %rax
	pushq	%rax
	.cfi_def_cfa_offset 144
	leaq	8(%rcx,%rdi), %r9
	leaq	4(%rcx,%rdi), %r8
	movl	%r13d, %ecx
	movl	%ebp, %esi
	movl	%r12d, %edi
	call	mod_voice_add
	addq	$16, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L707
.L708:
	cmpl	$11, %ebp
	jbe	.L710
	addl	$71, %ebp
.L711:
	movq	(%rsp), %rdi
	call	eng_audio
	movq	%rax, %rdx
	leal	-83(%rbp), %eax
	salq	$5, %rax
	leaq	24(%rax,%rdx), %rax
	movq	%rax, 24(%rsp)
.L713:
	movl	20(%rsp), %edx
	movl	%r12d, %esi
	movq	(%rsp), %rdi
	call	mod_tsrc
	movl	%eax, %edi
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rdx
	leaq	mod_tab(%rip), %rax
	movzbl	3(%rax,%rdx,4), %r8d
	movzbl	%r8b, %esi
	testl	%esi, %esi
	je	.L725
	leaq	mod_tab(%rip), %rax
	leaq	(%rax,%rdx,4), %rdx
	movl	$0, %eax
.L715:
	movzbl	32(%rdx), %ecx
	cmpl	%ebp, %ecx
	je	.L716
	addl	$1, %eax
	addq	$1, %rdx
	cmpl	%esi, %eax
	jb	.L715
.L716:
	cmpl	%eax, %esi
	je	.L714
.L718:
	movl	%eax, %eax
	movq	24(%rsp), %rsi
	movswl	12(%rsi), %edx
	movswl	10(%rsi), %esi
	movl	%edx, %ecx
	subl	%esi, %ecx
	movl	%r13d, %edx
	imull	%edi, %edx
	sarl	$6, %edx
	imull	%ecx, %edx
	sarl	$15, %edx
	addl	%edx, 32(%rsp,%rax,4)
.L707:
	addq	$6, %r14
	addl	$3, %r15d
	cmpl	$63, %r15d
	je	.L733
.L719:
	movzwl	(%r14), %r12d
	movq	8(%rsp), %rax
	movzwl	(%r14,%rax,2), %ebp
	leal	-1(%rbp), %eax
	cmpw	$18, %ax
	ja	.L707
	leal	-1(%r12), %eax
	cmpw	$7, %ax
	ja	.L707
	movl	%r15d, %eax
	movq	(%rsp), %rdi
	movzwl	(%rdi,%rax,2), %eax
	movswl	%ax, %r13d
	testl	%r13d, %r13d
	je	.L707
	movswl	%r12w, %r12d
	movswl	%bp, %ebp
	cmpl	$4, %ebp
	ja	.L708
	leaq	mod_tab(%rip), %rdx
	leaq	(%rbx,%rbx,4), %rcx
	leaq	(%rbx,%rcx,2), %rcx
	sete	%sil
	orb	%sil, 1(%rdx,%rcx,4)
	leal	-2(%r12), %edx
	cmpl	$3, %edx
	ja	.L709
	leaq	mod_tab(%rip), %rdx
	leaq	(%rdx,%rcx,4), %rsi
	movzbl	2(%rsi), %ecx
	movzbl	%cl, %edx
	addq	%rsi, %rdx
	movb	%r12b, 20(%rdx)
	movb	%bpl, 24(%rdx)
	addl	$1, %ecx
	movb	%cl, 2(%rsi)
	movb	%al, 28(%rdx)
	jmp	.L707
.L710:
	movl	%ebp, %ebp
	leaq	ID.22(%rip), %rax
	movzbl	(%rax,%rbp), %eax
	movzbl	%al, %ebp
	cmpb	$82, %al
	ja	.L711
	movzbl	%al, %eax
	salq	$5, %rax
	leaq	TP(%rip), %rdx
	addq	%rdx, %rax
	movq	%rax, 24(%rsp)
	jmp	.L713
.L725:
	movl	%esi, %eax
	movl	$0, %r8d
.L714:
	leaq	mod_tab(%rip), %r9
	movl	%eax, %ecx
	leaq	(%rbx,%rbx,4), %rdx
	addq	%rdx, %rdx
	leaq	(%rdx,%rbx), %rsi
	leaq	(%r9,%rsi,4), %rsi
	movb	%bpl, 32(%rcx,%rsi)
	movl	%ebp, %ebp
	movq	(%rsp), %r11
	movzwl	(%r11,%rbp,2), %r10d
	addq	%rbx, %rdx
	leaq	16(%rcx,%rdx,2), %rdx
	movw	%r10w, 4(%r9,%rdx,2)
	movl	$0, 32(%rsp,%rcx,4)
	addl	$1, %r8d
	movb	%r8b, 3(%rsi)
	jmp	.L718
.L733:
	movq	(%rsp), %r12
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rdx
	leaq	mod_tab(%rip), %rax
	cmpb	$0, 3(%rax,%rdx,4)
	je	.L726
	leaq	mod_tab(%rip), %rax
	leaq	(%rax,%rdx,4), %r13
	movl	$0, %ebp
	leaq	TP(%rip), %r14
	movq	%r13, %r15
	jmp	.L723
.L720:
	movzbl	%al, %eax
	salq	$5, %rax
	addq	%r14, %rax
.L721:
	movswl	10(%rax), %ecx
	movswl	36(%r13,%rbp,2), %edx
	addl	32(%rsp,%rbp,4), %edx
	movswl	12(%rax), %eax
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	cmpl	%edx, %ecx
	cmovle	%eax, %ecx
	movl	%ebx, %ebx
	movw	%cx, (%r12,%rbx,2)
	addq	$1, %rbp
	movzbl	3(%r15), %eax
	cmpl	%eax, %ebp
	jnb	.L734
.L723:
	movzbl	32(%r13,%rbp), %eax
	movzbl	%al, %ebx
	cmpb	$82, %al
	jbe	.L720
	movq	%r12, %rdi
	call	eng_audio
	movq	%rax, %rdx
	leal	-83(%rbx), %eax
	salq	$5, %rax
	leaq	24(%rax,%rdx), %rax
	jmp	.L721
.L734:
	movl	$1, %eax
	jmp	.L702
.L726:
	movl	$1, %eax
	jmp	.L702
.L732:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE508:
	.size	mod_begin, .-mod_begin
	.type	mod_end, @function
mod_end:
.LFB509:
	.cfi_startproc
	movq	%rdi, %r9
	leaq	trk(%rip), %rax
	movq	%rdi, %rdx
	subq	%rax, %rdx
	sarq	$5, %rdx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdx
	leaq	(%rdx,%rdx,4), %rax
	leaq	(%rdx,%rax,2), %rcx
	leaq	mod_tab(%rip), %rax
	cmpb	$0, 3(%rax,%rcx,4)
	je	.L736
	leaq	mod_tab(%rip), %rax
	leaq	(%rax,%rcx,4), %rcx
	movl	$0, %eax
	movq	%rcx, %r8
.L737:
	movzwl	36(%rcx,%rax,2), %edi
	movzbl	32(%rcx,%rax), %esi
	movw	%di, (%r9,%rsi,2)
	addq	$1, %rax
	movzbl	3(%r8), %esi
	cmpl	%esi, %eax
	jb	.L737
.L736:
	leaq	(%rdx,%rdx,4), %rax
	leaq	(%rdx,%rax,2), %rdx
	leaq	mod_tab(%rip), %rax
	movb	$0, (%rax,%rdx,4)
	ret
	.cfi_endproc
.LFE509:
	.size	mod_end, .-mod_end
	.type	mod_midi, @function
mod_midi:
.LFB512:
	.cfi_startproc
	cmpl	$208, %esi
	je	.L751
	cmpl	$176, %esi
	je	.L752
.L739:
	ret
.L751:
	movb	%dl, 2442(%rdi)
	ret
.L752:
	cmpl	$11, %edx
	ja	.L742
	testl	%edx, %edx
	je	.L739
	cmpl	$11, %edx
	ja	.L739
	movl	%edx, %eax
	leaq	.L744(%rip), %rdx
	movslq	(%rdx,%rax,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L744:
	.long	.L739-.L744
	.long	.L748-.L744
	.long	.L747-.L744
	.long	.L739-.L744
	.long	.L746-.L744
	.long	.L745-.L744
	.long	.L739-.L744
	.long	.L739-.L744
	.long	.L739-.L744
	.long	.L739-.L744
	.long	.L739-.L744
	.long	.L743-.L744
	.text
.L742:
	cmpl	$65, %edx
	je	.L749
	cmpl	$121, %edx
	jne	.L753
	movb	$0, 2458(%rdi)
	movb	$0, 2456(%rdi)
	movb	$0, 2457(%rdi)
	movb	$0, 2443(%rdi)
	movb	$0, 2442(%rdi)
	movb	$0, 2441(%rdi)
	ret
.L753:
	ret
.L748:
	movb	%cl, 2441(%rdi)
	ret
.L743:
	movl	$127, %eax
	subl	%ecx, %eax
	movb	%al, 2443(%rdi)
	ret
.L747:
	movb	%cl, 2457(%rdi)
	ret
.L746:
	movb	%cl, 2456(%rdi)
	ret
.L749:
	cmpl	$63, %ecx
	seta	2458(%rdi)
	ret
.L745:
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movl	%ecx, %edx
	movl	$4, %esi
	imull	$1059797125, %edi, %edi
	call	fm6_fn_set
	ret
	.cfi_endproc
.LFE512:
	.size	mod_midi, .-mod_midi
	.type	trk_nvoice, @function
trk_nvoice:
.LFB517:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	eng_audio
	movq	416(%rax), %rdx
	testq	%rdx, %rdx
	je	.L755
	movq	%rbx, %rdi
	call	*%rdx
.L756:
	movl	$16, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	testl	%eax, %eax
	movl	$8, %eax
	cmovne	%edx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L755:
	.cfi_restore_state
	movzbl	293(%rax), %eax
	jmp	.L756
	.cfi_endproc
.LFE517:
	.size	trk_nvoice, .-trk_nvoice
	.type	trk_vmode, @function
trk_vmode:
.LFB518:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	eng_audio
	movl	$1, %edx
	cmpb	$0, 440(%rax)
	jne	.L760
	movl	$0, %edx
	cmpb	$0, 296(%rax)
	jne	.L760
	movswl	74(%rbx), %edx
.L760:
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE518:
	.size	trk_vmode, .-trk_vmode
	.type	voice_units, @function
voice_units:
.LFB519:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	eng_audio
	movq	432(%rax), %rax
	testq	%rax, %rax
	je	.L766
	movq	%rbx, %rdi
	call	*%rax
.L765:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L766:
	.cfi_restore_state
	movq	%rbx, %rdi
	call	trk_nvoice
	cmpl	$8, %eax
	setbe	%al
	movzbl	%al, %eax
	addl	$1, %eax
	jmp	.L765
	.cfi_endproc
.LFE519:
	.size	voice_units, .-voice_units
	.type	chord_cpu1_reserve, @function
chord_cpu1_reserve:
.LFB521:
	.cfi_startproc
	movl	$0, %eax
	cmpb	$1, cr_dbg(%rip)
	je	.L781
.L770:
	ret
.L781:
	movzbl	184+trk(%rip), %edx
	cmpb	$24, %dl
	ja	.L772
	movl	$25247744, %eax
	btq	%rdx, %rax
	jnc	.L774
.L773:
	cmpb	$21, %dl
	je	.L779
	movl	$2, %eax
	cmpb	$14, %dl
	setne	%dl
	movzbl	%dl, %edx
	addl	$2, %edx
.L775:
	imull	%edx, %eax
	ret
.L772:
	movl	$0, %eax
	cmpb	$29, %dl
	ja	.L770
.L774:
	movl	$0, %eax
	movl	$912261120, %ecx
	btq	%rdx, %rcx
	jc	.L773
	ret
.L779:
	movl	$3, %eax
	movl	$3, %edx
	jmp	.L775
	.cfi_endproc
.LFE521:
	.size	chord_cpu1_reserve, .-chord_cpu1_reserve
	.type	lowest_held, @function
lowest_held:
.LFB524:
	.cfi_startproc
	leaq	188(%rdi), %rax
	movl	$16, %esi
	movl	$0, %edx
	jmp	.L784
.L789:
	movl	%esi, %r8d
	leaq	(%r8,%r8,4), %r9
	leaq	(%r8,%r9,4), %r8
	movzbl	188(%rdi,%r8,4), %r10d
	cmpb	%r10b, (%rax)
	cmovb	%edx, %esi
.L783:
	addl	$1, %edx
	addq	$84, %rax
	cmpl	$16, %edx
	je	.L788
.L784:
	cmpb	$0, 3(%rax)
	je	.L783
	cmpb	$0, 2(%rax)
	je	.L783
	cmpl	$16, %esi
	jne	.L789
	movl	%edx, %esi
	jmp	.L783
.L788:
	movl	%esi, %eax
	ret
	.cfi_endproc
.LFE524:
	.size	lowest_held, .-lowest_held
	.type	voice_chord_replace, @function
voice_chord_replace:
.LFB525:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$29, %edi
	ja	.L790
	movl	%edi, %edi
	leaq	ENGINES(%rip), %rax
	movq	(%rax,%rdi,8), %rax
	cmpb	$1, 293(%rax)
	jbe	.L793
	cmpq	$0, 384(%rax)
	sete	%al
	movzbl	%al, %eax
	ret
.L793:
	movl	$0, %eax
.L790:
	ret
	.cfi_endproc
.LFE525:
	.size	voice_chord_replace, .-voice_chord_replace
	.type	voice_alloc_engine, @function
voice_alloc_engine:
.LFB526:
	.cfi_startproc
	leaq	trk(%rip), %rax
	cmpq	%rax, %rdi
	je	.L797
.L795:
	movzbl	182(%rdi), %eax
	ret
.L797:
	cmpb	$19, 182+trk(%rip)
	jne	.L795
	cmpb	$0, 6620+morph(%rip)
	je	.L795
	movzwl	6592+morph(%rip), %eax
	ret
	.cfi_endproc
.LFE526:
	.size	voice_alloc_engine, .-voice_alloc_engine
	.type	chord_degree_known, @function
chord_degree_known:
.LFB527:
	.cfi_startproc
	movq	voice_chord_rank(%rip), %rdx
	movl	$0, %eax
	testq	%rdx, %rdx
	je	.L802
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	*%rdx
	cmpl	$-1, %eax
	setne	%al
	movzbl	%al, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L802:
	ret
	.cfi_endproc
.LFE527:
	.size	chord_degree_known, .-chord_degree_known
	.type	chord_note_rank, @function
chord_note_rank:
.LFB528:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movl	%esi, %r13d
	movl	%edx, %ebp
	call	lowest_held
	movl	%eax, %r12d
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	cmpl	$16, %r12d
	je	.L809
	testl	%eax, %eax
	je	.L809
	movq	voice_chord_rank(%rip), %rdx
	movl	$4, %eax
	testq	%rdx, %rdx
	je	.L805
	movl	%r13d, %esi
	movq	%rbx, %rdi
	call	*%rdx
	cmpl	$-1, %eax
	jne	.L805
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	jne	.L811
	movl	%r12d, %r12d
	leaq	(%r12,%r12,4), %rax
	leaq	(%r12,%rax,4), %rax
	movzbl	188(%rbx,%rax,4), %ecx
	movl	$-85, %edx
	movl	%edx, %eax
	mulb	%cl
	shrw	$11, %ax
	leal	(%rax,%rax,2), %eax
	sall	$2, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movzbl	%dl, %edx
	movzbl	%cl, %ecx
	movl	$5, %eax
	cmpl	%r13d, %ecx
	jnb	.L805
	movl	%r13d, %esi
	movl	$2863311531, %ecx
	imulq	%rcx, %rsi
	shrq	$35, %rsi
	leal	(%rsi,%rsi,2), %eax
	sall	$2, %eax
	movl	%r13d, %esi
	subl	%eax, %esi
	leal	12(%rsi), %eax
	subl	%edx, %eax
	movl	%eax, %edx
	imulq	%rcx, %rdx
	shrq	$35, %rdx
	leal	(%rdx,%rdx,2), %edx
	sall	$2, %edx
	subl	%edx, %eax
	leal	-10(%rax), %edx
	movl	$0, %eax
	cmpl	$1, %edx
	jbe	.L805
	leaq	188(%rbx), %rcx
	movl	$0, %edx
	movl	$-85, %r8d
	jmp	.L808
.L807:
	addl	$1, %edx
	addq	$84, %rcx
	cmpl	$16, %edx
	je	.L817
.L808:
	cmpl	%edx, %ebp
	je	.L807
	cmpb	$0, 3(%rcx)
	je	.L807
	cmpb	$0, 2(%rcx)
	je	.L807
	cmpb	$4, 4(%rcx)
	je	.L807
	movzbl	(%rcx), %edi
	movl	%edi, %eax
	mulb	%r8b
	shrw	$11, %ax
	leal	(%rax,%rax,2), %eax
	sall	$2, %eax
	movl	%edi, %r9d
	subl	%eax, %r9d
	movzbl	%r9b, %eax
	cmpl	%esi, %eax
	jne	.L807
	movzbl	%dil, %edi
	cmpl	%r13d, %edi
	jnb	.L807
	movl	$1, %eax
	jmp	.L805
.L817:
	movl	$4, %eax
	jmp	.L805
.L809:
	movl	$4, %eax
.L805:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L811:
	.cfi_restore_state
	movl	$4, %eax
	jmp	.L805
	.cfi_endproc
.LFE528:
	.size	chord_note_rank, .-chord_note_rank
	.type	chord_rank, @function
chord_rank:
.LFB529:
	.cfi_startproc
	movl	%esi, %eax
	leaq	(%rax,%rax,4), %rcx
	leaq	(%rax,%rcx,4), %rcx
	movl	$4, %eax
	cmpb	$0, 190(%rdi,%rcx,4)
	jne	.L825
	ret
.L825:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	%esi, %edx
	movl	%esi, %eax
	leaq	(%rax,%rax,4), %rcx
	leaq	(%rax,%rcx,4), %rax
	movzbl	188(%rdi,%rax,4), %esi
	call	chord_note_rank
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE529:
	.size	chord_rank, .-chord_rank
	.type	voice_victim, @function
voice_victim:
.LFB530:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, 40(%rsp)
	movl	%esi, 32(%rsp)
	movq	%rdx, 24(%rsp)
	leaq	trk(%rip), %r12
	movl	$4, %r15d
	movl	$16, 20(%rsp)
	movl	$0, %r13d
	jmp	.L844
.L869:
	cmpl	$1, %r13d
	je	.L828
	cmpl	$2, %r13d
	je	.L865
	leaq	trk(%rip), %rdx
	movq	40(%rsp), %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movl	%eax, %edx
	cmpl	$1, %eax
	je	.L866
.L848:
	cmpl	$2, %edx
	jne	.L827
	movl	$0, %edx
.L846:
	movl	$0, %eax
	cmpb	$0, morph_dual(%rip)
	jne	.L847
.L833:
	cmpl	%edx, %eax
	je	.L827
	jmp	.L834
.L865:
	cmpb	$0, morph_dual(%rip)
	je	.L830
	movzbl	182+trk(%rip), %edx
	leaq	trk(%rip), %rcx
	movq	40(%rsp), %rax
	subq	%rcx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rcx
	imulq	%rcx, %rax
	cmpl	$1, %eax
	je	.L867
	cmpb	$19, %dl
	sete	%dl
	movzbl	%dl, %edx
	cmpl	$2, %eax
	jne	.L868
.L847:
	cmpb	$19, 182+trk(%rip)
	sete	%al
	movzbl	%al, %eax
	jmp	.L833
.L835:
	cmpl	$0, 32(%rsp)
	je	.L859
	movq	40(%rsp), %rsi
	cmpq	%rsi, 8(%rsp)
	jne	.L859
.L834:
	addl	$1, %r13d
	cmpl	$3, %r13d
	je	.L826
	addq	$2464, %r12
.L844:
	movq	%r12, 8(%rsp)
	movq	%r12, %rdi
	call	trk_vmode
	movl	%eax, %r14d
	cmpb	$1, cr_dbg(%rip)
	je	.L869
.L827:
	movl	$16, 36(%rsp)
	testl	%r14d, %r14d
	jne	.L835
	movq	8(%rsp), %rdi
	call	lowest_held
	movl	%eax, 36(%rsp)
	jmp	.L835
.L859:
	leaq	188(%r12), %rbx
	movl	$0, %ebp
	movl	%r13d, 56(%rsp)
	movq	%r12, 48(%rsp)
	jmp	.L842
.L853:
	movl	$1, %r12d
.L838:
	cmpl	%r15d, %r12d
	jb	.L840
	jne	.L837
	cmpl	$16, 20(%rsp)
	je	.L840
	cmpl	$3, %r12d
	je	.L870
.L841:
	movl	20(%rsp), %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	salq	$2, %rax
	movq	24(%rsp), %rsi
	addq	(%rsi), %rax
	movl	264(%rax), %eax
	cmpl	%eax, 76(%r13)
	jnb	.L837
.L840:
	movq	24(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	%rcx, (%rax)
	movl	%r12d, %r15d
	movl	%ebp, 20(%rsp)
.L837:
	addl	$1, %ebp
	addq	$84, %rbx
	cmpl	$16, %ebp
	je	.L871
.L842:
	movq	%rbx, %r13
	cmpb	$0, 3(%rbx)
	je	.L837
	cmpb	$4, 4(%rbx)
	je	.L837
	cmpb	$0, 2(%rbx)
	je	.L853
	testl	%r14d, %r14d
	je	.L860
	movl	$2, %r12d
	testl	%ebp, %ebp
	jne	.L838
.L860:
	movl	32(%rsp), %eax
	orl	%r14d, %eax
	jne	.L837
	movl	$3, %r12d
	cmpl	%ebp, 36(%rsp)
	jne	.L838
	movq	8(%rsp), %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	jne	.L838
	movzbl	0(%r13), %esi
	movq	8(%rsp), %rdi
	call	chord_degree_known
	testl	%eax, %eax
	jne	.L838
	jmp	.L837
.L870:
	movq	24(%rsp), %rax
	movq	8(%rsp), %rdi
	cmpq	%rdi, (%rax)
	jne	.L841
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	je	.L841
	movl	%ebp, %esi
	movq	8(%rsp), %rdi
	call	chord_rank
	movl	%eax, 60(%rsp)
	movl	20(%rsp), %esi
	movq	8(%rsp), %rdi
	call	chord_rank
	cmpl	%eax, 60(%rsp)
	jb	.L840
	movq	24(%rsp), %rdx
	movq	8(%rsp), %rax
	cmpq	%rax, (%rdx)
	jne	.L841
	movq	%rax, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	je	.L841
	movl	%ebp, %esi
	movq	8(%rsp), %rdi
	call	chord_rank
	movl	%eax, 60(%rsp)
	movl	20(%rsp), %esi
	movq	8(%rsp), %rdi
	call	chord_rank
	cmpl	%eax, 60(%rsp)
	jne	.L837
	jmp	.L841
.L871:
	movl	56(%rsp), %r13d
	movq	48(%rsp), %r12
	jmp	.L834
.L828:
	leaq	trk(%rip), %rdx
	movq	40(%rsp), %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	cmpl	$1, %eax
	je	.L827
	cmpl	$2, %eax
	jne	.L834
	movl	$1, %edx
	jmp	.L846
.L867:
	cmpb	$19, %dl
	je	.L827
	jmp	.L826
.L868:
	movl	$0, %eax
	jmp	.L833
.L830:
	leaq	trk(%rip), %rdx
	movq	40(%rsp), %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movl	%eax, %edx
	cmpl	$1, %eax
	jne	.L848
.L826:
	movl	20(%rsp), %eax
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L866:
	.cfi_restore_state
	addl	$1, %r13d
	addq	$2464, %r12
	jmp	.L844
	.cfi_endproc
.LFE530:
	.size	voice_victim, .-voice_victim
	.type	voice_kill, @function
voice_kill:
.LFB531:
	.cfi_startproc
	movb	$0, 2(%rdi)
	movb	$4, 4(%rdi)
	addl	$1, voice_kills(%rip)
	ret
	.cfi_endproc
.LFE531:
	.size	voice_kill, .-voice_kill
	.type	vsq_push, @function
vsq_push:
.LFB534:
	.cfi_startproc
	movl	%esi, %r8d
	movl	%edx, %r9d
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	movl	$0, %eax
	cmpl	$2, %edi
	ja	.L873
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rax
	leaq	vsq(%rip), %rdx
	movzbl	24(%rdx,%rax), %r10d
	movzbl	%r10b, %esi
	testb	%r10b, %r10b
	je	.L875
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rcx
	addq	%rdx, %rcx
	movl	$0, %eax
.L877:
	movzbl	(%rcx,%rax), %edx
	cmpl	%r8d, %edx
	je	.L881
	addq	$1, %rax
	cmpl	%esi, %eax
	jb	.L877
	movl	$0, %eax
	cmpb	$7, %r10b
	ja	.L873
.L875:
	movzbl	%r10b, %eax
	movl	%edi, %edi
	leaq	(%rdi,%rdi,4), %rdx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	vsq(%rip), %rdx
	addq	%rcx, %rdx
	addq	%rdx, %rax
	movb	%r8b, (%rax)
	movb	$0, 16(%rax)
	addl	$1, %r10d
	movb	%r10b, 24(%rdx)
	movb	%r9b, 8(%rax)
	movl	$1, %eax
.L873:
	ret
.L881:
	movl	%eax, %eax
	movl	%edi, %edi
	leaq	(%rdi,%rdi,4), %rdx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	vsq(%rip), %rdx
	addq	%rcx, %rdx
	movb	%r9b, 8(%rax,%rdx)
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE534:
	.size	vsq_push, .-vsq_push
	.type	vsq_drop, @function
vsq_drop:
.LFB535:
	.cfi_startproc
	movl	%esi, %r8d
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	ja	.L882
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rax
	leaq	vsq(%rip), %rcx
	movzbl	24(%rcx,%rax), %eax
	movzbl	%al, %r9d
	testb	%al, %al
	je	.L887
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rsi
	movq	%rcx, %rax
	addq	%rsi, %rax
	leaq	1(%rcx), %rcx
	addq	%rsi, %rcx
	leal	-1(%r9), %esi
	addq	%rsi, %rcx
	movl	$0, %r9d
	movq	%rax, %r10
	jmp	.L886
.L889:
	movl	%r9d, %edx
	addq	%r10, %rdx
	movb	%sil, (%rdx)
	movzbl	16(%rax), %esi
	movb	%sil, 16(%rdx)
	movzbl	8(%rax), %esi
	movb	%sil, 8(%rdx)
	leal	1(%r9), %r9d
.L885:
	addq	$1, %rax
	cmpq	%rcx, %rax
	je	.L884
.L886:
	cmpl	$127, %r8d
	ja	.L885
	movzbl	(%rax), %esi
	movzbl	%sil, %edx
	cmpl	%r8d, %edx
	jne	.L889
	jmp	.L885
.L887:
	movl	$0, %r9d
.L884:
	movl	%edi, %edi
	leaq	(%rdi,%rdi,4), %rax
	leaq	(%rax,%rax,4), %rax
	leaq	vsq(%rip), %rdx
	movb	%r9b, 24(%rdx,%rax)
.L882:
	ret
	.cfi_endproc
.LFE535:
	.size	vsq_drop, .-vsq_drop
	.type	glide_set, @function
glide_set:
.LFB537:
	.cfi_startproc
	movq	%rsi, %rcx
	testl	%edx, %edx
	je	.L891
	movl	20(%rsi), %edx
	testl	%edx, %edx
	je	.L891
	movl	$0, %eax
	cmpw	$0, 82(%rdi)
	je	.L893
	movl	16(%rsi), %esi
	subl	%edx, %esi
	movswl	76(%rdi), %edx
	movl	%esi, %eax
	negl	%eax
	cmovs	%esi, %eax
	imull	%edx, %edx
	leal	7(%rdx), %esi
	testl	%edx, %edx
	cmovns	%edx, %esi
	sarl	$3, %esi
	addl	$1, %esi
	cltd
	idivl	%esi
	testl	%eax, %eax
	movl	$1, %edx
	cmovle	%edx, %eax
	jmp	.L893
.L891:
	movl	16(%rcx), %eax
	movl	%eax, 20(%rcx)
	movl	$0, %eax
.L893:
	movl	%eax, 24(%rcx)
	ret
	.cfi_endproc
.LFE537:
	.size	glide_set, .-glide_set
	.type	voice_start, @function
voice_start:
.LFB538:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	movl	%edx, %r12d
	movl	%ecx, 4(%rsp)
	movl	%r8d, 8(%rsp)
	call	eng_audio
	movq	%rax, %r13
	movzbl	3(%rbx), %eax
	testb	%al, %al
	je	.L896
	cmpb	$0, 4(%rbx)
	setne	%r14b
	movzbl	%r14b, %r14d
	movl	32(%rbx), %eax
	movl	%eax, 12(%rsp)
	movl	36(%rbx), %eax
	movl	%eax, 16(%rsp)
	movl	40(%rbx), %eax
	movl	%eax, 20(%rsp)
	movl	44(%rbx), %eax
	movl	%eax, 24(%rsp)
	movl	48(%rbx), %eax
	movl	%eax, 28(%rsp)
	movl	60(%rbx), %eax
	movl	%eax, 32(%rsp)
	movl	64(%rbx), %eax
	movl	%eax, 36(%rsp)
	movl	68(%rbx), %eax
	movl	%eax, 40(%rsp)
	movl	72(%rbx), %eax
	movl	%eax, 44(%rsp)
	movzbl	295(%r13), %r15d
	cmpb	$1, 2(%rbx)
	movl	$1, %eax
	sbbb	$-1, %al
.L897:
	movb	%al, voice_was(%rip)
	movb	%r12b, (%rbx)
	movzbl	4(%rsp), %eax
	movb	%al, 1(%rbx)
	movb	$1, 2(%rbx)
	movb	$1, 3(%rbx)
	movb	$1, 4(%rbx)
	movl	vage(%rip), %eax
	addl	$1, %eax
	movl	%eax, vage(%rip)
	movl	%eax, 76(%rbx)
	sall	$4, %r12d
	movl	%r12d, 16(%rbx)
	movzbl	2444(%rbp), %eax
	movb	%al, 80(%rbx)
	movzwl	2448(%rbp), %eax
	movw	%ax, 82(%rbx)
	leaq	188(%rbp), %rdx
	movq	%rbx, %rax
	subq	%rdx, %rax
	sarq	$2, %rax
	movabsq	$-3513665537849438403, %rdx
	imulq	%rdx, %rax
	movb	%al, 2446(%rbp)
	movl	8(%rsp), %edx
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	glide_set
	testl	%r14d, %r14d
	jne	.L898
	movl	$0, 8(%rbx)
	movl	$0, 12(%rbx)
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	*304(%r13)
.L895:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L898:
	.cfi_restore_state
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	*304(%r13)
	cmpb	$0, 294(%r13)
	jne	.L895
	movl	12(%rsp), %eax
	movl	%eax, 32(%rbx)
	movl	16(%rsp), %eax
	movl	%eax, 36(%rbx)
	movl	20(%rsp), %eax
	movl	%eax, 40(%rbx)
	testb	$1, %r15b
	je	.L900
	movl	24(%rsp), %eax
	movl	%eax, 44(%rbx)
.L900:
	testb	$2, %r15b
	je	.L901
	movl	28(%rsp), %eax
	movl	%eax, 48(%rbx)
.L901:
	testb	$16, %r15b
	je	.L902
	movl	32(%rsp), %eax
	movl	%eax, 60(%rbx)
.L902:
	testb	$32, %r15b
	je	.L903
	movl	36(%rsp), %eax
	movl	%eax, 64(%rbx)
.L903:
	testb	$64, %r15b
	je	.L904
	movl	40(%rsp), %eax
	movl	%eax, 68(%rbx)
.L904:
	testb	%r15b, %r15b
	jns	.L895
	movl	44(%rsp), %eax
	movl	%eax, 72(%rbx)
	jmp	.L895
.L896:
	movl	32(%rbx), %ecx
	movl	%ecx, 12(%rsp)
	movl	36(%rbx), %ecx
	movl	%ecx, 16(%rsp)
	movl	40(%rbx), %ecx
	movl	%ecx, 20(%rsp)
	movl	44(%rbx), %esi
	movl	%esi, 24(%rsp)
	movl	48(%rbx), %ecx
	movl	%ecx, 28(%rsp)
	movl	60(%rbx), %esi
	movl	%esi, 32(%rsp)
	movl	64(%rbx), %edi
	movl	%edi, 36(%rsp)
	movl	68(%rbx), %ecx
	movl	%ecx, 40(%rsp)
	movl	72(%rbx), %esi
	movl	%esi, 44(%rsp)
	movzbl	295(%r13), %r15d
	movl	$0, %r14d
	jmp	.L897
	.cfi_endproc
.LFE538:
	.size	voice_start, .-voice_start
	.type	mono_pick, @function
mono_pick:
.LFB540:
	.cfi_startproc
	movzbl	2362(%rdi), %eax
	movl	$0, %edx
	testb	%al, %al
	je	.L908
	movzbl	%al, %eax
	leal	-1(%rax), %esi
	movzbl	2346(%rdi,%rsi), %edx
	movzwl	84(%rdi), %ecx
	leaq	2346(%rdi), %rax
	leaq	2347(%rdi,%rsi), %rsi
	jmp	.L912
.L915:
	movzbl	(%rax), %edi
	cmpl	%edi, %edx
	cmova	%edi, %edx
.L911:
	addq	$1, %rax
	cmpq	%rsi, %rax
	je	.L908
.L912:
	cmpw	$1, %cx
	je	.L915
	cmpw	$2, %cx
	jne	.L911
	movzbl	(%rax), %edi
	cmpl	%edi, %edx
	cmovb	%edi, %edx
	jmp	.L911
.L908:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE540:
	.size	mono_pick, .-mono_pick
	.type	mono_remove, @function
mono_remove:
.LFB541:
	.cfi_startproc
	movzbl	2362(%rdi), %eax
	movzbl	%al, %edx
	testb	%al, %al
	je	.L920
	leaq	2346(%rdi), %rax
	leal	-1(%rdx), %edx
	leaq	2347(%rdi,%rdx), %r9
	movl	$0, %ecx
	jmp	.L919
.L918:
	addq	$1, %rax
	cmpq	%r9, %rax
	je	.L917
.L919:
	movzbl	(%rax), %edx
	movzbl	%dl, %r8d
	cmpl	%esi, %r8d
	je	.L918
	movl	%ecx, %r8d
	movb	%dl, 2346(%rdi,%r8)
	leal	1(%rcx), %ecx
	jmp	.L918
.L920:
	movl	$0, %ecx
.L917:
	movb	%cl, 2362(%rdi)
	ret
	.cfi_endproc
.LFE541:
	.size	mono_remove, .-mono_remove
	.type	trk_all_off, @function
trk_all_off:
.LFB545:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %r13
	leaq	trk(%rip), %rax
	cmpq	%rax, %rdi
	je	.L933
.L923:
	movq	%r13, %rdi
	call	eng_audio
	movq	%rax, %r14
	leaq	188(%r13), %rbx
	leaq	1532(%r13), %r12
	jmp	.L927
.L933:
	cmpb	$19, 182+trk(%rip)
	jne	.L923
	cmpb	$0, morph_dual(%rip)
	je	.L923
	leaq	4928(%rax), %rdi
	call	trk_all_off
	jmp	.L923
.L934:
	movb	$0, 2362(%r13)
	movb	$0, 2363(%r13)
	movb	$0, 2408(%r13)
	movl	$128, %esi
	movq	%r13, %rdi
	call	vsq_drop
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L924:
	.cfi_restore_state
	movb	$3, 4(%rbx)
	movq	448(%r14), %rax
	testq	%rax, %rax
	je	.L926
	movq	%rbp, %rsi
	movq	%r13, %rdi
	call	*%rax
	testl	%eax, %eax
	je	.L926
	movb	$4, 4(%rbp)
.L926:
	addq	$84, %rbx
	cmpq	%r12, %rbx
	je	.L934
.L927:
	movq	%rbx, %rbp
	movb	$0, 2(%rbx)
	cmpb	$0, 3(%rbx)
	jne	.L924
	movb	$0, 4(%rbx)
	jmp	.L926
	.cfi_endproc
.LFE545:
	.size	trk_all_off, .-trk_all_off
	.type	chord_render_range, @function
chord_render_range:
.LFB548:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, 8(%rsp)
	movl	%esi, %r15d
	movl	%edx, %ebx
	movl	%ecx, %r14d
	call	eng_audio
	movq	%rax, (%rsp)
	cmpl	%ebx, %r15d
	jnb	.L935
	movl	%ebx, %edi
	movl	%r15d, %edx
	leaq	0(,%rdx,8), %rcx
	leaq	chord_plan(%rip), %rax
	leaq	(%rcx,%rax), %r13
	movq	%rdx, %rsi
	salq	$7, %rsi
	leaq	704(%rax,%rsi), %rbp
	addq	%rdx, %rcx
	leaq	128(%rax,%rcx,4), %r12
	movq	%rdx, %rcx
	salq	$5, %rcx
	movl	%r14d, %esi
	addq	%rsi, %rcx
	leaq	(%rax,%rcx,4), %rbx
	movl	%edi, %eax
	subl	$1, %eax
	subl	%r15d, %eax
	leaq	(%rax,%rdx), %r15
	salq	$7, %r15
	leaq	832+chord_plan(%rip), %rax
	addq	%rax, %r15
	jmp	.L937
.L938:
	movl	$0, 704(%rax)
	addq	$4, %rax
	cmpq	%rbx, %rax
	jne	.L938
.L940:
	movq	0(%r13), %rsi
	movq	%r12, %r8
	movl	%r14d, %ecx
	movq	%rbp, %rdx
	movq	8(%rsp), %rdi
	movq	(%rsp), %rax
	call	*312(%rax)
	addq	$8, %r13
	subq	$-128, %rbp
	addq	$36, %r12
	subq	$-128, %rbx
	cmpq	%r15, %rbp
	je	.L935
.L937:
	leaq	-704(%rbp), %rax
	testl	%r14d, %r14d
	jne	.L938
	jmp	.L940
.L935:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE548:
	.size	chord_render_range, .-chord_render_range
	.type	slicer_busy, @function
slicer_busy:
.LFB556:
	.cfi_startproc
	leaq	trk(%rip), %rdx
	movq	%rdi, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	leaq	(%rax,%rax,4), %rcx
	leaq	sl(%rip), %rdx
	movl	28(%rdx,%rcx,8), %edx
	testl	%edx, %edx
	jne	.L946
	cmpw	$2, 90(%rdi)
	jne	.L944
	leaq	sl(%rip), %rax
	cmpl	$0, 16(%rax,%rcx,8)
	setne	%dl
	movzbl	%dl, %edx
	jmp	.L944
.L946:
	movl	$1, %edx
.L944:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE556:
	.size	slicer_busy, .-slicer_busy
	.type	clean_rest, @function
clean_rest:
.LFB564:
	.cfi_startproc
	leaq	cln_dl(%rip), %rax
	leaq	256(%rax), %rdx
.L948:
	movl	$0, (%rax)
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L948
	movl	$0, cln_pk(%rip)
	movl	$32768, cln_wh(%rip)
	movl	$0, cln_top(%rip)
	movl	$0, cln_hold(%rip)
	movl	$0, cln_wi(%rip)
	movl	$0, cln_w(%rip)
	movl	$8820, cln_hlen(%rip)
	movl	$104000, cln_env(%rip)
	movl	$32768, cln_wg(%rip)
	movl	$32768, cln_gs(%rip)
	ret
	.cfi_endproc
.LFE564:
	.size	clean_rest, .-clean_rest
	.type	fx_output_set, @function
fx_output_set:
.LFB575:
	.cfi_startproc
	testl	%edi, %edi
	setne	%al
	movb	%al, fx_out_want(%rip)
	testl	%esi, %esi
	jne	.L952
.L950:
	ret
.L952:
	movzbl	fx_out_want(%rip), %eax
	movb	%al, fx_out_mode(%rip)
	movb	$0, fx_out_fade(%rip)
	call	clean_rest
	movl	68+song(%rip), %eax
	sall	$12, %eax
	sarl	$4, %eax
	movl	%eax, cln_mq(%rip)
	ret
	.cfi_endproc
.LFE575:
	.size	fx_output_set, .-fx_output_set
	.type	beat_samples, @function
beat_samples:
.LFB578:
	.cfi_startproc
	movswl	song(%rip), %ecx
	movl	$2646000, %eax
	movl	$0, %edx
	divl	%ecx
	ret
	.cfi_endproc
.LFE578:
	.size	beat_samples, .-beat_samples
	.type	perf_len, @function
perf_len:
.LFB580:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$3, %edi
	ja	.L958
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	call	beat_samples
	movl	%ebx, %ebx
	leaq	PF_DEN(%rip), %rdx
	movzbl	(%rdx,%rbx), %ecx
	movl	$0, %edx
	divl	%ecx
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L958:
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE580:
	.size	perf_len, .-perf_len
	.type	perf_drop_slicer, @function
perf_drop_slicer:
.LFB584:
	.cfi_startproc
	movb	$0, 38+sl(%rip)
	movl	$0, 16+sl(%rip)
	movl	$0, 20+sl(%rip)
	movb	$0, 78+sl(%rip)
	movl	$0, 56+sl(%rip)
	movl	$0, 60+sl(%rip)
	movb	$0, 118+sl(%rip)
	movl	$0, 96+sl(%rip)
	movl	$0, 100+sl(%rip)
	ret
	.cfi_endproc
.LFE584:
	.size	perf_drop_slicer, .-perf_drop_slicer
	.type	perf_pick, @function
perf_pick:
.LFB585:
	.cfi_startproc
	andl	$975, %edi
	movl	$13, %edx
	movl	$0, %eax
.L964:
	btl	%eax, %edi
	cmovc	%eax, %edx
	addl	$1, %eax
	cmpl	$10, %eax
	jne	.L964
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE585:
	.size	perf_pick, .-perf_pick
	.type	perf_buf_start, @function
perf_buf_start:
.LFB586:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	cmpb	$0, sl_lent(%rip)
	je	.L976
.L968:
	movb	%bl, 24+pf(%rip)
	movb	$13, 25+pf(%rip)
	movl	$0, 40+pf(%rip)
	movl	$0, 36+pf(%rip)
	movb	$0, 28+pf(%rip)
	movl	$0, 52+pf(%rip)
	cmpl	$6, %ebx
	je	.L977
	leal	-8(%rbx), %eax
	cmpl	$1, %eax
	jbe	.L978
	cmpl	$7, %ebx
	je	.L979
	movb	$1, 23+pf(%rip)
	movb	$0, 27+pf(%rip)
	movl	%ebx, %edi
	call	perf_len
	movl	%eax, 32+pf(%rip)
	cmpl	$3, %ebx
	sete	26+pf(%rip)
	jmp	.L967
.L976:
	movb	$1, sl_lent(%rip)
	call	perf_drop_slicer
	jmp	.L968
.L977:
	call	beat_samples
	movb	$2, 23+pf(%rip)
	movl	$65536, 56+pf(%rip)
	movl	$32000, %edx
	cmpl	%edx, %eax
	movl	%edx, %ecx
	cmovbe	%eax, %ecx
	movl	$65536, %eax
	movl	$0, %edx
	divl	%ecx
	addl	$1, %eax
	movl	%eax, 60+pf(%rip)
	movl	$0, 64+pf(%rip)
.L967:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L978:
	.cfi_restore_state
	movb	$4, 23+pf(%rip)
	movl	$0, 32+pf(%rip)
	movl	$0, 84+pf(%rip)
	cmpl	$8, %ebx
	movl	$1048576, %eax
	movl	$-2097152, %edx
	cmove	%edx, %eax
	movl	%eax, 88+pf(%rip)
	movl	$0, 92+pf(%rip)
	jmp	.L967
.L979:
	movb	$3, 23+pf(%rip)
	movl	$0, 68+pf(%rip)
	movl	$1024, 72+pf(%rip)
	movl	$0, 80+pf(%rip)
	movl	$0, 76+pf(%rip)
	jmp	.L967
	.cfi_endproc
.LFE586:
	.size	perf_buf_start, .-perf_buf_start
	.type	perf_buf_select, @function
perf_buf_select:
.LFB587:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	movzbl	24+pf(%rip), %eax
	movzbl	%al, %edx
	cmpl	%edi, %edx
	je	.L992
.L981:
	cmpl	$13, %ebx
	je	.L983
	movzbl	23+pf(%rip), %edx
	cmpb	$1, %dl
	je	.L993
	testb	%dl, %dl
	je	.L988
.L985:
	cmpl	$0, 96+pf(%rip)
	je	.L988
.L989:
	movb	$13, 24+pf(%rip)
	movb	%bl, 25+pf(%rip)
.L980:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L992:
	.cfi_restore_state
	cmpb	$13, 25+pf(%rip)
	jne	.L981
	jmp	.L980
.L993:
	cmpb	$0, 27+pf(%rip)
	setne	%dl
	cmpb	$13, %al
	setne	%al
	testb	%al, %dl
	je	.L985
	cmpl	$3, %ebx
	ja	.L985
	movl	%ebx, %edi
	call	perf_len
	movl	%eax, %edx
	movl	36+pf(%rip), %eax
	addl	%eax, %eax
	cmpl	%edx, %eax
	jb	.L985
	movl	40+pf(%rip), %eax
	movl	%eax, 44+pf(%rip)
	movl	32+pf(%rip), %eax
	movl	%eax, 48+pf(%rip)
	movzbl	26+pf(%rip), %eax
	movb	%al, 29+pf(%rip)
	movl	$128, 52+pf(%rip)
	movb	%bl, 24+pf(%rip)
	movb	$13, 25+pf(%rip)
	movl	%ebx, %edi
	call	perf_len
	movl	%eax, 32+pf(%rip)
	cmpl	$3, %ebx
	sete	26+pf(%rip)
	movl	$0, 40+pf(%rip)
	jmp	.L980
.L988:
	movl	%ebx, %edi
	call	perf_buf_start
	jmp	.L980
.L983:
	cmpb	$0, 23+pf(%rip)
	je	.L986
	cmpl	$0, 96+pf(%rip)
	jne	.L989
.L986:
	movb	$13, 24+pf(%rip)
	movb	$13, 25+pf(%rip)
	jmp	.L980
	.cfi_endproc
.LFE587:
	.size	perf_buf_select, .-perf_buf_select
	.type	perf_begin, @function
perf_begin:
.LFB588:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movl	%edi, %ebp
	movzbl	perf_kill(%rip), %eax
	testb	%al, %al
	jne	.L995
	movzbl	perf_solo(%rip), %edx
	movl	$0, %eax
	testb	%dl, %dl
	je	.L996
	movzbl	perf_solo(%rip), %eax
	movzbl	%al, %eax
	notl	%eax
	sall	$10, %eax
	andl	$15360, %eax
.L996:
	movl	perf_held(%rip), %ebx
	orl	%eax, %ebx
	call	beat_samples
	cmpl	$24576, %eax
	jbe	.L1023
	cmpl	$49152, %eax
	jbe	.L1024
	cmpl	$98305, %eax
	sbbl	%edx, %edx
	andl	$4, %edx
	subl	$8, %edx
.L998:
	andl	$-9, %edx
.L1021:
	andl	%edx, %ebx
	jne	.L999
.L995:
	cmpb	$0, 20+pf(%rip)
	jne	.L1026
	movzbl	perf_k(%rip), %eax
	movzbl	1+perf_k(%rip), %ecx
	movzbl	2+perf_k(%rip), %edx
	orl	%ecx, %eax
	movl	$0, %ebx
	orb	%dl, %al
	jne	.L999
	addl	%ebp, pf(%rip)
	movb	$0, 21+pf(%rip)
	movl	$0, perf_act(%rip)
	movl	$0, %eax
	jmp	.L994
.L1026:
	movl	$0, %ebx
.L999:
	call	beat_samples
	shrl	$2, %eax
	movl	%eax, %ecx
	movl	%eax, 4+pf(%rip)
	cmpb	$0, 21+pf(%rip)
	je	.L1001
	movb	$0, 21+pf(%rip)
	movl	$0, %esi
	movl	$0, %edi
.L1002:
	addl	%ebp, %esi
	movl	%esi, pf(%rip)
	movl	12+pf(%rip), %eax
	orl	$-16, %eax
	andl	%ebx, %eax
	movl	%eax, 12+pf(%rip)
	movl	%eax, 16+pf(%rip)
	movl	%eax, %edx
	notl	%edx
	andl	%ebx, %edx
	movl	%ebp, 8+pf(%rip)
	andl	$15, %edx
	je	.L1003
	movzbl	54+song(%rip), %esi
	testb	%sil, %sil
	je	.L1031
	cmpl	%ebp, %edi
	jnb	.L1003
.L1031:
	testb	%sil, %sil
	movl	$0, %esi
	cmove	%esi, %edi
	movl	%edi, 8+pf(%rip)
	orl	%edx, %eax
	movl	%eax, 12+pf(%rip)
.L1003:
	movl	12+pf(%rip), %edx
	movl	%edx, perf_act(%rip)
	movzbl	perf_k(%rip), %esi
	movsbl	%sil, %esi
	sall	$4, %ecx
	movl	%ecx, %edi
	movl	%edx, %eax
	andl	$16, %eax
	je	.L1006
	movl	%ebp, %eax
	addl	172+pf(%rip), %eax
	movl	%eax, 172+pf(%rip)
	andl	$32, %edx
	movl	%edx, %r8d
	je	.L1007
.L1018:
	movl	%ebp, %r8d
	addl	176+pf(%rip), %r8d
.L1007:
	movl	$16128, %ecx
	testl	%eax, %eax
	je	.L1008
	cmpl	%eax, %edi
	cmovbe	%edi, %eax
	sall	$6, %eax
	movl	$0, %edx
	divl	%edi
	imull	$-196, %eax, %eax
	leal	16128(%rax), %ecx
.L1008:
	movl	%r8d, 176+pf(%rip)
	testl	%esi, %esi
	js	.L1036
.L1009:
	movl	$0, %edx
	testl	%r8d, %r8d
	je	.L1012
.L1010:
	cmpl	%r8d, %edi
	movl	%r8d, %eax
	cmovbe	%edi, %eax
	sall	$6, %eax
	movl	$0, %edx
	divl	%edi
	imull	$196, %eax, %edx
.L1012:
	testl	%esi, %esi
	jle	.L1011
	imull	$12544, %esi, %esi
	movslq	%esi, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	sarl	$31, %esi
	subl	%esi, %eax
	cmpl	%eax, %edx
	cmovl	%eax, %edx
.L1011:
	movl	112+pf(%rip), %eax
	subl	%eax, %ecx
	movl	$192, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	movl	$-192, %esi
	cmpl	%esi, %ecx
	cmovl	%esi, %ecx
	addl	%eax, %ecx
	movl	%ecx, 112+pf(%rip)
	movl	116+pf(%rip), %eax
	subl	%eax, %edx
	movl	$192, %esi
	cmpl	%esi, %edx
	cmovg	%esi, %edx
	movl	$-192, %esi
	cmpl	%esi, %edx
	cmovl	%esi, %edx
	addl	%eax, %edx
	movl	%edx, 116+pf(%rip)
	movl	%ecx, %r9d
	sarl	$8, %r9d
	movl	%edx, %eax
	sarl	$8, %eax
	movl	$62, %esi
	cmpl	%esi, %r9d
	cmovle	%r9d, %esi
	addl	$1, %esi
	movslq	%esi, %rsi
	leaq	(%rsi,%rsi,2), %r8
	leaq	PF_SVF(%rip), %rdi
	leaq	(%rdi,%r8,2), %r8
	leaq	pf(%rip), %rdi
	leaq	6(%rdi), %rbp
	leaq	0(,%rsi,4), %r10
	subq	%r10, %rsi
	addq	%rsi, %rsi
	movslq	%r9d, %r9
	leaq	(%r9,%r9,2), %r11
	addq	%r11, %r11
	movslq	%eax, %r9
	leaq	(%r9,%r9,2), %r10
	addq	%r10, %r10
	movl	$62, %r9d
	cmpl	%r9d, %eax
	cmovg	%r9d, %eax
	addl	$1, %eax
	cltq
	leaq	(%rax,%rax,2), %r9
	addq	%r9, %r9
	movzbl	%cl, %ecx
	movzbl	%dl, %edx
.L1013:
	leaq	(%r8,%rsi), %r13
	movzwl	0(%r13,%r11), %r12d
	movswl	(%r8), %eax
	movswl	%r12w, %r14d
	subl	%r14d, %eax
	imull	%ecx, %eax
	sarl	$8, %eax
	addl	%eax, %r12d
	movw	%r12w, 160(%rdi)
	movzwl	0(%r13,%r10), %r12d
	movswl	0(%r13,%r9), %eax
	movswl	%r12w, %r13d
	subl	%r13d, %eax
	imull	%edx, %eax
	sarl	$8, %eax
	addl	%eax, %r12d
	movw	%r12w, 166(%rdi)
	addq	$2, %r8
	addq	$2, %rdi
	cmpq	%rbp, %rdi
	jne	.L1013
	movb	$0, 22+pf(%rip)
	movl	$0, %eax
	movl	$0, %edi
	movl	$0, %edx
	movl	$1, %r9d
	movl	$1, %r8d
	leaq	204+pf(%rip), %r10
	jmp	.L1016
.L1001:
	movl	pf(%rip), %esi
	movl	%esi, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%edx, %edi
	testl	%edx, %edx
	je	.L1002
	movl	%ecx, %edi
	subl	%edx, %edi
	cmpl	%ebp, %edi
	cmova	%ebp, %edi
	jmp	.L1002
.L1036:
	imull	$12544, %esi, %edx
	movslq	%edx, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	addl	$16128, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	movl	$0, %edx
	testl	%r8d, %r8d
	jne	.L1010
	jmp	.L1011
.L1014:
	movl	%r9d, %edi
	sall	%cl, %edi
	orl	%edi, %edx
	movl	%r8d, %edi
.L1015:
	addq	$1, %rax
	cmpq	$3, %rax
	je	.L1037
.L1016:
	movl	%eax, %ecx
	leal	10(%rax), %esi
	btl	%esi, %ebx
	jc	.L1014
	cmpl	$32768, (%r10,%rax,4)
	jne	.L1014
	jmp	.L1015
.L1037:
	testb	%dil, %dil
	je	.L1017
	movb	%dl, 22+pf(%rip)
.L1017:
	movb	$1, 20+pf(%rip)
	movl	$1, %eax
.L994:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L1006:
	.cfi_restore_state
	movl	$0, 172+pf(%rip)
	andl	$32, %edx
	movl	%edx, %r8d
	jne	.L1018
	movl	$0, 176+pf(%rip)
	movl	$16128, %ecx
	testl	%esi, %esi
	jns	.L1009
	imull	$12544, %esi, %esi
	movslq	%esi, %rcx
	imulq	$1374389535, %rcx, %rcx
	sarq	$37, %rcx
	sarl	$31, %esi
	subl	%esi, %ecx
	addl	$16128, %ecx
	movl	$16128, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	movl	$0, %edx
	jmp	.L1011
.L1023:
	movl	$-1, %edx
.L997:
	cmpl	$24576, %eax
	jbe	.L1021
	jmp	.L998
.L1024:
	movl	$-2, %edx
	jmp	.L997
	.cfi_endproc
.LFE588:
	.size	perf_begin, .-perf_begin
	.type	perf_mute, @function
perf_mute:
.LFB589:
	.cfi_startproc
	movl	%edi, %r8d
	movl	%edi, %ecx
	leaq	pf(%rip), %rax
	movl	204(%rax,%rcx,4), %edi
	leal	10(%r8), %eax
	movl	12+pf(%rip), %ecx
	btl	%eax, %ecx
	setnc	%r9b
	movzbl	%r9b, %r9d
	sall	$15, %r9d
	testl	%edx, %edx
	je	.L1039
	movq	%rsi, %rcx
	movl	%edx, %edx
	leaq	(%rsi,%rdx,4), %r10
.L1040:
	movl	%r9d, %eax
	subl	%edi, %eax
	movl	$256, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-256, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	addl	%eax, %edi
	movl	(%rcx), %esi
	leal	(%rdi,%rdi), %edx
	movzwl	%si, %eax
	imull	%edx, %eax
	shrl	$16, %eax
	sarl	$16, %esi
	imull	%esi, %edx
	addl	%edx, %eax
	movl	%eax, (%rcx)
	addq	$4, %rcx
	cmpq	%r10, %rcx
	jne	.L1040
.L1039:
	movl	%r8d, %r8d
	leaq	pf(%rip), %rax
	movl	%edi, 204(%rax,%r8,4)
	ret
	.cfi_endproc
.LFE589:
	.size	perf_mute, .-perf_mute
	.type	exp2_neg, @function
exp2_neg:
.LFB607:
	.cfi_startproc
	movl	%edi, %ecx
	shrl	$16, %ecx
	movl	$0, %eax
	cmpl	$983039, %edi
	ja	.L1042
	shrl	%edi
	andl	$32767, %edi
	movl	$32768, %edx
	subl	%edi, %edx
	imull	$2579, %edx, %eax
	shrl	$15, %eax
	addl	$7409, %eax
	imull	%edx, %eax
	shrl	$15, %eax
	addl	$22780, %eax
	imull	%edx, %eax
	shrl	$15, %eax
	addl	$32768, %eax
	addl	$1, %ecx
	shrl	%cl, %eax
.L1042:
	ret
	.cfi_endproc
.LFE607:
	.size	exp2_neg, .-exp2_neg
	.type	morph_shadow_live, @function
morph_shadow_live:
.LFB618:
	.cfi_startproc
	cmpb	$0, morph_dual(%rip)
	je	.L1045
	cmpb	$19, 182+trk(%rip)
	jne	.L1045
	movzbl	2441+trk(%rip), %eax
	movb	%al, 7369+trk(%rip)
	movzbl	2442+trk(%rip), %eax
	movb	%al, 7370+trk(%rip)
	movzbl	2456+trk(%rip), %eax
	movb	%al, 7384+trk(%rip)
	movzbl	2457+trk(%rip), %eax
	movb	%al, 7385+trk(%rip)
	movzbl	2458+trk(%rip), %eax
	movb	%al, 7386+trk(%rip)
	movzwl	2460+trk(%rip), %eax
	movw	%ax, 7388+trk(%rip)
	movzbl	2443+trk(%rip), %eax
	movb	%al, 7371+trk(%rip)
	movl	midi_bend_target(%rip), %eax
	movl	%eax, 8+midi_bend_target(%rip)
	movl	midi_bend_q8(%rip), %eax
	movl	%eax, 8+midi_bend_q8(%rip)
.L1045:
	ret
	.cfi_endproc
.LFE618:
	.size	morph_shadow_live, .-morph_shadow_live
	.type	midi_out_event, @function
midi_out_event:
.LFB645:
	.cfi_startproc
	cmpb	$0, 1+usb(%rip)
	je	.L1047
	movl	mo_w(%rip), %eax
	movl	mo_r(%rip), %edx
	subl	%edx, %eax
	cmpl	$63, %eax
	ja	.L1047
	movl	mo_w(%rip), %eax
	movl	mo_w(%rip), %eax
	addl	$1, %eax
	movl	%eax, mo_w(%rip)
.L1047:
	ret
	.cfi_endproc
.LFE645:
	.size	midi_out_event, .-midi_out_event
	.type	crx_zero, @function
crx_zero:
.LFB695:
	.cfi_startproc
	leal	-1(%rsi), %eax
	testl	%esi, %esi
	je	.L1049
	movl	%eax, %eax
	leaq	1(%rdi,%rax), %rax
.L1051:
	addq	$1, %rdi
	movb	$0, -1(%rdi)
	cmpq	%rax, %rdi
	jne	.L1051
.L1049:
	ret
	.cfi_endproc
.LFE695:
	.size	crx_zero, .-crx_zero
	.type	crx_rand, @function
crx_rand:
.LFB698:
	.cfi_startproc
	movl	192(%rdi), %eax
	testl	%eax, %eax
	movl	$-1640531527, %edx
	cmove	%edx, %eax
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, 192(%rdi)
	ret
	.cfi_endproc
.LFE698:
	.size	crx_rand, .-crx_rand
	.type	crx_sort, @function
crx_sort:
.LFB700:
	.cfi_startproc
	cmpl	$1, %esi
	jle	.L1055
	movl	%esi, %r9d
	movl	$1, %r8d
	jmp	.L1061
.L1059:
	movslq	%edx, %rdx
	movb	%sil, (%rdi,%rdx)
	addq	$1, %r8
	cmpq	%r9, %r8
	je	.L1063
.L1061:
	movl	%r8d, %edx
	movzbl	(%rdi,%r8), %esi
	testl	%r8d, %r8d
	jle	.L1057
	leaq	(%rdi,%r8), %rax
.L1058:
	movzbl	-1(%rax), %ecx
	cmpb	%cl, %sil
	jnb	.L1059
	movb	%cl, (%rax)
	subq	$1, %rax
	subl	$1, %edx
	jne	.L1058
	jmp	.L1059
.L1063:
	ret
.L1057:
	movslq	%r8d, %rax
	movb	%sil, (%rdi,%rax)
	addq	$1, %r8
	jmp	.L1061
.L1055:
	ret
	.cfi_endproc
.LFE700:
	.size	crx_sort, .-crx_sort
	.type	crx_out_off, @function
crx_out_off:
.LFB703:
	.cfi_startproc
	movq	144(%rdi), %rax
	testq	%rax, %rax
	je	.L1067
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movzbl	%dl, %edx
	movq	160(%rdi), %rdi
	call	*%rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1067:
	ret
	.cfi_endproc
.LFE703:
	.size	crx_out_off, .-crx_out_off
	.type	crx_note_end, @function
crx_note_end:
.LFB705:
	.cfi_startproc
	cmpl	$127, %edx
	ja	.L1074
	movslq	%edx, %rcx
	movslq	%esi, %rax
	salq	$7, %rax
	addq	%rdi, %rax
	movzbl	218(%rcx,%rax), %eax
	testb	%al, %al
	je	.L1074
	cmpb	$1, %al
	jbe	.L1077
	movslq	%edx, %rdx
	movslq	%esi, %rsi
	salq	$7, %rsi
	addq	%rsi, %rdi
	subl	$1, %eax
	movb	%al, 218(%rdx,%rdi)
	ret
.L1077:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movslq	%esi, %rax
	salq	$7, %rax
	addq	%rdi, %rax
	movb	$0, 218(%rcx,%rax)
	call	crx_out_off
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1074:
	ret
	.cfi_endproc
.LFE705:
	.size	crx_note_end, .-crx_note_end
	.type	crx_sched, @function
crx_sched:
.LFB707:
	.cfi_startproc
	movq	%rdi, %r10
	movzwl	7280(%rdi), %r11d
	cmpw	$127, %r11w
	ja	.L1089
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edx, %ebx
	movl	%ecx, %ebp
	testl	%esi, %esi
	movl	$1, %eax
	cmove	%eax, %esi
	addl	184(%rdi), %esi
	movzwl	%r11w, %edx
	testl	%edx, %edx
	jle	.L1084
	movzwl	%r11w, %eax
	leaq	(%rdi,%rax,8), %rax
.L1082:
	movl	%edx, %edi
	subl	$1, %edx
	movl	6248(%rax), %ecx
	subl	%esi, %ecx
	testl	%ecx, %ecx
	jle	.L1081
	movq	6248(%rax), %rcx
	movq	%rcx, 6256(%rax)
	subq	$8, %rax
	testl	%edx, %edx
	jne	.L1082
	movl	%edx, %edi
.L1081:
	movslq	%edi, %rdi
	leaq	(%r10,%rdi,8), %rax
	movl	%esi, 6256(%rax)
	movb	%bl, 6260(%rax)
	movb	%bpl, 6261(%rax)
	movb	%r8b, 6262(%rax)
	movb	%r9b, 6263(%rax)
	addl	$1, %r11d
	movw	%r11w, 7280(%r10)
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1089:
	.cfi_restore 3
	.cfi_restore 6
	addw	$1, 7282(%rdi)
	movl	$0, %eax
	ret
.L1084:
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movl	%edx, %edi
	jmp	.L1081
	.cfi_endproc
.LFE707:
	.size	crx_sched, .-crx_sched
	.type	crx_cancel, @function
crx_cancel:
.LFB708:
	.cfi_startproc
	movzwl	7280(%rdi), %edx
	testw	%dx, %dx
	je	.L1094
	leaq	6256(%rdi), %rax
	movzwl	%dx, %edx
	leal	-1(%rdx), %edx
	leaq	6264(%rdi,%rdx,8), %r9
	movl	$0, %edx
	jmp	.L1093
.L1092:
	addq	$8, %rax
	cmpq	%r9, %rax
	je	.L1091
.L1093:
	cmpb	%sil, 5(%rax)
	je	.L1092
	movslq	%edx, %rcx
	movq	(%rax), %r8
	movq	%r8, 6256(%rdi,%rcx,8)
	leal	1(%rdx), %edx
	jmp	.L1092
.L1094:
	movl	$0, %edx
.L1091:
	movw	%dx, 7280(%rdi)
	ret
	.cfi_endproc
.LFE708:
	.size	crx_cancel, .-crx_cancel
	.type	crx_secret_quality, @function
crx_secret_quality:
.LFB711:
	.cfi_startproc
	movzbl	2(%rdi), %eax
	movl	$0, %edx
	testb	%al, %al
	je	.L1096
	cmpb	$1, %al
	je	.L1114
.L1098:
	movzbl	746(%rdi), %eax
	subl	$1, %eax
	js	.L1106
	movzbl	737(%rdi), %r8d
	cltq
	movl	$0, %esi
	jmp	.L1101
.L1114:
	cmpb	$0, (%rdi)
	je	.L1098
	jmp	.L1096
.L1107:
	movl	%edx, %esi
.L1099:
	subq	$1, %rax
	testl	%eax, %eax
	js	.L1115
.L1101:
	movzbl	738(%rdi,%rax), %edx
	leal	-1(%rdx), %ecx
	btl	%ecx, %r8d
	jnc	.L1099
	testl	%esi, %esi
	je	.L1107
	cmpl	%esi, %edx
	je	.L1099
	testl	%edx, %edx
	je	.L1096
	cmpl	$4, %esi
	je	.L1112
	cmpl	$4, %edx
	je	.L1112
	movl	$0, %edx
	jmp	.L1096
.L1115:
	movl	$0, %edx
.L1096:
	movl	%edx, %eax
	ret
.L1112:
	cmpl	$4, %esi
	cmove	%edx, %esi
	cmpl	$1, %esi
	je	.L1109
	cmpl	$3, %esi
	je	.L1110
	cmpl	$2, %esi
	movl	$7, %edx
	movl	$0, %eax
	cmovne	%eax, %edx
	jmp	.L1096
.L1106:
	movl	$0, %edx
	jmp	.L1096
.L1109:
	movl	$6, %edx
	jmp	.L1096
.L1110:
	movl	$5, %edx
	jmp	.L1096
	.cfi_endproc
.LFE711:
	.size	crx_secret_quality, .-crx_secret_quality
	.type	crx_expand_range, @function
crx_expand_range:
.LFB714:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdi, %r14
	movl	%esi, %r13d
	movl	%edx, %r12d
	movq	%rcx, %rbp
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rdi
	movl	$16, %esi
	call	crx_zero
	movl	$0, %ebx
	movslq	%r13d, %r9
	addq	%r14, %r9
	testl	%r12d, %r12d
	jle	.L1118
	movl	$0, %r11d
	movl	$0, %esi
	movl	$1, %r10d
	movq	%r14, %rdi
	jmp	.L1117
.L1119:
	addq	$1, %rdx
	cmpq	%r9, %rdx
	je	.L1131
.L1120:
	movzbl	(%rdx), %eax
	addl	%r14d, %eax
	cmpl	$127, %eax
	jg	.L1119
	movl	%eax, %esi
	sarl	$3, %esi
	movslq	%esi, %rcx
	movzbl	16(%rsp,%rcx), %r8d
	movl	%eax, %ecx
	andl	$7, %ecx
	movzbl	%r8b, %r15d
	btl	%ecx, %r15d
	jc	.L1119
	movslq	%esi, %rsi
	movl	%r10d, %r15d
	sall	%cl, %r15d
	orl	%r15d, %r8d
	movb	%r8b, 16(%rsp,%rsi)
	movslq	%ebx, %rcx
	movb	%al, 0(%rbp,%rcx)
	leal	1(%rbx), %ebx
	jmp	.L1119
.L1131:
	movl	12(%rsp), %esi
.L1122:
	addl	$1, %esi
	addl	$12, %r11d
	cmpl	%esi, %r12d
	je	.L1118
.L1117:
	movl	%r11d, %r14d
	movq	%rdi, %rdx
	testl	%r13d, %r13d
	jle	.L1122
	movl	%esi, 12(%rsp)
	jmp	.L1120
.L1118:
	movl	%ebx, %esi
	movq	%rbp, %rdi
	call	crx_sort
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1132
	movl	%ebx, %eax
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1132:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE714:
	.size	crx_expand_range, .-crx_expand_range
	.type	crx_order_notes, @function
crx_order_notes:
.LFB715:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movl	%edx, %ebx
	movq	56(%rsp), %rbp
	cmpl	$1, %ecx
	je	.L1176
	movq	%rdi, %r12
	cmpl	$2, %ecx
	je	.L1177
	cmpl	$3, %ecx
	je	.L1178
	cmpl	$4, %ecx
	je	.L1179
	cmpl	$5, %ecx
	jne	.L1163
	testl	%r8d, %r8d
	jne	.L1163
	testl	%edx, %edx
	jle	.L1161
	movslq	%edx, %rcx
	movl	$0, %eax
.L1152:
	movzbl	(%rsi,%rax), %edx
	movb	%dl, 0(%rbp,%rax)
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L1152
	leal	-1(%rbx), %r13d
	testl	%r13d, %r13d
	jle	.L1162
	movslq	%r13d, %r13
.L1153:
	movq	%r12, %rdi
	call	crx_rand
	movzbl	0(%rbp,%r13), %esi
	leal	1(%r13), %ecx
	movl	$0, %edx
	divl	%ecx
	movslq	%edx, %rdx
	addq	%rbp, %rdx
	movzbl	(%rdx), %eax
	movb	%al, 0(%rbp,%r13)
	movb	%sil, (%rdx)
	subq	$1, %r13
	testl	%r13d, %r13d
	jg	.L1153
	movl	%ebx, %eax
	jmp	.L1133
.L1176:
	subl	$1, %edx
	js	.L1155
	movslq	%edx, %rdx
	addq	%rsi, %rdx
	movq	%rbp, %rax
	leal	-1(%rbx), %ecx
	leaq	1(%rbp,%rcx), %rsi
.L1136:
	movzbl	(%rdx), %ecx
	movb	%cl, (%rax)
	subq	$1, %rdx
	addq	$1, %rax
	cmpq	%rsi, %rax
	jne	.L1136
	movl	%ebx, %eax
.L1133:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1177:
	.cfi_restore_state
	testl	%edx, %edx
	jle	.L1156
	movslq	%edx, %rcx
	movl	$0, %eax
.L1138:
	movzbl	(%rsi,%rax), %edx
	movb	%dl, 0(%rbp,%rax)
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L1138
	leal	-2(%rbx), %ecx
	testl	%r8d, %r8d
	setne	%dil
	setne	%dl
	movzbl	%dl, %edx
	cmpl	%edx, %ecx
	jl	.L1157
	movslq	%ecx, %rcx
	addq	%rsi, %rcx
	leaq	0(%rbp,%rax), %rdx
	movzbl	%dil, %edi
	leal	-2(%rbx), %esi
	subl	%edi, %esi
	leaq	1(%rbp,%rax), %rax
	addq	%rax, %rsi
.L1139:
	movzbl	(%rcx), %eax
	movb	%al, (%rdx)
	subq	$1, %rcx
	addq	$1, %rdx
	cmpq	%rsi, %rdx
	jne	.L1139
	leal	-1(%rbx,%rbx), %eax
	subl	%edi, %eax
	jmp	.L1133
.L1178:
	movl	%edx, %r8d
	subl	$1, %r8d
	js	.L1158
	movslq	%r8d, %rdx
	addq	%rsi, %rdx
	movq	%rbp, %rax
	leal	-1(%rbx), %ecx
	leaq	1(%rbp,%rcx), %rdi
.L1141:
	movzbl	(%rdx), %ecx
	movb	%cl, (%rax)
	subq	$1, %rdx
	addq	$1, %rax
	cmpq	%rdi, %rax
	jne	.L1141
	cmpl	$1, %r8d
	jle	.L1159
	leal	-1(%rbx), %edi
	movl	$1, %eax
	movslq	%ebx, %rcx
	addq	%rbp, %rcx
.L1142:
	movzbl	(%rsi,%rax), %edx
	movb	%dl, -1(%rcx,%rax)
	addq	$1, %rax
	cmpq	%rdi, %rax
	jne	.L1142
	leal	-2(%rbx,%rbx), %eax
	jmp	.L1133
.L1179:
	movl	$0, %r11d
	movl	$0, %r10d
	movl	$0, %eax
	movslq	40(%rsp), %rdi
	addq	%r9, %rdi
	cmpl	$0, 48(%rsp)
	jg	.L1144
	jmp	.L1133
.L1180:
	movslq	%eax, %r8
	movb	%dl, 0(%rbp,%r8)
	leal	1(%rax), %eax
.L1145:
	addq	$1, %rcx
	cmpq	%rdi, %rcx
	je	.L1148
.L1146:
	movzbl	(%rcx), %edx
	addl	%esi, %edx
	cmpl	$127, %edx
	jg	.L1145
	cmpl	$55, %eax
	jle	.L1180
	jmp	.L1145
.L1148:
	addl	$1, %r10d
	addl	$12, %r11d
	cmpl	%r10d, 48(%rsp)
	je	.L1133
.L1144:
	movl	%r11d, %esi
	movq	%r9, %rcx
	cmpl	$0, 40(%rsp)
	jg	.L1146
	jmp	.L1148
.L1163:
	movslq	%ebx, %rcx
	movl	$0, %eax
	testl	%ebx, %ebx
	jle	.L1133
.L1154:
	movzbl	(%rsi,%rax), %edx
	movb	%dl, 0(%rbp,%rax)
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L1154
	movl	%ebx, %eax
	jmp	.L1133
.L1155:
	movl	$0, %eax
	jmp	.L1133
.L1156:
	movl	$0, %eax
	jmp	.L1133
.L1157:
	movl	%ebx, %eax
	jmp	.L1133
.L1158:
	movl	$0, %eax
	jmp	.L1133
.L1159:
	movl	%ebx, %eax
	jmp	.L1133
.L1161:
	movl	$0, %eax
	jmp	.L1133
.L1162:
	movl	%ebx, %eax
	jmp	.L1133
	.cfi_endproc
.LFE715:
	.size	crx_order_notes, .-crx_order_notes
	.type	crx_build_clocked_seq, @function
crx_build_clocked_seq:
.LFB720:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$56, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	movzbl	97(%rsi), %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,2), %rax
	leaq	26(%rdi,%rax,2), %r12
	leaq	28(%rsi), %r13
	movq	%rsp, %rcx
	movswl	6(%r12), %edx
	movzbl	27(%rsi), %esi
	movq	%r13, %rdi
	call	crx_expand_range
	cmpb	$2, 97(%rbx)
	je	.L1182
	movslq	%eax, %rsi
	movl	$0, %edx
	testl	%eax, %eax
	jle	.L1185
.L1186:
	movzbl	(%rsp,%rdx), %ecx
	movb	%cl, 116(%rbx,%rdx)
	addq	$1, %rdx
	cmpq	%rsi, %rdx
	jne	.L1186
.L1185:
	movb	%al, 98(%rbx)
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1191
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1182:
	.cfi_restore_state
	movswl	4(%r12), %ecx
	movq	%rsp, %rsi
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	leaq	116(%rbx), %rdx
	pushq	%rdx
	.cfi_def_cfa_offset 112
	movswl	6(%r12), %edx
	pushq	%rdx
	.cfi_def_cfa_offset 120
	movzbl	27(%rbx), %edx
	pushq	%rdx
	.cfi_def_cfa_offset 128
	movq	%r13, %r9
	movl	$1, %r8d
	movl	%eax, %edx
	movq	%rbp, %rdi
	call	crx_order_notes
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	jmp	.L1185
.L1191:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE720:
	.size	crx_build_clocked_seq, .-crx_build_clocked_seq
	.type	crx_raw_loop, @function
crx_raw_loop:
.LFB729:
	.cfi_startproc
	movzbl	2(%rdi), %eax
	subl	$1, %eax
	movl	$0, %edx
	cmpb	$-3, %al
	ja	.L1192
	cmpb	$0, 15(%rdi)
	sete	%dl
	movzbl	%dl, %edx
.L1192:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE729:
	.size	crx_raw_loop, .-crx_raw_loop
	.type	crx_bass_pitch, @function
crx_bass_pitch:
.LFB735:
	.cfi_startproc
	cmpb	$1, 11(%rdi)
	je	.L1202
	movsbl	14(%rdi), %eax
	leal	9(%rax,%rax,2), %eax
	sall	$2, %eax
	cmpb	$0, 2(%rsi)
	je	.L1200
	movzbl	9(%rsi), %edx
	movswl	16(%rsi), %ecx
	addl	%ecx, %edx
	movzbl	10(%rsi), %ecx
	subl	%ecx, %edx
.L1201:
	addl	%edx, %eax
	movsbl	11(%rsi), %edx
	addl	%edx, %eax
	ret
.L1202:
	cmpb	$0, 2(%rsi)
	je	.L1197
	movswl	16(%rsi), %edx
.L1198:
	movsbl	11(%rsi), %eax
	addl	%edx, %eax
	movsbl	14(%rdi), %edx
	leal	(%rdx,%rdx,2), %edx
	leal	(%rax,%rdx,4), %eax
	ret
.L1197:
	movzbl	10(%rsi), %edx
	jmp	.L1198
.L1200:
	movzbl	8(%rsi), %edx
	jmp	.L1201
	.cfi_endproc
.LFE735:
	.size	crx_bass_pitch, .-crx_bass_pitch
	.type	crx_bass_release, @function
crx_bass_release:
.LFB737:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %rbx
	cmpb	$0, 93(%rsi)
	jne	.L1206
.L1204:
	movb	$0, 93(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1206:
	.cfi_restore_state
	movzbl	94(%rsi), %edx
	movl	$1, %esi
	call	crx_note_end
	jmp	.L1204
	.cfi_endproc
.LFE737:
	.size	crx_bass_release, .-crx_bass_release
	.type	crx_prepare_voice, @function
crx_prepare_voice:
.LFB743:
	.cfi_startproc
	movq	176(%rdi), %rax
	testq	%rax, %rax
	je	.L1210
	movzbl	15(%rsi), %edx
	testb	%dl, %dl
	je	.L1210
	cmpb	$-1, 2(%rsi)
	je	.L1210
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movzbl	14(%rsi), %r8d
	movzbl	%dl, %edx
	movsbw	11(%rsi), %cx
	addw	16(%rsi), %cx
	movswl	%cx, %esi
	movq	160(%rdi), %rdi
	movl	%r8d, %ecx
	call	*%rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1210:
	ret
	.cfi_endproc
.LFE743:
	.size	crx_prepare_voice, .-crx_prepare_voice
	.type	crx_gesture, @function
crx_gesture:
.LFB749:
	.cfi_startproc
	movq	168(%rdi), %r10
	testq	%r10, %r10
	je	.L1216
	movl	%edx, %ecx
	movslq	%esi, %rdx
	imulq	$172, %rdx, %rdx
	cmpb	$0, 752(%rdi,%rdx)
	je	.L1216
	movslq	%esi, %rdx
	imulq	$172, %rdx, %rdx
	cmpb	$0, 754(%rdi,%rdx)
	jne	.L1216
	subq	$16, %rsp
	.cfi_def_cfa_offset 24
	movq	%rdx, %rsi
	addq	%rdi, %rsi
	movzbl	759(%rsi), %r9d
	movzbl	766(%rsi), %r8d
	movzbl	767(%rsi), %r11d
	movsbw	763(%rsi), %dx
	addw	768(%rsi), %dx
	movswl	%dx, %edx
	movl	796(%rsi), %esi
	movq	160(%rdi), %rdi
	pushq	%rcx
	.cfi_def_cfa_offset 32
	movl	%r11d, %ecx
	call	*%r10
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1216:
	ret
	.cfi_endproc
.LFE749:
	.size	crx_gesture, .-crx_gesture
	.type	crx_find_voice, @function
crx_find_voice:
.LFB752:
	.cfi_startproc
	addq	$752, %rdi
	movl	$0, %eax
	jmp	.L1222
.L1220:
	addl	$1, %eax
	addq	$172, %rdi
	cmpl	$16, %eax
	je	.L1224
.L1222:
	cmpb	$0, (%rdi)
	je	.L1220
	movzbl	3(%rdi), %edx
	cmpl	%esi, %edx
	jne	.L1220
	ret
.L1224:
	movl	$-1, %eax
.L1219:
	ret
	.cfi_endproc
.LFE752:
	.size	crx_find_voice, .-crx_find_voice
	.type	crx_rec_commit, @function
crx_rec_commit:
.LFB760:
	.cfi_startproc
	movzbl	7348(%rdi), %eax
	testb	%al, %al
	js	.L1225
	cmpb	$0, 7349(%rdi)
	je	.L1225
	cmpb	$0, 730(%rdi)
	jne	.L1225
	cmpb	$0, 737(%rdi)
	jne	.L1225
	movsbq	%al, %rax
	leaq	(%rax,%rax), %rdx
	leaq	(%rdx,%rax), %rcx
	leaq	7296(%rdi,%rcx,2), %rcx
	movl	7350(%rdi), %esi
	movl	%esi, 4(%rcx)
	movzwl	7354(%rdi), %esi
	movw	%si, 8(%rcx)
	addq	%rax, %rdx
	movb	$1, 7300(%rdi,%rdx,2)
	movb	$-1, 7348(%rdi)
	movb	$0, 7349(%rdi)
.L1225:
	ret
	.cfi_endproc
.LFE760:
	.size	crx_rec_commit, .-crx_rec_commit
	.type	crx_str, @function
crx_str:
.LFB810:
	.cfi_startproc
	movzbl	(%rsi), %ecx
	testb	%cl, %cl
	je	.L1230
	cmpl	$1, %edx
	jle	.L1231
	leal	-1(%rdx), %edx
	movl	$0, %eax
.L1229:
	movb	%cl, (%rdi,%rax)
	addq	$1, %rax
	movzbl	(%rsi,%rax), %ecx
	testb	%cl, %cl
	je	.L1228
	cmpq	%rdx, %rax
	jne	.L1229
.L1228:
	movb	$0, (%rdi,%rax)
	ret
.L1230:
	movl	$0, %eax
	jmp	.L1228
.L1231:
	movl	$0, %eax
	jmp	.L1228
	.cfi_endproc
.LFE810:
	.size	crx_str, .-crx_str
	.type	crx_cat, @function
crx_cat:
.LFB811:
	.cfi_startproc
	movq	%rdi, %r8
	movq	%rsi, %rdi
	cmpb	$0, (%r8)
	je	.L1238
	leaq	1(%r8), %rax
	movl	$0, %ecx
.L1235:
	movl	%ecx, %r9d
	addl	$1, %ecx
	movq	%rax, %rsi
	addq	$1, %rax
	cmpb	$0, -1(%rax)
	jne	.L1235
	testl	%ecx, %ecx
	je	.L1234
	cmpb	$0, (%rdi)
	je	.L1236
	leal	-1(%rdx), %eax
	cmpl	%ecx, %eax
	jle	.L1236
	leal	2(%r9), %ecx
	movb	$32, (%rsi)
.L1234:
	movzbl	(%rdi), %esi
	testb	%sil, %sil
	je	.L1236
	leal	-1(%rdx), %eax
	cmpl	%eax, %ecx
	jge	.L1236
	leal	1(%rcx), %eax
	cltq
	movslq	%ecx, %r10
	subl	$2, %edx
	subl	%ecx, %edx
	leaq	2(%r10,%rdx), %r9
	subq	%r10, %rdi
	movq	%rdi, %rdx
.L1237:
	movl	%eax, %ecx
	movb	%sil, -1(%r8,%rax)
	movzbl	(%rdx,%rax), %esi
	testb	%sil, %sil
	je	.L1236
	addq	$1, %rax
	cmpq	%r9, %rax
	jne	.L1237
.L1236:
	movslq	%ecx, %rcx
	movb	$0, (%r8,%rcx)
	ret
.L1238:
	movl	$0, %ecx
	jmp	.L1234
	.cfi_endproc
.LFE811:
	.size	crx_cat, .-crx_cat
	.type	crl_zero, @function
crl_zero:
.LFB823:
	.cfi_startproc
	leal	-1(%rsi), %eax
	testl	%esi, %esi
	je	.L1241
	movl	%eax, %eax
	leaq	1(%rdi,%rax), %rax
.L1243:
	addq	$1, %rdi
	movb	$0, -1(%rdi)
	cmpq	%rax, %rdi
	jne	.L1243
.L1241:
	ret
	.cfi_endproc
.LFE823:
	.size	crl_zero, .-crl_zero
	.type	crl_lev0_scan, @function
crl_lev0_scan:
.LFB834:
	.cfi_startproc
	movzwl	12(%rdi), %r8d
	movl	$0, %esi
	movl	$0, %edx
	jmp	.L1246
.L1247:
	movw	%dx, 4616(%rdi,%rsi,2)
	addq	$1, %rsi
	cmpq	$32, %rsi
	je	.L1245
.L1246:
	cmpl	%r8d, %edx
	jnb	.L1247
	movl	%edx, %eax
	leaq	(%rdi,%rax,8), %rcx
.L1250:
	movzbl	153(%rcx), %eax
	andl	$31, %eax
	cmpl	%esi, %eax
	jnb	.L1247
	addl	$1, %edx
	addq	$8, %rcx
	cmpl	%r8d, %edx
	jne	.L1250
	movl	%r8d, %edx
	jmp	.L1247
.L1245:
	ret
	.cfi_endproc
.LFE834:
	.size	crl_lev0_scan, .-crl_lev0_scan
	.type	crl_restore, @function
crl_restore:
.LFB835:
	.cfi_startproc
	movzwl	12(%rdi), %eax
	testw	%ax, %ax
	je	.L1263
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movzwl	%ax, %r9d
	leal	-1(%rsi), %r11d
	movl	%r11d, %eax
	leaq	4616(%rdi,%rax,2), %rbx
	movl	$0, %eax
	movl	%esi, %r10d
	orl	$-128, %r10d
	jmp	.L1258
.L1267:
	movl	%r11d, %edx
.L1255:
	movb	%dl, 153(%rdi,%rax,8)
	addw	$1, 4700(%rdi)
.L1254:
	addq	$1, %rax
	cmpl	%r9d, %eax
	jnb	.L1266
.L1258:
	cmpb	%r10b, 153(%rdi,%rax,8)
	jne	.L1254
	movl	%esi, %edx
	testl	%esi, %esi
	je	.L1255
	testl	%r11d, %r11d
	je	.L1267
	movq	%rbx, %rcx
	movl	%r11d, %edx
.L1256:
	movzwl	(%rcx), %r8d
	cmpl	%r8d, %eax
	jnb	.L1255
	subq	$2, %rcx
	subl	$1, %edx
	jne	.L1256
	jmp	.L1255
.L1266:
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L1263:
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE835:
	.size	crl_restore, .-crl_restore
	.type	crl_write, @function
crl_write:
.LFB840:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%esi, %r11d
	movl	%edx, %esi
	movl	%ecx, %r10d
	movzbl	4245(%rdi), %eax
	cmpb	$3, %al
	je	.L1288
	cmpb	$5, %al
	je	.L1289
	cmpb	$6, %al
	jne	.L1268
	movzwl	4688(%rdi), %ebx
	movzwl	%bx, %r11d
	movzbl	4692(%rdi), %eax
	movl	%r11d, %edx
	imull	%eax, %edx
	movzwl	12(%rdi), %ecx
	cmpw	$511, %cx
	jbe	.L1275
.L1279:
	movb	$1, 4246(%rdi)
.L1268:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1288:
	.cfi_restore_state
	movl	4276(%rdi), %ebx
	cmpl	%ebx, 4252(%rdi)
	js	.L1268
	cmpl	%ebx, %r11d
	js	.L1282
	movl	%r11d, %edx
	subl	%ebx, %edx
	movl	4280(%rdi), %eax
	subl	$1, %eax
	cmpl	%edx, %eax
	jb	.L1268
	movl	%r11d, %ebx
	cmpl	$3071, %edx
	ja	.L1268
	jmp	.L1271
.L1289:
	movl	8(%rdi), %ecx
	testl	%ecx, %ecx
	je	.L1268
	movl	4288(%rdi), %ebx
	cmpl	%ebx, %r11d
	cmovns	%r11d, %ebx
	movl	%ebx, %eax
	subl	4268(%rdi), %eax
	cltd
	idivl	%ecx
	addl	%edx, %ecx
	testl	%edx, %edx
	cmovs	%ecx, %edx
.L1271:
	movzwl	12(%rdi), %ecx
	cmpw	$511, %cx
	ja	.L1279
	movl	4252(%rdi), %eax
	subl	%ebx, %eax
	movl	$3072, %r11d
	cmpl	%r11d, %eax
	cmova	%r11d, %eax
	testl	%eax, %eax
	movl	$1, %r11d
	cmove	%r11d, %eax
.L1278:
	addw	$1, 4700(%rdi)
	leal	1(%rcx), %r11d
	movw	%r11w, 12(%rdi)
	movzwl	%cx, %ecx
	leaq	(%rdi,%rcx,8), %rcx
	movw	%dx, 146(%rcx)
	movw	%ax, 148(%rcx)
	movl	$0, %eax
	testw	%si, %si
	js	.L1276
	cmpw	$127, %si
	movl	$127, %eax
	cmovle	%esi, %eax
.L1276:
	movb	%al, 150(%rcx)
	testb	%r9b, %r9b
	movl	$1, %eax
	cmovne	%r9d, %eax
	movb	%al, 151(%rcx)
	movl	%r10d, %eax
	sall	$4, %eax
	cmpb	$8, %r10b
	movl	$0, %edx
	cmovnb	%edx, %eax
	andl	$15, %r8d
	orl	%eax, %r8d
	movb	%r8b, 152(%rcx)
	movzbl	14(%rdi), %eax
	movb	%al, 153(%rcx)
	cmpw	$511, %r11w
	jbe	.L1268
	movb	$1, 4246(%rdi)
	jmp	.L1268
.L1282:
	movl	$0, %edx
	jmp	.L1271
.L1275:
	movl	$3072, %ebp
	cmpl	%ebp, %eax
	cmova	%ebp, %eax
	testl	%eax, %eax
	movl	$1, %ebp
	cmove	%ebp, %eax
	movb	$1, 4693(%rdi)
	addl	$1, %r11d
	movzwl	4690(%rdi), %ebp
	cmpl	%r11d, %ebp
	jnb	.L1278
	addl	$1, %ebx
	movw	%bx, 4690(%rdi)
	jmp	.L1278
	.cfi_endproc
.LFE840:
	.size	crl_write, .-crl_write
	.type	crl_take_start, @function
crl_take_start:
.LFB841:
	.cfi_startproc
	cmpb	$0, 4680(%rdi)
	je	.L1290
	movb	$0, 4680(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 16(%rdi)
	movw	$0, 12(%rdi)
	movl	$0, 8(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 4244(%rdi)
	movb	$0, 4712(%rdi)
	movb	$1, 4713(%rdi)
	addw	$1, 4700(%rdi)
.L1290:
	ret
	.cfi_endproc
.LFE841:
	.size	crl_take_start, .-crl_take_start
	.type	crl_close_open, @function
crl_close_open:
.LFB844:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %r12
	leaq	4300(%rdi), %rbx
	leaq	4556(%rdi), %rbp
	jmp	.L1294
.L1293:
	addq	$16, %rbx
	cmpq	%rbp, %rbx
	je	.L1297
.L1294:
	cmpb	$0, 6(%rbx)
	je	.L1293
	movzbl	7(%rbx), %ecx
	movswl	4(%rbx), %edx
	movl	(%rbx), %esi
	movzbl	9(%rbx), %r9d
	movzbl	8(%rbx), %r8d
	movq	%r12, %rdi
	call	crl_write
	movl	4252(%r12), %eax
	movl	%eax, (%rbx)
	jmp	.L1293
.L1297:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE844:
	.size	crl_close_open, .-crl_close_open
	.type	crl_quantize, @function
crl_quantize:
.LFB845:
	.cfi_startproc
	movzbl	1(%rdi), %edx
	cmpb	$6, %dl
	ja	.L1309
	movq	%rdi, %rax
	movzbl	%dl, %edx
	leaq	CRL_QGRID(%rip), %rcx
	movzbl	(%rcx,%rdx), %edi
	testl	%edi, %edi
	je	.L1309
	movl	8(%rax), %r8d
	testl	%r8d, %r8d
	je	.L1309
	movzwl	12(%rax), %edx
	cmpl	%edx, %esi
	jnb	.L1309
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %r10d
	shrl	%r10d
	movl	%esi, %r9d
	leaq	(%rax,%r9,8), %rcx
	subl	%esi, %edx
	leal	-1(%rdx), %edx
	addq	%r9, %rdx
	leaq	8(%rax,%rdx,8), %r9
	movl	$3072, %ebx
	movl	$1, %r11d
	jmp	.L1305
.L1313:
	movw	$0, 146(%rcx)
	jmp	.L1301
.L1302:
	subl	%eax, %edx
	movw	%ax, 146(%rcx)
	movl	%ebx, %eax
	cmpl	$3072, %edx
	ja	.L1304
.L1303:
	movl	%edx, %eax
.L1304:
	movw	%ax, 148(%rsi)
.L1301:
	addq	$8, %rcx
	cmpq	%r9, %rcx
	je	.L1312
.L1305:
	movq	%rcx, %rsi
	movzwl	146(%rcx), %ebp
	leal	0(%rbp,%r10), %eax
	movl	$0, %edx
	divl	%edi
	imull	%edi, %eax
	movzwl	148(%rcx), %edx
	cmpl	%r8d, %eax
	jnb	.L1313
	movzwl	%dx, %edx
	addl	%ebp, %edx
	cmpl	%edx, %eax
	jb	.L1302
	movw	%ax, 146(%rcx)
	movl	%r11d, %edx
	jmp	.L1303
.L1312:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1309:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE845:
	.size	crl_quantize, .-crl_quantize
	.type	cr_mchan, @function
cr_mchan:
.LFB893:
	.cfi_startproc
	movl	%edi, %edx
	leaq	cr_mch(%rip), %rax
	leaq	(%rax,%rdx,8), %rcx
	cmpb	$0, 7(%rax,%rdx,8)
	jne	.L1314
	movl	%edi, %edi
	movb	$2, 3(%rax,%rdi,8)
	movb	$127, 6(%rax,%rdi,8)
	movb	$127, 5(%rax,%rdi,8)
	movb	$1, 7(%rax,%rdi,8)
.L1314:
	movq	%rcx, %rax
	ret
	.cfi_endproc
.LFE893:
	.size	cr_mchan, .-cr_mchan
	.type	cr_mbend, @function
cr_mbend:
.LFB894:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	call	cr_mchan
	movq	%rax, %rdx
	movzwl	(%rax), %ecx
	movzbl	3(%rax), %eax
	imull	$100, %eax, %eax
	movzbl	4(%rdx), %edx
	addl	%edx, %eax
	sall	$8, %eax
	cltq
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	movswl	%cx, %edx
	imull	%edx, %eax
	movl	%edx, %esi
	shrl	$31, %esi
	addl	$8191, %esi
	movl	%ebx, %ebx
	cltd
	idivl	%esi
	leaq	midi_bend_target(%rip), %rdx
	movl	%eax, (%rdx,%rbx,4)
	imulq	$2464, %rbx, %rbx
	leaq	trk(%rip), %rax
	movw	%cx, 2460(%rax,%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE894:
	.size	cr_mbend, .-cr_mbend
	.type	cr_midi, @function
cr_midi:
.LFB901:
	.cfi_startproc
	movl	%edi, %eax
	shrl	$4, %edi
	sall	$8, %eax
	orl	%eax, %edi
	sall	$24, %edx
	andl	$2130706432, %edx
	orl	%edx, %edi
	sall	$16, %esi
	andl	$8323072, %esi
	orl	%esi, %edi
	call	midi_out_event
	ret
	.cfi_endproc
.LFE901:
	.size	cr_midi, .-cr_midi
	.type	cr_tr_end, @function
cr_tr_end:
.LFB903:
	.cfi_startproc
	cmpl	$2, %edi
	ja	.L1321
	movl	%edi, %eax
	leaq	cr_tr_n(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	testb	%al, %al
	je	.L1321
	movl	%edi, %edi
	subl	$1, %eax
	movb	%al, (%rdx,%rdi)
.L1321:
	ret
	.cfi_endproc
.LFE903:
	.size	cr_tr_end, .-cr_tr_end
	.type	cr_synth_chord_rank, @function
cr_synth_chord_rank:
.LFB906:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	leaq	trk(%rip), %rdx
	movq	%rdi, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movl	%eax, 20(%rsp)
	movl	$-1, (%rsp)
	cmpl	$2, %eax
	ja	.L1323
	movl	%esi, %ebx
	movzbl	cr_route(%rip), %edx
	movzbl	%dl, %edx
	cmpl	%eax, %edx
	jne	.L1323
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	je	.L1323
	leaq	752+cr(%rip), %rax
	leaq	-752(%rax), %rdi
	leaq	5504(%rax), %rcx
	movl	$0, %r14d
	jmp	.L1327
.L1326:
	movl	40(%rdx), %r14d
.L1325:
	addq	$172, %rax
	cmpq	%rcx, %rax
	je	.L1349
.L1327:
	movq	%rax, %rdx
	cmpb	$0, (%rax)
	je	.L1325
	cmpb	$0, 15(%rax)
	je	.L1325
	testl	%r14d, %r14d
	je	.L1326
	movl	40(%rax), %esi
	subl	%r14d, %esi
	testl	%esi, %esi
	jg	.L1326
	jmp	.L1325
.L1349:
	leaq	5504+cr(%rip), %r15
	movq	%rdi, %rcx
	movl	$0, %ebp
	movl	$0, %eax
	movl	$0, (%rsp)
	addq	$1, %rdi
	movl	$2863311531, %r13d
	movl	%r14d, 4(%rsp)
	movl	%eax, %r14d
	jmp	.L1334
.L1330:
	movl	4(%rsp), %esi
	cmpl	%esi, 792(%r9)
	je	.L1350
.L1332:
	testl	%r14d, %r14d
	je	.L1343
	movl	$1, %r14d
	cmpl	%r12d, (%rsp)
	jnb	.L1329
.L1343:
	movl	%r12d, (%rsp)
	movl	$1, %r14d
.L1329:
	addq	$1, %rax
	cmpq	%rax, %r10
	je	.L1351
.L1333:
	movzbl	780(%rax), %r8d
	movzbl	%r8b, %ecx
	addl	%r11d, %ecx
	movl	$127, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	testl	%ecx, %ecx
	movl	$0, %esi
	cmovs	%esi, %ecx
	cmpl	%ecx, %ebx
	jne	.L1329
	movswl	768(%r9), %esi
	movsbl	763(%r9), %ecx
	leal	1200(%rsi,%rcx), %esi
	movl	%esi, %ecx
	imulq	%r13, %rcx
	shrq	$35, %rcx
	leal	(%rcx,%rcx,2), %ecx
	sall	$2, %ecx
	subl	%ecx, %esi
	movl	$12, %ecx
	subl	%esi, %ecx
	movzbl	%r8b, %r8d
	leal	(%rcx,%r8), %esi
	movl	%esi, %ecx
	imulq	%r13, %rcx
	shrq	$35, %rcx
	leal	(%rcx,%rcx,2), %r8d
	sall	$2, %r8d
	movl	$5, %r12d
	subl	%r8d, %esi
	movl	%esi, %ecx
	je	.L1330
	cmpb	$1, 19(%rsp)
	setbe	%sil
	cmpb	$7, %dl
	sete	%r8b
	orl	%r8d, %esi
	movzbl	%sil, %esi
	movl	$4, %r8d
	subl	%esi, %r8d
	cmpl	%ecx, %r8d
	jne	.L1344
	movl	%edx, %esi
	andl	$-3, %esi
	movl	$6, %r12d
	cmpb	$4, %sil
	jne	.L1330
.L1344:
	movl	$4, %r12d
	cmpl	$7, %ecx
	je	.L1330
	movl	$0, %r12d
	cmpl	$9, %ecx
	je	.L1330
	subl	$10, %ecx
	cmpl	$2, %ecx
	sbbl	%r12d, %r12d
	andl	$-2, %r12d
	addl	$3, %r12d
	jmp	.L1330
.L1350:
	addl	$8, %r12d
	jmp	.L1332
.L1351:
	movq	8(%rsp), %rcx
.L1328:
	addq	$172, %rcx
	addq	$172, %rbp
	cmpq	%r15, %rcx
	je	.L1352
.L1334:
	movq	%rcx, %r9
	cmpb	$0, 752(%rcx)
	je	.L1328
	movzbl	767(%rcx), %r12d
	testb	%r12b, %r12b
	je	.L1328
	movzbl	779(%rcx), %eax
	movzbl	%al, %esi
	testb	%al, %al
	je	.L1328
	movl	20(%rsp), %eax
	leaq	cr_tr(%rip), %rdx
	movsbl	(%rdx,%rax), %r11d
	leaq	(%rdi,%rbp), %r10
	leal	-1(%rsi), %eax
	addq	%rax, %r10
	movq	%rcx, %rax
	leal	-1(%r12), %edx
	movb	%dl, 19(%rsp)
	movl	%r12d, %edx
	movq	%rcx, 8(%rsp)
	jmp	.L1333
.L1352:
	testl	%r14d, %r14d
	movl	$-1, %eax
	cmovne	(%rsp), %eax
	movl	%eax, (%rsp)
.L1323:
	movl	(%rsp), %eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE906:
	.size	cr_synth_chord_rank, .-cr_synth_chord_rank
	.type	cr_post, @function
cr_post:
.LFB913:
	.cfi_startproc
	movl	%esi, %r8d
	movl	cr_evq_w(%rip), %eax
	movl	cr_evq_r(%rip), %esi
	subl	%esi, %eax
	cmpl	$127, %eax
	ja	.L1356
	movl	cr_evq_w(%rip), %esi
	andl	$127, %esi
	imulq	$6, %rsi, %rsi
	leaq	cr_evq(%rip), %rax
	addq	%rsi, %rax
	movb	%dil, (%rax)
	movb	%r8b, 1(%rax)
	movb	%dl, 2(%rax)
	movw	%cx, 4(%rax)
	movl	cr_evq_w(%rip), %eax
	addl	$1, %eax
	movl	%eax, cr_evq_w(%rip)
	movl	$1, %eax
	ret
.L1356:
	movl	cr_evq_lost(%rip), %eax
	addl	$1, %eax
	movl	%eax, cr_evq_lost(%rip)
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE913:
	.size	cr_post, .-cr_post
	.type	cr_grid_feedback, @function
cr_grid_feedback:
.LFB914:
	.cfi_startproc
	movb	%dil, cr_grid_result(%rip)
	movl	cr_grid_result_serial(%rip), %eax
	addl	$1, %eax
	movl	%eax, cr_grid_result_serial(%rip)
	ret
	.cfi_endproc
.LFE914:
	.size	cr_grid_feedback, .-cr_grid_feedback
	.type	cr_loop_did, @function
cr_loop_did:
.LFB915:
	.cfi_startproc
	movb	%dil, crl_did(%rip)
	movl	crl_did_n(%rip), %eax
	addl	$1, %eax
	movl	%eax, crl_did_n(%rip)
	ret
	.cfi_endproc
.LFE915:
	.size	cr_loop_did, .-cr_loop_did
	.type	cr_idea_boundary, @function
cr_idea_boundary:
.LFB917:
	.cfi_startproc
	movzbl	15+cr_idea(%rip), %eax
	testb	%al, %al
	je	.L1359
	movl	4252+crl(%rip), %eax
	movl	%eax, cr_idea(%rip)
	movb	$1, 14+cr_idea(%rip)
	movb	$0, 15+cr_idea(%rip)
	movb	$-1, 16+cr_idea(%rip)
.L1359:
	ret
	.cfi_endproc
.LFE917:
	.size	cr_idea_boundary, .-cr_idea_boundary
	.type	cr_perform_map_build, @function
cr_perform_map_build:
.LFB920:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movzbl	cr_perform_base(%rip), %ecx
	leaq	cr_midi_mod_map(%rip), %rax
	leaq	11(%rax), %rdi
	movl	$0, %r9d
	movl	$0, %r8d
	movl	$2863311531, %r11d
	movl	$1354, %r10d
	leaq	white.24(%rip), %rbp
	leaq	black.25(%rip), %rbx
	jmp	.L1364
.L1363:
	cmpl	$4, %r8d
	ja	.L1362
	movl	%r8d, %edx
	movzbl	0(%rbp,%rdx), %edx
	movb	%dl, (%rax)
	leal	1(%r8), %r8d
.L1362:
	addq	$1, %rax
	addl	$1, %ecx
	cmpq	%rdi, %rax
	je	.L1367
.L1364:
	movb	$-2, (%rax)
	cmpl	$127, %ecx
	ja	.L1362
	movl	%ecx, %edx
	imulq	%r11, %rdx
	shrq	$35, %rdx
	leal	(%rdx,%rdx,2), %edx
	sall	$2, %edx
	movl	%ecx, %r12d
	subl	%edx, %r12d
	btl	%r12d, %r10d
	jnc	.L1363
	cmpl	$3, %r9d
	ja	.L1362
	movl	%r9d, %edx
	movzbl	(%rbx,%rdx), %edx
	movb	%dl, (%rax)
	leal	1(%r9), %r9d
	jmp	.L1362
.L1367:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE920:
	.size	cr_perform_map_build, .-cr_perform_map_build
	.type	cr_nudge_external_phase, @function
cr_nudge_external_phase:
.LFB943:
	.cfi_startproc
	movslq	cr_nudge_phase_samples(%rip), %rcx
	movzwl	20+cr(%rip), %eax
	imulq	%rax, %rcx
	salq	$20, %rcx
	movabsq	$-3826325998249183667, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$21, %rax
	sarq	$63, %rcx
	subl	%ecx, %eax
	ret
	.cfi_endproc
.LFE943:
	.size	cr_nudge_external_phase, .-cr_nudge_external_phase
	.type	cr_output_gain, @function
cr_output_gain:
.LFB946:
	.cfi_startproc
	cmpl	$32768, %edx
	je	.L1378
	movq	%rdi, %rax
	movl	%edx, %edi
	movzbl	fx_usb_fixed(%rip), %edx
	cmpb	$1, %dl
	sbbl	%ecx, %ecx
	andl	$5, %ecx
	addl	$2, %ecx
	addl	%esi, %esi
	leal	2(%rsi), %edx
	cmpl	%edx, %esi
	jnb	.L1378
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movzbl	fx_out_blk(%rip), %ebx
	movl	$1, %r8d
	sall	%cl, %r8d
	subl	$1, %r8d
	movl	%esi, %edx
	leaq	(%rax,%rdx,4), %rdx
	leal	2(%rsi), %r11d
	leaq	out_frac(%rip), %r10
	jmp	.L1374
.L1372:
	movl	%edi, %eax
	imull	(%rdx), %eax
	sarl	$15, %eax
	movl	%eax, (%rdx)
.L1373:
	addl	$1, %esi
	addq	$4, %rdx
	cmpl	%r11d, %esi
	je	.L1381
.L1374:
	testb	%bl, %bl
	je	.L1372
	movl	(%rdx), %eax
	sall	%cl, %eax
	movl	%esi, %r9d
	andl	$63, %r9d
	movzbl	(%r10,%r9), %ebp
	addl	%ebp, %eax
	movl	%eax, %ebp
	sarl	$8, %ebp
	imull	%edi, %ebp
	sarl	$7, %ebp
	movzbl	%al, %eax
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%ebp, %eax
	movl	%eax, %ebp
	sarl	%cl, %ebp
	movl	%ebp, (%rdx)
	andl	%r8d, %eax
	movb	%al, (%r10,%r9)
	jmp	.L1373
.L1381:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1378:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE946:
	.size	cr_output_gain, .-cr_output_gain
	.type	ux_mix, @function
ux_mix:
.LFB961:
	.cfi_startproc
	movl	%edx, %r9d
	cmpb	$0, 33+ux(%rip)
	jne	.L1392
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	$0, %r8d
	movl	$0, %eax
	leaq	SH.4(%rip), %r11
	leaq	MK.3(%rip), %r10
	movzwl	%di, %edi
	movzwl	%si, %esi
.L1383:
	movzbl	(%r11,%r8), %ecx
	movzbl	(%r10,%r8), %ebp
	movl	%edi, %ebx
	sarl	%cl, %ebx
	andl	%ebp, %ebx
	movl	%esi, %edx
	sarl	%cl, %edx
	andl	%ebp, %edx
	subl	%ebx, %edx
	imull	%r9d, %edx
	movl	%edx, %ebp
	sarl	$31, %ebp
	andl	$-100, %ebp
	leal	50(%rbp,%rdx), %ebp
	movslq	%ebp, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	sarl	$31, %ebp
	subl	%ebp, %edx
	addl	%ebx, %edx
	sall	%cl, %edx
	orl	%edx, %eax
	addq	$1, %r8
	cmpq	$3, %r8
	jne	.L1383
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1392:
	.cfi_restore 3
	.cfi_restore 6
	shrw	$11, %di
	movzwl	%di, %edi
	shrw	$11, %si
	movzwl	%si, %esi
	subl	%edi, %esi
	imull	%edx, %esi
	movl	%esi, %eax
	sarl	$31, %eax
	andl	$-100, %eax
	leal	50(%rax,%rsi), %eax
	movl	$100, %ecx
	cltd
	idivl	%ecx
	leal	(%rax,%rdi), %edx
	movl	%edx, %eax
	sall	$11, %eax
	movl	%edx, %ecx
	sall	$6, %ecx
	orl	%ecx, %eax
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE961:
	.size	ux_mix, .-ux_mix
	.type	palette_set, @function
palette_set:
.LFB963:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movl	%edi, %ebp
	imulq	$954437177, %rbp, %rbp
	shrq	$33, %rbp
	leal	0(%rbp,%rbp,8), %eax
	subl	%eax, %edi
	movl	%edi, %ebp
	sete	33+ux(%rip)
	leaq	UI_PALETTES(%rip), %rcx
	movl	%edi, %edx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rdx), %rsi
	movzwl	8(%rcx,%rsi,8), %ebx
	movw	%bx, ux(%rip)
	movzwl	10(%rcx,%rsi,8), %esi
	movw	%si, 4(%rsp)
	movw	%si, 2+ux(%rip)
	leaq	(%rax,%rdx), %rsi
	movzwl	12(%rcx,%rsi,8), %r12d
	movw	%r12w, 4+ux(%rip)
	movzwl	14(%rcx,%rsi,8), %r13d
	movw	%r13w, 6+ux(%rip)
	movzwl	16(%rcx,%rsi,8), %r15d
	movw	%r15w, 8+ux(%rip)
	movzwl	%r12w, %r12d
	movzwl	%bx, %r14d
	movl	$70, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 10+ux(%rip)
	movl	$42, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 12+ux(%rip)
	movl	$18, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 14+ux(%rip)
	movzwl	%r13w, %r13d
	movl	$80, %edx
	movl	%r13d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 16+ux(%rip)
	movl	$12, %edx
	movl	%r13d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 18+ux(%rip)
	movw	%bx, 20+ux(%rip)
	movzwl	4(%rsp), %eax
	movl	$12, %edx
	movl	%r12d, %esi
	movl	%eax, 4(%rsp)
	movl	%eax, %edi
	call	ux_mix
	movw	%ax, 24+ux(%rip)
	movl	$78, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 26+ux(%rip)
	movl	$10, %edx
	movl	%r13d, %esi
	movl	4(%rsp), %r14d
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 28+ux(%rip)
	movl	$6, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 30+ux(%rip)
	movl	%ebx, %edx
	shrw	$11, %dx
	movzwl	%dx, %edx
	movl	%edx, %eax
	sall	$8, %eax
	subl	%edx, %eax
	movl	%eax, %ecx
	imulq	$138547333, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	movl	%eax, %edx
	shrl	%edx
	addl	%ecx, %edx
	shrl	$4, %edx
	imull	$54, %edx, %edx
	movl	%ebx, %ecx
	andl	$31, %ecx
	movl	%ecx, %eax
	sall	$8, %eax
	subl	%ecx, %eax
	movl	%eax, %ecx
	imulq	$138547333, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	shrl	%eax
	addl	%ecx, %eax
	shrl	$4, %eax
	leal	(%rax,%rax,8), %ecx
	leal	(%rax,%rcx,2), %eax
	addl	%eax, %edx
	shrw	$5, %bx
	andl	$63, %ebx
	movl	%ebx, %eax
	sall	$8, %eax
	subl	%ebx, %eax
	movl	%eax, %ecx
	imulq	$68174085, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	shrl	%eax
	addl	%ecx, %eax
	shrl	$5, %eax
	imull	$183, %eax, %eax
	addl	%eax, %edx
	movl	%edx, %eax
	shrl	$8, %eax
	cmpl	$33023, %edx
	seta	32+ux(%rip)
	testl	%ebp, %ebp
	je	.L1398
	cmpl	$129, %eax
	sbbl	%r15d, %r15d
	andw	$16772, %r15w
	subw	$18235, %r15w
.L1398:
	movw	%r15w, 22+ux(%rip)
	addl	$1, 36+ux(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE963:
	.size	palette_set, .-palette_set
	.type	palette_from_stored, @function
palette_from_stored:
.LFB964:
	.cfi_startproc
	leal	-64(%rdi), %eax
	cmpl	$8, %eax
	jbe	.L1401
	movl	$0, %eax
	cmpl	$19, %edi
	ja	.L1401
	movl	%edi, %edi
	leaq	UI_PALETTE_MIGRATE(%rip), %rax
	movzbl	(%rax,%rdi), %eax
.L1401:
	ret
	.cfi_endproc
.LFE964:
	.size	palette_from_stored, .-palette_from_stored
	.type	panel_init, @function
panel_init:
.LFB997:
	.cfi_startproc
	cmpl	$1346457141, panel(%rip)
	jne	.L1405
	leaq	4+panel(%rip), %rax
	leaq	14(%rax), %rdi
	movl	$0, %edx
	movl	$1, %r8d
	jmp	.L1406
.L1414:
	orl	%ecx, %edx
	addq	$1, %rax
	cmpq	%rdi, %rax
	je	.L1413
.L1406:
	movzbl	(%rax), %ecx
	cmpb	$13, %cl
	ja	.L1405
	movl	%r8d, %esi
	sall	%cl, %esi
	movl	%esi, %ecx
	andl	%edx, %esi
	je	.L1414
.L1405:
	movl	$1346457141, panel(%rip)
	movabsq	$650777868590383874, %rax
	movq	%rax, 4+panel(%rip)
	movabsq	$72071939413903624, %rax
	movq	%rax, 10+panel(%rip)
	movl	$33947904, 18+panel(%rip)
	movl	$84148994, 21+panel(%rip)
	movl	$16843009, 25+panel(%rip)
	movl	$16843009, 28+panel(%rip)
	ret
.L1416:
	orl	%edx, %esi
	addq	$1, %rax
	cmpq	%r8, %rax
	je	.L1415
.L1408:
	movzbl	(%rax), %ecx
	cmpb	$6, %cl
	ja	.L1405
	movl	%r9d, %edx
	sall	%cl, %edx
	testl	%esi, %edx
	jne	.L1405
	movzbl	7(%rax), %ecx
	addl	$1, %ecx
	testb	$-3, %cl
	jne	.L1405
	jmp	.L1416
.L1415:
	ret
.L1413:
	leaq	18+panel(%rip), %rax
	leaq	7(%rax), %r8
	movl	$1, %r9d
	jmp	.L1408
	.cfi_endproc
.LFE997:
	.size	panel_init, .-panel_init
	.type	settings_init, @function
settings_init:
.LFB1006:
	.cfi_startproc
	movl	settings(%rip), %eax
	cmpl	$1397052467, %eax
	je	.L1422
	cmpl	$1397052468, %eax
	je	.L1420
.L1419:
	movl	$1397052468, settings(%rip)
	movl	$0, 4+settings(%rip)
	movl	$0, 8+settings(%rip)
	movl	$0, 12+settings(%rip)
.L1421:
	movl	4+settings(%rip), %edi
	call	palette_set
	movl	8+settings(%rip), %edx
	movl	%edx, %eax
	movl	$2863311531, %ecx
	imulq	%rcx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %eax
	subl	%eax, %edx
	movb	%dl, fx_lowcut(%rip)
	ret
.L1422:
	movl	4+settings(%rip), %edi
	cmpl	$19, %edi
	ja	.L1419
	movl	$1397052468, settings(%rip)
	call	palette_from_stored
	movl	%eax, 4+settings(%rip)
.L1420:
	cmpl	$8, 4+settings(%rip)
	jbe	.L1421
	jmp	.L1419
	.cfi_endproc
.LFE1006:
	.size	settings_init, .-settings_init
	.type	cr_sin, @function
cr_sin:
.LFB1015:
	.cfi_startproc
	movl	%edi, %esi
	shrl	$14, %esi
	movl	%edi, %ecx
	andl	$16383, %ecx
	testl	$16384, %edi
	je	.L1424
	movl	$16384, %eax
	subl	%ecx, %eax
	movl	%eax, %ecx
	shrl	$8, %ecx
	movl	$16384, %edx
	cmpl	$16383, %eax
	jbe	.L1430
.L1425:
	movl	%edx, %eax
	negl	%eax
	testb	$2, %sil
	cmovne	%eax, %edx
	movl	%edx, %eax
	ret
.L1430:
	movzbl	%al, %edi
	jmp	.L1427
.L1424:
	shrl	$8, %ecx
	movzbl	%dil, %edi
.L1427:
	leaq	CR_SIN(%rip), %rdx
	movl	%ecx, %eax
	movswl	(%rdx,%rax,2), %eax
	addl	$1, %ecx
	movl	%ecx, %ecx
	movswl	(%rdx,%rcx,2), %edx
	subl	%eax, %edx
	imull	%edi, %edx
	sarl	$8, %edx
	addl	%eax, %edx
	jmp	.L1425
	.cfi_endproc
.LFE1015:
	.size	cr_sin, .-cr_sin
	.type	cr_arc_px, @function
cr_arc_px:
.LFB1022:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	sall	$4, %esi
	movl	%esi, %r14d
	leal	8(%rsi), %r10d
	subl	(%rdi), %r10d
	sall	$4, %edx
	leal	8(%rdx), %ecx
	movl	4(%rdi), %esi
	movl	%ecx, %r12d
	subl	%esi, %r12d
	movl	%r10d, %r9d
	imull	%r10d, %r9d
	movl	%r12d, %eax
	imull	%r12d, %eax
	addl	%eax, %r9d
	movl	12(%rdi), %eax
	addl	$12, %eax
	imull	%eax, %eax
	movl	$0, %r8d
	cmpl	%r9d, %eax
	jl	.L1431
	movl	%edx, %r15d
	movl	16(%rdi), %edx
	leal	-12(%rdx), %eax
	imull	%eax, %eax
	cmpl	%r9d, %eax
	jle	.L1469
	cmpl	$12, %edx
	jg	.L1431
.L1469:
	movl	%r10d, %eax
	negl	%eax
	cmovs	%r10d, %eax
	movl	%r12d, %edx
	negl	%edx
	cmovs	%r12d, %edx
	movl	$0, -16(%rsp)
	movl	%eax, %ebx
	orl	%edx, %ebx
	je	.L1434
	movl	%eax, %r11d
	movl	%edx, %r8d
	cmpl	%edx, %eax
	jb	.L1435
	movl	%edx, %eax
	sall	$12, %eax
	movl	$0, %edx
	divl	%r11d
	movl	%eax, %r11d
	shrl	$6, %r11d
	movl	%r11d, %r8d
	leaq	CR_ATAN(%rip), %rdx
	movzwl	(%rdx,%r8,2), %ebx
	movzwl	%bx, %edx
	movl	$0, %r8d
	cmpl	$63, %r11d
	ja	.L1436
	leal	1(%r11), %r8d
	movl	%r8d, %r8d
	leaq	CR_ATAN(%rip), %r11
	movzwl	(%r11,%r8,2), %r8d
	subl	%edx, %r8d
	andl	$63, %eax
	imull	%eax, %r8d
	shrl	$6, %r8d
.L1436:
	leal	(%rdx,%r8), %eax
.L1437:
	movl	$32768, %edx
	subl	%eax, %edx
	testl	%r10d, %r10d
	cmovs	%edx, %eax
	movl	$65536, %edx
	subl	%eax, %edx
	testl	%r12d, %r12d
	cmovs	%edx, %eax
	movzwl	%ax, %eax
	movl	%eax, -16(%rsp)
.L1434:
	movl	%r9d, %r8d
	cmpl	$1073741823, %r9d
	ja	.L1460
	movl	$1073741824, %eax
.L1442:
	shrl	$2, %eax
	cmpl	%eax, %r8d
	jb	.L1442
	testl	%eax, %eax
	je	.L1475
.L1441:
	movl	$0, %edx
	jmp	.L1446
.L1435:
	sall	$12, %eax
	movl	$0, %edx
	divl	%r8d
	movl	%eax, %r8d
	shrl	$6, %r8d
	movl	%r8d, %r11d
	leaq	CR_ATAN(%rip), %rdx
	movzwl	(%rdx,%r11,2), %ebx
	movzwl	%bx, %r11d
	movl	$0, %edx
	cmpl	$63, %r8d
	ja	.L1438
	leal	1(%r8), %edx
	movl	%edx, %edx
	leaq	CR_ATAN(%rip), %r8
	movzwl	(%r8,%rdx,2), %edx
	subl	%r11d, %edx
	andl	$63, %eax
	imull	%eax, %edx
	shrl	$6, %edx
.L1438:
	movl	$16384, %eax
	subl	%r11d, %eax
	subl	%edx, %eax
	jmp	.L1437
.L1460:
	movl	$1073741824, %eax
	jmp	.L1441
.L1444:
	shrl	%edx
.L1445:
	shrl	$2, %eax
	je	.L1443
.L1446:
	leal	(%rdx,%rax), %r9d
	cmpl	%r9d, %r8d
	jb	.L1444
	subl	%r9d, %r8d
	shrl	%edx
	addl	%eax, %edx
	jmp	.L1445
.L1475:
	movl	%eax, %edx
.L1443:
	testl	%edx, %edx
	movl	$1, %eax
	cmovg	%edx, %eax
	movl	%eax, -12(%rsp)
	movl	72(%rdi), %ebx
	movl	%ebx, -8(%rsp)
	movl	$-1, -28(%rsp)
	testl	%ebx, %ebx
	jne	.L1447
	cmpl	$0, 56(%rdi)
	jne	.L1447
	movl	-16(%rsp), %r8d
	subl	60(%rdi), %r8d
	movzwl	%r8w, %r8d
	movl	%eax, %ebx
	leal	1(%rax), %eax
	imull	$88508, %eax, %eax
	movl	%ebx, %r9d
	imull	%ebx, %r9d
	cltd
	idivl	%r9d
	addl	$1, %eax
	cmpl	%eax, %r8d
	jb	.L1448
	leal	(%r8,%rax), %edx
	movl	$1, -28(%rsp)
	cmpl	%edx, 64(%rdi)
	jnb	.L1447
.L1448:
	movl	%eax, %edx
	addl	64(%rdi), %edx
	movl	$-1, -28(%rsp)
	cmpl	%r8d, %edx
	jnb	.L1447
	addl	%eax, %r8d
	cmpl	$65535, %r8d
	seta	%al
	movzbl	%al, %eax
	negl	%eax
	movl	%eax, -28(%rsp)
.L1447:
	movl	20(%rdi), %ebp
	leaq	4+CR_SS(%rip), %rbx
	leaq	-4(%rbx), %r13
	movl	$0, %r8d
	subl	%ecx, %esi
	movl	%esi, -4(%rsp)
	movl	%r15d, -20(%rsp)
	movl	%r12d, %r15d
	jmp	.L1449
.L1478:
	movl	-4(%rsp), %edx
	imull	%edx, %eax
	movl	-24(%rsp), %edx
	imull	%r10d, %edx
	addl	%edx, %eax
	imull	$10430, %eax, %eax
	movl	-12(%rsp), %r12d
	cltd
	idivl	%r12d
	cltd
	idivl	%r12d
	movl	-16(%rsp), %edx
	subl	60(%rdi), %edx
	addl	%edx, %eax
	movzwl	%ax, %eax
	cmpl	$0, -8(%rsp)
	jne	.L1452
	cmpl	%eax, 64(%rdi)
	jb	.L1450
.L1452:
	movl	56(%rdi), %r12d
	movl	$1, %edx
	testl	%r12d, %r12d
	je	.L1453
	imull	48(%rdi), %eax
	shrl	$16, %eax
	cltd
	idivl	%r12d
	cmpl	52(%rdi), %edx
	jl	.L1476
.L1450:
	movl	68(%rdi), %edx
	testl	%edx, %edx
	je	.L1453
	addl	%r14d, %ecx
	movl	%ecx, %edx
	subl	32(%rdi), %edx
	movl	%r11d, %eax
	subl	36(%rdi), %eax
	movl	28(%rdi), %r12d
	imull	%edx, %edx
	imull	%eax, %eax
	addl	%edx, %eax
	movl	$1, %edx
	cmpl	%r12d, %eax
	jle	.L1453
	subl	40(%rdi), %ecx
	movl	%r11d, %eax
	subl	44(%rdi), %eax
	imull	%ecx, %ecx
	imull	%eax, %eax
	addl	%eax, %ecx
	cmpl	%ecx, %r12d
	setge	%dl
	movzbl	%dl, %edx
.L1453:
	addl	%edx, %r8d
	addq	$1, %rsi
	cmpq	%rbx, %rsi
	je	.L1477
.L1454:
	movzbl	(%rsi), %ecx
	leal	-8(%rcx), %eax
	leal	(%r10,%rax), %edx
	imull	%edx, %edx
	addl	%r9d, %edx
	cmpl	%edx, %ebp
	jl	.L1450
	cmpl	%edx, 24(%rdi)
	jg	.L1450
	cmpl	$0, -28(%rsp)
	js	.L1478
	movl	$1, %edx
	cmpl	$0, -28(%rsp)
	je	.L1450
	jmp	.L1453
.L1476:
	movl	$1, %edx
	jmp	.L1453
.L1477:
	addq	$1, %r13
	cmpq	%rbx, %r13
	je	.L1431
.L1449:
	movzbl	0(%r13), %r11d
	leal	-8(%r11), %r12d
	leal	(%r15,%r12), %r9d
	imull	%r9d, %r9d
	movl	-20(%rsp), %eax
	addl	%eax, %r11d
	leaq	CR_SS(%rip), %rsi
	movl	%r12d, -24(%rsp)
	jmp	.L1454
.L1431:
	movl	%r8d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1022:
	.size	cr_arc_px, .-cr_arc_px
	.type	st_crc32, @function
st_crc32:
.LFB1125:
	.cfi_startproc
	movq	%rdi, %rcx
	leal	-1(%rsi), %eax
	testl	%esi, %esi
	je	.L1482
	movl	%eax, %eax
	leaq	1(%rdi,%rax), %rdi
	movl	$-1, %edx
	leaq	T.0(%rip), %rsi
.L1481:
	addq	$1, %rcx
	movzbl	-1(%rcx), %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$4, %edx
	andl	$15, %eax
	xorl	(%rsi,%rax,4), %edx
	movl	%edx, %eax
	shrl	$4, %eax
	andl	$15, %edx
	xorl	(%rsi,%rdx,4), %eax
	movl	%eax, %edx
	cmpq	%rdi, %rcx
	jne	.L1481
.L1480:
	movl	%edx, %eax
	notl	%eax
	ret
.L1482:
	movl	$-1, %edx
	jmp	.L1480
	.cfi_endproc
.LFE1125:
	.size	st_crc32, .-st_crc32
	.type	param_kept, @function
param_kept:
.LFB1141:
	.cfi_startproc
	cmpl	$82, %edi
	ja	.L1487
	cmpl	$38, %edi
	jbe	.L1489
	leal	-39(%rdi), %ecx
	movabsq	$13194139534275, %rax
	shrq	%cl, %rax
	andl	$1, %eax
	ret
.L1489:
	movl	$1, %eax
	testl	%edi, %edi
	je	.L1484
	subl	$17, %edi
	cmpl	$15, %edi
	setbe	%al
	movzbl	%al, %eax
	ret
.L1487:
	movl	$0, %eax
.L1484:
	ret
	.cfi_endproc
.LFE1141:
	.size	param_kept, .-param_kept
	.type	up_valid, @function
up_valid:
.LFB1148:
	.cfi_startproc
	movl	$0, %eax
	cmpb	$-91, (%rdi)
	jne	.L1490
	movzbl	1(%rdi), %edx
	leal	-1(%rdx), %ecx
	cmpb	$5, %cl
	jbe	.L1510
.L1490:
	ret
.L1510:
	movzbl	2(%rdi), %esi
	cmpb	$29, %sil
	ja	.L1490
	movzbl	3(%rdi), %r8d
	cmpb	$7, %r8b
	jbe	.L1490
	movzbl	%r8b, %r9d
	cmpb	$4, %dl
	sbbl	%ecx, %ecx
	andl	$-72, %ecx
	addl	$144, %ecx
	cmpl	%r9d, %ecx
	jb	.L1490
	cmpb	$0, 4(%rdi)
	je	.L1501
	cmpb	$6, %dl
	je	.L1501
	leal	-20(%rsi), %eax
	cmpb	$1, %al
	jbe	.L1502
	cmpb	$14, %sil
	je	.L1502
	cmpb	$24, %sil
	je	.L1511
.L1493:
	movl	$1, %eax
	cmpb	$3, %dl
	jbe	.L1490
	leaq	16(%rdi), %rax
	leal	-1(%r9), %edx
	leaq	17(%rdi,%rdx), %rdx
.L1494:
	cmpb	$-65, (%rax)
	ja	.L1506
	addq	$1, %rax
	cmpq	%rax, %rdx
	jne	.L1494
	cmpb	$16, %sil
	jne	.L1507
	cmpb	$91, %r8b
	jbe	.L1512
.L1507:
	movl	$1, %eax
	ret
.L1511:
	movl	$0, %eax
	cmpb	$112, %r8b
	ja	.L1490
	cmpw	$19523, 158(%rdi)
	jne	.L1490
	jmp	.L1493
.L1512:
	cmpw	$13648, 158(%rdi)
	jne	.L1508
	movsbl	157(%rdi), %eax
	notl	%eax
	shrl	$31, %eax
	ret
.L1501:
	movl	$0, %eax
	ret
.L1502:
	movl	$0, %eax
	ret
.L1506:
	movl	$0, %eax
	ret
.L1508:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE1148:
	.size	up_valid, .-up_valid
	.type	up_used, @function
up_used:
.LFB1149:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$63, %edi
	ja	.L1513
	movl	%edi, %eax
	andl	$15, %eax
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rax
	shrl	$4, %edi
	movl	%edi, %edi
	imulq	$3080, %rdi, %rdi
	leaq	8(%rax,%rdi), %rdi
	leaq	up_bank(%rip), %rax
	addq	%rax, %rdi
	call	up_valid
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
.L1513:
	ret
	.cfi_endproc
.LFE1149:
	.size	up_used, .-up_used
	.type	up_value, @function
up_value:
.LFB1151:
	.cfi_startproc
	movq	%rdi, %rdx
	movzbl	1(%rdi), %eax
	cmpb	$6, %al
	je	.L1529
	movzbl	2(%rdi), %ecx
	cmpb	$3, %al
	seta	%dil
	cmpb	$19, %cl
	jne	.L1521
	testb	%dil, %dil
	jne	.L1530
.L1521:
	cmpb	$24, %cl
	jne	.L1525
	testb	%dil, %dil
	jne	.L1531
.L1525:
	cmpb	$3, %al
	ja	.L1522
	movl	%esi, %esi
	movzwl	16(%rdx,%rsi,2), %eax
	ret
.L1529:
	movl	$0, %eax
	leaq	UP_CS1_COMMON(%rip), %rdi
.L1520:
	movzbl	(%rdi,%rax), %ecx
	cmpl	%ecx, %esi
	je	.L1532
	addq	$1, %rax
	cmpq	$41, %rax
	jne	.L1520
	movl	$0, %eax
	ret
.L1532:
	addl	$102, %eax
	cltq
	movzbl	16(%rdx,%rax), %eax
	subl	$64, %eax
	ret
.L1530:
	movzbl	3(%rdx), %ecx
	leal	1(%rsi), %eax
	cmpl	%ecx, %eax
	je	.L1533
.L1522:
	movl	%esi, %esi
	movzbl	16(%rdx,%rsi), %eax
	subl	$64, %eax
	ret
.L1533:
	cmpb	$77, 158(%rdx)
	jne	.L1522
	movzbl	159(%rdx), %eax
	cmpb	$57, %al
	je	.L1534
	cmpb	$56, %al
	jne	.L1522
	movzbl	157(%rdx), %eax
	sall	$8, %eax
	movzbl	156(%rdx), %esi
	orl	%esi, %eax
	leal	-7(%rcx), %ecx
	movzbl	16(%rdx,%rcx), %edx
	movzbl	%dl, %esi
	subl	$64, %esi
	cmpb	$63, %dl
	movl	$0, %edx
	cmovbe	%edx, %esi
	movl	%eax, %ecx
	imulq	$68174085, %rcx, %rcx
	shrq	$32, %rcx
	movl	%eax, %edx
	subl	%ecx, %edx
	shrl	%edx
	addl	%ecx, %edx
	shrl	$5, %edx
	movl	%edx, %ecx
	sall	$6, %ecx
	subl	%edx, %ecx
	subl	%ecx, %eax
	addl	$1, %eax
	sall	$8, %eax
	orl	%esi, %eax
	ret
.L1534:
	movzbl	157(%rdx), %eax
	sall	$7, %eax
	movzbl	156(%rdx), %edx
	orl	%edx, %eax
	ret
.L1531:
	movzbl	3(%rdx), %eax
	leal	-8(%rax), %ecx
	cmpl	%ecx, %esi
	jb	.L1522
	cmpl	%eax, %esi
	jnb	.L1522
	subl	%eax, %esi
	leal	128(%rsi,%rsi), %ecx
	leal	1(%rcx), %eax
	movzbl	16(%rdx,%rax), %eax
	sall	$8, %eax
	movl	%ecx, %ecx
	movzbl	16(%rdx,%rcx), %edx
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE1151:
	.size	up_value, .-up_value
	.type	va_store_valid, @function
va_store_valid:
.LFB1162:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$827539798, (%rdi)
	jne	.L1544
	cmpl	$2097155, 4(%rdi)
	jne	.L1544
	cmpw	$110, 12(%rdi)
	jne	.L1544
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	8(%rdi), %r12d
	leaq	16(%rdi), %rbx
	movl	$0, %ebp
	jmp	.L1538
.L1537:
	addl	$1, %ebp
	addq	$110, %rbx
	cmpl	$32, %ebp
	je	.L1547
.L1538:
	btl	%ebp, %r12d
	jnc	.L1537
	movq	%rbx, %rdi
	call	va_blob_ok
	testl	%eax, %eax
	jne	.L1537
	jmp	.L1535
.L1547:
	movl	$1, %eax
.L1535:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1544:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	ret
	.cfi_endproc
.LFE1162:
	.size	va_store_valid, .-va_store_valid
	.type	fm6u_valid, @function
fm6u_valid:
.LFB1171:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$200, %rsp
	.cfi_def_cfa_offset 240
	movq	%fs:40, %rax
	movq	%rax, 184(%rsp)
	xorl	%eax, %eax
	cmpl	$1429622086, (%rdi)
	jne	.L1548
	movq	%rdi, %rbx
	cmpl	$1048577, 4(%rdi)
	jne	.L1548
	movzwl	8(%rdi), %edx
	sall	$4, %esi
	cmpl	%esi, %edx
	jne	.L1548
	cmpw	$128, 10(%rdi)
	jne	.L1548
	movzwl	14(%rdi), %ebp
	testl	%ebp, %ebp
	jne	.L1548
	leaq	16(%rdi), %r12
	movq	%rsp, %r13
	jmp	.L1551
.L1550:
	addl	$1, %ebp
	subq	$-128, %r12
	cmpl	$16, %ebp
	je	.L1560
.L1551:
	movl	12(%rbx), %eax
	btl	%ebp, %eax
	jnc	.L1550
	leaq	16(%rsp), %rsi
	movq	%r13, %rdx
	movq	%r12, %rdi
	call	fm6_blob_read
	testl	%eax, %eax
	jne	.L1550
	jmp	.L1548
.L1560:
	movl	$1, %eax
.L1548:
	movq	184(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1561
	addq	$200, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1561:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1171:
	.size	fm6u_valid, .-fm6u_valid
	.type	quad_store_valid, @function
quad_store_valid:
.LFB1179:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$1396987217, (%rdi)
	jne	.L1571
	cmpl	$2097153, 4(%rdi)
	jne	.L1571
	cmpw	$80, 12(%rdi)
	jne	.L1571
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	8(%rdi), %r12d
	leaq	16(%rdi), %rbx
	movl	$0, %ebp
	jmp	.L1565
.L1564:
	addl	$1, %ebp
	addq	$80, %rbx
	cmpl	$32, %ebp
	je	.L1574
.L1565:
	btl	%ebp, %r12d
	jnc	.L1564
	movq	%rbx, %rdi
	call	quad_blob_ok
	testl	%eax, %eax
	jne	.L1564
	jmp	.L1562
.L1574:
	movl	$1, %eax
.L1562:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1571:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	ret
	.cfi_endproc
.LFE1179:
	.size	quad_store_valid, .-quad_store_valid
	.type	fm6_bank_valid, @function
fm6_bank_valid:
.LFB1189:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$1110854982, (%rdi)
	jne	.L1575
	cmpl	$2097154, 4(%rdi)
	jne	.L1575
	movl	$0, %eax
	leaq	FM6_FNMAX(%rip), %rdx
.L1577:
	movzbl	12(%rdi,%rax), %ecx
	cmpb	%cl, (%rdx,%rax)
	jb	.L1580
	addq	$1, %rax
	cmpq	$16, %rax
	jne	.L1577
	movl	$1, %eax
	ret
.L1580:
	movl	$0, %eax
.L1575:
	ret
	.cfi_endproc
.LFE1189:
	.size	fm6_bank_valid, .-fm6_bank_valid
	.type	fm6_bank_get, @function
fm6_bank_get:
.LFB1190:
	.cfi_startproc
	endbr64
	movl	%edi, %eax
	movq	%rsi, %rdi
	movl	$1, %edx
	cmpl	$31, %eax
	ja	.L1582
	cmpl	$1110854982, fm6_bank(%rip)
	jne	.L1582
	movl	8+fm6_bank(%rip), %ecx
	btl	%eax, %ecx
	jc	.L1587
.L1582:
	movl	%edx, %eax
	ret
.L1587:
	movl	%eax, %eax
	leaq	0(,%rax,8), %rdx
	subq	%rax, %rdx
	movq	%rdx, %rax
	salq	$4, %rax
	leaq	fm6_bank(%rip), %rdx
	leaq	28(%rdx,%rax), %rsi
	movl	$128, %edx
	call	fm6_unpack7
	movl	$0, %edx
	jmp	.L1582
	.cfi_endproc
.LFE1190:
	.size	fm6_bank_get, .-fm6_bank_get
	.type	upx_native_len, @function
upx_native_len:
.LFB1200:
	.cfi_startproc
	cmpl	$14, %edi
	je	.L1591
	ja	.L1590
	movl	$128, %eax
	cmpl	$12, %edi
	je	.L1588
	cmpl	$13, %edi
	movl	$110, %eax
	movl	$0, %edx
	cmovne	%edx, %eax
	ret
.L1590:
	cmpl	$15, %edi
	movl	$80, %eax
	movl	$0, %edx
	cmovne	%edx, %eax
	ret
.L1591:
	movl	$144, %eax
.L1588:
	ret
	.cfi_endproc
.LFE1200:
	.size	upx_native_len, .-upx_native_len
	.type	cb_trim, @function
cb_trim:
.LFB1232:
	.cfi_startproc
	leaq	CB_TRIM(%rip), %rdx
	movl	$0, %eax
	leaq	cb_trim_k(%rip), %r8
	jmp	.L1598
.L1596:
	addq	$1, %rax
	addq	$24, %rdx
	cmpq	$5, %rax
	je	.L1600
.L1598:
	movzbl	(%rdx), %ecx
	cmpl	%edi, %ecx
	jne	.L1596
	movzbl	(%r8,%rax), %ecx
	cmpl	%esi, %ecx
	jne	.L1596
	movl	%eax, %eax
	imulq	$24, %rax, %rax
	leaq	CB_TRIM(%rip), %rdx
	movzbl	16(%rdx,%rax), %eax
	ret
.L1600:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE1232:
	.size	cb_trim, .-cb_trim
	.type	pool_nf, @function
pool_nf:
.LFB1234:
	.cfi_startproc
	movl	%edi, %eax
	movl	$2290649225, %edx
	imulq	%rdx, %rax
	shrq	$36, %rax
	imull	$30, %eax, %eax
	subl	%eax, %edi
	leaq	ENGINES(%rip), %rax
	movq	(%rax,%rdi,8), %rax
	movzbl	288(%rax), %eax
	ret
	.cfi_endproc
.LFE1234:
	.size	pool_nf, .-pool_nf
	.type	cu_cpy, @function
cu_cpy:
.LFB1273:
	.cfi_startproc
	testl	%edx, %edx
	je	.L1602
	testq	%rsi, %rsi
	je	.L1607
	leal	-1(%rdx), %r8d
	movl	$0, %eax
	jmp	.L1605
.L1606:
	movb	%dl, (%rdi,%rax)
	addq	$1, %rax
.L1605:
	movl	%eax, %ecx
	movzbl	(%rsi,%rax), %edx
	testb	%dl, %dl
	je	.L1604
	cmpq	%r8, %rax
	jne	.L1606
.L1604:
	movl	%ecx, %ecx
	movb	$0, (%rdi,%rcx)
.L1602:
	ret
.L1607:
	movl	$0, %ecx
	jmp	.L1604
	.cfi_endproc
.LFE1273:
	.size	cu_cpy, .-cu_cpy
	.type	cu_cat, @function
cu_cat:
.LFB1274:
	.cfi_startproc
	testl	%edx, %edx
	je	.L1608
	movq	%rdi, %rcx
	movl	$0, %eax
.L1610:
	cmpb	$0, (%rcx)
	je	.L1612
	addl	$1, %eax
	addq	$1, %rcx
	cmpl	%eax, %edx
	jne	.L1610
.L1608:
	ret
.L1612:
	cmpl	%edx, %eax
	jnb	.L1608
	subl	%eax, %edx
	movl	%eax, %eax
	addq	%rax, %rdi
	call	cu_cpy
	ret
	.cfi_endproc
.LFE1274:
	.size	cu_cat, .-cu_cat
	.type	cu_engine_melodic, @function
cu_engine_melodic:
.LFB1281:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	call	eng_ok
	cmpl	$10, %ebx
	je	.L1615
	testl	%eax, %eax
	jne	.L1617
.L1615:
	movl	$0, %eax
.L1613:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1617:
	.cfi_restore_state
	movl	%ebx, %ebx
	leaq	ENGINES(%rip), %rax
	movq	(%rax,%rbx,8), %rax
	cmpb	$0, 288(%rax)
	setne	%al
	movzbl	%al, %eax
	jmp	.L1613
	.cfi_endproc
.LFE1281:
	.size	cu_engine_melodic, .-cu_engine_melodic
	.type	cu_loop_conf, @function
cu_loop_conf:
.LFB1294:
	.cfi_startproc
	movzbl	212+cs(%rip), %ecx
	movl	$8, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	213+cs(%rip), %ecx
	movl	$0, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	214+cs(%rip), %ecx
	movl	$1, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	215+cs(%rip), %ecx
	movl	$2, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	216+cs(%rip), %ecx
	movl	$3, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	207+cs(%rip), %ecx
	movl	$4, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	208+cs(%rip), %ecx
	movl	$5, %edx
	movl	$6, %esi
	movl	$25, %edi
	call	cr_post
	movzbl	206+cs(%rip), %ecx
	movl	$0, %edx
	movl	$7, %esi
	movl	$25, %edi
	call	cr_post
	ret
	.cfi_endproc
.LFE1294:
	.size	cu_loop_conf, .-cu_loop_conf
	.type	cu_set_tempo, @function
cu_set_tempo:
.LFB1295:
	.cfi_startproc
	movl	$20, %ecx
	cmpl	$19, %edi
	jle	.L1620
	cmpl	$300, %edi
	movl	$300, %ecx
	cmovle	%edi, %ecx
.L1620:
	movw	%cx, 20+cs(%rip)
	movl	$240, %eax
	cmpw	%ax, %cx
	cmovbe	%ecx, %eax
	movl	$40, %edx
	cmpw	%dx, %ax
	cmovb	%edx, %eax
	movw	%ax, song(%rip)
	movzwl	%cx, %ecx
	movl	$0, %edx
	movl	$0, %esi
	movl	$22, %edi
	call	cr_post
	ret
	.cfi_endproc
.LFE1295:
	.size	cu_set_tempo, .-cu_set_tempo
	.type	cu_fx_apply, @function
cu_fx_apply:
.LFB1296:
	.cfi_startproc
	cmpb	$0, 132+cs(%rip)
	je	.L1624
	movzbl	134+cs(%rip), %eax
	movw	%ax, 72+trk(%rip)
	movzbl	135+cs(%rip), %eax
	movw	%ax, 68+trk(%rip)
	movzbl	136+cs(%rip), %eax
	movw	%ax, 70+trk(%rip)
	movzbl	137+cs(%rip), %eax
	jmp	.L1625
.L1624:
	movw	$0, 72+trk(%rip)
	movw	$0, 68+trk(%rip)
	movw	$0, 70+trk(%rip)
	movl	$0, %eax
.L1625:
	movw	%ax, 66+trk(%rip)
	ret
	.cfi_endproc
.LFE1296:
	.size	cu_fx_apply, .-cu_fx_apply
	.type	cu_sends_to_fx, @function
cu_sends_to_fx:
.LFB1297:
	.cfi_startproc
	movzwl	72+trk(%rip), %eax
	movb	%al, 134+cs(%rip)
	movzwl	68+trk(%rip), %eax
	movb	%al, 135+cs(%rip)
	movzwl	70+trk(%rip), %eax
	movb	%al, 136+cs(%rip)
	movzwl	66+trk(%rip), %eax
	movb	%al, 137+cs(%rip)
	call	cu_fx_apply
	ret
	.cfi_endproc
.LFE1297:
	.size	cu_sends_to_fx, .-cu_sends_to_fx
	.type	cu_route, @function
cu_route:
.LFB1306:
	.cfi_startproc
	movl	$0, %eax
	leaq	201+cs(%rip), %r8
	leaq	cr_route(%rip), %rdi
	jmp	.L1630
.L1629:
	addq	$1, %rax
	cmpq	$3, %rax
	je	.L1632
.L1630:
	movzbl	(%rax,%r8), %edx
	testb	%dl, %dl
	setne	%sil
	movl	%eax, %ecx
	movb	%sil, 3(%rdi,%rcx)
	je	.L1629
	subl	$1, %edx
	movb	%dl, 6(%rdi,%rcx)
	jmp	.L1629
.L1632:
	movzbl	204+cs(%rip), %eax
	cmpb	$1, %al
	sbbb	%dl, %dl
	movb	%dl, 2+cr_route(%rip)
	orb	203+cs(%rip), %al
	setne	%cl
	movzbl	%cl, %ecx
	movl	$0, %edx
	movl	$2, %esi
	movl	$23, %edi
	call	cr_post
	ret
	.cfi_endproc
.LFE1306:
	.size	cu_route, .-cu_route
	.type	cu_message, @function
cu_message:
.LFB1313:
	.cfi_startproc
	movl	fm1_ms(%rip), %eax
	addl	$1200, %eax
	movl	%eax, 156+cu(%rip)
	movb	$0, 160+cu(%rip)
	movb	%sil, 161+cu(%rip)
	movl	$48, %edx
	movq	%rdi, %rsi
	leaq	162+cu(%rip), %rdi
	call	cu_cpy
	ret
	.cfi_endproc
.LFE1313:
	.size	cu_message, .-cu_message
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC7:
	.string	"Prophet preset can't be saved as bass"
	.align 8
.LC8:
	.string	"Cloud preset can't be saved as bass"
	.align 8
.LC9:
	.string	"CS-1 preset can't be saved as bass"
	.section	.rodata.str1.1
.LC10:
	.string	"Morph: chords only"
	.text
	.type	cu_bass_engine_block, @function
cu_bass_engine_block:
.LFB1284:
	.cfi_startproc
	testl	%edi, %edi
	setne	%al
	cmpl	$16, %esi
	jne	.L1635
	testb	%al, %al
	jne	.L1640
.L1635:
	cmpl	$22, %esi
	jne	.L1637
	testb	%al, %al
	jne	.L1641
.L1637:
	cmpl	$21, %esi
	jne	.L1638
	testb	%al, %al
	jne	.L1642
.L1638:
	cmpl	$19, %esi
	jne	.L1639
	testb	%al, %al
	jne	.L1643
.L1639:
	movl	$0, %eax
	ret
.L1640:
	movl	$5, %esi
	leaq	.LC7(%rip), %rdi
	call	cu_message
	movl	$1, %eax
	ret
.L1641:
	movl	$5, %esi
	leaq	.LC8(%rip), %rdi
	call	cu_message
	movl	$1, %eax
	ret
.L1642:
	movl	$5, %esi
	leaq	.LC9(%rip), %rdi
	call	cu_message
	movl	$1, %eax
	ret
.L1643:
	movl	$1, %esi
	leaq	.LC10(%rip), %rdi
	call	cu_message
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE1284:
	.size	cu_bass_engine_block, .-cu_bass_engine_block
	.type	crl_fl_sector, @function
crl_fl_sector:
.LFB1327:
	.cfi_startproc
	cmpl	$29, %edi
	ja	.L1647
	cmpl	$1, %esi
	ja	.L1647
	movl	$819200, %edx
	cmpl	$9, %edi
	jbe	.L1646
	cmpl	$20, %edi
	sbbl	%edx, %edx
	andl	$-200704, %edx
	addl	$937984, %edx
.L1646:
	movl	%edi, %eax
	movl	$3435973837, %ecx
	imulq	%rcx, %rax
	shrq	$35, %rax
	leal	(%rax,%rax,4), %eax
	addl	%eax, %eax
	subl	%eax, %edi
	leal	(%rsi,%rdi,2), %eax
	sall	$12, %eax
	addl	%edx, %eax
	ret
.L1647:
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE1327:
	.size	crl_fl_sector, .-crl_fl_sector
	.type	crs_slot, @function
crs_slot:
.LFB1561:
	.cfi_startproc
	leaq	ENGINE_ORDER(%rip), %rdx
	movl	%edi, %eax
	shrl	%eax
	movl	%eax, %eax
	movl	$2454267027, %ecx
	imulq	%rcx, %rax
	shrq	$34, %rax
	imull	$14, %eax, %eax
	subl	%eax, %edi
	cmpb	$15, (%rdx,%rdi)
	ja	.L1651
	movzbl	(%rdx,%rdi), %eax
	leaq	.L1653(%rip), %rdx
	movslq	(%rdx,%rax,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1653:
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1659-.L1653
	.long	.L1658-.L1653
	.long	.L1651-.L1653
	.long	.L1657-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1656-.L1653
	.long	.L1655-.L1653
	.long	.L1654-.L1653
	.long	.L1660-.L1653
	.text
.L1651:
	movl	$-2, %eax
	ret
.L1656:
	movl	$0, %eax
	ret
.L1655:
	movl	$1, %eax
	ret
.L1659:
	movl	$2, %eax
	ret
.L1654:
	movl	$3, %eax
	ret
.L1658:
	movl	$4, %eax
	ret
.L1657:
	movl	$5, %eax
	ret
.L1660:
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE1561:
	.size	crs_slot, .-crs_slot
	.type	crb_b, @function
crb_b:
.LFB1576:
	.cfi_startproc
	movl	crb_n(%rip), %eax
	cmpl	$1022, %eax
	ja	.L1661
	leal	1(%rax), %edx
	movl	%edx, crb_n(%rip)
	movl	%eax, %eax
	andl	$127, %edi
	leaq	st_buf(%rip), %rdx
	movb	%dil, (%rdx,%rax)
.L1661:
	ret
	.cfi_endproc
.LFE1576:
	.size	crb_b, .-crb_b
	.type	crb_u32, @function
crb_u32:
.LFB1577:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebp
	movl	$0, %ebx
.L1664:
	movl	%ebp, %edi
	movl	%ebx, %ecx
	shrl	%cl, %edi
	call	crb_b
	addl	$7, %ebx
	cmpl	$35, %ebx
	jne	.L1664
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1577:
	.size	crb_u32, .-crb_u32
	.type	crb_r32, @function
crb_r32:
.LFB1578:
	.cfi_startproc
	movzbl	1(%rdi), %eax
	sall	$7, %eax
	movzbl	2(%rdi), %edx
	sall	$14, %edx
	orl	%edx, %eax
	movzbl	(%rdi), %edx
	orl	%edx, %eax
	movzbl	3(%rdi), %edx
	sall	$21, %edx
	orl	%edx, %eax
	movzbl	4(%rdi), %edx
	sall	$28, %edx
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE1578:
	.size	crb_r32, .-crb_r32
	.type	crb_obj, @function
crb_obj:
.LFB1584:
	.cfi_startproc
	cmpl	$22, %edi
	je	.L1674
	leal	-12(%rdi), %eax
	cmpl	$9, %eax
	jbe	.L1679
	leal	-70(%rdi), %eax
	cmpl	$1, %eax
	jbe	.L1680
	movl	$0, %eax
	cmpl	$1, %edi
	je	.L1668
	movl	$7, %eax
	cmpl	$8, %edi
	je	.L1668
	movl	$1, %eax
	cmpl	$9, %edi
	je	.L1668
	leal	-8(%rdi), %edx
	leal	-1(%rdi), %eax
	cmpl	$10, %edi
	cmovnb	%edx, %eax
	ret
.L1679:
	cmpl	$13, %edi
	jbe	.L1671
	leal	-5(%rdi), %eax
	ret
.L1671:
	cmpl	$12, %edi
	setne	%al
	movzbl	%al, %eax
	leal	4(,%rax,4), %eax
	ret
.L1680:
	leal	-52(%rdi), %eax
	ret
.L1674:
	movl	$17, %eax
.L1668:
	ret
	.cfi_endproc
.LFE1584:
	.size	crb_obj, .-crb_obj
	.type	crb_busy, @function
crb_busy:
.LFB1590:
	.cfi_startproc
	movl	$1, %eax
	cmpb	$2, 196+cr_snap(%rip)
	je	.L1681
	cmpb	$0, 197+cr_snap(%rip)
	jne	.L1681
	movzbl	crl_stage_busy(%rip), %eax
	testb	%al, %al
	setne	%al
	movzbl	%al, %eax
.L1681:
	ret
	.cfi_endproc
.LFE1590:
	.size	crb_busy, .-crb_busy
	.type	crb_debug, @function
crb_debug:
.LFB1598:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$600, %rsp
	.cfi_def_cfa_offset 624
	movq	%fs:40, %rax
	movq	%rax, 584(%rsp)
	xorl	%eax, %eax
	movl	fm1_ms(%rip), %eax
	movl	%eax, (%rsp)
	movl	4+felucca_dbg(%rip), %eax
	movl	%eax, 4(%rsp)
	movl	8+felucca_dbg(%rip), %eax
	movl	%eax, 8(%rsp)
	movl	20+felucca_dbg(%rip), %eax
	movl	%eax, 12(%rsp)
	movl	12+felucca_dbg(%rip), %eax
	movl	%eax, 16(%rsp)
	movl	24+felucca_dbg(%rip), %eax
	movl	%eax, 20(%rsp)
	movl	28+felucca_dbg(%rip), %eax
	movl	%eax, 24(%rsp)
	movl	32+felucca_dbg(%rip), %eax
	movl	%eax, 28(%rsp)
	movl	$0, 32(%rsp)
	movl	$0, 36(%rsp)
	movl	$0, 40(%rsp)
	movl	$0, 44(%rsp)
	movzbl	cr_dbg(%rip), %eax
	movl	%eax, 48(%rsp)
	movl	4+cr_dbg(%rip), %eax
	movl	%eax, 52(%rsp)
	movl	$0, 56(%rsp)
	movl	$0, 60(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, %eax
	leaq	84(%rsp), %rsi
	leaq	100+cr_dbg(%rip), %rcx
.L1686:
	movl	(%rcx,%rax), %edx
	movl	%edx, (%rsi,%rax)
	addq	$4, %rax
	cmpq	$24, %rax
	jne	.L1686
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$1, %edi
	call	crb_b
	movl	$36, %edi
	call	crb_b
	movq	%rsp, %rbx
	leaq	144(%rsp), %rbp
.L1687:
	movl	(%rbx), %edi
	call	crb_u32
	addq	$4, %rbx
	cmpq	%rbp, %rbx
	jne	.L1687
	movq	584(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1692
	addq	$600, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1692:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1598:
	.size	crb_debug, .-crb_debug
	.type	t_begin, @function
t_begin:
.LFB1600:
	.cfi_startproc
	movb	$125, tx(%rip)
	movb	$70, 1+tx(%rip)
	movb	$76, 2+tx(%rip)
	movb	%dil, 3+tx(%rip)
	movl	$4, txn(%rip)
	ret
	.cfi_endproc
.LFE1600:
	.size	t_begin, .-t_begin
	.type	t_b, @function
t_b:
.LFB1601:
	.cfi_startproc
	movl	txn(%rip), %eax
	leal	1(%rax), %edx
	movl	%edx, txn(%rip)
	movl	%eax, %eax
	andl	$127, %edi
	leaq	tx(%rip), %rdx
	movb	%dil, (%rdx,%rax)
	ret
	.cfi_endproc
.LFE1601:
	.size	t_b, .-t_b
	.type	t_u32, @function
t_u32:
.LFB1602:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebp
	movl	$0, %ebx
.L1696:
	movl	%ebp, %edi
	movl	%ebx, %ecx
	shrl	%cl, %edi
	call	t_b
	addl	$7, %ebx
	cmpl	$35, %ebx
	jne	.L1696
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1602:
	.size	t_u32, .-t_u32
	.type	r32, @function
r32:
.LFB1605:
	.cfi_startproc
	movzbl	1(%rdi), %eax
	sall	$7, %eax
	movzbl	2(%rdi), %edx
	sall	$14, %edx
	orl	%edx, %eax
	movzbl	(%rdi), %edx
	orl	%edx, %eax
	movzbl	3(%rdi), %edx
	sall	$21, %edx
	movzbl	4(%rdi), %ecx
	sall	$28, %ecx
	orl	%ecx, %edx
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE1605:
	.size	r32, .-r32
	.type	find, @function
find:
.LFB1610:
	.cfi_startproc
	testl	%esi, %esi
	je	.L1703
	movq	%rdi, %rax
	movl	%esi, %esi
	leaq	(%rsi,%rsi,2), %rcx
	leaq	(%rdi,%rcx,8), %rdi
.L1702:
	movq	%rax, %rsi
	movzbl	(%rax), %ecx
	cmpl	%edx, %ecx
	je	.L1700
	addq	$24, %rax
	cmpq	%rdi, %rax
	jne	.L1702
	movl	$0, %esi
.L1700:
	movq	%rsi, %rax
	ret
.L1703:
	movl	$0, %esi
	jmp	.L1700
	.cfi_endproc
.LFE1610:
	.size	find, .-find
	.type	eng_state_clear, @function
eng_state_clear:
.LFB418:
	.cfi_startproc
	cmpl	$2, %edi
	jbe	.L1707
.L1705:
	ret
.L1707:
	movl	%edi, %ecx
	imulq	$6884, %rcx, %rcx
	leaq	eng_state(%rip), %rax
	addq	%rax, %rcx
	movq	$0, (%rcx)
	movq	$0, 6876(%rcx)
	leaq	8(%rcx), %rdi
	andq	$-8, %rdi
	subq	%rdi, %rcx
	addl	$6884, %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movl	$0, %eax
	rep stosq
	ret
	.cfi_endproc
.LFE418:
	.size	eng_state_clear, .-eng_state_clear
	.type	cr_mforget, @function
cr_mforget:
.LFB897:
	.cfi_startproc
	movl	%edi, %edx
	cmpl	$1, %edi
	jbe	.L1710
.L1709:
	movl	%edx, %edi
	leaq	midi_bend_target(%rip), %rax
	movl	$0, (%rax,%rdi,4)
	leaq	midi_bend_q8(%rip), %rax
	movl	$0, (%rax,%rdi,4)
	imulq	$2464, %rdi, %rdi
	leaq	trk(%rip), %rax
	movw	$0, 2460(%rax,%rdi)
	ret
.L1710:
	movl	%edi, %r8d
	movq	%r8, %rsi
	salq	$7, %rsi
	leaq	cr_mnote(%rip), %rax
	addq	%rax, %rsi
	movl	$16, %ecx
	movl	$0, %eax
	movq	%rsi, %rdi
	rep stosq
	leaq	cr_mheld(%rip), %rax
	movb	$0, (%rax,%r8)
	jmp	.L1709
	.cfi_endproc
.LFE897:
	.size	cr_mforget, .-cr_mforget
	.type	fm6_fn_reset, @function
fm6_fn_reset:
.LFB138:
	.cfi_startproc
	movabsq	$99923616732283651, %rax
	movabsq	$72057594037927936, %rdx
	movq	%rax, fm6_fn(%rip)
	movq	%rdx, 8+fm6_fn(%rip)
	movq	%rax, 16+fm6_fn(%rip)
	movq	%rdx, 24+fm6_fn(%rip)
	movq	%rax, 32+fm6_fn(%rip)
	movq	%rdx, 40+fm6_fn(%rip)
	ret
	.cfi_endproc
.LFE138:
	.size	fm6_fn_reset, .-fm6_fn_reset
	.type	p5_patch_init, @function
p5_patch_init:
.LFB279:
	.cfi_startproc
	movq	%rdi, %rdx
	movq	$0, 2(%rdi)
	movq	$0, 130(%rdi)
	leaq	10(%rdi), %rdi
	andq	$-8, %rdi
	movl	%edx, %eax
	subl	%edi, %eax
	leal	138(%rax), %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movl	$0, %eax
	rep stosq
	movb	$-123, 133(%rdx)
	movb	$50, 134(%rdx)
	movb	$3, 135(%rdx)
	movb	$24, 1(%rdx)
	movb	$24, (%rdx)
	movb	$1, 12(%rdx)
	movb	$1, 3(%rdx)
	movb	$64, 9(%rdx)
	movb	$64, 8(%rdx)
	movb	$127, 17(%rdx)
	movb	$127, 14(%rdx)
	movb	$1, 20(%rdx)
	movb	$60, 46(%rdx)
	movb	$60, 45(%rdx)
	movb	$127, 48(%rdx)
	movb	$127, 47(%rdx)
	movb	$35, 50(%rdx)
	movb	$35, 49(%rdx)
	movb	$1, 51(%rdx)
	movb	$5, 53(%rdx)
	movabsq	$2314885530818453536, %rax
	movq	%rax, 77(%rdx)
	movabsq	$5715718976869846601, %rax
	movq	%rax, 65(%rdx)
	movl	$1413826640, 73(%rdx)
	ret
	.cfi_endproc
.LFE279:
	.size	p5_patch_init, .-p5_patch_init
	.type	p5_patch_of, @function
p5_patch_of:
.LFB285:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	movl	%edi, %ebx
	movl	$2863311531, %eax
	imulq	%rax, %rbx
	shrq	$33, %rbx
	leal	(%rbx,%rbx,2), %eax
	movl	%edi, %ebx
	subl	%eax, %ebx
	movl	%ebx, %eax
	leaq	p5_ready(%rip), %rdx
	cmpb	$0, (%rdx,%rax)
	je	.L1716
.L1714:
	movl	%ebx, %eax
	imulq	$138, %rax, %rax
	leaq	p5_patch(%rip), %rdx
	addq	%rdx, %rax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1716:
	.cfi_restore_state
	movl	%ebx, %ebp
	imulq	$138, %rbp, %rdi
	leaq	p5_patch(%rip), %rax
	addq	%rax, %rdi
	call	p5_patch_init
	leaq	p5_ready(%rip), %rax
	movb	$1, (%rax,%rbp)
	jmp	.L1714
	.cfi_endproc
.LFE285:
	.size	p5_patch_of, .-p5_patch_of
	.type	p5_track_accept, @function
p5_track_accept:
.LFB310:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	p5_patch_of
	movl	$1, %edx
	leaq	2464+trk(%rip), %rcx
	cmpq	%rcx, %rbx
	je	.L1718
	movzbl	52(%rax), %esi
	negb	%sil
	sbbw	%dx, %dx
	andl	$3, %edx
.L1718:
	movw	%dx, 74(%rbx)
	cmpb	$1, 87(%rax)
	setbe	%dl
	movzbl	%dl, %edx
	movw	%dx, 84(%rbx)
	movzbl	54(%rax), %eax
	movl	$7, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	%eax, %edx
	sall	$7, %edx
	subl	%eax, %edx
	movslq	%edx, %rax
	imulq	$-1840700269, %rax, %rax
	shrq	$32, %rax
	addl	%edx, %eax
	sarl	$2, %eax
	sarl	$31, %edx
	subl	%edx, %eax
	movw	%ax, 88(%rbx)
	movw	$1, 86(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE310:
	.size	p5_track_accept, .-p5_track_accept
	.type	p5_deep_get, @function
p5_deep_get:
.LFB325:
	.cfi_startproc
	endbr64
	cmpl	$8, %esi
	ja	.L1726
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%esi, %ebx
	movl	%edx, %ebp
	movl	$0, %eax
	cmpl	$3, %edx
	ja	.L1722
	call	p5_patch_of
	movq	%rax, %rdx
	movl	%ebp, %ebp
	movl	%ebx, %ebx
	leaq	P5_EDIT_KEYS(%rip), %rax
	leaq	(%rax,%rbx,4), %rax
	movzbl	(%rax,%rbp), %eax
	movzbl	(%rdx,%rax), %eax
.L1722:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1726:
	.cfi_restore 3
	.cfi_restore 6
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE325:
	.size	p5_deep_get, .-p5_deep_get
	.type	p5_deep_set, @function
p5_deep_set:
.LFB326:
	.cfi_startproc
	endbr64
	cmpl	$8, %esi
	ja	.L1733
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%esi, %ebp
	movl	%edx, %ebx
	movl	%ecx, %r12d
	cmpl	$3, %edx
	ja	.L1730
	call	p5_patch_of
	movq	%rax, %rcx
	movl	%ebx, %ebx
	movl	%ebp, %edx
	leaq	P5_EDIT_KEYS(%rip), %rax
	leaq	(%rax,%rdx,4), %rax
	movzbl	(%rax,%rbx), %edx
	movl	$127, %eax
	cmpl	%eax, %r12d
	cmovle	%r12d, %eax
	testl	%eax, %eax
	movl	$0, %esi
	cmovs	%esi, %eax
	movb	%al, (%rcx,%rdx)
.L1730:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1733:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	ret
	.cfi_endproc
.LFE326:
	.size	p5_deep_set, .-p5_deep_set
	.type	p5_preset_loaded, @function
p5_preset_loaded:
.LFB323:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbp
	movl	%esi, %ebx
	call	p5_patch_of
	movq	%rax, %rdi
	leal	-1(%rbx), %esi
	cmpl	$199, %esi
	ja	.L1737
	movl	%esi, %esi
	imulq	$138, %rsi, %rsi
	leaq	P5_FACTORY(%rip), %rax
	addq	%rsi, %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rax), %xmm1
	movups	%xmm1, 16(%rdi)
	movdqu	32(%rax), %xmm2
	movups	%xmm2, 32(%rdi)
	movdqu	48(%rax), %xmm3
	movups	%xmm3, 48(%rdi)
	movdqu	64(%rax), %xmm4
	movups	%xmm4, 64(%rdi)
	movdqu	80(%rax), %xmm5
	movups	%xmm5, 80(%rdi)
	movdqu	96(%rax), %xmm6
	movups	%xmm6, 96(%rdi)
	movdqu	112(%rax), %xmm7
	movups	%xmm7, 112(%rdi)
	movdqu	122(%rax), %xmm0
	movups	%xmm0, 122(%rdi)
.L1738:
	movq	%rbp, %rdi
	call	p5_track_accept
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1737:
	.cfi_restore_state
	call	p5_patch_init
	jmp	.L1738
	.cfi_endproc
.LFE323:
	.size	p5_preset_loaded, .-p5_preset_loaded
	.type	p5_blob_get, @function
p5_blob_get:
.LFB327:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %rbx
	call	p5_patch_of
	movdqu	(%rax), %xmm0
	movups	%xmm0, (%rbx)
	movdqu	16(%rax), %xmm1
	movups	%xmm1, 16(%rbx)
	movdqu	32(%rax), %xmm2
	movups	%xmm2, 32(%rbx)
	movdqu	48(%rax), %xmm3
	movups	%xmm3, 48(%rbx)
	movdqu	64(%rax), %xmm4
	movups	%xmm4, 64(%rbx)
	movdqu	80(%rax), %xmm5
	movups	%xmm5, 80(%rbx)
	movdqu	96(%rax), %xmm6
	movups	%xmm6, 96(%rbx)
	movdqu	112(%rax), %xmm7
	movups	%xmm7, 112(%rbx)
	movdqu	122(%rax), %xmm0
	movups	%xmm0, 122(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE327:
	.size	p5_blob_get, .-p5_blob_get
	.type	p5_blob_set, @function
p5_blob_set:
.LFB328:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbp
	testq	%rsi, %rsi
	je	.L1743
	movq	%rsi, %rbx
	call	p5_patch_of
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbx), %xmm1
	movups	%xmm1, 16(%rax)
	movdqu	32(%rbx), %xmm2
	movups	%xmm2, 32(%rax)
	movdqu	48(%rbx), %xmm3
	movups	%xmm3, 48(%rax)
	movdqu	64(%rbx), %xmm4
	movups	%xmm4, 64(%rax)
	movdqu	80(%rbx), %xmm5
	movups	%xmm5, 80(%rax)
	movdqu	96(%rbx), %xmm6
	movups	%xmm6, 96(%rax)
	movdqu	112(%rbx), %xmm7
	movups	%xmm7, 112(%rax)
	movdqu	122(%rbx), %xmm0
	movups	%xmm0, 122(%rax)
.L1744:
	movq	%rbp, %rdi
	call	p5_track_accept
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1743:
	.cfi_restore_state
	call	p5_patch_of
	movq	%rax, %rdi
	call	p5_patch_init
	jmp	.L1744
	.cfi_endproc
.LFE328:
	.size	p5_blob_set, .-p5_blob_set
	.type	morph_end, @function
morph_end:
.LFB489:
	.cfi_startproc
	leaq	trk(%rip), %rax
	cmpq	%rdi, %rax
	je	.L1748
.L1746:
	ret
.L1748:
	cmpb	$0, 6621+morph(%rip)
	je	.L1746
	movdqu	4022+morph(%rip), %xmm0
	movaps	%xmm0, trk(%rip)
	movdqu	4038+morph(%rip), %xmm1
	movaps	%xmm1, 16+trk(%rip)
	movdqu	4054+morph(%rip), %xmm2
	movaps	%xmm2, 32+trk(%rip)
	movdqu	4070+morph(%rip), %xmm3
	movaps	%xmm3, 48+trk(%rip)
	movdqu	4086+morph(%rip), %xmm4
	movaps	%xmm4, 64+trk(%rip)
	movdqu	4102+morph(%rip), %xmm5
	movaps	%xmm5, 80+trk(%rip)
	movdqu	4118+morph(%rip), %xmm6
	movaps	%xmm6, 96+trk(%rip)
	movdqu	4134+morph(%rip), %xmm7
	movaps	%xmm7, 112+trk(%rip)
	movdqu	4150+morph(%rip), %xmm0
	movaps	%xmm0, 128+trk(%rip)
	movdqu	4166+morph(%rip), %xmm1
	movaps	%xmm1, 144+trk(%rip)
	movdqu	4182+morph(%rip), %xmm2
	movaps	%xmm2, 160+trk(%rip)
	movq	4196+morph(%rip), %rax
	movq	%rax, 174+trk(%rip)
	movb	$0, 6621+morph(%rip)
	ret
	.cfi_endproc
.LFE489:
	.size	morph_end, .-morph_end
	.type	fm6_eff_build, @function
fm6_eff_build:
.LFB183:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	leaq	trk(%rip), %rdx
	movq	%rdi, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movq	%rax, %r15
	movl	$0, %eax
	cmpl	$2, %r15d
	ja	.L1749
	movq	%rdi, %rbx
	call	morph_fm_key
	movl	%eax, 4(%rsp)
	movl	%r15d, %eax
	imulq	$196, %rax, %rax
	leaq	fm6_eff(%rip), %rdx
	cmpb	$0, 157(%rdx,%rax)
	je	.L1751
	movl	%r15d, %eax
	leaq	fm6_pgen(%rip), %rdx
	movzbl	(%rdx,%rax), %edx
	imulq	$196, %rax, %rax
	leaq	fm6_eff(%rip), %rcx
	cmpb	%dl, 156(%rcx,%rax)
	je	.L1774
.L1751:
	movl	%r15d, %eax
	leaq	fm6_pgen(%rip), %rdx
	movzbl	(%rdx,%rax), %edx
	leaq	fm6_eff(%rip), %rbp
	imulq	$196, %rax, %rax
	movb	%dl, 156(%rbp,%rax)
	movl	%r15d, %esi
	addq	%rax, %rbp
	movl	$588, %ecx
	cmpq	%rcx, %rax
	cmovnb	%rax, %rcx
	subq	%rax, %rcx
	imulq	$156, %rsi, %rsi
	leaq	fm6_patch(%rip), %rax
	addq	%rax, %rsi
	movl	$155, %edx
	movq	%rbp, %rdi
	call	__memcpy_chk@PLT
	movl	$0, %eax
.L1755:
	movzwl	166(%rbx,%rax), %edx
	movw	%dx, 158(%rbp,%rax)
	addq	$2, %rax
	cmpq	$14, %rax
	jne	.L1755
	movzwl	166(%rbx), %edi
	leal	-1(%rdi), %eax
	cmpw	$31, %ax
	ja	.L1756
	movswl	%di, %edi
	subl	$1, %edi
.L1757:
	movb	%dil, 134(%rbp)
	movzbl	135(%rbp), %eax
	movswl	168(%rbx), %edx
	addl	%edx, %eax
	movl	$7, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movb	%al, 135(%rbp)
	call	fm6_carriers
	movl	%eax, %r13d
	movswl	174(%rbx), %eax
	movl	$63, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-64, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	leal	(%rax,%rax,4), %eax
	sall	$3, %eax
	leal	63(%rax), %r9d
	cmovns	%eax, %r9d
	sarl	$6, %r9d
	movswl	178(%rbx), %eax
	movl	$127, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	imull	$167772, %eax, %eax
	movslq	%eax, %r10
	imulq	$-2130574327, %r10, %r10
	shrq	$32, %r10
	addl	%eax, %r10d
	sarl	$6, %r10d
	sarl	$31, %eax
	subl	%eax, %r10d
	movq	%rbp, %rsi
	movl	$105, %edi
	movl	$5, %r8d
	movl	$0, %r12d
	leaq	SPREAD.34(%rip), %r14
	movq	%r15, 8(%rsp)
	jmp	.L1762
.L1774:
	movl	%r15d, %eax
	leaq	fm6_morph_seen(%rip), %rdx
	movl	4(%rsp), %esi
	cmpl	%esi, (%rdx,%rax,4)
	jne	.L1751
	movl	%r15d, %edx
	imulq	$196, %rdx, %rdx
	addq	%rcx, %rdx
	movl	$0, %eax
.L1752:
	movl	%eax, %ecx
	movzwl	166(%rbx,%rax,2), %esi
	cmpw	%si, 158(%rdx,%rax,2)
	jne	.L1753
	addq	$1, %rax
	cmpq	$7, %rax
	jne	.L1752
	addl	$1, %ecx
.L1753:
	movl	$0, %eax
	cmpl	$7, %ecx
	jne	.L1751
	jmp	.L1749
.L1756:
	movzbl	134(%rbp), %edi
	andl	$31, %edi
	jmp	.L1757
.L1758:
	movl	%edi, %ecx
	addq	%rbp, %rcx
	cmpb	$0, 17(%rcx)
	jne	.L1760
	movzbl	18(%rcx), %eax
	movswl	172(%rbx), %edx
	addl	%edx, %eax
	movl	$31, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movb	%al, 18(%rcx)
.L1760:
	movq	%rcx, %rdx
	leaq	4(%rcx), %r11
.L1761:
	movzbl	(%rdx), %eax
	subl	%r9d, %eax
	movl	$99, %r15d
	cmpl	%r15d, %eax
	cmovg	%r15d, %eax
	testl	%eax, %eax
	movl	$0, %r15d
	cmovs	%r15d, %eax
	movb	%al, (%rdx)
	addq	$1, %rdx
	cmpq	%r11, %rdx
	jne	.L1761
	movzbl	15(%rcx), %eax
	movswl	176(%rbx), %edx
	addl	%edx, %eax
	movl	$7, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movb	%al, 15(%rcx)
.L1759:
	subl	$1, %r8d
	subq	$4, %rsi
	subl	$21, %edi
	cmpl	$-21, %edi
	je	.L1775
.L1762:
	movl	$0, 192(%rsi)
	btl	%r8d, %r13d
	jnc	.L1758
	movl	%r12d, %eax
	movsbl	(%r14,%rax), %eax
	imull	%r10d, %eax
	movl	%eax, 192(%rsi)
	leal	1(%r12), %r12d
	jmp	.L1759
.L1775:
	movq	8(%rsp), %r15
	cmpb	$0, morph_dual(%rip)
	jne	.L1763
	movq	%rbx, %rdi
	call	morph_fm_key
	testl	%eax, %eax
	je	.L1763
	movzwl	6604+morph(%rip), %eax
	movzwl	%ax, %edx
	testw	%ax, %ax
	je	.L1763
	leaq	10+morph(%rip), %rax
	leal	-1(%rdx), %edx
	leaq	(%rdx,%rdx,2), %rcx
	leaq	24(%rax), %rdx
	leaq	(%rdx,%rcx,8), %rdx
	jmp	.L1765
.L1764:
	addq	$24, %rax
	cmpq	%rdx, %rax
	je	.L1763
.L1765:
	cmpb	$2, 6(%rax)
	jne	.L1764
	movzbl	7(%rax), %ecx
	movzwl	(%rax), %esi
	movb	%sil, 0(%rbp,%rcx)
	jmp	.L1764
.L1763:
	movl	%r15d, %r15d
	leaq	fm6_morph_seen(%rip), %rax
	movl	4(%rsp), %ebx
	movl	%ebx, (%rax,%r15,4)
	imulq	$196, %r15, %r15
	leaq	fm6_eff(%rip), %rax
	movb	$1, 157(%rax,%r15)
	movl	$1, %eax
.L1749:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE183:
	.size	fm6_eff_build, .-fm6_eff_build
	.type	st_read, @function
st_read:
.LFB692:
	.cfi_startproc
	movl	%edi, %eax
	cmpl	$1048576, %edi
	ja	.L1778
	movq	%rsi, %rdi
	movl	$1048576, %ecx
	subl	%eax, %ecx
	cmpl	%edx, %ecx
	jb	.L1779
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	%edx, %edx
	movl	%eax, %eax
	leaq	emu_flash(%rip), %rcx
	leaq	(%rax,%rcx), %rsi
	call	memcpy@PLT
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1778:
	movl	$-8, %eax
	ret
.L1779:
	movl	$-8, %eax
	ret
	.cfi_endproc
.LFE692:
	.size	st_read, .-st_read
	.type	st_ext_scan, @function
st_ext_scan:
.LFB1130:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$64, %rsp
	.cfi_def_cfa_offset 112
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	movl	$0, 8(%rsp)
	movl	$0, 12(%rsp)
	movb	$-1, 1+st_ext_page(%rip)
	movb	$-1, st_ext_page(%rip)
	movl	$1019904, %ebx
	movl	$0, %ebp
	leaq	16(%rsp), %r12
	jmp	.L1789
.L1786:
	movl	%eax, %eax
	leaq	st_ext_page(%rip), %rdx
	movb	%bpl, (%rdx,%rax)
	movl	24(%rsp), %edx
	movl	%edx, 8(%rsp,%rax,4)
.L1788:
	addl	$1, %ebp
	addl	$4096, %ebx
	cmpl	$3, %ebp
	je	.L1793
.L1789:
	movl	$32, %edx
	movq	%r12, %rsi
	movl	%ebx, %edi
	call	st_read
	testl	%eax, %eax
	jne	.L1788
	cmpl	$1431061830, 16(%rsp)
	jne	.L1788
	movzwl	20(%rsp), %r13d
	leal	-18(%r13), %eax
	cmpw	$1, %ax
	ja	.L1788
	cmpw	$0, 22(%rsp)
	jne	.L1788
	movl	28(%rsp), %r14d
	cmpl	$3840, %r14d
	ja	.L1788
	leaq	16(%rsp), %rdi
	movl	$28, %esi
	call	st_crc32
	cmpl	%eax, 44(%rsp)
	jne	.L1788
	leal	256(%rbx), %edi
	movl	%r14d, %edx
	leaq	st_buf(%rip), %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1788
	movl	%r14d, %esi
	leaq	st_buf(%rip), %rdi
	call	st_crc32
	cmpl	%eax, 32(%rsp)
	jne	.L1788
	movzwl	%r13w, %eax
	subl	$18, %eax
	movl	%eax, %edx
	leaq	st_ext_page(%rip), %rcx
	cmpb	$-1, (%rcx,%rdx)
	je	.L1786
	movl	24(%rsp), %ecx
	movl	8(%rsp,%rdx,4), %edx
	cmpl	%edx, %ecx
	je	.L1788
	cmpl	%edx, %ecx
	jns	.L1786
	jmp	.L1788
.L1793:
	movb	$1, st_ext_ready(%rip)
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1794
	addq	$64, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L1794:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1130:
	.size	st_ext_scan, .-st_ext_scan
	.type	st_sector, @function
st_sector:
.LFB1126:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %ebp
	movl	%esi, %ebx
	leal	-18(%rdi), %r12d
	cmpl	$1, %r12d
	jbe	.L1809
	leal	252(%rsi), %eax
	sall	$12, %eax
	testl	%edi, %edi
	je	.L1795
	cmpl	$7, %edi
	je	.L1810
	leal	178(%rsi), %eax
	sall	$12, %eax
	cmpl	$17, %edi
	je	.L1795
	cmpl	$8, %edi
	je	.L1811
	ja	.L1812
	cmpl	$4, %edi
	ja	.L1813
	leal	149(%rsi,%rdi,2), %eax
	sall	$12, %eax
	jmp	.L1795
.L1809:
	cmpb	$0, st_ext_ready(%rip)
	je	.L1814
.L1797:
	testl	%ebx, %ebx
	je	.L1798
	leal	-17(%rbp), %eax
	movl	%eax, %edx
	movl	$2863311531, %ecx
	imulq	%rcx, %rdx
	shrq	$33, %rdx
	leal	(%rdx,%rdx,2), %edx
	subl	%edx, %eax
	addl	$249, %eax
	sall	$12, %eax
.L1795:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1814:
	.cfi_restore_state
	call	st_ext_scan
	jmp	.L1797
.L1798:
	movl	%r12d, %r12d
	leaq	st_ext_page(%rip), %rax
	movzbl	(%rax,%r12), %edx
	cmpb	$2, %dl
	ja	.L1800
	movzbl	%dl, %eax
	addl	$249, %eax
	sall	$12, %eax
	jmp	.L1795
.L1800:
	leal	231(%rbp), %eax
	sall	$12, %eax
	jmp	.L1795
.L1810:
	cmpl	$1, %esi
	sbbl	%eax, %eax
	andl	$-389120, %eax
	addl	$1040384, %eax
	jmp	.L1795
.L1811:
	leal	160(%rsi), %eax
	sall	$12, %eax
	jmp	.L1795
.L1812:
	leal	144(%rsi,%rdi,2), %eax
	sall	$12, %eax
	jmp	.L1795
.L1813:
	leal	210(%rsi,%rdi,2), %eax
	sall	$12, %eax
	jmp	.L1795
	.cfi_endproc
.LFE1126:
	.size	st_sector, .-st_sector
	.type	crb_sector, @function
crb_sector:
.LFB1586:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%esi, %ebx
	leal	-40(%rdi), %eax
	cmpl	$29, %eax
	ja	.L1816
	movl	%eax, %edi
	call	crl_fl_sector
.L1815:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1816:
	.cfi_restore_state
	call	crb_obj
	movl	%eax, %edi
	movl	%ebx, %esi
	call	st_sector
	jmp	.L1815
	.cfi_endproc
.LFE1586:
	.size	crb_sector, .-crb_sector
	.type	st_head, @function
st_head:
.LFB1127:
	.cfi_startproc
	cmpl	$19, %edi
	ja	.L1828
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %ebp
	movl	%esi, %r12d
	movq	%rdx, %rbx
	cmpl	$1, %esi
	ja	.L1821
	call	st_sector
	movl	%eax, %edi
	movl	$32, %edx
	movq	%rbx, %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1822
	cmpl	$1431061830, (%rbx)
	jne	.L1823
	movzwl	4(%rbx), %eax
	cmpl	%ebp, %eax
	jne	.L1824
	movzwl	6(%rbx), %eax
	cmpl	%r12d, %eax
	jne	.L1825
	cmpl	$3840, 12(%rbx)
	ja	.L1826
	movl	28(%rbx), %ebp
	movl	$28, %esi
	movq	%rbx, %rdi
	call	st_crc32
	cmpl	%eax, %ebp
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L1819:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1821:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1819
.L1822:
	movl	$-1, %eax
	jmp	.L1819
.L1823:
	movl	$-1, %eax
	jmp	.L1819
.L1824:
	movl	$-1, %eax
	jmp	.L1819
.L1825:
	movl	$-1, %eax
	jmp	.L1819
.L1826:
	movl	$-1, %eax
	jmp	.L1819
.L1828:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE1127:
	.size	st_head, .-st_head
	.type	st_body, @function
st_body:
.LFB1128:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdx, %rbx
	movl	12(%rdx), %ebp
	call	st_sector
	leal	256(%rax), %edi
	movl	%ebp, %edx
	leaq	st_buf(%rip), %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1833
	movl	12(%rbx), %esi
	leaq	st_buf(%rip), %rdi
	call	st_crc32
	cmpl	%eax, 16(%rbx)
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L1831:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1833:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1831
	.cfi_endproc
.LFE1128:
	.size	st_body, .-st_body
	.type	st_current, @function
st_current:
.LFB1129:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$80, %rsp
	.cfi_def_cfa_offset 112
	movl	%edi, %ebx
	movq	%rsi, %r12
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rdx
	movl	$0, %esi
	call	st_head
	movl	%eax, %ebp
	leaq	32(%rsp), %rdx
	movl	$1, %esi
	movl	%ebx, %edi
	call	st_head
	testl	%eax, %eax
	jne	.L1836
	testl	%ebp, %ebp
	jne	.L1837
	movl	40(%rsp), %edx
	movl	8(%rsp), %eax
	cmpl	%eax, %edx
	je	.L1838
	cmpl	%eax, %edx
	js	.L1838
	leaq	32(%rsp), %rdx
	movl	$1, %esi
	movl	%ebx, %edi
	call	st_body
	testl	%eax, %eax
	je	.L1843
.L1836:
	movl	$-1, %eax
	testl	%ebp, %ebp
	je	.L1848
.L1835:
	movq	72(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1849
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1843:
	.cfi_restore_state
	movdqa	32(%rsp), %xmm0
	movups	%xmm0, (%r12)
	movdqa	48(%rsp), %xmm1
	movups	%xmm1, 16(%r12)
	movl	$1, %eax
	jmp	.L1835
.L1838:
	movq	%rsp, %rdx
	movl	$0, %esi
	movl	%ebx, %edi
	call	st_body
	testl	%eax, %eax
	je	.L1841
	leaq	32(%rsp), %rdx
	movl	$1, %esi
	movl	%ebx, %edi
	call	st_body
	movl	%eax, %edx
	movl	$-1, %eax
	testl	%edx, %edx
	jne	.L1835
	movdqa	32(%rsp), %xmm4
	movups	%xmm4, (%r12)
	movdqa	48(%rsp), %xmm5
	movups	%xmm5, 16(%r12)
	movl	$1, %eax
	jmp	.L1835
.L1848:
	movq	%rsp, %rdx
	movl	$0, %esi
	movl	%ebx, %edi
	call	st_body
	testl	%eax, %eax
	jne	.L1850
.L1841:
	movdqa	(%rsp), %xmm2
	movups	%xmm2, (%r12)
	movdqa	16(%rsp), %xmm3
	movups	%xmm3, 16(%r12)
	movl	$0, %eax
	jmp	.L1835
.L1850:
	movl	$-1, %eax
	jmp	.L1835
.L1837:
	leaq	32(%rsp), %rdx
	movl	$1, %esi
	movl	%ebx, %edi
	call	st_body
	testl	%eax, %eax
	je	.L1843
	movl	$-1, %eax
	jmp	.L1835
.L1849:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1129:
	.size	st_current, .-st_current
	.type	st_load, @function
st_load:
.LFB1132:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	cmpb	$0, cr_safe(%rip)
	jne	.L1856
	movq	%rsi, %rbx
	movl	%edx, %ebp
	cmpl	$19, %edi
	ja	.L1856
	movq	%rsp, %rsi
	call	st_current
	testl	%eax, %eax
	js	.L1857
	movl	12(%rsp), %eax
	cmpl	%eax, %ebp
	jb	.L1858
	testl	%eax, %eax
	je	.L1851
	movl	%eax, %edi
	movl	$0, %edx
	leaq	st_buf(%rip), %rsi
.L1854:
	movzbl	(%rsi,%rdx), %ecx
	movb	%cl, (%rbx,%rdx)
	addq	$1, %rdx
	cmpq	%rdi, %rdx
	jne	.L1854
.L1851:
	movq	40(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1861
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1856:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1851
.L1857:
	movl	$-1, %eax
	jmp	.L1851
.L1858:
	movl	$-1, %eax
	jmp	.L1851
.L1861:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1132:
	.size	st_load, .-st_load
	.type	crl_fl_head, @function
crl_fl_head:
.LFB1328:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %ebp
	movl	%esi, %r12d
	movq	%rdx, %rbx
	call	crl_fl_sector
	movl	%eax, %edi
	movl	$32, %edx
	movq	%rbx, %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1864
	cmpl	$1431061830, (%rbx)
	jne	.L1865
	movzwl	4(%rbx), %eax
	addl	$19504, %ebp
	cmpl	%ebp, %eax
	jne	.L1866
	movzwl	6(%rbx), %eax
	cmpl	%r12d, %eax
	jne	.L1867
	cmpl	$3792, 12(%rbx)
	ja	.L1868
	movl	28(%rbx), %ebp
	movl	$28, %esi
	movq	%rbx, %rdi
	call	st_crc32
	cmpl	%eax, %ebp
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L1862:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1864:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1862
.L1865:
	movl	$-1, %eax
	jmp	.L1862
.L1866:
	movl	$-1, %eax
	jmp	.L1862
.L1867:
	movl	$-1, %eax
	jmp	.L1862
.L1868:
	movl	$-1, %eax
	jmp	.L1862
	.cfi_endproc
.LFE1328:
	.size	crl_fl_head, .-crl_fl_head
	.type	crl_fl_body, @function
crl_fl_body:
.LFB1329:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdx, %rbx
	movq	%rcx, %rbp
	movl	12(%rdx), %r12d
	call	crl_fl_sector
	leal	256(%rax), %edi
	movl	%r12d, %edx
	movq	%rbp, %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1872
	movl	12(%rbx), %esi
	movq	%rbp, %rdi
	call	st_crc32
	cmpl	%eax, 16(%rbx)
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L1870:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L1872:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1870
	.cfi_endproc
.LFE1329:
	.size	crl_fl_body, .-crl_fl_body
	.type	crl_fl_current, @function
crl_fl_current:
.LFB1330:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$88, %rsp
	.cfi_def_cfa_offset 128
	movl	%edi, %ebx
	movq	%rsi, %r13
	movq	%rdx, %r12
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rdx
	movl	$0, %esi
	call	crl_fl_head
	movl	%eax, %ebp
	leaq	32(%rsp), %rdx
	movl	$1, %esi
	movl	%ebx, %edi
	call	crl_fl_head
	testl	%eax, %eax
	jne	.L1875
	testl	%ebp, %ebp
	jne	.L1876
	movl	40(%rsp), %edx
	movl	8(%rsp), %eax
	cmpl	%eax, %edx
	je	.L1877
	cmpl	%eax, %edx
	js	.L1877
	leaq	32(%rsp), %rdx
	movq	%r12, %rcx
	movl	$1, %esi
	movl	%ebx, %edi
	call	crl_fl_body
	testl	%eax, %eax
	je	.L1883
	testl	%ebp, %ebp
	jne	.L1881
.L1877:
	movq	%rsp, %rdx
	movq	%r12, %rcx
	movl	$0, %esi
	movl	%ebx, %edi
	call	crl_fl_body
	testl	%eax, %eax
	jne	.L1881
.L1882:
	movdqa	(%rsp), %xmm2
	movups	%xmm2, 0(%r13)
	movdqa	16(%rsp), %xmm3
	movups	%xmm3, 16(%r13)
	movl	$0, %eax
	jmp	.L1874
.L1883:
	movdqa	32(%rsp), %xmm0
	movups	%xmm0, 0(%r13)
	movdqa	48(%rsp), %xmm1
	movups	%xmm1, 16(%r13)
	movl	$1, %eax
	jmp	.L1874
.L1875:
	testl	%ebp, %ebp
	je	.L1880
	movl	$-1, %eax
.L1874:
	movq	72(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1887
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1880:
	.cfi_restore_state
	movq	%rsp, %rdx
	movq	%r12, %rcx
	movl	$0, %esi
	movl	%ebx, %edi
	call	crl_fl_body
	testl	%eax, %eax
	je	.L1882
	movl	$-1, %eax
	jmp	.L1874
.L1876:
	leaq	32(%rsp), %rdx
	movq	%r12, %rcx
	movl	$1, %esi
	movl	%ebx, %edi
	call	crl_fl_body
	testl	%eax, %eax
	je	.L1883
.L1881:
	leaq	32(%rsp), %rdx
	movq	%r12, %rcx
	movl	$1, %esi
	movl	%ebx, %edi
	call	crl_fl_body
	movl	%eax, %edx
	movl	$-1, %eax
	testl	%edx, %edx
	jne	.L1874
	movdqa	32(%rsp), %xmm4
	movups	%xmm4, 0(%r13)
	movdqa	48(%rsp), %xmm5
	movups	%xmm5, 16(%r13)
	movl	$1, %eax
	jmp	.L1874
.L1887:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1330:
	.size	crl_fl_current, .-crl_fl_current
	.type	crl_fl_load, @function
crl_fl_load:
.LFB1331:
	.cfi_startproc
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	cmpb	$0, flash_ok(%rip)
	je	.L1891
	movq	%rsi, %rdx
	cmpb	$0, cr_safe(%rip)
	jne	.L1892
	cmpl	$29, %edi
	ja	.L1892
	movq	%rsp, %rsi
	call	crl_fl_current
	testl	%eax, %eax
	js	.L1893
	movl	12(%rsp), %eax
.L1888:
	movq	40(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1895
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1891:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1888
.L1892:
	movl	$-1, %eax
	jmp	.L1888
.L1893:
	movl	$-1, %eax
	jmp	.L1888
.L1895:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1331:
	.size	crl_fl_load, .-crl_fl_load
	.type	crb_body, @function
crb_body:
.LFB1588:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdx, %rbx
	movl	12(%rdx), %ebp
	call	crb_sector
	leal	256(%rax), %edi
	movl	%ebp, %edx
	leaq	st_buf(%rip), %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L1898
	movl	12(%rbx), %esi
	leaq	st_buf(%rip), %rdi
	call	st_crc32
	cmpl	%eax, 16(%rbx)
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L1896:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1898:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L1896
	.cfi_endproc
.LFE1588:
	.size	crb_body, .-crb_body
	.type	fm1_ticks, @function
fm1_ticks:
.LFB672:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rsi
	movl	$1, %edi
	call	clock_gettime@PLT
	imulq	$1000000000, (%rsp), %rdx
	addq	8(%rsp), %rdx
	shrq	$3, %rdx
	movabsq	$2361183241434822607, %rcx
	movq	%rdx, %rax
	mulq	%rcx
	shrq	$4, %rdx
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1903
	movl	%edx, %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1903:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE672:
	.size	fm1_ticks, .-fm1_ticks
	.type	emu_flash_sync, @function
emu_flash_sync:
.LFB691:
	.cfi_startproc
	addl	$1, emu_flash_writes(%rip)
	movq	emu_flash_f(%rip), %rax
	testq	%rax, %rax
	je	.L1907
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movl	%esi, %ebp
	movl	%edi, %ebx
	movl	$0, %edx
	movq	%rbx, %rsi
	movq	%rax, %rdi
	call	fseek@PLT
	movl	%ebp, %edx
	leaq	emu_flash(%rip), %rax
	leaq	(%rbx,%rax), %rdi
	movq	emu_flash_f(%rip), %rcx
	movl	$1, %esi
	call	fwrite@PLT
	movq	emu_flash_f(%rip), %rdi
	call	fflush@PLT
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1907:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE691:
	.size	emu_flash_sync, .-emu_flash_sync
	.type	st_erase, @function
st_erase:
.LFB693:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	andl	$-4096, %ebx
	cmpl	$1048575, %ebx
	ja	.L1912
	addl	$11, emu_stall_blocks(%rip)
	addl	$1, emu_stalls(%rip)
	movl	%ebx, %edi
	movl	$1048576, %ecx
	subq	%rdi, %rcx
	leaq	emu_flash(%rip), %rax
	addq	%rax, %rdi
	movl	$4096, %edx
	movl	$255, %esi
	call	__memset_chk@PLT
	movl	$4096, %esi
	movl	%ebx, %edi
	call	emu_flash_sync
	movl	$0, %eax
.L1910:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1912:
	.cfi_restore_state
	movl	$-8, %eax
	jmp	.L1910
	.cfi_endproc
.LFE693:
	.size	st_erase, .-st_erase
	.type	st_prog, @function
st_prog:
.LFB694:
	.cfi_startproc
	cmpl	$1048576, %edi
	ja	.L1918
	movl	%edi, %r11d
	movq	%rsi, %rcx
	movl	%edx, %esi
	movl	$1048576, %eax
	subl	%edi, %eax
	cmpl	%edx, %eax
	jb	.L1919
	movzbl	%dil, %eax
	addl	%edx, %eax
	cmpl	$256, %eax
	ja	.L1920
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testl	%edx, %edx
	je	.L1916
	movl	%edx, %r9d
	addq	%rcx, %r9
	movq	%rcx, %rax
	movl	%edi, %r10d
	subl	%ecx, %r10d
	leaq	emu_flash(%rip), %r8
.L1917:
	leal	(%r10,%rax), %edi
	movzbl	(%r8,%rdi), %ecx
	andb	(%rax), %cl
	movb	%cl, (%r8,%rdi)
	addq	$1, %rax
	cmpq	%r9, %rax
	jne	.L1917
.L1916:
	movl	%r11d, %edi
	call	emu_flash_sync
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L1918:
	movl	$-8, %eax
	ret
.L1919:
	movl	$-8, %eax
	ret
.L1920:
	movl	$-8, %eax
	ret
	.cfi_endproc
.LFE694:
	.size	st_prog, .-st_prog
	.type	st_save, @function
st_save:
.LFB1133:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	cmpb	$0, cr_safe(%rip)
	jne	.L1950
	movl	%edi, %r12d
	movq	%rsi, %rbx
	movl	%edx, %ebp
	cmpl	$19, %edi
	ja	.L1951
	cmpl	$3840, %edx
	ja	.L1951
	leal	-18(%rdi), %r14d
	cmpl	$1, %r14d
	jbe	.L1962
	leaq	48(%rsp), %rsi
	call	st_current
	movl	%eax, %r15d
	testl	%eax, %eax
	js	.L1957
	movl	56(%rsp), %eax
	movl	%eax, 8(%rsp)
	sete	%sil
	movzbl	%sil, %esi
.L1942:
	movl	%r12d, %edi
	call	st_sector
	movl	%eax, %r13d
	testl	%ebp, %ebp
	je	.L1943
	movl	%ebp, %esi
	movl	$0, %eax
	leaq	st_buf(%rip), %rcx
.L1944:
	movzbl	(%rbx,%rax), %edx
	movb	%dl, (%rcx,%rax)
	addq	$1, %rax
	cmpq	%rsi, %rax
	jne	.L1944
	movl	%r13d, %edi
	call	st_erase
	testl	%eax, %eax
	jne	.L1926
	movl	$0, %ebx
	leaq	st_buf(%rip), %r14
.L1945:
	movl	%ebp, %edx
	subl	%ebx, %edx
	movl	$256, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%ebx, %esi
	addq	%r14, %rsi
	leal	256(%r13,%rbx), %edi
	call	st_prog
	testl	%eax, %eax
	jne	.L1926
	addl	$256, %ebx
	cmpl	%ebp, %ebx
	jb	.L1945
.L1948:
	movl	$1431061830, 48(%rsp)
	movw	%r12w, 52(%rsp)
	testl	%r15d, %r15d
	sete	%bl
	sete	%al
	movzbl	%al, %eax
	movw	%ax, 54(%rsp)
	movl	8(%rsp), %eax
	addl	$1, %eax
	movl	%eax, 56(%rsp)
	movl	%ebp, 60(%rsp)
	movl	%ebp, %esi
	leaq	st_buf(%rip), %rdi
	call	st_crc32
	movl	%eax, 64(%rsp)
	movl	$-1, 72(%rsp)
	movl	$-1, 68(%rsp)
	leaq	48(%rsp), %rbp
	movl	$28, %esi
	movq	%rbp, %rdi
	call	st_crc32
	movl	%eax, 76(%rsp)
	movl	$32, %edx
	movq	%rbp, %rsi
	movl	%r13d, %edi
	call	st_prog
	testl	%eax, %eax
	jne	.L1926
	movzbl	%bl, %ebx
	leaq	80(%rsp), %rdx
	movl	%ebx, %esi
	movl	%r12d, %edi
	call	st_head
	testl	%eax, %eax
	jne	.L1946
	movq	%rbp, %rsi
	leaq	80(%rsp), %rdi
	movl	$32, %edx
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L1946
	leaq	80(%rsp), %rdx
	movl	%ebx, %esi
	movl	%r12d, %edi
	call	st_body
	testl	%eax, %eax
	jne	.L1946
.L1926:
	movq	120(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1963
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1962:
	.cfi_restore_state
	cmpb	$0, st_ext_ready(%rip)
	je	.L1964
.L1929:
	leaq	16(%rsp), %rsi
	movl	%r12d, %edi
	call	st_current
	movl	$0, 8(%rsp)
	testl	%eax, %eax
	js	.L1930
	movl	24(%rsp), %eax
	movl	%eax, 8(%rsp)
.L1930:
	movzbl	st_ext_page(%rip), %edx
	movzbl	1+st_ext_page(%rip), %ecx
	testl	%edx, %edx
	je	.L1931
	testl	%ecx, %ecx
	jne	.L1953
	cmpl	$1, %edx
	jne	.L1931
.L1933:
	movl	$-1, %eax
	cmpl	$2, %ecx
	je	.L1926
	movl	$2, 12(%rsp)
	jmp	.L1932
.L1964:
	call	st_ext_scan
	jmp	.L1929
.L1931:
	cmpl	$1, %ecx
	jne	.L1954
	movl	$-1, %eax
	cmpl	$2, %edx
	je	.L1926
	jmp	.L1933
.L1953:
	movl	$0, 12(%rsp)
.L1932:
	movl	12(%rsp), %eax
	leal	249(%rax), %r13d
	sall	$12, %r13d
	leaq	st_buf(%rip), %rdi
	cmpl	$8, %ebp
	jnb	.L1965
.L1935:
	movl	$0, %eax
	testb	$4, %bpl
	je	.L1936
	movl	(%rbx), %eax
	movl	%eax, (%rdi)
	movl	$4, %eax
.L1936:
	testb	$2, %bpl
	je	.L1937
	movzwl	(%rbx,%rax), %edx
	movw	%dx, (%rdi,%rax)
	addq	$2, %rax
.L1937:
	testb	$1, %bpl
	je	.L1938
	movzbl	(%rbx,%rax), %edx
	movb	%dl, (%rdi,%rax)
.L1938:
	movl	%r13d, %edi
	call	st_erase
	testl	%eax, %eax
	jne	.L1926
	testl	%ebp, %ebp
	je	.L1939
	movl	$0, %ebx
	leaq	st_buf(%rip), %r15
.L1940:
	movl	%ebp, %edx
	subl	%ebx, %edx
	movl	$256, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%ebx, %esi
	addq	%r15, %rsi
	leal	256(%r13,%rbx), %edi
	call	st_prog
	testl	%eax, %eax
	jne	.L1926
	addl	$256, %ebx
	cmpl	%ebp, %ebx
	jb	.L1940
.L1939:
	movl	$1431061830, 48(%rsp)
	movw	%r12w, 52(%rsp)
	movw	$0, 54(%rsp)
	movl	8(%rsp), %eax
	addl	$1, %eax
	movl	%eax, 56(%rsp)
	movl	%ebp, 60(%rsp)
	movl	%ebp, %esi
	leaq	st_buf(%rip), %rdi
	call	st_crc32
	movl	%eax, 64(%rsp)
	movl	$-1, 72(%rsp)
	movl	$-1, 68(%rsp)
	leaq	48(%rsp), %rbx
	movl	$28, %esi
	movq	%rbx, %rdi
	call	st_crc32
	movl	%eax, 76(%rsp)
	movl	$32, %edx
	movq	%rbx, %rsi
	movl	%r13d, %edi
	call	st_prog
	testl	%eax, %eax
	jne	.L1926
	leaq	st_ext_page(%rip), %rdx
	movl	%r14d, %eax
	movzbl	(%rdx,%rax), %ebx
	movzbl	12(%rsp), %ecx
	movb	%cl, (%rdx,%rax)
	leaq	80(%rsp), %rdx
	movl	$0, %esi
	movl	%r12d, %edi
	call	st_head
	testl	%eax, %eax
	jne	.L1941
	leaq	48(%rsp), %rsi
	leaq	80(%rsp), %rdi
	movl	$32, %edx
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L1941
	leaq	80(%rsp), %rdx
	movl	$0, %esi
	movl	%r12d, %edi
	call	st_body
	testl	%eax, %eax
	je	.L1926
.L1941:
	movl	%r14d, %r14d
	leaq	st_ext_page(%rip), %rax
	movb	%bl, (%rax,%r14)
	movl	$-7, %eax
	jmp	.L1926
.L1954:
	movl	$1, 12(%rsp)
	jmp	.L1932
.L1965:
	movl	%ebp, %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movq	%rbx, %rsi
	rep movsq
	movq	%rsi, %rbx
	jmp	.L1935
.L1957:
	movl	$0, 8(%rsp)
	movl	$0, %esi
	jmp	.L1942
.L1946:
	movl	$-7, %eax
	jmp	.L1926
.L1950:
	movl	$-1, %eax
	jmp	.L1926
.L1951:
	movl	$-1, %eax
	jmp	.L1926
.L1943:
	movl	%eax, %edi
	call	st_erase
	testl	%eax, %eax
	jne	.L1926
	jmp	.L1948
.L1963:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1133:
	.size	st_save, .-st_save
	.type	crl_fl_save, @function
crl_fl_save:
.LFB1332:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movq	%fs:40, %rax
	movq	%rax, 88(%rsp)
	xorl	%eax, %eax
	cmpb	$0, flash_ok(%rip)
	je	.L1974
	movl	%edi, %r13d
	movq	%rsi, %r12
	movl	%edx, %ebp
	cmpb	$0, cr_safe(%rip)
	jne	.L1975
	cmpl	$29, %edi
	ja	.L1976
	cmpl	$3792, %edx
	ja	.L1976
	leaq	16(%rsp), %rsi
	leaq	st_buf(%rip), %rdx
	call	crl_fl_current
	testl	%eax, %eax
	js	.L1977
	movl	24(%rsp), %ecx
	movl	%ecx, 12(%rsp)
	sete	%r15b
	movzbl	%r15b, %r15d
.L1968:
	movl	%r15d, %esi
	movl	%r13d, %edi
	call	crl_fl_sector
	movl	%eax, %r14d
	movl	%eax, 8(%rsp)
	movl	%eax, %edi
	call	st_erase
	testl	%eax, %eax
	jne	.L1966
	testl	%ebp, %ebp
	je	.L1969
	movl	$0, %ebx
	addl	$256, %r14d
.L1970:
	movl	%ebp, %edx
	subl	%ebx, %edx
	movl	$256, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%ebx, %esi
	addq	%r12, %rsi
	leal	(%r14,%rbx), %edi
	call	st_prog
	testl	%eax, %eax
	jne	.L1966
	addl	$256, %ebx
	cmpl	%ebp, %ebx
	jb	.L1970
.L1969:
	movl	$1431061830, 16(%rsp)
	leal	19504(%r13), %eax
	movw	%ax, 20(%rsp)
	movw	%r15w, 22(%rsp)
	movl	12(%rsp), %eax
	addl	$1, %eax
	movl	%eax, 24(%rsp)
	movl	%ebp, 28(%rsp)
	movl	%ebp, %esi
	movq	%r12, %rdi
	call	st_crc32
	movl	%eax, 32(%rsp)
	movl	$-1, 40(%rsp)
	movl	$-1, 36(%rsp)
	leaq	16(%rsp), %rbx
	movl	$28, %esi
	movq	%rbx, %rdi
	call	st_crc32
	movl	%eax, 44(%rsp)
	movl	$32, %edx
	movq	%rbx, %rsi
	movl	8(%rsp), %edi
	call	st_prog
	testl	%eax, %eax
	je	.L1980
.L1966:
	movq	88(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1981
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1977:
	.cfi_restore_state
	movl	$0, 12(%rsp)
	movl	$0, %r15d
	jmp	.L1968
.L1980:
	leaq	48(%rsp), %rdx
	movl	%r15d, %esi
	movl	%r13d, %edi
	call	crl_fl_head
	testl	%eax, %eax
	jne	.L1971
	movq	%rbx, %rsi
	leaq	48(%rsp), %rdi
	movl	$32, %edx
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L1971
	leaq	48(%rsp), %rdx
	leaq	st_buf(%rip), %rcx
	movl	%r15d, %esi
	movl	%r13d, %edi
	call	crl_fl_body
	testl	%eax, %eax
	je	.L1966
.L1971:
	movl	$-7, %eax
	jmp	.L1966
.L1974:
	movl	$-1, %eax
	jmp	.L1966
.L1975:
	movl	$-1, %eax
	jmp	.L1966
.L1976:
	movl	$-1, %eax
	jmp	.L1966
.L1981:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1332:
	.size	crl_fl_save, .-crl_fl_save
	.type	fm1_irq_on, @function
fm1_irq_on:
.LFB677:
	.cfi_startproc
	movl	emu_cpu_depth(%rip), %eax
	subl	$1, %eax
	movl	%eax, emu_cpu_depth(%rip)
	je	.L1984
.L1982:
	ret
.L1984:
	movq	$0, emu_cpu_owner(%rip)
	ret
	.cfi_endproc
.LFE677:
	.size	fm1_irq_on, .-fm1_irq_on
	.type	fm1_irq_off, @function
fm1_irq_off:
.LFB675:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	pthread_self@PLT
	movq	emu_cpu_owner(%rip), %rdx
	cmpq	%rdx, %rax
	jne	.L1988
.L1986:
	addl	$1, emu_cpu_depth(%rip)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1988:
	.cfi_restore_state
	movq	%rax, emu_cpu_owner(%rip)
	jmp	.L1986
	.cfi_endproc
.LFE675:
	.size	fm1_irq_off, .-fm1_irq_off
	.type	fm6_put_patch, @function
fm6_put_patch:
.LFB176:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$184, %rsp
	.cfi_def_cfa_offset 208
	movl	%edx, %ebp
	movq	%fs:40, %rax
	movq	%rax, 168(%rsp)
	xorl	%eax, %eax
	movl	%edi, %ebx
	movl	$2863311531, %eax
	imulq	%rax, %rbx
	shrq	$33, %rbx
	leal	(%rbx,%rbx,2), %eax
	subl	%eax, %edi
	movl	%edi, %ebx
	movq	%rsp, %rdi
	movdqu	(%rsi), %xmm0
	movaps	%xmm0, (%rsp)
	movdqu	16(%rsi), %xmm1
	movaps	%xmm1, 16(%rsp)
	movdqu	32(%rsi), %xmm2
	movaps	%xmm2, 32(%rsp)
	movdqu	48(%rsi), %xmm3
	movaps	%xmm3, 48(%rsp)
	movdqu	64(%rsi), %xmm4
	movaps	%xmm4, 64(%rsp)
	movdqu	80(%rsi), %xmm5
	movaps	%xmm5, 80(%rsp)
	movdqu	96(%rsi), %xmm6
	movaps	%xmm6, 96(%rsp)
	movdqu	112(%rsi), %xmm7
	movaps	%xmm7, 112(%rsp)
	movdqu	128(%rsi), %xmm0
	movaps	%xmm0, 128(%rsp)
	movdqu	139(%rsi), %xmm1
	movups	%xmm1, 139(%rsp)
	call	fm6_sanitize
	movl	%ebx, %edx
	imulq	$156, %rdx, %rdx
	leaq	fm6_patch(%rip), %rax
	addq	%rdx, %rax
	movdqa	(%rsp), %xmm2
	movups	%xmm2, (%rax)
	movdqa	16(%rsp), %xmm3
	movups	%xmm3, 16(%rax)
	movdqa	32(%rsp), %xmm4
	movups	%xmm4, 32(%rax)
	movdqa	48(%rsp), %xmm5
	movups	%xmm5, 48(%rax)
	movdqa	64(%rsp), %xmm6
	movups	%xmm6, 64(%rax)
	movdqa	80(%rsp), %xmm7
	movups	%xmm7, 80(%rax)
	movdqa	96(%rsp), %xmm0
	movups	%xmm0, 96(%rax)
	movdqa	112(%rsp), %xmm1
	movups	%xmm1, 112(%rax)
	movdqa	128(%rsp), %xmm2
	movups	%xmm2, 128(%rax)
	movdqu	140(%rsp), %xmm3
	movups	%xmm3, 140(%rax)
	testl	%ebp, %ebp
	je	.L1990
	movl	%ebx, %eax
	leaq	fm6_on(%rip), %rdx
	movb	$63, (%rdx,%rax)
	leaq	fm6_lgen(%rip), %rcx
	movzbl	(%rcx,%rax), %edx
	addl	$1, %edx
	movb	%dl, (%rcx,%rax)
.L1990:
	leaq	fm6_pgen(%rip), %rdx
	movl	%ebx, %ebx
	movzbl	(%rdx,%rbx), %eax
	addl	$1, %eax
	movb	%al, (%rdx,%rbx)
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1993
	addq	$184, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L1993:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE176:
	.size	fm6_put_patch, .-fm6_put_patch
	.type	fm6_load_slot, @function
fm6_load_slot:
.LFB179:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$304, %rsp
	.cfi_def_cfa_offset 336
	movl	%edi, %ebx
	movl	%esi, %ebp
	movq	%fs:40, %rax
	movq	%rax, 296(%rsp)
	xorl	%eax, %eax
	cmpl	$23, %esi
	jbe	.L2010
	cmpl	$55, %esi
	ja	.L2004
	movq	fm6_bank_read(%rip), %rax
	testq	%rax, %rax
	je	.L2004
	movq	%rsp, %rsi
	leal	-24(%rbp), %edi
	call	*%rax
	testl	%eax, %eax
	je	.L1997
.L2004:
	movabsq	$27975301214724963, %rax
	movabsq	$144115428594024487, %rdx
	movq	%rax, (%rsp)
	movq	%rdx, 8(%rsp)
	movabsq	$7161677110969590528, %rax
	movabsq	$61572651165440, %rdx
	movq	%rax, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movabsq	$7161677110969565186, %rax
	movabsq	$15762598698352739, %rdx
	movq	%rax, 32(%rsp)
	movq	%rdx, 40(%rsp)
	movabsq	$7161677110963077632, %rax
	movabsq	$4035225266778301283, %rdx
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movabsq	$7161677109302263808, %rax
	movabsq	$167510238051, %rdx
	movq	%rax, 64(%rsp)
	movq	%rdx, 72(%rsp)
	movabsq	$7161676684133924920, %rax
	movabsq	$42882620941155, %rdx
	movq	%rax, 80(%rsp)
	movq	%rdx, 88(%rsp)
	movabsq	$7161567842700113920, %rax
	movabsq	$576515943475340131, %rdx
	movq	%rax, 96(%rsp)
	movq	%rdx, 104(%rsp)
	movabsq	$5641066606990721059, %rax
	movabsq	$4990913417152844873, %rdx
	movq	%rax, 112(%rsp)
	movq	%rdx, 120(%rsp)
.L1997:
	leaq	128(%rsp), %r12
	movq	%rsp, %rdi
	movq	%r12, %rsi
	call	fm6_unpack
	movl	$1, %edx
	movq	%r12, %rsi
	movl	%ebx, %edi
	call	fm6_put_patch
	movl	%ebx, %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %eax
	subl	%eax, %ebx
	leaq	fm6_slot(%rip), %rax
	movb	%bpl, (%rax,%rbx)
	movq	296(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2011
	addq	$304, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L2010:
	.cfi_restore_state
	cmpl	$7, %esi
	jbe	.L2012
	leal	-8(%rsi), %r11d
	imulq	$156, %r11, %r9
	leaq	FM6_ROM(%rip), %rax
	addq	%rax, %r9
	movq	%r9, %r8
	movq	%r9, %rsi
	movl	$105, %edi
	leaq	128(%rsp), %r10
.L1998:
	movl	$0, %eax
	movl	%edi, %ecx
	addq	%r10, %rcx
.L1999:
	movzbl	(%rsi,%rax), %edx
	movb	%dl, (%rcx,%rax)
	addq	$1, %rax
	cmpq	$21, %rax
	jne	.L1999
	subl	$21, %edi
	addq	$21, %rsi
	cmpl	$-21, %edi
	jne	.L1998
	leaq	128(%rsp), %rax
	leaq	132(%rsp), %rcx
.L2001:
	movzbl	126(%r8), %edx
	movb	%dl, 126(%rax)
	movzbl	130(%r8), %edx
	movb	%dl, 130(%rax)
	addq	$1, %r8
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L2001
	imulq	$156, %r11, %r11
	leaq	FM6_ROM(%rip), %rax
	addq	%r11, %rax
	movzbl	134(%rax), %edx
	movb	%dl, 262(%rsp)
	movzbl	135(%rax), %edx
	movb	%dl, 263(%rsp)
	movzbl	136(%rax), %edx
	movb	%dl, 264(%rsp)
	movzbl	137(%rax), %edx
	movb	%dl, 265(%rsp)
	movzbl	138(%rax), %edx
	movb	%dl, 266(%rsp)
	movzbl	139(%rax), %edx
	movb	%dl, 267(%rsp)
	movzbl	140(%rax), %edx
	movb	%dl, 268(%rsp)
	movzbl	141(%rax), %edx
	movb	%dl, 269(%rsp)
	movzbl	142(%rax), %edx
	movb	%dl, 270(%rsp)
	movzbl	143(%rax), %edx
	movb	%dl, 271(%rsp)
	movzbl	144(%rax), %eax
	movb	%al, 272(%rsp)
	movl	$0, %eax
	movl	$32, %esi
	leaq	273(%rsp), %rcx
.L2003:
	movzbl	145(%r9,%rax), %edx
	testb	%dl, %dl
	cmove	%esi, %edx
	movb	%dl, (%rcx,%rax)
	addq	$1, %rax
	cmpq	$10, %rax
	jne	.L2003
	leaq	128(%rsp), %r12
	movq	%r12, %rdi
	call	fm6_sanitize
	movq	%rsp, %rsi
	movl	$16, %ecx
	movl	$0, %eax
	movq	%rsi, %rdi
	rep stosq
	movq	%r12, %rdi
	call	fm6_pack
	jmp	.L1997
.L2012:
	movl	%esi, %edx
	salq	$7, %rdx
	leaq	FM6_FACTORY(%rip), %rax
	addq	%rdx, %rax
	movdqa	(%rax), %xmm0
	movaps	%xmm0, (%rsp)
	movdqa	16(%rax), %xmm1
	movaps	%xmm1, 16(%rsp)
	movdqa	32(%rax), %xmm2
	movaps	%xmm2, 32(%rsp)
	movdqa	48(%rax), %xmm3
	movaps	%xmm3, 48(%rsp)
	movdqa	64(%rax), %xmm4
	movaps	%xmm4, 64(%rsp)
	movdqa	80(%rax), %xmm5
	movaps	%xmm5, 80(%rsp)
	movdqa	96(%rax), %xmm6
	movaps	%xmm6, 96(%rsp)
	movdqa	112(%rax), %xmm7
	movaps	%xmm7, 112(%rsp)
	jmp	.L1997
.L2011:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE179:
	.size	fm6_load_slot, .-fm6_load_slot
	.type	fm6_blob_preset, @function
fm6_blob_preset:
.LFB217:
	.cfi_startproc
	endbr64
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	ja	.L2016
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movl	%esi, %ebx
	movl	%edi, %ebp
	cmpl	$24, %esi
	ja	.L2013
	movl	%edi, %edi
	salq	$4, %rdi
	movl	$48, %ecx
	cmpq	%rcx, %rdi
	cmovnb	%rdi, %rcx
	subq	%rdi, %rcx
	leaq	fm6_fn(%rip), %rax
	addq	%rax, %rdi
	movl	$16, %edx
	leaq	FM6_FNDEF(%rip), %rsi
	call	__memcpy_chk@PLT
	movl	%ebx, %ebx
	salq	$5, %rbx
	leaq	FM6_PRESETS(%rip), %rax
	movsbl	15(%rax,%rbx), %esi
	movl	$55, %eax
	cmpl	%eax, %esi
	cmovg	%eax, %esi
	testl	%esi, %esi
	movl	$0, %eax
	cmovs	%eax, %esi
	movl	%ebp, %edi
	call	fm6_load_slot
.L2013:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L2016:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE217:
	.size	fm6_blob_preset, .-fm6_blob_preset
	.type	fm6_blob_apply, @function
fm6_blob_apply:
.LFB214:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$192, %rsp
	.cfi_def_cfa_offset 208
	movl	%edi, %ebx
	movq	%fs:40, %rax
	movq	%rax, 184(%rsp)
	xorl	%eax, %eax
	cmpl	$2, %edi
	jbe	.L2024
.L2019:
	movq	184(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L2025
	addq	$192, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L2024:
	.cfi_restore_state
	movq	%rsi, %rdi
	movq	%rsp, %rdx
	leaq	16(%rsp), %rsi
	call	fm6_blob_read
	testl	%eax, %eax
	je	.L2019
	movl	%ebx, %eax
	salq	$4, %rax
	leaq	fm6_fn(%rip), %rdx
	movdqa	(%rsp), %xmm0
	movaps	%xmm0, (%rdx,%rax)
	leaq	16(%rsp), %rsi
	movl	$1, %edx
	movl	%ebx, %edi
	call	fm6_put_patch
	movl	$1, %eax
	jmp	.L2019
.L2025:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE214:
	.size	fm6_blob_apply, .-fm6_blob_apply
	.type	fm6_blob_set, @function
fm6_blob_set:
.LFB216:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$184, %rsp
	.cfi_def_cfa_offset 224
	movq	%fs:40, %rax
	movq	%rax, 168(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	movq	%rdi, %rbx
	subq	%rax, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	cmpl	$2, %ebx
	jbe	.L2031
.L2026:
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2032
	addq	$184, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L2031:
	.cfi_restore_state
	movq	%rdi, %rbp
	movl	%ebx, %edi
	call	fm6_blob_apply
	testl	%eax, %eax
	je	.L2033
.L2028:
	movl	%ebx, %ebx
	movswl	180(%rbp), %eax
	movl	$55, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	leaq	fm6_slot(%rip), %rdx
	movb	%al, (%rdx,%rbx)
	jmp	.L2026
.L2033:
	movq	%rsp, %r13
	movq	%r13, %rsi
	leaq	FM6_INIT(%rip), %rdi
	call	fm6_unpack
	movl	%ebx, %edi
	salq	$4, %rdi
	movl	$48, %ecx
	cmpq	%rcx, %rdi
	cmovnb	%rdi, %rcx
	subq	%rdi, %rcx
	leaq	fm6_fn(%rip), %rax
	addq	%rax, %rdi
	movl	$16, %edx
	leaq	FM6_FNDEF(%rip), %rsi
	call	__memcpy_chk@PLT
	movl	$1, %edx
	movq	%r13, %rsi
	movl	%ebx, %edi
	call	fm6_put_patch
	jmp	.L2028
.L2032:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE216:
	.size	fm6_blob_set, .-fm6_blob_set
	.type	fm6_dset, @function
fm6_dset:
.LFB220:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$176, %rsp
	.cfi_def_cfa_offset 224
	movl	%esi, %r13d
	movl	%edx, %ebp
	movl	%ecx, %r14d
	movq	%fs:40, %rax
	movq	%rax, 168(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	movq	%rdi, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	movl	%edx, %esi
	movl	%r13d, %edi
	call	fm6_dref
	testl	%eax, %eax
	js	.L2034
	movl	%ebx, %r12d
	movl	%eax, %edx
	cmpl	$2, %ebx
	ja	.L2034
	leaq	FM6_PAGES(%rip), %rcx
	movl	%ebp, %ebp
	movl	%r13d, %r13d
	salq	$5, %rbp
	movq	%r13, %rax
	salq	$4, %rax
	leaq	(%rax,%r13), %rsi
	leaq	0(%rbp,%rsi,8), %rsi
	movswl	18(%rcx,%rsi), %ebp
	movswl	20(%rcx,%rsi), %eax
	cmpl	%r14d, %eax
	cmovg	%r14d, %eax
	cmpl	%r14d, %ebp
	cmovle	%eax, %ebp
	cmpl	$767, %edx
	jg	.L2044
	leal	-256(%rdx), %esi
	cmpl	$255, %esi
	jbe	.L2045
	movl	%ebx, %eax
	imulq	$156, %rax, %rax
	leaq	fm6_patch(%rip), %rcx
	addq	%rcx, %rax
	movdqu	(%rax), %xmm0
	movaps	%xmm0, (%rsp)
	movdqu	16(%rax), %xmm1
	movaps	%xmm1, 16(%rsp)
	movdqu	32(%rax), %xmm2
	movaps	%xmm2, 32(%rsp)
	movdqu	48(%rax), %xmm3
	movaps	%xmm3, 48(%rsp)
	movdqu	64(%rax), %xmm4
	movaps	%xmm4, 64(%rsp)
	movdqu	80(%rax), %xmm5
	movaps	%xmm5, 80(%rsp)
	movdqu	96(%rax), %xmm6
	movaps	%xmm6, 96(%rsp)
	movdqu	112(%rax), %xmm7
	movaps	%xmm7, 112(%rsp)
	movdqu	128(%rax), %xmm0
	movaps	%xmm0, 128(%rsp)
	movdqu	139(%rax), %xmm1
	movups	%xmm1, 139(%rsp)
	cmpl	$511, %edx
	jle	.L2039
	leal	-501(%rdx), %eax
	cltq
	movl	%ebp, %ecx
	sarl	$2, %ecx
	movb	%cl, (%rsp,%rax)
	subl	$500, %edx
	movslq	%edx, %rdx
	andl	$3, %ebp
	movb	%bpl, (%rsp,%rdx)
.L2040:
	movq	%rsp, %rsi
	movl	$0, %edx
	movl	%r12d, %edi
	call	fm6_put_patch
.L2034:
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2046
	addq	$176, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L2044:
	.cfi_restore_state
	movl	%ebp, %edx
	movl	$0, %esi
	movl	%ebx, %edi
	call	fm6_fn_set
	movl	%ebp, %edx
	movl	$1, %esi
	movl	%ebx, %edi
	call	fm6_fn_set
	jmp	.L2034
.L2045:
	movl	%ebp, %edx
	movl	%ebx, %edi
	call	fm6_fn_set
	jmp	.L2034
.L2039:
	movslq	%edx, %rdx
	movb	%bpl, (%rsp,%rdx)
	jmp	.L2040
.L2046:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE220:
	.size	fm6_dset, .-fm6_dset
	.type	fm6_blob_make, @function
fm6_blob_make:
.LFB211:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$144, %rsp
	.cfi_def_cfa_offset 176
	movq	%rdi, %r8
	movq	%rsi, %rbx
	movq	%rdx, %rbp
	movq	%fs:40, %rax
	movq	%rax, 136(%rsp)
	xorl	%eax, %eax
	movq	$0, (%rdx)
	movq	$0, 120(%rdx)
	leaq	8(%rdx), %rdi
	andq	$-8, %rdi
	movq	%rdx, %rcx
	subq	%rdi, %rcx
	subl	$-128, %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	rep stosq
	movq	%rsp, %r12
	movl	$16, %ecx
	movq	%r12, %rdi
	rep stosq
	movq	%r12, %rsi
	movq	%r8, %rdi
	call	fm6_pack
	movl	$128, %edx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	call	fm6_pack7
	movb	$70, 112(%rbp)
	movb	$1, 113(%rbp)
	movl	$0, %edx
	movl	$0, %esi
	movl	$0, %edi
	leaq	FM6_FNBITS(%rip), %r10
	movl	$-1, %r9d
.L2048:
	movzbl	(%r10,%rdx), %ecx
	movzbl	%cl, %r8d
	movl	%r9d, %eax
	sall	%cl, %eax
	notl	%eax
	andb	(%rbx,%rdx), %al
	movzbl	%al, %eax
	movl	%esi, %ecx
	salq	%cl, %rax
	orq	%rax, %rdi
	addl	%r8d, %esi
	addq	$1, %rdx
	cmpq	$16, %rdx
	jne	.L2048
	movl	$0, %eax
.L2049:
	leal	0(,%rax,8), %ecx
	movq	%rdi, %rdx
	shrq	%cl, %rdx
	movb	%dl, 114(%rbp,%rax)
	addq	$1, %rax
	cmpq	$8, %rax
	jne	.L2049
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2054
	addq	$144, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L2054:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE211:
	.size	fm6_blob_make, .-fm6_blob_make
	.type	fm6_blob_get, @function
fm6_blob_get:
.LFB215:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$184, %rsp
	.cfi_def_cfa_offset 208
	movq	%rsi, %rbx
	movq	%fs:40, %rax
	movq	%rax, 168(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	jbe	.L2060
	movq	%rsp, %rbp
	movq	%rbp, %rsi
	leaq	FM6_INIT(%rip), %rdi
	call	fm6_unpack
	movq	%rbx, %rdx
	leaq	FM6_FNDEF(%rip), %rsi
	movq	%rbp, %rdi
	call	fm6_blob_make
.L2055:
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2061
	addq	$184, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L2060:
	.cfi_restore_state
	movl	%edi, %edi
	movq	%rdi, %rsi
	salq	$4, %rsi
	leaq	fm6_fn(%rip), %rax
	addq	%rax, %rsi
	imulq	$156, %rdi, %rdi
	leaq	fm6_patch(%rip), %rax
	addq	%rax, %rdi
	movq	%rbx, %rdx
	call	fm6_blob_make
	jmp	.L2055
.L2061:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE215:
	.size	fm6_blob_get, .-fm6_blob_get
	.type	morph_invalidate, @function
morph_invalidate:
.LFB493:
	.cfi_startproc
	movb	$0, morph_dual(%rip)
	movb	$0, 6620+morph(%rip)
	movb	$0, 6622+morph(%rip)
	movb	$0, 6625+morph(%rip)
	leaq	6456+morph(%rip), %rdx
	movl	$16, %ecx
	movl	$0, %eax
	movq	%rdx, %rdi
	rep stosq
	ret
	.cfi_endproc
.LFE493:
	.size	morph_invalidate, .-morph_invalidate
	.type	cr_cb_all_off, @function
cr_cb_all_off:
.LFB909:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	%esi, 8(%rsp)
	movl	%esi, %eax
	leaq	cr_route(%rip), %rdx
	movzbl	(%rdx,%rax), %eax
	movb	%al, 15(%rsp)
	movzbl	%al, %r14d
	testl	%esi, %esi
	je	.L2071
.L2064:
	movl	8(%rsp), %eax
	salq	$7, %rax
	leaq	cr_ono(%rip), %rbp
	addq	%rax, %rbp
	leaq	128+cr_ono(%rip), %r13
	addq	%rax, %r13
	leaq	cr_route(%rip), %r15
	jmp	.L2067
.L2071:
	leaq	cr_rosen_notes(%rip), %rdx
	movl	$0, %eax
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep stosq
	leaq	cr_chord_skipped(%rip), %rdx
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep stosq
	movb	$0, cr_rosen_valid(%rip)
	movb	$0, cr_rosen_pending(%rip)
	jmp	.L2064
.L2073:
	movzbl	%bl, %ebx
	subl	$1, %ebx
	movl	%ebx, %edi
	call	cr_tr_end
	cmpl	%r14d, %ebx
	je	.L2065
	movl	%ebx, %edi
	imulq	$2464, %rdi, %rdi
	leaq	trk(%rip), %rax
	addq	%rax, %rdi
	call	trk_all_off
	jmp	.L2065
.L2066:
	movb	$0, (%r12)
	addq	$1, %rbp
	cmpq	%r13, %rbp
	je	.L2072
.L2067:
	movq	%rbp, %r12
	movzbl	0(%rbp), %ebx
	shrb	$5, %bl
	jne	.L2073
.L2065:
	movzbl	(%r12), %edi
	andl	$31, %edi
	je	.L2066
	movzbl	%dil, %edi
	subl	$1, %edi
	movl	8(%rsp), %eax
	movzbl	6(%r15,%rax), %eax
	andl	$15, %eax
	cmpl	%eax, %edi
	je	.L2066
	orb	$-80, %dil
	movl	$0, %edx
	movl	$123, %esi
	call	cr_midi
	jmp	.L2066
.L2072:
	cmpl	$2, %r14d
	jbe	.L2074
.L2068:
	movl	8(%rsp), %eax
	leaq	cr_route(%rip), %rdx
	movzbl	6(%rdx,%rax), %edi
	andl	$15, %edi
	orb	$-80, %dil
	movl	$0, %edx
	movl	$123, %esi
	call	cr_midi
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2074:
	.cfi_restore_state
	movzbl	15(%rsp), %edi
	imulq	$2464, %rdi, %rdi
	leaq	trk(%rip), %rax
	addq	%rax, %rdi
	call	trk_all_off
	jmp	.L2068
	.cfi_endproc
.LFE909:
	.size	cr_cb_all_off, .-cr_cb_all_off
	.type	fm6_bank_empty, @function
fm6_bank_empty:
.LFB1192:
	.cfi_startproc
	leaq	fm6_bank(%rip), %rdx
	movl	$451, %ecx
	movl	$0, %eax
	movq	%rdx, %rdi
	rep stosq
	movl	$0, (%rdi)
	movl	$1110854982, fm6_bank(%rip)
	movw	$2, 4+fm6_bank(%rip)
	movw	$32, 6+fm6_bank(%rip)
	movabsq	$99923616732283651, %rax
	movabsq	$72057594037927936, %rdx
	movq	%rax, 12+fm6_bank(%rip)
	movq	%rdx, 20+fm6_bank(%rip)
	ret
	.cfi_endproc
.LFE1192:
	.size	fm6_bank_empty, .-fm6_bank_empty
	.type	fm6_bank_check, @function
fm6_bank_check:
.LFB1193:
	.cfi_startproc
	cmpl	$3612, %edi
	jne	.L2077
	leaq	fm6_bank(%rip), %rdi
	call	fm6_bank_valid
	testl	%eax, %eax
	jne	.L2078
.L2077:
	call	fm6_bank_empty
.L2078:
	leaq	fm6_bank_get(%rip), %rax
	movq	%rax, fm6_bank_read(%rip)
	addl	$1, fm6_bank_gen(%rip)
	ret
	.cfi_endproc
.LFE1193:
	.size	fm6_bank_check, .-fm6_bank_check
	.type	fm6_bank_import, @function
fm6_bank_import:
.LFB1194:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$312, %rsp
	.cfi_def_cfa_offset 368
	movq	%fs:40, %rax
	movq	%rax, 296(%rsp)
	xorl	%eax, %eax
	movzbl	1(%rdi), %eax
	sall	$8, %eax
	movzbl	2(%rdi), %edx
	sall	$16, %edx
	orl	%edx, %eax
	movzbl	(%rdi), %edx
	orl	%edx, %eax
	movzbl	3(%rdi), %edx
	sall	$24, %edx
	orl	%edx, %eax
	movl	$1, %edx
	cmpl	$1110854982, %eax
	jne	.L2079
	movq	%rdi, %rbx
	cmpl	$3588, %esi
	je	.L2091
	movl	$1, %edx
	cmpl	$3472, %esi
	je	.L2092
.L2079:
	movq	296(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2093
	movl	%edx, %eax
	addq	$312, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2091:
	.cfi_restore_state
	call	fm6_bank_empty
	leaq	4(%rbx), %rsi
	movq	4(%rbx), %rax
	movq	%rax, 28+fm6_bank(%rip)
	movq	3580(%rbx), %rax
	movq	%rax, 3604+fm6_bank(%rip)
	leaq	36+fm6_bank(%rip), %rdi
	andq	$-8, %rdi
	leaq	28+fm6_bank(%rip), %rax
	subq	%rdi, %rax
	subq	%rax, %rsi
	leal	3584(%rax), %ecx
	movl	%ecx, %eax
	shrl	$3, %eax
	movl	%eax, %ecx
	rep movsq
	movl	$-1, 8+fm6_bank(%rip)
	movl	$0, %edx
	jmp	.L2079
.L2092:
	cmpb	$1, 4(%rdi)
	jne	.L2079
	cmpb	$27, 6(%rdi)
	jne	.L2079
	movzbl	9(%rdi), %r14d
	sall	$8, %r14d
	movzbl	10(%rdi), %eax
	sall	$16, %eax
	orl	%eax, %r14d
	movzbl	8(%rdi), %eax
	orl	%eax, %r14d
	movzbl	11(%rdi), %eax
	sall	$24, %eax
	orl	%eax, %r14d
	call	fm6_bank_empty
	addq	$16, %rbx
	leaq	28+fm6_bank(%rip), %r12
	movl	$0, %ebp
	jmp	.L2083
.L2082:
	addl	$1, %ebp
	subq	$-128, %rbx
	addq	$112, %r12
	cmpl	$27, %ebp
	je	.L2094
.L2083:
	btl	%ebp, %r14d
	jnc	.L2082
	leaq	128(%rsp), %r15
	movq	%r15, %rsi
	movq	%rbx, %rdi
	call	fm6_unpack
	movq	%rsp, %r13
	movl	$16, %ecx
	movl	$0, %eax
	movq	%r13, %rdi
	rep stosq
	movq	%r13, %rsi
	movq	%r15, %rdi
	call	fm6_pack
	movl	$128, %edx
	movq	%r13, %rsi
	movq	%r12, %rdi
	call	fm6_pack7
	movl	$1, %eax
	movl	%ebp, %ecx
	sall	%cl, %eax
	leaq	fm6_bank(%rip), %rcx
	orl	%eax, 8(%rcx)
	jmp	.L2082
.L2094:
	movl	$0, %edx
	jmp	.L2079
.L2093:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1194:
	.size	fm6_bank_import, .-fm6_bank_import
	.type	fm6_bank_boot, @function
fm6_bank_boot:
.LFB1196:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	cmpb	$0, flash_ok(%rip)
	jne	.L2100
.L2096:
	movl	$-1, %edi
	call	fm6_bank_check
.L2095:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2100:
	.cfi_restore_state
	movl	$4104, %edx
	leaq	fm6_rx(%rip), %rsi
	movl	$7, %edi
	call	st_load
	movl	%eax, %esi
	cmpl	$3612, %eax
	je	.L2101
	testl	%eax, %eax
	jle	.L2096
	leaq	fm6_rx(%rip), %rdi
	call	fm6_bank_import
	testl	%eax, %eax
	jne	.L2096
	movl	$3612, %edi
	call	fm6_bank_check
	jmp	.L2095
.L2101:
	leaq	fm6_rx(%rip), %rsi
	leaq	fm6_bank(%rip), %rdi
	movl	$451, %ecx
	rep movsq
	movl	(%rsi), %eax
	movl	%eax, (%rdi)
	movl	$3612, %edi
	call	fm6_bank_check
	jmp	.L2095
	.cfi_endproc
.LFE1196:
	.size	fm6_bank_boot, .-fm6_bank_boot
	.type	settings_import, @function
settings_import:
.LFB1557:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbx
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	cmpl	$764, %esi
	je	.L2130
	cmpl	$572, %esi
	jne	.L2105
	cmpl	$1346720308, (%rdi)
	sete	%dl
	movzbl	%dl, %edx
	movl	$0, %ebp
.L2106:
	cmpl	$40, %esi
	jne	.L2123
	movl	(%rbx), %ecx
	orl	%ebp, %edx
	cmpl	$1346720305, %ecx
	sete	%al
	movzbl	%al, %eax
	orl	%edx, %eax
	je	.L2102
	cmpl	$1346720305, %ecx
	jne	.L2110
	movq	8(%rbx), %r8
	movq	16(%rbx), %r9
	movq	%r8, (%rsp)
	movq	%r9, 8(%rsp)
	movq	24(%rbx), %rsi
	movq	32(%rbx), %rdi
	movq	%rsi, 16(%rsp)
	movq	%rdi, 24(%rsp)
	movq	%r8, 16(%rbx)
	movq	%r9, 24(%rbx)
	movq	%rsi, 32(%rbx)
	movq	%rdi, 40(%rbx)
	movl	$0, 12(%rbx)
	movl	$0, 8(%rbx)
.L2111:
	movl	$0, 48(%rbx)
.L2110:
	testl	%edx, %edx
	je	.L2131
	testl	%ebp, %ebp
	je	.L2113
.L2114:
	movl	$1346720309, (%rbx)
	movl	4(%rbx), %edi
	call	palette_from_stored
	movl	%eax, %edi
	movl	%eax, %eax
	imulq	$954437177, %rax, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,8), %eax
	subl	%eax, %edi
	addl	$64, %edi
	movl	%edi, 4(%rbx)
	movl	$1397052468, settings(%rip)
	call	palette_from_stored
	movl	%eax, 4+settings(%rip)
	movl	8(%rbx), %eax
	movl	%eax, 8+settings(%rip)
	movl	12(%rbx), %eax
	movl	%eax, 12+settings(%rip)
	movl	48(%rbx), %edx
	movl	%edx, %ecx
	andl	$-4, %ecx
	andl	$3, %edx
	cmpl	$1212957696, %ecx
	movl	$1, %ecx
	cmovne	%ecx, %edx
	movb	%dl, settings_hold(%rip)
	movl	%eax, %edx
	andl	$-2, %edx
	andl	$3, %eax
	cmpl	$1279607808, %edx
	movl	$0, %edx
	cmovne	%edx, %eax
	movb	%al, settings_leds(%rip)
	leaq	favorites(%rip), %rax
	leaq	52(%rbx), %rsi
	movl	$65, %ecx
	movq	%rax, %rdi
	rep movsq
	cmpl	$1, 516+favorites(%rip)
	sete	%al
	movzbl	%al, %eax
	movl	%eax, 516+favorites(%rip)
	movzbl	32+favorites(%rip), %edi
	movl	$0, %eax
	leaq	FM4_TO_FM6(%rip), %r9
	leaq	favorites(%rip), %rsi
	movl	$1, %r8d
	jmp	.L2118
.L2130:
	cmpl	$1346720309, (%rdi)
	sete	%dl
	movzbl	%dl, %edx
.L2104:
	cmpl	$48, %esi
	jne	.L2122
	movl	(%rbx), %ecx
	cmpl	$1346720306, %ecx
	sete	%al
	movzbl	%al, %eax
	orl	%edx, %eax
	je	.L2102
	movl	%edx, %ebp
	cmpl	$1346720306, %ecx
	je	.L2111
	jmp	.L2110
.L2105:
	cmpl	$52, %esi
	jne	.L2121
	cmpl	$1346720307, (%rdi)
	sete	%al
	movzbl	%al, %eax
	movl	$0, %edx
	movl	$0, %ebp
.L2107:
	orl	%ebp, %edx
	orl	%edx, %eax
	jne	.L2110
	jmp	.L2102
.L2121:
	movl	$0, %edx
	jmp	.L2104
.L2122:
	movl	%edx, %ebp
	movl	$0, %edx
	jmp	.L2106
.L2131:
	movq	$0, 52(%rbx)
	movq	$0, 564(%rbx)
	leaq	60(%rbx), %rdi
	andq	$-8, %rdi
	movl	%ebx, %eax
	subl	%edi, %eax
	leal	572(%rax), %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movl	$0, %eax
	rep stosq
.L2113:
	movq	$0, 572(%rbx)
	movq	$0, 756(%rbx)
	leaq	580(%rbx), %rdi
	andq	$-8, %rdi
	movl	%ebx, %eax
	subl	%edi, %eax
	leal	764(%rax), %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movl	$0, %eax
	rep stosq
	jmp	.L2114
.L2117:
	addq	$1, %rax
	cmpq	$8, %rax
	je	.L2132
.L2118:
	btl	%eax, %edi
	jnc	.L2117
	movzbl	(%r9,%rax), %ecx
	movl	%ecx, %edx
	shrb	$3, %dl
	andl	$31, %edx
	andl	$7, %ecx
	movl	%r8d, %r10d
	sall	%cl, %r10d
	orb	%r10b, 384(%rsi,%rdx)
	jmp	.L2117
.L2132:
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 32+favorites(%rip)
	movaps	%xmm0, 48+favorites(%rip)
	cmpl	$1346457141, 16(%rbx)
	je	.L2133
.L2119:
	movl	$2, %eax
	subl	%ebp, %eax
.L2102:
	movq	40(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L2134
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L2133:
	.cfi_restore_state
	movdqu	16(%rbx), %xmm1
	movaps	%xmm1, panel(%rip)
	movdqu	32(%rbx), %xmm2
	movaps	%xmm2, 16+panel(%rip)
	jmp	.L2119
.L2123:
	movl	$0, %eax
	jmp	.L2107
.L2134:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE1557:
	.size	settings_import, .-settings_import
	.section	.rodata.str1.1
.LC11:
	.string	"r+b"
.LC12:
	.string	"w+b"
	.section	.rodata.str1.8
	.align 8
.LC13:
	.string	"emu: flash file %s: cannot open (RAM only)\n"
	.text
	.type	emu_flash_open, @function
emu_flash_open:
.LFB690:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$1048576, %edx
	movl	$255, %esi
	leaq	emu_flash(%rip), %rdi
	call	memset@PLT
	movb	$1, flash_ok(%rip)
	cmpb	$0, emu_flash_path(%rip)
	jne	.L2141
.L2135:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2141:
	.cfi_restore_state
	leaq	.LC11(%rip), %rsi
	leaq	emu_flash_path(%rip), %rdi
	call	fopen@PLT
	movq	%rax, %rcx
	movq	%rax, emu_flash_f(%rip)
	testq	%rax, %rax
	je	.L2137
	movl	$1048576, %edx
	movl	$1, %esi
	leaq	emu_flash(%rip), %rdi
	call	fread@PLT
	cmpq	$1048575, %rax
	jbe	.L2142
.L2138:
	movq	emu_flash_f(%rip), %rdi
	testq	%rdi, %rdi
	je	.L2143
	movl	$0, %edx
	movl	$0, %esi
	call	fseek@PLT
	movq	emu_flash_f(%rip), %rcx
	movl	$1048576, %edx
	movl	$1, %esi
	leaq	emu_flash(%rip), %rdi
	call	fwrite@PLT
	movq	emu_flash_f(%rip), %rdi
	call	fflush@PLT
	jmp	.L2135
.L2142:
	movl	$1048576, %edx
	subq	%rax, %rdx
	leaq	emu_flash(%rip), %rcx
	leaq	(%rax,%rcx), %rdi
	movq	%rdx, %rcx
	movl	$255, %esi
	call	__memset_chk@PLT
	jmp	.L2138
.L2137:
	leaq	.LC12(%rip), %rsi
	leaq	emu_flash_path(%rip), %rdi
	call	fopen@PLT
	movq	%rax, emu_flash_f(%rip)
	jmp	.L2138
.L2143:
	leaq	emu_flash_path(%rip), %rcx
	leaq	.LC13(%rip), %rdx
	movl	$2, %esi
	movq	stderr(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	jmp	.L2135
	.cfi_endproc
.LFE690:
	.size	emu_flash_open, .-emu_flash_open
	.type	p5_mod_samples, @function
p5_mod_samples:
.LFB306:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %r10
	movq	%rsi, %r9
	movl	%edx, %ebp
	movl	%ecx, %r13d
	movl	768(%rdi), %r15d
	cmpl	$0, 780(%rdi)
	jne	.L2145
	movl	$5339475, 780(%rdi)
.L2145:
	leaq	784(%r10), %rcx
	leaq	848(%r10), %r14
	movl	%r15d, %esi
	movl	$32767, %r12d
	subl	%r8d, %r12d
	leaq	P5_EXP2_Q14(%rip), %r11
	movl	%r15d, -4(%rsp)
	jmp	.L2155
.L2165:
	movl	$0, %edi
	movl	$0, %eax
.L2146:
	cmpb	$0, 24(%r9)
	je	.L2147
	movl	%esi, %ebx
	shrl	$17, %ebx
	testl	%esi, %esi
	js	.L2148
	leal	-16384(%rbx,%rbx), %r15d
.L2149:
	addl	%r15d, %eax
	addl	$1, %edi
	cmpb	$0, 25(%r9)
	je	.L2150
.L2164:
	movl	%esi, %ebx
	sarl	$31, %ebx
	notl	%ebx
	andl	$32767, %ebx
	addl	%ebx, %eax
	addl	$1, %edi
	cmpl	$3, %edi
	jne	.L2150
	movslq	%eax, %rdi
	imulq	$1431655766, %rdi, %rdi
	shrq	$32, %rdi
	sarl	$31, %eax
	movl	%eax, %ebx
	movl	%edi, %eax
	subl	%ebx, %eax
	jmp	.L2152
.L2148:
	addl	%ebx, %ebx
	movl	$49151, %r15d
	subl	%ebx, %r15d
	jmp	.L2149
.L2150:
	movl	%eax, %ebx
	sarl	%ebx
	cmpl	$2, %edi
	cmove	%ebx, %eax
.L2152:
	imull	%r12d, %eax
	sarl	$15, %eax
	imull	%r8d, %edx
	sarl	$15, %edx
	addl	%edx, %eax
	imull	%r13d, %eax
	sarl	$15, %eax
	movw	%ax, (%rcx)
	imull	$12834, %eax, %eax
	addl	$8192, %eax
	sarl	$14, %eax
	movl	$65535, %ebx
	cmpl	%ebx, %eax
	cmovle	%eax, %ebx
	movl	$-65535, %edx
	cmpl	%edx, %ebx
	cmovl	%edx, %ebx
	movzbl	%bh, %edx
	movl	%edx, %edi
	addl	$1, %edx
	movl	%edx, %edx
	movzwl	(%r11,%rdx,2), %edx
	movzwl	(%r11,%rdi,2), %edi
	subl	%edi, %edx
	movzbl	%bl, %ebx
	imull	%ebx, %edx
	subl	$-128, %edx
	shrl	$8, %edx
	addl	%edi, %edx
	leal	(%rdx,%rdx), %edi
	testl	%eax, %eax
	cmovns	%edi, %edx
	movw	%dx, 64(%rcx)
	addl	%ebp, %esi
	addq	$2, %rcx
	cmpq	%r14, %rcx
	je	.L2172
.L2155:
	movl	780(%r10), %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$17, %eax
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%eax, %edx
	movl	%edx, 780(%r10)
	shrl	$17, %edx
	subl	$16384, %edx
	cmpb	$0, 23(%r9)
	je	.L2165
	movl	%esi, %eax
	shrl	$17, %eax
	movl	$1, %edi
	jmp	.L2146
.L2172:
	movl	-4(%rsp), %r15d
	sall	$5, %ebp
	addl	%r15d, %ebp
	movl	%ebp, 768(%r10)
	cmpb	$0, 23(%r9)
	je	.L2167
	movl	%ebp, %eax
	shrl	$17, %eax
	movl	$1, %edx
.L2156:
	cmpb	$0, 24(%r9)
	je	.L2157
	movl	%ebp, %ecx
	shrl	$17, %ecx
	testl	%ebp, %ebp
	js	.L2158
	leal	-16384(%rcx,%rcx), %ecx
.L2159:
	addl	%ecx, %eax
	addl	$1, %edx
	cmpb	$0, 25(%r9)
	je	.L2160
.L2163:
	sarl	$31, %ebp
	notl	%ebp
	andl	$32767, %ebp
	addl	%ebp, %eax
	addl	$1, %edx
	cmpl	$3, %edx
	jne	.L2160
	movslq	%eax, %rdx
	imulq	$1431655766, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$31, %eax
	movl	%eax, %ecx
	movl	%edx, %eax
	subl	%ecx, %eax
	jmp	.L2162
.L2167:
	movl	$0, %edx
	movl	$0, %eax
	jmp	.L2156
.L2158:
	leal	(%rcx,%rcx), %esi
	movl	$49151, %ecx
	subl	%esi, %ecx
	jmp	.L2159
.L2160:
	movl	%eax, %ecx
	sarl	%ecx
	cmpl	$2, %edx
	cmove	%ecx, %eax
.L2162:
	movl	%eax, 772(%r10)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2157:
	.cfi_restore_state
	cmpb	$0, 25(%r9)
	je	.L2162
	jmp	.L2163
.L2147:
	cmpb	$0, 25(%r9)
	jne	.L2164
	jmp	.L2152
	.cfi_endproc
.LFE306:
	.size	p5_mod_samples, .-p5_mod_samples
	.type	master_loop, @function
master_loop:
.LFB562:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, -48(%rsp)
	movl	%esi, -40(%rsp)
	movl	%edx, -68(%rsp)
	movl	%ecx, -36(%rsp)
	movl	dc_l(%rip), %r10d
	movl	dce_l(%rip), %eax
	movl	%eax, -88(%rsp)
	movl	dc_r(%rip), %r9d
	movl	dce_r(%rip), %eax
	movl	%eax, -84(%rsp)
	movl	lim_env(%rip), %r8d
	movl	lim_g(%rip), %eax
	movl	%eax, -72(%rsp)
	movl	lc_l1(%rip), %eax
	movl	%eax, -76(%rsp)
	movl	lc_l2(%rip), %eax
	movl	%eax, -80(%rsp)
	movl	lc_r1(%rip), %r13d
	movl	lc_r2(%rip), %r12d
	movl	lce(%rip), %eax
	movl	%eax, -60(%rsp)
	movl	4+lce(%rip), %eax
	movl	%eax, -56(%rsp)
	movl	8+lce(%rip), %eax
	movl	%eax, -52(%rsp)
	movl	12+lce(%rip), %eax
	movl	%eax, -64(%rsp)
	movl	sb_lp1(%rip), %eax
	movl	%eax, -4(%rsp)
	movl	sb_lp2(%rip), %eax
	movl	%eax, -16(%rsp)
	movl	sb_lp3(%rip), %eax
	movl	%eax, -20(%rsp)
	movl	sb_lp4(%rip), %eax
	movl	%eax, -28(%rsp)
	movl	sb_env(%rip), %eax
	movl	%eax, -32(%rsp)
	movl	sb_h1(%rip), %eax
	movl	%eax, -12(%rsp)
	movl	sb_h2(%rip), %eax
	movl	%eax, -8(%rsp)
	movl	sb_hl(%rip), %eax
	movl	%eax, -24(%rsp)
	testl	%esi, %esi
	je	.L2174
	movl	$0, %r11d
	jmp	.L2191
.L2203:
	leal	(%rdi,%rsi), %eax
	sarl	%eax
	movl	-4(%rsp), %ecx
	subl	%ecx, %eax
	imull	$692, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %ecx
	movl	%ecx, -4(%rsp)
	movl	%ecx, %eax
	movl	-16(%rsp), %ecx
	subl	%ecx, %eax
	imull	$692, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %ecx
	movl	%ecx, -16(%rsp)
	movl	%ecx, %eax
	movl	-20(%rsp), %ecx
	subl	%ecx, %eax
	imull	$692, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %ecx
	movl	%ecx, -20(%rsp)
	movl	%ecx, %eax
	movl	-28(%rsp), %ecx
	subl	%ecx, %eax
	imull	$692, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %ecx
	movl	%ecx, -28(%rsp)
	movl	%ecx, %eax
	negl	%eax
	cmovs	%ecx, %eax
	movl	-32(%rsp), %ecx
	cmpl	%ecx, %eax
	jle	.L2177
	subl	%ecx, %eax
	sarl	$2, %eax
	addl	%eax, %ecx
	movl	%ecx, -32(%rsp)
.L2178:
	movl	-32(%rsp), %ecx
	movl	%ecx, %eax
	negl	%eax
	movl	-28(%rsp), %edx
	sall	$3, %edx
	cmpl	%ecx, %edx
	cmovle	%edx, %ecx
	cmpl	%edx, %eax
	cmovle	%ecx, %eax
	movl	%eax, %edx
	movl	-12(%rsp), %ecx
	subl	%ecx, %edx
	sarl	$5, %edx
	addl	%edx, %ecx
	movl	%ecx, -12(%rsp)
	subl	%ecx, %eax
	movl	%eax, %edx
	movl	-8(%rsp), %ecx
	subl	%ecx, %edx
	sarl	$5, %edx
	addl	%edx, %ecx
	movl	%ecx, -8(%rsp)
	subl	%ecx, %eax
	movl	-24(%rsp), %ecx
	subl	%ecx, %eax
	sarl	$3, %eax
	addl	%eax, %ecx
	movl	%ecx, -24(%rsp)
	leal	(%rcx,%rcx,2), %edx
	movl	$5, %ecx
	jmp	.L2176
.L2177:
	movl	-32(%rsp), %ecx
	testl	%ecx, %ecx
	jle	.L2178
	movl	%ecx, %eax
	sarl	$11, %eax
	addl	$1, %eax
	subl	%eax, %ecx
	movl	%ecx, -32(%rsp)
	jmp	.L2178
.L2200:
	movl	$32768, %edx
.L2193:
	movl	-72(%rsp), %eax
	subl	%eax, %edx
	sarl	$6, %edx
	addl	%edx, %eax
	movl	%eax, -72(%rsp)
	movl	%ecx, %r8d
	cmpl	$32767, %eax
	jg	.L2184
.L2183:
	sarl	$4, %esi
	movl	-72(%rsp), %eax
	imull	%eax, %esi
	sarl	$11, %esi
	sarl	$4, %edi
	imull	%eax, %edi
	sarl	$11, %edi
	movl	%ecx, %r8d
.L2184:
	movl	%esi, %edx
	negl	%edx
	cmovs	%esi, %edx
	movl	%edx, %ecx
	sarl	$8, %ecx
	movl	$31588, %eax
	cmpl	$65535, %edx
	jg	.L2187
	movslq	%ecx, %rax
	leaq	TANH_Q15(%rip), %r15
	movswl	(%r15,%rax,2), %r14d
	addl	$1, %ecx
	movslq	%ecx, %rcx
	movswl	(%r15,%rcx,2), %eax
	subl	%r14d, %eax
	movzbl	%dl, %edx
	imull	%edx, %eax
	sarl	$8, %eax
	addl	%r14d, %eax
.L2187:
	movl	%eax, %edx
	negl	%edx
	testl	%esi, %esi
	cmovs	%edx, %eax
	movl	%eax, (%rbx)
	movl	%edi, %edx
	negl	%edx
	cmovs	%edi, %edx
	movl	%edx, %ecx
	sarl	$8, %ecx
	movl	$31588, %eax
	cmpl	$65535, %edx
	jg	.L2189
	movslq	%ecx, %rax
	leaq	TANH_Q15(%rip), %rbx
	movswl	(%rbx,%rax,2), %esi
	addl	$1, %ecx
	movslq	%ecx, %rcx
	movswl	(%rbx,%rcx,2), %eax
	subl	%esi, %eax
	movzbl	%dl, %edx
	imull	%edx, %eax
	sarl	$8, %eax
	addl	%esi, %eax
.L2189:
	movl	%eax, %edx
	negl	%edx
	testl	%edi, %edi
	cmovs	%edx, %eax
	movl	%eax, 0(%rbp)
	addl	$1, %r11d
	cmpl	%r11d, -40(%rsp)
	je	.L2174
.L2191:
	leal	(%r11,%r11), %eax
	movl	%eax, %edx
	movq	-48(%rsp), %rdi
	leaq	(%rdi,%rdx,4), %rbx
	movl	(%rbx), %esi
	leal	1(%rax), %eax
	leaq	(%rdi,%rax,4), %rbp
	movl	0(%rbp), %edi
	movl	%esi, %edx
	sall	$6, %edx
	subl	%r10d, %edx
	movl	-88(%rsp), %eax
	addl	%eax, %edx
	movl	%edx, %eax
	sarl	$12, %eax
	andl	$4095, %edx
	movl	%edx, -88(%rsp)
	addl	%eax, %r10d
	leal	32(%r10), %eax
	sarl	$6, %eax
	subl	%eax, %esi
	movl	%edi, %eax
	sall	$6, %eax
	subl	%r9d, %eax
	movl	-84(%rsp), %ecx
	addl	%ecx, %eax
	movl	%eax, %edx
	sarl	$12, %edx
	andl	$4095, %eax
	movl	%eax, -84(%rsp)
	addl	%edx, %r9d
	leal	32(%r9), %eax
	sarl	$6, %eax
	subl	%eax, %edi
	movl	-68(%rsp), %eax
	testl	%eax, %eax
	je	.L2175
	movl	$6, %ecx
	movl	$0, %edx
	cmpl	$2, %eax
	je	.L2203
.L2176:
	movl	%esi, %eax
	movl	-76(%rsp), %r15d
	subl	%r15d, %eax
	movl	-60(%rsp), %r14d
	addl	%r14d, %eax
	movl	%eax, %r14d
	sarl	%cl, %r14d
	movl	%r14d, %r15d
	sall	%cl, %r15d
	subl	%r15d, %eax
	movl	%eax, -60(%rsp)
	addl	%r14d, -76(%rsp)
	movl	-76(%rsp), %r15d
	subl	%r15d, %esi
	movl	%esi, %eax
	movl	-80(%rsp), %r14d
	subl	%r14d, %eax
	movl	-56(%rsp), %r15d
	addl	%r15d, %eax
	movl	%eax, %r15d
	sarl	%cl, %r15d
	movl	%r15d, %r14d
	sall	%cl, %r15d
	subl	%r15d, %eax
	movl	%eax, -56(%rsp)
	addl	%r14d, -80(%rsp)
	movl	-80(%rsp), %eax
	subl	%eax, %esi
	addl	%edx, %esi
	movl	%edi, %eax
	subl	%r13d, %eax
	movl	-52(%rsp), %r14d
	addl	%r14d, %eax
	movl	%eax, %r14d
	sarl	%cl, %r14d
	movl	%r14d, %r15d
	sall	%cl, %r15d
	subl	%r15d, %eax
	movl	%eax, -52(%rsp)
	addl	%r14d, %r13d
	subl	%r13d, %edi
	movl	%edi, %eax
	subl	%r12d, %eax
	movl	-64(%rsp), %r14d
	addl	%r14d, %eax
	movl	%eax, %r14d
	sarl	%cl, %r14d
	movl	%r14d, %r15d
	sall	%cl, %r15d
	subl	%r15d, %eax
	movl	%eax, -64(%rsp)
	addl	%r14d, %r12d
	subl	%r12d, %edi
	addl	%edx, %edi
.L2175:
	movl	%esi, %ecx
	negl	%ecx
	cmovs	%esi, %ecx
	movl	%edi, %eax
	negl	%eax
	cmovs	%edi, %eax
	cmpl	%eax, %ecx
	cmovl	%eax, %ecx
	cmpl	$0, -36(%rsp)
	je	.L2180
	cmpl	%r8d, %ecx
	jg	.L2181
	cmpl	$18000, %r8d
	jle	.L2195
	leal	-18000(%r8), %eax
	sarl	$12, %eax
	addl	$1, %eax
	movl	%r8d, %ecx
	subl	%eax, %ecx
.L2181:
	cmpl	$18000, %ecx
	jle	.L2182
	movl	$589824000, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %edx
	movl	-72(%rsp), %r8d
	cmpl	%r8d, %eax
	jl	.L2193
	movl	%eax, -72(%rsp)
	jmp	.L2183
.L2180:
	cmpl	%r8d, %ecx
	jle	.L2185
	subl	%r8d, %ecx
	sarl	$2, %ecx
	addl	%ecx, %r8d
.L2186:
	cmpl	$18000, %r8d
	jle	.L2184
	movl	$589824000, %eax
	movl	$0, %edx
	divl	%r8d
	sarl	$4, %esi
	imull	%eax, %esi
	sarl	$11, %esi
	sarl	$4, %edi
	imull	%eax, %edi
	sarl	$11, %edi
	jmp	.L2184
.L2185:
	cmpl	$18000, %r8d
	jle	.L2184
	leal	-18000(%r8), %eax
	sarl	$12, %eax
	addl	$1, %eax
	subl	%eax, %r8d
	jmp	.L2186
.L2174:
	movl	%r10d, dc_l(%rip)
	movl	-88(%rsp), %eax
	movl	%eax, dce_l(%rip)
	movl	%r9d, dc_r(%rip)
	movl	-84(%rsp), %eax
	movl	%eax, dce_r(%rip)
	movl	%r8d, lim_env(%rip)
	movl	-72(%rsp), %eax
	movl	%eax, lim_g(%rip)
	movl	-68(%rsp), %eax
	testl	%eax, %eax
	je	.L2173
	movl	-76(%rsp), %ebx
	movl	%ebx, lc_l1(%rip)
	movl	-80(%rsp), %ebx
	movl	%ebx, lc_l2(%rip)
	movl	%r13d, lc_r1(%rip)
	movl	%r12d, lc_r2(%rip)
	movl	-60(%rsp), %ebx
	movl	%ebx, lce(%rip)
	movl	-56(%rsp), %ebx
	movl	%ebx, 4+lce(%rip)
	movl	-52(%rsp), %ebx
	movl	%ebx, 8+lce(%rip)
	movl	-64(%rsp), %ebx
	movl	%ebx, 12+lce(%rip)
	cmpl	$2, %eax
	je	.L2204
.L2173:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2204:
	.cfi_restore_state
	movl	-4(%rsp), %eax
	movl	%eax, sb_lp1(%rip)
	movl	-16(%rsp), %eax
	movl	%eax, sb_lp2(%rip)
	movl	-20(%rsp), %eax
	movl	%eax, sb_lp3(%rip)
	movl	-28(%rsp), %eax
	movl	%eax, sb_lp4(%rip)
	movl	-32(%rsp), %eax
	movl	%eax, sb_env(%rip)
	movl	-12(%rsp), %eax
	movl	%eax, sb_h1(%rip)
	movl	-8(%rsp), %eax
	movl	%eax, sb_h2(%rip)
	movl	-24(%rsp), %eax
	movl	%eax, sb_hl(%rip)
	jmp	.L2173
.L2195:
	movl	%r8d, %ecx
.L2182:
	cmpl	$32768, -72(%rsp)
	jg	.L2200
	movl	%ecx, %r8d
	movl	$32768, -72(%rsp)
	jmp	.L2184
	.cfi_endproc
.LFE562:
	.size	master_loop, .-master_loop
	.type	out_master, @function
out_master:
.LFB574:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %r12
	movq	%rsi, %rdi
	movq	%rdx, %r9
	movq	%rcx, %rsi
	movl	%r8d, %r11d
	movzbl	fx_out_mode(%rip), %eax
	movb	%al, 47(%rsp)
	movzbl	%al, %r10d
	testl	%r10d, %r10d
	je	.L2206
	testl	%r8d, %r8d
	je	.L2207
	movl	%r8d, %ebx
	salq	$2, %rbx
	movl	$0, %edx
	movl	$0, %ecx
	movl	$0, %ebp
	jmp	.L2209
.L2208:
	movl	%ecx, %r13d
	movl	%eax, %r8d
	addl	(%rdi,%rdx), %r8d
	leal	(%r8,%r8,2), %r8d
	sall	$6, %r8d
	sarl	$6, %r8d
	movl	%r8d, (%r12,%r13,4)
	leal	1(%rcx), %r8d
	addl	(%r9,%rdx), %eax
	leal	(%rax,%rax,2), %eax
	sall	$6, %eax
	sarl	$6, %eax
	movl	%eax, (%r12,%r8,4)
	addl	$2, %ecx
	addq	$4, %rdx
	cmpq	%rbx, %rdx
	je	.L2210
.L2209:
	movl	%ebp, %eax
	testq	%rsi, %rsi
	je	.L2208
	movl	(%rsi,%rdx), %eax
	jmp	.L2208
.L2206:
	movzbl	fx_usb_fixed(%rip), %eax
	testb	%al, %al
	movl	$4096, %r8d
	cmove	68+song(%rip), %r8d
	testl	%r11d, %r11d
	je	.L2207
	movl	%r11d, %ebp
	salq	$2, %rbp
	movl	%r10d, %ecx
	movl	$0, %edx
	movl	$0, %r14d
	jmp	.L2213
.L2212:
	movl	%ecx, %r13d
	movl	%eax, %ebx
	addl	(%rdi,%rdx), %ebx
	sarl	$2, %ebx
	imull	%r8d, %ebx
	sarl	$10, %ebx
	movl	%ebx, (%r12,%r13,4)
	leal	1(%rcx), %ebx
	addl	(%r9,%rdx), %eax
	sarl	$2, %eax
	imull	%r8d, %eax
	sarl	$10, %eax
	movl	%eax, (%r12,%rbx,4)
	addl	$2, %ecx
	addq	$4, %rdx
	cmpq	%rdx, %rbp
	je	.L2210
.L2213:
	movl	%r14d, %eax
	testq	%rsi, %rsi
	je	.L2212
	movl	(%rsi,%rdx), %eax
	jmp	.L2212
.L2299:
	movl	%ebx, %eax
	subl	%edi, %eax
.L2217:
	movl	%r9d, %r13d
	testl	%eax, %eax
	js	.L2219
.L2218:
	movl	$4096, %r13d
	cmpl	%r13d, %eax
	cmovle	%eax, %r13d
.L2219:
	movl	%edx, %eax
	leaq	(%r12,%rax,4), %rbp
	movl	0(%rbp), %eax
	movl	$8388607, %r14d
	cmpl	%r14d, %eax
	cmovg	%r14d, %eax
	movl	$-8388607, %r14d
	cmpl	%r14d, %eax
	cmovl	%r14d, %eax
	sarl	$4, %eax
	imull	%r13d, %eax
	sarl	$8, %eax
	movl	%eax, 0(%rbp)
	leal	1(%rdx), %eax
	leaq	(%r12,%rax,4), %rbp
	movl	0(%rbp), %eax
	movl	$8388607, %r14d
	cmpl	%r14d, %eax
	cmovg	%r14d, %eax
	movl	$-8388607, %r14d
	cmpl	%r14d, %eax
	cmovl	%r14d, %eax
	sarl	$4, %eax
	imull	%r13d, %eax
	sarl	$8, %eax
	movl	%eax, 0(%rbp)
	addl	$1, %ecx
	addl	$2, %edx
	subl	$8, %edi
	cmpl	%r11d, %ecx
	jnb	.L2274
.L2220:
	movl	%edi, %eax
	cmpl	$15, %r8d
	jbe	.L2217
	cmpl	$16, %r8d
	ja	.L2299
	movl	%r9d, %eax
	jmp	.L2218
.L2309:
	cmpb	$0, 47(%rsp)
	sete	fx_out_mode(%rip)
.L2215:
	leal	1(%rsi), %eax
.L2222:
	movb	%al, fx_out_fade(%rip)
.L2214:
	movzbl	47(%rsp), %eax
	movb	%al, fx_out_blk(%rip)
	testl	%r10d, %r10d
	jne	.L2223
	movzbl	fx_lowcut(%rip), %eax
	movzbl	%al, %eax
	cmpb	$0, fx_smooth(%rip)
	je	.L2224
	testl	%eax, %eax
	je	.L2300
	cmpl	$2, %eax
	je	.L2301
	movl	$1, %ecx
	movl	$1, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2278:
	movl	$1, %esi
	jmp	.L2215
.L2300:
	movl	$1, %ecx
	movl	$0, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2301:
	movl	$1, %ecx
	movl	$2, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2224:
	testl	%eax, %eax
	je	.L2302
	cmpl	$2, %eax
	je	.L2303
	movl	$0, %ecx
	movl	$1, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2302:
	movl	$0, %ecx
	movl	$0, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2303:
	movl	$0, %ecx
	movl	$2, %edx
	movl	%r11d, %esi
	movq	%r12, %rdi
	call	master_loop
	jmp	.L2226
.L2223:
	movl	dc_l(%rip), %r10d
	movl	dce_l(%rip), %r14d
	movl	dc_r(%rip), %r15d
	movl	dce_r(%rip), %r13d
	movl	cln_w(%rip), %esi
	testl	%r11d, %r11d
	je	.L2230
	movl	cln_env(%rip), %eax
	movl	cln_gs(%rip), %edi
	movl	%edi, 8(%rsp)
	movl	cln_pk(%rip), %ecx
	movl	cln_hold(%rip), %edi
	movl	%edi, 36(%rsp)
	movl	cln_top(%rip), %edi
	movl	%edi, 40(%rsp)
	movl	cln_hlen(%rip), %edi
	movl	%edi, 32(%rsp)
	movl	cln_wg(%rip), %edi
	movl	%edi, 20(%rsp)
	movl	cln_wi(%rip), %edi
	movl	%edi, 16(%rsp)
	movq	%r12, %rdi
	movl	%r11d, 4(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 51(%rsp)
	leaq	cln_dl(%rip), %r8
	leaq	256(%r8), %r9
	movl	%r13d, 12(%rsp)
	movl	%eax, %r13d
	movq	%r12, 56(%rsp)
	movl	%r11d, 68(%rsp)
	jmp	.L2259
.L2305:
	movl	$1, %ebx
.L2233:
	movl	%esi, %eax
	subl	%ebx, %eax
	andl	$31, %eax
	addl	%eax, %eax
	movl	%eax, %ebp
	movl	(%r8,%rbp,4), %edx
	movl	$8388607, %r12d
	cmpl	%r12d, %edx
	cmovg	%r12d, %edx
	movl	$-8388607, %r12d
	cmpl	%r12d, %edx
	cmovl	%r12d, %edx
	movl	%edx, (%r8,%rbp,4)
	addl	$1, %eax
	movl	%eax, %eax
	movl	(%r8,%rax,4), %edx
	movl	$8388607, %ebp
	cmpl	%ebp, %edx
	cmovg	%ebp, %edx
	movl	$-8388607, %ebp
	cmpl	%ebp, %edx
	cmovl	%ebp, %edx
	movl	%edx, (%r8,%rax,4)
	addl	$1, %ebx
	cmpl	%ebx, %r11d
	jnb	.L2233
	movl	$8388607, %r12d
	jmp	.L2232
.L2234:
	cmpl	%ecx, %r12d
	movl	%ecx, %eax
	cmovge	%r12d, %eax
	movl	%r12d, %ecx
	jmp	.L2236
.L2237:
	movl	%r13d, %ebx
	sarl	$3, %ebx
	movl	%r13d, %edx
	subl	%ebx, %edx
	cmpl	%ecx, %edx
	jge	.L2240
	movl	32(%rsp), %ebx
	cmpl	%ebx, 36(%rsp)
	jnb	.L2241
	movl	%ebx, 36(%rsp)
	movb	$1, 48(%rsp)
.L2241:
	movl	%r13d, %ebx
	sarl	$8, %ebx
	movl	%r13d, %edx
	subl	%ebx, %edx
	cmpl	%edx, %ecx
	jge	.L2282
	movl	40(%rsp), %ebx
	cmpl	$8819, %ebx
	ja	.L2243
	addl	%r11d, %ebx
	movl	%ebx, 40(%rsp)
	movb	$1, 50(%rsp)
	jmp	.L2247
.L2243:
	movl	$104000, %edx
	cmpl	%edx, %eax
	cmovge	%eax, %edx
	movl	%r13d, %eax
	subl	%edx, %eax
	sarl	$10, %eax
	movl	%r13d, %edx
	subl	%eax, %edx
.L2244:
	cmpl	%r13d, %edx
	je	.L2247
	movl	%edx, %r13d
	jmp	.L2239
.L2240:
	movl	36(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L2245
	movl	%ebx, %eax
	subl	%r11d, %eax
	cmpl	%ebx, %r11d
	movl	$0, %ebx
	cmovnb	%ebx, %eax
	movl	%eax, 36(%rsp)
	movb	$1, 48(%rsp)
	jmp	.L2247
.L2245:
	cmpl	$104000, %r13d
	jle	.L2247
	leal	-104000(%r13), %ebx
	sarl	$13, %ebx
	addl	$4, %ebx
	imull	%r11d, %ebx
	movl	%r13d, %edx
	subl	%ebx, %edx
	movl	$104000, %ebx
	cmpl	%ebx, %edx
	cmovl	%ebx, %edx
	cmpl	%eax, %edx
	cmovl	%eax, %edx
	movb	$1, 46(%rsp)
	movl	$8820, 32(%rsp)
	jmp	.L2244
.L2248:
	movb	$1, 49(%rsp)
	movb	$1, 51(%rsp)
.L2247:
	movl	16(%rsp), %eax
	leaq	cln_wh(%rip), %rbx
	movl	(%rbx,%rax,4), %edx
	movq	%rbx, %rbp
	movl	20(%rsp), %ebx
	movl	%ebx, 0(%rbp,%rax,4)
	movl	8(%rsp), %ebp
	movl	%ebp, %eax
	subl	%edx, %eax
	addl	%ebx, %eax
	cmpl	$31, 4(%rsp)
	cmovbe	%ebx, %eax
	movl	%eax, %ebx
	cmpl	$32768, %ebp
	jne	.L2287
	cmpl	$32768, %eax
	jne	.L2287
.L2250:
	leal	(%r11,%r11), %eax
	leaq	(%rdi,%rax,4), %rdi
	movl	$0, 16(%rsp)
	subl	%r11d, 4(%rsp)
	je	.L2304
	movl	%ebx, 8(%rsp)
.L2259:
	movl	$32, %r11d
	movl	4(%rsp), %eax
	cmpl	%r11d, %eax
	cmovbe	%eax, %r11d
	movl	$0, %ebp
	movl	$0, %r12d
	movl	%ecx, 24(%rsp)
	movl	12(%rsp), %ebx
	movl	%r13d, 28(%rsp)
.L2231:
	movl	(%rdi,%rbp,8), %ecx
	movl	%ecx, %edx
	sall	$6, %edx
	subl	%r10d, %edx
	addl	%r14d, %edx
	movl	%edx, %eax
	sarl	$12, %eax
	andl	$4095, %edx
	movl	%edx, %r14d
	addl	%eax, %r10d
	leal	32(%r10), %eax
	sarl	$6, %eax
	subl	%eax, %ecx
	movl	4(%rdi,%rbp,8), %edx
	movl	%edx, %eax
	sall	$6, %eax
	subl	%r15d, %eax
	addl	%eax, %ebx
	movl	%ebx, %eax
	sarl	$12, %eax
	andl	$4095, %ebx
	addl	%eax, %r15d
	leal	32(%r15), %eax
	sarl	$6, %eax
	subl	%eax, %edx
	movl	%ecx, %eax
	negl	%eax
	cmovs	%ecx, %eax
	movl	%edx, %r13d
	negl	%r13d
	cmovs	%edx, %r13d
	cmpl	%r13d, %eax
	cmovl	%r13d, %eax
	cmpl	%eax, %r12d
	cmovl	%eax, %r12d
	movl	%esi, %eax
	andl	$31, %eax
	addl	%eax, %eax
	movl	%eax, %r13d
	movl	(%r8,%r13,4), %r13d
	movl	%r13d, (%rdi,%rbp,8)
	addl	$1, %eax
	movl	%eax, %eax
	movl	(%r8,%rax,4), %eax
	movl	%eax, 4(%rdi,%rbp,8)
	leal	(%rsi,%rsi), %eax
	movl	%eax, %r13d
	movl	%ecx, (%r8,%r13,4)
	leal	1(%rax), %eax
	movl	%edx, (%r8,%rax,4)
	addl	$1, %esi
	andl	$31, %esi
	addq	$1, %rbp
	cmpl	%r11d, %ebp
	jb	.L2231
	movl	24(%rsp), %ecx
	movl	%ebx, 12(%rsp)
	movl	28(%rsp), %r13d
	cmpl	$8388607, %r12d
	jg	.L2305
.L2232:
	cmpl	$31, 4(%rsp)
	ja	.L2234
	cmpl	%r12d, %ecx
	cmovl	%r12d, %ecx
	leaq	cln_dl(%rip), %rdx
.L2235:
	movl	(%rdx), %ebx
	movl	%ebx, %eax
	negl	%eax
	cmovs	%ebx, %eax
	cmpl	%eax, %ecx
	cmovl	%eax, %ecx
	addq	$4, %rdx
	cmpq	%rdx, %r9
	jne	.L2235
	movl	%ecx, %eax
.L2236:
	cmpl	%r13d, %eax
	jle	.L2237
	movl	%eax, %edx
	subl	%r13d, %edx
	movl	%r13d, %ebx
	sarl	%ebx
	cmpl	%ebx, %edx
	movzbl	46(%rsp), %ebp
	movl	$1, %r12d
	cmovg	%r12d, %ebp
	movb	%bpl, 46(%rsp)
	movl	$1764, %edx
	cmovle	32(%rsp), %edx
	movl	%edx, 32(%rsp)
	movl	%edx, 36(%rsp)
	movl	%eax, %r13d
	movb	$1, 50(%rsp)
	movl	$0, 40(%rsp)
	movb	$1, 48(%rsp)
.L2239:
	movl	$32768, 20(%rsp)
	cmpl	$104000, %r13d
	jle	.L2248
	movl	$-887095296, %eax
	movl	$0, %edx
	divl	%r13d
	movl	%eax, 20(%rsp)
	jmp	.L2248
.L2287:
	movl	8(%rsp), %eax
	movl	%eax, %r12d
	imull	%r11d, %r12d
	movl	%ebx, %edx
	subl	%eax, %edx
	movl	$0, %ebp
	movl	%esi, 8(%rsp)
	movl	%ecx, 16(%rsp)
	movl	%ebx, 24(%rsp)
	movl	%edx, %esi
	movl	%r15d, 28(%rsp)
	movl	%r10d, 52(%rsp)
	movl	4(%rsp), %r10d
	movl	%r13d, 64(%rsp)
	jmp	.L2258
.L2252:
	movl	%r12d, %eax
	movl	$0, %edx
	divl	%r11d
.L2253:
	movl	(%rdi,%rbp,8), %ecx
	movl	%ecx, %edx
	sarl	$8, %edx
	imull	%eax, %edx
	sarl	$7, %edx
	movzbl	%cl, %ecx
	imull	%eax, %ecx
	sarl	$15, %ecx
	addl	%ecx, %edx
	movl	%edx, %ecx
	negl	%ecx
	cmovs	%edx, %ecx
	cmpl	$104000, %ecx
	jle	.L2254
	subl	$104000, %ecx
	movl	$54136, %ebx
	cmpl	%ebx, %ecx
	cmovg	%ebx, %ecx
	imull	$9917, %ecx, %ecx
	sarl	$13, %ecx
	movl	%ecx, %ebx
	negl	%ebx
	cmovs	%ecx, %ebx
	movl	%ebx, %ecx
	sarl	$8, %ecx
	movslq	%ecx, %r15
	leaq	TANH_Q15(%rip), %r13
	movswl	0(%r13,%r15,2), %r15d
	addl	$1, %ecx
	movslq	%ecx, %rcx
	movswl	0(%r13,%rcx,2), %ecx
	subl	%r15d, %ecx
	movzbl	%bl, %ebx
	imull	%ebx, %ecx
	sarl	$8, %ecx
	addl	%r15d, %ecx
	imull	$27068, %ecx, %ecx
	sarl	$15, %ecx
	leal	104000(%rcx), %ebx
	movl	$-104000, %r15d
	subl	%ecx, %r15d
	testl	%edx, %edx
	cmovs	%r15d, %ebx
	movl	%ebx, %edx
.L2254:
	movl	%edx, (%rdi,%rbp,8)
	movl	4(%rdi,%rbp,8), %edx
	movl	%edx, %ecx
	sarl	$8, %ecx
	imull	%eax, %ecx
	sarl	$7, %ecx
	movzbl	%dl, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	leal	(%rcx,%rdx), %eax
	movl	%eax, %edx
	negl	%edx
	cmovs	%eax, %edx
	cmpl	$104000, %edx
	jle	.L2256
	subl	$104000, %edx
	movl	$54136, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	imull	$9917, %edx, %edx
	sarl	$13, %edx
	movl	%edx, %ecx
	negl	%ecx
	cmovs	%edx, %ecx
	movl	%ecx, %edx
	sarl	$8, %edx
	movslq	%edx, %rbx
	leaq	TANH_Q15(%rip), %r15
	movswl	(%r15,%rbx,2), %ebx
	addl	$1, %edx
	movslq	%edx, %rdx
	movswl	(%r15,%rdx,2), %edx
	subl	%ebx, %edx
	movzbl	%cl, %ecx
	imull	%ecx, %edx
	sarl	$8, %edx
	addl	%ebx, %edx
	imull	$27068, %edx, %edx
	sarl	$15, %edx
	leal	104000(%rdx), %ecx
	movl	$-104000, %ebx
	subl	%edx, %ebx
	testl	%eax, %eax
	movl	%ecx, %eax
	cmovs	%ebx, %eax
.L2256:
	movl	%eax, 4(%rdi,%rbp,8)
	addq	$1, %rbp
	cmpl	%r11d, %ebp
	jnb	.L2306
.L2258:
	addl	%esi, %r12d
	cmpl	$31, %r10d
	jbe	.L2252
	movl	%r12d, %eax
	shrl	$5, %eax
	jmp	.L2253
.L2306:
	movl	8(%rsp), %esi
	movl	16(%rsp), %ecx
	movl	24(%rsp), %ebx
	movl	28(%rsp), %r15d
	movl	52(%rsp), %r10d
	movl	64(%rsp), %r13d
	jmp	.L2250
.L2304:
	movl	%ecx, %edi
	movl	%r13d, %ecx
	movl	12(%rsp), %r13d
	movq	56(%rsp), %r12
	movl	68(%rsp), %r11d
	movl	$0, cln_wi(%rip)
	cmpb	$0, 49(%rsp)
	je	.L2260
	movl	20(%rsp), %eax
	movl	%eax, cln_wg(%rip)
.L2260:
	cmpb	$0, 50(%rsp)
	je	.L2261
	movl	40(%rsp), %eax
	movl	%eax, cln_top(%rip)
.L2261:
	cmpb	$0, 48(%rsp)
	je	.L2262
	movl	36(%rsp), %eax
	movl	%eax, cln_hold(%rip)
.L2262:
	cmpb	$0, 46(%rsp)
	je	.L2263
	movl	32(%rsp), %eax
	movl	%eax, cln_hlen(%rip)
.L2263:
	movl	%edi, cln_pk(%rip)
	movl	%ebx, cln_gs(%rip)
	cmpb	$0, 51(%rsp)
	je	.L2264
	movl	%ecx, cln_env(%rip)
.L2264:
	movl	%r10d, dc_l(%rip)
	movl	%r14d, dce_l(%rip)
	movl	%r15d, dc_r(%rip)
	movl	%r13d, dce_r(%rip)
	movl	%esi, cln_w(%rip)
	movzbl	fx_usb_fixed(%rip), %eax
	testb	%al, %al
	je	.L2265
	addl	%r11d, %r11d
	movl	%r11d, %r8d
	je	.L2226
	movl	$0, %eax
	leaq	out_frac(%rip), %rdi
.L2266:
	movl	(%r12,%rax,4), %edx
	movq	%rax, %rcx
	andl	$63, %ecx
	movl	%edx, %esi
	andl	$3, %esi
	movb	%sil, (%rdi,%rcx)
	sarl	$2, %edx
	movl	%edx, (%r12,%rax,4)
	addq	$1, %rax
	cmpl	%r8d, %eax
	jb	.L2266
	jmp	.L2226
.L2307:
	movl	$18000, lim_env(%rip)
	movl	$32768, lim_g(%rip)
	call	clean_rest
	movl	68+song(%rip), %eax
	sall	$12, %eax
	sarl	$4, %eax
	movl	%eax, cln_mq(%rip)
	jmp	.L2205
.L2230:
	movzbl	fx_usb_fixed(%rip), %eax
	testb	%al, %al
	jne	.L2226
	movl	68+song(%rip), %edx
	sall	$12, %edx
	sarl	$4, %edx
	jmp	.L2270
.L2282:
	movb	$1, 50(%rsp)
	movl	$0, 40(%rsp)
	jmp	.L2247
.L2265:
	movl	68+song(%rip), %edx
	sall	$12, %edx
	sarl	$4, %edx
	movl	cln_mq(%rip), %esi
	movl	%edx, %r8d
	subl	%esi, %r8d
	sarl	$5, %r8d
	movl	4(%rsp), %ebx
	movl	%ebx, %ecx
	leaq	out_frac(%rip), %rdi
.L2267:
	movl	%ecx, %r9d
	andl	$62, %r9d
	movl	%ecx, %eax
	leaq	(%r12,%rax,4), %r13
	leal	1(%rcx), %eax
	leaq	(%r12,%rax,4), %rbp
	addl	%r8d, %esi
	movl	%esi, %eax
	sarl	$8, %eax
	movl	%eax, %r10d
	imull	0(%r13), %r10d
	imull	0(%rbp), %eax
	movl	%r10d, %r14d
	sarl	$14, %r14d
	movl	%r14d, 0(%r13)
	movl	%eax, %r13d
	sarl	$14, %r13d
	movl	%r13d, 0(%rbp)
	movl	%r9d, %ebp
	sarl	$7, %r10d
	andl	$127, %r10d
	movb	%r10b, (%rdi,%rbp)
	addl	$1, %r9d
	movl	%r9d, %r9d
	sarl	$7, %eax
	andl	$127, %eax
	movb	%al, (%rdi,%r9)
	addl	$1, %ebx
	addl	$2, %ecx
	cmpl	%ebx, %r11d
	jne	.L2267
.L2270:
	movl	%edx, cln_mq(%rip)
.L2226:
	movzbl	47(%rsp), %eax
	cmpb	fx_out_mode(%rip), %al
	jne	.L2307
.L2205:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2308:
	.cfi_restore_state
	movzbl	%sil, %eax
	leal	-1(%rax), %r8d
	jmp	.L2271
.L2210:
	movzbl	fx_out_fade(%rip), %esi
	testb	%sil, %sil
	jne	.L2308
.L2273:
	movzbl	fx_out_want(%rip), %eax
	cmpb	%al, 47(%rsp)
	je	.L2214
	movb	$1, fx_out_fade(%rip)
	testl	%r11d, %r11d
	je	.L2278
	movl	$0, %r8d
	movl	$1, %eax
	movl	$1, %esi
.L2271:
	movl	%r8d, %ecx
	sall	$5, %ecx
	movl	$511, %edx
	subl	%ecx, %edx
	leal	0(,%rdx,8), %edi
	sall	$5, %eax
	addl	%edx, %eax
	movl	$0, %edx
	movl	$0, %ecx
	movl	$0, %r9d
	leal	-4600(,%rax,8), %ebx
	jmp	.L2220
.L2207:
	movzbl	fx_out_fade(%rip), %esi
	testb	%sil, %sil
	je	.L2273
.L2274:
	cmpb	$17, %sil
	je	.L2309
	movl	$0, %eax
	cmpb	$33, %sil
	je	.L2222
	jmp	.L2215
	.cfi_endproc
.LFE574:
	.size	out_master, .-out_master
	.type	kv_filter, @function
kv_filter:
.LFB401:
	.cfi_startproc
	movq	%rsi, %rax
	movq	%rcx, %rsi
	cmpb	$0, 2(%rax)
	jne	.L2311
	movb	$3, 72(%rdx)
.L2312:
	movzwl	128(%rdi), %r9d
	andl	$127, %r9d
	movl	68(%rdx), %ecx
	movzwl	%cx, %eax
	leaq	ENV_EXP(%rip), %r10
	movzwl	(%r10,%r9,2), %r10d
	imull	%r10d, %eax
	shrl	$16, %eax
	movl	%ecx, %r9d
	sarl	$16, %r9d
	imull	%r10d, %r9d
	addl	%r9d, %eax
	subl	%eax, %ecx
	movl	%ecx, 68(%rdx)
.L2315:
	movswl	178(%rdi), %eax
	movl	$63, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-64, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	movl	68(%rdx), %edx
	sarl	$9, %edx
	imull	%edx, %eax
	sarl	$7, %eax
	movl	%eax, %edx
	movswl	174(%rdi), %eax
	movl	$127, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	movl	$0, %ecx
	cmovs	%ecx, %eax
	sall	$8, %eax
	addl	16(%rsi), %eax
	leal	(%rdx,%rax), %r9d
	movswl	176(%rdi), %eax
	movl	$110, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	imull	$7600, %eax, %eax
	movslq	%eax, %rdx
	imulq	$-2130574327, %rdx, %rdx
	shrq	$32, %rdx
	addl	%eax, %edx
	sarl	$6, %edx
	sarl	$31, %eax
	subl	%edx, %eax
	addl	$8192, %eax
	movswl	180(%rdi), %edx
	movl	$127, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	movl	4(%rsi), %ecx
	subl	$960, %ecx
	imull	%edx, %ecx
	leal	7(%rcx), %edx
	testl	%ecx, %ecx
	cmovns	%ecx, %edx
	sarl	$3, %edx
	addl	%r9d, %edx
	movl	$32512, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	movl	%edx, %ecx
	sarl	$8, %ecx
	movslq	%ecx, %rdi
	leaq	SVF_G(%rip), %rsi
	movzwl	(%rsi,%rdi,2), %esi
	cmpl	$126, %ecx
	jg	.L2316
	addl	$1, %ecx
	movslq	%ecx, %rcx
	leaq	SVF_G(%rip), %rdi
	movzwl	(%rdi,%rcx,2), %ecx
	subl	%esi, %ecx
	movzbl	%dl, %edx
	imull	%ecx, %edx
	sarl	$8, %edx
	addl	%edx, %esi
.L2316:
	leal	(%rax,%rsi), %ecx
	imull	%esi, %ecx
	sarl	$12, %ecx
	addl	$4096, %ecx
	movl	$33554432, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, (%r8)
	imull	%esi, %eax
	sarl	$12, %eax
	movl	%eax, 4(%r8)
	imull	%eax, %esi
	sarl	$12, %esi
	movl	%esi, 8(%r8)
	ret
.L2311:
	movzbl	72(%rdx), %eax
	cmpb	$1, %al
	jne	.L2313
	movzwl	122(%rdi), %ecx
	andl	$127, %ecx
	movl	68(%rdx), %eax
	leaq	ENV_LIN(%rip), %r9
	addl	(%r9,%rcx,4), %eax
	cmpl	$16777215, %eax
	jg	.L2314
	movl	%eax, 68(%rdx)
	jmp	.L2315
.L2314:
	movl	$16777216, 68(%rdx)
	movb	$2, 72(%rdx)
	jmp	.L2315
.L2313:
	cmpb	$2, %al
	jne	.L2312
	movzwl	124(%rdi), %r9d
	andl	$127, %r9d
	movl	68(%rdx), %r10d
	movswl	126(%rdi), %eax
	sall	$17, %eax
	subl	%r10d, %eax
	movzwl	%ax, %ecx
	leaq	ENV_EXP(%rip), %r11
	movzwl	(%r11,%r9,2), %r9d
	imull	%r9d, %ecx
	shrl	$16, %ecx
	sarl	$16, %eax
	imull	%r9d, %eax
	addl	%ecx, %eax
	addl	%r10d, %eax
	movl	%eax, 68(%rdx)
	jmp	.L2315
	.cfi_endproc
.LFE401:
	.size	kv_filter, .-kv_filter
	.type	p5_wave, @function
p5_wave:
.LFB313:
	.cfi_startproc
	movl	%r8d, %eax
	orl	%r9d, %eax
	orl	%ecx, %eax
	je	.L2348
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %r10d
	movl	%edx, %ebx
	movl	%ecx, %edi
	movl	%r10d, %r11d
	shrl	$16, %r11d
	subl	$32768, %r11d
	movl	$0, %eax
	testl	%esi, %esi
	je	.L2319
	cmpl	%esi, %r10d
	jb	.L2351
	movl	$0, %eax
	movl	%esi, %ecx
	addl	%r10d, %ecx
	jc	.L2352
.L2319:
	subl	%eax, %r11d
	movl	%r11d, %eax
	sarl	%eax
	testl	%edi, %edi
	cmovne	%eax, %edi
	testl	%r8d, %r8d
	je	.L2326
	leal	(%r10,%rbx), %eax
	movl	%eax, %r8d
	shrl	$16, %r8d
	subl	$32768, %r8d
	movl	$0, %edx
	testl	%esi, %esi
	je	.L2327
	cmpl	%esi, %eax
	jb	.L2353
	movl	$0, %edx
	movl	%esi, %ecx
	addl	%eax, %ecx
	jc	.L2354
.L2327:
	subl	%edx, %r8d
	movl	%r11d, %edx
	subl	%r8d, %edx
	sarl	%edx
	leal	(%rdi,%rdx), %eax
	testl	%r9d, %r9d
	je	.L2317
	cmpl	$-2147483648, %ebx
	jne	.L2355
.L2333:
	shrl	$15, %esi
	movslq	%esi, %rsi
	movslq	%edx, %rdx
	imulq	%rdx, %rsi
	sarq	$14, %rsi
	movq	16(%rsp), %rbx
	movl	(%rbx), %ecx
	movl	%ecx, %edx
	sall	$15, %edx
	subl	%ecx, %edx
	sarl	$15, %edx
	addl	%esi, %edx
	movl	$40000, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	movl	$-40000, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
	movl	%edx, (%rbx)
	sarl	%edx
	addl	%edx, %eax
.L2317:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2351:
	.cfi_restore_state
	cmpl	$134217727, %esi
	ja	.L2356
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%r10d, %eax
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2322:
	leal	(%rdx,%rdx), %eax
	imull	%edx, %edx
	sarl	$15, %edx
	subl	%edx, %eax
	subl	$32768, %eax
	jmp	.L2319
.L2356:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	%r10d, %eax
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2322
.L2352:
	movl	%r10d, %eax
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2357
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2324:
	movl	%edx, %eax
	imull	%edx, %eax
	sarl	$15, %eax
	subl	%edx, %eax
	subl	%edx, %eax
	addl	$32768, %eax
	jmp	.L2319
.L2357:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2324
.L2353:
	cmpl	$134217727, %esi
	ja	.L2358
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2330:
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2327
.L2358:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2330
.L2354:
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2359
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2332:
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2327
.L2359:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2332
.L2355:
	movl	%eax, %edi
.L2340:
	leal	-2147483648(%r10), %eax
	movl	%eax, %r8d
	shrl	$16, %r8d
	subl	$32768, %r8d
	movl	$0, %edx
	testl	%esi, %esi
	je	.L2334
	cmpl	%esi, %eax
	jb	.L2360
	movl	$0, %edx
	movl	%esi, %ebx
	addl	%eax, %ebx
	jc	.L2361
.L2334:
	subl	%edx, %r8d
	movl	%r11d, %edx
	subl	%r8d, %edx
	sarl	%edx
	movl	%edi, %eax
	jmp	.L2333
.L2360:
	cmpl	$134217727, %esi
	ja	.L2362
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %ebx
	shrl	%cl, %ebx
	movl	$0, %edx
	divl	%ebx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2337:
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2334
.L2362:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2337
.L2361:
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2363
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %ebx
	shrl	%cl, %ebx
	movl	$0, %edx
	divl	%ebx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2339:
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2334
.L2363:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2339
.L2326:
	testl	%r9d, %r9d
	jne	.L2340
	movl	%edi, %eax
	jmp	.L2317
.L2348:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE313:
	.size	p5_wave, .-p5_wave
	.type	p5_samples, @function
p5_samples:
.LFB320:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$232, %rsp
	.cfi_def_cfa_offset 288
	movq	%rdi, %r15
	movq	%rsi, %r14
	movq	%rdx, 112(%rsp)
	movq	%r8, 120(%rsp)
	movq	%r9, 128(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 216(%rsp)
	xorl	%eax, %eax
	movl	(%r9), %esi
	movl	%esi, 56(%rsp)
	movl	4(%r9), %esi
	movl	%esi, 60(%rsp)
	movl	8(%r9), %esi
	movl	%esi, 64(%rsp)
	movl	12(%r9), %esi
	movl	%esi, 68(%rsp)
	movl	16(%r9), %esi
	movl	%esi, 72(%rsp)
	movl	20(%r9), %edi
	movl	%edi, 76(%rsp)
	movl	24(%r9), %ebx
	movl	%ebx, 80(%rsp)
	movl	28(%r9), %ebx
	movl	%ebx, 20(%rsp)
	movl	32(%r9), %ebx
	movl	%ebx, 84(%rsp)
	movl	36(%r9), %ebx
	movl	%ebx, 88(%rsp)
	movl	40(%r9), %ebx
	movl	%ebx, 92(%rsp)
	movl	44(%r9), %ebx
	movl	%ebx, 96(%rsp)
	movl	48(%r9), %ebx
	movl	%ebx, 148(%rsp)
	movl	52(%r9), %ebx
	movl	%ebx, 152(%rsp)
	movl	56(%r9), %ebx
	movl	%ebx, 156(%rsp)
	movl	60(%r9), %ebx
	movl	%ebx, 160(%rsp)
	movl	64(%r9), %ebx
	movl	%ebx, 164(%rsp)
	movl	68(%r9), %ebx
	movl	%ebx, 168(%rsp)
	movl	72(%r9), %ebx
	movl	%ebx, 100(%rsp)
	movl	76(%r9), %ebx
	movl	%ebx, 176(%rsp)
	movl	80(%r9), %ebx
	movl	%ebx, 104(%rsp)
	movl	84(%r9), %ebx
	movl	%ebx, 108(%rsp)
	movl	88(%r9), %eax
	movl	%eax, 144(%rsp)
	testl	%ecx, %ecx
	je	.L2429
	shrl	$15, %edi
	movl	%edi, 172(%rsp)
	shrl	$14, %esi
	movl	%esi, 180(%rsp)
	movl	%ecx, %eax
	movq	%rax, 136(%rsp)
	movl	$0, %r13d
	jmp	.L2426
.L2467:
	cmpl	$134217727, %esi
	ja	.L2456
	bsrl	%esi, %eax
	xorl	$31, %eax
	movl	$15, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	movl	%edi, %eax
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2375:
	leal	(%rdx,%rdx), %eax
	imull	%edx, %edx
	sarl	$15, %edx
	subl	%edx, %eax
	subl	$32768, %eax
	jmp	.L2372
.L2456:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	%edi, %eax
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2375
.L2468:
	movl	%edi, %eax
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2457
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2377:
	movl	%edx, %eax
	imull	%edx, %eax
	sarl	$15, %eax
	subl	%edx, %eax
	subl	%edx, %eax
	addl	$32768, %eax
	jmp	.L2372
.L2457:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2377
.L2469:
	cmpl	$134217727, %esi
	ja	.L2458
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2383:
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2380
.L2458:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2383
.L2470:
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2459
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2385:
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2380
.L2459:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2385
.L2477:
	cmpl	$134217727, %esi
	ja	.L2460
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %ebx
	shrl	%cl, %ebx
	movl	$0, %edx
	divl	%ebx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2390:
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2387
.L2460:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2390
.L2478:
	notl	%eax
	cmpl	$134217727, %esi
	ja	.L2461
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%esi, %ebx
	shrl	%cl, %ebx
	movl	$0, %edx
	divl	%ebx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2392:
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2387
.L2461:
	movl	%esi, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2392
.L2471:
	negl	%ecx
	shrl	%cl, %ebx
	testl	%ebx, %ebx
	movl	$1, %eax
	cmove	%eax, %ebx
	jmp	.L2393
.L2472:
	cmpl	$134217727, %ebx
	ja	.L2462
	bsrl	%ebx, %edx
	xorl	$31, %edx
	movl	$15, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%r9d, %eax
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%ebx, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2402:
	leal	(%rdx,%rdx), %eax
	imull	%edx, %edx
	sarl	$15, %edx
	subl	%edx, %eax
	subl	$32768, %eax
	jmp	.L2399
.L2462:
	movl	%ebx, %ecx
	shrl	$15, %ecx
	movl	%r9d, %eax
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2402
.L2473:
	movl	%r9d, %eax
	notl	%eax
	cmpl	$134217727, %ebx
	ja	.L2463
	bsrl	%ebx, %r10d
	xorl	$31, %r10d
	movl	$15, %edx
	cmpl	%edx, %r10d
	cmova	%edx, %r10d
	movl	%r10d, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%r10d, %ecx
	movl	%ebx, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
.L2404:
	movl	%edx, %eax
	imull	%edx, %eax
	sarl	$15, %eax
	subl	%edx, %eax
	subl	%edx, %eax
	addl	$32768, %eax
	jmp	.L2399
.L2463:
	movl	%ebx, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	jmp	.L2404
.L2474:
	cmpl	$134217727, %ebx
	ja	.L2464
	bsrl	%ebx, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%ebx, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2409:
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
.L2406:
	subl	%edx, %r10d
	subl	%r10d, %r8d
	sarl	%r8d
	addl	%r8d, %ebp
.L2398:
	addl	32(%r15), %ebp
	movl	$0, 32(%r15)
	leal	(%rdi,%rsi), %r12d
	leal	(%r9,%rbx), %eax
	cmpb	$0, 10(%r14)
	setne	%cl
	testl	%esi, %esi
	setne	%dl
	testb	%dl, %cl
	je	.L2412
	cmpl	%edi, %r12d
	jb	.L2465
.L2412:
	movl	%eax, (%r15)
	movl	%r12d, 4(%r15)
	movl	8(%rsp), %eax
	movl	%eax, %edx
	andl	$32767, %edx
	movl	108(%rsp), %edi
	imull	%edi, %edx
	sarl	$15, %edx
	sarl	$15, %eax
	imull	%edi, %eax
	addl	%eax, %edx
	movl	%ebp, %eax
	andl	$32767, %eax
	movl	104(%rsp), %ebx
	imull	%ebx, %eax
	sarl	$15, %eax
	sarl	$15, %ebp
	imull	%ebx, %ebp
	addl	%eax, %ebp
	addl	%ebp, %edx
	movl	44(%rsp), %eax
	movl	144(%rsp), %esi
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, %edx
	cmpb	$0, 31(%rsp)
	je	.L2413
	movl	48(%rsp), %esi
	movl	%esi, %eax
	andl	$32767, %eax
	movl	160(%rsp), %ebx
	imull	%ebx, %eax
	sarl	$15, %eax
	movl	%eax, %ecx
	movl	%esi, %eax
	sarl	$15, %eax
	imull	%ebx, %eax
	addl	%ecx, %eax
	addl	%eax, 12(%rsp)
.L2413:
	cmpb	$0, 31(%r14)
	je	.L2414
	movl	16(%rsp), %esi
	leal	0(,%rsi,8), %eax
	subl	%esi, %eax
	sarl	$3, %eax
	addl	%eax, 12(%rsp)
.L2414:
	movzbl	20(%r14), %ebx
	movl	%edx, %eax
	negl	%eax
	cmovs	%edx, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	cltq
	leaq	P5_TANH_Q15(%rip), %rsi
	movswl	(%rsi,%rax,2), %eax
	movl	%eax, %ecx
	negl	%ecx
	testl	%edx, %edx
	cmovs	%ecx, %eax
	movl	$32512, %esi
	movl	12(%rsp), %edi
	cmpl	%esi, %edi
	cmovle	%edi, %esi
	testl	%esi, %esi
	movl	$0, %edx
	cmovs	%edx, %esi
	cmpl	$0, 108(%r15)
	je	.L2416
	cmpl	80(%r15), %esi
	je	.L2466
.L2416:
	movl	%esi, %edx
	shrl	$8, %edx
	movl	%edx, %ecx
	leaq	P5_TPT_G(%rip), %rdi
	movzwl	(%rdi,%rcx,2), %ecx
	cmpl	$126, %edx
	ja	.L2418
	addl	$1, %edx
	movl	%edx, %edx
	movzwl	(%rdi,%rdx,2), %edx
	subl	%ecx, %edx
	movzbl	%sil, %edi
	imull	%edi, %edx
	sarl	$8, %edx
	addl	%edx, %ecx
.L2418:
	movl	%ecx, %edx
	imull	%ecx, %edx
	sarl	$12, %edx
	movl	%ecx, %edi
	imull	%edx, %edi
	sarl	$12, %edi
	movl	%ecx, %r10d
	imull	%edi, %r10d
	sarl	$12, %r10d
	movl	20(%rsp), %r12d
	movl	%r12d, %r8d
	imull	%r10d, %r8d
	sarl	$12, %r8d
	movl	%r8d, %r9d
	shrl	$5, %r9d
	leaq	P5_INV_DEN(%rip), %rbp
	movl	%r9d, %r11d
	movzwl	0(%rbp,%r11,2), %r11d
	addl	$1, %r9d
	movl	%r9d, %r9d
	movzwl	0(%rbp,%r9,2), %r9d
	subl	%r11d, %r9d
	andl	$31, %r8d
	imull	%r8d, %r9d
	sarl	$5, %r9d
	leal	(%r11,%r9), %r8d
	movl	%ecx, 88(%r15)
	movl	%edx, 92(%r15)
	movl	%edi, 96(%r15)
	movl	%r10d, 100(%r15)
	movl	%esi, 80(%r15)
	movl	%r12d, 84(%r15)
	movl	%r8d, 104(%r15)
	movl	$1, 108(%r15)
.L2417:
	movl	8(%r15), %r10d
	movl	12(%r15), %r9d
	movl	16(%r15), %esi
	movl	20(%r15), %r11d
	movl	84(%rsp), %ebp
	imull	%ebp, %eax
	sarl	$15, %eax
	imull	%r10d, %edi
	sarl	$12, %edi
	imull	%r9d, %edx
	sarl	$12, %edx
	addl	%edi, %edx
	movl	%esi, %edi
	imull	%ecx, %edi
	sarl	$12, %edi
	addl	%edi, %edx
	addl	%r11d, %edx
	movl	$4096, %edi
	subl	%ecx, %edi
	imull	%edi, %edx
	sarl	$12, %edx
	movl	20(%rsp), %edi
	imull	%edi, %edx
	sarl	$12, %edx
	subl	%edx, %eax
	movl	$262143, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-262143, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	imull	%r8d, %eax
	sarl	$13, %eax
	movl	%eax, %edx
	negl	%edx
	cmovs	%eax, %edx
	addl	$16, %edx
	sarl	$5, %edx
	movl	$2048, %edi
	cmpl	%edi, %edx
	cmovg	%edi, %edx
	movslq	%edx, %rdx
	leaq	P5_TANH_Q15(%rip), %rdi
	movswl	(%rdi,%rdx,2), %edx
	movl	%edx, %edi
	negl	%edi
	testl	%eax, %eax
	cmovs	%edi, %edx
	testb	%bl, %bl
	je	.L2420
	movl	%edx, %eax
	subl	%r10d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	addl	%eax, %r10d
	addl	%r10d, %eax
	movl	$60000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-60000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 8(%r15)
	movl	%r10d, %eax
	subl	%r9d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	leal	(%r9,%rax), %edx
	addl	%edx, %eax
	movl	$60000, %edi
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	movl	$-60000, %edi
	cmpl	%edi, %eax
	cmovl	%edi, %eax
	movl	%eax, 12(%r15)
	subl	%esi, %edx
	imull	%ecx, %edx
	sarl	$12, %edx
	leal	(%rsi,%rdx), %eax
	addl	%eax, %edx
	movl	$60000, %esi
	cmpl	%esi, %edx
	cmovg	%esi, %edx
	movl	$-60000, %esi
	cmpl	%esi, %edx
	cmovl	%esi, %edx
	movl	%edx, 16(%r15)
	subl	%r11d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	leal	(%r11,%rax), %edx
	addl	%edx, %eax
	movl	$60000, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-60000, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	movl	%eax, 20(%r15)
.L2421:
	movl	%edx, %eax
	negl	%eax
	cmovs	%edx, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	cltq
	leaq	P5_TANH_Q15(%rip), %rbx
	movswl	(%rbx,%rax,2), %edi
	movl	%edi, %eax
	negl	%eax
	testl	%edx, %edx
	cmovs	%eax, %edi
	movq	120(%rsp), %rax
	movl	8(%rax), %ecx
	movl	12(%rax), %eax
	movl	%eax, 8(%rsp)
	movl	%eax, %esi
	subl	%ecx, %esi
	movl	24(%rsp), %eax
	imull	%eax, %esi
	movl	44(%r15), %eax
	addl	$32767, %eax
	movl	40(%rsp), %edx
	movl	92(%rsp), %ebx
	imull	%ebx, %edx
	sarl	$15, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	imull	%edi, %eax
	sarl	$15, %eax
	movl	%esi, %edx
	sarl	$31, %edx
	andl	$31, %edx
	addl	%esi, %edx
	sarl	$5, %edx
	addl	%ecx, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	movq	112(%rsp), %rsi
	addl	%eax, (%rsi,%r13,4)
	addq	$1, %r13
	cmpq	%r13, 136(%rsp)
	je	.L2365
.L2426:
	movl	%r13d, 24(%rsp)
	movl	64(%rsp), %eax
	movl	56(%rsp), %ebx
	subl	%ebx, %eax
	imull	%r13d, %eax
	sarl	$5, %eax
	addl	%ebx, %eax
	movl	68(%rsp), %edx
	movl	60(%rsp), %ebx
	subl	%ebx, %edx
	imull	%r13d, %edx
	sarl	$5, %edx
	leal	(%rdx,%rbx), %esi
	movl	%esi, 40(%rsp)
	movl	88(%rsp), %edx
	imull	%eax, %edx
	sarl	$15, %edx
	movl	96(%rsp), %esi
	imull	%esi, %edx
	sarl	$15, %edx
	movl	80(%rsp), %esi
	addl	%edx, %esi
	movl	%esi, 12(%rsp)
	movzbl	34(%r14), %r10d
	movl	$0, 32(%rsp)
	testb	%r10b, %r10b
	je	.L2366
	movl	148(%rsp), %edx
	imull	%eax, %edx
	sarl	$15, %edx
	movl	%edx, 32(%rsp)
.L2366:
	movzbl	35(%r14), %r12d
	movl	$0, 36(%rsp)
	testb	%r12b, %r12b
	je	.L2367
	movl	164(%rsp), %edx
	imull	%eax, %edx
	sarl	$15, %edx
	movl	%edx, 36(%rsp)
.L2367:
	movzbl	36(%r14), %ebx
	movb	%bl, 31(%rsp)
	testb	%bl, %bl
	je	.L2368
	movl	156(%rsp), %esi
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, 12(%rsp)
.L2368:
	movl	28(%r15), %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, 28(%r15)
	shrl	$17, %eax
	subl	$16384, %eax
	movl	%eax, 44(%rsp)
	movq	128(%rsp), %rsi
	movq	96(%rsi), %rax
	movswl	(%rax,%r13,2), %eax
	movl	%eax, 16(%rsp)
	movq	104(%rsi), %rax
	movzwl	(%rax,%r13,2), %r11d
	movl	76(%rsp), %edi
	movl	%edi, %esi
	cmpb	$0, 28(%r14)
	je	.L2369
	movzwl	%r11w, %eax
	andl	$32767, %edi
	movl	%edi, %esi
	imull	%eax, %esi
	shrl	$15, %esi
	movl	172(%rsp), %ecx
	imull	%ecx, %eax
	addl	%eax, %esi
	movl	$1932735280, %eax
	cmpl	%eax, %esi
	cmova	%eax, %esi
.L2369:
	movzbl	6(%r14), %eax
	movb	%al, 48(%rsp)
	movzbl	7(%r14), %ebx
	movzbl	5(%r14), %ebp
	cmpb	$0, 30(%r14)
	movl	$0, %r8d
	cmovne	16(%rsp), %r8d
	movl	4(%r15), %edi
	orl	%ebx, %eax
	movl	$0, 8(%rsp)
	orb	%bpl, %al
	je	.L2371
	movl	%edi, %r9d
	shrl	$16, %r9d
	subl	$32768, %r9d
	movl	$0, %eax
	testl	%esi, %esi
	je	.L2372
	cmpl	%esi, %edi
	jb	.L2467
	movl	$0, %eax
	movl	%esi, %ecx
	addl	%edi, %ecx
	jc	.L2468
.L2372:
	subl	%eax, %r9d
	movl	%r9d, %eax
	sarl	%eax
	testb	%bpl, %bpl
	movl	$0, %ecx
	cmove	%ecx, %eax
	movl	%eax, 8(%rsp)
	testb	%bl, %bl
	je	.L2379
	movl	176(%rsp), %eax
	addl	%eax, %r8d
	movl	$31743, %eax
	cmpl	%eax, %r8d
	cmovg	%eax, %r8d
	movl	$1024, %eax
	cmpl	%eax, %r8d
	cmovl	%eax, %r8d
	sall	$17, %r8d
	leal	(%rdi,%r8), %eax
	movl	%eax, %ebx
	shrl	$16, %ebx
	subl	$32768, %ebx
	movl	$0, %edx
	testl	%esi, %esi
	je	.L2380
	cmpl	%esi, %eax
	jb	.L2469
	movl	$0, %edx
	movl	%esi, %ecx
	addl	%eax, %ecx
	jc	.L2470
.L2380:
	subl	%edx, %ebx
	movl	%r9d, %eax
	subl	%ebx, %eax
	sarl	%eax
	addl	%eax, 8(%rsp)
	cmpb	$0, 48(%rsp)
	je	.L2371
	cmpl	$-2147483648, %r8d
	jne	.L2427
.L2386:
	movl	%esi, %edx
	shrl	$15, %edx
	movslq	%edx, %rdx
	cltq
	imulq	%rax, %rdx
	sarq	$14, %rdx
	movl	24(%r15), %ecx
	movl	%ecx, %eax
	sall	$15, %eax
	subl	%ecx, %eax
	sarl	$15, %eax
	addl	%edx, %eax
	movl	$40000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-40000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 24(%r15)
	sarl	%eax
	addl	%eax, 8(%rsp)
.L2371:
	movl	8(%rsp), %eax
	addl	%eax, %eax
	movl	%eax, 48(%rsp)
	movl	72(%rsp), %edx
	movl	%edx, %ebx
	testb	%r10b, %r10b
	je	.L2393
	movl	%eax, %ecx
	andl	$32767, %ecx
	movl	152(%rsp), %ebx
	imull	%ebx, %ecx
	sarl	$15, %ecx
	sarl	$15, %eax
	imull	%ebx, %eax
	addl	%eax, %ecx
	movl	%edx, %r10d
	movl	%edx, %ebx
	movl	32(%rsp), %eax
	addl	%eax, %ecx
	je	.L2393
	movl	$24576, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	movl	$-32768, %eax
	cmpl	%eax, %ecx
	cmovl	%eax, %ecx
	movl	%ecx, %eax
	shrl	$4, %eax
	movzbl	%al, %eax
	movl	%eax, %edx
	addl	$1, %eax
	movl	%eax, %eax
	leaq	P5_EXP2_Q14(%rip), %rbx
	movzwl	(%rbx,%rax,2), %eax
	movzwl	(%rbx,%rdx,2), %edx
	subl	%edx, %eax
	movl	%ecx, %r8d
	andl	$15, %r8d
	imull	%r8d, %eax
	shrl	$4, %eax
	addl	%edx, %eax
	movl	%r10d, %ebx
	andl	$16383, %ebx
	imull	%eax, %ebx
	shrl	$14, %ebx
	movl	180(%rsp), %edx
	imull	%edx, %eax
	addl	%eax, %ebx
	sarl	$12, %ecx
	js	.L2471
	movl	$1932735280, %eax
	shrl	%cl, %eax
	movl	%ebx, %edx
	sall	%cl, %edx
	cmpl	%ebx, %eax
	movl	$1932735280, %ebx
	cmovnb	%edx, %ebx
.L2393:
	cmpb	$0, 27(%r14)
	je	.L2395
	movzwl	%r11w, %edx
	movl	%ebx, %eax
	andl	$32767, %eax
	imull	%edx, %eax
	shrl	$15, %eax
	shrl	$15, %ebx
	imull	%edx, %ebx
	addl	%eax, %ebx
	movl	$1932735280, %eax
	cmpl	%eax, %ebx
	cmova	%eax, %ebx
.L2395:
	movl	$0, %eax
	testb	%r12b, %r12b
	je	.L2396
	movl	8(%rsp), %ecx
	movl	%ecx, %eax
	andl	$32767, %eax
	movl	168(%rsp), %r11d
	imull	%r11d, %eax
	sarl	$15, %eax
	sarl	$15, %ecx
	movl	%ecx, %edx
	imull	%r11d, %edx
	addl	%edx, %eax
	movl	36(%rsp), %ecx
	addl	%ecx, %eax
.L2396:
	movl	100(%rsp), %ecx
	addl	%ecx, %eax
	cmpb	$0, 29(%r14)
	movl	$0, %edx
	cmovne	16(%rsp), %edx
	addl	%edx, %eax
	movl	$31743, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$1024, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	sall	$17, %eax
	movl	%eax, 52(%rsp)
	movl	$0, 212(%rsp)
	movzbl	4(%r14), %eax
	movzbl	%al, %ecx
	movl	%ecx, 32(%rsp)
	movzbl	3(%r14), %edx
	movzbl	%dl, %ecx
	movl	%ecx, 36(%rsp)
	movl	(%r15), %r9d
	movl	$0, %ebp
	orb	%dl, %al
	je	.L2398
	movl	%r9d, %r8d
	shrl	$16, %r8d
	subl	$32768, %r8d
	movl	$0, %eax
	testl	%ebx, %ebx
	je	.L2399
	cmpl	%ebx, %r9d
	jb	.L2472
	movl	$0, %eax
	movl	%ebx, %ecx
	addl	%r9d, %ecx
	jc	.L2473
.L2399:
	subl	%eax, %r8d
	movl	%r8d, %ebp
	sarl	%ebp
	movl	36(%rsp), %eax
	testl	%eax, %eax
	cmove	%eax, %ebp
	cmpl	$0, 32(%rsp)
	je	.L2398
	movl	52(%rsp), %eax
	addl	%r9d, %eax
	movl	%eax, %r10d
	shrl	$16, %r10d
	subl	$32768, %r10d
	movl	$0, %edx
	testl	%ebx, %ebx
	je	.L2406
	cmpl	%ebx, %eax
	jb	.L2474
	movl	$0, %edx
	movl	%ebx, %ecx
	addl	%eax, %ecx
	jnc	.L2406
	notl	%eax
	cmpl	$134217727, %ebx
	ja	.L2475
	bsrl	%ebx, %edx
	xorl	$31, %edx
	movl	$15, %ecx
	cmpl	%ecx, %edx
	cmova	%ecx, %edx
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	movl	%ebx, %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2411:
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2406
.L2464:
	movl	%ebx, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2409
.L2475:
	movl	%ebx, %ecx
	shrl	$15, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L2411
.L2465:
	bsrl	%esi, %edx
	xorl	$31, %edx
	movl	$15, %eax
	cmpl	%eax, %edx
	cmova	%eax, %edx
	movl	%edi, %eax
	negl	%eax
	movl	%edx, %ecx
	sall	%cl, %eax
	movl	$15, %ecx
	subl	%edx, %ecx
	shrl	%cl, %esi
	movl	$0, %edx
	divl	%esi
	movl	$32768, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	movl	%edx, %eax
	movl	%ebx, %ecx
	shrl	$15, %ecx
	movl	%ebx, %esi
	andl	$32767, %esi
	movl	%edx, %edi
	movl	%ecx, 196(%rsp)
	imull	%ecx, %edi
	addl	%r9d, %edi
	movl	%edx, 204(%rsp)
	movl	%esi, 200(%rsp)
	imull	%esi, %eax
	shrl	$15, %eax
	addl	%eax, %edi
	leaq	212(%rsp), %rdx
	movq	%rdx, 184(%rsp)
	pushq	%rdx
	.cfi_def_cfa_offset 296
	movl	$0, %r9d
	movl	40(%rsp), %r8d
	movl	44(%rsp), %ecx
	movl	60(%rsp), %edx
	movl	%ebx, %esi
	call	p5_wave
	movl	%eax, 200(%rsp)
	pushq	192(%rsp)
	.cfi_def_cfa_offset 304
	movl	$0, %r9d
	movl	48(%rsp), %r8d
	movl	52(%rsp), %ecx
	movl	68(%rsp), %edx
	movl	%ebx, %esi
	movl	$0, %edi
	call	p5_wave
	movl	$32768, %edx
	movl	220(%rsp), %edi
	subl	%edi, %edx
	movl	%eax, %ebx
	movl	208(%rsp), %r11d
	subl	%r11d, %ebx
	movl	%ebx, %esi
	sarl	%esi
	movl	%edx, %ebx
	imull	%edx, %ebx
	movl	%ebx, %ecx
	sarl	$15, %ecx
	imull	%esi, %ecx
	sarl	$15, %ecx
	addl	%ecx, %ebp
	movl	%edi, %eax
	imull	%edi, %eax
	sarl	$15, %eax
	imull	%esi, %eax
	sarl	$15, %eax
	negl	%eax
	movl	%eax, 32(%r15)
	movl	216(%rsp), %eax
	imull	%edx, %eax
	shrl	$15, %eax
	movl	212(%rsp), %ecx
	imull	%ecx, %edx
	addl	%edx, %eax
	addq	$16, %rsp
	.cfi_def_cfa_offset 288
	jmp	.L2412
.L2466:
	movl	20(%rsp), %edi
	cmpl	84(%r15), %edi
	jne	.L2416
	movl	88(%r15), %ecx
	movl	92(%r15), %edx
	movl	96(%r15), %edi
	movl	104(%r15), %r8d
	jmp	.L2417
.L2420:
	movl	%edx, %eax
	subl	%r10d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	addl	%eax, %r10d
	addl	%r10d, %eax
	movl	$60000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-60000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 8(%r15)
	movl	%r10d, %eax
	negl	%eax
	cmovs	%r10d, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	cltq
	leaq	P5_TANH_Q15(%rip), %rbx
	movswl	(%rbx,%rax,2), %eax
	movl	%eax, %edx
	negl	%edx
	testl	%r10d, %r10d
	cmovs	%edx, %eax
	subl	%r9d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	addl	%eax, %r9d
	addl	%r9d, %eax
	movl	$60000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-60000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 12(%r15)
	movl	%r9d, %eax
	negl	%eax
	cmovs	%r9d, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	cltq
	movswl	(%rbx,%rax,2), %eax
	movl	%eax, %edx
	negl	%edx
	testl	%r9d, %r9d
	cmovs	%edx, %eax
	subl	%esi, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	addl	%eax, %esi
	addl	%esi, %eax
	movl	$60000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-60000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 16(%r15)
	movl	%esi, %eax
	negl	%eax
	cmovs	%esi, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	cltq
	movswl	(%rbx,%rax,2), %eax
	movl	%eax, %edx
	negl	%edx
	testl	%esi, %esi
	cmovs	%edx, %eax
	subl	%r11d, %eax
	imull	%ecx, %eax
	sarl	$12, %eax
	addl	%eax, %r11d
	addl	%r11d, %eax
	movl	$60000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-60000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 20(%r15)
	movl	%r11d, %eax
	negl	%eax
	cmovs	%r11d, %eax
	addl	$16, %eax
	sarl	$5, %eax
	movl	$2048, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	cltq
	movswl	(%rbx,%rax,2), %edx
	movl	%edx, %eax
	negl	%eax
	testl	%r11d, %r11d
	cmovs	%eax, %edx
	jmp	.L2421
.L2429:
	movl	$0, %eax
.L2365:
	movl	%eax, 64(%r15)
	movq	216(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2476
	addq	$232, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2379:
	.cfi_restore_state
	cmpb	$0, 48(%rsp)
	je	.L2371
.L2427:
	leal	-2147483648(%rdi), %eax
	movl	%eax, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %r8d
	movl	$0, %edx
	testl	%esi, %esi
	je	.L2387
	cmpl	%esi, %eax
	jb	.L2477
	movl	$0, %edx
	movl	%esi, %ecx
	addl	%eax, %ecx
	jc	.L2478
.L2387:
	subl	%edx, %r8d
	movl	%r9d, %eax
	subl	%r8d, %eax
	sarl	%eax
	jmp	.L2386
.L2476:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE320:
	.size	p5_samples, .-p5_samples
	.type	kv_emit, @function
kv_emit:
.LFB402:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rsi, %rax
	movl	%edx, %r10d
	movq	%rcx, %rsi
	movl	48(%rdi), %edx
	movl	%r10d, %ecx
	shrl	$31, %ecx
	leal	(%rcx,%r10), %r10d
	sarl	%r10d
	subl	%edx, %r10d
	movl	44(%rdi), %r11d
	movl	4(%rax), %ebx
	movl	%r10d, %ecx
	imull	8(%rax), %ecx
	movl	%r11d, %ebp
	imull	%ebx, %ebp
	addl	%ebp, %ecx
	sarl	$13, %ecx
	addl	%edx, %ecx
	movl	%r11d, %ebp
	imull	(%rax), %ebp
	movl	%ebp, %eax
	imull	%ebx, %r10d
	addl	%r10d, %eax
	sarl	$13, %eax
	addl	%eax, %eax
	subl	%r11d, %eax
	movl	$150000, %r10d
	cmpl	%r10d, %eax
	cmovg	%r10d, %eax
	movl	$-150000, %r10d
	cmpl	%r10d, %eax
	cmovl	%r10d, %eax
	movl	%eax, 44(%rdi)
	leal	(%rcx,%rcx), %eax
	subl	%edx, %eax
	movl	$150000, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-150000, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 48(%rdi)
	movl	%ecx, %eax
	negl	%eax
	cmovs	%ecx, %eax
	movl	%eax, %r10d
	sarl	$8, %r10d
	movl	$31588, %edx
	cmpl	$65535, %eax
	jg	.L2480
	leaq	TANH_Q15(%rip), %rdx
	movslq	%r10d, %r11
	movswl	(%rdx,%r11,2), %r11d
	addl	$1, %r10d
	movslq	%r10d, %r10
	movswl	(%rdx,%r10,2), %edx
	subl	%r11d, %edx
	movzbl	%al, %eax
	imull	%eax, %edx
	sarl	$8, %edx
	addl	%r11d, %edx
.L2480:
	movl	%edx, %eax
	negl	%eax
	testl	%ecx, %ecx
	cmovs	%eax, %edx
	movl	52(%rdi), %eax
	movl	%edx, %ecx
	subl	%eax, %ecx
	sarl	$10, %ecx
	addl	%eax, %ecx
	movl	%ecx, 52(%rdi)
	movl	8(%rsi), %edi
	movl	12(%rsi), %esi
	subl	%edi, %esi
	imull	%r9d, %esi
	movl	%r9d, %r9d
	movl	%esi, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%esi, %eax
	sarl	$5, %eax
	addl	%edi, %eax
	subl	%ecx, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	addl	%eax, (%r8,%r9,4)
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE402:
	.size	kv_emit, .-kv_emit
	.type	rev_hall, @function
rev_hall:
.LFB612:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %r12
	movq	%rsi, 64(%rsp)
	movswl	18+song(%rip), %eax
	imull	$-180, %eax, %eax
	leal	32767(%rax), %r15d
	movl	84+hl(%rip), %ebp
	movl	96+hl(%rip), %ebx
	movl	100+hl(%rip), %r13d
	movl	88+hl(%rip), %eax
	movl	%eax, 48(%rsp)
	movl	92+hl(%rip), %eax
	movl	%eax, 52(%rsp)
	movzwl	16+song(%rip), %edi
	movw	%di, 16(%rsp)
	movswl	120+hl(%rip), %edx
	movswl	%di, %eax
	addl	$1, %eax
	cmpl	%eax, %edx
	jne	.L2557
.L2485:
	movl	$0, %ecx
	leaq	260+hl(%rip), %rsi
.L2487:
	movl	(%r12,%rcx,2), %eax
	leal	0(%rbp,%rax,2), %eax
	movl	4(%r12,%rcx,2), %ebp
	addl	%ebp, %eax
	sarl	$2, %eax
	movl	$262143, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-262143, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	imull	$2580, %eax, %eax
	sarl	$15, %eax
	movl	%eax, %edx
	subl	%ebx, %edx
	addl	%r13d, %edx
	movl	%edx, %r13d
	andl	$31, %r13d
	sarl	$5, %edx
	addl	%edx, %ebx
	subl	%ebx, %eax
	movl	%eax, (%rsi,%rcx)
	addq	$4, %rcx
	cmpq	$64, %rcx
	jne	.L2487
	movl	%ebp, 84+hl(%rip)
	movl	%ebx, 96+hl(%rip)
	movl	%r13d, 100+hl(%rip)
	movl	$0, %edx
	leaq	rev_u(%rip), %r12
	movl	$16, %r14d
	leaq	hl(%rip), %r13
	movq	%rdx, %rcx
.L2493:
	leaq	16+hl(%rip), %rax
	movzwl	(%rax,%rcx), %r11d
	leaq	HL_AP(%rip), %rax
	movzwl	(%rax,%rcx), %edx
	movzwl	%dx, %ebp
	leaq	HL_APG(%rip), %rax
	movswl	(%rax,%rcx), %r9d
	movl	$0, %ebx
	movw	%dx, 8(%rsp)
	movl	%r15d, %edx
	movq	%rcx, %r15
.L2492:
	movl	%r14d, %r8d
	subl	%ebx, %r8d
	movl	%ebp, %ecx
	subl	%r11d, %ecx
	cmpl	%ecx, %r8d
	cmova	%ecx, %r8d
	movl	%r11d, %r10d
	testl	%r8d, %r8d
	je	.L2488
	leaq	(%r12,%r10,2), %rcx
	leal	65(%rbx), %esi
	leaq	0(%r13,%rsi,4), %rdi
	movl	%r8d, %esi
	addq	%r10, %rsi
	leaq	(%r12,%rsi,2), %r10
	movl	%ebp, 16(%rsp)
	movl	%r11d, (%rsp)
.L2489:
	movswl	(%rcx), %r11d
	movl	%r9d, %esi
	imull	%r11d, %esi
	movl	%esi, %eax
	sarl	$31, %eax
	andl	$16383, %eax
	addl	%esi, %eax
	sarl	$14, %eax
	addl	(%rdi), %eax
	movl	$32767, %esi
	cmpl	%esi, %eax
	cmovle	%eax, %esi
	movl	$-32768, %ebp
	cmpl	%ebp, %esi
	cmovl	%ebp, %esi
	movw	%si, (%rcx)
	imull	%r9d, %eax
	addl	$8192, %eax
	sarl	$14, %eax
	subl	%eax, %r11d
	movl	%r11d, (%rdi)
	addq	$2, %rcx
	addq	$4, %rdi
	cmpq	%r10, %rcx
	jne	.L2489
	movl	16(%rsp), %ebp
	movl	(%rsp), %r11d
	addl	%r8d, %r11d
	cmpl	%ebp, %r11d
	movl	$0, %eax
	cmovnb	%eax, %r11d
.L2490:
	addl	%r8d, %ebx
	cmpl	$15, %ebx
	jbe	.L2492
	movq	%r15, %rcx
	movl	%edx, %r15d
	movzwl	8(%rsp), %edx
	leaq	16+hl(%rip), %rax
	movw	%r11w, (%rax,%rcx)
	movzwl	%dx, %edx
	leaq	(%r12,%rdx,2), %r12
	addq	$2, %rcx
	cmpq	$4, %rcx
	jne	.L2493
	addl	$1153115, 124+hl(%rip)
	leaq	436(%rax), %rax
	movq	%rax, 56(%rsp)
	leaq	-432(%rax), %rdx
	leaq	-452(%rax), %r11
	movl	$0, 28(%rsp)
	movl	$0, %r10d
	leaq	rev_comb(%rip), %r14
	movq	%r10, (%rsp)
	movq	%rax, %r10
	jmp	.L2517
.L2557:
	sall	$16, %edi
	movl	%edi, %edi
	movl	$2290649225, %eax
	imulq	%rax, %rdi
	shrq	$36, %rdi
	call	exp2_neg
	leaq	HL_LEN(%rip), %r14
	leaq	104+hl(%rip), %rdx
	movl	%ebp, (%rsp)
	movl	%ebx, 8(%rsp)
	movl	%eax, %ebx
	movq	%rdx, %rbp
.L2486:
	movzwl	(%r14), %edi
	imull	%ebx, %edi
	imull	$59, %edi, %edi
	shrl	$15, %edi
	call	exp2_neg
	movl	$32440, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	imull	$6193, %eax, %eax
	shrl	$15, %eax
	movw	%ax, 0(%rbp)
	addq	$2, %r14
	addq	$2, %rbp
	leaq	16+HL_LEN(%rip), %rax
	cmpq	%rax, %r14
	jne	.L2486
	movl	(%rsp), %ebp
	movl	8(%rsp), %ebx
	movzwl	16(%rsp), %eax
	addl	$1, %eax
	movw	%ax, 120+hl(%rip)
	jmp	.L2485
.L2494:
	movq	(%rsp), %rbx
	movl	%ebx, %esi
	andl	$1, %esi
	addl	$1, %esi
	leaq	hl(%rip), %rax
	imull	124(%rax), %esi
	movl	28(%rsp), %eax
	addl	%eax, %esi
	movl	%esi, %r9d
	shrl	$22, %r9d
	movl	%r9d, %r8d
	leaq	SINE(%rip), %rax
	movswl	(%rax,%r8,2), %r8d
	addl	$1, %r9d
	andl	$1023, %r9d
	movswl	(%rax,%r9,2), %r9d
	subl	%r8d, %r9d
	shrl	$7, %esi
	andl	$32767, %esi
	imull	%esi, %r9d
	sarl	$15, %r9d
	addl	%r8d, %r9d
	sarl	$4, %r9d
	leal	2560(%r9), %esi
	movzbl	%r9b, %r9d
	movzwl	(%r11), %r8d
	shrl	$8, %esi
	addl	%esi, %r8d
	leaq	HL_LEN(%rip), %rax
	movzwl	(%rax,%rbx,2), %esi
	movl	%r8d, %ebx
	subl	%esi, %ebx
	cmpl	%esi, %r8d
	cmovnb	%ebx, %r8d
	jmp	.L2495
.L2497:
	movq	%r10, 8(%rsp)
	movl	$0, %r12d
	movq	%r14, %rcx
	movq	%r11, 32(%rsp)
	movq	%r10, 40(%rsp)
	jmp	.L2508
.L2499:
	testl	%r10d, %r10d
	je	.L2502
	movl	%r10d, %r13d
	addq	%r13, %r13
	movl	$0, %esi
	movl	%r8d, 20(%rsp)
	movl	%ebx, 24(%rsp)
.L2503:
	movswl	0(%rbp,%rsi), %r8d
	subl	%eax, %r8d
	imull	%r15d, %r8d
	addl	%r9d, %r8d
	movl	%r8d, %r9d
	andl	$32767, %r9d
	sarl	$15, %r8d
	addl	%r8d, %eax
	movl	%edi, %ebx
	imull	%eax, %ebx
	movl	%ebx, %r8d
	sarl	$31, %r8d
	andl	$16383, %r8d
	addl	%ebx, %r8d
	sarl	$14, %r8d
	movw	%r8w, (%r11,%rsi)
	addq	$2, %rsi
	cmpq	%rsi, %r13
	jne	.L2503
	movl	20(%rsp), %r8d
	movl	24(%rsp), %ebx
.L2504:
	movl	%eax, (%r14)
	movl	%r9d, 32(%r14)
	addl	%r10d, %r8d
	cmpl	%ebx, %r8d
	jb	.L2506
.L2529:
	movl	$0, %r8d
.L2506:
	addl	%r10d, %r12d
	cmpl	$15, %r12d
	ja	.L2558
.L2508:
	movl	$16, %r10d
	subl	%r12d, %r10d
	movl	%ebx, %eax
	subl	%r8d, %eax
	cmpl	%eax, %r10d
	cmova	%eax, %r10d
	movl	%r12d, %eax
	movq	8(%rsp), %rsi
	leaq	(%rsi,%rax,2), %r11
	movl	%r8d, %eax
	leaq	(%rcx,%rax,2), %rbp
	movq	%rdx, %r14
	movl	(%rdx), %eax
	movl	32(%rdx), %r9d
	cmpl	$31, 16(%rsp)
	jle	.L2499
	movl	%r10d, %r13d
	addq	%r13, %r13
	movl	$0, %esi
	testl	%r10d, %r10d
	je	.L2559
	movl	%r8d, 20(%rsp)
.L2505:
	movswl	0(%rbp,%rsi), %r8d
	subl	%eax, %r8d
	imull	%r15d, %r8d
	addl	%r9d, %r8d
	movl	%r8d, %r9d
	andl	$32767, %r9d
	sarl	$15, %r8d
	addl	%r8d, %eax
	movl	%edi, %r8d
	imull	%eax, %r8d
	addl	$8192, %r8d
	sarl	$14, %r8d
	movw	%r8w, (%r11,%rsi)
	addq	$2, %rsi
	cmpq	%rsi, %r13
	jne	.L2505
	movl	20(%rsp), %r8d
	jmp	.L2504
.L2558:
	movq	%rcx, %r14
	movq	32(%rsp), %r11
	movq	40(%rsp), %r10
.L2507:
	leal	1(%rbx), %esi
	movl	%esi, %esi
	leaq	(%r14,%rsi,2), %r14
	addq	$1, (%rsp)
	movq	(%rsp), %rax
	addq	$2, %r11
	addq	$32, %r10
	addl	$738197504, 28(%rsp)
	addq	$4, %rdx
	cmpq	$8, %rax
	je	.L2560
.L2517:
	movswl	104(%r11), %edi
	movl	$105, %esi
	movzbl	(%rsp), %ecx
	shrl	%cl, %esi
	andl	$1, %esi
	movl	%esi, 8(%rsp)
	je	.L2494
	movzwl	(%r11), %r8d
	movl	$0, %r9d
.L2495:
	leaq	HL_LEN(%rip), %rax
	movq	(%rsp), %rbx
	movzwl	(%rax,%rbx,2), %ebx
	movl	%ebx, %esi
	shrw	%si
	movzwl	%si, %esi
	addl	%r8d, %esi
	movzwl	%bx, %ebx
	movl	%esi, %ebp
	subl	%ebx, %ebp
	cmpl	%ebx, %esi
	cmovnb	%ebp, %esi
	movl	%r8d, %ebp
	movzwl	(%r14,%rbp,2), %r12d
	movl	%r12d, %ebp
	negw	%bp
	cmovs	%r12d, %ebp
	movzwl	%bp, %ebp
	movl	%esi, %esi
	movzwl	(%r14,%rsi,2), %r12d
	movl	%r12d, %esi
	negw	%si
	cmovs	%r12d, %esi
	movzwl	%si, %esi
	leal	0(%rbp,%rsi), %eax
	movl	%eax, 16(%rsp)
	movl	8(%rsp), %ebp
	testl	%ebp, %ebp
	jne	.L2497
	movq	%r10, %r12
	movl	%r15d, 32(%rsp)
	movq	%r11, %r15
	movq	%r10, %rax
	jmp	.L2498
.L2509:
	testl	%r10d, %r10d
	je	.L2511
	movl	%r10d, %r13d
	addq	%r13, %r13
	movl	$0, %ecx
	movl	%r8d, 20(%rsp)
	movl	%ebx, 24(%rsp)
.L2512:
	movswl	(%rsi,%rcx), %ebx
	movswl	2(%rsi,%rcx), %r8d
	subl	%ebx, %r8d
	imull	%r9d, %r8d
	subl	$-128, %r8d
	sarl	$8, %r8d
	addl	%ebx, %r8d
	imull	%edi, %r8d
	movl	%r8d, %ebx
	sarl	$31, %ebx
	andl	$16383, %ebx
	addl	%r8d, %ebx
	sarl	$14, %ebx
	movw	%bx, (%r11,%rcx)
	addq	$2, %rcx
	cmpq	%rcx, %r13
	jne	.L2512
	movl	20(%rsp), %r8d
	movl	24(%rsp), %ebx
.L2513:
	addl	%r10d, %r8d
	cmpl	%ebx, %r8d
	jb	.L2515
.L2531:
	movl	8(%rsp), %r8d
.L2515:
	addl	%r10d, %ebp
	cmpl	$15, %ebp
	ja	.L2561
.L2498:
	movl	$16, %r10d
	subl	%ebp, %r10d
	movl	%ebx, %ecx
	subl	%r8d, %ecx
	cmpl	%ecx, %r10d
	cmova	%ecx, %r10d
	movl	%ebp, %ecx
	leaq	(%r12,%rcx,2), %r11
	movl	%r8d, %ecx
	leaq	(%r14,%rcx,2), %rsi
	cmpl	$31, 16(%rsp)
	jle	.L2509
	movl	%r10d, %r13d
	addq	%r13, %r13
	movl	$0, %ecx
	testl	%r10d, %r10d
	je	.L2511
	movl	%r8d, 20(%rsp)
	movl	%ebx, 24(%rsp)
.L2514:
	movswl	(%rsi,%rcx), %ebx
	movswl	2(%rsi,%rcx), %r8d
	subl	%ebx, %r8d
	imull	%r9d, %r8d
	subl	$-128, %r8d
	sarl	$8, %r8d
	addl	%ebx, %r8d
	imull	%edi, %r8d
	addl	$8192, %r8d
	sarl	$14, %r8d
	movw	%r8w, (%r11,%rcx)
	addq	$2, %rcx
	cmpq	%rcx, %r13
	jne	.L2514
	movl	20(%rsp), %r8d
	movl	24(%rsp), %ebx
	jmp	.L2513
.L2561:
	movq	%r15, %r11
	movl	32(%rsp), %r15d
	movq	%rax, %r10
	jmp	.L2507
.L2560:
	leaq	260+hl(%rip), %r12
	leaq	224(%r12), %rdx
	movq	56(%rsp), %rax
.L2518:
	movswl	(%rax), %esi
	movswl	32(%rax), %r11d
	movswl	64(%rax), %r14d
	movswl	96(%rax), %ebp
	movswl	128(%rax), %r9d
	movswl	160(%rax), %r13d
	movswl	192(%rax), %ebx
	movswl	224(%rax), %r8d
	movl	(%r12), %edi
	leal	(%rsi,%rbp), %ecx
	addl	%r9d, %ecx
	subl	%r8d, %ecx
	movl	%ecx, 64(%r12)
	leal	(%r11,%r14), %r10d
	leal	(%r10,%r13), %ecx
	addl	%ebx, %ecx
	movl	%ecx, 128(%r12)
	leal	(%r10,%rbp), %ecx
	addl	%r9d, %ecx
	addl	%r13d, %ecx
	addl	%ebx, %ecx
	addl	%r8d, %ecx
	addl	%ecx, %esi
	addl	%edi, %ecx
	movl	$32767, %r15d
	cmpl	%r15d, %ecx
	cmovg	%r15d, %ecx
	movl	$-32768, %r15d
	cmpl	%r15d, %ecx
	cmovl	%r15d, %ecx
	movw	%cx, (%rax)
	leal	(%r14,%rbp), %ecx
	addl	%r13d, %ecx
	leal	(%r11,%rcx,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r15d
	cmpl	%r15d, %ecx
	cmovg	%r15d, %ecx
	movl	$-32768, %r15d
	cmpl	%r15d, %ecx
	cmovl	%r15d, %ecx
	movw	%cx, 32(%rax)
	leal	0(%rbp,%r9), %ecx
	addl	%ebx, %ecx
	leal	(%r14,%rcx,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r15d
	cmpl	%r15d, %ecx
	cmovg	%r15d, %ecx
	movl	$-32768, %r15d
	cmpl	%r15d, %ecx
	cmovl	%r15d, %ecx
	movw	%cx, 64(%rax)
	leal	(%r9,%r13), %ecx
	addl	%r8d, %ecx
	leal	0(%rbp,%rcx,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r15d
	cmpl	%r15d, %ecx
	cmovg	%r15d, %ecx
	movl	$-32768, %r15d
	cmpl	%r15d, %ecx
	cmovl	%r15d, %ecx
	movw	%cx, 96(%rax)
	leal	0(%r13,%rbx), %ecx
	addl	%r11d, %ecx
	leal	(%r9,%rcx,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r15d
	cmpl	%r15d, %ecx
	cmovg	%r15d, %ecx
	movl	$-32768, %r15d
	cmpl	%r15d, %ecx
	cmovl	%r15d, %ecx
	movw	%cx, 128(%rax)
	leal	(%rbx,%r8), %ecx
	addl	%r14d, %ecx
	leal	0(%r13,%rcx,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r13d
	cmpl	%r13d, %ecx
	cmovg	%r13d, %ecx
	movl	$-32768, %r13d
	cmpl	%r13d, %ecx
	cmovl	%r13d, %ecx
	movw	%cx, 160(%rax)
	addl	%r8d, %r11d
	addl	%ebp, %r11d
	leal	(%rbx,%r11,2), %ecx
	subl	%esi, %ecx
	addl	%edi, %ecx
	movl	$32767, %r11d
	cmpl	%r11d, %ecx
	cmovg	%r11d, %ecx
	movl	$-32768, %r11d
	cmpl	%r11d, %ecx
	cmovl	%r11d, %ecx
	movw	%cx, 192(%rax)
	addl	%r9d, %r10d
	leal	(%r8,%r10,2), %ecx
	subl	%esi, %ecx
	subl	%edi, %ecx
	movl	$32767, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	movl	$-32768, %esi
	cmpl	%esi, %ecx
	cmovl	%esi, %ecx
	movw	%cx, 224(%rax)
	addq	$2, %rax
	addq	$4, %r12
	cmpq	%rdx, %rax
	jne	.L2518
	movl	$0, %eax
	leaq	rev_comb(%rip), %r8
	leaq	hl(%rip), %r10
	movl	$16, %r13d
	movl	$0, %r12d
	jmp	.L2524
.L2521:
	addl	%ecx, %esi
	cmpl	%r14d, %esi
	cmovnb	%r12d, %esi
	addl	%ecx, %ebp
	cmpl	$15, %ebp
	ja	.L2562
.L2523:
	movl	%r13d, %ecx
	subl	%ebp, %ecx
	movl	%r14d, %eax
	subl	%esi, %eax
	cmpl	%eax, %ecx
	cmova	%eax, %ecx
	testl	%ecx, %ecx
	je	.L2519
	leal	(%rcx,%rsi), %r9d
	movl	%esi, %eax
	movl	%ebp, %edi
	subl	%esi, %edi
	movl	%r14d, 16(%rsp)
.L2520:
	movl	%eax, %edx
	leal	(%rdi,%rax), %r14d
	leaq	224(%r14,%r11), %r14
	movzwl	4(%r10,%r14,2), %r14d
	movw	%r14w, (%r8,%rdx,2)
	addl	$1, %eax
	cmpl	%eax, %r9d
	jne	.L2520
	movl	16(%rsp), %r14d
.L2519:
	testl	%esi, %esi
	jne	.L2521
	movzwl	(%r8), %eax
	movw	%ax, (%r15)
	jmp	.L2521
.L2562:
	movq	%rbx, %rax
	movw	%si, (%r10,%rbx,2)
	leal	1(%r14), %edx
	movl	%edx, %edx
	leaq	(%r8,%rdx,2), %r8
	addq	$1, %rax
	cmpq	$8, %rax
	je	.L2563
.L2524:
	movzwl	(%r10,%rax,2), %esi
	leaq	HL_LEN(%rip), %rdx
	movzwl	(%rdx,%rax,2), %edx
	movzwl	%dx, %r14d
	movzwl	%dx, %edx
	leaq	(%r8,%rdx,2), %r15
	movl	$0, %ebp
	movl	%eax, %r11d
	salq	$4, %r11
	movq	%rax, %rbx
	jmp	.L2523
.L2563:
	leaq	388+hl(%rip), %rsi
	movq	64(%rsp), %rax
	addq	$4, %rax
	leaq	-252(%rsi), %r8
	leaq	64(%rsi), %r10
	movl	48(%rsp), %edx
	movl	52(%rsp), %r11d
.L2525:
	movl	-64(%rsi), %r9d
	movl	(%rsi), %ebx
	movl	%edx, %edi
	leal	(%r9,%rbx), %edx
	sall	$2, %edx
	movl	%r11d, %ecx
	subl	%ebx, %r9d
	leal	0(,%r9,4), %r11d
	addl	%edx, %edi
	sarl	%edi
	addl	%edi, -4(%rax)
	addl	%edx, (%rax)
	addl	%r11d, %ecx
	sarl	%ecx
	movl	%ecx, -4(%r8)
	movl	%r11d, (%r8)
	addq	$4, %rsi
	addq	$8, %rax
	addq	$8, %r8
	cmpq	%r10, %rsi
	jne	.L2525
	movl	%edx, 88+hl(%rip)
	movl	%r11d, 92+hl(%rip)
	movb	$1, 128+hl(%rip)
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2502:
	.cfi_restore_state
	movl	%eax, (%rdx)
	movl	%r9d, 32(%rdx)
	addl	%r10d, %r8d
	cmpl	%ebx, %r8d
	jb	.L2506
	addl	%r10d, %r12d
	movl	%r10d, %r8d
	jmp	.L2508
.L2559:
	movl	%eax, (%rdx)
	movl	%r9d, 32(%rdx)
	addl	%r10d, %r8d
	cmpl	%ebx, %r8d
	jnb	.L2529
	addl	%r10d, %r12d
	jmp	.L2508
.L2511:
	addl	%r10d, %r8d
	cmpl	%ebx, %r8d
	jnb	.L2531
	addl	%r10d, %ebp
	jmp	.L2498
.L2488:
	addl	%r8d, %r11d
	cmpl	%ebp, %r11d
	jb	.L2490
	addl	%r8d, %ebx
	movl	%r8d, %r11d
	jmp	.L2492
	.cfi_endproc
.LFE612:
	.size	rev_hall, .-rev_hall
	.type	track_lfo_tick, @function
track_lfo_tick:
.LFB516:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movl	1532(%rdi), %edx
	movzwl	18(%rdi), %eax
	andl	$127, %eax
	leaq	LFO_INC(%rip), %rcx
	movl	%edx, %esi
	addl	(%rcx,%rax,4), %esi
	movl	%esi, 1532(%rdi)
	cmpl	%edx, %esi
	jb	.L2583
.L2565:
	movl	1532(%rbx), %ecx
	movzwl	20(%rbx), %edx
	cmpw	$3, %dx
	je	.L2569
	jg	.L2570
	cmpw	$1, %dx
	je	.L2571
	movl	%ecx, %eax
	shrl	$16, %eax
	subl	$32768, %eax
	cmpw	$2, %dx
	je	.L2576
.L2573:
	movl	%ecx, %eax
	shrl	$22, %eax
	leaq	SINE(%rip), %rsi
	movl	%eax, %edx
	movswl	(%rsi,%rdx,2), %edx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%rsi,%rax,2), %eax
	subl	%edx, %eax
	shrl	$7, %ecx
	andl	$32767, %ecx
	imull	%ecx, %eax
	sarl	$15, %eax
	addl	%edx, %eax
	jmp	.L2576
.L2583:
	movl	1544(%rdi), %edx
	testl	%edx, %edx
	movl	$-1640531527, %eax
	cmove	%eax, %edx
	leaq	trk(%rip), %rcx
	movq	%rdi, %rax
	subq	%rcx, %rax
	sarq	$5, %rax
	imull	$1059797125, %eax, %eax
	cmpl	$1, %eax
	jbe	.L2584
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	sall	$5, %edx
	xorl	%edx, %eax
.L2568:
	movl	%eax, 1544(%rbx)
	jmp	.L2565
.L2584:
	call	rng
	jmp	.L2568
.L2570:
	cmpw	$4, %dx
	jne	.L2573
	movzwl	1546(%rbx), %eax
	subl	$32768, %eax
	jmp	.L2576
.L2571:
	shrl	$15, %ecx
	leal	-32768(%rcx), %edx
	movl	$98303, %eax
	subl	%ecx, %eax
	cmpl	$65535, %ecx
	cmovle	%edx, %eax
.L2576:
	movl	%eax, 1536(%rbx)
	movl	1540(%rbx), %edx
	cmpl	$32766, %edx
	jg	.L2564
	movzwl	24(%rbx), %esi
	movq	%rsi, %rcx
	andl	$127, %ecx
	leaq	ENV_LIN(%rip), %rax
	movl	(%rax,%rcx,4), %ecx
	movl	$32767, %eax
	testw	%si, %si
	je	.L2578
	movl	%ecx, %eax
	shrl	$9, %eax
	movl	$1, %ecx
	cmove	%ecx, %eax
	addl	%edx, %eax
	movl	$32767, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
.L2578:
	movl	%eax, 1540(%rbx)
.L2564:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2569:
	.cfi_restore_state
	movl	%ecx, %eax
	sarl	$31, %eax
	andl	$-65534, %eax
	addl	$32767, %eax
	jmp	.L2576
	.cfi_endproc
.LFE516:
	.size	track_lfo_tick, .-track_lfo_tick
	.type	bass_wave, @function
bass_wave:
.LFB127:
	.cfi_startproc
	movl	%esi, %ecx
	movl	%edx, %r8d
	cmpl	$1, %edi
	je	.L2586
	cmpl	$2, %edi
	je	.L2587
	testl	%edi, %edi
	jne	.L2588
	movl	%esi, %eax
	shrl	$22, %eax
	leaq	SINE(%rip), %rsi
	movl	%eax, %edx
	movswl	(%rsi,%rdx,2), %edx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%rsi,%rax,2), %eax
	subl	%edx, %eax
	shrl	$7, %ecx
	andl	$32767, %ecx
	imull	%ecx, %eax
	sarl	$15, %eax
	addl	%edx, %eax
	ret
.L2586:
	shrl	$15, %ecx
	leal	-32768(%rcx), %esi
	movl	$98303, %eax
	subl	%ecx, %eax
	movl	%eax, %edx
	cmpl	$65535, %ecx
	movl	%esi, %eax
	cmovg	%edx, %eax
	ret
.L2587:
	movl	%esi, %eax
	shrl	$16, %eax
	leal	-32768(%rax), %esi
	movl	$0, %edx
	movl	%r8d, %edi
	shrl	$15, %edi
	je	.L2591
	cmpl	%r8d, %ecx
	jb	.L2604
	movl	$0, %edx
	addl	%ecx, %r8d
	jc	.L2605
.L2591:
	movl	%esi, %eax
	subl	%edx, %eax
	ret
.L2604:
	movl	%ecx, %eax
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2591
.L2605:
	movl	%ecx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2591
.L2588:
	movl	%esi, %eax
	shrl	$16, %eax
	leal	-32768(%rax), %esi
	movl	%edx, %edi
	shrl	$15, %edi
	je	.L2593
	cmpl	%edx, %ecx
	jb	.L2606
	movl	$0, %eax
	addl	%ecx, %edx
	jc	.L2607
.L2595:
	subl	%eax, %esi
	leal	-2147483648(%rcx), %eax
	movl	%eax, %ecx
	shrl	$16, %ecx
	subl	$32768, %ecx
	cmpl	%r8d, %eax
	jb	.L2608
	movl	$0, %edx
	addl	%eax, %r8d
	jnc	.L2596
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2596
.L2606:
	movl	%ecx, %eax
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L2595
.L2607:
	movl	%ecx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L2595
.L2608:
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2596
.L2593:
	addl	$-2147483648, %ecx
	shrl	$16, %ecx
	subl	$32768, %ecx
	movl	$0, %edx
.L2596:
	subl	%edx, %ecx
	movl	%esi, %eax
	subl	%ecx, %eax
	sarl	%eax
	ret
	.cfi_endproc
.LFE127:
	.size	bass_wave, .-bass_wave
	.type	bass_render, @function
bass_render:
.LFB129:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movq	%rdi, %rax
	movq	%rsi, %r11
	movq	%rdx, 32(%rsp)
	movl	%ecx, 84(%rsp)
	movq	%r8, %r15
	movswl	166(%rdi), %esi
	movl	$3, %edx
	cmpl	%edx, %esi
	cmovg	%edx, %esi
	testl	%esi, %esi
	movl	$0, %edx
	cmovs	%edx, %esi
	movswl	168(%rdi), %edi
	movl	$3, %edx
	cmpl	%edx, %edi
	cmovg	%edx, %edi
	testl	%edi, %edi
	movl	$0, %edx
	cmovs	%edx, %edi
	movswl	170(%rax), %edx
	movl	$127, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	imull	$258, %edx, %ecx
	movl	%ecx, 16(%rsp)
	movzwl	180(%rax), %ecx
	movw	%cx, 24(%rsp)
	movswl	%cx, %edx
	movl	$127, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	imull	$258, %edx, %ecx
	movl	%ecx, 68(%rsp)
	movzwl	178(%rax), %ecx
	movw	%cx, 26(%rsp)
	movswl	%cx, %edx
	movl	$127, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	imull	$1792, %edx, %edx
	leal	32768(%rdx), %r13d
	movl	(%r8), %ecx
	movl	%ecx, (%rsp)
	movzwl	172(%rax), %r8d
	movl	%ecx, 4(%rsp)
	testw	%r8w, %r8w
	je	.L2610
	movswl	%r8w, %r8d
	movl	$50, %edx
	cmpl	%edx, %r8d
	cmovg	%edx, %r8d
	testl	%r8d, %r8d
	movl	$0, %edx
	cmovs	%edx, %r8d
	sall	$4, %r8d
	movslq	%r8d, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	movl	%r8d, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	movl	%edx, %ecx
	addl	4(%r15), %ecx
	movl	$2047, %r9d
	cmpl	%r9d, %ecx
	cmovg	%r9d, %ecx
	testl	%ecx, %ecx
	movl	$0, %r9d
	cmovs	%r9d, %ecx
	addl	$64, %ecx
	imull	$21846, %ecx, %r9d
	shrl	$22, %r9d
	leal	(%r9,%r9,2), %r10d
	sall	$6, %r10d
	movl	%ecx, %ebx
	subl	%r10d, %ebx
	movl	$10, %ecx
	subl	%r9d, %ecx
	leaq	PITCH_OCT(%rip), %r9
	movl	(%r9,%rbx,4), %r9d
	shrl	%cl, %r9d
	imull	$-100, %edx, %edx
	addl	%r8d, %edx
	imull	$2367, %edx, %edx
	movslq	%edx, %rcx
	imulq	$274877907, %rcx, %rcx
	sarq	$42, %rcx
	sarl	$31, %edx
	subl	%edx, %ecx
	movl	%r9d, %edx
	shrl	$12, %edx
	imull	%edx, %ecx
	addl	%r9d, %ecx
	movl	%ecx, 4(%rsp)
.L2610:
	movl	32(%r11), %ebx
	movl	36(%r11), %ecx
	movl	40(%r11), %edx
	movl	%edx, 80(%rsp)
	movl	44(%r11), %r12d
	movl	48(%r11), %ebp
	movswl	176(%rax), %edx
	movl	$127, %r8d
	cmpl	%r8d, %edx
	cmovg	%r8d, %edx
	testl	%edx, %edx
	movl	$0, %r8d
	cmovs	%r8d, %edx
	imull	$7600, %edx, %edx
	movslq	%edx, %r8
	imulq	$-2130574327, %r8, %r8
	shrq	$32, %r8
	addl	%edx, %r8d
	sarl	$6, %r8d
	sarl	$31, %edx
	subl	%r8d, %edx
	addl	$8192, %edx
	movswl	174(%rax), %eax
	movl	$127, %r8d
	cmpl	%r8d, %eax
	cmovg	%r8d, %eax
	testl	%eax, %eax
	movl	$0, %r8d
	cmovs	%r8d, %eax
	sall	$8, %eax
	addl	16(%r15), %eax
	movl	$32512, %r8d
	cmpl	%r8d, %eax
	cmovg	%r8d, %eax
	testl	%eax, %eax
	movl	$0, %r8d
	cmovs	%r8d, %eax
	movl	%eax, %r9d
	sarl	$8, %r9d
	movslq	%r9d, %r10
	leaq	SVF_G(%rip), %r8
	movzwl	(%r8,%r10,2), %r8d
	cmpl	$126, %r9d
	jg	.L2611
	addl	$1, %r9d
	movslq	%r9d, %r9
	leaq	SVF_G(%rip), %r10
	movzwl	(%r10,%r9,2), %r9d
	subl	%r8d, %r9d
	movzbl	%al, %eax
	imull	%eax, %r9d
	sarl	$8, %r9d
	addl	%r9d, %r8d
.L2611:
	leal	(%rdx,%r8), %r9d
	imull	%r8d, %r9d
	sarl	$12, %r9d
	addl	$4096, %r9d
	movl	$33554432, %eax
	movl	$0, %edx
	divl	%r9d
	movl	%r8d, %edx
	imull	%eax, %edx
	sarl	$12, %edx
	movl	%edx, 28(%rsp)
	imull	%edx, %r8d
	sarl	$12, %r8d
	movl	%r8d, 48(%rsp)
	movl	84(%rsp), %edx
	testl	%edx, %edx
	je	.L2612
	movl	(%rsp), %r9d
	shrl	%r9d
	sarl	$2, %r13d
	movl	%r13d, 72(%rsp)
	movl	%edx, %edx
	movq	%rdx, 40(%rsp)
	movl	80(%rsp), %r14d
	movl	%ecx, 8(%rsp)
	movl	%ebx, 12(%rsp)
	movl	$0, %r13d
	movl	$32767, %edx
	movl	%edx, %r10d
	movl	16(%rsp), %r8d
	subl	%r8d, %r10d
	movl	%r10d, 52(%rsp)
	movl	68(%rsp), %r10d
	subl	%r10d, %edx
	movl	%edx, 76(%rsp)
	movl	%r9d, 20(%rsp)
	movl	%ecx, 88(%rsp)
	movl	%esi, 56(%rsp)
	movl	%edi, 60(%rsp)
	movl	%ebx, 92(%rsp)
	movq	%r11, 96(%rsp)
	movl	%eax, 64(%rsp)
	jmp	.L2619
.L2617:
	sarl	%eax
	leal	16000(%rax), %ecx
	movl	$-16000, %esi
	subl	%eax, %esi
	testl	%edx, %edx
	cmovs	%esi, %ecx
	movl	%ecx, %edx
.L2616:
	movl	8(%r15), %esi
	movl	12(%r15), %ecx
	subl	%esi, %ecx
	imull	%r13d, %ecx
	movl	%ecx, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%ecx, %eax
	sarl	$5, %eax
	addl	%esi, %eax
	imull	%edx, %eax
	addl	%eax, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	movq	32(%rsp), %rdi
	addl	%eax, (%rdi,%r13,4)
	addq	$1, %r13
	movq	40(%rsp), %rax
	cmpq	%rax, %r13
	je	.L2625
.L2619:
	movl	(%rsp), %edx
	movl	12(%rsp), %esi
	movl	56(%rsp), %edi
	call	bass_wave
	movl	%eax, %ebx
	movl	4(%rsp), %edx
	movl	8(%rsp), %esi
	movl	60(%rsp), %edi
	call	bass_wave
	movl	52(%rsp), %edi
	imull	%edi, %ebx
	sarl	$15, %ebx
	movl	16(%rsp), %esi
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, %ebx
	cmpw	$0, 24(%rsp)
	jle	.L2613
	movl	76(%rsp), %eax
	imull	%eax, %ebx
	movl	%ebx, %edx
	sarl	$15, %edx
	movl	%r14d, %eax
	shrl	$22, %eax
	movl	%eax, %ecx
	leaq	SINE(%rip), %rsi
	movswl	(%rsi,%rcx,2), %ecx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%rsi,%rax,2), %ebx
	subl	%ecx, %ebx
	movl	%r14d, %eax
	shrl	$7, %eax
	andl	$32767, %eax
	imull	%eax, %ebx
	sarl	$15, %ebx
	addl	%ecx, %ebx
	movl	68(%rsp), %eax
	imull	%eax, %ebx
	sarl	$15, %ebx
	addl	%edx, %ebx
.L2613:
	movl	(%rsp), %edi
	addl	%edi, 12(%rsp)
	movl	4(%rsp), %esi
	addl	%esi, 8(%rsp)
	movl	20(%rsp), %eax
	addl	%eax, %r14d
	cmpw	$0, 26(%rsp)
	jle	.L2614
	sarl	$2, %ebx
	movl	72(%rsp), %eax
	imull	%eax, %ebx
	movl	%ebx, %edx
	sarl	$11, %edx
	movl	%edx, %eax
	negl	%eax
	cmovs	%edx, %eax
	movl	%eax, %ecx
	sarl	$8, %ecx
	movl	$31588, %ebx
	cmpl	$65535, %eax
	jg	.L2615
	movslq	%ecx, %rsi
	leaq	TANH_Q15(%rip), %rdi
	movswl	(%rdi,%rsi,2), %esi
	addl	$1, %ecx
	movslq	%ecx, %rcx
	movswl	(%rdi,%rcx,2), %ebx
	subl	%esi, %ebx
	movzbl	%al, %eax
	imull	%eax, %ebx
	sarl	$8, %ebx
	addl	%esi, %ebx
.L2615:
	movl	%ebx, %eax
	negl	%eax
	testl	%edx, %edx
	cmovs	%eax, %ebx
.L2614:
	sarl	%ebx
	subl	%ebp, %ebx
	movl	28(%rsp), %edi
	movl	%edi, %edx
	imull	%r12d, %edx
	movl	48(%rsp), %eax
	imull	%ebx, %eax
	addl	%eax, %edx
	sarl	$13, %edx
	addl	%ebp, %edx
	movl	64(%rsp), %eax
	imull	%r12d, %eax
	imull	%edi, %ebx
	addl	%ebx, %eax
	sarl	$13, %eax
	addl	%eax, %eax
	subl	%r12d, %eax
	movl	%eax, %r12d
	movl	$150000, %eax
	cmpl	%eax, %r12d
	cmovg	%eax, %r12d
	movl	$-150000, %eax
	cmpl	%eax, %r12d
	cmovl	%eax, %r12d
	leal	(%rdx,%rdx), %eax
	subl	%ebp, %eax
	movl	%eax, %ebp
	movl	$150000, %eax
	cmpl	%eax, %ebp
	cmovg	%eax, %ebp
	movl	$-150000, %eax
	cmpl	%eax, %ebp
	cmovl	%eax, %ebp
	movl	%edx, %eax
	negl	%eax
	cmovs	%edx, %eax
	cmpl	$16000, %eax
	jle	.L2616
	leal	-32000(%rax,%rax), %eax
	movl	%eax, %ecx
	negl	%ecx
	cmovs	%eax, %ecx
	movl	%ecx, %esi
	sarl	$8, %esi
	movl	$31588, %eax
	cmpl	$65535, %ecx
	jg	.L2617
	movslq	%esi, %rax
	leaq	TANH_Q15(%rip), %rbx
	movswl	(%rbx,%rax,2), %edi
	addl	$1, %esi
	movslq	%esi, %rsi
	movswl	(%rbx,%rsi,2), %eax
	subl	%edi, %eax
	movzbl	%cl, %ecx
	imull	%ecx, %eax
	sarl	$8, %eax
	addl	%edi, %eax
	jmp	.L2617
.L2625:
	movl	20(%rsp), %r9d
	movl	88(%rsp), %ecx
	movl	92(%rsp), %ebx
	movq	96(%rsp), %r11
	movl	(%rsp), %eax
	leal	(%rax,%rbx), %esi
	movl	84(%rsp), %edx
	subl	$1, %edx
	imull	%edx, %eax
	leal	(%rax,%rsi), %ebx
	movl	4(%rsp), %edi
	leal	(%rdi,%rcx), %eax
	imull	%edx, %edi
	movl	%edi, %ecx
	addl	%eax, %ecx
	movl	80(%rsp), %eax
	addl	%r9d, %eax
	imull	%edx, %r9d
	addl	%r9d, %eax
	movl	%eax, 80(%rsp)
.L2612:
	movl	%ebx, 32(%r11)
	movl	%ecx, 36(%r11)
	movl	80(%rsp), %eax
	movl	%eax, 40(%r11)
	movl	%r12d, 44(%r11)
	movl	%ebp, 48(%r11)
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE129:
	.size	bass_render, .-bass_render
	.type	pd_wave, @function
pd_wave:
.LFB135:
	.cfi_startproc
	movq	%rdi, %rax
	movl	%esi, %ecx
	movl	4(%rdi), %edi
	movl	(%rax), %edx
	cmpl	$4, %edx
	ja	.L2627
	movl	%edx, %edx
	leaq	.L2629(%rip), %rsi
	movslq	(%rsi,%rdx,4), %rdx
	addq	%rsi, %rdx
	notrack jmp	*%rdx
	.section	.rodata
	.align 4
	.align 4
.L2629:
	.long	.L2633-.L2629
	.long	.L2632-.L2629
	.long	.L2631-.L2629
	.long	.L2630-.L2629
	.long	.L2628-.L2629
	.text
.L2633:
	cmpl	%edi, %ecx
	jnb	.L2634
	imull	16(%rax), %ecx
	movl	%ecx, %edx
	shrl	$16, %edx
.L2635:
	sall	$16, %edx
	addl	$1073741824, %edx
	movl	%edx, %eax
	shrl	$22, %eax
	leaq	SINE(%rip), %rsi
	movl	%eax, %ecx
	movswl	(%rsi,%rcx,2), %ecx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%rsi,%rax,2), %eax
	subl	%ecx, %eax
	shrl	$7, %edx
	andl	$32767, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%ecx, %eax
	negl	%eax
	ret
.L2634:
	subl	%edi, %ecx
	movl	%ecx, %edx
	imull	20(%rax), %edx
	shrl	$16, %edx
	addl	$32768, %edx
	jmp	.L2635
.L2632:
	cmpl	%edi, %ecx
	jnb	.L2636
	imull	16(%rax), %ecx
	movl	%ecx, %edx
	shrl	$16, %edx
	jmp	.L2635
.L2636:
	movl	$32768, %edx
	cmpl	$32767, %ecx
	jbe	.L2635
	addl	$32768, %edi
	movl	$65535, %edx
	cmpl	%edi, %ecx
	jnb	.L2635
	leal	-32768(%rcx), %edx
	imull	20(%rax), %edx
	shrl	$16, %edx
	addl	$32768, %edx
	jmp	.L2635
.L2631:
	movl	$65535, %edx
	cmpl	%edi, %ecx
	jnb	.L2635
	imull	16(%rax), %ecx
	movl	%ecx, %edx
	shrl	$16, %edx
	jmp	.L2635
.L2630:
	cmpl	%edi, %ecx
	jnb	.L2637
	imull	16(%rax), %ecx
	movl	%ecx, %edx
	shrl	$16, %edx
	jmp	.L2635
.L2637:
	subl	%edi, %ecx
	movl	%ecx, %edx
	imull	20(%rax), %edx
	shrl	$16, %edx
	jmp	.L2635
.L2628:
	movl	$65535, %edx
	cmpl	%edi, %ecx
	jnb	.L2635
	movl	8(%rax), %esi
	cmpl	%esi, %ecx
	jnb	.L2638
	imull	16(%rax), %ecx
	movl	%ecx, %edx
	shrl	$16, %edx
	jmp	.L2635
.L2638:
	subl	%esi, %ecx
	movl	%ecx, %edx
	imull	20(%rax), %edx
	shrl	$16, %edx
	addl	$32768, %edx
	jmp	.L2635
.L2627:
	imull	12(%rax), %esi
	shrl	$16, %esi
	leal	(%rcx,%rsi,8), %eax
	subl	%esi, %eax
	sall	$16, %eax
	addl	$1073741824, %eax
	movl	%eax, %esi
	shrl	$22, %esi
	leaq	SINE(%rip), %r8
	movl	%esi, %edi
	movswl	(%r8,%rdi,2), %edi
	addl	$1, %esi
	andl	$1023, %esi
	movswl	(%r8,%rsi,2), %esi
	subl	%edi, %esi
	shrl	$7, %eax
	andl	$32767, %eax
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%edi, %eax
	leal	(%rax,%rax,4), %esi
	negl	%esi
	sarl	$3, %esi
	movl	$65535, %eax
	subl	%ecx, %eax
	cmpl	$5, %edx
	je	.L2640
	cmpl	$6, %edx
	je	.L2651
	cmpl	$16383, %ecx
	ja	.L2644
	leal	0(,%rcx,4), %eax
	jmp	.L2643
.L2651:
	cmpl	$32767, %ecx
	ja	.L2642
	leal	(%rcx,%rcx), %eax
	jmp	.L2643
.L2642:
	movl	$65535, %eax
	subl	%ecx, %eax
	addl	%eax, %eax
.L2640:
	movl	$65535, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
.L2643:
	imull	%esi, %eax
	sarl	$16, %eax
	ret
.L2644:
	movl	$65535, %eax
	cmpl	$49152, %ecx
	jbe	.L2643
	subl	%ecx, %eax
	sall	$2, %eax
	jmp	.L2640
	.cfi_endproc
.LFE135:
	.size	pd_wave, .-pd_wave
	.type	phase_render, @function
phase_render:
.LFB137:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movq	%rdi, %rax
	movq	%rsi, %rbp
	movq	%rdx, 32(%rsp)
	movl	%ecx, 68(%rsp)
	movq	%r8, %r14
	movq	%fs:40, %rdx
	movq	%rdx, 136(%rsp)
	xorl	%edx, %edx
	movzwl	166(%rdi), %edx
	movl	%edx, %ebx
	andl	$7, %ebx
	movswl	168(%rdi), %ecx
	movl	%ecx, 8(%rsp)
	movswl	172(%rdi), %edx
	imull	24(%r8), %edx
	sall	$8, %edx
	sarl	$15, %edx
	movswl	170(%rdi), %ecx
	sall	$8, %ecx
	addl	16(%r8), %ecx
	addl	%ecx, %edx
	movl	(%r8), %ecx
	movl	%ecx, 24(%rsp)
	movswl	174(%rdi), %esi
	movl	$1, 28(%rsp)
	testl	%esi, %esi
	jne	.L2653
	cmpw	$0, 176(%rdi)
	setne	%cl
	movzbl	%cl, %ecx
	movl	%ecx, 28(%rsp)
.L2653:
	movzwl	176(%rax), %edi
	movw	%di, 50(%rsp)
	movzwl	178(%rax), %eax
	movw	%ax, 48(%rsp)
	cwtl
	movl	%eax, 52(%rsp)
	sall	$4, %esi
	movslq	%esi, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	movl	%esi, %ecx
	sarl	$31, %ecx
	subl	%ecx, %eax
	movl	32(%rbp), %ecx
	movl	%ecx, 64(%rsp)
	movl	36(%rbp), %edi
	movl	%edi, 4(%rsp)
	movl	40(%rbp), %edi
	movl	%edi, (%rsp)
	movl	44(%rbp), %r13d
	movl	48(%rbp), %r15d
	movl	20(%r14), %ecx
	leal	-16384(%rdx,%rcx), %ecx
	movl	$32512, %edx
	cmpl	%edx, %ecx
	cmovg	%edx, %ecx
	testl	%ecx, %ecx
	movl	$0, %edx
	cmovs	%edx, %ecx
	movl	%ecx, %edx
	sall	$16, %edx
	subl	%ecx, %edx
	shrl	$8, %edx
	movl	%edx, %edx
	imulq	$33818642, %rdx, %rdx
	shrq	$32, %rdx
	imull	$56000, %edx, %edx
	shrl	$16, %edx
	movl	%edx, %r12d
	movl	%eax, %edx
	addl	4(%r14), %edx
	movl	$2047, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	addl	$64, %edx
	imull	$21846, %edx, %edi
	shrl	$22, %edi
	leal	(%rdi,%rdi,2), %ecx
	sall	$6, %ecx
	subl	%ecx, %edx
	movl	$10, %ecx
	subl	%edi, %ecx
	leaq	PITCH_OCT(%rip), %rdi
	movl	(%rdi,%rdx,4), %edx
	shrl	%cl, %edx
	movl	%edx, %ecx
	imull	$-100, %eax, %eax
	addl	%esi, %eax
	imull	$2367, %eax, %eax
	movslq	%eax, %rdx
	imulq	$274877907, %rdx, %rdx
	sarq	$42, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%ecx, %eax
	shrl	$12, %eax
	imull	%edx, %eax
	addl	%ecx, %eax
	movl	%eax, 56(%rsp)
	leaq	80(%rsp), %rdi
	movl	%r12d, %edx
	movl	%ebx, %esi
	call	pd_setup
	movl	8(%rsp), %eax
	subl	$1, %eax
	cmovc	%ebx, %eax
	leaq	112(%rsp), %rdi
	movl	%r12d, %edx
	movl	%eax, %esi
	call	pd_setup
	movl	68(%rsp), %eax
	testl	%eax, %eax
	je	.L2655
	movl	24(%rsp), %ebx
	shrl	%ebx
	movl	%ebx, 60(%rsp)
	movl	%eax, %eax
	movq	%rax, 40(%rsp)
	movl	64(%rsp), %r12d
	movl	$0, %ebx
	leaq	112(%rsp), %rax
	movq	%rax, 16(%rsp)
	leaq	80(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	%rbp, 72(%rsp)
	jmp	.L2663
.L2661:
	addl	%ebp, %eax
	sarl	%eax
	movl	%eax, %ebp
	movl	%ecx, 4(%rsp)
.L2658:
	cmpw	$0, 48(%rsp)
	je	.L2662
	movl	60(%rsp), %eax
	addl	%eax, (%rsp)
	movl	(%rsp), %esi
	movl	%esi, %eax
	shrl	$22, %eax
	movl	%eax, %edx
	leaq	SINE(%rip), %rdi
	movswl	(%rdi,%rdx,2), %ecx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%rdi,%rax,2), %eax
	subl	%ecx, %eax
	shrl	$7, %esi
	movl	%esi, %edx
	andl	$32767, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%ecx, %eax
	movl	52(%rsp), %ecx
	imull	%ecx, %eax
	imull	$200, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %ebp
.L2662:
	movl	8(%r14), %ecx
	movl	12(%r14), %edx
	subl	%ecx, %edx
	imull	%ebx, %edx
	movl	%edx, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%edx, %eax
	sarl	$5, %eax
	addl	%ecx, %eax
	imull	%ebp, %eax
	sarl	$15, %eax
	imull	$24000, %eax, %eax
	sarl	$15, %eax
	addl	%eax, %eax
	movq	32(%rsp), %rdi
	addl	%eax, (%rdi,%rbx,4)
	addq	$1, %rbx
	movq	40(%rsp), %rax
	cmpq	%rax, %rbx
	je	.L2670
.L2663:
	movl	%r12d, %esi
	shrl	$16, %esi
	testl	%r13d, %r13d
	movq	16(%rsp), %rdi
	cmove	8(%rsp), %rdi
	call	pd_wave
	movl	%eax, %ebp
	movl	%r13d, %eax
	xorl	$1, %eax
	movl	24(%rsp), %ecx
	addl	%ecx, %r12d
	cmovc	%eax, %r13d
	cmpl	$0, 28(%rsp)
	je	.L2658
	movl	4(%rsp), %esi
	shrl	$16, %esi
	testl	%r15d, %r15d
	movq	16(%rsp), %rdi
	cmove	8(%rsp), %rdi
	call	pd_wave
	movl	%r15d, %edx
	xorl	$1, %edx
	movl	4(%rsp), %ecx
	movl	56(%rsp), %edi
	addl	%edi, %ecx
	cmovc	%edx, %r15d
	cmpw	$0, 50(%rsp)
	je	.L2661
	imull	%ebp, %eax
	sarl	$15, %eax
	movl	%eax, %ebp
	movl	%ecx, 4(%rsp)
	jmp	.L2658
.L2670:
	movq	72(%rsp), %rbp
	movl	64(%rsp), %edx
	movl	24(%rsp), %ebx
	addl	%ebx, %edx
	movl	68(%rsp), %eax
	subl	$1, %eax
	imull	%ebx, %eax
	addl	%edx, %eax
	movl	%eax, 64(%rsp)
.L2655:
	movl	64(%rsp), %eax
	movl	%eax, 32(%rbp)
	movl	4(%rsp), %eax
	movl	%eax, 36(%rbp)
	movl	(%rsp), %eax
	movl	%eax, 40(%rbp)
	movl	%r13d, 44(%rbp)
	movl	%r15d, 48(%rbp)
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2671
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2671:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE137:
	.size	phase_render, .-phase_render
	.type	va_morph, @function
va_morph:
.LFB446:
	.cfi_startproc
	movl	%edi, %r8d
	movl	%esi, %r9d
	movl	%edx, %ecx
	cmpl	$12383, %edx
	jle	.L2673
	cmpl	$24767, %edx
	jg	.L2714
	leal	-2147483648(%rdi), %eax
	movl	%eax, %edi
	shrl	$16, %edi
	movl	%esi, %r10d
	shrl	$15, %r10d
	je	.L2680
	cmpl	%esi, %eax
	jb	.L2715
	movl	$0, %esi
	movl	%r9d, %edx
	addl	%eax, %edx
	jc	.L2716
.L2682:
	subl	$32768, %edi
	subl	%edi, %esi
	cmpl	$18575, %ecx
	jg	.L2696
	movl	%r8d, %edi
	shrl	$16, %edi
	subl	$32768, %edi
	cmpl	%r9d, %r8d
	jb	.L2717
	movl	%esi, %edx
	movl	$0, %eax
	addl	%r8d, %r9d
	jnc	.L2685
	movl	%r8d, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	movl	%esi, %edx
	jmp	.L2685
.L2714:
	subl	$24768, %ecx
	imull	$16785, %ecx, %ecx
	sarl	$12, %ecx
	movl	$32766, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	testl	%ecx, %ecx
	movl	$0, %eax
	cmovs	%eax, %ecx
	imull	$-58982, %ecx, %ecx
	leal	-2147483648(%rcx), %esi
	movl	%edi, %ecx
	shrl	$16, %ecx
	subl	$32768, %ecx
	movl	%r9d, %edi
	shrl	$15, %edi
	je	.L2675
	cmpl	%r9d, %r8d
	jb	.L2718
	movl	$0, %eax
	movl	%r9d, %edx
	addl	%r8d, %edx
	jc	.L2719
.L2677:
	subl	%eax, %ecx
	leal	(%rsi,%r8), %eax
	movl	%eax, %esi
	shrl	$16, %esi
	subl	$32768, %esi
	cmpl	%r9d, %eax
	jb	.L2720
	movl	$0, %edx
	addl	%eax, %r9d
	jnc	.L2678
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L2678
.L2718:
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L2677
.L2719:
	movl	%r8d, %eax
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L2677
.L2720:
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L2678
.L2715:
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %esi
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %esi
	subl	$32768, %esi
	jmp	.L2682
.L2716:
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %esi
	imull	%eax, %esi
	sarl	$15, %esi
	subl	%eax, %esi
	subl	%eax, %esi
	addl	$32768, %esi
	jmp	.L2682
.L2723:
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L2683
.L2717:
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	movl	%esi, %edx
	jmp	.L2685
.L2673:
	cmpl	$6191, %edx
	jle	.L2686
	leal	-1073741824(%rdi), %eax
	shrl	$15, %eax
	leal	-32768(%rax), %edx
	movl	$98303, %esi
	subl	%eax, %esi
	cmpl	$65535, %eax
	cmovle	%edx, %esi
	movl	%edi, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %edi
	movl	$0, %eax
	movl	%r9d, %r10d
	shrl	$15, %r10d
	je	.L2689
	cmpl	%r9d, %r8d
	jb	.L2721
	movl	$0, %eax
	addl	%r8d, %r9d
	jc	.L2722
.L2689:
	subl	%eax, %edi
	movl	%edi, %edx
	subl	$6192, %ecx
.L2684:
	imull	$2710, %ecx, %eax
	sarl	$12, %eax
	subl	%esi, %edx
	imull	%edx, %eax
	sarl	$12, %eax
	addl	%esi, %eax
	ret
.L2721:
	movl	%r8d, %eax
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L2689
.L2722:
	movl	%r8d, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L2689
.L2686:
	leal	-2147483648(%rdi), %eax
	movl	%eax, %edx
	shrl	$22, %edx
	leaq	SINE(%rip), %rsi
	movl	%edx, %edi
	movswl	(%rsi,%rdi,2), %edi
	addl	$1, %edx
	andl	$1023, %edx
	movswl	(%rsi,%rdx,2), %esi
	subl	%edi, %esi
	shrl	$7, %eax
	andl	$32767, %eax
	imull	%eax, %esi
	sarl	$15, %esi
	addl	%edi, %esi
	leal	-1073741824(%r8), %eax
	shrl	$15, %eax
	leal	-32768(%rax), %edi
	movl	$98303, %edx
	subl	%eax, %edx
	cmpl	$65535, %eax
	cmovle	%edi, %edx
	jmp	.L2684
.L2675:
	leal	(%rsi,%r8), %eax
	shrl	$16, %eax
	leal	-32768(%rax), %esi
	movl	$0, %edx
.L2678:
	subl	%edx, %esi
	movl	%ecx, %eax
	subl	%esi, %eax
	sarl	%eax
	ret
.L2696:
	movl	%r8d, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %edi
	cmpl	%r9d, %r8d
	jb	.L2723
	movl	$0, %eax
	addl	%r8d, %r9d
	jnc	.L2683
	movl	%r8d, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L2683
.L2680:
	movl	$32768, %esi
	subl	%edi, %esi
	cmpl	$18575, %edx
	jle	.L2724
	movl	%r8d, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %edi
	movl	$0, %eax
.L2683:
	subl	%eax, %edi
	movl	%edi, %edx
	addl	%esi, %edx
	sarl	%edx
	subl	$18576, %ecx
	jmp	.L2684
.L2724:
	movl	%r8d, %eax
	shrl	$16, %eax
	leal	-32768(%rax), %edi
	movl	%esi, %edx
	movl	$0, %eax
.L2685:
	subl	%eax, %edi
	movl	%edi, %esi
	subl	$12384, %ecx
	jmp	.L2684
	.cfi_endproc
.LFE446:
	.size	va_morph, .-va_morph
	.type	crb_head, @function
crb_head:
.LFB1587:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movl	%edi, %ebp
	movl	%esi, %r12d
	movq	%rdx, %rbx
	leal	-40(%rdi), %eax
	leal	19464(%rdi), %r13d
	cmpl	$29, %eax
	jbe	.L2727
	call	crb_obj
	movl	%eax, %r13d
.L2727:
	movl	%r12d, %esi
	movl	%ebp, %edi
	call	crb_sector
	movl	%eax, %edi
	movl	$32, %edx
	movq	%rbx, %rsi
	call	st_read
	testl	%eax, %eax
	jne	.L2729
	cmpl	$1431061830, (%rbx)
	jne	.L2730
	movzwl	4(%rbx), %eax
	cmpl	%r13d, %eax
	jne	.L2731
	movzwl	6(%rbx), %eax
	cmpl	%r12d, %eax
	jne	.L2732
	cmpl	$3840, 12(%rbx)
	ja	.L2733
	movl	28(%rbx), %ebp
	movl	$28, %esi
	movq	%rbx, %rdi
	call	st_crc32
	cmpl	%eax, %ebp
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L2725:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L2729:
	.cfi_restore_state
	movl	$-1, %eax
	jmp	.L2725
.L2730:
	movl	$-1, %eax
	jmp	.L2725
.L2731:
	movl	$-1, %eax
	jmp	.L2725
.L2732:
	movl	$-1, %eax
	jmp	.L2725
.L2733:
	movl	$-1, %eax
	jmp	.L2725
	.cfi_endproc
.LFE1587:
	.size	crb_head, .-crb_head
	.type	up_set_value, @function
up_set_value:
.LFB1152:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%esi, %ecx
	movl	%edx, %ebx
	movzbl	1(%rdi), %eax
	cmpb	$6, %al
	je	.L2748
	movzbl	2(%rdi), %esi
	cmpb	$3, %al
	seta	%r8b
	cmpb	$19, %sil
	jne	.L2740
	testb	%r8b, %r8b
	jne	.L2749
.L2740:
	cmpb	$24, %sil
	jne	.L2742
	testb	%r8b, %r8b
	jne	.L2750
.L2742:
	cmpb	$3, %al
	ja	.L2745
	movl	%ecx, %ecx
	movw	%bx, 16(%rdi,%rcx,2)
	jmp	.L2735
.L2748:
	movl	$0, %eax
	leaq	UP_CS1_COMMON(%rip), %rsi
.L2739:
	movzbl	(%rsi,%rax), %edx
	cmpl	%edx, %ecx
	je	.L2751
	addq	$1, %rax
	cmpq	$41, %rax
	jne	.L2739
	jmp	.L2735
.L2751:
	addl	$102, %eax
	cltq
	addl	$64, %ebx
	movb	%bl, 16(%rdi,%rax)
	jmp	.L2735
.L2749:
	leal	1(%rcx), %esi
	movzbl	3(%rdi), %eax
	cmpl	%eax, %esi
	je	.L2752
.L2745:
	movl	%ecx, %ecx
	addl	$64, %edx
	movb	%dl, 16(%rdi,%rcx)
.L2735:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2752:
	.cfi_restore_state
	movl	$16383, %edx
	cmpw	%dx, %bx
	cmovle	%ebx, %edx
	testw	%dx, %dx
	movl	$0, %eax
	cmovs	%eax, %edx
	movl	%edx, %eax
	andl	$127, %eax
	movb	%al, 156(%rdi)
	movl	%edx, %eax
	shrw	$7, %ax
	movb	%al, 157(%rdi)
	movb	$77, 158(%rdi)
	movb	$57, 159(%rdi)
	movl	$127, %eax
	cmpw	%ax, %dx
	cmova	%eax, %edx
	jmp	.L2745
.L2750:
	movzbl	3(%rdi), %eax
	leal	-8(%rax), %esi
	cmpl	%esi, %ecx
	jb	.L2745
	cmpl	%eax, %ecx
	jnb	.L2745
	movl	%ecx, %edx
	subl	%eax, %edx
	leal	128(%rdx,%rdx), %eax
	movl	%eax, %edx
	movb	%bl, 16(%rdi,%rdx)
	leal	1(%rax), %eax
	movzbl	%bh, %ebx
	movb	%bl, 16(%rdi,%rax)
	movb	$67, 158(%rdi)
	movb	$76, 159(%rdi)
	movl	$0, %edx
	jmp	.L2745
	.cfi_endproc
.LFE1152:
	.size	up_set_value, .-up_set_value
	.type	cb_rec_engine, @function
cb_rec_engine:
.LFB1235:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %eax
	andl	$15, %eax
	shrl	$4, %edi
	movl	%edi, %edi
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rax
	imulq	$3080, %rdi, %rdi
	addq	%rdi, %rax
	leaq	up_bank(%rip), %rdx
	movzbl	10(%rdx,%rax), %ebx
	movl	%ebx, %edi
	call	eng_ok
	testl	%eax, %eax
	jne	.L2753
	cmpl	$1, %ebx
	movl	$0, %ebx
	movl	$12, %eax
	cmove	%eax, %ebx
.L2753:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1235:
	.size	cb_rec_engine, .-cb_rec_engine
	.type	cb_bind_raw, @function
cb_bind_raw:
.LFB1236:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %ebx
	movl	%edi, %ebp
	shrl	$4, %ebp
	movl	%edi, %r12d
	andl	$15, %r12d
	call	up_used
	movl	%eax, %edx
	movl	$255, %eax
	testl	%edx, %edx
	je	.L2757
	movl	%r12d, %eax
	movl	%ebp, %edx
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rax
	imulq	$3080, %rdx, %rdx
	addq	%rdx, %rax
	leaq	up_bank(%rip), %rdx
	movzbl	9(%rdx,%rax), %edx
	subl	$3, %edx
	movl	$255, %eax
	testb	$-3, %dl
	je	.L2757
	movl	%r12d, %edx
	movl	%ebp, %eax
	leaq	(%rdx,%rdx,2), %rdx
	salq	$6, %rdx
	imulq	$3080, %rax, %rax
	addq	%rax, %rdx
	movl	$255, %eax
	leaq	up_bank(%rip), %rcx
	cmpb	$-90, 183(%rcx,%rdx)
	jne	.L2757
	movzbl	199(%rcx,%rdx), %ebp
	movl	$255, %eax
	testb	%bpl, %bpl
	je	.L2757
	movl	%ebx, %edi
	call	cb_rec_engine
	movl	%eax, %edx
	movzbl	%bpl, %ebp
	leal	-1(%rbp), %eax
	movl	%edx, %edx
	leaq	ENGINES(%rip), %rcx
	movq	(%rcx,%rdx,8), %rdx
	movzbl	288(%rdx), %edx
	cmpl	%edx, %eax
	movl	$255, %edx
	cmovnb	%edx, %eax
.L2757:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1236:
	.size	cb_bind_raw, .-cb_bind_raw
	.type	cb_bound, @function
cb_bound:
.LFB1237:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movl	%edi, %ebp
	call	cb_bind_raw
	movl	%eax, %r12d
	cmpl	$255, %eax
	je	.L2765
	movl	%ebp, %edi
	call	cb_rec_engine
	movl	%eax, %r13d
	testl	%ebp, %ebp
	je	.L2765
	movl	$0, %ebx
	jmp	.L2768
.L2767:
	addl	$1, %ebx
	cmpl	%ebx, %ebp
	je	.L2765
.L2768:
	movl	%ebx, %edi
	call	cb_bind_raw
	cmpl	%r12d, %eax
	jne	.L2767
	movl	%ebx, %edi
	call	cb_rec_engine
	cmpl	%r13d, %eax
	jne	.L2767
	movl	$255, %r12d
.L2765:
	movl	%r12d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1237:
	.size	cb_bound, .-cb_bound
	.type	cb_added, @function
cb_added:
.LFB1238:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebp
	movl	%esi, %ebx
	movl	%esi, %edi
	call	up_used
	testl	%eax, %eax
	je	.L2772
	movl	%ebx, %edi
	call	cb_rec_engine
	movl	%eax, %edx
	movl	$0, %eax
	cmpl	%ebp, %edx
	je	.L2776
.L2772:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L2776:
	.cfi_restore_state
	movl	%ebx, %edi
	call	cb_bound
	cmpl	$255, %eax
	sete	%al
	movzbl	%al, %eax
	jmp	.L2772
	.cfi_endproc
.LFE1238:
	.size	cb_added, .-cb_added
	.type	pool_pos_slot, @function
pool_pos_slot:
.LFB1243:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movl	$0, %ebp
	cmpl	$63, %esi
	ja	.L2777
	movl	%edi, %r12d
	movl	%esi, %ebx
	movl	%esi, %edi
	call	up_used
	testl	%eax, %eax
	je	.L2782
	movl	%ebx, %edi
	call	cb_rec_engine
	cmpl	%r12d, %eax
	jne	.L2777
	movl	%ebx, %edi
	call	cb_bound
	leal	1(%rax), %ebp
	cmpl	$255, %eax
	jne	.L2777
	movl	%r12d, %edi
	call	pool_nf
	leal	1(%rax), %ebp
	testl	%ebx, %ebx
	je	.L2777
	movl	$0, %r13d
.L2780:
	movl	%r13d, %esi
	movl	%r12d, %edi
	call	cb_added
	addl	%eax, %ebp
	addl	$1, %r13d
	cmpl	%r13d, %ebx
	jne	.L2780
	jmp	.L2777
.L2782:
	movl	$0, %ebp
.L2777:
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1243:
	.size	pool_pos_slot, .-pool_pos_slot
	.section	.rodata.str1.8
	.align 8
.LC14:
	.string	"pool: slot %u binds %s %u again: an added preset\n"
	.text
	.type	cb_init, @function
cb_init:
.LFB1249:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	leaq	CB_TRIM(%rip), %r10
	leaq	cb_trim_k(%rip), %r11
	leaq	120(%r10), %r13
	leaq	ENGINES(%rip), %r12
	movl	$-119, %ebp
	movl	$30, %ebx
	jmp	.L2793
.L2789:
	cmpb	%al, (%rdx)
	je	.L2802
	addl	$1, %edi
	addq	$32, %rsi
	cmpl	%r9d, %edi
	je	.L2787
.L2792:
	movq	(%rsi), %rcx
	movzbl	(%rcx), %eax
	movq	%r8, %rdx
	testb	%al, %al
	je	.L2789
.L2788:
	cmpb	%al, (%rdx)
	jne	.L2789
	addq	$1, %rcx
	addq	$1, %rdx
	movzbl	(%rcx), %eax
	testb	%al, %al
	jne	.L2788
	jmp	.L2789
.L2802:
	movb	%dil, (%r14)
.L2787:
	addq	$24, %r10
	addq	$1, %r11
	cmpq	%r13, %r10
	je	.L2803
.L2793:
	movzbl	(%r10), %edx
	movl	%edx, %eax
	mulb	%bpl
	shrw	$12, %ax
	imull	%ebx, %eax
	subl	%eax, %edx
	movzbl	%dl, %edx
	movq	(%r12,%rdx,8), %rdx
	movq	%r11, %r14
	movb	$-1, (%r11)
	movzbl	288(%rdx), %eax
	movzbl	%al, %r9d
	testb	%al, %al
	je	.L2787
	movq	8(%r10), %r8
	movq	280(%rdx), %rsi
	movl	$0, %edi
	jmp	.L2792
.L2803:
	movl	$0, %ebx
	leaq	ENGINES(%rip), %r13
	leaq	.LC14(%rip), %r12
	jmp	.L2795
.L2805:
	movl	%ebx, %edi
	call	cb_rec_engine
	movl	%eax, %eax
	movq	0(%r13,%rax,8), %rax
	movq	(%rax), %rcx
	leal	1(%rbx), %edx
	leal	1(%rbp), %r8d
	movq	%r12, %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
.L2794:
	addl	$1, %ebx
	cmpl	$64, %ebx
	je	.L2804
.L2795:
	movl	%ebx, %edi
	call	cb_bind_raw
	movl	%eax, %ebp
	cmpl	$255, %eax
	je	.L2794
	movl	%ebx, %edi
	call	cb_bound
	cmpl	$255, %eax
	jne	.L2794
	jmp	.L2805
.L2804:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE1249:
	.size	cb_init, .-cb_init
	.type	upx_blob_get, @function
upx_blob_get:
.LFB1207:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	leal	-32(%rdi), %r13d
	movl	$1, %eax
	cmpl	$31, %r13d
	ja	.L2806
	movl	%edi, %ebx
	movl	%esi, %ebp
	movq	%rdx, %r12
	call	up_used
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L2806
	movl	%ebx, %eax
	andl	$15, %eax
	shrl	$4, %ebx
	movl	%ebx, %ebx
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rax
	imulq	$3080, %rbx, %rbx
	addq	%rbx, %rax
	leaq	up_bank(%rip), %rdx
	movzbl	10(%rdx,%rax), %edx
	movl	$1, %eax
	cmpl	%ebp, %edx
	jne	.L2806
	movl	%r13d, %eax
	leaq	upx_len(%rip), %rdx
	movzbl	(%rdx,%rax), %ebx
	movl	%ebp, %edi
	call	upx_native_len
	movl	%eax, %edx
	movzbl	%bl, %ecx
	movl	$1, %eax
	cmpl	%edx, %ecx
	je	.L2817
.L2806:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L2817:
	.cfi_restore_state
	movzbl	%bl, %eax
	movl	%r13d, %r13d
	leaq	0(%r13,%r13,8), %rsi
	salq	$4, %rsi
	leaq	upx_aux(%rip), %rdx
	addq	%rdx, %rsi
	cmpb	$7, %bl
	ja	.L2808
	testb	$4, %al
	jne	.L2818
	testl	%eax, %eax
	je	.L2809
	movzbl	(%rsi), %edx
	movb	%dl, (%r12)
	testb	$2, %al
	je	.L2809
	movzwl	-2(%rax,%rsi), %edx
	movw	%dx, -2(%r12,%rax)
	jmp	.L2809
.L2818:
	movl	(%rsi), %edx
	movl	%edx, (%r12)
	movl	-4(%rax,%rsi), %edx
	movl	%edx, -4(%r12,%rax)
	jmp	.L2809
.L2808:
	movq	(%rsi), %rdx
	movq	%rdx, (%r12)
	movq	-8(%rax,%rsi), %rdx
	movq	%rdx, -8(%r12,%rax)
	leaq	8(%r12), %rdi
	andq	$-8, %rdi
	subq	%rdi, %r12
	subq	%r12, %rsi
	leal	(%rax,%r12), %ecx
	movl	%ecx, %eax
	shrl	$3, %eax
	movl	%eax, %ecx
	rep movsq
.L2809:
	movl	$0, %eax
	jmp	.L2806
	.cfi_endproc
.LFE1207:
	.size	upx_blob_get, .-upx_blob_get
	.section	.rodata.str1.8
	.align 8
.LC15:
	.string	"fm6: load slot %u patch crc %04x\n"
	.text
	.type	fm6u_get, @function
fm6u_get:
.LFB1174:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	movq	%rsi, %rdx
	cmpl	$31, %edi
	ja	.L2825
	movl	%edi, %esi
	shrl	$4, %esi
	movl	%esi, %eax
	movq	%rax, %rcx
	salq	$7, %rcx
	addq	%rax, %rcx
	salq	$4, %rcx
	movl	$1, %eax
	leaq	fm6u(%rip), %rdi
	cmpl	$1429622086, (%rdi,%rcx)
	jne	.L2819
	movl	%ebx, %ecx
	andl	$15, %ecx
	movl	%esi, %edi
	movq	%rdi, %rax
	salq	$7, %rax
	addq	%rdi, %rax
	salq	$4, %rax
	leaq	fm6u(%rip), %rdi
	movl	12(%rdi,%rax), %edi
	movl	$1, %eax
	btl	%ecx, %edi
	jc	.L2826
.L2819:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2825:
	.cfi_restore_state
	movl	$12, %esi
	call	upx_blob_get
	jmp	.L2819
.L2826:
	negq	%rsi
	andl	$2064, %esi
	movl	%ecx, %ecx
	salq	$7, %rcx
	leaq	16(%rsi,%rcx), %rax
	leaq	fm6u(%rip), %rcx
	addq	%rcx, %rax
	movdqa	(%rax), %xmm0
	movups	%xmm0, (%rdx)
	movdqa	16(%rax), %xmm1
	movups	%xmm1, 16(%rdx)
	movdqa	32(%rax), %xmm2
	movups	%xmm2, 32(%rdx)
	movdqa	48(%rax), %xmm3
	movups	%xmm3, 48(%rdx)
	movdqa	64(%rax), %xmm4
	movups	%xmm4, 64(%rdx)
	movdqa	80(%rax), %xmm5
	movups	%xmm5, 80(%rdx)
	movdqa	96(%rax), %xmm6
	movups	%xmm6, 96(%rdx)
	movdqa	112(%rax), %xmm7
	movups	%xmm7, 112(%rdx)
	movl	$128, %esi
	movq	%rdx, %rdi
	call	st_crc32
	movzwl	%ax, %ecx
	leal	1(%rbx), %edx
	leaq	.LC15(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movl	$0, %eax
	jmp	.L2819
	.cfi_endproc
.LFE1174:
	.size	fm6u_get, .-fm6u_get
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"quad: load slot %u patch crc %04x\n"
	.text
	.type	quad_store_get, @function
quad_store_get:
.LFB1181:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	movq	%rsi, %rdx
	cmpl	$31, %edi
	ja	.L2833
	movl	$1, %eax
	cmpl	$1396987217, quad_store(%rip)
	jne	.L2827
	movl	8+quad_store(%rip), %ecx
	btl	%edi, %ecx
	jc	.L2834
.L2827:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2833:
	.cfi_restore_state
	movl	$15, %esi
	call	upx_blob_get
	jmp	.L2827
.L2834:
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rax
	salq	$4, %rax
	leaq	quad_store(%rip), %rcx
	leaq	16(%rcx,%rax), %rax
	movdqa	(%rax), %xmm0
	movups	%xmm0, (%rsi)
	movdqa	16(%rax), %xmm1
	movups	%xmm1, 16(%rsi)
	movdqa	32(%rax), %xmm2
	movups	%xmm2, 32(%rsi)
	movdqa	48(%rax), %xmm3
	movups	%xmm3, 48(%rsi)
	movdqa	64(%rax), %xmm4
	movups	%xmm4, 64(%rsi)
	movl	$80, %esi
	movq	%rdx, %rdi
	call	st_crc32
	movzwl	%ax, %ecx
	leal	1(%rbx), %edx
	leaq	.LC16(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movl	$0, %eax
	jmp	.L2827
	.cfi_endproc
.LFE1181:
	.size	quad_store_get, .-quad_store_get
	.section	.rodata.str1.8
	.align 8
.LC17:
	.string	"va: load slot %u patch crc %04x\n"
	.text
	.type	va_store_get, @function
va_store_get:
.LFB1164:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	movq	%rsi, %rdx
	cmpl	$31, %edi
	ja	.L2841
	movl	$1, %eax
	cmpl	$827539798, va_store(%rip)
	jne	.L2835
	movl	8+va_store(%rip), %ecx
	btl	%edi, %ecx
	jc	.L2842
.L2835:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2841:
	.cfi_restore_state
	movl	$13, %esi
	call	upx_blob_get
	jmp	.L2835
.L2842:
	movl	%edi, %eax
	imulq	$110, %rax, %rax
	leaq	va_store(%rip), %rcx
	leaq	16(%rcx,%rax), %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, (%rsi)
	movdqu	16(%rax), %xmm1
	movups	%xmm1, 16(%rsi)
	movdqu	32(%rax), %xmm2
	movups	%xmm2, 32(%rsi)
	movdqu	48(%rax), %xmm3
	movups	%xmm3, 48(%rsi)
	movdqu	64(%rax), %xmm4
	movups	%xmm4, 64(%rsi)
	movdqu	80(%rax), %xmm5
	movups	%xmm5, 80(%rsi)
	movdqu	94(%rax), %xmm6
	movups	%xmm6, 94(%rsi)
	movl	$110, %esi
	movq	%rdx, %rdi
	call	st_crc32
	movzwl	%ax, %ecx
	leal	1(%rbx), %edx
	leaq	.LC17(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movl	$0, %eax
	jmp	.L2835
	.cfi_endproc
.LFE1164:
	.size	va_store_get, .-va_store_get
	.type	up_name, @function
up_name:
.LFB1157:
	.cfi_startproc
	movq	%rsi, %r9
	movl	%edi, %ecx
	shrl	$4, %ecx
	movl	%ecx, %ecx
	imulq	$3080, %rcx, %rcx
	andl	$15, %edi
	leaq	(%rdi,%rdi,2), %rax
	salq	$6, %rax
	addq	%rax, %rcx
	leaq	up_bank(%rip), %rax
	addq	%rax, %rcx
	movl	$0, %edx
.L2844:
	movl	%edx, %r8d
	movzbl	12(%rcx,%rdx), %eax
	testb	%al, %al
	je	.L2846
	leal	-97(%rax), %edi
	leal	-32(%rax), %esi
	cmpb	$26, %dil
	cmovb	%esi, %eax
	movb	%al, (%r9,%rdx)
	addq	$1, %rdx
	cmpq	$12, %rdx
	jne	.L2844
	addl	$1, %r8d
.L2846:
	movl	%r8d, %r8d
	movb	$0, (%r9,%r8)
	ret
	.cfi_endproc
.LFE1157:
	.size	up_name, .-up_name
	.type	settings_export, @function
settings_export:
.LFB1558:
	.cfi_startproc
	movl	$1346720309, (%rdi)
	movl	4+settings(%rip), %eax
	movl	%eax, %edx
	imulq	$954437177, %rdx, %rdx
	shrq	$33, %rdx
	leal	(%rdx,%rdx,8), %edx
	subl	%edx, %eax
	addl	$64, %eax
	movl	%eax, 4(%rdi)
	movl	8+settings(%rip), %eax
	movl	%eax, 8(%rdi)
	movl	12+settings(%rip), %eax
	cmpb	$1, settings_leds(%rip)
	je	.L2853
	cmpl	$2, %eax
	movl	$0, %edx
	cmovnb	%edx, %eax
.L2850:
	movl	%eax, 12+settings(%rip)
	movl	%eax, 12(%rdi)
	movdqa	panel(%rip), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqa	16+panel(%rip), %xmm1
	movups	%xmm1, 32(%rdi)
	movl	48(%rdi), %edx
	movzbl	settings_hold(%rip), %eax
	andl	$3, %eax
	cmpl	$1, %eax
	je	.L2851
	orl	$1212957696, %eax
	movl	%eax, %edx
.L2852:
	movl	%edx, 48(%rdi)
	leaq	52(%rdi), %rcx
	movq	favorites(%rip), %rax
	movq	%rax, 52(%rdi)
	movq	512+favorites(%rip), %rax
	movq	%rax, 564(%rdi)
	addq	$60, %rdi
	andq	$-8, %rdi
	subq	%rdi, %rcx
	leaq	favorites(%rip), %rsi
	subq	%rcx, %rsi
	addl	$520, %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	rep movsq
	ret
.L2853:
	movl	$1279607809, %eax
	jmp	.L2850
.L2851:
	cmpl	$2, %edx
	movl	$0, %eax
	cmovnb	%eax, %edx
	jmp	.L2852
	.cfi_endproc
.LFE1558:
	.size	settings_export, .-settings_export
	.type	crl_drop_take, @function
crl_drop_take:
.LFB846:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	leaq	8(%rdi), %rdi
	movl	$138, %esi
	call	crl_zero
	movb	$0, 4244(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE846:
	.size	crl_drop_take, .-crl_drop_take
	.type	crl_take_next, @function
crl_take_next:
.LFB837:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movq	4704(%rdi), %rdx
	movq	$0, 4704(%rdi)
	testq	%rdx, %rdx
	je	.L2859
	cmpl	$0, (%rdx)
	je	.L2859
	movzwl	4(%rdx), %eax
	testw	%ax, %ax
	jne	.L2870
.L2859:
	leaq	8(%rbx), %rdi
	movl	$138, %esi
	call	crl_zero
.L2861:
	cmpb	$0, 17(%rbx)
	je	.L2862
	movl	8(%rbx), %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$40, %rax
	movl	$2, %edx
	cmpl	$2, %eax
	je	.L2863
	movl	$3, %edx
	cmpl	$4, %eax
	je	.L2863
	cmpl	$1, %eax
	setne	%dl
	leal	1(%rdx,%rdx,2), %edx
.L2863:
	movb	%dl, (%rbx)
.L2862:
	movq	%rbx, %rdi
	call	crl_lev0_scan
	addw	$1, 4700(%rbx)
	movb	$0, 4713(%rbx)
	addb	$1, 4714(%rbx)
	cmpl	$0, 8(%rbx)
	jne	.L2858
	movb	$0, 4244(%rbx)
.L2858:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2870:
	.cfi_restore_state
	movzwl	%ax, %eax
	leaq	138(,%rax,8), %rsi
	movl	$0, %eax
.L2860:
	movzbl	(%rdx,%rax), %ecx
	movb	%cl, 8(%rbx,%rax)
	addq	$1, %rax
	cmpq	%rsi, %rax
	jne	.L2860
	jmp	.L2861
	.cfi_endproc
.LFE837:
	.size	crl_take_next, .-crl_take_next
	.type	crx_bass_ok, @function
crx_bass_ok:
.LFB734:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	movq	%rsi, %rbp
	cmpb	$0, 3(%rdi)
	je	.L2872
	movzbl	2(%rsi), %eax
	leal	-1(%rax), %edx
	movl	$0, %eax
	cmpb	$-3, %dl
	ja	.L2871
.L2872:
	movq	%rbp, %rdi
	call	crx_raw_loop
	testl	%eax, %eax
	jne	.L2876
	cmpb	$0, 10(%rbx)
	je	.L2871
	cmpb	$0, 23(%rbx)
	je	.L2871
	movl	$1, %eax
	cmpb	$0, 11(%rbx)
	jne	.L2871
	cmpb	$0, 15(%rbp)
	setne	%al
	movzbl	%al, %eax
	jmp	.L2871
.L2876:
	movl	$0, %eax
.L2871:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE734:
	.size	crx_bass_ok, .-crx_bass_ok
	.type	crx_chord_streams_ok, @function
crx_chord_streams_ok:
.LFB730:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	movq	%rsi, %rbp
	cmpb	$0, 3(%rdi)
	je	.L2880
	movzbl	2(%rsi), %eax
	leal	-1(%rax), %edx
	movl	$1, %eax
	cmpb	$-3, %dl
	ja	.L2879
.L2880:
	movq	%rbp, %rdi
	call	crx_raw_loop
	testl	%eax, %eax
	jne	.L2883
	cmpb	$0, 10(%rbx)
	je	.L2884
	movzbl	11(%rbx), %edx
	cmpb	$3, %dl
	je	.L2879
	movl	$1, %eax
	cmpb	$2, %dl
	jne	.L2879
	cmpb	$0, 15(%rbp)
	setne	%al
	movzbl	%al, %eax
	jmp	.L2879
.L2883:
	movl	$1, %eax
.L2879:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L2884:
	.cfi_restore_state
	movl	$1, %eax
	jmp	.L2879
	.cfi_endproc
.LFE730:
	.size	crx_chord_streams_ok, .-crx_chord_streams_ok
	.type	crx_phase_clocked, @function
crx_phase_clocked:
.LFB723:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movl	%edx, %r12d
	movzbl	97(%rsi), %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,2), %rax
	leaq	26(%r8,%rax,2), %rax
	cmpw	$0, 12(%rax)
	je	.L2888
	movl	184(%r8), %eax
	movl	%eax, 104(%rsi)
	movw	$0, 100(%rsi)
	movl	$0, 108(%rsi)
.L2887:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L2888:
	.cfi_restore_state
	movswq	2(%rax), %rdx
	leaq	CR_DIV_UNITS(%rip), %rcx
	movzbl	(%rcx,%rdx), %r11d
	movswl	10(%rax), %ebp
	movzwl	20(%r8), %ebx
	movl	208(%r8), %r9d
	movl	184(%r8), %eax
	subl	%r9d, %eax
	movl	%r9d, 104(%rsi)
	movzwl	216(%r8), %r10d
	movw	%r10w, 100(%rsi)
	movl	$0, %ecx
	testl	%eax, %eax
	jle	.L2890
	imull	%ebx, %eax
	imull	$2500, %r11d, %ecx
	movl	$0, %edx
	divl	%ecx
	movl	$2, %edx
	cmpl	%edx, %eax
	cmovb	%edx, %eax
	leal	-2(%rax), %ecx
.L2890:
	movzwl	%r10w, %r10d
	leal	(%rbx,%rbx), %esi
	subl	184(%r8), %r9d
	movl	%ecx, %eax
	shrl	%eax
	imull	$100, %eax, %eax
	movl	%ecx, %edx
	andl	$1, %edx
	negl	%edx
	andl	%ebp, %edx
	addl	%edx, %eax
	imull	%r11d, %eax
	imull	$50, %eax, %eax
	addl	%r10d, %eax
	leal	(%rbx,%rax,2), %eax
	movl	$0, %edx
	divl	%esi
	addl	%r9d, %eax
	testl	%eax, %eax
	jg	.L2892
.L2891:
	addl	$1, %ecx
	movl	%ecx, %eax
	shrl	%eax
	imull	$100, %eax, %eax
	movl	%ecx, %edx
	andl	$1, %edx
	negl	%edx
	andl	%ebp, %edx
	addl	%edx, %eax
	imull	%r11d, %eax
	imull	$50, %eax, %eax
	addl	%r10d, %eax
	leal	(%rbx,%rax,2), %eax
	movl	$0, %edx
	divl	%esi
	addl	%r9d, %eax
	testl	%eax, %eax
	jle	.L2891
.L2892:
	movl	%ecx, 108(%rdi)
	testl	%r12d, %r12d
	je	.L2887
	movl	212(%r8), %eax
	movl	$0, %edx
	divl	%r11d
	addl	%ecx, %eax
	movl	%eax, 112(%rdi)
	jmp	.L2887
	.cfi_endproc
.LFE723:
	.size	crx_phase_clocked, .-crx_phase_clocked
	.type	crx_note_start, @function
crx_note_start:
.LFB704:
	.cfi_startproc
	movl	$0, %eax
	cmpl	$127, %edx
	ja	.L2905
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %r13
	movl	%esi, %ebx
	movl	%edx, %ebp
	movl	$127, %eax
	cmpl	%eax, %ecx
	cmovle	%ecx, %eax
	movl	%eax, %r12d
	testl	%eax, %eax
	movl	$1, %eax
	cmovle	%eax, %r12d
	movslq	%edx, %rdx
	movslq	%esi, %rax
	salq	$7, %rax
	addq	%rdi, %rax
	cmpb	$0, 218(%rdx,%rax)
	je	.L2899
	movl	%ebp, %edx
	call	crx_out_off
	movq	136(%r13), %rax
	testq	%rax, %rax
	je	.L2900
	movzbl	%bpl, %edx
	movq	160(%r13), %rdi
	movl	%r12d, %ecx
	movl	%ebx, %esi
	call	*%rax
.L2900:
	movslq	%ebp, %rdx
	movslq	%ebx, %rax
	salq	$7, %rax
	addq	%r13, %rax
	movzbl	218(%rdx,%rax), %edx
	movl	$1, %eax
	cmpb	$-1, %dl
	je	.L2897
	movslq	%ebp, %rbp
	movslq	%ebx, %rbx
	salq	$7, %rbx
	addq	%r13, %rbx
	addl	$1, %edx
	movb	%dl, 218(%rbp,%rbx)
	jmp	.L2897
.L2899:
	movq	136(%rdi), %rax
	testq	%rax, %rax
	je	.L2901
	movzbl	%bpl, %edx
	movq	160(%rdi), %rdi
	movl	%r12d, %ecx
	call	*%rax
.L2901:
	movslq	%ebp, %rbp
	movslq	%ebx, %rbx
	salq	$7, %rbx
	addq	%r13, %rbx
	movb	$1, 218(%rbp,%rbx)
	movl	$1, %eax
.L2897:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L2905:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	ret
	.cfi_endproc
.LFE704:
	.size	crx_note_start, .-crx_note_start
	.type	crx_strum_fire, @function
crx_strum_fire:
.LFB718:
	.cfi_startproc
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 752(%rdi,%rax)
	je	.L2913
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movl	%edx, %r12d
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 800(%rdi,%rax)
	je	.L2908
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$31, 801(%rdi,%rax)
	ja	.L2908
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpw	$0, 788(%rdi,%rax)
	je	.L2910
	cmpw	$127, 7280(%rdi)
	ja	.L2908
.L2910:
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	759(%rbx,%rax), %ecx
	movl	%r12d, %edx
	movl	$0, %esi
	movq	%rbx, %rdi
	call	crx_note_start
	testl	%eax, %eax
	jne	.L2916
.L2908:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L2916:
	.cfi_restore_state
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	801(%rbx,%rax), %eax
	cmpb	$31, %al
	ja	.L2911
	movslq	%ebp, %rdx
	imulq	$172, %rdx, %rdx
	addq	%rbx, %rdx
	leal	1(%rax), %ecx
	movb	%cl, 801(%rdx)
	movzbl	%al, %eax
	movb	%r12b, 802(%rdx,%rax)
.L2911:
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	addq	%rbx, %rax
	movb	%r12b, 790(%rax)
	movb	$1, 791(%rax)
	movzwl	788(%rax), %esi
	testw	%si, %si
	je	.L2908
	leal	(%rbp,%rbp), %ecx
	movzbl	%cl, %ecx
	movzwl	%si, %esi
	movl	%r12d, %r9d
	movl	%ebp, %r8d
	movl	$1, %edx
	movq	%rbx, %rdi
	call	crx_sched
	jmp	.L2908
.L2913:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	ret
	.cfi_endproc
.LFE718:
	.size	crx_strum_fire, .-crx_strum_fire
	.type	crx_bass_start, @function
crx_bass_start:
.LFB736:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %r12
	movq	%rsi, %rbx
	call	crx_bass_pitch
	movl	%eax, %ebp
	cmpb	$0, 12(%r12)
	je	.L2918
	cmpb	$0, 13(%r12)
	je	.L2918
	leal	12(%rax), %eax
	cmpl	$116, %ebp
	cmovb	%eax, %ebp
.L2918:
	movb	$1, 92(%rbx)
	movb	$0, 93(%rbx)
	movzbl	7(%rbx), %ecx
	movl	%ebp, %edx
	movl	$1, %esi
	movq	%r12, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L2917
	movb	$1, 93(%rbx)
	movb	%bpl, 94(%rbx)
.L2917:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE736:
	.size	crx_bass_start, .-crx_bass_start
	.type	crx_bass_sync, @function
crx_bass_sync:
.LFB761:
	.cfi_startproc
	cmpb	$0, 10(%rdi)
	je	.L2926
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %rbx
	cmpb	$0, 23(%rdi)
	je	.L2921
	cmpb	$0, 11(%rdi)
	jne	.L2923
	cmpb	$0, 15(%rsi)
	jne	.L2923
	cmpb	$0, 92(%rsi)
	je	.L2921
	call	crx_bass_release
	movb	$0, 92(%rbx)
	jmp	.L2921
.L2923:
	cmpb	$0, 92(%rbx)
	je	.L2929
.L2921:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2929:
	.cfi_restore_state
	movq	%rbx, %rsi
	call	crx_bass_start
	jmp	.L2921
.L2926:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE761:
	.size	crx_bass_sync, .-crx_bass_sync
	.type	crx_keys_bass_sync, @function
crx_keys_bass_sync:
.LFB738:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %r12
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	movl	$0, %ebx
	leaq	734(%rdi), %rax
	movq	%rax, 16(%rsp)
	jmp	.L2945
.L2931:
	leaq	731(%r12), %r13
	cmpb	$0, 3(%r12)
	je	.L2951
	movl	%ebx, %edx
	movl	$16, %eax
	jmp	.L2932
.L2936:
	movq	8(%rsp), %rax
	cmpb	$0, 6(%rax)
	jne	.L2935
	cmpb	$0, 2(%rax)
	jne	.L2935
	movzbl	10(%rax), %eax
	cmpb	$0, 602(%r12,%rax)
	jne	.L2937
	jmp	.L2935
.L2953:
	movq	8(%rsp), %r14
.L2935:
	addq	$172, %rbp
	cmpq	%r15, %rbp
	je	.L2962
.L2938:
	movq	%rbp, %rdi
	movq	%rbp, 8(%rsp)
	cmpb	$0, 0(%rbp)
	je	.L2935
	cmpb	$0, 27(%rbp)
	je	.L2935
	testl	%ebx, %ebx
	je	.L2936
	call	crx_raw_loop
	testl	%eax, %eax
	je	.L2935
.L2937:
	movq	8(%rsp), %r8
	movzbl	28(%r8), %edx
	movl	%edx, %eax
	shrb	$3, %al
	movzbl	%al, %esi
	andl	$31, %eax
	movzbl	32(%rsp,%rax), %eax
	movl	%edx, %ecx
	andl	$7, %ecx
	movzbl	%al, %edi
	btl	%ecx, %edi
	jc	.L2935
	movslq	%esi, %rsi
	movl	$1, %edi
	sall	%cl, %edi
	orl	%edi, %eax
	movb	%al, 32(%rsp,%rsi)
	addl	$1, 28(%rsp)
	testq	%r14, %r14
	je	.L2953
	cmpb	28(%r14), %dl
	cmovb	%r8, %r14
	jmp	.L2935
.L2962:
	movl	28(%rsp), %r15d
	cmpl	$2, %r15d
	jbe	.L2933
	testq	%r14, %r14
	je	.L2933
	movq	%r14, %rsi
	movq	%r12, %rdi
	call	crx_bass_pitch
	movl	%eax, %ebp
	cmpb	$0, 12(%r12)
	je	.L2939
	cmpb	$0, 13(%r12)
	je	.L2939
	cmpl	$115, %eax
	ja	.L2939
	addl	$12, %ebp
	cmpl	$2, %r15d
	seta	%al
	testq	%r14, %r14
	setne	%dl
	andl	%edx, %eax
	movb	%al, 0(%r13)
	cmpb	$0, 1(%r13)
	jne	.L2940
	movb	$0, 1(%r13)
	jmp	.L2948
.L2939:
	cmpl	$2, 28(%rsp)
	seta	%al
	testq	%r14, %r14
	setne	%dl
	andl	%edx, %eax
	movb	%al, 0(%r13)
	cmpb	$0, 1(%r13)
	je	.L2942
	jmp	.L2940
.L2955:
	movl	$-1, %ebp
	movl	$0, %r14d
.L2940:
	movzbl	2(%r13), %edx
	cmpl	%ebp, %edx
	je	.L2943
.L2946:
	movl	$1, %esi
	movq	%r12, %rdi
	call	crx_note_end
.L2942:
	movb	$0, 1(%r13)
	cmpl	$127, %ebp
	ja	.L2943
.L2948:
	movzbl	7(%r14), %ecx
	movl	%ebp, %edx
	movl	$1, %esi
	movq	%r12, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L2943
	movb	$1, 1(%r13)
	movb	%bpl, 2(%r13)
	jmp	.L2943
.L2951:
	movl	%ebx, 28(%rsp)
	movl	$0, %r14d
.L2933:
	cmpl	$2, 28(%rsp)
	seta	%al
	testq	%r14, %r14
	setne	%dl
	andl	%edx, %eax
	movb	%al, 0(%r13)
	movl	$-1, %ebp
	cmpb	$0, 1(%r13)
	je	.L2942
	movzbl	2(%r13), %edx
	movl	$-1, %ebp
	jmp	.L2946
.L2952:
	movl	$0, 28(%rsp)
	movl	$0, %r14d
	jmp	.L2933
.L2934:
	movb	$0, 0(%r13)
	cmpb	$0, 1(%r13)
	jne	.L2955
	movb	$0, 1(%r13)
.L2943:
	addl	$1, %ebx
	cmpl	$2, %ebx
	je	.L2963
.L2945:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	testl	%ebx, %ebx
	je	.L2931
	movq	16(%rsp), %r13
	movl	$32, %eax
	movl	$24, %edx
.L2932:
	cmpb	$0, 10(%r12)
	je	.L2934
	cmpb	$0, 23(%r12)
	je	.L2934
	cmpl	%eax, %edx
	jnb	.L2952
	movl	%edx, %ecx
	imulq	$172, %rcx, %rsi
	leaq	752(%r12,%rsi), %rbp
	subl	$1, %eax
	subl	%edx, %eax
	addq	%rcx, %rax
	imulq	$172, %rax, %rax
	leaq	924(%r12,%rax), %r15
	movl	$0, 28(%rsp)
	movl	$0, %r14d
	jmp	.L2938
.L2963:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2964
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2964:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE738:
	.size	crx_keys_bass_sync, .-crx_keys_bass_sync
	.type	crx_sync_owner, @function
crx_sync_owner:
.LFB746:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 8(%rsp)
	movl	%esi, 16(%rsp)
	movq	%rcx, %rbp
	movq	%r8, %r13
	movl	%r9d, 28(%rsp)
	movq	96(%rsp), %r12
	movl	104(%rsp), %r14d
	cmpb	$0, (%rdx)
	je	.L2966
	movl	$0, %ebx
	movslq	%r14d, %r15
	cmpb	$0, (%r8)
	jne	.L2967
.L2968:
	testl	%r14d, %r14d
	jle	.L2977
	movq	%r12, %rbx
	movslq	%r14d, %rax
	leaq	(%rax,%r12), %r15
	leaq	1(%rbp), %rax
	movq	%r12, 96(%rsp)
	movq	%rax, %r12
	jmp	.L2978
.L2966:
	movb	$1, (%rdx)
	movb	$0, (%r8)
	testl	%r14d, %r14d
	jle	.L2965
	movq	%r12, %rbx
	movslq	%r14d, %r14
	addq	%r14, %r12
	movl	16(%rsp), %r14d
	movq	%rcx, 16(%rsp)
	movq	8(%rsp), %rbp
	movl	112(%rsp), %r15d
	jmp	.L2971
.L2970:
	addq	$1, %rbx
	cmpq	%r12, %rbx
	je	.L2965
.L2971:
	movq	%rbx, 8(%rsp)
	movzbl	(%rbx), %edx
	movl	%r15d, %ecx
	movl	%r14d, %esi
	movq	%rbp, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L2970
	movzbl	0(%r13), %eax
	movzbl	%al, %edx
	movl	28(%rsp), %edi
	cmpl	%edi, %edx
	jge	.L2970
	leal	1(%rax), %edx
	movb	%dl, 0(%r13)
	movq	8(%rsp), %rsi
	movzbl	(%rsi), %edx
	movzbl	%al, %eax
	movq	16(%rsp), %rsi
	movb	%dl, (%rsi,%rax)
	jmp	.L2970
.L2976:
	movzbl	0(%rbp,%rbx), %edx
	movl	16(%rsp), %esi
	movq	8(%rsp), %rdi
	call	crx_note_end
.L2974:
	addq	$1, %rbx
	movzbl	0(%r13), %eax
	cmpl	%ebx, %eax
	jle	.L2968
.L2967:
	testl	%r14d, %r14d
	jle	.L2976
	movzbl	0(%rbp,%rbx), %edi
	movq	%r12, %rax
	leaq	(%r15,%r12), %rsi
	movl	$0, %edx
	movl	$1, %ecx
.L2973:
	cmpb	%dil, (%rax)
	cmove	%ecx, %edx
	addq	$1, %rax
	cmpq	%rsi, %rax
	jne	.L2973
	testl	%edx, %edx
	jne	.L2974
	jmp	.L2976
.L2984:
	movzbl	(%rbx), %edx
	movl	112(%rsp), %ecx
	movl	16(%rsp), %esi
	movq	8(%rsp), %rdi
	call	crx_note_start
.L2981:
	addq	$1, %rbx
	cmpq	%r15, %rbx
	je	.L2982
.L2978:
	movzbl	0(%r13), %edx
	testb	%dl, %dl
	je	.L2984
	movzbl	(%rbx), %edi
	movq	%rbp, %rax
	movzbl	%dl, %edx
	leal	-1(%rdx), %ecx
	addq	%r12, %rcx
	movl	$0, %edx
	movl	$1, %esi
.L2980:
	cmpb	%dil, (%rax)
	cmove	%esi, %edx
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L2980
	testl	%edx, %edx
	jne	.L2981
	jmp	.L2984
.L2982:
	movq	96(%rsp), %r12
	movl	28(%rsp), %eax
	cmpl	%eax, %r14d
	movl	%eax, %ecx
	cmovle	%r14d, %ecx
	testl	%ecx, %ecx
	jle	.L2977
	movslq	%ecx, %rcx
	movl	$0, %eax
.L2985:
	movzbl	(%r12,%rax), %edx
	movb	%dl, 0(%rbp,%rax)
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L2985
.L2977:
	movl	28(%rsp), %eax
	cmpl	%eax, %r14d
	cmovl	%r14d, %eax
	movb	%al, 0(%r13)
.L2965:
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE746:
	.size	crx_sync_owner, .-crx_sync_owner
	.type	crx_fire_clocked_once, @function
crx_fire_clocked_once:
.LFB721:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	addq	%rdi, %rax
	movzbl	849(%rax), %ecx
	movzbl	%cl, %edx
	leaq	(%rdx,%rdx,4), %rsi
	leaq	(%rdx,%rsi,2), %rdx
	leaq	26(%rdi,%rdx,2), %r12
	movswq	2(%r12), %rdx
	leaq	CR_DIV_UNITS(%rip), %rsi
	movzbl	(%rsi,%rdx), %r14d
	movzbl	759(%rax), %r13d
	cmpb	$2, %cl
	je	.L3010
	movswl	14(%r12), %eax
	leaq	CR_PATTERNS(%rip), %rsi
	leal	-1(%rax), %edx
	movslq	%edx, %rdx
	movzbl	(%rsi,%rdx), %edi
	movslq	%ebp, %rdx
	imulq	$172, %rdx, %rdx
	cltq
	movzbl	(%rsi,%rax), %ecx
	subl	%edi, %ecx
	movl	864(%rbx,%rdx), %eax
	movl	$0, %edx
	divl	%ecx
	leal	-1(%rdi,%rdx), %eax
	movzbl	(%rsi,%rax), %ecx
	movl	%ecx, %edx
	andl	$15, %edx
	je	.L3001
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	850(%rbx,%rax), %eax
	testb	%al, %al
	je	.L3001
	movzbl	%al, %esi
	movswl	16(%r12), %eax
	leal	-1(%rdx,%rax), %eax
	cltd
	idivl	%esi
	leal	(%rdx,%rsi), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	cltq
	movslq	%ebp, %rdx
	imulq	$172, %rdx, %rdx
	addq	%rbx, %rdx
	movzbl	868(%rax,%rdx), %r15d
	movzbl	%cl, %ecx
	sarl	$4, %ecx
	addl	$1, %ecx
	imull	%r13d, %ecx
	movl	$1, %r13d
	cmpl	$7, %ecx
	jle	.L3003
	leal	23(%rcx), %r13d
	addl	$8, %ecx
	cmovns	%ecx, %r13d
	sarl	$4, %r13d
	jmp	.L3003
.L3010:
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	850(%rdi,%rax), %r15d
	testb	%r15b, %r15b
	je	.L3001
	cmpw	$5, 4(%r12)
	je	.L3011
	movslq	%ebp, %rcx
	imulq	$172, %rcx, %rcx
	addq	%rdi, %rcx
	movzbl	%r15b, %r15d
	movl	864(%rcx), %eax
	movl	$0, %edx
	divl	%r15d
	movl	%edx, %edx
	movzbl	868(%rcx,%rdx), %r15d
.L3003:
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 800(%rbx,%rax)
	je	.L3001
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	cmpb	$31, 801(%rbx,%rax)
	ja	.L3001
	cmpw	$127, 7280(%rbx)
	jbe	.L3012
.L3001:
	movslq	%ebp, %rbp
	imulq	$172, %rbp, %rbp
	addq	%rbp, %rbx
	addl	$1, 864(%rbx)
	addl	$1, 860(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3011:
	.cfi_restore_state
	call	crx_rand
	movzbl	%r15b, %r15d
	movl	$0, %edx
	divl	%r15d
	movslq	%edx, %rdx
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	addq	%rbx, %rax
	movzbl	868(%rdx,%rax), %r15d
	jmp	.L3003
.L3012:
	movl	%r13d, %ecx
	movl	%r15d, %edx
	movl	$0, %esi
	movq	%rbx, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L3001
	movzwl	20(%rbx), %ecx
	movswl	8(%r12), %eax
	movzbl	%r14b, %r14d
	imull	%r14d, %eax
	imull	$50, %eax, %eax
	addl	%ecx, %eax
	addl	%ecx, %ecx
	movslq	%ebp, %rdx
	imulq	$172, %rdx, %rdx
	movzbl	801(%rbx,%rdx), %edx
	cmpb	$31, %dl
	ja	.L3005
	movslq	%ebp, %rsi
	imulq	$172, %rsi, %rsi
	addq	%rbx, %rsi
	leal	1(%rdx), %edi
	movb	%dil, 801(%rsi)
	movzbl	%dl, %edx
	movb	%r15b, 802(%rsi,%rdx)
.L3005:
	movslq	%ebp, %rdx
	imulq	$172, %rdx, %rdx
	addq	%rbx, %rdx
	movb	%r15b, 790(%rdx)
	movb	$1, 791(%rdx)
	leal	(%rbp,%rbp), %edi
	movzbl	%dil, %edi
	movl	$1, %esi
	cmpl	%ecx, %eax
	jb	.L3006
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %esi
.L3006:
	movl	%r15d, %r9d
	movl	%ebp, %r8d
	movl	%edi, %ecx
	movl	$1, %edx
	movq	%rbx, %rdi
	call	crx_sched
	jmp	.L3001
	.cfi_endproc
.LFE721:
	.size	crx_fire_clocked_once, .-crx_fire_clocked_once
	.type	crx_clocked_step, @function
crx_clocked_step:
.LFB722:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbp
	movl	%esi, %r12d
	movl	$64, %r14d
	movslq	%esi, %rbx
	imulq	$172, %rbx, %rbx
	addq	%rdi, %rbx
	leaq	CR_DIV_UNITS(%rip), %r13
.L3017:
	movzwl	20(%rbp), %ecx
	cmpb	$0, 752(%rbx)
	je	.L3013
	cmpb	$0, 848(%rbx)
	je	.L3013
	movzbl	849(%rbx), %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,2), %rax
	leaq	26(%rbp,%rax,2), %rax
	movswq	2(%rax), %rdx
	movzbl	0(%r13,%rdx), %esi
	movswl	10(%rax), %edi
	movl	860(%rbx), %r9d
	cmpl	$1, %r9d
	jbe	.L3015
	movl	%r9d, %r10d
	shrl	%r10d
	movl	%esi, %eax
	imull	%r10d, %eax
	imull	$5000, %eax, %eax
	movslq	%r12d, %r8
	imulq	$172, %r8, %r8
	addq	%rbp, %r8
	movzwl	852(%r8), %edx
	addl	%edx, %eax
	movl	$0, %edx
	divl	%ecx
	addl	%eax, 856(%r8)
	movw	%dx, 852(%r8)
	addl	%r10d, %r10d
	subl	%r10d, %r9d
	movl	%r9d, 860(%r8)
.L3015:
	movl	860(%rbx), %edx
	movl	%edx, %eax
	shrl	%eax
	imull	$100, %eax, %eax
	andl	$1, %edx
	negl	%edx
	andl	%edi, %edx
	addl	%edx, %eax
	imull	%esi, %eax
	imull	$50, %eax, %eax
	movzwl	852(%rbx), %edx
	addl	%edx, %eax
	leal	(%rcx,%rax,2), %eax
	addl	%ecx, %ecx
	movl	$0, %edx
	divl	%ecx
	addl	856(%rbx), %eax
	subl	184(%rbp), %eax
	movl	%eax, %esi
	testl	%eax, %eax
	jle	.L3022
	leal	1(%r12,%r12), %ecx
	movzbl	%cl, %ecx
	movl	$0, %r9d
	movl	%r12d, %r8d
	movl	$3, %edx
	movq	%rbp, %rdi
	call	crx_sched
.L3013:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L3022:
	.cfi_restore_state
	movl	%r12d, %esi
	movq	%rbp, %rdi
	call	crx_fire_clocked_once
	subl	$1, %r14d
	jne	.L3017
	leal	1(%r12,%r12), %ecx
	movzbl	%cl, %ecx
	movl	$0, %r9d
	movl	%r12d, %r8d
	movl	$3, %edx
	movl	$1, %esi
	movq	%rbp, %rdi
	call	crx_sched
	jmp	.L3013
	.cfi_endproc
.LFE722:
	.size	crx_clocked_step, .-crx_clocked_step
	.type	crx_rephase_clocked, @function
crx_rephase_clocked:
.LFB724:
	.cfi_startproc
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 752(%rdi,%rax)
	je	.L3026
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 848(%rdi,%rax)
	jne	.L3029
.L3023:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L3029:
	.cfi_restore_state
	leal	1(%rsi,%rsi), %esi
	movzbl	%sil, %esi
	call	crx_cancel
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	leaq	752(%rbx,%rax), %rsi
	movl	$0, %edx
	movq	%rbx, %rdi
	call	crx_phase_clocked
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	crx_clocked_step
	jmp	.L3023
.L3026:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE724:
	.size	crx_rephase_clocked, .-crx_rephase_clocked
	.type	crx_main_voice, @function
crx_main_voice:
.LFB741:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%rdi, %rbp
	movl	%esi, %ebx
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	testl	%edx, %edx
	jne	.L3031
	movslq	%esi, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 848(%rdi,%rax)
	jne	.L3056
.L3032:
	leal	(%rbx,%rbx), %esi
	movzbl	%sil, %esi
	movq	%rbp, %rdi
	call	crx_cancel
	movslq	%ebx, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 801(%rbp,%rax)
	je	.L3033
	movq	%rax, %r14
	addq	%rbp, %r14
	movl	$0, %r12d
	movq	%r14, %r13
.L3034:
	movzbl	802(%r14,%r12), %edx
	movl	$0, %esi
	movq	%rbp, %rdi
	call	crx_note_end
	addq	$1, %r12
	movzbl	801(%r13), %eax
	cmpl	%r12d, %eax
	jg	.L3034
.L3033:
	movslq	%ebx, %rbx
	imulq	$172, %rbx, %rbx
	addq	%rbp, %rbx
	movb	$0, 801(%rbx)
	movb	$0, 800(%rbx)
	movb	$0, 848(%rbx)
.L3030:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3057
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3056:
	.cfi_restore_state
	leal	1(%rsi,%rsi), %esi
	movzbl	%sil, %esi
	call	crx_cancel
	jmp	.L3032
.L3031:
	cmpb	$0, 22(%rdi)
	je	.L3030
	movslq	%esi, %r12
	imulq	$172, %r12, %r12
	leaq	752(%rdi,%r12), %r13
	movq	%r13, %rsi
	call	crx_chord_streams_ok
	testl	%eax, %eax
	je	.L3030
	cmpb	$0, 16(%rbp)
	je	.L3036
	cmpb	$0, 3(%rbp)
	je	.L3058
.L3036:
	movslq	%ebx, %rax
	imulq	$172, %rax, %rax
	addq	%rbp, %rax
	movb	$1, 800(%rax)
	movb	$0, 801(%rax)
	cmpb	$0, 779(%rax)
	je	.L3030
	addq	%rbp, %r12
	movl	$0, %r13d
	movq	%rax, %rbx
	jmp	.L3048
.L3058:
	movzbl	17(%rbp), %edx
	movq	%r12, %rax
	addq	%rbp, %rax
	movb	$1, 800(%rax)
	movb	$0, 801(%rax)
	movb	$0, 791(%rax)
	movzbl	%dl, %eax
	subl	$2, %eax
	cmpl	$1, %eax
	jbe	.L3059
	movzbl	%dl, %r15d
	movzbl	%dl, %edx
	leaq	(%rdx,%rdx,4), %rax
	leaq	(%rdx,%rax,2), %rax
	leaq	26(%rbp,%rax,2), %r13
	leaq	780(%rbp,%r12), %r14
	leaq	32(%rsp), %rax
	movswl	6(%r13), %edx
	movslq	%ebx, %r12
	imulq	$172, %r12, %r12
	addq	%rbp, %r12
	movzbl	779(%r12), %esi
	movq	%rax, 8(%rsp)
	movq	%rax, %rcx
	movq	%r14, %rdi
	call	crx_expand_range
	movl	%eax, %edx
	movswl	4(%r13), %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 200
	leaq	72(%rsp), %rax
	pushq	%rax
	.cfi_def_cfa_offset 208
	movswl	6(%r13), %eax
	pushq	%rax
	.cfi_def_cfa_offset 216
	movzbl	779(%r12), %eax
	pushq	%rax
	.cfi_def_cfa_offset 224
	movq	%r14, %r9
	movl	$0, %r8d
	movq	40(%rsp), %rsi
	movq	%rbp, %rdi
	call	crx_order_notes
	movl	%eax, %esi
	movzwl	20(%rbp), %ecx
	movswl	0(%r13), %eax
	imull	$120, %eax, %eax
	movl	%ecx, %edx
	shrw	%dx
	movzwl	%dx, %edx
	addl	%edx, %eax
	movzwl	%cx, %ecx
	cltd
	idivl	%ecx
	testl	%eax, %eax
	movl	$1, %edx
	movl	%edx, %ecx
	cmovg	%eax, %ecx
	addq	$32, %rsp
	.cfi_def_cfa_offset 192
	cmpl	$1, %r15d
	je	.L3060
	movslq	%ebx, %rax
	imulq	$172, %rax, %rax
	movw	$0, 788(%rbp,%rax)
	movl	$0, %r14d
	cmpl	$4, %r15d
	jne	.L3039
	movswl	8(%r13), %eax
	imull	%ecx, %eax
	movl	$1, %edx
	cmpl	$49, %eax
	jle	.L3040
	addl	$50, %eax
	movslq	%eax, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
.L3040:
	movslq	%ebx, %rax
	imulq	$172, %rax, %rax
	movw	%dx, 788(%rbp,%rax)
	movl	$0, %r14d
	jmp	.L3039
.L3059:
	movq	%r12, %rax
	addq	%rbp, %rax
	movb	$1, 848(%rax)
	movb	%dl, 849(%rax)
	movl	$0, 864(%rax)
	movl	$0, 860(%rax)
	movl	184(%rbp), %edx
	movl	%edx, 856(%rax)
	movw	$0, 852(%rax)
	movq	%r13, %rsi
	movq	%rbp, %rdi
	call	crx_build_clocked_seq
	movl	$1, %edx
	movq	%r13, %rsi
	movq	%rbp, %rdi
	call	crx_phase_clocked
	movl	%ebx, %esi
	movq	%rbp, %rdi
	call	crx_clocked_step
	jmp	.L3030
.L3060:
	movswl	18(%r13), %r14d
	movslq	%ebx, %rax
	imulq	$172, %rax, %rax
	movw	$0, 788(%rbp,%rax)
.L3039:
	testl	%esi, %esi
	jle	.L3030
	movl	%r14d, %eax
	imull	%ecx, %eax
	addl	$50, %eax
	movslq	%eax, %r8
	imulq	$1374389535, %r8, %r8
	sarq	$37, %r8
	sarl	$31, %eax
	subl	%eax, %r8d
	leal	1(%r8,%r8), %eax
	movl	%eax, 24(%rsp)
	leal	(%rbx,%rbx), %r15d
	movzbl	%r15b, %eax
	movl	%eax, 20(%rsp)
	leaq	64(%rsp), %r12
	movslq	%esi, %rsi
	leaq	(%rsi,%r12), %r15
	movl	$0, %r13d
	movl	%r8d, 28(%rsp)
	movl	%ebx, 8(%rsp)
	movl	%ecx, %ebx
	jmp	.L3044
.L3041:
	testl	%esi, %esi
	jle	.L3061
	movzbl	(%r12), %r9d
	movl	8(%rsp), %r8d
	movl	20(%rsp), %ecx
	movl	$2, %edx
	movq	%rbp, %rdi
	call	crx_sched
.L3043:
	addq	$1, %r12
	addl	%ebx, %r13d
	cmpq	%r15, %r12
	je	.L3030
.L3044:
	movl	%r13d, %esi
	testl	%r14d, %r14d
	jle	.L3041
	movq	%rbp, %rdi
	call	crx_rand
	movl	$0, %edx
	divl	24(%rsp)
	movl	28(%rsp), %eax
	subl	%eax, %edx
	leal	0(%r13,%rdx), %esi
	jmp	.L3041
.L3061:
	movzbl	(%r12), %edx
	movl	8(%rsp), %esi
	movq	%rbp, %rdi
	call	crx_strum_fire
	jmp	.L3043
.L3047:
	addl	$1, %r13d
	addq	$1, %r12
	movzbl	779(%rbx), %eax
	cmpl	%r13d, %eax
	jle	.L3030
.L3048:
	movzbl	759(%rbx), %ecx
	movzbl	780(%r12), %edx
	movl	$0, %esi
	movq	%rbp, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L3047
	movzbl	801(%rbx), %eax
	cmpb	$31, %al
	ja	.L3047
	movzbl	780(%r12), %edx
	leal	1(%rax), %ecx
	movb	%cl, 801(%rbx)
	movzbl	%al, %eax
	movb	%dl, 802(%rbx,%rax)
	jmp	.L3047
.L3057:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE741:
	.size	crx_main_voice, .-crx_main_voice
	.type	crx_sound_voice, @function
crx_sound_voice:
.LFB744:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %r12
	movl	%esi, %ebp
	movslq	%esi, %rbx
	imulq	$172, %rbx, %rbx
	leaq	752(%rdi,%rbx), %r13
	movq	%r13, %rsi
	call	crx_prepare_voice
	movl	$1, %edx
	movl	%ebp, %esi
	movq	%r12, %rdi
	call	crx_main_voice
	cmpb	$0, 24(%r12)
	je	.L3062
	movq	%r13, %rsi
	movq	%r12, %rdi
	call	crx_chord_streams_ok
	testl	%eax, %eax
	je	.L3062
	movq	%rbx, %rax
	addq	%r12, %rax
	movb	$1, 834(%rax)
	movb	$0, 835(%rax)
	cmpb	$0, 779(%rax)
	je	.L3062
	movq	%rax, %rbx
	movl	$0, %r13d
	movq	%rax, %rbp
	jmp	.L3065
.L3064:
	addl	$1, %r13d
	addq	$1, %rbx
	movzbl	779(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L3062
.L3065:
	movzbl	759(%rbp), %ecx
	movzbl	780(%rbx), %edx
	movl	$2, %esi
	movq	%r12, %rdi
	call	crx_note_start
	testl	%eax, %eax
	je	.L3064
	movzbl	835(%rbp), %eax
	cmpb	$7, %al
	ja	.L3064
	leal	1(%rax), %edx
	movb	%dl, 835(%rbp)
	movzbl	780(%rbx), %edx
	movzbl	%al, %eax
	movb	%dl, 836(%rbp,%rax)
	jmp	.L3064
.L3062:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE744:
	.size	crx_sound_voice, .-crx_sound_voice
	.type	crx_hush_voice, @function
crx_hush_voice:
.LFB745:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbp
	movl	%esi, %r14d
	movl	$0, %edx
	call	crx_main_voice
	movslq	%r14d, %rax
	imulq	$172, %rax, %rax
	cmpb	$0, 835(%rbp,%rax)
	je	.L3069
	movq	%rax, %r13
	addq	%rbp, %r13
	movl	$0, %ebx
	movq	%r13, %r12
.L3070:
	movzbl	836(%r13,%rbx), %edx
	movl	$2, %esi
	movq	%rbp, %rdi
	call	crx_note_end
	addq	$1, %rbx
	movzbl	835(%r12), %eax
	cmpl	%ebx, %eax
	jg	.L3070
.L3069:
	movslq	%r14d, %r14
	imulq	$172, %r14, %r14
	addq	%r14, %rbp
	movb	$0, 835(%rbp)
	movb	$0, 834(%rbp)
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE745:
	.size	crx_hush_voice, .-crx_hush_voice
	.type	crx_restart_sounding_voices, @function
crx_restart_sounding_voices:
.LFB778:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %r12
	leaq	752(%rdi), %rbp
	movl	$0, %ebx
	jmp	.L3075
.L3074:
	addl	$1, %ebx
	addq	$172, %rbp
	cmpl	$32, %ebx
	je	.L3078
.L3075:
	cmpb	$0, 0(%rbp)
	je	.L3074
	movl	$0, %edx
	movl	%ebx, %esi
	movq	%r12, %rdi
	call	crx_main_voice
	movl	$1, %edx
	movl	%ebx, %esi
	movq	%r12, %rdi
	call	crx_main_voice
	jmp	.L3074
.L3078:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE778:
	.size	crx_restart_sounding_voices, .-crx_restart_sounding_voices
	.type	crx_swag_next, @function
crx_swag_next:
.LFB754:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	movzbl	201(%rdi), %eax
	cmpb	$1, %al
	sete	%cl
	setne	%dl
	cmpb	$0, 3(%rdi)
	setne	%dil
	testb	%al, %al
	sete	%r8b
	orb	%r8b, %dil
	jne	.L3079
	movzbl	%cl, %ecx
	leal	-3(%rcx,%rcx), %ecx
	movzbl	%dl, %edx
	leal	1(,%rdx,4), %edx
	testl	%esi, %esi
	jne	.L3091
.L3079:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L3091:
	.cfi_restore_state
	movsbl	15(%rbx), %esi
	cmpl	%edx, %esi
	movl	%edx, %ebp
	cmovle	%esi, %ebp
	cmpl	%ecx, %esi
	cmovl	%ecx, %ebp
	cmpb	$2, %al
	je	.L3092
	cmpb	$0, 202(%rbx)
	je	.L3085
	cmpl	%ebp, %edx
	jg	.L3086
	movb	$-1, 203(%rbx)
.L3087:
	movsbl	203(%rbx), %eax
	addl	%eax, %ebp
.L3085:
	movb	$1, 202(%rbx)
	movb	%bpl, 15(%rbx)
	jmp	.L3079
.L3092:
	movq	%rbx, %rdi
	call	crx_rand
	andl	$7, %eax
	addl	$2, %ebp
	cmpl	%eax, %ebp
	setl	%dl
	movzbl	%dl, %edx
	leal	-3(%rax,%rdx), %ebp
	jmp	.L3085
.L3086:
	cmpl	%ecx, %ebp
	jg	.L3087
	movb	$1, 203(%rbx)
	jmp	.L3087
	.cfi_endproc
.LFE754:
	.size	crx_swag_next, .-crx_swag_next
	.type	crx_kill_voice, @function
crx_kill_voice:
.LFB750:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movslq	%esi, %r12
	imulq	$172, %r12, %r12
	leaq	752(%rdi,%r12), %r13
	movl	$0, %edx
	call	crx_gesture
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	crx_hush_voice
	movq	%r13, %rsi
	movq	%rbx, %rdi
	call	crx_bass_release
	movb	$0, 844(%rbx,%r12)
	cmpb	$0, 7284(%rbx)
	je	.L3094
	cmpb	$0, 7285(%rbx)
	je	.L3094
	movzbl	7293(%rbx), %eax
	cmpl	%eax, %ebp
	jne	.L3094
	movl	792(%rbx,%r12), %eax
	cmpl	%eax, 7296(%rbx)
	jne	.L3094
	movq	%r12, %rax
	addq	%rbx, %rax
	movzbl	755(%rax), %edx
	movb	%dl, 7286(%rbx)
	movzbl	756(%rax), %edx
	movb	%dl, 7287(%rbx)
	movzbl	759(%rax), %edx
	movb	%dl, 7288(%rbx)
	movzbl	761(%rax), %edx
	movb	%dl, 7289(%rbx)
	movzbl	762(%rax), %edx
	movb	%dl, 7290(%rbx)
	movzbl	765(%rax), %edx
	movb	%dl, 7291(%rbx)
	movzbl	766(%rax), %eax
	movb	%al, 7292(%rbx)
	movb	$0, 7285(%rbx)
.L3094:
	movzbl	7356(%rbx), %eax
	cmpl	%ebp, %eax
	je	.L3109
	movslq	%ebp, %rbp
	imulq	$172, %rbp, %rbp
	movb	$0, 752(%rbx,%rbp)
.L3093:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L3109:
	.cfi_restore_state
	movb	$1, 7357(%rbx)
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	767(%rbx,%rax), %eax
	movb	%al, 7358(%rbx)
	testb	%al, %al
	je	.L3096
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	766(%rbx,%rax), %eax
.L3096:
	movb	%al, 7359(%rbx)
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	addq	%rbx, %rax
	movswl	768(%rax), %edx
	movsbl	763(%rax), %eax
	addl	%eax, %edx
	movslq	%edx, %rax
	imulq	$715827883, %rax, %rax
	sarq	$33, %rax
	movl	%edx, %ecx
	sarl	$31, %ecx
	subl	%ecx, %eax
	leal	(%rax,%rax,2), %ecx
	sall	$2, %ecx
	movl	%edx, %eax
	subl	%ecx, %eax
	leal	12(%rax), %edx
	cmovs	%edx, %eax
	movb	%al, 7360(%rbx)
	movslq	%ebp, %rax
	imulq	$172, %rax, %rax
	movzbl	779(%rbx,%rax), %edx
	movb	%dl, 7361(%rbx)
	testb	%dl, %dl
	je	.L3098
	leaq	7362(%rbx), %rax
	movzbl	%dl, %edx
	leal	-1(%rdx), %edx
	leaq	7363(%rbx,%rdx), %rcx
.L3099:
	movzbl	-6582(%rax,%r12), %edx
	movb	%dl, (%rax)
	addq	$1, %rax
	cmpq	%rcx, %rax
	jne	.L3099
.L3098:
	movslq	%ebp, %rbp
	imulq	$172, %rbp, %rbp
	movb	$0, 752(%rbx,%rbp)
	leaq	752(%rbx), %rax
	movl	$-1, %ecx
	movl	$0, %edx
	jmp	.L3101
.L3104:
	movl	%edx, %ecx
.L3100:
	addl	$1, %edx
	addq	$172, %rax
	cmpl	$32, %edx
	je	.L3110
.L3101:
	cmpb	$0, (%rax)
	je	.L3100
	testl	%ecx, %ecx
	js	.L3104
	movslq	%ecx, %rdi
	imulq	$172, %rdi, %rdi
	movl	40(%rax), %esi
	subl	792(%rbx,%rdi), %esi
	testl	%esi, %esi
	cmovg	%edx, %ecx
	jmp	.L3100
.L3110:
	testl	%ecx, %ecx
	movl	$255, %eax
	cmovs	%eax, %ecx
	movb	%cl, 7356(%rbx)
	jmp	.L3093
	.cfi_endproc
.LFE750:
	.size	crx_kill_voice, .-crx_kill_voice
	.type	crx_clear_free_voices, @function
crx_clear_free_voices:
.LFB757:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %r12
	leaq	752(%rdi), %rbx
	movl	$0, %ebp
	jmp	.L3113
.L3117:
	movl	%ebp, %esi
	movq	%r12, %rdi
	call	crx_kill_voice
.L3112:
	addl	$1, %ebp
	addq	$172, %rbx
	cmpl	$16, %ebp
	je	.L3116
.L3113:
	cmpb	$0, (%rbx)
	je	.L3112
	cmpb	$0, 6(%rbx)
	je	.L3112
	jmp	.L3117
.L3116:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE757:
	.size	crx_clear_free_voices, .-crx_clear_free_voices
	.type	cr_perform_drop_latched, @function
cr_perform_drop_latched:
.LFB930:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movl	%edi, %r12d
	leaq	752+cr(%rip), %rbx
	movl	$0, %ebp
	leaq	-752(%rbx), %r13
	jmp	.L3120
.L3119:
	addl	$1, %ebp
	addq	$172, %rbx
	cmpl	$16, %ebp
	je	.L3123
.L3120:
	cmpb	$0, (%rbx)
	je	.L3119
	cmpb	$0, 6(%rbx)
	jne	.L3119
	movzbl	4(%rbx), %ecx
	leal	1(%r12), %edx
	cmpl	%edx, %ecx
	jne	.L3119
	movzbl	3(%rbx), %eax
	cmpb	$0, 602(%r13,%rax)
	jne	.L3119
	movl	%ebp, %esi
	leaq	cr(%rip), %rdi
	call	crx_kill_voice
	jmp	.L3119
.L3123:
	leaq	cr(%rip), %rdi
	call	crx_keys_bass_sync
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE930:
	.size	cr_perform_drop_latched, .-cr_perform_drop_latched
	.type	perf_block, @function
perf_block:
.LFB604:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdi, (%rsp)
	movq	%rsi, 8(%rsp)
	movl	%edx, %ebp
	movl	16+pf(%rip), %r15d
	movzbl	1+perf_k(%rip), %eax
	movsbl	%al, %eax
	movl	%eax, 20(%rsp)
	testl	%eax, %eax
	je	.L3125
	movl	%eax, 184+pf(%rip)
	movl	$32768, 20(%rsp)
.L3125:
	movl	184+pf(%rip), %eax
	leal	0(,%rax,8), %ebx
	subl	%eax, %ebx
	imulq	$1374389535, %rbx, %rbx
	shrq	$37, %rbx
	leal	4(%rbx), %eax
	movl	%eax, 36(%rsp)
	leal	1(%rbx), %eax
	movl	%eax, 32(%rsp)
	cmpl	$0, 8+pf(%rip)
	jne	.L3235
.L3126:
	movzbl	3+perf_k(%rip), %eax
	movl	92+pf(%rip), %edx
	movsbl	%al, %eax
	imull	$269, %eax, %eax
	subl	%edx, %eax
	movl	$512, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-512, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	addl	%edx, %eax
	movl	%eax, 92+pf(%rip)
	testl	%ebp, %ebp
	je	.L3127
	leal	3(%rbx), %ecx
	movl	$1, %eax
	sall	%cl, %eax
	movl	%eax, 40(%rsp)
	movl	%ebp, %eax
	movq	%rax, 24(%rsp)
	movl	$0, %r13d
	leaq	pf(%rip), %r14
	jmp	.L3195
.L3235:
	movl	%r15d, %edi
	call	perf_pick
	movl	%eax, %edi
	call	perf_buf_select
	jmp	.L3126
.L3246:
	movl	12(%r14), %r15d
	movl	%r15d, %edi
	call	perf_pick
	movl	%eax, %edi
	call	perf_buf_select
	jmp	.L3128
.L3247:
	cmpb	$1, %al
	je	.L3236
	cmpb	$2, %al
	je	.L3237
	cmpb	$3, %al
	je	.L3238
	cmpb	$4, %al
	je	.L3239
	movl	$0, %edx
	movl	$0, %eax
	movl	$0, %ecx
.L3134:
	movl	%ecx, 100(%r14)
	movl	96(%r14), %esi
	subl	%esi, %ecx
	movl	$256, %edi
	cmpl	%edi, %ecx
	cmovg	%edi, %ecx
	movl	$-256, %edi
	cmpl	%edi, %ecx
	cmovl	%edi, %ecx
	addl	%esi, %ecx
	movl	%ecx, 96(%r14)
	je	.L3183
	cmpl	$32768, %ecx
	je	.L3221
	addl	%ecx, %ecx
	subl	%ebx, %eax
	movzwl	%ax, %esi
	imull	%ecx, %esi
	shrl	$16, %esi
	sarl	$16, %eax
	imull	%ecx, %eax
	addl	%esi, %eax
	addl	%eax, %ebx
	subl	%ebp, %edx
	movzwl	%dx, %eax
	imull	%ecx, %eax
	shrl	$16, %eax
	sarl	$16, %edx
	imull	%ecx, %edx
	addl	%edx, %eax
	addl	%eax, %ebp
	jmp	.L3129
.L3236:
	cmpb	$0, 27(%r14)
	jne	.L3131
	movl	36+pf(%rip), %esi
	cmpb	$0, 28+pf(%rip)
	je	.L3240
	movb	$0, 28+pf(%rip)
	movl	%ebp, %eax
	addl	108+pf(%rip), %eax
	sarl	$2, %eax
	movl	%eax, %edx
	leaq	0(,%rsi,4), %rcx
	andl	$24572, %ecx
	leaq	sl_buf(%rip), %rax
	addq	%rax, %rcx
	movl	%ebx, %eax
	addl	104+pf(%rip), %eax
	sarl	$2, %eax
	movl	$32767, %edi
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	movl	$-32768, %edi
	cmpl	%edi, %eax
	cmovl	%edi, %eax
	movw	%ax, (%rcx)
	movl	$32767, %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	$-32768, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movw	%ax, 2(%rcx)
	addl	$1, %esi
.L3133:
	movl	%esi, 36+pf(%rip)
	movl	40+pf(%rip), %eax
	addl	$1, %eax
	movl	%eax, 40+pf(%rip)
	cmpl	32+pf(%rip), %eax
	jb	.L3198
	movb	$1, 27+pf(%rip)
	movl	$0, 40+pf(%rip)
	movl	$0, %edx
	movl	$0, %eax
	movl	$0, %ecx
	jmp	.L3134
.L3240:
	movl	%ebx, 104+pf(%rip)
	movl	%ebp, 108+pf(%rip)
	movb	$1, 28+pf(%rip)
	jmp	.L3133
.L3131:
	movl	36+pf(%rip), %esi
	movl	32+pf(%rip), %r12d
	movl	40+pf(%rip), %ecx
	leal	-1(%r12), %edi
	subl	%ecx, %edi
	cmpb	$0, 26+pf(%rip)
	movl	%edi, %r8d
	cmove	%ecx, %r8d
	movl	%r8d, %eax
	shrl	%eax
	leal	-1(%rsi), %edx
	cmpl	%esi, %eax
	cmovnb	%edx, %eax
	leaq	0(,%rax,4), %rdx
	andl	$24572, %edx
	leaq	sl_buf(%rip), %r9
	addq	%r9, %rdx
	testb	$1, %r8b
	je	.L3137
	addl	$1, %eax
	leaq	4(%rdx), %r8
	cmpl	%esi, %eax
	cmovnb	%rdx, %r8
.L3138:
	movswl	(%rdx), %eax
	leal	(%rax,%rax,2), %eax
	movswl	(%r8), %r9d
	addl	%r9d, %eax
	sarl	%eax
	movswl	2(%rdx), %edx
	leal	(%rdx,%rdx,2), %edx
	movswl	2(%r8), %r8d
	addl	%r8d, %edx
	sarl	%edx
	cmpl	%edi, %ecx
	cmovbe	%ecx, %edi
	cmpl	$127, %edi
	ja	.L3139
	imull	%edi, %eax
	sarl	$7, %eax
	imull	%edx, %edi
	sarl	$7, %edi
	movl	%edi, %edx
.L3139:
	movl	52+pf(%rip), %edi
	testl	%edi, %edi
	jne	.L3241
.L3140:
	addl	$1, %ecx
	cmpl	%r12d, %ecx
	movl	$0, %esi
	cmovnb	%esi, %ecx
	movl	%ecx, 40+pf(%rip)
.L3148:
	movl	$0, %ecx
	cmpb	$13, 24+pf(%rip)
	je	.L3134
	movzbl	3+perf_k(%rip), %ecx
	movsbl	%cl, %ecx
	imull	$-327, %ecx, %ecx
	addl	$32768, %ecx
	jmp	.L3134
.L3137:
	leaq	-4(%rdx), %r8
	testl	%eax, %eax
	cmove	%rdx, %r8
	jmp	.L3138
.L3241:
	movl	48+pf(%rip), %r10d
	movl	%r10d, 44(%rsp)
	movl	44+pf(%rip), %r11d
	leal	-1(%r10), %r8d
	subl	%r11d, %r8d
	movl	%r8d, 48(%rsp)
	cmpb	$0, 29+pf(%rip)
	cmove	%r11d, %r8d
	movl	%r8d, 52(%rsp)
	movl	%r8d, %r9d
	shrl	%r9d
	leal	-1(%rsi), %r8d
	cmpl	%esi, %r9d
	cmovnb	%r8d, %r9d
	leaq	0(,%r9,4), %r10
	andl	$24572, %r10d
	leaq	sl_buf(%rip), %r8
	addq	%r10, %r8
	testb	$1, 52(%rsp)
	je	.L3143
	leal	1(%r9), %r10d
	leaq	4(%r8), %r9
	cmpl	%esi, %r10d
	cmovnb	%r8, %r9
.L3144:
	movswl	(%r8), %esi
	leal	(%rsi,%rsi,2), %esi
	movswl	(%r9), %r10d
	addl	%r10d, %esi
	sarl	%esi
	movswl	2(%r8), %r8d
	leal	(%r8,%r8,2), %r8d
	movswl	2(%r9), %r9d
	addl	%r9d, %r8d
	sarl	%r8d
	movl	48(%rsp), %r10d
	cmpl	%r10d, %r11d
	movl	%r10d, %r9d
	cmovbe	%r11d, %r9d
	cmpl	$127, %r9d
	ja	.L3145
	imull	%r9d, %esi
	sarl	$7, %esi
	imull	%r8d, %r9d
	movl	%r9d, %r8d
	sarl	$7, %r8d
.L3145:
	imull	%edi, %esi
	sarl	$7, %esi
	addl	%esi, %eax
	imull	%edi, %r8d
	sarl	$7, %r8d
	addl	%r8d, %edx
	subl	$1, %edi
	movl	%edi, 52+pf(%rip)
	leal	1(%r11), %esi
	movl	44(%rsp), %edi
	cmpl	%edi, %esi
	movl	$0, %edi
	cmovnb	%edi, %esi
	movl	%esi, 44+pf(%rip)
	jmp	.L3140
.L3143:
	leaq	-4(%r8), %rsi
	testl	%r9d, %r9d
	cmove	%r8, %rsi
	movq	%rsi, %r9
	jmp	.L3144
.L3237:
	movl	36+pf(%rip), %ecx
	cmpb	$0, 28+pf(%rip)
	je	.L3242
	movb	$0, 28+pf(%rip)
	movl	%ebp, %eax
	addl	108+pf(%rip), %eax
	sarl	$2, %eax
	movl	%eax, %edx
	leaq	0(,%rcx,4), %rsi
	andl	$24572, %esi
	leaq	sl_buf(%rip), %rax
	addq	%rax, %rsi
	movl	%ebx, %eax
	addl	104+pf(%rip), %eax
	sarl	$2, %eax
	movl	$32767, %edi
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	movl	$-32768, %edi
	cmpl	%edi, %eax
	cmovl	%edi, %eax
	movw	%ax, (%rsi)
	movl	$32767, %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	$-32768, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movw	%ax, 2(%rsi)
	addl	$1, %ecx
.L3151:
	movl	%ecx, 36+pf(%rip)
	cmpl	$1, %ecx
	jbe	.L3205
	movl	64+pf(%rip), %esi
	movl	%esi, %edx
	shrl	$16, %edx
	movl	%esi, %eax
	shrl	%eax
	andl	$32767, %eax
	leaq	0(,%rdx,4), %rcx
	andl	$24572, %ecx
	leaq	sl_buf(%rip), %rdi
	addq	%rdi, %rcx
	leal	2(%rdx,%rdx), %edx
	andl	$12286, %edx
	leaq	(%rdi,%rdx,2), %rdi
	movswl	(%rcx), %r8d
	movswl	(%rdi), %edx
	subl	%r8d, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	addl	%r8d, %edx
	addl	%edx, %edx
	movswl	2(%rcx), %r8d
	movswl	2(%rdi), %ecx
	subl	%r8d, %ecx
	imull	%eax, %ecx
	sarl	$15, %ecx
	addl	%r8d, %ecx
	addl	%ecx, %ecx
	movl	56+pf(%rip), %r8d
	leal	0(,%r8,4), %edi
	cmpl	$8192, %r8d
	movl	$32768, %eax
	cmovnb	%eax, %edi
	addl	%edi, %edi
	movzwl	%dx, %eax
	imull	%edi, %eax
	shrl	$16, %eax
	sarl	$16, %edx
	imull	%edi, %edx
	addl	%edx, %eax
	movzwl	%cx, %edx
	imull	%edi, %edx
	shrl	$16, %edx
	sarl	$16, %ecx
	imull	%edi, %ecx
	addl	%ecx, %edx
	movl	%r8d, %ecx
	shrl	%ecx
	addl	%esi, %ecx
	movl	%ecx, 64+pf(%rip)
	movl	60+pf(%rip), %esi
	movl	%r8d, %ecx
	subl	%esi, %ecx
	cmpl	%r8d, %esi
	movl	$0, %esi
	cmovnb	%esi, %ecx
	movl	%ecx, 56+pf(%rip)
	jmp	.L3148
.L3242:
	movl	%ebx, 104+pf(%rip)
	movl	%ebp, 108+pf(%rip)
	movb	$1, 28+pf(%rip)
	jmp	.L3151
.L3238:
	movl	36+pf(%rip), %eax
	cmpl	$4095, %eax
	jbe	.L3243
.L3155:
	movl	68+pf(%rip), %r12d
	cmpl	$1023, %r12d
	jbe	.L3158
	movl	$2048, %ecx
	subl	%r12d, %ecx
.L3159:
	movl	36+pf(%rip), %esi
	movl	76+pf(%rip), %eax
	leal	(%r12,%rax,2), %edi
	movl	%edi, %edx
	shrl	%edx
	cmpl	%esi, %edx
	jb	.L3162
.L3161:
	leal	-1(%rsi), %edx
.L3162:
	leaq	0(,%rdx,4), %rax
	andl	$24572, %eax
	leaq	sl_buf(%rip), %r8
	addq	%r8, %rax
	testb	$1, %dil
	je	.L3163
	addl	$1, %edx
	leaq	4(%rax), %rdi
	cmpl	%esi, %edx
	cmovnb	%rax, %rdi
	movq	%rdi, %rsi
.L3164:
	movswl	(%rax), %edx
	leal	(%rdx,%rdx,2), %edx
	movswl	(%rsi), %edi
	addl	%edi, %edx
	sarl	%edx
	imull	%ecx, %edx
	movl	%edx, 44(%rsp)
	movswl	2(%rax), %eax
	leal	(%rax,%rax,2), %eax
	movswl	2(%rsi), %edx
	addl	%edx, %eax
	sarl	%eax
	imull	%ecx, %eax
	movl	%eax, 48(%rsp)
	leal	1(%r12), %eax
	cmpl	$2048, %eax
	movl	$0, %edx
	cmovnb	%edx, %eax
	movl	%eax, 68+pf(%rip)
	movl	72+pf(%rip), %r12d
	cmpl	$1023, %r12d
	jbe	.L3166
	movl	$2048, %ecx
	subl	%r12d, %ecx
.L3167:
	movl	36+pf(%rip), %edi
	movl	80+pf(%rip), %eax
	leal	(%r12,%rax,2), %esi
	movl	%esi, %eax
	shrl	%eax
	cmpl	%edi, %eax
	jb	.L3170
.L3169:
	leal	-1(%rdi), %eax
.L3170:
	leaq	0(,%rax,4), %rdx
	andl	$24572, %edx
	leaq	sl_buf(%rip), %r8
	addq	%r8, %rdx
	testb	$1, %sil
	je	.L3171
	addl	$1, %eax
	leaq	4(%rdx), %rsi
	cmpl	%edi, %eax
	cmovnb	%rdx, %rsi
.L3172:
	movswl	(%rdx), %eax
	leal	(%rax,%rax,2), %eax
	movswl	(%rsi), %edi
	addl	%edi, %eax
	sarl	%eax
	imull	%ecx, %eax
	movl	44(%rsp), %edi
	addl	%edi, %eax
	movswl	2(%rdx), %edx
	leal	(%rdx,%rdx,2), %edx
	movswl	2(%rsi), %esi
	addl	%esi, %edx
	sarl	%edx
	imull	%ecx, %edx
	movl	48(%rsp), %edi
	addl	%edi, %edx
	leal	1(%r12), %ecx
	cmpl	$2048, %ecx
	movl	$0, %esi
	cmovnb	%esi, %ecx
	movl	%ecx, 72+pf(%rip)
	sarl	$10, %eax
	sarl	$10, %edx
	jmp	.L3148
.L3243:
	cmpb	$0, 28+pf(%rip)
	je	.L3244
	movb	$0, 28+pf(%rip)
	movl	%ebp, %edx
	addl	108+pf(%rip), %edx
	sarl	$2, %edx
	movl	%edx, %ecx
	leaq	0(,%rax,4), %rsi
	andl	$24572, %esi
	leaq	sl_buf(%rip), %rdx
	addq	%rdx, %rsi
	movl	%ebx, %edx
	addl	104+pf(%rip), %edx
	sarl	$2, %edx
	movl	$32767, %edi
	cmpl	%edi, %edx
	cmovg	%edi, %edx
	movl	$-32768, %edi
	cmpl	%edi, %edx
	cmovl	%edi, %edx
	movw	%dx, (%rsi)
	movl	$32767, %edx
	cmpl	%edx, %ecx
	cmovle	%ecx, %edx
	movl	$-32768, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
	movw	%dx, 2(%rsi)
	addl	$1, %eax
.L3157:
	movl	%eax, 36+pf(%rip)
	cmpl	$1023, %eax
	ja	.L3155
	movl	$0, %edx
	movl	$0, %eax
	movl	$0, %ecx
	jmp	.L3134
.L3244:
	movl	%ebx, 104+pf(%rip)
	movl	%ebp, 108+pf(%rip)
	movb	$1, 28+pf(%rip)
	jmp	.L3157
.L3158:
	testl	%r12d, %r12d
	jne	.L3209
	call	rng
	movl	36+pf(%rip), %esi
	shrl	$16, %eax
	movl	%eax, %edx
	leal	-1023(%rsi), %eax
	imull	%eax, %edx
	shrl	$16, %edx
	movl	%edx, 76+pf(%rip)
	leal	(%rdx,%rdx), %edi
	movl	%r12d, %ecx
	cmpl	%esi, %edx
	jnb	.L3161
	leaq	0(,%rdx,4), %rax
	andl	$24572, %eax
	leaq	sl_buf(%rip), %rcx
	addq	%rcx, %rax
	movl	%r12d, %ecx
.L3163:
	leaq	-4(%rax), %rsi
	testl	%edx, %edx
	cmove	%rax, %rsi
	jmp	.L3164
.L3209:
	movl	%r12d, %ecx
	jmp	.L3159
.L3166:
	testl	%r12d, %r12d
	jne	.L3212
	call	rng
	movl	36+pf(%rip), %edi
	shrl	$16, %eax
	leal	-1023(%rdi), %edx
	imull	%edx, %eax
	shrl	$16, %eax
	movl	%eax, 80+pf(%rip)
	leal	(%rax,%rax), %esi
	movl	%r12d, %ecx
	cmpl	%edi, %eax
	jnb	.L3169
	leaq	0(,%rax,4), %rdx
	andl	$24572, %edx
	leaq	sl_buf(%rip), %rcx
	addq	%rcx, %rdx
	movl	%r12d, %ecx
.L3171:
	leaq	-4(%rdx), %rsi
	testl	%eax, %eax
	cmove	%rdx, %rsi
	jmp	.L3172
.L3212:
	movl	%r12d, %ecx
	jmp	.L3167
.L3239:
	movl	84+pf(%rip), %ecx
	leal	1073741824(%rcx), %eax
	movl	%eax, %edx
	shrl	$22, %edx
	leaq	SINE(%rip), %rdi
	movl	%edx, %esi
	movswl	(%rdi,%rsi,2), %esi
	addl	$1, %edx
	andl	$1023, %edx
	movswl	(%rdi,%rdx,2), %edx
	subl	%esi, %edx
	shrl	$7, %eax
	andl	$32767, %eax
	imull	%eax, %edx
	sarl	$15, %edx
	addl	%esi, %edx
	movl	$32768, %eax
	subl	%edx, %eax
	sarl	%eax
	movl	%ecx, %esi
	shrl	$5, %esi
	addl	$8388608, %esi
	movl	%esi, %r8d
	shrl	$16, %r8d
	movl	32+pf(%rip), %edx
	leal	1(%r8), %edi
	cmpl	%edi, %edx
	jb	.L3216
	shrl	%esi
	andl	$32767, %esi
	movl	36+pf(%rip), %edi
	subl	%r8d, %edi
	leaq	0(,%rdi,4), %r9
	andl	$16380, %r9d
	leaq	sl_buf(%rip), %r8
	addq	%r8, %r9
	leal	8190(%rdi,%rdi), %edi
	andl	$8190, %edi
	leaq	(%r8,%rdi,2), %r8
	movswl	(%r9), %r10d
	movswl	(%r8), %edi
	subl	%r10d, %edi
	imull	%esi, %edi
	sarl	$15, %edi
	leal	(%rdi,%r10), %r12d
	movswl	2(%r9), %edi
	movswl	2(%r8), %r8d
	subl	%edi, %r8d
	imull	%esi, %r8d
	sarl	$15, %r8d
	addl	%edi, %r8d
.L3174:
	leal	-2147483648(%rcx), %esi
	shrl	$5, %esi
	addl	$8388608, %esi
	movl	%esi, %edi
	shrl	$16, %edi
	leal	1(%rdi), %r9d
	cmpl	%r9d, %edx
	jb	.L3217
	shrl	%esi
	andl	$32767, %esi
	movl	36+pf(%rip), %r10d
	subl	%edi, %r10d
	leaq	0(,%r10,4), %r9
	andl	$16380, %r9d
	leaq	sl_buf(%rip), %rdi
	addq	%rdi, %r9
	leal	8190(%r10,%r10), %r10d
	andl	$8190, %r10d
	leaq	(%rdi,%r10,2), %r10
	movswl	(%r9), %r11d
	movswl	(%r10), %edi
	subl	%r11d, %edi
	imull	%esi, %edi
	sarl	$15, %edi
	addl	%r11d, %edi
	movswl	2(%r9), %r9d
	movswl	2(%r10), %r10d
	subl	%r9d, %r10d
	imull	%r10d, %esi
	sarl	$15, %esi
	addl	%r9d, %esi
.L3175:
	movl	$32768, %r9d
	subl	%eax, %r9d
	imull	%eax, %r12d
	imull	%r9d, %edi
	addl	%r12d, %edi
	sarl	$15, %edi
	movl	%edi, 48(%rsp)
	imull	%r8d, %eax
	imull	%esi, %r9d
	addl	%r9d, %eax
	sarl	$15, %eax
	movl	%eax, 44(%rsp)
	movl	%ebx, %r8d
	sarl	%r8d
	movl	%ebp, %r12d
	sarl	%r12d
	movl	92+pf(%rip), %esi
	testl	%esi, %esi
	je	.L3218
	imull	%esi, %edi
	sarl	$15, %edi
	movl	%edi, %eax
	negl	%eax
	cmovs	%edi, %eax
	movl	%eax, %r9d
	sarl	$8, %r9d
	cmpl	$65535, %eax
	jg	.L3219
	movslq	%r9d, %r10
	leaq	TANH_Q15(%rip), %r11
	movswl	(%r11,%r10,2), %r10d
	addl	$1, %r9d
	movslq	%r9d, %r9
	movswl	(%r11,%r9,2), %r9d
	subl	%r10d, %r9d
	movzbl	%al, %eax
	imull	%eax, %r9d
	sarl	$8, %r9d
	leal	(%r9,%r10), %eax
	testl	%edi, %edi
	js	.L3177
.L3178:
	addl	%r8d, %eax
	movl	44(%rsp), %edi
	imull	%edi, %esi
	sarl	$15, %esi
	movl	%esi, %edi
	negl	%edi
	cmovs	%esi, %edi
	movl	%edi, %r9d
	sarl	$8, %r9d
	cmpl	$65535, %edi
	jg	.L3220
	movslq	%r9d, %r10
	leaq	TANH_Q15(%rip), %r11
	movswl	(%r11,%r10,2), %r10d
	addl	$1, %r9d
	movslq	%r9d, %r9
	movswl	(%r11,%r9,2), %r9d
	subl	%r10d, %r9d
	movzbl	%dil, %edi
	imull	%edi, %r9d
	sarl	$8, %r9d
	addl	%r10d, %r9d
	testl	%esi, %esi
	js	.L3179
.L3180:
	leal	(%r12,%r9), %esi
.L3176:
	cmpl	$127, %edx
	ja	.L3181
	imull	%edx, %eax
	sarl	$7, %eax
	imull	%edx, %esi
	sarl	$7, %esi
.L3181:
	movl	36+pf(%rip), %r9d
	leaq	0(,%r9,4), %rdi
	andl	$8188, %edi
	leaq	sl_buf(%rip), %r10
	addq	%r10, %rdi
	movl	$32767, %r10d
	cmpl	%r10d, %eax
	cmovg	%r10d, %eax
	movl	$-32768, %r10d
	cmpl	%r10d, %eax
	cmovl	%r10d, %eax
	movw	%ax, (%rdi)
	movl	$32767, %eax
	cmpl	%eax, %esi
	cmovle	%esi, %eax
	movl	$-32768, %esi
	cmpl	%esi, %eax
	cmovl	%esi, %eax
	movw	%ax, 2(%rdi)
	addl	$1, %r9d
	movl	%r9d, 36+pf(%rip)
	cmpl	$4095, %edx
	ja	.L3182
	addl	$1, %edx
	movl	%edx, 32+pf(%rip)
.L3182:
	addl	88+pf(%rip), %ecx
	movl	%ecx, 84+pf(%rip)
	movl	%ebx, %eax
	sarl	$4, %eax
	addl	%r8d, %eax
	imull	$45875, 48(%rsp), %edx
	sarl	$15, %edx
	addl	%edx, %eax
	movl	%ebp, %edx
	sarl	$4, %edx
	addl	%r12d, %edx
	imull	$45875, 44(%rsp), %ecx
	sarl	$15, %ecx
	addl	%ecx, %edx
	cmpb	$13, 24+pf(%rip)
	setne	%cl
	movzbl	%cl, %ecx
	sall	$15, %ecx
	jmp	.L3134
.L3216:
	movl	$0, %r8d
	movl	$0, %r12d
	jmp	.L3174
.L3217:
	movl	$0, %esi
	movl	$0, %edi
	jmp	.L3175
.L3219:
	movl	$31588, %eax
.L3177:
	negl	%eax
	jmp	.L3178
.L3220:
	movl	$31588, %r9d
.L3179:
	negl	%r9d
	jmp	.L3180
.L3218:
	movl	%r12d, %esi
	movl	%r8d, %eax
	jmp	.L3176
.L3198:
	movl	$0, %edx
	movl	$0, %eax
	movl	$0, %ecx
	jmp	.L3134
.L3205:
	movl	$0, %edx
	movl	$0, %eax
	movl	$0, %ecx
	jmp	.L3134
.L3183:
	cmpb	$13, 24(%r14)
	jne	.L3129
	movzbl	25+pf(%rip), %eax
	cmpb	$13, %al
	jne	.L3245
	movb	$0, 23+pf(%rip)
	cmpb	$0, sl_lent(%rip)
	je	.L3129
	movb	$0, sl_lent(%rip)
	call	perf_drop_slicer
	jmp	.L3129
.L3245:
	movzbl	%al, %edi
	call	perf_buf_start
	jmp	.L3129
.L3221:
	movl	%edx, %ebp
	movl	%eax, %ebx
	jmp	.L3129
.L3248:
	movl	132(%r14), %edi
	movl	%ebx, %edx
	sarl	$2, %edx
	movl	$32767, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	movl	$-32767, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
	subl	%edi, %edx
	movl	%edx, %r9d
	movswl	160(%r14), %esi
	movl	128(%r14), %r8d
	movswl	162(%r14), %r10d
	movswl	164(%r14), %r11d
	movl	%r8d, %edx
	imull	%r10d, %edx
	movl	%r9d, %ecx
	imull	%r11d, %ecx
	addl	%ecx, %edx
	sarl	$14, %edx
	addl	%edi, %edx
	movl	%esi, %ecx
	imull	%r8d, %ecx
	imull	%r10d, %r9d
	addl	%r9d, %ecx
	sarl	$14, %ecx
	addl	%ecx, %ecx
	subl	%r8d, %ecx
	movl	%ecx, 128(%r14)
	leal	(%rdx,%rdx), %ecx
	subl	%edi, %ecx
	movl	%ecx, 132(%r14)
	sall	$2, %edx
	movl	140(%r14), %edi
	movl	%ebp, %r9d
	sarl	$2, %r9d
	movl	$32767, %ecx
	cmpl	%ecx, %r9d
	cmovg	%ecx, %r9d
	movl	$-32767, %ecx
	cmpl	%ecx, %r9d
	cmovl	%ecx, %r9d
	subl	%edi, %r9d
	movl	136(%r14), %r8d
	movl	%r8d, %ecx
	imull	%r10d, %ecx
	imull	%r9d, %r11d
	addl	%r11d, %ecx
	sarl	$14, %ecx
	addl	%edi, %ecx
	imull	%r8d, %esi
	imull	%r10d, %r9d
	addl	%r9d, %esi
	sarl	$14, %esi
	addl	%esi, %esi
	subl	%r8d, %esi
	movl	%esi, 136(%r14)
	leal	(%rcx,%rcx), %esi
	subl	%edi, %esi
	movl	%esi, 140(%r14)
	sall	$2, %ecx
	cmpl	$32768, %eax
	je	.L3224
	addl	%eax, %eax
	subl	%ebx, %edx
	movzwl	%dx, %esi
	imull	%eax, %esi
	shrl	$16, %esi
	sarl	$16, %edx
	imull	%eax, %edx
	addl	%esi, %edx
	addl	%edx, %ebx
	subl	%ebp, %ecx
	movzwl	%cx, %edx
	imull	%eax, %edx
	shrl	$16, %edx
	sarl	$16, %ecx
	imull	%eax, %ecx
	leal	(%rdx,%rcx), %eax
	addl	%eax, %ebp
	jmp	.L3187
.L3224:
	movl	%ecx, %ebp
	movl	%edx, %ebx
	jmp	.L3187
.L3249:
	cmpl	$0, 116(%r14)
	setg	%al
	movzbl	%al, %eax
	sall	$15, %eax
	jmp	.L3188
.L3250:
	movl	%ebx, %edx
	sarl	$2, %edx
	movl	$32767, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	movl	$-32767, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
	movl	148(%r14), %r10d
	movl	%edx, %r12d
	subl	%r10d, %r12d
	movswl	166(%r14), %edi
	movl	144(%r14), %r11d
	movswl	168(%r14), %esi
	movl	%edi, %r9d
	imull	%r11d, %r9d
	movl	%r12d, %ecx
	imull	%esi, %ecx
	addl	%ecx, %r9d
	sarl	$14, %r9d
	movswl	170(%r14), %r8d
	movl	%r11d, %ecx
	imull	%esi, %ecx
	imull	%r8d, %r12d
	addl	%r12d, %ecx
	sarl	$14, %ecx
	addl	%r10d, %ecx
	leal	(%r9,%r9), %r12d
	subl	%r11d, %r12d
	movl	%r12d, 144(%r14)
	leal	(%rcx,%rcx), %r11d
	subl	%r10d, %r11d
	movl	%r11d, 148(%r14)
	subl	%r9d, %edx
	subl	%ecx, %edx
	sall	$2, %edx
	movl	%ebp, %ecx
	sarl	$2, %ecx
	movl	$32767, %r9d
	cmpl	%r9d, %ecx
	cmovg	%r9d, %ecx
	movl	$-32767, %r9d
	cmpl	%r9d, %ecx
	cmovl	%r9d, %ecx
	movl	156(%r14), %r10d
	movl	%ecx, %r9d
	subl	%r10d, %r9d
	movl	152(%r14), %r11d
	imull	%r11d, %edi
	movl	%r9d, %r12d
	imull	%esi, %r12d
	addl	%r12d, %edi
	sarl	$14, %edi
	imull	%r11d, %esi
	imull	%r8d, %r9d
	addl	%r9d, %esi
	sarl	$14, %esi
	addl	%r10d, %esi
	leal	(%rdi,%rdi), %r8d
	subl	%r11d, %r8d
	movl	%r8d, 152(%r14)
	leal	(%rsi,%rsi), %r8d
	subl	%r10d, %r8d
	movl	%r8d, 156(%r14)
	subl	%edi, %ecx
	subl	%esi, %ecx
	sall	$2, %ecx
	cmpl	$32768, %eax
	je	.L3227
	leal	(%rax,%rax), %edi
	subl	%ebx, %edx
	movzwl	%dx, %esi
	imull	%edi, %esi
	shrl	$16, %esi
	sarl	$16, %edx
	imull	%edi, %edx
	addl	%esi, %edx
	addl	%edx, %ebx
	subl	%ebp, %ecx
	movzwl	%cx, %eax
	imull	%edi, %eax
	shrl	$16, %eax
	sarl	$16, %ecx
	imull	%edi, %ecx
	addl	%ecx, %eax
	addl	%eax, %ebp
	jmp	.L3190
.L3227:
	movl	%ecx, %ebp
	movl	%edx, %ebx
	jmp	.L3190
.L3192:
	movl	$0, 196(%r14)
	movl	%ebx, %edx
	movl	36(%rsp), %edi
	movl	%edi, %ecx
	sarl	%cl, %edx
	sall	%cl, %edx
	movl	40(%rsp), %esi
	addl	%esi, %edx
	movl	%edx, 188(%r14)
	movl	%ebp, %edx
	sarl	%cl, %edx
	sall	%cl, %edx
	addl	%esi, %edx
	movl	%edx, 192(%r14)
.L3193:
	movl	188(%r14), %edx
	cmpl	$32768, %eax
	je	.L3194
	addl	%eax, %eax
	subl	%ebx, %edx
	movzwl	%dx, %ecx
	imull	%eax, %ecx
	shrl	$16, %ecx
	sarl	$16, %edx
	imull	%eax, %edx
	addl	%ecx, %edx
	addl	%edx, %ebx
	movl	192(%r14), %edx
	subl	%ebp, %edx
	movzwl	%dx, %ecx
	imull	%eax, %ecx
	shrl	$16, %ecx
	sarl	$16, %edx
	imull	%eax, %edx
	leal	(%rcx,%rdx), %eax
	addl	%eax, %ebp
.L3191:
	movq	(%rsp), %rax
	movl	%ebx, (%rax,%r13,4)
	movq	8(%rsp), %rax
	movl	%ebp, (%rax,%r13,4)
	addq	$1, %r13
	movq	24(%rsp), %rax
	cmpq	%rax, %r13
	je	.L3127
.L3195:
	movq	(%rsp), %rax
	movl	(%rax,%r13,4), %ebx
	movq	8(%rsp), %rax
	movl	(%rax,%r13,4), %ebp
	cmpl	%r13d, 8(%r14)
	je	.L3246
.L3128:
	movzbl	23(%r14), %eax
	testb	%al, %al
	jne	.L3247
.L3129:
	movl	$32768, %eax
	testb	$16, %r15b
	jne	.L3185
	movzbl	perf_k(%rip), %edx
	testb	%dl, %dl
	js	.L3185
	cmpl	$16127, 112(%r14)
	setle	%al
	movzbl	%al, %eax
	sall	$15, %eax
.L3185:
	movl	120(%r14), %edx
	subl	%edx, %eax
	movl	$256, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-256, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	addl	%edx, %eax
	movl	%eax, 120(%r14)
	jne	.L3248
	movl	$0, 140(%r14)
	movl	$0, 136(%r14)
	movl	$0, 132(%r14)
	movl	$0, 128(%r14)
.L3187:
	movl	$32768, %eax
	testb	$32, %r15b
	jne	.L3188
	movzbl	perf_k(%rip), %edx
	testb	%dl, %dl
	jle	.L3249
.L3188:
	movl	124(%r14), %edx
	subl	%edx, %eax
	movl	$256, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-256, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	addl	%edx, %eax
	movl	%eax, 124(%r14)
	jne	.L3250
	movl	$0, 156(%r14)
	movl	$0, 152(%r14)
	movl	$0, 148(%r14)
	movl	$0, 144(%r14)
.L3190:
	movl	180(%r14), %edx
	movl	20(%rsp), %eax
	subl	%edx, %eax
	movl	$256, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-256, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	addl	%edx, %eax
	movl	%eax, 180(%r14)
	je	.L3191
	movl	196(%r14), %edi
	leal	1(%rdi), %edx
	movl	32(%rsp), %edi
	cmpl	%edi, %edx
	jnb	.L3192
	movl	%edx, 196(%r14)
	jmp	.L3193
.L3127:
	movzbl	23+pf(%rip), %ecx
	movl	96+pf(%rip), %eax
	orl	120+pf(%rip), %eax
	orl	124+pf(%rip), %eax
	orl	180+pf(%rip), %eax
	orl	200+pf(%rip), %eax
	movl	$1, %edx
	orl	12+pf(%rip), %eax
	jne	.L3196
	orb	22+pf(%rip), %cl
	jne	.L3196
	movzbl	perf_k(%rip), %eax
	testb	%al, %al
	jne	.L3196
	movzbl	1+perf_k(%rip), %eax
	testb	%al, %al
	jne	.L3196
	movzbl	2+perf_k(%rip), %eax
	testb	%al, %al
	setne	%dl
	movzbl	%dl, %edx
.L3196:
	movb	%dl, 20+pf(%rip)
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3194:
	.cfi_restore_state
	movl	192(%r14), %ebp
	movl	%edx, %ebx
	jmp	.L3191
	.cfi_endproc
.LFE604:
	.size	perf_block, .-perf_block
	.type	slicer_track, @function
slicer_track:
.LFB555:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %r13
	movq	%rsi, -16(%rsp)
	movl	%edx, %r14d
	leaq	trk(%rip), %rdx
	movq	%rdi, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movl	%eax, -8(%rsp)
	movl	$0, %r15d
	testq	%rsi, %rsi
	je	.L3252
	movl	$1, %r15d
	cmpw	$0, 90(%rdi)
	jne	.L3252
	movl	%eax, %edx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	sl(%rip), %rdx
	cmpl	$0, 24(%rdx,%rcx,8)
	jne	.L3252
	leaq	sl(%rip), %rdx
	cmpl	$0, 28(%rdx,%rcx,8)
	setne	%r15b
	movzbl	%r15b, %r15d
.L3252:
	testl	%r14d, %r14d
	je	.L3251
	movswl	song(%rip), %ebx
	movl	%ebx, -24(%rsp)
	movswl	2+song(%rip), %ebx
	movl	%ebx, -20(%rsp)
	movzbl	sl_lent(%rip), %ebx
	movb	%bl, -1(%rsp)
	movl	%eax, %eax
	salq	$13, %rax
	leaq	sl_buf(%rip), %rdx
	leaq	(%rax,%rdx), %r12
	movl	$0, %r8d
	movl	-8(%rsp), %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	sl(%rip), %rax
	leaq	(%rax,%rdx,8), %rbp
	movl	%r14d, %eax
	movl	%r8d, %r14d
	movl	%eax, %r8d
	jmp	.L3277
.L3295:
	movzwl	90(%r13), %r9d
	movzbl	36(%rbp), %eax
	leal	1(%rax), %esi
	movl	%esi, %edi
	andl	$15, %edi
	movb	%dil, 36(%rbp)
	movl	$2646000, %eax
	movl	$0, %edx
	divl	-24(%rsp)
	movswl	94(%r13), %ecx
	movl	%ecx, %edx
	movl	$2863311531, %ebx
	imulq	%rbx, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,2), %edx
	addl	%edx, %edx
	subl	%edx, %ecx
	leaq	SL_DEN(%rip), %rbx
	movzbl	(%rbx,%rcx), %ecx
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %r10d
	movl	%eax, 8(%rbp)
	movswl	62(%r13), %edx
	movl	-20(%rsp), %ebx
	addl	%ebx, %edx
	movl	$100, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	imull	%eax, %edx
	movslq	%edx, %rcx
	imulq	$274877907, %rcx, %rcx
	sarq	$36, %rcx
	sarl	$31, %edx
	movl	%ecx, %r11d
	subl	%edx, %r11d
	subl	%ecx, %edx
	testb	$1, %sil
	cmove	%r11d, %edx
	addl	%eax, %edx
	movl	%edx, 4(%rbp)
	movl	$0, 0(%rbp)
	movswl	92(%r13), %edx
	subl	$1, %edx
	andl	$15, %edx
	leaq	SL_PAT(%rip), %rcx
	movzwl	(%rcx,%rdx,2), %edx
	btl	%edi, %edx
	setc	%dl
	movb	%dl, 37(%rbp)
	movl	$0, 12(%rbp)
	movl	$0, 16(%rbp)
	movb	$0, 38(%rbp)
	cmpw	$2, %r9w
	je	.L3293
.L3257:
	movl	$0, 20(%rbp)
	jmp	.L3254
.L3293:
	cmpb	$0, -1(%rsp)
	jne	.L3257
	testb	%dl, %dl
	je	.L3259
	leaq	sl(%rip), %rcx
	movl	-8(%rsp), %edx
	leaq	0(,%rdx,4), %rax
	leaq	(%rax,%rdx), %rsi
	movl	$0, 20(%rcx,%rsi,8)
	movb	$1, 38(%rcx,%rsi,8)
	jmp	.L3254
.L3259:
	movl	-8(%rsp), %edx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	sl(%rip), %rdx
	movl	20(%rdx,%rcx,8), %edx
	cmpl	$255, %edx
	jbe	.L3254
	cmpl	$8192, %eax
	jbe	.L3260
.L3261:
	shrl	%r10d
	cmpl	$8192, %r10d
	ja	.L3261
.L3260:
	movl	-8(%rsp), %eax
	leaq	(%rax,%rax,4), %rax
	addl	%edx, %edx
	cmpl	%r10d, %edx
	cmova	%r10d, %edx
	leaq	sl(%rip), %rcx
	movl	%edx, 16(%rcx,%rax,8)
	jmp	.L3254
.L3296:
	cmpb	$0, 37(%rbp)
	movl	$0, %ebx
	cmove	%r11d, %ebx
	movl	%ebx, -60(%rsp)
	movzwl	%dx, %edx
	leal	1(%rcx), %ecx
	andl	$15, %ecx
	shrl	%cl, %edx
	testb	$1, %dl
	movl	$0, %ebx
	cmovne	%ebx, %r11d
	movl	$0, %edi
.L3265:
	testl	%r9d, %r9d
	je	.L3262
	movl	%r9d, %ebx
	movq	-16(%rsp), %rsi
	leaq	(%rsi,%rax,4), %r10
	movl	$0, %esi
	movl	-60(%rsp), %eax
	movl	%eax, -52(%rsp)
	movl	%r11d, -56(%rsp)
	movl	%r15d, -48(%rsp)
	movl	%r9d, -44(%rsp)
	movl	%r14d, -32(%rsp)
	movl	%edi, %r9d
	movq	%r13, -40(%rsp)
	movl	%r8d, -28(%rsp)
	jmp	.L3276
.L3297:
	movl	-8(%rsp), %edx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	sl(%rip), %rdx
	cmpl	$0, 16(%rdx,%rcx,8)
	jne	.L3284
	movl	$0, -60(%rsp)
	movl	$0, %r11d
	movl	$0, %edi
	jmp	.L3265
.L3284:
	movl	%r11d, %edi
	movl	$0, -60(%rsp)
	movl	$0, %r11d
	jmp	.L3265
.L3270:
	movl	%edi, 32(%rbp)
.L3269:
	movl	16(%rbp), %r14d
	testl	%r14d, %r14d
	je	.L3271
	movl	12(%rbp), %r8d
	leal	-1(%r14), %edi
	subl	%r8d, %edi
	movl	%r8d, %r15d
	shrl	%r15d
	movl	%r15d, %eax
	movswl	(%r12,%rax,2), %eax
	testb	$1, %r8b
	je	.L3272
	addl	$1, %r15d
	andl	$4095, %r15d
	movswl	(%r12,%r15,2), %r15d
	addl	%eax, %r15d
	movl	%r15d, %eax
	sarl	%eax
.L3272:
	sall	$2, %eax
	cmpl	%edi, %r8d
	cmovbe	%r8d, %edi
	subl	$1, %ecx
	cmpl	%ecx, %edi
	cmova	%ecx, %edi
	cmpl	$127, %edi
	ja	.L3273
	imull	%eax, %edi
	movl	%edi, %eax
	sarl	$7, %eax
.L3273:
	addl	$1, %r8d
	movl	%r8d, 12(%rbp)
	movl	$0, %ecx
	cmpl	%r14d, %r8d
	jnb	.L3274
	movl	%r8d, %ecx
.L3274:
	movl	%ecx, 12(%rbp)
	subl	%r13d, %eax
	addl	%edx, %edx
	movzwl	%ax, %ecx
	imull	%edx, %ecx
	shrl	$16, %ecx
	sarl	$16, %eax
	imull	%edx, %eax
	addl	%eax, %ecx
	addl	%ecx, %r13d
.L3275:
	movl	%r13d, (%r10,%rsi,4)
	addq	$1, %rsi
	cmpq	%rbx, %rsi
	je	.L3294
.L3276:
	movl	%esi, %r14d
	movl	(%r10,%rsi,4), %edi
	movl	0(%rbp), %r8d
	movl	4(%rbp), %ecx
	subl	%r8d, %ecx
	subl	%esi, %ecx
	cmpl	$128, %ecx
	ja	.L3288
	movl	-56(%rsp), %eax
	cmpl	%r11d, -60(%rsp)
	jl	.L3266
.L3288:
	movl	-52(%rsp), %eax
.L3266:
	movl	24(%rbp), %edx
	subl	%edx, %eax
	movl	$256, %r13d
	cmpl	%r13d, %eax
	cmovg	%r13d, %eax
	movl	$-256, %r13d
	cmpl	%r13d, %eax
	cmovl	%r13d, %eax
	addl	%edx, %eax
	movl	%eax, 24(%rbp)
	movl	28(%rbp), %r13d
	movl	%r9d, %edx
	subl	%r13d, %edx
	movl	$256, %r15d
	cmpl	%r15d, %edx
	cmovg	%r15d, %edx
	movl	$-256, %r15d
	cmpl	%r15d, %edx
	cmovl	%r15d, %edx
	addl	%r13d, %edx
	movl	%edx, 28(%rbp)
	movl	%edi, %r13d
	testl	%eax, %eax
	je	.L3268
	addl	%eax, %eax
	movzwl	%di, %r15d
	imull	%eax, %r15d
	shrl	$16, %r15d
	sarl	$16, %r13d
	imull	%eax, %r13d
	leal	(%r15,%r13), %eax
	movl	%edi, %r13d
	subl	%eax, %r13d
.L3268:
	cmpb	$0, 38(%rbp)
	je	.L3269
	addl	%r14d, %r8d
	testb	$1, %r8b
	je	.L3270
	movl	20(%rbp), %r14d
	movl	%r14d, %eax
	addl	32(%rbp), %edi
	sarl	$3, %edi
	movl	$32767, %r8d
	cmpl	%r8d, %edi
	cmovg	%r8d, %edi
	movl	$-32768, %r8d
	cmpl	%r8d, %edi
	cmovl	%r8d, %edi
	movw	%di, (%r12,%rax,2)
	leal	1(%r14), %eax
	movl	%eax, 20(%rbp)
	cmpl	$4095, %eax
	jbe	.L3269
	movb	$0, 38(%rbp)
	jmp	.L3269
.L3271:
	testl	%edx, %edx
	je	.L3275
	addl	%edx, %edx
	movzwl	%r13w, %eax
	imull	%edx, %eax
	shrl	$16, %eax
	movl	%r13d, %ecx
	sarl	$16, %ecx
	imull	%edx, %ecx
	addl	%ecx, %eax
	subl	%eax, %r13d
	jmp	.L3275
.L3294:
	movl	-48(%rsp), %r15d
	movl	-44(%rsp), %r9d
	movl	-32(%rsp), %r14d
	movq	-40(%rsp), %r13
	movl	-28(%rsp), %r8d
.L3262:
	addl	%r9d, 0(%rbp)
	addl	%r9d, %r14d
	cmpl	%r8d, %r14d
	jnb	.L3251
.L3277:
	movl	4(%rbp), %eax
	cmpl	%eax, 0(%rbp)
	jnb	.L3295
.L3254:
	movl	4(%rbp), %r9d
	subl	0(%rbp), %r9d
	movl	%r8d, %eax
	subl	%r14d, %eax
	cmpl	%eax, %r9d
	cmova	%eax, %r9d
	testl	%r15d, %r15d
	je	.L3262
	movl	%r14d, %eax
	movswl	90(%r13), %esi
	movswl	92(%r13), %edx
	subl	$1, %edx
	andl	$15, %edx
	leaq	SL_PAT(%rip), %rcx
	movzwl	(%rcx,%rdx,2), %edx
	movzbl	36(%rbp), %ecx
	movswl	96(%r13), %r11d
	imull	$258, %r11d, %r11d
	cmpl	$1, %esi
	je	.L3296
	cmpl	$2, %esi
	je	.L3297
	movl	$0, -60(%rsp)
	movl	$0, %r11d
	movl	$0, %edi
	jmp	.L3265
.L3251:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE555:
	.size	slicer_track, .-slicer_track
	.type	cr_chord_omit_tone, @function
cr_chord_omit_tone:
.LFB905:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movl	%edi, %eax
	movl	%edi, 16(%rsp)
	movl	%esi, 12(%rsp)
	movl	$0, %edi
	cmpl	$2, %eax
	ja	.L3298
	movl	%eax, %eax
	imulq	$2464, %rax, %rax
	leaq	trk(%rip), %rdx
	movzbl	184(%rdx,%rax), %esi
	movb	%sil, 33(%rsp)
	leal	-14(%rsi), %eax
	testb	$-3, %al
	je	.L3300
	leal	-21(%rsi), %eax
	cmpb	$5, %al
	ja	.L3298
.L3300:
	movl	16(%rsp), %eax
	imulq	$2464, %rax, %rax
	movl	$0, %edi
	leaq	trk(%rip), %rdx
	cmpw	$0, 74(%rdx,%rax)
	jne	.L3298
	cmpb	$0, 16+cr(%rip)
	je	.L3301
	cmpb	$1, 17+cr(%rip)
	ja	.L3298
.L3301:
	movzbl	33(%rsp), %eax
	movl	%eax, 36(%rsp)
	leaq	cr(%rip), %r13
	movl	$0, %edi
	movl	$2863311531, %r15d
	jmp	.L3332
.L3376:
	cmpl	$21, 36(%rsp)
	je	.L3304
	testb	%al, %al
	jne	.L3304
.L3305:
	movzbl	779(%rbp), %esi
	testl	%esi, %esi
	je	.L3352
	movl	$0, %ecx
	movl	$0, %edi
	movl	$0, %r9d
	movl	$12, %r8d
	subl	%r12d, %r8d
	jmp	.L3327
.L3372:
	cmpb	$0, morph_dual(%rip)
	je	.L3311
	movzbl	182+trk(%rip), %eax
	cmpl	$1, 16(%rsp)
	je	.L3368
	cmpb	$19, %al
	sete	%al
	movzbl	%al, %eax
	cmpl	$2, 16(%rsp)
	jne	.L3369
.L3337:
	cmpb	$19, 182+trk(%rip)
	sete	%dl
	movzbl	%dl, %edx
	jmp	.L3314
.L3315:
	addl	%edx, %ebx
	addq	$84, %rax
	cmpq	%r14, %rax
	je	.L3370
.L3316:
	movl	%r13d, %edx
	cmpb	$0, 1(%rax)
	je	.L3315
	cmpb	$0, (%rax)
	je	.L3315
	cmpb	$4, 2(%rax)
	setne	%dl
	movzbl	%dl, %edx
	jmp	.L3315
.L3370:
	movzbl	1+cr_route(%rip), %eax
	movzbl	%al, %eax
	cmpl	%ebp, %eax
	je	.L3371
.L3317:
	leaq	-1534(%r14), %rdi
	call	voice_units
	imull	%eax, %ebx
	addl	%ebx, 28(%rsp)
.L3307:
	addl	$1, %ebp
	cmpl	$3, %ebp
	je	.L3364
	addq	$2464, %r14
.L3319:
	cmpl	%ebp, 16(%rsp)
	je	.L3307
	cmpb	$1, cr_dbg(%rip)
	jne	.L3308
	cmpl	$1, %ebp
	je	.L3309
	cmpl	$2, %ebp
	je	.L3372
	cmpl	$1, 16(%rsp)
	je	.L3373
.L3340:
	movl	$0, %eax
	cmpl	$2, 16(%rsp)
	jne	.L3308
.L3336:
	movl	$0, %edx
	cmpb	$0, morph_dual(%rip)
	jne	.L3337
.L3314:
	cmpl	%eax, %edx
	jne	.L3307
.L3308:
	leaq	-1344(%r14), %rax
	movl	$0, %ebx
	jmp	.L3316
.L3371:
	cmpb	$0, 10+cr(%rip)
	je	.L3317
	cmpb	$0, 23+cr(%rip)
	je	.L3317
	testl	%ebx, %ebx
	movl	$1, %eax
	cmove	%eax, %ebx
	jmp	.L3317
.L3364:
	movq	40(%rsp), %rbx
	movq	48(%rsp), %rbp
.L3318:
	movl	$1, %eax
	movl	28(%rsp), %edi
	cmpl	$15, %edi
	ja	.L3320
	movl	$16, %eax
	subl	%edi, %eax
	movl	$3, %ecx
	movzbl	33(%rsp), %edi
	cmpb	$16, %dil
	je	.L3321
	leal	-21(%rdi), %edx
	cmpb	$6, %dl
	setb	%cl
	movzbl	%cl, %ecx
	addl	$2, %ecx
.L3321:
	movl	$0, %edx
	divl	%ecx
.L3320:
	cmpb	$0, 34(%rsp)
	je	.L3322
	cmpl	$21, 36(%rsp)
	sete	%dl
	movzbl	%dl, %edx
	leal	2(%rax,%rdx), %eax
.L3324:
	cmpl	%eax, 20(%rsp)
	jb	.L3305
.L3325:
	testl	%eax, %eax
	movl	$1, %edx
	cmovne	%eax, %edx
	movl	%edx, 20(%rsp)
	jmp	.L3305
.L3322:
	cmpb	$1, 35(%rsp)
	je	.L3324
	leaq	cr(%rip), %rdi
	cmpb	$0, 10(%rdi)
	je	.L3324
	cmpb	$0, 23+cr(%rip)
	je	.L3324
	movzbl	1+cr_route(%rip), %edx
	cmpb	$2, %dl
	ja	.L3324
	movzbl	1+cr_route(%rip), %edx
	movzbl	%dl, %edx
	movl	16(%rsp), %edi
	cmpl	%edi, %edx
	je	.L3324
	movl	$4, %edx
	cmpl	%edx, %eax
	cmova	%edx, %eax
	jmp	.L3325
.L3353:
	movl	$1, %r9d
.L3326:
	addq	$1, %rcx
	cmpl	%esi, %ecx
	jnb	.L3374
.L3327:
	movzbl	780(%rbp,%rcx), %edx
	addl	%r8d, %edx
	movl	%edx, %eax
	imulq	%r15, %rax
	shrq	$35, %rax
	leal	(%rax,%rax,2), %r10d
	sall	$2, %r10d
	movl	%edx, %eax
	subl	%r10d, %eax
	leal	-10(%rax), %edx
	cmpl	$1, %edx
	jbe	.L3353
	cmpl	$9, %eax
	movl	$1, %eax
	cmove	%eax, %edi
	jmp	.L3326
.L3374:
	movl	20(%rsp), %eax
	cmpl	%esi, %eax
	jnb	.L3355
	subl	%eax, %esi
	testl	%edi, %edi
	je	.L3328
	cmpl	$9, 24(%rsp)
	sete	%dil
	movzbl	%dil, %edi
	subl	$1, %esi
	je	.L3329
	testl	%r9d, %r9d
	je	.L3329
.L3333:
	movl	24(%rsp), %eax
	subl	$10, %eax
	cmpl	$1, %eax
	setbe	%al
	movzbl	%al, %eax
	orl	%eax, %edi
	subl	$1, %esi
.L3329:
	testl	%esi, %esi
	jne	.L3334
.L3330:
	testl	%edi, %edi
	je	.L3298
.L3303:
	addq	$1, %rbx
	movzbl	779(%rbp), %eax
	cmpl	%eax, %ebx
	jnb	.L3375
.L3331:
	movzbl	780(%rbp,%rbx), %eax
	movl	12(%rsp), %esi
	cmpl	%esi, %eax
	jne	.L3303
	movswl	768(%rbp), %edx
	movsbl	763(%rbp), %eax
	leal	1200(%rdx,%rax), %edx
	movl	%edx, %eax
	imulq	%r15, %rax
	shrq	$35, %rax
	leal	(%rax,%rax,2), %eax
	sall	$2, %eax
	subl	%eax, %edx
	movl	%edx, %r12d
	movl	%esi, %eax
	addl	$12, %eax
	subl	%edx, %eax
	movl	%eax, %edx
	imulq	%r15, %rdx
	shrq	$35, %rdx
	leal	(%rdx,%rdx,2), %edx
	sall	$2, %edx
	subl	%edx, %eax
	movl	%eax, 24(%rsp)
	movzbl	cr_dbg(%rip), %eax
	movb	%al, 35(%rsp)
	cmpb	$1, %al
	sete	%al
	cmpl	$0, 16(%rsp)
	sete	%dl
	andl	%eax, %edx
	movb	%dl, 34(%rsp)
	movzbl	%dl, %edx
	leal	5(%rdx), %edi
	movl	%edi, 20(%rsp)
	movzbl	33(%rsp), %edi
	cmpb	$16, %dil
	je	.L3304
	leal	-22(%rdi), %edx
	cmpb	$4, %dl
	ja	.L3376
.L3304:
	leaq	1534+trk(%rip), %r14
	movl	$0, %eax
	movl	$0, 28(%rsp)
	movl	$0, %r13d
	movq	%rbx, 40(%rsp)
	movq	%rbp, 48(%rsp)
	movl	%eax, %ebp
	jmp	.L3319
.L3375:
	movq	56(%rsp), %r13
.L3302:
	addq	$172, %r13
	leaq	5504+cr(%rip), %rax
	cmpq	%rax, %r13
	je	.L3298
.L3332:
	movq	%r13, %rbp
	cmpb	$0, 752(%r13)
	je	.L3302
	cmpb	$0, 767(%r13)
	je	.L3302
	cmpb	$0, 779(%r13)
	je	.L3302
	movl	$0, %ebx
	movq	%r13, 56(%rsp)
	jmp	.L3331
.L3352:
	movl	$0, %edi
.L3298:
	movl	%edi, %eax
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3355:
	.cfi_restore_state
	movl	$0, %edi
	jmp	.L3298
.L3328:
	testl	%r9d, %r9d
	jne	.L3333
	movl	%r9d, %edi
.L3334:
	cmpl	$7, 24(%rsp)
	sete	%al
	movzbl	%al, %eax
	orl	%eax, %edi
	jmp	.L3330
.L3309:
	cmpl	$1, 16(%rsp)
	je	.L3308
	cmpl	$2, 16(%rsp)
	jne	.L3307
	movl	$1, %eax
	jmp	.L3336
.L3368:
	cmpb	$19, %al
	je	.L3308
	movq	40(%rsp), %rbx
	movq	48(%rsp), %rbp
	jmp	.L3318
.L3369:
	movl	$0, %edx
	jmp	.L3314
.L3373:
	addl	$1, %ebp
	addq	$2464, %r14
	jmp	.L3319
.L3311:
	cmpl	$1, 16(%rsp)
	jne	.L3340
	movq	40(%rsp), %rbx
	movq	48(%rsp), %rbp
	jmp	.L3318
	.cfi_endproc
.LFE905:
	.size	cr_chord_omit_tone, .-cr_chord_omit_tone
	.type	voices_busy_of, @function
voices_busy_of:
.LFB522:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	movq	%rdi, 8(%rsp)
	movl	%edi, %r15d
	leaq	1535+trk(%rip), %rbp
	movl	$0, %r14d
	movl	$0, %r13d
	movl	$0, %r12d
	jmp	.L3392
.L3412:
	cmpb	$0, morph_dual(%rip)
	je	.L3380
	cmpb	$19, 182+trk(%rip)
	sete	%dl
	movzbl	%dl, %edx
	movl	$1, %eax
	cmpl	$1, %r15d
	je	.L3381
	movl	$0, %eax
	cmpl	$2, %r15d
	jne	.L3381
.L3397:
	cmpb	$19, 182+trk(%rip)
	sete	%al
	movzbl	%al, %eax
	jmp	.L3381
.L3413:
	movl	$0, %edx
.L3398:
	movl	$0, %eax
	cmpb	$0, morph_dual(%rip)
	jne	.L3397
.L3381:
	cmpl	%edx, %eax
	jne	.L3383
	jmp	.L3378
.L3384:
	addl	%edx, %ebx
	addq	$84, %rax
	cmpq	%rbp, %rax
	je	.L3410
.L3385:
	movl	%r12d, %edx
	cmpb	$0, (%rax)
	je	.L3384
	cmpb	$4, 1(%rax)
	setne	%dl
	movzbl	%dl, %edx
	jmp	.L3384
.L3410:
	leaq	-1535(%rbp), %rdi
	call	voice_units
	imull	%ebx, %eax
	addl	%eax, %r14d
	testl	%r13d, %r13d
	je	.L3411
.L3383:
	addl	$1, %r13d
	cmpl	$3, %r13d
	je	.L3391
	addq	$2464, %rbp
.L3392:
	cmpb	$1, cr_dbg(%rip)
	jne	.L3378
	cmpl	$1, %r13d
	je	.L3379
	cmpl	$2, %r13d
	je	.L3412
.L3380:
	cmpl	$1, %r15d
	je	.L3383
	cmpl	$2, %r15d
	je	.L3413
.L3378:
	leaq	-1344(%rbp), %rax
	movl	$0, %ebx
	jmp	.L3385
.L3411:
	call	chord_cpu1_reserve
	testl	%eax, %eax
	je	.L3386
	movzbl	182+trk(%rip), %eax
	cmpb	$24, %al
	ja	.L3387
	movl	$25247744, %edx
	btq	%rax, %rdx
	jc	.L3388
.L3389:
	movl	$912261120, %edx
	btq	%rax, %rdx
	jnc	.L3386
.L3388:
	cmpb	$21, %al
	sete	%al
	movzbl	%al, %eax
	addl	$2, %eax
	cmpl	%eax, %ebx
	cmova	%eax, %ebx
	leaq	trk(%rip), %rdi
	call	voice_units
	imull	%ebx, %eax
	subl	%eax, %r14d
.L3386:
	addl	$1, %r13d
	addq	$2464, %rbp
	jmp	.L3392
.L3387:
	cmpb	$29, %al
	ja	.L3386
	jmp	.L3389
.L3391:
	cmpl	$1, 8(%rsp)
	je	.L3414
.L3377:
	movl	%r14d, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3414:
	.cfi_restore_state
	call	chord_cpu1_reserve
	addl	%eax, %r14d
	jmp	.L3377
.L3379:
	cmpl	$1, %r15d
	je	.L3378
	cmpl	$2, %r15d
	jne	.L3383
	movl	$1, %edx
	jmp	.L3398
	.cfi_endproc
.LFE522:
	.size	voices_busy_of, .-voices_busy_of
	.type	voice_room, @function
voice_room:
.LFB532:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movq	%fs:40, %rax
	movq	%rax, 8(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %r12
	jmp	.L3416
.L3417:
	movl	%eax, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rdx
	movq	(%rsp), %rax
	leaq	188(%rax,%rdx,4), %rdi
	call	voice_kill
.L3416:
	movq	%rbx, %rdi
	call	voices_busy_of
	movl	%eax, %r13d
	movq	%rbx, %rdi
	call	voice_units
	addl	%eax, %r13d
	cmpl	$16, %r13d
	jbe	.L3422
	movq	$0, (%rsp)
	movq	%r12, %rdx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	voice_victim
	cmpl	$16, %eax
	jne	.L3417
	testl	%ebp, %ebp
	sete	%al
	movzbl	%al, %eax
	jmp	.L3415
.L3422:
	movl	$1, %eax
.L3415:
	movq	8(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L3423
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L3423:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE532:
	.size	voice_room, .-voice_room
	.type	mono_play, @function
mono_play:
.LFB539:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %r13
	movl	%esi, 8(%rsp)
	movl	%edx, 24(%rsp)
	movl	%ecx, 12(%rsp)
	movl	%r8d, 16(%rsp)
	call	trk_vmode
	movl	$1, %ebp
	cmpl	$3, %eax
	je	.L3447
.L3425:
	movl	8(%rsp), %eax
	sall	$4, %eax
	movl	%eax, 28(%rsp)
	leaq	188(%r13), %r15
	movl	$1, %r14d
	subl	%ebp, %r14d
	movl	24(%rsp), %ecx
	leal	(%rcx,%rcx,8), %eax
	leal	0(,%rax,4), %eax
	imulq	$1374389535, %rax, %rax
	shrq	$37, %rax
	shrl	%ecx
	movl	%ecx, %edx
	cmpl	$7, %ebp
	cmova	%eax, %edx
	movl	%edx, 20(%rsp)
	movl	$0, %r12d
	jmp	.L3440
.L3447:
	movq	%r13, %rdi
	call	trk_nvoice
	movl	%eax, %ebp
	testl	%eax, %eax
	jne	.L3425
.L3426:
	movzbl	8(%rsp), %eax
	movb	%al, 2363(%r13)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3427:
	.cfi_restore_state
	movl	$0, %edx
	cmpl	$1, %ebp
	jbe	.L3429
	movl	%r14d, %eax
	jmp	.L3428
.L3430:
	cmpb	$0, 3(%rbx)
	je	.L3431
.L3432:
	cmpb	$4, 4(%rbx)
	je	.L3431
.L3434:
	cmpl	$1, %ebp
	jbe	.L3436
	movl	16(%rsp), %r8d
	movl	20(%rsp), %ecx
	movl	8(%rsp), %edx
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	voice_start
	testl	%r12d, %r12d
	je	.L3437
	movq	%r13, %rdi
	call	eng_audio
	cmpb	$0, 294(%rax)
	jne	.L3435
	imull	$1664525, unison_seed(%rip), %eax
	addl	$1013904223, %eax
	movl	%eax, unison_seed(%rip)
	addl	%eax, 32(%rbx)
.L3435:
	addl	$1, %r12d
	addq	$84, %r15
	addl	$2, %r14d
	cmpl	%ebp, %r12d
	je	.L3426
.L3440:
	movq	%r15, %rbx
	cmpl	$1, %ebp
	jbe	.L3427
	cmpl	$8, %ebp
	je	.L3427
	leal	0(,%r14,8), %eax
	subl	%r14d, %eax
	leal	-1(%rbp), %ecx
	cltd
	idivl	%ecx
.L3428:
	movswl	88(%r13), %edx
	imull	%eax, %edx
	imull	$56, %edx, %eax
	movslq	%eax, %rdx
	imulq	$618397991, %rdx, %rdx
	sarq	$39, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
.L3429:
	movl	%edx, 28(%rbx)
	cmpl	$0, 12(%rsp)
	jne	.L3430
	cmpb	$0, 3(%rbx)
	je	.L3431
	cmpb	$0, 2(%rbx)
	je	.L3432
	movzbl	8(%rsp), %eax
	movb	%al, (%rbx)
	movl	28(%rsp), %eax
	movl	%eax, 16(%rbx)
	movzbl	2444(%r13), %eax
	movb	%al, 80(%rbx)
	movzwl	2448(%r13), %eax
	movw	%ax, 82(%rbx)
	movzbl	1(%rbx), %eax
	movl	24(%rsp), %edi
	cmpl	%edi, %eax
	jnb	.L3438
	cmpl	$1, %ebp
	je	.L3448
.L3438:
	movl	16(%rsp), %edx
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	glide_set
	movq	%r13, %rdi
	call	eng_audio
	movq	392(%rax), %rax
	testq	%rax, %rax
	je	.L3435
.L3439:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	*%rax
	jmp	.L3435
.L3431:
	testl	%r12d, %r12d
	setne	%sil
	movzbl	%sil, %esi
	movq	%r13, %rdi
	call	voice_room
	testl	%eax, %eax
	jne	.L3434
	jmp	.L3435
.L3448:
	movzbl	24(%rsp), %eax
	movb	%al, 1(%rbx)
	movl	16(%rsp), %edx
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	glide_set
	movq	%r13, %rdi
	call	eng_audio
	movq	392(%rax), %rax
	testq	%rax, %rax
	jne	.L3439
	jmp	.L3426
.L3436:
	movl	16(%rsp), %r8d
	movl	24(%rsp), %ecx
	movl	8(%rsp), %edx
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	voice_start
	jmp	.L3435
.L3437:
	addl	$1, %r12d
	addq	$84, %r15
	addl	$2, %r14d
	jmp	.L3440
	.cfi_endproc
.LFE539:
	.size	mono_play, .-mono_play
	.type	trk_note_off, @function
trk_note_off:
.LFB544:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movl	%esi, %ebp
	leaq	trk(%rip), %rax
	cmpq	%rax, %rdi
	je	.L3469
.L3450:
	movq	%rbx, %rdi
	call	trk_vmode
	movl	%eax, %r12d
	movzbl	2408(%rbx), %eax
	movzbl	%al, %edx
	testb	%al, %al
	je	.L3463
	leaq	2409(%rbx), %rax
	leal	-1(%rdx), %edx
	leaq	2410(%rbx,%rdx), %rdi
	movl	$0, %ecx
	jmp	.L3453
.L3469:
	cmpb	$19, 182+trk(%rip)
	jne	.L3450
	cmpb	$0, morph_dual(%rip)
	je	.L3450
	leaq	4928(%rax), %rdi
	call	trk_note_off
	jmp	.L3450
.L3452:
	addq	$1, %rax
	cmpq	%rdi, %rax
	je	.L3451
.L3453:
	movzbl	(%rax), %edx
	movzbl	%dl, %esi
	cmpl	%ebp, %esi
	je	.L3452
	movl	%ecx, %esi
	movb	%dl, 2409(%rbx,%rsi)
	movzbl	16(%rax), %edx
	movb	%dl, 2425(%rbx,%rsi)
	leal	1(%rcx), %ecx
	jmp	.L3452
.L3463:
	movl	$0, %ecx
.L3451:
	movb	%cl, 2408(%rbx)
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	vsq_drop
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	mono_remove
	testl	%r12d, %r12d
	je	.L3454
	movl	$1, %r13d
	cmpl	$3, %r12d
	je	.L3470
.L3455:
	movzbl	2363(%rbx), %eax
	cmpl	%ebp, %eax
	je	.L3471
.L3454:
	leaq	188(%rbx), %rax
	addq	$1532, %rbx
	jmp	.L3462
.L3470:
	movq	%rbx, %rdi
	call	trk_nvoice
	movl	%eax, %r13d
	jmp	.L3455
.L3471:
	movq	%rbx, %rdi
	call	mono_pick
	testl	%eax, %eax
	jne	.L3456
	testl	%r13d, %r13d
	je	.L3458
	movq	%rbx, %rax
	movl	%r13d, %r13d
	leaq	0(%r13,%r13,4), %rdx
	leaq	0(%r13,%rdx,4), %rdx
	leaq	(%rbx,%rdx,4), %rdx
	jmp	.L3460
.L3456:
	cmpw	$0, 76(%rbx)
	movzbl	189(%rbx), %edx
	setne	%r8b
	movzbl	%r8b, %r8d
	movl	$0, %ecx
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	mono_play
	jmp	.L3454
.L3459:
	addq	$84, %rax
	cmpq	%rdx, %rax
	je	.L3458
.L3460:
	cmpb	$0, 190(%rax)
	je	.L3459
	movb	$0, 190(%rax)
	movb	$3, 192(%rax)
	jmp	.L3459
.L3458:
	movb	$0, 2363(%rbx)
	jmp	.L3454
.L3461:
	addq	$84, %rax
	cmpq	%rbx, %rax
	je	.L3472
.L3462:
	movzbl	(%rax), %edx
	cmpl	%ebp, %edx
	jne	.L3461
	cmpb	$0, 2(%rax)
	je	.L3461
	movb	$0, 2(%rax)
	movb	$3, 4(%rax)
	jmp	.L3461
.L3472:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE544:
	.size	trk_note_off, .-trk_note_off
	.type	cr_mrelease, @function
cr_mrelease:
.LFB895:
	.cfi_startproc
	movl	%esi, %ecx
	movl	%edi, %edx
	salq	$7, %rdx
	leaq	cr_mnote(%rip), %rax
	addq	%rdx, %rax
	cmpb	$0, (%rax,%rcx)
	je	.L3477
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	%esi, %eax
	movl	%edi, %ecx
	movq	%rdx, %r8
	leaq	cr_mnote(%rip), %rdx
	addq	%r8, %rdx
	movb	$0, (%rdx,%rax)
	leaq	cr_mheld(%rip), %rax
	movzbl	(%rax,%rcx), %eax
	testb	%al, %al
	je	.L3475
	movl	%edi, %edx
	subl	$1, %eax
	leaq	cr_mheld(%rip), %rcx
	movb	%al, (%rcx,%rdx)
.L3475:
	movl	%edi, %edi
	imulq	$2464, %rdi, %rdi
	leaq	trk(%rip), %rax
	addq	%rax, %rdi
	call	trk_note_off
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
.L3477:
	ret
	.cfi_endproc
.LFE895:
	.size	cr_mrelease, .-cr_mrelease
	.type	cr_mpedal_up, @function
cr_mpedal_up:
.LFB896:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	%edi, %r12d
	call	cr_mchan
	movb	$0, 2(%rax)
	movl	%r12d, %ebp
	salq	$7, %rbp
	leaq	cr_mnote(%rip), %rax
	addq	%rax, %rbp
	movl	$0, %ebx
	jmp	.L3482
.L3481:
	addq	$1, %rbx
	cmpq	$128, %rbx
	je	.L3485
.L3482:
	cmpb	$0, 0(%rbp,%rbx)
	jns	.L3481
	movl	%ebx, %esi
	movl	%r12d, %edi
	call	cr_mrelease
	jmp	.L3481
.L3485:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE896:
	.size	cr_mpedal_up, .-cr_mpedal_up
	.type	cr_cb_note_off, @function
cr_cb_note_off:
.LFB908:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movl	%esi, %ebx
	movl	%edx, %ebp
	andl	$127, %ebp
	testl	%esi, %esi
	jne	.L3487
	movq	%rbp, %rax
	andl	$127, %eax
	leaq	cr_rosen_notes(%rip), %rdx
	movb	$0, (%rdx,%rax)
	leaq	cr_chord_skipped(%rip), %rdx
	movb	$0, (%rdx,%rax)
.L3487:
	movzbl	%bpl, %r13d
	movq	%rbp, %rcx
	andl	$127, %ecx
	movl	%ebx, %edx
	salq	$7, %rdx
	leaq	cr_ono(%rip), %rax
	addq	%rdx, %rax
	movzbl	(%rax,%rcx), %eax
	shrb	$5, %al
	jne	.L3491
.L3488:
	movslq	%r13d, %rax
	movl	%ebx, %ecx
	salq	$7, %rcx
	leaq	cr_ono(%rip), %rdx
	addq	%rcx, %rdx
	movzbl	(%rdx,%rax), %r12d
	movl	%r12d, %edi
	andl	$31, %edi
	jne	.L3492
.L3486:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L3491:
	.cfi_restore_state
	movzbl	%al, %eax
	leal	-1(%rax), %r12d
	movl	%r12d, %edi
	leaq	cr_tr(%rip), %rax
	movsbl	(%rax,%rdi), %esi
	addl	%r13d, %esi
	movl	$127, %eax
	cmpl	%eax, %esi
	cmovg	%eax, %esi
	testl	%esi, %esi
	movl	$0, %eax
	cmovs	%eax, %esi
	imulq	$2464, %rdi, %rdi
	leaq	trk(%rip), %rax
	addq	%rax, %rdi
	call	trk_note_off
	movl	%r12d, %edi
	call	cr_tr_end
	movslq	%r13d, %rax
	movl	%ebx, %ecx
	salq	$7, %rcx
	leaq	cr_ono(%rip), %rdx
	addq	%rcx, %rdx
	andb	$31, (%rdx,%rax)
	jmp	.L3488
.L3492:
	movzbl	%bpl, %esi
	movzbl	%dil, %edi
	subl	$1, %edi
	orb	$-128, %dil
	movl	$0, %edx
	call	cr_midi
	movslq	%r13d, %r13
	movl	%ebx, %ebx
	salq	$7, %rbx
	leaq	cr_ono(%rip), %rax
	addq	%rbx, %rax
	andl	$-32, %r12d
	movb	%r12b, (%rax,%r13)
	jmp	.L3486
	.cfi_endproc
.LFE908:
	.size	cr_cb_note_off, .-cr_cb_note_off
	.type	trk_note_on_inner, @function
trk_note_on_inner:
.LFB542:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	cmpw	$0, 80(%rdi)
	jne	.L3493
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movl	%edx, %r12d
	call	trk_vmode
	movl	%eax, 4(%rsp)
	cmpb	$0, 2390(%rbx)
	jne	.L3495
	movzbl	182(%rbx), %eax
	cmpb	%al, 184(%rbx)
	je	.L3609
.L3495:
	movzbl	2408(%rbx), %edi
	movzbl	%dil, %esi
	testl	%esi, %esi
	je	.L3576
	leaq	2409(%rbx), %rdx
	movl	$0, %eax
.L3497:
	movzbl	(%rdx), %ecx
	cmpl	%ebp, %ecx
	je	.L3610
	addl	$1, %eax
	addq	$1, %rdx
	cmpl	%esi, %eax
	jne	.L3497
	cmpb	$15, %dil
	jbe	.L3499
	movzbl	2408(%rbx), %edx
.L3572:
	leal	-1(%rdx), %eax
.L3502:
	movl	%eax, %eax
	movb	%bpl, 2409(%rbx,%rax)
	movb	%r12b, 2425(%rbx,%rax)
.L3493:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3611
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3610:
	.cfi_restore_state
	cmpl	%eax, %esi
	jne	.L3501
	movl	%eax, %esi
	cmpb	$15, %dil
	jbe	.L3499
.L3501:
	movzbl	2408(%rbx), %edx
	cmpl	%edx, %eax
	jb	.L3502
	jmp	.L3572
.L3576:
	movl	$0, %edi
.L3499:
	addl	$1, %edi
	movb	%dil, 2408(%rbx)
	movl	%esi, %eax
	jmp	.L3501
.L3609:
	movb	%r12b, 2444(%rbx)
	movb	%bpl, 2445(%rbx)
	movl	mod_seed(%rip), %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%edx, %eax
	movl	%eax, mod_seed(%rip)
	shrl	$16, %eax
	movw	%ax, 2448(%rbx)
	leaq	190(%rbx), %r15
	movq	%rbx, 8(%rsp)
	leaq	1534(%rbx), %rsi
	movq	%r15, %rax
	movl	$0, %edx
.L3503:
	movzbl	(%rax), %ecx
	orl	%ecx, %edx
	addq	$84, %rax
	cmpq	%rsi, %rax
	jne	.L3503
	testl	%edx, %edx
	jne	.L3504
	movswl	22(%rbx), %eax
	sall	$25, %eax
	movl	%eax, 1532(%rbx)
	movl	$0, 1540(%rbx)
.L3504:
	cmpl	$0, 4(%rsp)
	je	.L3612
	movl	$0, %r13d
	cmpb	$0, 2363(%rbx)
	je	.L3559
	cmpb	$0, 191(%rbx)
	je	.L3559
	cmpb	$0, 190(%rbx)
	setne	%r13b
	movzbl	%r13b, %r13d
.L3559:
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	mono_remove
	cmpb	$15, 2362(%rbx)
	ja	.L3613
.L3560:
	movzbl	2362(%rbx), %eax
	leal	1(%rax), %edx
	movb	%dl, 2362(%rbx)
	movzbl	%al, %eax
	movb	%bpl, 2346(%rbx,%rax)
	movq	%rbx, %rdi
	call	eng_audio
	movq	400(%rax), %rax
	testq	%rax, %rax
	je	.L3561
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	*%rax
.L3561:
	movq	%rbx, %rdi
	call	mono_pick
	movl	%eax, %esi
	testl	%r13d, %r13d
	je	.L3562
	movzbl	2363(%rbx), %eax
	cmpl	%esi, %eax
	je	.L3493
	cmpl	$1, 4(%rsp)
	je	.L3570
	movl	$1, %r8d
	cmpw	$0, 76(%rbx)
	jne	.L3565
	cmpb	$0, 2308(%rbx)
	setne	%r8b
	movzbl	%r8b, %r8d
	jmp	.L3565
.L3612:
	movq	%rbx, %rdi
	call	eng_audio
	movq	%rax, %r13
	movq	%rbx, %rdi
	call	trk_nvoice
	movl	%eax, %r14d
	movzbl	voice_fade_steal(%rip), %eax
	movb	%al, 16(%rsp)
	testb	%al, %al
	je	.L3506
	leaq	trk(%rip), %rax
	movq	%rbx, %r8
	subq	%rax, %r8
	sarq	$5, %r8
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %r8
	cmpl	$2, %r8d
	ja	.L3506
	leaq	vsq(%rip), %rax
	movl	%r8d, %edx
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rdx,%rdx,4), %rdx
	movzbl	24(%rax,%rdx), %edi
	movl	%r8d, %edx
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rdx,%rdx,4), %rsi
	addq	%rax, %rsi
	movl	$0, %eax
.L3507:
	cmpq	%rdi, %rax
	je	.L3506
	leaq	1(%rax), %rcx
	movzbl	(%rsi,%rax), %edx
	cmpl	%edx, %ebp
	je	.L3614
	movq	%rcx, %rax
	jmp	.L3507
.L3614:
	movl	%eax, %eax
	movl	%r8d, %r8d
	leaq	(%r8,%r8,4), %rdx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	vsq(%rip), %rdx
	addq	%rcx, %rdx
	movb	%r12b, 8(%rax,%rdx)
.L3508:
	movb	$0, 2362(%rbx)
	movb	$0, 2363(%rbx)
	jmp	.L3493
.L3506:
	movq	384(%r13), %rax
	testq	%rax, %rax
	je	.L3615
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	*%rax
	movl	$0, %edx
	divl	%r14d
	movl	%edx, %ecx
	leaq	(%rcx,%rcx,4), %rax
	salq	$2, %rax
	leaq	(%rax,%rcx), %rsi
	leaq	188(%rbx,%rsi,4), %r14
	cmpb	$0, 191(%rbx,%rsi,4)
	je	.L3513
	cmpb	$4, 192(%rbx,%rsi,4)
	jne	.L3514
.L3513:
	movl	$0, %esi
	movq	%rbx, %rdi
	call	voice_room
.L3514:
	movb	$0, 2362(%rbx)
	movb	$0, 2363(%rbx)
	movl	$0, 28(%r14)
	movl	$0, %r8d
	cmpw	$0, 76(%rbx)
	je	.L3567
	movq	%rbx, %rdi
	call	eng_audio
	cmpb	$0, 296(%rax)
	sete	%r8b
	movzbl	%r8b, %r8d
.L3567:
	movl	%r12d, %ecx
	movl	%ebp, %edx
	movq	%r14, %rsi
	movq	%rbx, %rdi
	call	voice_start
	jmp	.L3493
.L3615:
	leaq	188(%rbx), %rax
	movl	4(%rsp), %r13d
	movl	%r13d, 24(%rsp)
	testl	%r14d, %r14d
	jne	.L3517
.L3512:
	cmpw	$0, 86(%rbx)
	jne	.L3529
	cmpw	$0, 76(%rbx)
	jne	.L3529
	movl	%r14d, %r13d
	testl	%r14d, %r14d
	je	.L3531
	movzbl	2364(%rbx), %esi
	movl	$1, %ecx
	subl	$1, %esi
.L3539:
	leal	(%rsi,%rcx), %eax
	movl	$0, %edx
	divl	%r14d
	movl	%edx, %eax
	leaq	(%rax,%rax,4), %rdi
	leaq	(%rax,%rdi,4), %rax
	cmpb	$0, 191(%rbx,%rax,4)
	cmove	%edx, %r13d
	cmpl	%r14d, %ecx
	setb	%dl
	cmpl	%r13d, %r14d
	sete	%al
	addl	$1, %ecx
	testb	%al, %dl
	jne	.L3539
	leal	1(%r13), %eax
	movzbl	%al, %eax
	cmpl	%r13d, %r14d
	je	.L3531
.L3541:
	movl	$0, %edx
	divl	%r14d
	movb	%dl, 2364(%rbx)
	cmpl	%r14d, %r13d
	jb	.L3542
	testl	%r14d, %r14d
	jne	.L3543
	movl	%r14d, 8(%rsp)
	jmp	.L3537
.L3617:
	movl	%r13d, %eax
	imulq	$84, %rax, %rax
	leaq	188(%rbx,%rax), %rdi
	call	voice_kill
	jmp	.L3508
.L3515:
	cmpb	$1, %dl
	adcl	$0, 24(%rsp)
	addl	$1, %r13d
	addq	$84, %rax
	cmpl	%r13d, %r14d
	je	.L3616
.L3517:
	movzbl	3(%rax), %edx
	testb	%dl, %dl
	je	.L3515
	movzbl	(%rax), %ecx
	cmpl	%ecx, %ebp
	jne	.L3515
	cmpb	$0, 16(%rsp)
	je	.L3516
	movq	%rbx, %rdi
	call	eng_audio
	cmpb	$0, 294(%rax)
	je	.L3516
	movl	%r13d, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	cmpl	$0, 200(%rbx,%rax,4)
	je	.L3516
	movl	%r13d, %eax
	leaq	(%rax,%rdx,4), %rax
	cmpb	$4, 192(%rbx,%rax,4)
	je	.L3516
	movl	%r12d, %edx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	vsq_push
	testl	%eax, %eax
	jne	.L3617
.L3516:
	movl	%r13d, %r13d
	leaq	0(%r13,%r13,4), %rax
	salq	$2, %rax
	leaq	(%rax,%r13), %rdx
	leaq	188(%rbx,%rdx,4), %r14
	cmpb	$4, 192(%rbx,%rdx,4)
	jne	.L3514
	movl	$0, %esi
	movq	%rbx, %rdi
	call	voice_room
	jmp	.L3514
.L3616:
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	cmpb	$0, 16(%rsp)
	setne	%cl
	cmpl	$0, 24(%rsp)
	sete	%dl
	testb	%dl, %cl
	je	.L3520
	testl	%eax, %eax
	jne	.L3618
.L3520:
	cmpl	$0, 24(%rsp)
	je	.L3512
	leaq	32(%rsp), %rax
	movq	%rax, 8(%rsp)
	jmp	.L3527
.L3521:
	addq	$84, 8(%rsp)
	movq	8(%rsp), %rax
	cmpq	%r13, %rax
	je	.L3512
.L3523:
	movq	8(%rsp), %rax
	cmpb	$0, 191(%rax)
	je	.L3521
	cmpb	$4, 192(%rax)
	jne	.L3521
	movl	%r12d, %edx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	vsq_push
	testl	%eax, %eax
	je	.L3521
	movb	$0, 2362(%rbx)
	movb	$0, 2363(%rbx)
	jmp	.L3493
.L3524:
	cmpl	$15, %eax
	ja	.L3512
	movl	%eax, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rdx
	movq	32(%rsp), %rax
	leaq	188(%rax,%rdx,4), %rdi
	call	voice_kill
.L3527:
	movq	%rbx, %rdi
	call	voices_busy_of
	movl	%eax, %r13d
	movq	%rbx, %rdi
	call	voice_units
	addl	%eax, %r13d
	cmpl	$16, %r13d
	jbe	.L3512
	movq	$0, 32(%rsp)
	movq	8(%rsp), %rdx
	movl	$0, %esi
	movq	%rbx, %rdi
	call	voice_victim
	cmpl	%r14d, %eax
	jnb	.L3524
	cmpq	32(%rsp), %rbx
	jne	.L3524
	cmpb	$0, voice_fade_steal(%rip)
	je	.L3525
	movl	%eax, %edx
	leaq	(%rdx,%rdx,4), %rcx
	leaq	(%rdx,%rcx,4), %rdx
	cmpl	$0, 200(%rbx,%rdx,4)
	jne	.L3524
.L3525:
	addl	$1, voice_steals(%rip)
	movl	%eax, %eax
	imulq	$84, %rax, %rax
	leaq	188(%rbx,%rax), %r14
	jmp	.L3514
.L3532:
	addl	$1, %ecx
	addq	$84, %rdx
	cmpl	%ecx, %r14d
	je	.L3619
.L3534:
	cmpb	$0, (%rdx)
	jne	.L3532
	movl	17(%rdx), %r10d
	movl	%r10d, %esi
	subl	%r9d, %esi
	movl	%esi, %eax
	negl	%eax
	cmovs	%esi, %eax
	testl	%r10d, %r10d
	cmove	%r8d, %eax
	cmpl	%edi, %eax
	jge	.L3532
	movl	%eax, %edi
	movl	%ecx, %r13d
	jmp	.L3532
.L3529:
	testl	%r14d, %r14d
	je	.L3620
	movl	%ebp, %r9d
	sall	$4, %r9d
	leaq	191(%rbx), %rdx
	movl	%r14d, %r13d
	movl	4(%rsp), %ecx
	movl	$2147483647, %edi
	movl	$2147483632, %r8d
	jmp	.L3534
.L3620:
	movl	%r14d, 8(%rsp)
	movl	%r14d, %r13d
.L3537:
	cmpl	%r13d, %r14d
	je	.L3621
.L3548:
	cmpl	%r14d, %r13d
	jnb	.L3549
	movl	%r13d, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	cmpb	$0, 190(%rbx,%rax,4)
	je	.L3555
	movl	%r13d, %eax
	leaq	(%rax,%rdx,4), %rax
	cmpb	$4, 192(%rbx,%rax,4)
	je	.L3555
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	jne	.L3622
.L3555:
	addl	$1, voice_steals(%rip)
	cmpb	$0, voice_fade_steal(%rip)
	je	.L3557
	movl	%r13d, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	cmpl	$0, 200(%rbx,%rax,4)
	je	.L3557
	movl	%r12d, %edx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	vsq_push
	testl	%eax, %eax
	je	.L3558
	movl	%r13d, %eax
	imulq	$84, %rax, %rax
	leaq	188(%rbx,%rax), %rdi
	call	voice_kill
	jmp	.L3508
.L3531:
	movzbl	2364(%rbx), %eax
	addl	$1, %eax
	movzbl	%al, %eax
	jmp	.L3541
.L3542:
	movl	%r13d, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	leaq	188(%rbx,%rax,4), %r14
	jmp	.L3514
.L3581:
	movl	%edx, 8(%rsp)
.L3544:
	leal	1(%rdx), %ecx
	addq	$84, %rax
	cmpl	%ecx, %r14d
	je	.L3623
	movl	%ecx, %edx
.L3545:
	cmpb	$0, 2(%rax)
	je	.L3544
	movl	8(%rsp), %r11d
	cmpl	%r11d, %r14d
	je	.L3581
	movl	%r11d, %esi
	leaq	(%rsi,%rsi,4), %rdi
	leaq	(%rsi,%rdi,4), %rsi
	movzbl	188(%rbx,%rsi,4), %edi
	cmpb	%dil, (%rax)
	cmovb	%edx, %r11d
	movl	%r11d, 8(%rsp)
	jmp	.L3544
.L3623:
	movl	4(%rsp), %eax
	jmp	.L3547
.L3584:
	movl	%eax, %r13d
.L3546:
	leal	1(%rax), %esi
	addq	$84, %r15
	cmpl	%eax, %edx
	je	.L3537
	movl	%esi, %eax
.L3547:
	cmpb	$0, (%r15)
	jne	.L3546
	cmpb	$4, 2(%r15)
	je	.L3546
	cmpl	%r13d, %ecx
	je	.L3584
	movl	%r13d, %edi
	leaq	(%rdi,%rdi,4), %r8
	leaq	(%rdi,%r8,4), %rdi
	movl	264(%rbx,%rdi,4), %edi
	cmpl	%edi, 74(%r15)
	cmovb	%eax, %r13d
	jmp	.L3546
.L3621:
	testl	%r13d, %r13d
	je	.L3549
	leaq	188(%rbx), %rax
	movq	%rax, 16(%rsp)
	movl	%r13d, 24(%rsp)
	movl	4(%rsp), %r15d
	jmp	.L3554
.L3626:
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	jne	.L3550
	movq	16(%rsp), %rax
	movzbl	(%rax), %esi
	movq	%rbx, %rdi
	call	chord_degree_known
	testl	%eax, %eax
	je	.L3551
	jmp	.L3550
.L3552:
	movl	24(%rsp), %eax
	cmpl	%eax, %r13d
	je	.L3587
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	jne	.L3624
.L3553:
	movl	24(%rsp), %edi
	movl	%edi, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	movq	16(%rsp), %rsi
	movl	264(%rbx,%rax,4), %eax
	cmpl	%eax, 76(%rsi)
	cmovb	%r15d, %edi
	movl	%edi, 24(%rsp)
.L3551:
	addl	$1, %r15d
	addq	$84, 16(%rsp)
	cmpl	%r13d, %r15d
	je	.L3625
.L3554:
	movl	8(%rsp), %eax
	cmpl	%eax, %r15d
	je	.L3626
.L3550:
	cmpb	$0, voice_fade_steal(%rip)
	je	.L3552
	movq	16(%rsp), %rax
	cmpb	$4, 4(%rax)
	jne	.L3552
	jmp	.L3551
.L3624:
	movl	%r15d, %esi
	movq	%rbx, %rdi
	call	chord_rank
	movl	%eax, 28(%rsp)
	movl	24(%rsp), %esi
	movq	%rbx, %rdi
	call	chord_rank
	cmpl	%eax, 28(%rsp)
	jb	.L3588
	movq	%rbx, %rdi
	call	voice_alloc_engine
	movl	%eax, %edi
	call	voice_chord_replace
	testl	%eax, %eax
	je	.L3553
	movl	%r15d, %esi
	movq	%rbx, %rdi
	call	chord_rank
	movl	%eax, 28(%rsp)
	movl	24(%rsp), %esi
	movq	%rbx, %rdi
	call	chord_rank
	cmpl	%eax, 28(%rsp)
	jne	.L3551
	jmp	.L3553
.L3587:
	movl	%r15d, 24(%rsp)
	jmp	.L3551
.L3588:
	movl	%r15d, 24(%rsp)
	jmp	.L3551
.L3625:
	movl	24(%rsp), %r13d
	jmp	.L3548
.L3622:
	movl	$16, %edx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	chord_note_rank
	movl	%eax, %r15d
	movl	%r13d, %esi
	movq	%rbx, %rdi
	call	chord_rank
	cmpl	%eax, %r15d
	jnb	.L3555
	jmp	.L3508
.L3627:
	movl	%r12d, %edx
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	vsq_push
	testl	%eax, %eax
	je	.L3558
	jmp	.L3508
.L3613:
	movzbl	2346(%rbx), %esi
	movq	%rbx, %rdi
	call	mono_remove
	jmp	.L3560
.L3570:
	movl	$1, %r8d
	cmpw	$0, 76(%rbx)
	jne	.L3564
	cmpb	$0, 2308(%rbx)
	setne	%r8b
	movzbl	%r8b, %r8d
.L3564:
	movl	$1, %ecx
	movl	%r12d, %edx
	movq	%rbx, %rdi
	call	mono_play
	jmp	.L3493
.L3562:
	movl	$0, %r8d
	cmpl	$1, 4(%rsp)
	je	.L3570
.L3565:
	movl	%r13d, %ecx
	xorl	$1, %ecx
	movl	%r12d, %edx
	movq	%rbx, %rdi
	call	mono_play
	jmp	.L3493
.L3549:
	addl	$1, voice_steals(%rip)
	cmpb	$0, voice_fade_steal(%rip)
	jne	.L3627
.L3558:
	cmpl	%r13d, %r14d
	cmove	4(%rsp), %r13d
.L3557:
	movl	%r13d, %edx
	leaq	(%rdx,%rdx,4), %rax
	salq	$2, %rax
	leaq	(%rax,%rdx), %rcx
	leaq	188(%rbx,%rcx,4), %r14
	cmpb	$4, 192(%rbx,%rcx,4)
	jne	.L3514
	movl	$0, %esi
	movq	%rbx, %rdi
	call	voice_room
	jmp	.L3514
.L3619:
	cmpl	%r14d, %r13d
	jb	.L3542
.L3543:
	leaq	188(%rbx), %rax
	movl	%r14d, 8(%rsp)
	movl	4(%rsp), %edx
	jmp	.L3545
.L3618:
	movl	%r14d, %eax
	leaq	(%rax,%rax,4), %rdx
	leaq	(%rax,%rdx,4), %rax
	leaq	(%rbx,%rax,4), %r13
	jmp	.L3523
.L3611:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE542:
	.size	trk_note_on_inner, .-trk_note_on_inner
	.type	track_render_x, @function
track_render_x:
.LFB549:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	movq	%rdi, %r15
	movq	%rsi, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%rcx, 56(%rsp)
	movl	%r8d, 80(%rsp)
	movq	%r9, %rbp
	movq	%fs:40, %rax
	movq	%rax, 232(%rsp)
	xorl	%eax, %eax
	call	eng_audio
	movq	%rax, 72(%rsp)
	testq	%rbp, %rbp
	je	.L3629
	movl	0(%rbp), %eax
	movl	%eax, %r14d
.L3630:
	movzwl	6+song(%rip), %eax
	testw	%ax, %ax
	js	.L3631
	movswl	%ax, %edx
	sall	$4, %edx
	movslq	%edx, %rcx
	imulq	$1374389535, %rcx, %rcx
	sarq	$37, %rcx
	sarl	$31, %edx
	subl	%edx, %ecx
	movl	%ecx, 8(%rsp)
.L3632:
	cwtl
	sall	$4, %eax
	imull	$-100, 8(%rsp), %edx
	addl	%edx, %eax
	imull	$2367, %eax, %eax
	movslq	%eax, %rdx
	imulq	$274877907, %rdx, %rdx
	sarq	$42, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, 24(%rsp)
	leaq	trk(%rip), %rax
	movq	%r15, %rbx
	subq	%rax, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	movzbl	184(%r15), %eax
	cmpl	$29, %eax
	ja	.L3633
	movl	%eax, %eax
	leaq	ENGINES(%rip), %rcx
	leaq	ENG_FM4_GONE(%rip), %rdx
	cmpq	%rdx, (%rcx,%rax,8)
	je	.L3633
	movl	%ebx, %edx
	leaq	midi_bend_q8(%rip), %rax
	movl	(%rax,%rdx,4), %eax
	leaq	midi_bend_target(%rip), %rcx
	movl	(%rcx,%rdx,4), %edx
	subl	%eax, %edx
	testl	%edx, %edx
	jle	.L3636
	cmpl	$3, %edx
	jle	.L3637
	leal	6(%rdx), %ecx
	addl	$3, %edx
	cmovs	%ecx, %edx
	sarl	$2, %edx
.L3637:
	addl	%edx, %eax
	movl	%ebx, %edx
	leaq	midi_bend_q8(%rip), %rcx
	movl	%eax, (%rcx,%rdx,4)
	jns	.L3635
	movl	$15, %ecx
	subl	%eax, %ecx
	leal	15(%rcx), %edx
	cmovns	%ecx, %edx
	sarl	$4, %edx
	negl	%edx
	movl	%edx, 12(%rsp)
	jmp	.L3639
.L3629:
	movl	1540(%r15), %eax
	imull	1536(%r15), %eax
	sarl	$15, %eax
	movl	%eax, %r14d
	jmp	.L3630
.L3631:
	movswl	%ax, %edx
	negl	%edx
	sall	$4, %edx
	addl	$99, %edx
	movslq	%edx, %rcx
	imulq	$1374389535, %rcx, %rcx
	sarq	$37, %rcx
	sarl	$31, %edx
	subl	%ecx, %edx
	movl	%edx, 8(%rsp)
	jmp	.L3632
.L3633:
	movl	%ebx, %eax
	leaq	midi_bend_target(%rip), %rdx
	movl	$0, (%rdx,%rax,4)
	leaq	midi_bend_q8(%rip), %rdx
	movl	$0, (%rdx,%rax,4)
	movl	$0, %eax
.L3635:
	leal	15(%rax), %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	sarl	$4, %edx
	movl	%edx, 12(%rsp)
.L3639:
	movl	12(%rsp), %edx
	sall	$4, %edx
	subl	%edx, %eax
	imull	$2367, %eax, %eax
	movslq	%eax, %rdx
	imulq	$1717986919, %rdx, %rdx
	sarq	$42, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, 28(%rsp)
	movl	$0, %eax
	cmpb	$0, 2390(%r15)
	je	.L3640
	cmpb	$0, 2391(%r15)
	setne	%al
	movzbl	%al, %eax
.L3640:
	movl	%eax, 44(%rsp)
	movl	80(%rsp), %esi
	testl	%esi, %esi
	je	.L3641
	movq	48(%rsp), %rdi
	movq	%rdi, %rax
	movl	%esi, %edx
	salq	$2, %rdx
	leaq	(%rdi,%rdx), %rcx
.L3642:
	movl	$0, (%rax)
	addq	$4, %rax
	cmpq	%rcx, %rax
	jne	.L3642
	movq	56(%rsp), %rax
	movb	$0, (%rax)
	movq	72(%rsp), %rax
	cmpq	$0, 376(%rax)
	je	.L3643
	movq	64(%rsp), %rsi
	movq	%rsi, %rax
	addq	%rsi, %rdx
.L3644:
	movl	$0, (%rax)
	addq	$4, %rax
	cmpq	%rdx, %rax
	jne	.L3644
.L3643:
	cmpl	$0, 44(%rsp)
	je	.L3645
	cmpb	$19, 182(%r15)
	je	.L3645
	leaq	166(%r15), %rax
	leaq	208(%rsp), %rdx
	leaq	224(%rsp), %rsi
.L3646:
	movzwl	(%rax), %ecx
	movw	%cx, (%rdx)
	movzwl	2226(%rax), %ecx
	movw	%cx, (%rax)
	addq	$2, %rax
	addq	$2, %rdx
	cmpq	%rsi, %rdx
	jne	.L3646
.L3645:
	testq	%rbp, %rbp
	je	.L3716
.L3647:
	movq	72(%rsp), %rax
	movq	336(%rax), %rax
	testq	%rax, %rax
	je	.L3648
	movq	%r15, %rdi
	call	*%rax
.L3648:
	movl	%r14d, %r13d
	leal	32768(%r14), %eax
	sarl	%eax
	movl	%eax, 84(%rsp)
	leaq	188(%r15), %r14
	leaq	1532(%r15), %rax
	movq	%rax, 16(%rsp)
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rax
	salq	$2, %rax
	movq	%rax, %rsi
	movq	%rax, 136(%rsp)
	leaq	mod_tab(%rip), %rax
	addq	%rsi, %rax
	movq	%rax, 128(%rsp)
	movl	$0, 40(%rsp)
	leaq	(%rbx,%rbx,4), %rax
	leaq	(%rbx,%rax,2), %rax
	movq	%rax, 32(%rsp)
	movq	72(%rsp), %r12
	jmp	.L3690
.L3636:
	cmpl	$-3, %edx
	jge	.L3637
	movl	%edx, %ecx
	subl	$3, %ecx
	cmovns	%ecx, %edx
	sarl	$2, %edx
	jmp	.L3637
.L3716:
	movq	%r15, %rdi
	call	track_lfo_tick
	jmp	.L3647
.L3651:
	cmpb	$4, %al
	jne	.L3654
.L3655:
	movl	$0, 8(%rbx)
	movb	$0, 4(%rbx)
	movb	$0, 3(%rbx)
	movl	$0, %edx
	cmpb	$0, 352(%r12)
	je	.L3659
.L3658:
	movq	320(%r12), %rax
	testq	%rax, %rax
	jne	.L3700
	jmp	.L3662
.L3652:
	movzwl	2(%r15), %edx
	andl	$127, %edx
	movl	8(%r14), %eax
	leaq	ENV_LIN(%rip), %rcx
	addl	(%rcx,%rdx,4), %eax
	cmpl	$16777215, %eax
	jle	.L3656
	movl	$16777216, 8(%r14)
	movb	$2, 4(%r14)
	jmp	.L3657
.L3650:
	movzwl	8(%r15), %ecx
	andl	$127, %ecx
	movl	8(%r14), %edx
	movzwl	%dx, %eax
	leaq	ENV_EXP(%rip), %rsi
	movzwl	(%rsi,%rcx,2), %esi
	imull	%esi, %eax
	shrl	$16, %eax
	movl	%edx, %ecx
	sarl	$16, %ecx
	imull	%esi, %ecx
	addl	%ecx, %eax
	subl	%eax, %edx
	movl	%edx, 8(%r14)
	cmpl	$4095, %edx
	jle	.L3655
	jmp	.L3657
.L3654:
	movl	$0, 8(%rbx)
	jmp	.L3657
.L3727:
	movq	%rbx, %rsi
	movq	%r15, %rdi
	call	*360(%r12)
	testl	%eax, %eax
	je	.L3660
	cmpq	$0, 384(%r12)
	je	.L3717
	movb	$0, 2(%rbx)
	movb	$0, 3(%rbx)
	movb	$0, 4(%rbx)
	movl	$0, 8(%rbx)
	movl	$0, %edx
	jmp	.L3658
.L3717:
	movb	$0, 2(%rbx)
	movb	$0, 3(%rbx)
	movb	$0, 4(%rbx)
	movl	$0, 12(%rbx)
	movl	$0, 8(%rbx)
	jmp	.L3689
.L3660:
	movl	$16777216, 8(%rbx)
	movl	$32767, %edx
	jmp	.L3658
.L3670:
	movl	%ecx, %ebp
	subl	%r8d, %ebp
	movl	%eax, %r11d
	negl	%r11d
	cmpl	%eax, %ebp
	cmovge	%r11d, %esi
	jmp	.L3671
.L3723:
	cmpb	$2, 4(%rbx)
	jne	.L3672
	cmpb	$0, 294(%r12)
	jne	.L3672
	jmp	.L3689
.L3724:
	leaq	(%rcx,%r11,4), %rcx
	movl	4(%rcx), %r10d
	movl	%r10d, 144(%rsp)
	movl	8(%rcx), %r10d
	movl	%r10d, 148(%rsp)
	movl	12(%rcx), %r10d
	movl	%r10d, 152(%rsp)
	movl	16(%rcx), %ecx
	movl	%ecx, 156(%rsp)
	movzbl	2446(%r15), %ecx
	leaq	(%rcx,%rcx,4), %r10
	leaq	(%rcx,%r10,4), %rcx
	leaq	188(%r15,%rcx,4), %rcx
	cmpq	%rcx, %rbx
	je	.L3718
.L3676:
	leaq	mod_tab(%rip), %rcx
	movq	32(%rsp), %r11
	movzbl	2(%rcx,%r11,4), %ecx
	testl	%ecx, %ecx
	je	.L3681
	leaq	1+mod_tab(%rip), %r10
	movq	136(%rsp), %r11
	addq	%r11, %r10
	leal	-1(%rcx), %ecx
	addq	%r10, %rcx
	movq	128(%rsp), %rbp
	leaq	148(%rsp), %r10
	movl	%r9d, 88(%rsp)
	movl	%r8d, 92(%rsp)
	movl	%esi, 96(%rsp)
	movl	%edi, 100(%rsp)
	movl	%r13d, 104(%rsp)
	movl	%eax, 108(%rsp)
	movq	%r12, 112(%rsp)
	movl	%edx, %r13d
	movq	%rcx, %r12
	movq	%r14, 120(%rsp)
	movq	%r10, %r14
	jmp	.L3680
.L3718:
	movl	%edx, 2452(%r15)
	jmp	.L3676
.L3720:
	movzbl	80(%rbx), %edx
	imull	$258, %edx, %edx
.L3677:
	movsbl	28(%rax), %ecx
	movzbl	24(%rax), %esi
	leaq	156(%rsp), %rax
	pushq	%rax
	.cfi_def_cfa_offset 312
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_def_cfa_offset 320
	movq	%r14, %r9
	leaq	160(%rsp), %r8
	call	mod_voice_add
	addq	$1, %rbp
	addq	$16, %rsp
	.cfi_def_cfa_offset 304
	cmpq	%r12, %rbp
	je	.L3719
.L3680:
	movq	%rbp, %rax
	movzbl	20(%rbp), %edi
	movl	%r13d, %edx
	cmpl	$2, %edi
	je	.L3677
	cmpl	$3, %edi
	je	.L3720
	cmpl	$4, %edi
	je	.L3721
	movswl	82(%rbx), %edx
	jmp	.L3677
.L3721:
	movzbl	(%rbx), %edx
	subl	$60, %edx
	sall	$9, %edx
	movl	$32767, %ecx
	cmpl	%ecx, %edx
	cmovg	%ecx, %edx
	movl	$-32767, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
	jmp	.L3677
.L3719:
	movl	88(%rsp), %r9d
	movl	92(%rsp), %r8d
	movl	96(%rsp), %esi
	movl	100(%rsp), %edi
	movl	104(%rsp), %r13d
	movl	108(%rsp), %eax
	movq	112(%rsp), %r12
	movq	120(%rsp), %r14
.L3681:
	movl	144(%rsp), %edx
	testl	%edx, %edx
	je	.L3683
	addl	%edx, %eax
	movl	$2047, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movl	%eax, 164(%rsp)
	addl	$64, %eax
	imull	$21846, %eax, %edx
	shrl	$22, %edx
	leal	(%rdx,%rdx,2), %ecx
	sall	$6, %ecx
	subl	%ecx, %eax
	movl	$10, %ecx
	subl	%edx, %ecx
	leaq	PITCH_OCT(%rip), %rdx
	movl	(%rdx,%rax,4), %eax
	shrl	%cl, %eax
	testl	%esi, %esi
	jne	.L3684
	movl	%eax, 160(%rsp)
.L3683:
	movl	148(%rsp), %eax
	addl	%eax, 176(%rsp)
	movl	176(%rsp), %eax
	movl	$38400, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-38400, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 176(%rsp)
	addl	152(%rsp), %edi
	movl	$48640, %eax
	cmpl	%eax, %edi
	cmovg	%eax, %edi
	movl	$-15872, %eax
	cmpl	%eax, %edi
	cmovl	%eax, %edi
	movl	%edi, 180(%rsp)
	leaq	mod_tab(%rip), %rax
	movq	32(%rsp), %rdx
	cmpb	$0, 1(%rax,%rdx,4)
	je	.L3675
	imull	156(%rsp), %r9d
	sarl	$15, %r9d
	movl	%r9d, 172(%rsp)
	movl	%r9d, 12(%rbx)
	jmp	.L3675
.L3684:
	movl	%eax, %edx
	shrl	$12, %edx
	imull	%esi, %edx
	addl	%edx, %eax
	movl	%eax, 160(%rsp)
	jmp	.L3683
.L3725:
	movl	2752+chord_plan(%rip), %eax
	leal	1(%rax), %edx
	movl	%edx, 2752+chord_plan(%rip)
	movl	%eax, %eax
	leaq	chord_plan(%rip), %rdx
	movq	%rbx, (%rdx,%rax,8)
	leaq	(%rax,%rax,8), %rdx
	leaq	128+chord_plan(%rip), %rax
	leaq	(%rax,%rdx,4), %rax
	movdqa	160(%rsp), %xmm0
	movups	%xmm0, (%rax)
	movdqa	176(%rsp), %xmm1
	movups	%xmm1, 16(%rax)
	movl	192(%rsp), %edx
	movl	%edx, 32(%rax)
	addl	$1, 40(%rsp)
	jmp	.L3689
.L3687:
	leaq	160(%rsp), %r8
	movl	80(%rsp), %ecx
	movq	48(%rsp), %rdx
	movq	%rbx, %rsi
	movq	%r15, %rdi
	call	*312(%r12)
	jmp	.L3688
.L3726:
	cmpb	$0, chord_prepare(%rip)
	je	.L3706
	leaq	trk(%rip), %rax
	cmpq	%rax, %r15
	je	.L3628
.L3706:
	movq	72(%rsp), %rax
	movq	408(%rax), %rax
	testq	%rax, %rax
	je	.L3694
	movl	40(%rsp), %ecx
	movl	80(%rsp), %edx
	movq	48(%rsp), %rsi
	movq	%r15, %rdi
	call	*%rax
.L3694:
	movq	72(%rsp), %rax
	movq	424(%rax), %rax
	testq	%rax, %rax
	je	.L3695
	movl	40(%rsp), %r8d
	movl	80(%rsp), %ecx
	movq	64(%rsp), %rdx
	movq	48(%rsp), %rsi
	movq	%r15, %rdi
	call	*%rax
	movq	56(%rsp), %rbx
	orb	%al, (%rbx)
.L3695:
	cmpl	$0, 44(%rsp)
	je	.L3628
	cmpb	$19, 182(%r15)
	je	.L3696
	movl	$0, %eax
.L3697:
	movzwl	208(%rsp,%rax), %edx
	movw	%dx, 166(%r15,%rax)
	addq	$2, %rax
	cmpq	$16, %rax
	jne	.L3697
.L3696:
	subb	$1, 2391(%r15)
.L3628:
	movq	232(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3722
	movl	40(%rsp), %eax
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3663:
	.cfi_restore_state
	movl	%edx, 184(%rsp)
	movzbl	1(%rbx), %ecx
	imull	%edx, %ecx
	imull	$258, %ecx, %ecx
	sarl	$15, %ecx
	movl	%edx, %edi
.L3698:
	movl	%ecx, 172(%rsp)
	movzwl	32(%r15), %eax
	testw	%ax, %ax
	je	.L3665
	cwtl
	movl	84(%rsp), %esi
	imull	%esi, %eax
	imull	$258, %eax, %eax
	sarl	$15, %eax
	movl	$32767, %esi
	subl	%eax, %esi
	movl	%esi, %eax
	imull	%ecx, %eax
	sarl	$15, %eax
	movl	%eax, 172(%rsp)
.L3665:
	cmpl	$0, 44(%rsp)
	je	.L3666
	movzbl	2391(%r15), %eax
	subl	$1, %eax
	imull	172(%rsp), %eax
	leal	3(%rax), %ecx
	testl	%eax, %eax
	cmovs	%ecx, %eax
	sarl	$2, %eax
	movl	%eax, 172(%rsp)
.L3666:
	movl	12(%rbx), %r10d
	movl	%r10d, 168(%rsp)
	movl	172(%rsp), %r9d
	movl	%r9d, 12(%rbx)
	movl	20(%rbx), %ecx
	movl	16(%rbx), %r8d
	cmpl	%r8d, %ecx
	je	.L3667
	movl	%r8d, %esi
	subl	%ecx, %esi
	movl	24(%rbx), %eax
	testl	%eax, %eax
	jne	.L3668
	movzwl	76(%r15), %r11d
	movl	%r11d, %eax
	andl	$127, %eax
	testw	%r11w, %r11w
	movl	$40, %r11d
	cmove	%r11d, %eax
	cltq
	leaq	ENV_LIN(%rip), %r11
	movl	(%r11,%rax,4), %eax
	shrl	$14, %eax
.L3668:
	testl	%eax, %eax
	movl	$1, %r11d
	cmovle	%r11d, %eax
	testl	%esi, %esi
	jle	.L3670
	cmpl	%eax, %esi
	cmovg	%eax, %esi
.L3671:
	addl	%esi, %ecx
	movl	%ecx, 20(%rbx)
.L3667:
	orl	%r10d, %edi
	je	.L3723
.L3672:
	movswl	26(%r15), %eax
	imull	%r13d, %eax
	leal	(%rax,%rax,2), %eax
	sarl	$15, %eax
	movl	8(%rsp), %ecx
	addl	20(%rbx), %ecx
	movl	12(%rsp), %edi
	addl	%edi, %ecx
	addl	%ecx, %eax
	movswl	12(%r15), %ecx
	imull	%edx, %ecx
	leal	(%rcx,%rcx,2), %ecx
	sarl	$15, %ecx
	addl	%ecx, %eax
	movl	$2047, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	movl	$0, %ecx
	cmovs	%ecx, %eax
	movl	%eax, 164(%rsp)
	leal	64(%rax), %edi
	imull	$21846, %edi, %esi
	shrl	$22, %esi
	leal	(%rsi,%rsi,2), %ecx
	sall	$6, %ecx
	subl	%ecx, %edi
	movl	$10, %ecx
	subl	%esi, %ecx
	leaq	PITCH_OCT(%rip), %rsi
	movl	(%rsi,%rdi,4), %esi
	shrl	%cl, %esi
	movl	%esi, %ecx
	movl	%esi, 160(%rsp)
	movl	24(%rsp), %esi
	addl	28(%rbx), %esi
	movl	28(%rsp), %edi
	addl	%edi, %esi
	movl	%esi, 188(%rsp)
	je	.L3673
	movl	%ecx, %edi
	shrl	$12, %edi
	imull	%esi, %edi
	addl	%edi, %ecx
	movl	%ecx, 160(%rsp)
.L3673:
	movswl	28(%r15), %ecx
	imull	%r13d, %ecx
	sarl	$7, %ecx
	movswl	10(%r15), %edi
	imull	%edx, %edi
	sarl	$7, %edi
	addl	%edi, %ecx
	movl	%ecx, 176(%rsp)
	cmpb	$110, 1(%rbx)
	jbe	.L3674
	leal	(%rdx,%rdx,2), %edi
	sall	$3, %edi
	sarl	$7, %edi
	addl	%edi, %ecx
	movl	%ecx, 176(%rsp)
.L3674:
	movswl	30(%r15), %edi
	imull	%r13d, %edi
	sarl	$7, %edi
	movswl	14(%r15), %ecx
	imull	%edx, %ecx
	sarl	$7, %ecx
	leal	16384(%rdi,%rcx), %edi
	movl	%edi, 180(%rsp)
	leaq	mod_tab(%rip), %rcx
	movq	32(%rsp), %r11
	cmpb	$0, (%rcx,%r11,4)
	jne	.L3724
.L3675:
	movl	164(%rsp), %eax
	movl	8(%rsp), %edx
	subl	%edx, %eax
	movl	12(%rsp), %edx
	subl	%edx, %eax
	subl	%r8d, %eax
	imull	$87381, %eax, %eax
	movl	24(%rsp), %edi
	subl	%edi, %esi
	movl	28(%rsp), %edx
	subl	%edx, %esi
	imull	$5909, %esi, %esi
	addl	%esi, %eax
	movl	%eax, 192(%rsp)
	cmpb	$0, chord_prepare(%rip)
	je	.L3686
	leaq	trk(%rip), %rax
	cmpq	%rax, %r15
	je	.L3725
.L3686:
	movq	376(%r12), %rax
	testq	%rax, %rax
	je	.L3687
	leaq	160(%rsp), %r9
	movl	80(%rsp), %r8d
	movq	64(%rsp), %rcx
	movq	48(%rsp), %rdx
	movq	%rbx, %rsi
	movq	%r15, %rdi
	call	*%rax
	movq	56(%rsp), %rbx
	orb	%al, (%rbx)
.L3688:
	addl	$1, 40(%rsp)
.L3689:
	addq	$84, %r14
	movq	16(%rsp), %rax
	cmpq	%rax, %r14
	je	.L3726
.L3690:
	movq	%r14, %rbx
	cmpb	$0, 3(%r14)
	je	.L3689
	movzwl	6(%r15), %edx
	movzbl	4(%r14), %eax
	cmpb	$3, %al
	je	.L3650
	ja	.L3651
	cmpb	$1, %al
	je	.L3652
	cmpb	$2, %al
	jne	.L3654
	movzwl	4(%r15), %esi
	andl	$127, %esi
	movl	8(%r14), %ecx
	sall	$17, %edx
	subl	%ecx, %edx
	movzwl	%dx, %eax
	leaq	ENV_EXP(%rip), %rdi
	movzwl	(%rdi,%rsi,2), %esi
	imull	%esi, %eax
	shrl	$16, %eax
	sarl	$16, %edx
	imull	%esi, %edx
	addl	%edx, %eax
	addl	%ecx, %eax
	movl	%eax, 8(%r14)
.L3657:
	movl	8(%rbx), %edx
	sarl	$9, %edx
	cmpb	$0, 352(%r12)
	jne	.L3727
.L3659:
	movq	320(%r12), %rax
	testq	%rax, %rax
	je	.L3663
.L3700:
	movq	%rbx, %rsi
	movq	%r15, %rdi
	call	*%rax
	movl	%eax, %edx
.L3662:
	cmpb	$0, 352(%r12)
	je	.L3663
	movl	$0, 184(%rsp)
	movl	%edx, %edi
	movl	%edx, %ecx
	movl	$0, %edx
	jmp	.L3698
.L3656:
	movl	%eax, 8(%r14)
	jmp	.L3657
.L3641:
	movq	56(%rsp), %rax
	movb	$0, (%rax)
	jmp	.L3643
.L3722:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE549:
	.size	track_render_x, .-track_render_x
	.type	c1_part1_job, @function
c1_part1_job:
.LFB620:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %ebx
	cmpb	$0, c1_chord_split(%rip)
	jne	.L3732
.L3729:
	leaq	4+c1_lfo(%rip), %r9
	movl	%ebx, %r8d
	leaq	c1_side_on(%rip), %rcx
	leaq	c1_side(%rip), %rdx
	leaq	c1_buf(%rip), %rsi
	leaq	2464+trk(%rip), %rdi
	call	track_render_x
	movl	%eax, c1_nr(%rip)
	cmpb	$0, morph_dual(%rip)
	je	.L3728
	cmpb	$19, 182+trk(%rip)
	je	.L3733
.L3728:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L3732:
	.cfi_restore_state
	movl	%edi, %ecx
	movl	c1_chord_count(%rip), %edx
	movl	$0, %esi
	leaq	trk(%rip), %rdi
	call	chord_render_range
	jmp	.L3729
.L3733:
	movl	$0, %r9d
	movl	%ebx, %r8d
	leaq	morph_b_side_on(%rip), %rcx
	leaq	morph_b_side(%rip), %rdx
	leaq	morph_b_pcm(%rip), %rsi
	leaq	4928+trk(%rip), %rdi
	call	track_render_x
	movl	%eax, morph_b_nr(%rip)
	jmp	.L3728
	.cfi_endproc
.LFE620:
	.size	c1_part1_job, .-c1_part1_job
	.type	morph_deep_get, @function
morph_deep_get:
.LFB497:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movl	%esi, %edi
	cmpl	$1, %esi
	ja	.L3747
	movl	%edx, %esi
	cmpl	$3, %edx
	ja	.L3747
	movl	%edi, %edx
	orl	%esi, %edx
	je	.L3749
	call	morph_column
	cmpl	$8, %eax
	je	.L3750
	cmpl	$2, %eax
	jne	.L3743
	cmpb	$0, 6620+morph(%rip)
	jne	.L3751
.L3743:
	movzbl	6272+morph(%rip), %edx
	testb	%dl, %dl
	je	.L3746
	movl	%eax, %eax
	addq	$3128, %rax
	leaq	morph(%rip), %rdx
	movzwl	(%rdx,%rax,2), %eax
	cwtl
	jmp	.L3734
.L3749:
	movzbl	6272+morph(%rip), %eax
	testb	%al, %al
	je	.L3737
	movzwl	6256+morph(%rip), %eax
	cwtl
.L3738:
	cmpl	$11, %eax
	cmovnb	%edx, %eax
	jmp	.L3734
.L3737:
	movswl	166(%rbx), %eax
	jmp	.L3738
.L3750:
	movzbl	6272+morph(%rip), %eax
	testb	%al, %al
	je	.L3741
	movzwl	6270+morph(%rip), %eax
	cwtl
.L3742:
	movzbl	%al, %eax
	jmp	.L3734
.L3741:
	movswl	180(%rbx), %eax
	jmp	.L3742
.L3751:
	movzbl	6272+morph(%rip), %edx
	testb	%dl, %dl
	je	.L3744
	movzwl	6262+morph(%rip), %edx
	movswl	%dx, %edx
.L3745:
	testl	%edx, %edx
	je	.L3743
	movzwl	6606+morph(%rip), %eax
	subl	$-128, %eax
	shrl	$8, %eax
	jmp	.L3734
.L3744:
	movswl	172(%rbx), %edx
	jmp	.L3745
.L3746:
	leal	83(%rax), %eax
	movswl	(%rbx,%rax,2), %eax
	jmp	.L3734
.L3747:
	movl	$0, %eax
.L3734:
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE497:
	.size	morph_deep_get, .-morph_deep_get
	.type	va_mod_dst, @function
va_mod_dst:
.LFB454:
	.cfi_startproc
	endbr64
	cmpl	$255, %esi
	je	.L3779
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	imull	$1059797125, %edi, %edi
	call	va_index
	cmpl	$255, %eax
	je	.L3774
	cmpl	$23, %eax
	ja	.L3756
	movl	%eax, %edx
	movl	$2863311531, %ecx
	imulq	%rcx, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,2), %ecx
	addl	%ecx, %ecx
	subl	%ecx, %eax
	cmpl	$3, %eax
	ja	.L3757
	leal	2(%rdx), %ecx
	cmpl	$1, %eax
	ja	.L3752
	addl	$6, %edx
	cmpl	$1, %eax
	movl	$-1, %ecx
	cmove	%edx, %ecx
.L3752:
	movl	%ecx, %eax
	ret
.L3779:
	movl	$17, %ecx
	cmpl	$39, %edx
	je	.L3752
	ja	.L3755
	movl	$16, %ecx
	testl	%edx, %edx
	je	.L3752
	cmpl	$28, %edx
	sete	%cl
	movzbl	%cl, %ecx
	leal	-1(%rcx,%rcx), %ecx
	jmp	.L3752
.L3755:
	cmpl	$44, %edx
	sete	%cl
	movzbl	%cl, %ecx
	leal	-1(%rcx,%rcx), %ecx
	jmp	.L3752
.L3757:
	addl	$10, %edx
	cmpl	$4, %eax
	movl	$-1, %ecx
	cmove	%edx, %ecx
	jmp	.L3752
.L3756:
	leal	-53(%rax), %edx
	cmpl	$19, %edx
	jbe	.L3780
	cmpl	$31, %eax
	ja	.L3763
	cmpl	$25, %eax
	jbe	.L3776
	subl	$26, %eax
	cmpl	$5, %eax
	ja	.L3764
	movl	%eax, %eax
	leaq	.L3766(%rip), %rdx
	movslq	(%rdx,%rax,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L3766:
	.long	.L3769-.L3766
	.long	.L3768-.L3766
	.long	.L3777-.L3766
	.long	.L3767-.L3766
	.long	.L3764-.L3766
	.long	.L3765-.L3766
	.text
.L3780:
	movl	%edx, %ecx
	movl	$3435973837, %eax
	imulq	%rax, %rcx
	shrq	$34, %rcx
	leal	(%rcx,%rcx,4), %eax
	subl	%eax, %edx
	jne	.L3762
	addl	$18, %ecx
	jmp	.L3752
.L3762:
	addl	$26, %ecx
	cmpl	$2, %edx
	movl	$-1, %eax
	cmovne	%eax, %ecx
	jmp	.L3752
.L3768:
	movl	$14, %ecx
	jmp	.L3752
.L3764:
	movl	$-1, %ecx
	jmp	.L3752
.L3763:
	cmpl	$104, %eax
	movl	$24, %ecx
	movl	$-1, %eax
	cmovne	%eax, %ecx
	jmp	.L3752
.L3769:
	movl	$22, %ecx
	jmp	.L3752
.L3765:
	movl	$25, %ecx
	jmp	.L3752
.L3767:
	movl	$23, %ecx
	jmp	.L3752
.L3774:
	movl	$-1, %ecx
	jmp	.L3752
.L3776:
	movl	$-1, %ecx
	jmp	.L3752
.L3777:
	movl	$15, %ecx
	jmp	.L3752
	.cfi_endproc
.LFE454:
	.size	va_mod_dst, .-va_mod_dst
	.type	va_voice, @function
va_voice:
.LFB442:
	.cfi_startproc
	leaq	trk(%rip), %rdx
	movq	%rdi, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	addq	$188, %rdi
	subq	%rdi, %rsi
	sarq	$2, %rsi
	movabsq	$-3513665537849438403, %rdx
	imulq	%rdx, %rsi
	cmpl	$2, %eax
	ja	.L3783
	cmpl	$7, %esi
	ja	.L3783
	movl	%esi, %esi
	leaq	(%rsi,%rsi,2), %rdx
	leaq	(%rdx,%rdx,8), %rdx
	movl	%eax, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	(%rax,%rax,8), %rax
	salq	$5, %rax
	leaq	(%rax,%rdx,4), %rax
	leaq	va_vs(%rip), %rdx
	addq	%rdx, %rax
	ret
.L3783:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE442:
	.size	va_voice, .-va_voice
	.type	va_note_on, @function
va_note_on:
.LFB443:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	call	va_voice
	testq	%rax, %rax
	je	.L3784
	movq	%rax, %rsi
	cmpl	$0, 8(%rbx)
	jne	.L3786
	movl	$1, %r9d
	cmpl	$0, 12(%rbx)
	je	.L3787
.L3786:
	cmpb	$0, 104(%rsi)
	sete	%r9b
	movzbl	%r9b, %r9d
.L3787:
	leaq	188(%rbp), %rax
	leaq	1532(%rbp), %r8
	movl	$0, %ecx
	movl	$0, %edi
	jmp	.L3789
.L3802:
	cmpb	$0, 2(%rax)
	setne	%dl
	movzbl	%dl, %edx
.L3788:
	orl	%edx, %ecx
	addq	$84, %rax
	cmpq	%r8, %rax
	je	.L3801
.L3789:
	movl	%edi, %edx
	cmpq	%rax, %rbx
	jne	.L3802
	jmp	.L3788
.L3801:
	testl	%ecx, %ecx
	jne	.L3790
	leaq	trk(%rip), %rax
	subq	%rax, %rbp
	sarq	$5, %rbp
	leaq	va_lfo(%rip), %rcx
	imull	$1059797125, %ebp, %eax
	leaq	0(,%rax,8), %rdx
	leaq	(%rdx,%rax), %rdi
	movl	$0, (%rcx,%rdi,8)
	movl	$0, 4(%rcx,%rdi,8)
	movl	$0, 8(%rcx,%rdi,8)
	movl	$0, 12(%rcx,%rdi,8)
.L3790:
	testl	%r9d, %r9d
	je	.L3791
	movl	76(%rbx), %eax
	movl	$0, 32(%rbx)
	imull	$-1640531527, %eax, %edx
	movl	%edx, 36(%rbx)
	imull	$-626627285, %eax, %edx
	movl	%edx, 40(%rbx)
	imull	$387276957, %eax, %eax
	movl	%eax, (%rsi)
	movl	$0, 48(%rbx)
	movl	$0, 44(%rbx)
	cmpl	$0, 52(%rbx)
	jne	.L3792
	movl	76(%rbx), %eax
	addl	$625341585, %eax
	movl	%eax, 52(%rbx)
.L3792:
	movl	$0, %eax
.L3793:
	movl	$0, 4(%rsi,%rax,2)
	movw	$0, 44(%rsi,%rax)
	movw	$0, 36(%rsi,%rax)
	movl	$0, 56(%rbx,%rax,2)
	addq	$2, %rax
	cmpq	$8, %rax
	jne	.L3793
	movl	$0, 72(%rbx)
	movl	$0, 52(%rsi)
	pxor	%xmm0, %xmm0
	movups	%xmm0, 56(%rsi)
	movups	%xmm0, 72(%rsi)
	movl	$0, 92(%rsi)
	movl	$0, 88(%rsi)
	movb	$0, 96(%rsi)
.L3791:
	movb	$1, 100(%rsi)
	movl	$0, 20(%rsi)
	movb	$1, 101(%rsi)
	movl	$0, 24(%rsi)
	movb	$1, 102(%rsi)
	movl	$0, 28(%rsi)
	movb	$1, 103(%rsi)
	movl	$0, 32(%rsi)
	movw	$0, 98(%rsi)
	movb	$1, 104(%rsi)
.L3784:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE443:
	.size	va_note_on, .-va_note_on
	.type	va_done, @function
va_done:
.LFB445:
	.cfi_startproc
	endbr64
	call	va_voice
	testq	%rax, %rax
	je	.L3806
	cmpb	$0, 104(%rax)
	je	.L3805
	movl	$0, %edx
	cmpb	$0, 100(%rax)
	jne	.L3803
.L3805:
	movb	$0, 104(%rax)
	movl	$1, %edx
.L3803:
	movl	%edx, %eax
	ret
.L3806:
	movl	$1, %edx
	jmp	.L3803
	.cfi_endproc
.LFE445:
	.size	va_done, .-va_done
	.type	va_render, @function
va_render:
.LFB451:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$904, %rsp
	.cfi_def_cfa_offset 960
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	movq	%rsi, 88(%rsp)
	movq	%rdx, 120(%rsp)
	movq	%rcx, 136(%rsp)
	movl	%r8d, %r15d
	movl	%r8d, 84(%rsp)
	movq	%r9, 112(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 888(%rsp)
	xorl	%eax, %eax
	call	va_voice
	movq	%rax, 16(%rsp)
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm0, 400(%rsp)
	movaps	%xmm0, 416(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	testq	%rax, %rax
	je	.L4084
	movq	%rax, %rdi
	cmpb	$0, 104(%rax)
	sete	%cl
	cmpl	$32, %r15d
	seta	%dl
	movl	$0, %eax
	orb	%dl, %cl
	movb	%cl, 187(%rsp)
	je	.L4183
.L3808:
	movq	888(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L4184
	addq	$904, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L4183:
	.cfi_restore_state
	leaq	trk(%rip), %rdx
	movq	%rbp, %rax
	subq	%rdx, %rax
	sarq	$5, %rax
	movabsq	$5749634516480899205, %rdx
	imulq	%rdx, %rax
	movq	%rax, %r10
	movl	%eax, 260(%rsp)
	movl	%eax, %r8d
	imulq	$106, %r8, %rdx
	leaq	va_patch(%rip), %rax
	addq	%rdx, %rax
	movq	%rax, 24(%rsp)
	leaq	32(%rax), %rcx
	movl	$1, %eax
	movq	%rbx, %r9
	jmp	.L3819
.L4187:
	movb	$4, 99(%rdi,%rax)
.L3812:
	movzbl	4(%rcx), %r11d
	andl	$127, %r11d
	movzwl	%dx, %esi
	leaq	ENV_EXP(%rip), %rbx
	movzwl	(%rbx,%r11,2), %ebx
	imull	%ebx, %esi
	shrl	$16, %esi
	movl	%edx, %r11d
	sarl	$16, %r11d
	imull	%ebx, %r11d
	addl	%r11d, %esi
	subl	%esi, %edx
	cmpl	$4095, %edx
	jg	.L3816
	movb	$0, 99(%rdi,%rax)
	movl	$0, %edx
	jmp	.L3816
.L3810:
	movzbl	99(%rdi,%rax), %esi
	cmpb	$2, %sil
	jne	.L4082
	movzbl	1(%rcx), %r11d
	andl	$127, %r11d
	movl	16(%rdi,%rax,4), %esi
	leaq	ENV_LIN(%rip), %rbx
	addl	(%rbx,%r11,4), %esi
	movl	%esi, 16(%rdi,%rax,4)
	cmpl	$16777215, %esi
	jbe	.L3816
	movb	$3, 99(%rdi,%rax)
	jmp	.L3816
.L4188:
	cmpb	$1, %sil
	jne	.L4185
	movzbl	(%rcx), %esi
	andl	$127, %esi
	leaq	ENV_LIN(%rip), %r11
	addl	(%r11,%rsi,4), %edx
	cmpl	$16777215, %edx
	jle	.L3816
	cmpb	$1, 1(%rcx)
	movl	$2, %edx
	adcb	$0, %dl
	movb	%dl, 99(%rdi,%rax)
	movl	$16777216, %edx
	jmp	.L3816
.L4185:
	movl	$0, %edx
	jmp	.L3816
.L3817:
	movzbl	2(%rcx), %ebx
	andl	$127, %ebx
	movsbl	3(%rcx), %esi
	sall	$17, %esi
	subl	%edx, %esi
	movzwl	%si, %r11d
	leaq	ENV_EXP(%rip), %r12
	movzwl	(%r12,%rbx,2), %ebx
	imull	%ebx, %r11d
	shrl	$16, %r11d
	sarl	$16, %esi
	imull	%ebx, %esi
	addl	%r11d, %esi
	addl	%esi, %edx
.L3816:
	movl	%edx, (%rdi,%rax,4)
	sarl	$9, %edx
	movl	%edx, 364(%rsp,%rax,4)
	addq	$1, %rax
	addq	$5, %rcx
	cmpq	$5, %rax
	je	.L4186
.L3819:
	movl	(%rdi,%rax,4), %edx
	cmpb	$0, 2(%r9)
	jne	.L3810
	movzbl	99(%rdi,%rax), %ebx
	leal	-1(%rbx), %esi
	cmpb	$2, %sil
	jbe	.L4187
	movzbl	99(%rdi,%rax), %esi
.L4082:
	cmpb	$2, %sil
	jbe	.L4188
	cmpb	$3, %sil
	je	.L3817
	cmpb	$4, %sil
	je	.L3812
	movl	$0, %edx
	jmp	.L3816
.L4186:
	movq	16(%rsp), %rbx
	movzwl	98(%rbx), %eax
	cmpw	$-1, %ax
	je	.L3820
	addl	$1, %eax
	movw	%ax, 98(%rbx)
.L3820:
	movl	$0, 432(%rsp)
	movq	24(%rsp), %rax
	leaq	56(%rax), %r9
	leaq	432(%rsp), %rax
	leaq	(%r8,%r8,8), %rdx
	leaq	va_lfo(%rip), %rcx
	leaq	(%rcx,%rdx,8), %r11
	leaq	368(%rsp), %rdi
	movq	%r11, %rsi
	movl	$1, %ecx
	leaq	ENV_LIN(%rip), %rbx
	movq	16(%rsp), %r13
	jmp	.L3824
.L4240:
	movq	88(%rsp), %rax
	movzbl	80(%rax), %eax
	testb	%al, %al
	je	.L3825
	movzbl	%al, %eax
	imull	$258, %eax, %eax
.L3826:
	movl	%eax, 468(%rsp)
	movq	88(%rsp), %rbx
	movzbl	(%rbx), %eax
	subl	$60, %eax
	sall	$9, %eax
	movl	$32767, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	$-32767, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	%eax, 472(%rsp)
	movswl	82(%rbx), %eax
	movl	%eax, 476(%rsp)
	movzbl	2441(%rbp), %eax
	imull	$258, %eax, %eax
	movl	%eax, 480(%rsp)
	movl	%r10d, %eax
	leaq	(%rax,%rax,8), %rdx
	leaq	va_lfo(%rip), %rax
	cmpb	$0, 48(%rax,%rdx,8)
	je	.L3827
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	24(%rsp), %rbx
	leaq	73(%rbx), %rax
	leaq	97(%rbx), %rdi
	jmp	.L3829
.L3825:
	movq	88(%rsp), %rax
	movzbl	1(%rax), %eax
	imull	$258, %eax, %eax
	jmp	.L3826
.L3828:
	addq	$3, %rax
	cmpq	%rdi, %rax
	je	.L4189
.L3829:
	movsbl	1(%rax), %edx
	subl	$26, %edx
	cmpl	$3, %edx
	ja	.L3828
	movsbl	(%rax), %ecx
	leal	-1(%rcx), %r9d
	cmpl	$11, %r9d
	ja	.L3828
	movl	%edx, %edx
	movl	%ecx, %ecx
	movsbl	2(%rax), %esi
	imull	432(%rsp,%rcx,4), %esi
	addl	%esi, 752(%rsp,%rdx,4)
	jmp	.L3828
.L4189:
	movq	24(%rsp), %rax
	leaq	55(%rax), %rsi
	movl	$0, %edx
	leaq	ENV_LIN(%rip), %r9
	jmp	.L3833
.L4191:
	addl	%r12d, %r14d
.L3834:
	addq	$3, %rax
	cmpq	%rdi, %rax
	je	.L4190
.L3851:
	movzbl	(%rax), %edx
	movzbl	1(%rax), %ecx
	leal	-1(%rdx), %esi
	cmpb	$11, %sil
	ja	.L3834
	leal	-1(%rcx), %esi
	cmpb	$28, %sil
	ja	.L3834
	movsbl	2(%rax), %esi
	testl	%esi, %esi
	je	.L3834
	movsbl	%dl, %edx
	movsbl	%cl, %r9d
	movl	%edx, %ebx
	movl	432(%rsp,%rbx,4), %ebx
	movl	%ebx, %r12d
	imull	%esi, %r12d
	cmpb	$1, %cl
	je	.L4191
	cmpl	$5, %r9d
	ja	.L3836
	leal	-2(%r9), %edx
	addl	%r12d, 384(%rsp,%rdx,4)
	jmp	.L3834
.L3836:
	cmpl	$9, %r9d
	ja	.L3837
	leal	-6(%r9), %edx
	addl	%r12d, 400(%rsp,%rdx,4)
	jmp	.L3834
.L3837:
	cmpl	$13, %r9d
	ja	.L3838
	leal	-10(%r9), %edx
	addl	%r12d, 416(%rsp,%rdx,4)
	jmp	.L3834
.L3838:
	cmpl	$14, %r9d
	je	.L4192
	cmpl	$15, %r9d
	je	.L4193
	cmpl	$16, %r9d
	je	.L4194
	cmpl	$17, %r9d
	je	.L4195
	cmpl	$22, %r9d
	je	.L4196
	cmpl	$21, %r9d
	ja	.L3848
	leal	-18(%r9), %edx
	addl	%r12d, 288(%rsp,%rdx,4)
	jmp	.L3834
.L4192:
	addl	%r12d, 208(%rsp)
	jmp	.L3834
.L4193:
	addl	%r12d, 216(%rsp)
	jmp	.L3834
.L4194:
	leal	-5(%rdx), %ecx
	cmpl	$3, %ecx
	ja	.L3842
	addl	$32768, %ebx
	sarl	%ebx
.L3843:
	movl	$32767, %edx
	cmpl	%edx, %ebx
	cmovg	%edx, %ebx
	testl	%ebx, %ebx
	movl	$0, %edx
	cmovs	%edx, %ebx
	testl	%esi, %esi
	jle	.L3844
	movl	$32767, %edx
	movl	%edx, %ecx
	subl	%ebx, %ecx
	imull	%ecx, %esi
	sarl	$6, %esi
	movl	%edx, %ecx
	subl	%esi, %ecx
.L3845:
	movl	$32767, %edx
	cmpl	%edx, %ecx
	cmovle	%ecx, %edx
	testl	%edx, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	movl	212(%rsp), %ebx
	imull	%ebx, %edx
	sarl	$15, %edx
	movl	%edx, 212(%rsp)
	jmp	.L3834
.L3842:
	leal	32768(%rbx), %ecx
	sarl	%ecx
	cmpl	$9, %edx
	cmova	%ecx, %ebx
	jmp	.L3843
.L3844:
	negl	%esi
	movl	%esi, %edx
	imull	%ebx, %edx
	sarl	$6, %edx
	movl	$32767, %ecx
	subl	%edx, %ecx
	jmp	.L3845
.L4195:
	addl	%r12d, %r11d
	jmp	.L3834
.L4196:
	addl	%r12d, 224(%rsp)
	jmp	.L3834
.L3848:
	cmpl	$23, %r9d
	je	.L4197
	cmpl	$24, %r9d
	je	.L4198
	movl	220(%rsp), %ebx
	addl	%ebx, %r12d
	cmpl	$25, %r9d
	cmovne	%ebx, %r12d
	movl	%r12d, 220(%rsp)
	jmp	.L3834
.L4197:
	addl	%r12d, 228(%rsp)
	jmp	.L3834
.L4198:
	addl	%r12d, 256(%rsp)
	jmp	.L3834
.L3827:
	movq	24(%rsp), %rbx
	leaq	73(%rbx), %rax
	movq	%rbx, 128(%rsp)
	leaq	97(%rbx), %rdi
	movl	$0, 220(%rsp)
	movl	$0, 256(%rsp)
	movl	$0, 228(%rsp)
	movl	$32767, 212(%rsp)
	movl	$0, 224(%rsp)
	movl	$0, %r11d
	movl	$0, 216(%rsp)
	movl	$0, 208(%rsp)
	movl	$0, %r14d
	jmp	.L3851
.L4190:
	leaq	188(%rbp), %rdx
	movq	88(%rsp), %rax
	subq	%rdx, %rax
	sarq	$2, %rax
	movabsq	$-3513665537849438403, %rdx
	imulq	%rdx, %rax
	movq	%rax, %rbx
	movq	%rax, 248(%rsp)
	movzbl	2446(%rbp), %eax
	cmpq	%rax, %rbx
	je	.L4199
.L3853:
	movq	24(%rsp), %rbx
	movsbl	97(%rbx), %eax
	movsbl	98(%rbx), %edx
	imull	$68, %edx, %edx
	sarl	$10, %edx
	movl	%edx, 8(%rsp)
	cmpl	$64, %eax
	jle	.L3855
	movl	$127, %edx
	subl	%eax, %edx
	imull	$520, %edx, %edx
	movl	$32767, %eax
.L3856:
	movl	%edx, 280(%rsp)
	movl	%eax, 284(%rsp)
	movq	24(%rsp), %rax
	leaq	99(%rax), %rdx
	leaq	24(%rax), %rcx
	movl	$0, %esi
	jmp	.L3858
.L4199:
	movl	%r10d, %eax
	movl	%r11d, %ecx
	sarl	$15, %ecx
	movl	$63, %edx
	cmpl	%edx, %ecx
	cmovg	%edx, %ecx
	movl	$-64, %edx
	cmpl	%edx, %ecx
	cmovl	%edx, %ecx
	leaq	va_pan_off(%rip), %rdx
	movb	%cl, (%rdx,%rax)
	leaq	va_rate_off(%rip), %rax
	leaq	(%rax,%r8,4), %rsi
	movl	$0, %edx
.L3854:
	movl	288(%rsp,%rdx,4), %eax
	sarl	$14, %eax
	movl	$127, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	$-127, %ecx
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	movb	%al, (%rsi,%rdx)
	addq	$1, %rdx
	cmpq	$4, %rdx
	jne	.L3854
	jmp	.L3853
.L3855:
	cmpl	$63, %eax
	jg	.L4087
	sall	$9, %eax
	movl	$32767, %edx
	jmp	.L3856
.L4087:
	movl	$32767, %edx
	movl	$32767, %eax
	jmp	.L3856
.L3857:
	addq	$1, %rdx
	addq	$6, %rax
	cmpq	%rcx, %rax
	je	.L4200
.L3858:
	cmpb	$2, (%rdx)
	jne	.L3857
	cmpb	$2, (%rax)
	jne	.L3857
	cmpb	$0, 1(%rax)
	movl	$1, %edi
	cmovne	%edi, %esi
	jmp	.L3857
.L4200:
	movl	$0, %r13d
	testl	%esi, %esi
	je	.L3859
	movl	%r10d, %r10d
	leaq	(%r10,%r10,8), %rdx
	leaq	va_lfo(%rip), %rax
	movl	60(%rax,%rdx,8), %eax
	movl	%eax, %r13d
	sall	$4, %r13d
	subl	%eax, %r13d
	sarl	$15, %r13d
.L3859:
	movq	112(%rsp), %rax
	movl	20(%rax), %eax
	leal	-16384(%rax), %r12d
	sarl	$8, %r12d
	movq	24(%rsp), %rax
	leaq	1(%rax), %r10
	leaq	384(%rsp), %r9
	movl	$0, %edx
	movl	$0, 144(%rsp)
	leaq	SPREAD.39(%rip), %r15
	movq	%rbp, 32(%rsp)
	jmp	.L3865
.L3863:
	movl	$1, %eax
	movl	%ebp, %ecx
	sall	%cl, %eax
	orl	%eax, 144(%rsp)
.L3864:
	addq	$1, %rdx
	addq	$6, %r10
	addq	$4, %r9
	cmpq	$4, %rdx
	je	.L4201
.L3865:
	movl	%edx, %ebp
	movq	%r10, %r8
	movzbl	4(%r10), %ebx
	movl	$960, %esi
	testb	%bl, %bl
	je	.L3860
	movq	112(%rsp), %rax
	movl	4(%rax), %esi
.L3860:
	movq	%r9, %r11
	movsbl	(%r15,%rdx), %ecx
	movl	8(%rsp), %eax
	imull	%eax, %ecx
	movsbl	2(%r8), %eax
	addl	%eax, %ecx
	imull	$2621, %ecx, %ecx
	sarl	$10, %ecx
	movsbl	1(%r8), %eax
	sall	$8, %eax
	sall	$4, %esi
	addl	%esi, %eax
	addl	%ecx, %eax
	movl	%r14d, %ecx
	addl	(%r9), %ecx
	leal	(%rcx,%rcx,2), %ecx
	sarl	$11, %ecx
	addl	%ecx, %eax
	addl	%r13d, %eax
	movl	$32752, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	movl	$0, %ecx
	cmovs	%ecx, %eax
	movl	%eax, %esi
	shrl	$4, %esi
	addl	$64, %esi
	imull	$21846, %esi, %edi
	shrl	$22, %edi
	leal	(%rdi,%rdi,2), %ecx
	sall	$6, %ecx
	subl	%ecx, %esi
	movl	$10, %ecx
	subl	%edi, %ecx
	leaq	PITCH_OCT(%rip), %rdi
	movl	(%rdi,%rsi,4), %esi
	shrl	%cl, %esi
	movl	$0, %ecx
	testb	%bl, %bl
	je	.L3861
	movq	112(%rsp), %rbx
	movl	28(%rbx), %ecx
.L3861:
	andl	$15, %eax
	imull	$237, %eax, %eax
	sarl	$8, %eax
	addl	%ecx, %eax
	je	.L3862
	movl	%esi, %ecx
	shrl	$12, %ecx
	imull	%eax, %ecx
	addl	%ecx, %esi
.L3862:
	movl	%esi, 304(%rsp,%rdx,4)
	movl	16(%r11), %eax
	sarl	$14, %eax
	movsbl	(%r8), %ecx
	addl	%ecx, %eax
	movl	$127, %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	movl	$0, %ecx
	cmovs	%ecx, %eax
	movl	%ebp, %ecx
	shrl	%ecx
	movl	%ecx, %ecx
	imull	%eax, %eax
	imull	280(%rsp,%rcx,4), %eax
	addl	%eax, %eax
	sarl	$15, %eax
	movl	%eax, 320(%rsp,%rdx,4)
	movl	32(%r11), %ecx
	sarl	$14, %ecx
	movsbl	3(%r8), %esi
	addl	%esi, %ecx
	addl	%r12d, %ecx
	movl	$127, %esi
	cmpl	%esi, %ecx
	cmovg	%esi, %ecx
	testl	%ecx, %ecx
	movl	$0, %esi
	cmovs	%esi, %ecx
	imull	$258, %ecx, %esi
	movl	%esi, 336(%rsp,%rdx,4)
	movl	%ecx, 352(%rsp,%rdx,4)
	testl	%eax, %eax
	jne	.L3863
	movq	16(%rsp), %rax
	cmpw	$0, 36(%rax,%rdx,2)
	je	.L3864
	jmp	.L3863
.L4201:
	movq	32(%rsp), %rbp
	movl	144(%rsp), %eax
	testb	$2, %al
	je	.L3866
	movq	24(%rsp), %rbx
	cmpb	$0, 24(%rbx)
	je	.L3866
	orl	$1, %eax
	movl	%eax, 144(%rsp)
.L3866:
	movl	144(%rsp), %eax
	testb	$8, %al
	je	.L3867
	movq	24(%rsp), %rbx
	cmpb	$0, 25(%rbx)
	je	.L3867
	orl	$4, %eax
	movl	%eax, 144(%rsp)
.L3867:
	movl	84(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L3868
	leaq	496(%rsp), %rax
	movl	%ebx, %edx
	leaq	(%rax,%rdx,4), %rdx
.L3869:
	movl	$0, (%rax)
	addq	$4, %rax
	cmpq	%rdx, %rax
	jne	.L3869
.L3868:
	movl	308(%rsp), %eax
	movl	%eax, 188(%rsp)
	movzwl	306(%rsp), %eax
	orl	$1, %eax
	movl	%eax, 192(%rsp)
	movq	$0, 8(%rsp)
	movl	$0, 148(%rsp)
	leaq	752(%rsp), %rax
	movq	%rax, 176(%rsp)
	leaq	624(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	%rbp, 232(%rsp)
	movq	88(%rsp), %r10
	jmp	.L4026
.L3870:
	movq	16(%rsp), %rax
	movl	(%rax), %ebx
	jmp	.L3871
.L4241:
	movq	24(%rsp), %rax
	cmpb	$0, 24(%rax)
	setne	%al
	movzbl	%al, %eax
	movl	%eax, 152(%rsp)
	movl	%eax, 104(%rsp)
.L3876:
	cmpl	$3, 32(%rsp)
	jne	.L4093
	movq	24(%rsp), %rax
	cmpb	$0, 25(%rax)
	setne	%r13b
	movzbl	%r13b, %r13d
	movl	$0, 48(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, %ecx
	movl	$0, %r11d
	jmp	.L3878
.L4242:
	movq	24(%rsp), %rsi
	cmpb	$0, 24(%rsi)
	setne	%r11b
	movzbl	%r11b, %r11d
	movl	%r11d, 64(%rsp)
	movl	%eax, 48(%rsp)
	movl	%eax, 104(%rsp)
	movl	$0, %ecx
	movl	$0, 152(%rsp)
	movl	$0, %r13d
.L3878:
	movq	128(%rsp), %rax
	movq	%rax, %rsi
	movzbl	(%rax), %r9d
	movl	144(%rsp), %eax
	movl	32(%rsp), %edi
	btl	%edi, %eax
	jnc	.L4202
	movl	80(%rsp), %edi
	subl	%ebp, %edi
	movl	%edi, %eax
	sarl	$31, %eax
	andl	$31, %eax
	addl	%edi, %eax
	sarl	$5, %eax
	movl	%eax, %r14d
	movl	%edx, %r15d
	sall	$16, %r15d
	movl	100(%rsp), %eax
	sall	$16, %eax
	subl	%r15d, %eax
	sarl	$5, %eax
	movl	%eax, 40(%rsp)
	movl	96(%rsp), %edi
	subl	%r12d, %edi
	sarl	$5, %edi
	movl	%r13d, 72(%rsp)
	movsbl	%r8b, %r8d
	cmpl	$0, 104(%rsp)
	je	.L4094
	movl	188(%rsp), %eax
	movl	$0, %edx
	divl	192(%rsp)
	movl	%eax, 104(%rsp)
	cmpl	$4194304, %eax
	jbe	.L4203
	cmpl	$1, %r8d
	je	.L4139
	movl	$4194304, 104(%rsp)
	movb	$1, 60(%rsp)
	jmp	.L4080
.L4092:
	movl	$0, 104(%rsp)
	movl	$0, 152(%rsp)
	jmp	.L3876
.L4093:
	movl	$0, 48(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, %ecx
	movl	$0, %r11d
	movl	$0, %r13d
	jmp	.L3878
.L4202:
	shrl	%ebp
	movl	80(%rsp), %eax
	shrl	%eax
	addl	%eax, %ebp
	movl	84(%rsp), %eax
	imull	%eax, %ebp
	addl	%ebx, %ebp
	cmpl	$2, %edi
	ja	.L3880
	movq	8(%rsp), %rax
	movl	%ebp, 32(%r10,%rax,4)
.L3881:
	movl	80(%rsp), %edx
	movzwl	100(%rsp), %eax
	movzwl	96(%rsp), %ecx
	jmp	.L3882
.L3880:
	movq	16(%rsp), %rax
	movl	%ebp, (%rax)
	jmp	.L3881
.L4203:
	movb	$1, 60(%rsp)
	jmp	.L3883
.L4094:
	movzbl	187(%rsp), %eax
	movb	%al, 60(%rsp)
.L3883:
	cmpl	$1, %r8d
	je	.L3885
.L4080:
	cmpl	$2, %r8d
	je	.L4204
	cmpb	$8, %r9b
	ja	.L3890
	movzbl	%r9b, %r9d
	leaq	.L3891(%rip), %rdx
	movslq	(%rdx,%r9,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L3891:
	.long	.L3890-.L3891
	.long	.L3895-.L3891
	.long	.L3894-.L3891
	.long	.L3893-.L3891
	.long	.L3892-.L3891
	.long	.L3889-.L3891
	.long	.L3885-.L3891
	.long	.L3887-.L3891
	.long	.L3888-.L3891
	.text
.L4204:
	movsbl	%r9b, %eax
	cmpb	$1, %r9b
	je	.L3887
	cmpl	$2, %eax
	je	.L3888
.L3889:
	movl	52(%r10), %eax
	movl	152(%rsp), %esi
	orl	%ecx, %esi
	movl	%esi, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3964
	cmpl	$0, 84(%rsp)
	je	.L3966
	leaq	496(%rsp), %rcx
	movl	84(%rsp), %edx
	leaq	(%rcx,%rdx,4), %r8
	movl	40(%rsp), %esi
.L3972:
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$17, %eax
	xorl	%eax, %edx
	movl	%edx, %eax
	sall	$5, %eax
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$16, %edx
	subl	$32768, %edx
	movl	%r15d, %edi
	sarl	$16, %edi
	imull	%edi, %edx
	sarl	$15, %edx
	addl	%edx, (%rcx)
	addl	%esi, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %rcx
	cmpq	%r8, %rcx
	jne	.L3972
	jmp	.L3966
.L3895:
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	movl	%ecx, 152(%rsp)
	jne	.L3896
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %r11
	imull	$-58982, %edi, %r13d
	imull	$-58982, %r12d, %r12d
	leal	-2147483648(%r12), %r8d
	movl	%ebp, %r9d
	notl	%r9d
	movl	84(%rsp), %eax
	leaq	(%r11,%rax,4), %r12
	movq	%r10, 48(%rsp)
	movl	40(%rsp), %r10d
	jmp	.L3912
.L3896:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	imull	$-58982, %edi, %r13d
	imull	$-58982, %r12d, %r12d
	leal	-2147483648(%r12), %r11d
	movl	%ebp, %r12d
	notl	%r12d
	movl	%eax, %eax
	movq	%rax, 152(%rsp)
	movl	$0, %r8d
	movl	104(%rsp), %eax
	movq	%rax, 104(%rsp)
	movq	%r10, 168(%rsp)
	movl	148(%rsp), %r10d
	jmp	.L3907
.L4225:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L3901
.L4226:
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L3901
.L4227:
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L3902
.L4224:
	movl	%r10d, 148(%rsp)
	movq	168(%rsp), %r10
	jmp	.L3898
.L4229:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L3910
.L4230:
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L3910
.L4231:
	movl	$0, %edx
	divl	%edi
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L3911
.L4228:
	movq	48(%rsp), %r10
	jmp	.L3898
.L3894:
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3913
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %rax
	movl	84(%rsp), %edx
	leaq	(%rax,%rdx,4), %r9
	movl	$98303, %r8d
	movl	40(%rsp), %esi
.L3924:
	movl	%ebx, %edx
	shrl	$15, %edx
	leal	-32768(%rdx), %edi
	movl	%r8d, %ecx
	subl	%edx, %ecx
	cmpl	$65535, %edx
	cmovle	%edi, %ecx
	movl	%r15d, %edx
	sarl	$16, %edx
	imull	%ecx, %edx
	sarl	$15, %edx
	addl	%edx, (%rax)
	addl	%esi, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %rax
	cmpq	%rax, %r9
	jne	.L3924
	jmp	.L3898
.L3913:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	movl	%eax, %r9d
	movl	$0, %eax
	movl	$98303, %esi
	movl	$1, %r11d
	movl	104(%rsp), %r12d
	movl	72(%rsp), %r13d
	movq	%r10, 104(%rsp)
	movl	148(%rsp), %r10d
	movq	%r12, 72(%rsp)
	movl	40(%rsp), %r12d
	jmp	.L3921
.L3920:
	addq	$1, %rax
	cmpq	%rax, %r9
	je	.L4205
.L3921:
	movl	%eax, %ecx
	movl	%ebx, %edi
	shrl	$15, %edi
	leal	-32768(%rdi), %r8d
	movl	%esi, %edx
	subl	%edi, %edx
	cmpl	$65535, %edi
	cmovle	%r8d, %edx
	cmpl	$0, 48(%rsp)
	je	.L3917
	movl	%edx, 624(%rsp,%rax,4)
.L3917:
	testl	%r13d, %r13d
	je	.L3918
	imull	624(%rsp,%rax,4), %edx
	sarl	$15, %edx
.L3918:
	movl	%r15d, %edi
	sarl	$16, %edi
	imull	%edx, %edi
	sarl	$15, %edi
	addl	%edi, 496(%rsp,%rax,4)
	addl	%r12d, %r15d
	leal	(%rbx,%rbp), %edx
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3919
	cmpl	%ebx, %edx
	jnb	.L3919
	movl	%r11d, %edi
	sall	%cl, %edi
	orl	%edi, %r10d
	movl	%edx, 752(%rsp,%rax,4)
.L3919:
	movl	%edx, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3920
	btl	%ecx, %r10d
	jnc	.L3920
	movl	752(%rsp,%rax,4), %ebx
	movq	72(%rsp), %rcx
	imulq	%rcx, %rbx
	shrq	$16, %rbx
	jmp	.L3920
.L4205:
	movl	%r10d, 148(%rsp)
	movq	104(%rsp), %r10
	jmp	.L3898
.L3893:
	movl	%r12d, %eax
	orl	%edi, %eax
	jne	.L3925
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3926
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %rdx
	movl	84(%rsp), %eax
	leaq	(%rdx,%rax,4), %r9
	leaq	SINE(%rip), %r8
	movl	40(%rsp), %ecx
.L3933:
	movl	%ebx, %eax
	shrl	$22, %eax
	movl	%eax, %esi
	movswl	(%r8,%rsi,2), %esi
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%r8,%rax,2), %eax
	subl	%esi, %eax
	movl	%ebx, %edi
	shrl	$7, %edi
	andl	$32767, %edi
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%esi, %eax
	movl	%r15d, %esi
	sarl	$16, %esi
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, (%rdx)
	addl	%ecx, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %rdx
	cmpq	%r9, %rdx
	jne	.L3933
	jmp	.L3898
.L3926:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	movl	%eax, %esi
	movl	$0, %edx
	leaq	SINE(%rip), %r9
	movl	$1, %r11d
	movl	104(%rsp), %r12d
	movl	72(%rsp), %r13d
	movq	%r10, 104(%rsp)
	movl	148(%rsp), %r10d
	movq	%r12, 72(%rsp)
	movl	40(%rsp), %r12d
	jmp	.L3932
.L3931:
	addq	$1, %rdx
	cmpq	%rdx, %rsi
	je	.L4206
.L3932:
	movl	%edx, %ecx
	movl	%ebx, %eax
	shrl	$22, %eax
	movl	%eax, %edi
	movswl	(%r9,%rdi,2), %r8d
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%r9,%rax,2), %eax
	subl	%r8d, %eax
	movl	%ebx, %edi
	shrl	$7, %edi
	andl	$32767, %edi
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%r8d, %eax
	cmpl	$0, 48(%rsp)
	je	.L3928
	movl	%eax, 624(%rsp,%rdx,4)
.L3928:
	testl	%r13d, %r13d
	je	.L3929
	imull	624(%rsp,%rdx,4), %eax
	sarl	$15, %eax
.L3929:
	movl	%r15d, %edi
	sarl	$16, %edi
	imull	%eax, %edi
	sarl	$15, %edi
	addl	%edi, 496(%rsp,%rdx,4)
	addl	%r12d, %r15d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3930
	cmpl	%ebx, %eax
	jnb	.L3930
	movl	%r11d, %edi
	sall	%cl, %edi
	orl	%edi, %r10d
	movl	%eax, 752(%rsp,%rdx,4)
.L3930:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3931
	btl	%ecx, %r10d
	jnc	.L3931
	movl	752(%rsp,%rdx,4), %ebx
	movq	72(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
	jmp	.L3931
.L4206:
	movl	%r10d, 148(%rsp)
	movq	104(%rsp), %r10
	jmp	.L3898
.L3925:
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3934
	cmpl	$0, 84(%rsp)
	je	.L3898
	leal	(%rdi,%rdi,2), %r11d
	leal	32768(%r12,%r12,2), %edi
	leaq	496(%rsp), %rdx
	movl	84(%rsp), %eax
	leaq	(%rdx,%rax,4), %r12
	leaq	SINE(%rip), %r9
	movl	$98303, %r13d
	movq	%r10, 48(%rsp)
	movl	40(%rsp), %r10d
.L3945:
	movl	%ebx, %eax
	shrl	$22, %eax
	movl	%eax, %ecx
	movswl	(%r9,%rcx,2), %ecx
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%r9,%rax,2), %eax
	subl	%ecx, %eax
	movl	%ebx, %esi
	shrl	$7, %esi
	andl	$32767, %esi
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	sarl	$2, %ecx
	imull	%ecx, %eax
	sarl	$13, %eax
	addl	$32768, %eax
	movl	%eax, %esi
	andl	$131071, %esi
	leal	-32768(%rsi), %r8d
	movl	%r13d, %ecx
	subl	%esi, %ecx
	testl	$65536, %eax
	cmove	%r8d, %ecx
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%ecx, %eax
	sarl	$15, %eax
	addl	%eax, (%rdx)
	addl	%r10d, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addl	%r11d, %edi
	addq	$4, %rdx
	cmpq	%rdx, %r12
	jne	.L3945
	movq	48(%rsp), %r10
	jmp	.L3898
.L3934:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	leal	(%rdi,%rdi,2), %r13d
	leal	32768(%r12,%r12,2), %r12d
	movl	%eax, %eax
	movq	%rax, 152(%rsp)
	movl	$0, %edx
	leaq	SINE(%rip), %r11
	movl	$1, %esi
	movl	104(%rsp), %eax
	movq	%rax, 104(%rsp)
	movl	148(%rsp), %r9d
	movq	%r10, 168(%rsp)
	jmp	.L3942
.L3941:
	addq	$1, %rdx
	addl	%r13d, %r12d
	movq	152(%rsp), %rax
	cmpq	%rax, %rdx
	je	.L4207
.L3942:
	movl	%edx, %ecx
	movl	%ebx, %eax
	shrl	$22, %eax
	movl	%eax, %edi
	movswl	(%r11,%rdi,2), %r8d
	addl	$1, %eax
	andl	$1023, %eax
	movswl	(%r11,%rax,2), %eax
	subl	%r8d, %eax
	movl	%ebx, %edi
	shrl	$7, %edi
	andl	$32767, %edi
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%r8d, %eax
	movl	%r12d, %edi
	sarl	$2, %edi
	imull	%edi, %eax
	sarl	$13, %eax
	addl	$32768, %eax
	movl	%eax, %r8d
	andl	$131071, %r8d
	leal	-32768(%r8), %r10d
	movl	$98303, %edi
	subl	%r8d, %edi
	testl	$65536, %eax
	cmove	%r10d, %edi
	cmpl	$0, 48(%rsp)
	je	.L3938
	movl	%edi, 624(%rsp,%rdx,4)
.L3938:
	cmpl	$0, 72(%rsp)
	je	.L3939
	imull	624(%rsp,%rdx,4), %edi
	sarl	$15, %edi
.L3939:
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%edi, %eax
	sarl	$15, %eax
	addl	%eax, 496(%rsp,%rdx,4)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3940
	cmpl	%ebx, %eax
	jnb	.L3940
	movl	%esi, %edi
	sall	%cl, %edi
	orl	%edi, %r9d
	movl	%eax, 752(%rsp,%rdx,4)
.L3940:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3941
	btl	%ecx, %r9d
	jnc	.L3941
	movl	752(%rsp,%rdx,4), %ebx
	movq	104(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
	jmp	.L3941
.L4207:
	movl	%r9d, 148(%rsp)
	movq	168(%rsp), %r10
	jmp	.L3898
.L3892:
	movl	260(%rsp), %eax
	leaq	(%rax,%rax,8), %rdi
	movl	248(%rsp), %eax
	sall	$29, %eax
	leaq	va_lfo(%rip), %rdx
	addl	52(%rdx,%rdi,8), %eax
	shrl	$15, %eax
	leal	-32768(%rax), %edi
	movl	$98303, %edx
	subl	%eax, %edx
	cmpl	$65535, %eax
	cmovle	%edi, %edx
	sarl	$7, %r12d
	imull	%edx, %r12d
	imull	$88, %r12d, %eax
	leal	-2147483648(%rax), %r12d
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	movl	%ecx, %esi
	jne	.L3948
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %r13
	movl	%ebp, %r8d
	notl	%r8d
	movl	84(%rsp), %eax
	leaq	0(%r13,%rax,4), %r11
	movq	%r10, 48(%rsp)
	movl	40(%rsp), %r10d
	jmp	.L3963
.L3948:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	movl	%ebp, %r11d
	notl	%r11d
	movl	%eax, %r13d
	movl	$0, %r8d
	movl	104(%rsp), %eax
	movq	%rax, 104(%rsp)
	movq	%r10, 152(%rsp)
	movl	148(%rsp), %r10d
	jmp	.L3958
.L4233:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L3952
.L4234:
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L3952
.L4235:
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L3953
.L4232:
	movl	%r10d, 148(%rsp)
	movq	152(%rsp), %r10
	jmp	.L3898
.L4237:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L3961
.L4238:
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L3961
.L4239:
	movl	$0, %edx
	divl	%r9d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	subl	$32768, %edx
	jmp	.L3962
.L4236:
	movq	48(%rsp), %r10
	jmp	.L3898
.L3964:
	movl	84(%rsp), %ecx
	testl	%ecx, %ecx
	je	.L3966
	movl	%ecx, %r8d
	movl	$0, %edi
	movl	$1, %r9d
	movl	104(%rsp), %r11d
	movl	40(%rsp), %r12d
	movl	72(%rsp), %r13d
	movq	%r10, 72(%rsp)
	movl	148(%rsp), %r10d
	movq	%r11, 40(%rsp)
	movl	64(%rsp), %r11d
	jmp	.L3971
.L3970:
	addq	$1, %rdi
	cmpq	%r8, %rdi
	je	.L4208
.L3971:
	movl	%edi, %ecx
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$17, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	sall	$5, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$16, %edx
	subl	$32768, %edx
	cmpl	$0, 48(%rsp)
	je	.L3967
	movl	%edx, 624(%rsp,%rdi,4)
.L3967:
	testl	%r13d, %r13d
	je	.L3968
	imull	624(%rsp,%rdi,4), %edx
	sarl	$15, %edx
.L3968:
	movl	%r15d, %esi
	sarl	$16, %esi
	imull	%edx, %esi
	sarl	$15, %esi
	addl	%esi, 496(%rsp,%rdi,4)
	addl	%r12d, %r15d
	leal	(%rbx,%rbp), %edx
	addl	%r14d, %ebp
	testl	%r11d, %r11d
	je	.L3969
	cmpl	%ebx, %edx
	jnb	.L3969
	movl	%r9d, %esi
	sall	%cl, %esi
	orl	%esi, %r10d
	movl	%edx, 752(%rsp,%rdi,4)
.L3969:
	movl	%edx, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3970
	btl	%ecx, %r10d
	jnc	.L3970
	movl	752(%rsp,%rdi,4), %ebx
	movq	40(%rsp), %rcx
	imulq	%rcx, %rbx
	shrq	$16, %rbx
	jmp	.L3970
.L4208:
	movl	%r10d, 148(%rsp)
	movq	72(%rsp), %r10
.L3966:
	movl	%eax, 52(%r10)
	jmp	.L3898
.L3885:
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3973
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %r13
	movl	84(%rsp), %eax
	leaq	0(%r13,%rax,4), %rax
	movq	%rax, 48(%rsp)
	movl	%r14d, 60(%rsp)
	movl	%edi, %r14d
	movq	%r10, 64(%rsp)
.L3980:
	movl	%r12d, %edx
	movl	%ebp, %esi
	movl	%ebx, %edi
	call	va_morph
	movl	%eax, %edx
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%eax, 0(%r13)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	addl	%r14d, %r12d
	addl	%ebp, %ebx
	movl	60(%rsp), %eax
	addl	%eax, %ebp
	addq	$4, %r13
	cmpq	%r13, 48(%rsp)
	jne	.L3980
	movq	64(%rsp), %r10
	jmp	.L3898
.L4139:
	movl	$4194304, 104(%rsp)
	movb	$1, 60(%rsp)
.L3973:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	movl	%eax, %eax
	movq	%rax, 152(%rsp)
	movl	$0, %r13d
	movl	104(%rsp), %eax
	movq	%rax, 240(%rsp)
	movl	%edi, 168(%rsp)
	movq	%r10, 264(%rsp)
	jmp	.L3979
.L3978:
	addq	$1, %r13
	movq	152(%rsp), %rax
	cmpq	%rax, %r13
	je	.L4209
.L3979:
	movl	%r13d, 104(%rsp)
	movl	%r12d, %edx
	movl	%ebp, %esi
	movl	%ebx, %edi
	call	va_morph
	cmpl	$0, 48(%rsp)
	je	.L3975
	movq	160(%rsp), %rsi
	movl	%eax, (%rsi,%r13,4)
.L3975:
	cmpl	$0, 72(%rsp)
	je	.L3976
	movq	160(%rsp), %rsi
	imull	(%rsi,%r13,4), %eax
	sarl	$15, %eax
.L3976:
	movl	%r15d, %edx
	sarl	$16, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%eax, 496(%rsp,%r13,4)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	movl	168(%rsp), %eax
	addl	%eax, %r12d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3977
	cmpl	%ebx, %eax
	jnb	.L3977
	movl	$1, %edx
	movzbl	104(%rsp), %ecx
	sall	%cl, %edx
	orl	%edx, 148(%rsp)
	movq	176(%rsp), %rbx
	movl	%eax, (%rbx,%r13,4)
.L3977:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3978
	movl	148(%rsp), %eax
	movl	104(%rsp), %esi
	btl	%esi, %eax
	jnc	.L3978
	movq	176(%rsp), %rax
	movl	(%rax,%r13,4), %ebx
	movq	240(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
	jmp	.L3978
.L4209:
	movq	264(%rsp), %r10
.L3898:
	cmpl	$2, 32(%rsp)
	ja	.L4024
	movq	8(%rsp), %rax
	movl	%ebx, 32(%r10,%rax,4)
.L4025:
	movl	80(%rsp), %edx
	movzwl	100(%rsp), %eax
	movzwl	96(%rsp), %ecx
.L3882:
	movq	8(%rsp), %rbx
	movl	%edx, 56(%r10,%rbx,4)
	movq	16(%rsp), %rsi
	movw	%ax, 36(%rsi,%rbx,2)
	movw	%cx, 44(%rsi,%rbx,2)
	movq	%rbx, %rax
	addq	$1, %rax
	movq	%rax, 8(%rsp)
	addq	$6, 128(%rsp)
	cmpq	$4, %rax
	je	.L4210
.L4026:
	movq	8(%rsp), %rax
	movl	%eax, 32(%rsp)
	cmpl	$2, %eax
	ja	.L3870
	movl	32(%r10,%rax,4), %ebx
.L3871:
	movq	8(%rsp), %rdi
	movl	56(%r10,%rdi,4), %eax
	testl	%eax, %eax
	jne	.L3872
	movl	304(%rsp,%rdi,4), %ebp
	movl	%ebp, 80(%rsp)
	movq	16(%rsp), %rsi
	movzwl	36(%rsi,%rdi,2), %edx
	movl	320(%rsp,%rdi,4), %esi
	movl	%esi, 100(%rsp)
	movq	24(%rsp), %rsi
	movzbl	99(%rsi,%rdi), %r8d
	testb	%r8b, %r8b
	je	.L3873
	testl	%eax, %eax
	jne	.L3873
	movl	336(%rsp,%rdi,4), %r12d
	jmp	.L3874
.L3887:
	movl	52(%r10), %eax
	movq	8(%rsp), %rdi
	movl	352(%rsp,%rdi,4), %edx
	movl	$0, %edi
	cmpb	$0, 5(%rsi)
	je	.L3981
	movq	112(%rsp), %rsi
	movl	4(%rsi), %esi
	movl	%esi, 168(%rsp)
	leal	-960(%rsi), %edi
	leal	(%rdi,%rdi,2), %r8d
	leal	(%rdi,%r8,4), %edi
	sarl	$7, %edi
.L3981:
	addl	%edx, %edi
	movl	$127, %edx
	cmpl	%edx, %edi
	cmovg	%edx, %edi
	testl	%edi, %edi
	movl	$0, %edx
	cmovs	%edx, %edi
	movl	%edi, %r8d
	sarl	$3, %r8d
	andl	$7, %edi
	leaq	VA_BROWN_K(%rip), %rdx
	movslq	%r8d, %r9
	movzwl	(%rdx,%r9,2), %r12d
	addl	$1, %r8d
	movslq	%r8d, %r8
	movzwl	(%rdx,%r8,2), %edx
	subl	%r12d, %edx
	imull	%edi, %edx
	sarl	$3, %edx
	addl	%r12d, %edx
	leaq	VA_BROWN_G(%rip), %r12
	movzwl	(%r12,%r9,2), %r9d
	movzwl	(%r12,%r8,2), %r8d
	subl	%r9d, %r8d
	imull	%edi, %r8d
	sarl	$3, %r8d
	addl	%r9d, %r8d
	movl	152(%rsp), %esi
	orl	%ecx, %esi
	movl	%esi, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3982
	cmpl	$0, 84(%rsp)
	je	.L3984
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rsi
	movl	56(%rcx,%rsi,8), %r9d
	leaq	496(%rsp), %rdi
	movl	84(%rsp), %ecx
	leaq	(%rdi,%rcx,4), %r11
	movl	40(%rsp), %esi
.L3991:
	movl	%eax, %ecx
	sall	$13, %ecx
	xorl	%eax, %ecx
	movl	%ecx, %eax
	shrl	$17, %eax
	xorl	%eax, %ecx
	movl	%ecx, %eax
	sall	$5, %eax
	xorl	%eax, %ecx
	movl	%ecx, %eax
	shrl	$16, %ecx
	subl	$32768, %ecx
	subl	%r9d, %ecx
	imull	%edx, %ecx
	sarl	$15, %ecx
	addl	%ecx, %r9d
	movl	%r8d, %ecx
	imull	%r9d, %ecx
	sarl	$8, %ecx
	movl	$32767, %r12d
	cmpl	%r12d, %ecx
	cmovg	%r12d, %ecx
	movl	$-32767, %r12d
	cmpl	%r12d, %ecx
	cmovl	%r12d, %ecx
	movl	%r15d, %r12d
	sarl	$16, %r12d
	imull	%r12d, %ecx
	sarl	$15, %ecx
	addl	(%rdi), %ecx
	movl	%ecx, (%rdi)
	addl	%esi, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %rdi
	cmpq	%rdi, %r11
	jne	.L3991
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	movl	%r9d, 56(%rsi,%rdi,8)
	movl	84(%rsp), %esi
	leal	-1(%rsi), %edx
	movl	%ecx, 496(%rsp,%rdx,4)
.L3984:
	movl	%eax, 52(%r10)
	jmp	.L3898
.L3982:
	movl	84(%rsp), %ecx
	testl	%ecx, %ecx
	je	.L3984
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	movl	56(%rsi,%rdi,8), %r12d
	movl	%ecx, %r11d
	movl	$0, %r9d
	movl	$1, %r13d
	movl	104(%rsp), %ecx
	movq	%rcx, 104(%rsp)
	movq	%r10, 152(%rsp)
	movl	148(%rsp), %r10d
	jmp	.L3989
.L3988:
	addq	$1, %r9
	cmpq	%r11, %r9
	je	.L4211
.L3989:
	movl	%r9d, %ecx
	movl	%eax, %esi
	sall	$13, %esi
	xorl	%eax, %esi
	movl	%esi, %eax
	shrl	$17, %eax
	xorl	%esi, %eax
	movl	%eax, %esi
	sall	$5, %esi
	xorl	%eax, %esi
	movl	%esi, %eax
	shrl	$16, %esi
	subl	$32768, %esi
	subl	%r12d, %esi
	imull	%edx, %esi
	sarl	$15, %esi
	addl	%esi, %r12d
	movl	%r8d, %esi
	imull	%r12d, %esi
	sarl	$8, %esi
	movl	$32767, %edi
	cmpl	%edi, %esi
	cmovg	%edi, %esi
	movl	$-32767, %edi
	cmpl	%edi, %esi
	cmovl	%edi, %esi
	cmpl	$0, 48(%rsp)
	je	.L3985
	movl	%esi, 624(%rsp,%r9,4)
.L3985:
	cmpl	$0, 72(%rsp)
	je	.L3986
	imull	624(%rsp,%r9,4), %esi
	sarl	$15, %esi
.L3986:
	movl	%r15d, %edi
	sarl	$16, %edi
	imull	%esi, %edi
	sarl	$15, %edi
	addl	%edi, 496(%rsp,%r9,4)
	movl	40(%rsp), %esi
	addl	%esi, %r15d
	leal	(%rbx,%rbp), %esi
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3987
	cmpl	%ebx, %esi
	jnb	.L3987
	movl	%r13d, %edi
	sall	%cl, %edi
	orl	%edi, %r10d
	movl	%esi, 752(%rsp,%r9,4)
.L3987:
	movl	%esi, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3988
	btl	%ecx, %r10d
	jnc	.L3988
	movl	752(%rsp,%r9,4), %ebx
	movq	104(%rsp), %rcx
	imulq	%rcx, %rbx
	shrq	$16, %rbx
	jmp	.L3988
.L4211:
	movl	%r10d, 148(%rsp)
	movq	152(%rsp), %r10
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rsi
	movl	%r12d, 56(%rcx,%rsi,8)
	jmp	.L3984
.L3888:
	movl	52(%r10), %eax
	movq	8(%rsp), %rsi
	movl	352(%rsp,%rsi,4), %edx
	movl	%edx, %edi
	imull	%edx, %edi
	imull	%edi, %edx
	movl	$2513169435, %r8d
	imulq	%r8, %rdx
	shrq	$44, %rdx
	leal	2(%rdx), %r8d
	movl	152(%rsp), %esi
	orl	%ecx, %esi
	movl	%esi, %ecx
	orl	%r11d, %ecx
	orl	%r13d, %ecx
	jne	.L3992
	cmpl	$0, 84(%rsp)
	je	.L3994
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rsi
	movl	60(%rcx,%rsi,8), %r9d
	movl	56(%rcx,%rsi,8), %ecx
	leaq	496(%rsp), %rdi
	movl	84(%rsp), %edx
	leaq	(%rdi,%rdx,4), %r11
	movl	40(%rsp), %esi
	jmp	.L4005
.L3992:
	movl	84(%rsp), %ecx
	testl	%ecx, %ecx
	je	.L3994
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	movl	60(%rsi,%rdi,8), %r12d
	movl	56(%rsi,%rdi,8), %r9d
	movl	%ecx, %r11d
	movl	$0, %edi
	movl	$1, %r13d
	movl	104(%rsp), %ecx
	movq	%rcx, 104(%rsp)
	movq	%r10, 152(%rsp)
	movl	148(%rsp), %r10d
	jmp	.L4001
.L3995:
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$17, %eax
	xorl	%edx, %eax
	movl	%eax, %r9d
	sall	$5, %r9d
	xorl	%eax, %r9d
	movl	%r9d, %eax
	shrl	$16, %r9d
	subl	$32768, %r9d
	jmp	.L3996
.L4000:
	addq	$1, %rdi
	cmpq	%r11, %rdi
	je	.L4212
.L4001:
	movl	%edi, %ecx
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%eax, %edx
	movl	%edx, %eax
	shrl	$17, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	sall	$5, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$16, %edx
	subl	$32768, %edx
	subl	%r12d, %edx
	imull	$10000, %edx, %edx
	sarl	$15, %edx
	addl	%edx, %r12d
	movzwl	%ax, %edx
	cmpl	%r8d, %edx
	jb	.L3995
	movl	%r9d, %edx
	sarl	$3, %edx
	testl	%r9d, %r9d
	setg	%sil
	movzbl	%sil, %esi
	addl	%esi, %edx
	subl	%edx, %r9d
.L3996:
	movl	%r12d, %edx
	sarl	$3, %edx
	addl	%r9d, %edx
	movl	$32767, %esi
	cmpl	%esi, %edx
	cmovg	%esi, %edx
	movl	$-32767, %esi
	cmpl	%esi, %edx
	cmovl	%esi, %edx
	cmpl	$0, 48(%rsp)
	je	.L3997
	movl	%edx, 624(%rsp,%rdi,4)
.L3997:
	cmpl	$0, 72(%rsp)
	je	.L3998
	imull	624(%rsp,%rdi,4), %edx
	sarl	$15, %edx
.L3998:
	movl	%r15d, %esi
	sarl	$16, %esi
	imull	%edx, %esi
	sarl	$15, %esi
	addl	%esi, 496(%rsp,%rdi,4)
	movl	40(%rsp), %esi
	addl	%esi, %r15d
	leal	(%rbx,%rbp), %edx
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3999
	cmpl	%ebx, %edx
	jnb	.L3999
	movl	%r13d, %esi
	sall	%cl, %esi
	orl	%esi, %r10d
	movl	%edx, 752(%rsp,%rdi,4)
.L3999:
	movl	%edx, %ebx
	cmpb	$0, 60(%rsp)
	je	.L4000
	btl	%ecx, %r10d
	jnc	.L4000
	movl	752(%rsp,%rdi,4), %ebx
	movq	104(%rsp), %rcx
	imulq	%rcx, %rbx
	shrq	$16, %rbx
	jmp	.L4000
.L4003:
	movl	%eax, %ecx
	sall	$13, %ecx
	xorl	%eax, %ecx
	movl	%ecx, %eax
	shrl	$17, %eax
	xorl	%eax, %ecx
	movl	%ecx, %eax
	sall	$5, %eax
	xorl	%eax, %ecx
	movl	%ecx, %eax
	shrl	$16, %ecx
	subl	$32768, %ecx
.L4004:
	movl	%r9d, %edx
	sarl	$3, %edx
	addl	%ecx, %edx
	movl	$32767, %r12d
	cmpl	%r12d, %edx
	cmovg	%r12d, %edx
	movl	$-32767, %r12d
	cmpl	%r12d, %edx
	cmovl	%r12d, %edx
	movl	%r15d, %r12d
	sarl	$16, %r12d
	imull	%r12d, %edx
	sarl	$15, %edx
	addl	(%rdi), %edx
	movl	%edx, (%rdi)
	addl	%esi, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %rdi
	cmpq	%r11, %rdi
	je	.L4213
.L4005:
	movl	%eax, %edx
	sall	$13, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	sall	$5, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$16, %edx
	subl	$32768, %edx
	subl	%r9d, %edx
	imull	$10000, %edx, %edx
	sarl	$15, %edx
	addl	%edx, %r9d
	movzwl	%ax, %edx
	cmpl	%r8d, %edx
	jb	.L4003
	movl	%ecx, %edx
	sarl	$3, %edx
	testl	%ecx, %ecx
	setg	%r12b
	movzbl	%r12b, %r12d
	addl	%r12d, %edx
	subl	%edx, %ecx
	jmp	.L4004
.L4213:
	movq	16(%rsp), %rsi
	movq	8(%rsp), %rdi
	movl	%ecx, 56(%rsi,%rdi,8)
	movl	84(%rsp), %ecx
	leal	-1(%rcx), %ecx
	movl	%edx, 496(%rsp,%rcx,4)
	movl	%r9d, 60(%rsi,%rdi,8)
.L3994:
	movl	%eax, 52(%r10)
	jmp	.L3898
.L4212:
	movl	%r10d, 148(%rsp)
	movq	152(%rsp), %r10
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rsi
	movl	%r9d, 56(%rcx,%rsi,8)
	movl	%r12d, 60(%rcx,%rsi,8)
	jmp	.L3994
.L3890:
	movl	152(%rsp), %eax
	orl	%ecx, %eax
	movl	%eax, %ecx
	orl	%r11d, %ecx
	orl	%ecx, %r13d
	jne	.L4006
	cmpl	$0, 84(%rsp)
	je	.L3898
	leaq	496(%rsp), %r9
	movl	%ebp, %ecx
	notl	%ecx
	movl	84(%rsp), %eax
	leaq	(%r9,%rax,4), %r11
	movl	40(%rsp), %esi
	movq	%r10, 40(%rsp)
	jmp	.L4023
.L4006:
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L3898
	movl	%ebp, %r11d
	notl	%r11d
	movl	%eax, %r13d
	movl	$0, %r8d
	movl	104(%rsp), %eax
	movq	%rax, 104(%rsp)
	movl	148(%rsp), %esi
	movq	%r10, 152(%rsp)
	jmp	.L4017
.L4215:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
	jmp	.L4008
.L4216:
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L4008
.L4016:
	addq	$1, %r8
	subl	%r14d, %r11d
	cmpq	%r8, %r13
	je	.L4214
.L4017:
	movl	%r8d, %ecx
	movl	%ebx, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %r9d
	movl	$0, %eax
	movl	%ebp, %r10d
	shrl	$15, %r10d
	je	.L4008
	cmpl	%ebp, %ebx
	jb	.L4215
	movl	$0, %eax
	cmpl	%ebx, %r11d
	jb	.L4216
.L4008:
	movl	%r9d, %edx
	subl	%eax, %edx
	movl	%r12d, %eax
	testl	%r12d, %r12d
	je	.L4010
	movl	%ebx, %r9d
	shrl	$15, %r9d
	leal	-32768(%r9), %r10d
	movl	$98303, %eax
	subl	%r9d, %eax
	cmpl	$65535, %r9d
	cmovle	%r10d, %eax
	subl	%edx, %eax
	movl	%r12d, %r9d
	sarl	$3, %r9d
	imull	%r9d, %eax
	sarl	$12, %eax
.L4010:
	addl	%edx, %eax
	cmpl	$0, 48(%rsp)
	je	.L4013
	movl	%eax, 624(%rsp,%r8,4)
.L4013:
	cmpl	$0, 72(%rsp)
	je	.L4014
	imull	624(%rsp,%r8,4), %eax
	sarl	$15, %eax
.L4014:
	movl	%r15d, %edx
	sarl	$16, %edx
	imull	%edx, %eax
	sarl	$15, %eax
	addl	%eax, 496(%rsp,%r8,4)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	addl	%edi, %r12d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L4015
	cmpl	%ebx, %eax
	jnb	.L4015
	movl	$1, %edx
	sall	%cl, %edx
	orl	%edx, %esi
	movl	%eax, 752(%rsp,%r8,4)
.L4015:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L4016
	btl	%ecx, %esi
	jnc	.L4016
	movl	752(%rsp,%r8,4), %ebx
	movq	104(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
	jmp	.L4016
.L4214:
	movl	%esi, 148(%rsp)
	movq	152(%rsp), %r10
	jmp	.L3898
.L4218:
	movl	%ebx, %eax
	movl	$0, %edx
	divl	%r10d
	leal	(%rax,%rax), %edx
	imull	%eax, %eax
	sarl	$15, %eax
	subl	%eax, %edx
	leal	-32768(%rdx), %eax
.L4018:
	movl	%r8d, %edx
	subl	%eax, %edx
	movl	%r12d, %eax
	testl	%r12d, %r12d
	je	.L4020
	movl	%ebx, %r8d
	shrl	$15, %r8d
	leal	-32768(%r8), %r10d
	movl	$98303, %eax
	subl	%r8d, %eax
	cmpl	$65535, %r8d
	cmovle	%r10d, %eax
	subl	%edx, %eax
	movl	%r12d, %r8d
	sarl	$3, %r8d
	imull	%r8d, %eax
	sarl	$12, %eax
.L4020:
	movl	%r15d, %r8d
	sarl	$16, %r8d
	addl	%edx, %eax
	imull	%eax, %r8d
	sarl	$15, %r8d
	addl	%r8d, (%r9)
	addl	%esi, %r15d
	addl	%edi, %r12d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %r9
	subl	%r14d, %ecx
	cmpq	%r9, %r11
	je	.L4217
.L4023:
	movl	%ebx, %edx
	shrl	$16, %edx
	leal	-32768(%rdx), %r8d
	movl	%r13d, %eax
	movl	%ebp, %r10d
	shrl	$15, %r10d
	je	.L4018
	cmpl	%ebp, %ebx
	jb	.L4218
	cmpl	%ebx, %ecx
	jnb	.L4018
	movl	%ebx, %eax
	notl	%eax
	movl	$0, %edx
	divl	%r10d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	leal	32768(%rdx), %eax
	jmp	.L4018
.L4217:
	movq	40(%rsp), %r10
	jmp	.L3898
.L4024:
	movq	16(%rsp), %rax
	movl	%ebx, (%rax)
	jmp	.L4025
.L4210:
	movq	232(%rsp), %rbp
	movq	24(%rsp), %rsi
	movsbl	27(%rsi), %edx
	sall	$8, %edx
	movl	372(%rsp), %eax
	movl	220(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L4027
	movsbl	31(%rsi), %esi
	sarl	$15, %ebx
	addl	%ebx, %esi
	movl	$63, %ecx
	cmpl	%ecx, %esi
	cmovg	%ecx, %esi
	movl	$-64, %ecx
	cmpl	%ecx, %esi
	cmovl	%ecx, %esi
.L4028:
	movq	112(%rsp), %r10
	movl	4(%r10), %ebx
	movl	%ebx, 8(%rsp)
	leal	-960(%rbx), %ecx
	movq	24(%rsp), %rbx
	movsbl	30(%rbx), %edi
	imull	%edi, %ecx
	imull	$150, %ecx, %ecx
	sarl	$10, %ecx
	imull	%esi, %eax
	sarl	$6, %eax
	addl	%edx, %eax
	addl	%eax, %ecx
	addl	16(%r10), %ecx
	movl	208(%rsp), %eax
	sarl	$7, %eax
	addl	%eax, %ecx
	movsbl	28(%rbx), %eax
	movl	216(%rsp), %edx
	sarl	$14, %edx
	addl	%edx, %eax
	movl	$127, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movl	%eax, %edx
	sall	$4, %edx
	subl	%edx, %eax
	leal	8192(,%rax,4), %eax
	movl	%eax, 32(%rsp)
	movl	256(%rsp), %eax
	testl	%eax, %eax
	je	.L4029
	movsbl	104(%rbx), %edx
	sarl	$14, %eax
	addl	%eax, %edx
	js	.L4030
	movl	$127, %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	%eax, 8(%rsp)
	jmp	.L4031
.L4027:
	movq	24(%rsp), %rbx
	movsbl	31(%rbx), %esi
	jmp	.L4028
.L4029:
	movq	24(%rsp), %rax
	movsbl	104(%rax), %eax
	movl	%eax, 8(%rsp)
.L4031:
	cmpl	$0, 8(%rsp)
	jne	.L4219
.L4030:
	movl	$32512, %eax
	cmpl	%eax, %ecx
	cmovle	%ecx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movl	%eax, %edx
	sarl	$8, %edx
	movslq	%edx, %rsi
	leaq	SVF_G(%rip), %rcx
	movzwl	(%rcx,%rsi,2), %ecx
	cmpl	$126, %edx
	jg	.L4035
	addl	$1, %edx
	movslq	%edx, %rdx
	leaq	SVF_G(%rip), %rsi
	movzwl	(%rsi,%rdx,2), %edx
	subl	%ecx, %edx
	movzbl	%al, %eax
	imull	%edx, %eax
	sarl	$8, %eax
	addl	%eax, %ecx
.L4035:
	movl	32(%rsp), %eax
	leal	(%rax,%rcx), %esi
	imull	%ecx, %esi
	sarl	$12, %esi
	addl	$4096, %esi
	movl	$33554432, %eax
	movl	$0, %edx
	divl	%esi
	movl	%eax, 60(%rsp)
	imull	%ecx, %eax
	sarl	$12, %eax
	movl	%eax, %r13d
	imull	%eax, %ecx
	sarl	$12, %ecx
	movl	%ecx, 64(%rsp)
	movl	$0, 8(%rsp)
.L4034:
	movl	224(%rsp), %edi
	sarl	$6, %edi
	movl	$32767, %eax
	cmpl	%eax, %edi
	cmovg	%eax, %edi
	movl	$-32767, %eax
	cmpl	%eax, %edi
	cmovl	%eax, %edi
	movq	24(%rsp), %rax
	movsbl	26(%rax), %eax
	sall	$8, %eax
	addl	%eax, %edi
	movl	%edi, %r11d
	andl	$32767, %r11d
	movl	$0, 40(%rsp)
	cmpq	$0, 136(%rsp)
	je	.L4036
	cmpw	$3, 74(%rbp)
	je	.L4220
.L4036:
	movq	88(%rsp), %rax
	movzbl	80(%rax), %eax
	testb	%al, %al
	je	.L4037
	movzbl	%al, %eax
.L4038:
	movl	$127, %edx
	subl	%eax, %edx
	movq	24(%rsp), %rax
	movsbl	52(%rax), %eax
	imull	%eax, %edx
	imull	$2080, %edx, %edx
	sarl	$10, %edx
	movl	$32767, %eax
	subl	%edx, %eax
	imull	368(%rsp), %eax
	sarl	$15, %eax
	movl	212(%rsp), %ebx
	imull	%ebx, %eax
	sarl	$15, %eax
	cmpw	$3, 74(%rbp)
	je	.L4221
.L4039:
	movq	112(%rsp), %rbx
	imull	12(%rbx), %eax
	sarl	$15, %eax
	movl	%eax, 100(%rsp)
	movq	88(%rsp), %rbx
	movl	72(%rbx), %r10d
	subl	%r10d, %eax
	sarl	$5, %eax
	movl	%eax, 48(%rsp)
	movl	44(%rbx), %esi
	movl	48(%rbx), %ecx
	movl	228(%rsp), %eax
	testl	%eax, %eax
	je	.L4040
	movq	24(%rsp), %rbx
	movsbl	29(%rbx), %edx
	sarl	$14, %eax
	leal	(%rdx,%rax), %r15d
	movl	$127, %eax
	cmpl	%eax, %r15d
	cmovg	%eax, %r15d
	testl	%r15d, %r15d
	movl	$0, %eax
	cmovs	%eax, %r15d
.L4041:
	imull	$97, %r15d, %eax
	leal	4096(%rax), %r14d
	movl	%r11d, %r9d
	shrl	$13, %r9d
	movq	24(%rsp), %rax
	cmpb	$0, 24(%rax)
	je	.L4042
	movq	16(%rsp), %rax
	movl	52(%rax), %r8d
	movl	84(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L4043
	leaq	496(%rsp), %rax
	movl	%ebx, %edx
	leaq	(%rax,%rdx,4), %rbx
.L4044:
	movl	%r8d, %ebp
	sarl	$8, %ebp
	movl	(%rax), %edx
	subl	%ebp, %edx
	movl	%edx, (%rax)
	addl	%edx, %r8d
	addq	$4, %rax
	cmpq	%rbx, %rax
	jne	.L4044
.L4043:
	movq	16(%rsp), %rax
	movl	%r8d, 52(%rax)
.L4042:
	andl	$8191, %edi
	movl	8(%rsp), %eax
	orl	%eax, %edi
	orl	40(%rsp), %edi
	jne	.L4045
	movq	16(%rsp), %rax
	movb	$0, 96(%rax)
	movl	84(%rsp), %eax
	testl	%eax, %eax
	je	.L4046
	sarl	$4, %r14d
	movl	%eax, %eax
	leaq	0(,%rax,4), %r12
	movl	$0, %r8d
	leaq	TANH_Q15(%rip), %rbp
	movl	%r14d, 16(%rsp)
	movl	64(%rsp), %ebx
	movq	120(%rsp), %r11
	jmp	.L4055
.L4219:
	imull	$7235, 8(%rsp), %esi
	sarl	$8, %esi
	movl	%ecx, %eax
	subl	%esi, %eax
	movl	$32512, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movl	%eax, %edx
	sarl	$8, %edx
	movslq	%edx, %r8
	leaq	SVF_G(%rip), %rdi
	movzwl	(%rdi,%r8,2), %edi
	cmpl	$126, %edx
	jg	.L4032
	addl	$1, %edx
	movslq	%edx, %rdx
	leaq	SVF_G(%rip), %r8
	movzwl	(%r8,%rdx,2), %edx
	subl	%edi, %edx
	movzbl	%al, %eax
	imull	%eax, %edx
	sarl	$8, %edx
	addl	%edx, %edi
.L4032:
	movl	32(%rsp), %eax
	leal	(%rax,%rdi), %r8d
	imull	%edi, %r8d
	sarl	$12, %r8d
	addl	$4096, %r8d
	movl	$33554432, %eax
	movl	$0, %edx
	divl	%r8d
	movl	%eax, 60(%rsp)
	imull	%edi, %eax
	sarl	$12, %eax
	movl	%eax, %r13d
	imull	%eax, %edi
	sarl	$12, %edi
	movl	%edi, 64(%rsp)
	addl	%esi, %ecx
	movl	$32512, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	testl	%ecx, %ecx
	movl	$0, %eax
	cmovs	%eax, %ecx
	movl	%ecx, %eax
	sarl	$8, %eax
	movslq	%eax, %rsi
	leaq	SVF_G(%rip), %rdx
	movzwl	(%rdx,%rsi,2), %esi
	cmpl	$126, %eax
	jg	.L4033
	addl	$1, %eax
	cltq
	movzwl	(%rdx,%rax,2), %eax
	subl	%esi, %eax
	movzbl	%cl, %ecx
	imull	%ecx, %eax
	sarl	$8, %eax
	addl	%eax, %esi
.L4033:
	movl	32(%rsp), %eax
	leal	(%rax,%rsi), %ecx
	imull	%esi, %ecx
	sarl	$12, %ecx
	addl	$4096, %ecx
	movl	$33554432, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, 196(%rsp)
	imull	%esi, %eax
	sarl	$12, %eax
	movl	%eax, 204(%rsp)
	imull	%eax, %esi
	sarl	$12, %esi
	movl	%esi, 200(%rsp)
	jmp	.L4034
.L4220:
	movq	24(%rsp), %rax
	movzbl	105(%rax), %eax
	testb	%al, %al
	je	.L4036
	movq	248(%rsp), %rbx
	leal	-7(%rbx,%rbx), %edx
	movsbl	%al, %eax
	imull	%edx, %eax
	leal	(%rax,%rax,8), %edx
	leal	(%rax,%rdx,4), %edx
	movl	$32767, %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	$-32767, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	sarl	$4, %eax
	movl	%eax, 40(%rsp)
	jmp	.L4036
.L4037:
	movq	88(%rsp), %rax
	movzbl	1(%rax), %eax
	jmp	.L4038
.L4221:
	imull	$13107, %eax, %eax
	sarl	$15, %eax
	jmp	.L4039
.L4040:
	movq	24(%rsp), %rax
	movsbl	29(%rax), %r15d
	jmp	.L4041
.L4049:
	movl	32(%rsp), %r14d
	imull	%r14d, %edi
	sarl	$12, %edi
	subl	%edi, %eax
	subl	%edx, %eax
	movl	%eax, %edx
.L4051:
	movl	$200000, %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	$-200000, %edi
	cmpl	%edi, %eax
	cmovl	%edi, %eax
	movl	%eax, %edi
	negl	%edi
	cmovs	%eax, %edi
	cmpl	$16000, %edi
	jle	.L4052
	leal	-32000(%rdi,%rdi), %edi
	movl	%edi, %eax
	negl	%eax
	cmovs	%edi, %eax
	movl	%eax, %r14d
	sarl	$8, %r14d
	movl	$31588, %edi
	cmpl	$65535, %eax
	jg	.L4053
	movslq	%r14d, %rdi
	movswl	0(%rbp,%rdi,2), %edi
	addl	$1, %r14d
	movslq	%r14d, %r14
	movswl	0(%rbp,%r14,2), %r14d
	subl	%edi, %r14d
	movzbl	%al, %eax
	imull	%eax, %r14d
	sarl	$8, %r14d
	addl	%r14d, %edi
.L4053:
	sarl	%edi
	leal	16000(%rdi), %r14d
	movl	$-16000, %eax
	subl	%edi, %eax
	testl	%edx, %edx
	cmovns	%r14d, %eax
.L4052:
	movl	48(%rsp), %edi
	addl	%edi, %r10d
	imull	%r10d, %eax
	sarl	$15, %eax
	imull	$6000, %eax, %eax
	sarl	$11, %eax
	addl	%eax, (%r11,%r8)
	addq	$4, %r8
	cmpq	%r8, %r12
	je	.L4046
.L4055:
	movl	496(%rsp,%r8), %eax
	sarl	%eax
	testl	%r15d, %r15d
	je	.L4047
	movl	16(%rsp), %edx
	imull	%eax, %edx
	sarl	$8, %edx
	movl	%edx, %edi
	negl	%edi
	cmovs	%edx, %edi
	movl	%edi, %r14d
	sarl	$8, %r14d
	movl	$31588, %eax
	cmpl	$65535, %edi
	jg	.L4048
	movslq	%r14d, %rax
	movswl	0(%rbp,%rax,2), %eax
	addl	$1, %r14d
	movslq	%r14d, %r14
	movswl	0(%rbp,%r14,2), %r14d
	subl	%eax, %r14d
	movzbl	%dil, %edi
	imull	%edi, %r14d
	sarl	$8, %r14d
	addl	%r14d, %eax
.L4048:
	movl	%eax, %edi
	negl	%edi
	testl	%edx, %edx
	cmovs	%edi, %eax
.L4047:
	movl	%eax, %r14d
	subl	%ecx, %r14d
	movl	60(%rsp), %edi
	imull	%esi, %edi
	movl	%r14d, %edx
	imull	%r13d, %edx
	addl	%edx, %edi
	sarl	$13, %edi
	movl	%r13d, %edx
	imull	%esi, %edx
	imull	%ebx, %r14d
	addl	%r14d, %edx
	sarl	$13, %edx
	addl	%ecx, %edx
	leal	(%rdi,%rdi), %r14d
	subl	%esi, %r14d
	movl	%r14d, %esi
	movl	$150000, %r14d
	cmpl	%r14d, %esi
	cmovg	%r14d, %esi
	movl	$-150000, %r14d
	cmpl	%r14d, %esi
	cmovl	%r14d, %esi
	leal	(%rdx,%rdx), %r14d
	subl	%ecx, %r14d
	movl	%r14d, %ecx
	movl	$150000, %r14d
	cmpl	%r14d, %ecx
	cmovg	%r14d, %ecx
	movl	$-150000, %r14d
	cmpl	%r14d, %ecx
	cmovl	%r14d, %ecx
	cmpl	$2, %r9d
	je	.L4049
	cmpl	$3, %r9d
	je	.L4050
	cmpl	$1, %r9d
	jne	.L4051
	movl	32(%rsp), %eax
	imull	%eax, %edi
	sarl	$12, %edi
	movl	%edi, %edx
	jmp	.L4051
.L4050:
	movl	32(%rsp), %edx
	imull	%edx, %edi
	sarl	$12, %edi
	subl	%edi, %eax
	movl	%eax, %edx
	jmp	.L4051
.L4045:
	sarl	$3, %r11d
	andl	$1023, %r11d
	movl	%r9d, %eax
	leaq	(%rax,%rax,2), %rdx
	leaq	VA_FW(%rip), %rdi
	addq	%rdi, %rdx
	addl	$1, %r9d
	andl	$3, %r9d
	leaq	(%r9,%r9,2), %rax
	addq	%rdi, %rax
	movsbl	(%rdx), %r8d
	movsbl	(%rax), %edi
	subl	%r8d, %edi
	imull	%r11d, %edi
	sall	$10, %r8d
	leal	(%rdi,%r8), %ebx
	movl	%ebx, 80(%rsp)
	movsbl	1(%rdx), %edi
	movsbl	1(%rax), %ebp
	subl	%edi, %ebp
	imull	%r11d, %ebp
	sall	$10, %edi
	addl	%edi, %ebp
	movsbl	2(%rdx), %edx
	movsbl	2(%rax), %r12d
	subl	%edx, %r12d
	imull	%r11d, %r12d
	sall	$10, %edx
	addl	%edx, %r12d
	cmpl	$0, 8(%rsp)
	je	.L4056
	movq	16(%rsp), %rax
	cmpb	$0, 96(%rax)
	jne	.L4057
	movl	%esi, 88(%rax)
	movl	%ecx, 92(%rax)
	movb	$1, 96(%rax)
.L4057:
	movq	16(%rsp), %rax
	movl	88(%rax), %ebx
	movl	92(%rax), %r11d
	cmpl	$0, 84(%rsp)
	je	.L4059
.L4058:
	sarl	$4, %r14d
	movl	%r14d, 96(%rsp)
	movl	84(%rsp), %eax
	salq	$2, %rax
	movq	%rax, 72(%rsp)
	movl	$0, %r8d
	movl	%r15d, 84(%rsp)
	movl	%ebp, 24(%rsp)
	jmp	.L4071
.L4056:
	movq	16(%rsp), %rax
	movb	$0, 96(%rax)
	cmpl	$0, 84(%rsp)
	je	.L4046
	movl	8(%rsp), %ebx
	movl	%ebx, %r11d
	jmp	.L4058
.L4062:
	movl	%edi, %edx
	negl	%edx
	testl	%eax, %eax
	cmovs	%edx, %edi
.L4061:
	movl	%edi, %r14d
	subl	%ecx, %r14d
	movl	60(%rsp), %edx
	imull	%esi, %edx
	movl	%r14d, %eax
	imull	%r13d, %eax
	addl	%eax, %edx
	sarl	$13, %edx
	movl	%r13d, %r9d
	imull	%esi, %r9d
	movl	64(%rsp), %eax
	imull	%eax, %r14d
	addl	%r14d, %r9d
	sarl	$13, %r9d
	addl	%ecx, %r9d
	leal	(%rdx,%rdx), %eax
	subl	%esi, %eax
	movl	%eax, %esi
	movl	$150000, %eax
	cmpl	%eax, %esi
	cmovg	%eax, %esi
	movl	$-150000, %eax
	cmpl	%eax, %esi
	cmovl	%eax, %esi
	leal	(%r9,%r9), %eax
	subl	%ecx, %eax
	movl	%eax, %ecx
	movl	$150000, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	movl	$-150000, %eax
	cmpl	%eax, %ecx
	cmovl	%eax, %ecx
	movl	80(%rsp), %r14d
	imull	%edi, %r14d
	movl	32(%rsp), %eax
	imull	%edx, %eax
	sarl	$12, %eax
	movl	24(%rsp), %edx
	imull	%edx, %eax
	addl	%r14d, %eax
	imull	%r12d, %r9d
	addl	%r9d, %eax
	sarl	$10, %eax
	movl	$200000, %edx
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	movl	$-200000, %r9d
	cmpl	%r9d, %edx
	cmovl	%r9d, %edx
	movl	%edx, %r9d
	negl	%r9d
	cmovs	%edx, %r9d
	cmpl	$16000, %r9d
	jle	.L4063
	leal	-32000(%r9,%r9), %r9d
	movl	%r9d, %edx
	negl	%edx
	cmovs	%r9d, %edx
	movl	%edx, %r15d
	sarl	$8, %r15d
	movl	$31588, %r9d
	cmpl	$65535, %edx
	jg	.L4064
	movslq	%r15d, %r9
	leaq	TANH_Q15(%rip), %rbp
	movswl	0(%rbp,%r9,2), %r9d
	addl	$1, %r15d
	movslq	%r15d, %r15
	movswl	0(%rbp,%r15,2), %r15d
	subl	%r9d, %r15d
	movzbl	%dl, %edx
	imull	%edx, %r15d
	sarl	$8, %r15d
	addl	%r15d, %r9d
.L4064:
	sarl	%r9d
	leal	16000(%r9), %r15d
	movl	$-16000, %edx
	subl	%r9d, %edx
	testl	%eax, %eax
	cmovns	%r15d, %edx
.L4063:
	movl	48(%rsp), %eax
	addl	%eax, %r10d
	cmpl	$0, 8(%rsp)
	jne	.L4222
	imull	%r10d, %edx
	sarl	$15, %edx
	imull	$6000, %edx, %edx
	movl	%edx, %eax
	sarl	$11, %eax
	movl	40(%rsp), %edi
	testl	%edi, %edi
	je	.L4070
	movl	%edi, %edx
	imull	%eax, %edx
	sarl	$11, %edx
	movq	136(%rsp), %rdi
	addl	%edx, (%rdi,%r8)
.L4070:
	movq	120(%rsp), %rdi
	addl	%eax, (%rdi,%r8)
	addq	$4, %r8
	cmpq	%r8, 72(%rsp)
	je	.L4223
.L4071:
	movl	496(%rsp,%r8), %edi
	sarl	%edi
	cmpl	$0, 84(%rsp)
	je	.L4061
	movl	96(%rsp), %eax
	imull	%edi, %eax
	sarl	$8, %eax
	movl	%eax, %edx
	negl	%edx
	cmovs	%eax, %edx
	movl	%edx, %r9d
	sarl	$8, %r9d
	movl	$31588, %edi
	cmpl	$65535, %edx
	jg	.L4062
	movslq	%r9d, %rdi
	leaq	TANH_Q15(%rip), %r15
	movswl	(%r15,%rdi,2), %r14d
	addl	$1, %r9d
	movslq	%r9d, %r9
	movswl	(%r15,%r9,2), %edi
	subl	%r14d, %edi
	movzbl	%dl, %edx
	imull	%edx, %edi
	sarl	$8, %edi
	addl	%r14d, %edi
	jmp	.L4062
.L4222:
	subl	%r11d, %edi
	movl	196(%rsp), %r9d
	imull	%ebx, %r9d
	movl	204(%rsp), %r15d
	movl	%r15d, %eax
	imull	%edi, %eax
	addl	%eax, %r9d
	sarl	$13, %r9d
	movl	%r15d, %eax
	imull	%ebx, %eax
	movl	200(%rsp), %r15d
	imull	%r15d, %edi
	addl	%edi, %eax
	sarl	$13, %eax
	leal	(%rax,%r11), %edi
	leal	(%r9,%r9), %eax
	subl	%ebx, %eax
	movl	%eax, %ebx
	movl	$150000, %eax
	cmpl	%eax, %ebx
	cmovg	%eax, %ebx
	movl	$-150000, %eax
	cmpl	%eax, %ebx
	cmovl	%eax, %ebx
	leal	(%rdi,%rdi), %eax
	subl	%r11d, %eax
	movl	%eax, %r11d
	movl	$150000, %eax
	cmpl	%eax, %r11d
	cmovg	%eax, %r11d
	movl	$-150000, %eax
	cmpl	%eax, %r11d
	cmovl	%eax, %r11d
	movl	32(%rsp), %eax
	imull	%eax, %r9d
	sarl	$12, %r9d
	movl	24(%rsp), %eax
	imull	%eax, %r9d
	addl	%r14d, %r9d
	imull	%r12d, %edi
	leal	(%r9,%rdi), %eax
	sarl	$10, %eax
	movl	$200000, %edi
	cmpl	%edi, %eax
	cmovle	%eax, %edi
	movl	$-200000, %r9d
	cmpl	%r9d, %edi
	cmovl	%r9d, %edi
	movl	%edi, %r9d
	negl	%r9d
	cmovs	%edi, %r9d
	cmpl	$16000, %r9d
	jle	.L4067
	leal	-32000(%r9,%r9), %r9d
	movl	%r9d, %edi
	negl	%edi
	cmovs	%r9d, %edi
	movl	%edi, %r9d
	sarl	$8, %r9d
	movl	$31588, %r14d
	cmpl	$65535, %edi
	jg	.L4068
	leaq	TANH_Q15(%rip), %r15
	movslq	%r9d, %r14
	movswl	(%r15,%r14,2), %r14d
	addl	$1, %r9d
	movslq	%r9d, %r9
	movswl	(%r15,%r9,2), %r9d
	subl	%r14d, %r9d
	movzbl	%dil, %edi
	imull	%edi, %r9d
	sarl	$8, %r9d
	addl	%r9d, %r14d
.L4068:
	sarl	%r14d
	movl	%r14d, %r9d
	leal	16000(%r14), %r14d
	movl	$-16000, %edi
	subl	%r9d, %edi
	testl	%eax, %eax
	cmovns	%r14d, %edi
.L4067:
	leal	(%rdx,%rdi), %eax
	sarl	%eax
	imull	%r10d, %eax
	sarl	$15, %eax
	imull	$6000, %eax, %eax
	sarl	$11, %eax
	movq	136(%rsp), %r15
	testq	%r15, %r15
	je	.L4070
	subl	%edx, %edi
	sarl	%edi
	imull	%r10d, %edi
	movl	%edi, %edx
	sarl	$15, %edx
	imull	$6000, %edx, %edx
	sarl	$11, %edx
	movl	40(%rsp), %edi
	imull	%eax, %edi
	sarl	$11, %edi
	addl	%edi, %edx
	addl	%edx, (%r15,%r8)
	jmp	.L4070
.L4223:
	cmpl	$0, 8(%rsp)
	je	.L4046
.L4059:
	movq	16(%rsp), %rax
	movl	%ebx, 88(%rax)
	movl	%r11d, 92(%rax)
.L4046:
	movq	88(%rsp), %rax
	movl	%esi, 44(%rax)
	movl	%ecx, 48(%rax)
	movl	100(%rsp), %ebx
	movl	%ebx, 72(%rax)
	movl	$0, %eax
	cmpq	$0, 136(%rsp)
	je	.L3808
	movl	40(%rsp), %eax
	orl	8(%rsp), %eax
	setne	%al
	movzbl	%al, %eax
	jmp	.L3808
.L4084:
	movl	$0, %eax
	jmp	.L3808
.L3899:
	leal	(%r11,%rbx), %edi
	shrl	$16, %edi
	subl	$32768, %edi
	movl	$0, %edx
.L3902:
	subl	%edx, %edi
	subl	%edi, %esi
	sarl	%esi
	cmpl	$0, 48(%rsp)
	je	.L3903
	movl	%esi, 624(%rsp,%r8,4)
.L3903:
	cmpl	$0, 72(%rsp)
	je	.L3904
	imull	624(%rsp,%r8,4), %esi
	sarl	$15, %esi
.L3904:
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, 496(%rsp,%r8,4)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3905
	cmpl	%ebx, %eax
	jnb	.L3905
	movl	$1, %edx
	sall	%cl, %edx
	orl	%edx, %r10d
	movl	%eax, 752(%rsp,%r8,4)
.L3905:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3906
	btl	%ecx, %r10d
	jnc	.L3906
	movl	752(%rsp,%r8,4), %ebx
	movq	104(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
.L3906:
	addq	$1, %r8
	addl	%r13d, %r11d
	subl	%r14d, %r12d
	cmpq	%r8, 152(%rsp)
	je	.L4224
.L3907:
	movl	%r8d, %ecx
	movl	%ebx, %esi
	shrl	$16, %esi
	subl	$32768, %esi
	movl	%ebp, %r9d
	shrl	$15, %r9d
	je	.L3899
	cmpl	%ebp, %ebx
	jb	.L4225
	movl	$0, %eax
	cmpl	%ebx, %r12d
	jb	.L4226
.L3901:
	subl	%eax, %esi
	leal	(%r11,%rbx), %eax
	movl	%eax, %edi
	shrl	$16, %edi
	subl	$32768, %edi
	cmpl	%ebp, %eax
	jb	.L4227
	movl	$0, %edx
	cmpl	%eax, %r12d
	jnb	.L3902
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L3902
.L3908:
	leal	(%r8,%rbx), %esi
	shrl	$16, %esi
	subl	$32768, %esi
	movl	152(%rsp), %edx
.L3911:
	subl	%edx, %esi
	subl	%esi, %ecx
	sarl	%ecx
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%eax, %ecx
	sarl	$15, %ecx
	addl	%ecx, (%r11)
	addl	%r10d, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %r11
	addl	%r13d, %r8d
	subl	%r14d, %r9d
	cmpq	%r11, %r12
	je	.L4228
.L3912:
	movl	%ebx, %ecx
	shrl	$16, %ecx
	subl	$32768, %ecx
	movl	%ebp, %edi
	shrl	$15, %edi
	je	.L3908
	cmpl	%ebp, %ebx
	jb	.L4229
	movl	152(%rsp), %eax
	cmpl	%ebx, %r9d
	jb	.L4230
.L3910:
	subl	%eax, %ecx
	leal	(%r8,%rbx), %eax
	movl	%eax, %esi
	shrl	$16, %esi
	subl	$32768, %esi
	cmpl	%ebp, %eax
	jb	.L4231
	movl	152(%rsp), %edx
	cmpl	%eax, %r9d
	jnb	.L3911
	notl	%eax
	movl	$0, %edx
	divl	%edi
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L3911
.L3950:
	leal	(%r12,%rbx), %edi
	shrl	$16, %edi
	subl	$32768, %edi
	movl	$0, %edx
.L3953:
	subl	%edx, %edi
	subl	%edi, %esi
	sarl	%esi
	cmpl	$0, 48(%rsp)
	je	.L3954
	movl	%esi, 624(%rsp,%r8,4)
.L3954:
	cmpl	$0, 72(%rsp)
	je	.L3955
	imull	624(%rsp,%r8,4), %esi
	sarl	$15, %esi
.L3955:
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%esi, %eax
	sarl	$15, %eax
	addl	%eax, 496(%rsp,%r8,4)
	movl	40(%rsp), %eax
	addl	%eax, %r15d
	leal	(%rbx,%rbp), %eax
	addl	%r14d, %ebp
	cmpl	$0, 64(%rsp)
	je	.L3956
	cmpl	%ebx, %eax
	jnb	.L3956
	movl	$1, %edx
	sall	%cl, %edx
	orl	%edx, %r10d
	movl	%eax, 752(%rsp,%r8,4)
.L3956:
	movl	%eax, %ebx
	cmpb	$0, 60(%rsp)
	je	.L3957
	btl	%ecx, %r10d
	jnc	.L3957
	movl	752(%rsp,%r8,4), %ebx
	movq	104(%rsp), %rax
	imulq	%rax, %rbx
	shrq	$16, %rbx
.L3957:
	addq	$1, %r8
	subl	%r14d, %r11d
	cmpq	%r8, %r13
	je	.L4232
.L3958:
	movl	%r8d, %ecx
	movl	%ebx, %esi
	shrl	$16, %esi
	subl	$32768, %esi
	movl	%ebp, %r9d
	shrl	$15, %r9d
	je	.L3950
	cmpl	%ebp, %ebx
	jb	.L4233
	movl	$0, %eax
	cmpl	%ebx, %r11d
	jb	.L4234
.L3952:
	subl	%eax, %esi
	leal	(%r12,%rbx), %eax
	movl	%eax, %edi
	shrl	$16, %edi
	subl	$32768, %edi
	cmpl	%ebp, %eax
	jb	.L4235
	movl	$0, %edx
	cmpl	%eax, %r11d
	jnb	.L3953
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L3953
.L3959:
	leal	(%r12,%rbx), %edi
	shrl	$16, %edi
	subl	$32768, %edi
	movl	%esi, %edx
.L3962:
	subl	%edx, %edi
	subl	%edi, %ecx
	sarl	%ecx
	movl	%r15d, %eax
	sarl	$16, %eax
	imull	%eax, %ecx
	sarl	$15, %ecx
	addl	%ecx, 0(%r13)
	addl	%r10d, %r15d
	addl	%ebp, %ebx
	addl	%r14d, %ebp
	addq	$4, %r13
	subl	%r14d, %r8d
	cmpq	%r11, %r13
	je	.L4236
.L3963:
	movl	%ebx, %ecx
	shrl	$16, %ecx
	subl	$32768, %ecx
	movl	%ebp, %r9d
	shrl	$15, %r9d
	je	.L3959
	cmpl	%ebp, %ebx
	jb	.L4237
	movl	%esi, %eax
	cmpl	%ebx, %r8d
	jb	.L4238
.L3961:
	subl	%eax, %ecx
	leal	(%r12,%rbx), %eax
	movl	%eax, %edi
	shrl	$16, %edi
	subl	$32768, %edi
	cmpl	%ebp, %eax
	jb	.L4239
	movl	%esi, %edx
	cmpl	%eax, %r8d
	jnb	.L3962
	notl	%eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %edx
	imull	%eax, %edx
	sarl	$15, %edx
	subl	%eax, %edx
	subl	%eax, %edx
	addl	$32768, %edx
	jmp	.L3962
.L3831:
	movswl	40(%r11), %eax
	imull	%ecx, %eax
	imull	$258, %eax, %eax
	sarl	$15, %eax
.L3832:
	movl	%eax, 452(%rsp,%rdx,4)
.L3830:
	addq	$1, %rdx
	addq	$2, %r11
	addq	$5, %rsi
	cmpq	$4, %rdx
	je	.L3827
.L3833:
	movl	752(%rsp,%rdx,4), %eax
	testl	%eax, %eax
	je	.L3830
	movsbl	(%rsi), %ecx
	sarl	$14, %eax
	addl	%eax, %ecx
	movl	$127, %eax
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	testl	%ecx, %ecx
	movl	$0, %eax
	cmovs	%eax, %ecx
	movzbl	1(%rsi), %eax
	testb	%al, %al
	je	.L3831
	andl	$127, %eax
	movl	(%r9,%rax,4), %edi
	shrl	$9, %edi
	movq	16(%rsp), %rax
	movzwl	98(%rax), %eax
	imull	%eax, %edi
	movswl	40(%r11), %eax
	imull	%ecx, %eax
	imull	$258, %eax, %eax
	sarl	$15, %eax
	cmpl	$32766, %edi
	jg	.L3832
	imull	%edi, %eax
	sarl	$15, %eax
	jmp	.L3832
.L3821:
	movl	(%rdi), %edx
	movl	%edx, 4(%rax)
.L4081:
	movswl	32(%rsi), %edx
.L3823:
	movl	%edx, 20(%rax)
	addq	$5, %r9
	addl	$1, %ecx
	addq	$4, %rax
	addq	$2, %rsi
	addq	$4, %rdi
	cmpl	$5, %ecx
	je	.L4240
.L3824:
	movzbl	(%r9), %edx
	testb	%dl, %dl
	je	.L3821
	andl	$127, %edx
	movl	(%rbx,%rdx,4), %r12d
	shrl	$9, %r12d
	movzwl	98(%r13), %edx
	imull	%edx, %r12d
	movl	(%rdi), %edx
	movl	%edx, 4(%rax)
	cmpl	$32766, %r12d
	jg	.L4081
	movswl	32(%rsi), %edx
	imull	%r12d, %edx
	sarl	$15, %edx
	jmp	.L3823
.L3872:
	movq	8(%rsp), %rsi
	movl	304(%rsp,%rsi,4), %edi
	movl	%edi, 80(%rsp)
	movq	16(%rsp), %rdi
	movzwl	36(%rdi,%rsi,2), %edx
	movl	320(%rsp,%rsi,4), %edi
	movl	%edi, 100(%rsp)
	movq	24(%rsp), %rcx
	movzbl	99(%rcx,%rsi), %r8d
	movl	%eax, %ebp
.L3873:
	movq	16(%rsp), %rax
	movq	8(%rsp), %rsi
	movswl	44(%rax,%rsi,2), %r12d
.L3874:
	movq	8(%rsp), %rax
	movl	336(%rsp,%rax,4), %eax
	movl	%eax, 96(%rsp)
	cmpl	$1, 32(%rsp)
	je	.L4241
	movl	32(%rsp), %eax
	testl	%eax, %eax
	je	.L4242
	cmpl	$2, 32(%rsp)
	jne	.L4092
	movq	24(%rsp), %rax
	cmpb	$0, 25(%rax)
	setne	%cl
	movzbl	%cl, %ecx
	movl	%ecx, 48(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, %r11d
	movl	$0, 152(%rsp)
	movl	$0, %r13d
	jmp	.L3878
.L4184:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE451:
	.size	va_render, .-va_render
	.type	va_render_mono, @function
va_render_mono:
.LFB452:
	.cfi_startproc
	endbr64
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%r8, %r9
	movl	%ecx, %r8d
	movl	$0, %ecx
	call	va_render
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE452:
	.size	va_render_mono, .-va_render_mono
	.type	va_block, @function
va_block:
.LFB441:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	leaq	trk(%rip), %rax
	movq	%rdi, %r14
	subq	%rax, %r14
	sarq	$5, %r14
	movabsq	$5749634516480899205, %rax
	movq	%r14, %r9
	imulq	%rax, %r9
	movl	%r9d, 4(%rsp)
	cmpl	$2, %r9d
	ja	.L4245
	movl	%r9d, %r13d
	imulq	$106, %r13, %rsi
	leaq	va_patch(%rip), %rax
	leaq	(%rsi,%rax), %r14
	leaq	166(%rdi), %rbp
	movq	%r13, %rbx
	salq	$4, %rbx
	leaq	va_mlast(%rip), %rax
	addq	%rax, %rbx
	leaq	VA_MACRO(%rip), %r12
	leaq	8(%r12), %r15
	movq	%r13, 8(%rsp)
	movq	%r9, 16(%rsp)
	jmp	.L4248
.L4247:
	addq	$2, %rbp
	addq	$2, %rbx
	addq	$1, %r12
	cmpq	%r15, %r12
	je	.L4273
.L4248:
	movzwl	0(%rbp), %esi
	cmpw	(%rbx), %si
	je	.L4247
	movw	%si, (%rbx)
	movzbl	(%r12), %edi
	movzbl	%dil, %r13d
	addq	%r14, %r13
	movswl	%si, %esi
	movzbl	%dil, %edi
	call	va_clampv
	movb	%al, 0(%r13)
	jmp	.L4247
.L4273:
	movq	8(%rsp), %r13
	movq	16(%rsp), %r9
	movswl	song(%rip), %ebx
	movl	$300, %eax
	cmpl	%eax, %ebx
	cmovg	%eax, %ebx
	movl	$20, %eax
	cmpl	%eax, %ebx
	cmovl	%eax, %ebx
	leaq	0(%r13,%r13,8), %rdx
	leaq	va_lfo(%rip), %rax
	leaq	(%rax,%rdx,8), %rdi
	leaq	53(%r14), %rcx
	leaq	va_rate_off(%rip), %rax
	leaq	(%rax,%r13,4), %rbp
	movq	%rdi, %r8
	movl	$0, %edx
	leaq	LFO_INC(%rip), %r12
	leaq	VA_DIV_Q4(%rip), %r13
	movl	$1821285621, %esi
	movq	%r9, 8(%rsp)
	movl	%ebx, %r9d
	jmp	.L4261
.L4275:
	imull	$14, %eax, %eax
	shrl	$7, %eax
	movl	%eax, %eax
	movl	%r9d, %r15d
	imull	0(%r13,%rax,4), %r15d
	movl	%r15d, %eax
	shrl	$4, %eax
	jmp	.L4250
.L4254:
	cmpb	$4, %r10b
	jne	.L4257
	movzwl	18(%r11), %r11d
	subl	$32768, %r11d
	jmp	.L4260
.L4255:
	shrl	$15, %eax
	leal	-32768(%rax), %r10d
	movl	$98303, %r11d
	subl	%eax, %r11d
	cmpl	$65535, %eax
	cmovle	%r10d, %r11d
.L4260:
	movw	%r11w, 40(%r8)
	movsbl	2(%rbx), %eax
	imull	%r11d, %eax
	imull	$258, %eax, %eax
	sarl	$15, %eax
	movw	%ax, 32(%r8)
	addq	$1, %rdx
	addq	$4, %rdi
	addq	$5, %rcx
	addq	$2, %r8
	cmpq	$4, %rdx
	je	.L4274
.L4261:
	movq	%rdi, %r11
	movl	(%rdi), %r10d
	movq	%rcx, %rbx
	movsbl	(%rcx), %eax
	movsbl	0(%rbp,%rdx), %r15d
	addl	%r15d, %eax
	movl	$127, %r15d
	cmpl	%r15d, %eax
	cmovg	%r15d, %eax
	testl	%eax, %eax
	movl	$0, %r15d
	cmovs	%r15d, %eax
	cmpb	$0, 4(%rcx)
	jne	.L4275
	cltq
	movl	(%r12,%rax,4), %eax
.L4250:
	addl	%r10d, %eax
	movl	%eax, (%r11)
	jnc	.L4251
	movl	%edx, %r10d
	addl	16(%r11), %r10d
	cmove	%esi, %r10d
	movl	%r10d, %r15d
	sall	$13, %r15d
	xorl	%r15d, %r10d
	movl	%r10d, %r15d
	shrl	$17, %r15d
	xorl	%r15d, %r10d
	movl	%r10d, %r15d
	sall	$5, %r15d
	xorl	%r15d, %r10d
	movl	%r10d, 16(%r11)
.L4251:
	movzbl	1(%rbx), %r10d
	cmpb	$3, %r10b
	je	.L4253
	jg	.L4254
	cmpb	$1, %r10b
	je	.L4255
	movl	%eax, %r11d
	shrl	$16, %r11d
	subl	$32768, %r11d
	cmpb	$2, %r10b
	je	.L4260
.L4257:
	movl	%eax, %r10d
	shrl	$22, %r10d
	leaq	SINE(%rip), %r15
	movl	%r10d, %r11d
	movswl	(%r15,%r11,2), %r11d
	addl	$1, %r10d
	andl	$1023, %r10d
	movswl	(%r15,%r10,2), %r10d
	subl	%r11d, %r10d
	shrl	$7, %eax
	andl	$32767, %eax
	imull	%eax, %r10d
	sarl	$15, %r10d
	addl	%r10d, %r11d
	jmp	.L4260
.L4253:
	sarl	$31, %eax
	movl	%eax, %r11d
	andl	$-65534, %r11d
	addl	$32767, %r11d
	jmp	.L4260
.L4274:
	movq	8(%rsp), %r9
	movl	%r9d, %eax
	leaq	(%rax,%rax,8), %rdx
	leaq	va_lfo(%rip), %rax
	movb	$0, 48(%rax,%rdx,8)
	leaq	73(%r14), %rax
	leaq	97(%r14), %rsi
	movl	4(%rsp), %edx
	leaq	(%rdx,%rdx,8), %rcx
	leaq	va_lfo(%rip), %rdx
	leaq	(%rdx,%rcx,8), %rdi
	jmp	.L4263
.L4262:
	addq	$3, %rax
	cmpq	%rsi, %rax
	je	.L4276
.L4263:
	movsbl	1(%rax), %edx
	subl	$26, %edx
	cmpl	$3, %edx
	ja	.L4262
	cmpb	$0, (%rax)
	je	.L4262
	cmpb	$0, 2(%rax)
	je	.L4262
	movb	$1, 48(%rdi)
	jmp	.L4262
.L4276:
	leaq	va_lfo(%rip), %rcx
	movl	%r9d, %edx
	leaq	0(,%rdx,8), %rax
	leaq	(%rax,%rdx), %rdi
	movl	52(%rcx,%rdi,8), %esi
	addl	$3665893, %esi
	movl	%esi, 52(%rcx,%rdi,8)
	movzwl	68(%rcx,%rdi,8), %esi
	leal	-1(%rsi), %edx
	movw	%dx, 68(%rcx,%rdi,8)
	testw	%si, %si
	jne	.L4264
	movl	56(%rcx,%rdi,8), %edx
	addl	$7, %edx
	movl	$1821285621, %eax
	cmove	%eax, %edx
	movl	%edx, %eax
	sall	$13, %eax
	xorl	%edx, %eax
	movl	%eax, %edx
	shrl	$17, %edx
	xorl	%edx, %eax
	movl	%eax, %edx
	sall	$5, %edx
	xorl	%edx, %eax
	movl	%eax, 56(%rcx,%rdi,8)
	movq	%rdi, %r8
	movl	%eax, %edi
	shrl	$16, %edi
	subl	$32768, %edi
	movl	%edi, 64(%rcx,%r8,8)
	andw	$511, %ax
	addw	$400, %ax
	movw	%ax, 68(%rcx,%r8,8)
.L4264:
	leaq	va_lfo(%rip), %rdx
	movl	%r9d, %r14d
	leaq	0(,%r14,8), %rax
	leaq	(%rax,%r14), %rcx
	movl	60(%rdx,%rcx,8), %ecx
	leaq	(%rax,%r14), %rsi
	movl	64(%rdx,%rsi,8), %eax
	subl	%ecx, %eax
	sarl	$8, %eax
	addl	%ecx, %eax
	movl	%eax, 60(%rdx,%rsi,8)
.L4245:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE441:
	.size	va_block, .-va_block
	.type	va_blob_preset, @function
va_blob_preset:
.LFB437:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$136, %rsp
	.cfi_def_cfa_offset 176
	movq	%rdi, %rbp
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	jbe	.L4284
.L4277:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L4285
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L4284:
	.cfi_restore_state
	movl	%esi, %ebx
	movq	%rdi, %r13
	movq	%rsp, %rdi
	call	va_init_patch
	cmpl	$24, %ebx
	ja	.L4279
	movl	%ebx, %ebx
	leaq	VA_PRESET_EDITS(%rip), %rax
	movq	(%rax,%rbx,8), %r12
	movzbl	(%r12), %ebx
	cmpb	$-1, %bl
	je	.L4279
.L4280:
	movsbl	1(%r12), %esi
	movzbl	%bl, %edi
	call	va_clampv
	movzbl	%bl, %ebx
	movb	%al, (%rsp,%rbx)
	addq	$2, %r12
	movzbl	(%r12), %ebx
	cmpb	$-1, %bl
	jne	.L4280
.L4279:
	movl	%r13d, %edi
	imulq	$106, %rdi, %rdi
	movl	$318, %ecx
	cmpq	%rcx, %rdi
	cmovnb	%rdi, %rcx
	subq	%rdi, %rcx
	movq	%rsp, %rsi
	leaq	va_patch(%rip), %rax
	addq	%rax, %rdi
	movl	$106, %edx
	call	__memcpy_chk@PLT
	movq	%rbp, %rdi
	call	va_macros_out
	jmp	.L4277
.L4285:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE437:
	.size	va_blob_preset, .-va_blob_preset
	.type	va_blob_set, @function
va_blob_set:
.LFB436:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	addq	$-128, %rsp
	.cfi_def_cfa_offset 160
	movq	%rdi, %rbp
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	movq	%rdi, %rbx
	subq	%rax, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	cmpl	$2, %ebx
	jbe	.L4290
.L4286:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L4291
	subq	$-128, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L4290:
	.cfi_restore_state
	movq	%rsi, %rdi
	movq	%rsp, %r12
	movq	%r12, %rsi
	call	va_unpack
	movl	%ebx, %ebx
	imulq	$106, %rbx, %rbx
	movl	$318, %ecx
	cmpq	%rcx, %rbx
	cmovnb	%rbx, %rcx
	subq	%rbx, %rcx
	leaq	va_patch(%rip), %rax
	leaq	(%rbx,%rax), %rdi
	movl	$106, %edx
	movq	%r12, %rsi
	call	__memcpy_chk@PLT
	movq	%rbp, %rdi
	call	va_macros_out
	jmp	.L4286
.L4291:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE436:
	.size	va_blob_set, .-va_blob_set
	.type	va_blob_get, @function
va_blob_get:
.LFB435:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$136, %rsp
	.cfi_def_cfa_offset 160
	movq	%rsi, %rbx
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	ja	.L4293
	movl	%edi, %edi
	imulq	$106, %rdi, %rdi
	leaq	va_patch(%rip), %rax
	addq	%rax, %rdi
	call	va_pack
.L4292:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L4297
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L4293:
	.cfi_restore_state
	movq	%rsp, %rbp
	movq	%rbp, %rdi
	call	va_init_patch
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	va_pack
	jmp	.L4292
.L4297:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE435:
	.size	va_blob_get, .-va_blob_get
	.type	va_set, @function
va_set:
.LFB434:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	leaq	trk(%rip), %rax
	movq	%rdi, %rbx
	subq	%rax, %rbx
	sarq	$5, %rbx
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rbx
	cmpl	$2, %ebx
	ja	.L4298
	movq	%rdi, %r12
	movl	%ecx, %r14d
	movl	%ebx, %r13d
	movl	%ebx, %edi
	call	va_index
	movl	%eax, %ebp
	cmpl	$255, %eax
	je	.L4298
	cmpl	$23, %eax
	ja	.L4300
	movl	%eax, %eax
	movl	$2863311531, %edx
	imulq	%rdx, %rax
	shrq	$34, %rax
	leal	(%rax,%rax,2), %eax
	addl	%eax, %eax
	cmpl	%eax, %ebp
	jne	.L4301
	movl	%ebp, %eax
	imulq	%rdx, %rax
	shrq	$34, %rax
	movl	%ebx, %ecx
	imulq	$106, %rcx, %rcx
	leaq	va_patch(%rip), %rdx
	addq	%rcx, %rdx
	cmpb	$2, 99(%rax,%rdx)
	je	.L4308
.L4301:
	movl	%r14d, %esi
	movl	%ebp, %edi
	call	va_clampv
	movl	%eax, %esi
	movl	%ebp, %eax
	movl	%ebx, %ecx
	imulq	$106, %rcx, %rcx
	leaq	va_patch(%rip), %rdx
	addq	%rcx, %rdx
	movb	%sil, (%rdx,%rax)
.L4302:
	movl	%ebx, %ebx
	salq	$4, %rbx
	leaq	va_mlast(%rip), %rax
	addq	%rax, %rbx
	movl	$0, %eax
	leaq	VA_MACRO(%rip), %rsi
	movl	%ebp, %edx
	movl	%r13d, %r13d
	imulq	$106, %r13, %r13
	leaq	va_patch(%rip), %rcx
	addq	%r13, %rcx
	addq	%rdx, %rcx
	jmp	.L4305
.L4308:
	movl	$2, %eax
	cmpl	%eax, %r14d
	cmovg	%eax, %r14d
	testl	%r14d, %r14d
	movl	$0, %eax
	cmovs	%eax, %r14d
	jmp	.L4301
.L4300:
	movl	%eax, %eax
	movl	%ebx, %edx
	imulq	$106, %rdx, %rdx
	leaq	va_patch(%rip), %r15
	addq	%rdx, %r15
	addq	%rax, %r15
	movzbl	(%r15), %eax
	movb	%al, 7(%rsp)
	movl	%r14d, %esi
	movl	%ebp, %edi
	call	va_clampv
	movb	%al, (%r15)
	leal	-99(%rbp), %edx
	cmpl	$3, %edx
	setbe	%sil
	cmpb	$2, 7(%rsp)
	setne	%cl
	testb	%cl, %sil
	je	.L4302
	cmpb	$2, %al
	jne	.L4302
	leal	(%rdx,%rdx,2), %eax
	addl	%eax, %eax
	movl	%eax, %esi
	movl	%ebx, %ecx
	imulq	$106, %rcx, %rcx
	leaq	va_patch(%rip), %rdx
	addq	%rcx, %rdx
	cmpb	$2, (%rdx,%rsi)
	jle	.L4303
	movl	%eax, %edx
	movq	%rcx, %rsi
	leaq	va_patch(%rip), %rcx
	addq	%rsi, %rcx
	movb	$0, (%rcx,%rdx)
.L4303:
	leal	5(%rax), %ecx
	movl	%ebx, %edx
	imulq	$106, %rdx, %rdx
	leaq	va_patch(%rip), %rax
	addq	%rdx, %rax
	movb	$0, (%rax,%rcx)
	jmp	.L4302
.L4304:
	addq	$1, %rax
	cmpq	$8, %rax
	je	.L4298
.L4305:
	movzbl	(%rsi,%rax), %edx
	cmpl	%ebp, %edx
	jne	.L4304
	movsbw	(%rcx), %dx
	movw	%dx, 166(%r12,%rax,2)
	movsbw	(%rcx), %dx
	movw	%dx, (%rbx,%rax,2)
	jmp	.L4304
.L4298:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE434:
	.size	va_set, .-va_set
	.type	va_desc, @function
va_desc:
.LFB433:
	.cfi_startproc
	endbr64
	cmpl	$7, %esi
	ja	.L4314
	movl	%esi, %ecx
	andl	$1, %ecx
	movl	$0, %eax
	cmpl	%edx, %ecx
	jne	.L4309
	leaq	trk(%rip), %rax
	subq	%rax, %rdi
	sarq	$5, %rdi
	movabsq	$5749634516480899205, %rax
	imulq	%rax, %rdi
	cmpl	$2, %edi
	ja	.L4311
	shrl	%esi
	leal	99(%rsi), %r8d
	movl	%edi, %edx
	imulq	$106, %rdx, %rdx
	leaq	va_patch(%rip), %rax
	addq	%rdx, %rax
	movsbl	(%rax,%r8), %edx
	cmpl	$2, %edx
	ja	.L4311
	testl	%ecx, %ecx
	je	.L4320
	leaq	VA_D_SHAPE(%rip), %rax
	cmpl	$1, %edx
	je	.L4309
	cmpl	$2, %edx
	jne	.L4317
	leal	(%rsi,%rsi,2), %eax
	leal	(%rax,%rax), %edx
	movl	%edi, %edi
	imulq	$106, %rdi, %rdi
	leaq	va_patch(%rip), %rax
	addq	%rdi, %rax
	movsbl	(%rax,%rdx), %edx
	leaq	32+VA_D_SHAPE(%rip), %rax
	cmpl	$1, %edx
	je	.L4309
	cmpl	$2, %edx
	leaq	64(%rax), %rax
	leaq	-32(%rax), %rdx
	cmove	%rdx, %rax
	ret
.L4320:
	movl	%edx, %ecx
	jmp	.L4313
.L4314:
	movl	$0, %eax
	ret
.L4317:
	leaq	96+VA_D_SHAPE(%rip), %rax
	ret
.L4311:
	testl	%ecx, %ecx
	jne	.L4321
.L4313:
	movl	%ecx, %eax
	salq	$5, %rax
	leaq	VA_D_WAVE(%rip), %rdx
	addq	%rdx, %rax
	ret
.L4321:
	leaq	96+VA_D_SHAPE(%rip), %rax
.L4309:
	ret
	.cfi_endproc
.LFE433:
	.size	va_desc, .-va_desc
	.type	va_get, @function
va_get:
.LFB432:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	