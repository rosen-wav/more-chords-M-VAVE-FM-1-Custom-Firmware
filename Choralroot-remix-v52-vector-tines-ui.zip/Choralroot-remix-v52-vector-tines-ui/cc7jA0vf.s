	.file	"cr_v52_render_test.c"
	.text
	.type	ux_mix, @function
ux_mix:
.LFB56:
	.cfi_startproc
	movl	%edx, %r9d
	cmpb	$0, 33+ux(%rip)
	jne	.L11
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	$0, %r8d
	movl	$0, %eax
	leaq	SH.15(%rip), %r11
	leaq	MK.14(%rip), %r10
	movzwl	%di, %edi
	movzwl	%si, %esi
.L2:
	movzbl	(%r11,%r8), %ecx
	movzbl	(%r10,%r8), %ebp
	movl	%edi, %ebx
	sarl	%cl, %ebx
	andl	%ebp, %ebx
	movl	%esi, %edx
	sarl	%cl, %edx
	andl	%ebp, %edx
	subl	%ebx, %edx
	imull	%r9d, %edx
	movl	%edx, %ebp
	sarl	$31, %ebp
	andl	$-100, %ebp
	leal	50(%rbp,%rdx), %ebp
	movslq	%ebp, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	sarl	$31, %ebp
	subl	%ebp, %edx
	addl	%ebx, %edx
	sall	%cl, %edx
	orl	%edx, %eax
	addq	$1, %r8
	cmpq	$3, %r8
	jne	.L2
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L11:
	.cfi_restore 3
	.cfi_restore 6
	shrw	$11, %di
	movzwl	%di, %edi
	shrw	$11, %si
	movzwl	%si, %esi
	subl	%edi, %esi
	imull	%edx, %esi
	movl	%esi, %eax
	sarl	$31, %eax
	andl	$-100, %eax
	leal	50(%rax,%rsi), %eax
	movslq	%eax, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	addl	%edi, %edx
	movl	%edx, %eax
	sall	$11, %eax
	movl	%edx, %ecx
	sall	$6, %ecx
	orl	%ecx, %eax
	orl	%edx, %eax
	ret
	.cfi_endproc
.LFE56:
	.size	ux_mix, .-ux_mix
	.type	palette_set, @function
palette_set:
.LFB58:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movl	%edi, %ebp
	imulq	$954437177, %rbp, %rbp
	shrq	$33, %rbp
	leal	0(%rbp,%rbp,8), %eax
	subl	%eax, %edi
	movl	%edi, %ebp
	sete	33+ux(%rip)
	leaq	UI_PALETTES(%rip), %rcx
	movl	%edi, %edx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rdx), %rsi
	movzwl	8(%rcx,%rsi,8), %ebx
	movw	%bx, ux(%rip)
	movzwl	10(%rcx,%rsi,8), %esi
	movw	%si, 4(%rsp)
	movw	%si, 2+ux(%rip)
	leaq	(%rax,%rdx), %rsi
	movzwl	12(%rcx,%rsi,8), %r12d
	movw	%r12w, 4+ux(%rip)
	movzwl	14(%rcx,%rsi,8), %r13d
	movw	%r13w, 6+ux(%rip)
	movzwl	16(%rcx,%rsi,8), %r15d
	movw	%r15w, 8+ux(%rip)
	movzwl	%r12w, %r12d
	movzwl	%bx, %r14d
	movl	$70, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 10+ux(%rip)
	movl	$42, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 12+ux(%rip)
	movl	$18, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 14+ux(%rip)
	movzwl	%r13w, %r13d
	movl	$80, %edx
	movl	%r13d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 16+ux(%rip)
	movl	$12, %edx
	movl	%r13d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 18+ux(%rip)
	movw	%bx, 20+ux(%rip)
	movzwl	4(%rsp), %eax
	movl	$12, %edx
	movl	%r12d, %esi
	movl	%eax, 4(%rsp)
	movl	%eax, %edi
	call	ux_mix
	movw	%ax, 24+ux(%rip)
	movl	$78, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 26+ux(%rip)
	movl	$10, %edx
	movl	%r13d, %esi
	movl	4(%rsp), %r14d
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 28+ux(%rip)
	movl	$6, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	ux_mix
	movw	%ax, 30+ux(%rip)
	movl	%ebx, %edx
	shrw	$11, %dx
	movzwl	%dx, %edx
	movl	%edx, %eax
	sall	$8, %eax
	subl	%edx, %eax
	movl	%eax, %ecx
	imulq	$138547333, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	movl	%eax, %edx
	shrl	%edx
	addl	%ecx, %edx
	shrl	$4, %edx
	imull	$54, %edx, %edx
	movl	%ebx, %ecx
	andl	$31, %ecx
	movl	%ecx, %eax
	sall	$8, %eax
	subl	%ecx, %eax
	movl	%eax, %ecx
	imulq	$138547333, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	shrl	%eax
	addl	%ecx, %eax
	shrl	$4, %eax
	leal	(%rax,%rax,8), %ecx
	leal	(%rax,%rcx,2), %eax
	addl	%eax, %edx
	shrw	$5, %bx
	andl	$63, %ebx
	movl	%ebx, %eax
	sall	$8, %eax
	subl	%ebx, %eax
	movl	%eax, %ecx
	imulq	$68174085, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	shrl	%eax
	addl	%ecx, %eax
	shrl	$5, %eax
	imull	$183, %eax, %eax
	addl	%eax, %edx
	movl	%edx, %eax
	shrl	$8, %eax
	cmpl	$33023, %edx
	seta	32+ux(%rip)
	testl	%ebp, %ebp
	je	.L17
	cmpl	$129, %eax
	sbbl	%r15d, %r15d
	andw	$16772, %r15w
	subw	$18235, %r15w
.L17:
	movw	%r15w, 22+ux(%rip)
	addl	$1, 36+ux(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE58:
	.size	palette_set, .-palette_set
	.type	cv_rect, @function
cv_rect:
.LFB67:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %r9d
	movl	%esi, %eax
	movl	%edx, %esi
	movl	cv_oy(%rip), %edx
	rolw	$8, %r8w
	testl	%edi, %edi
	movl	$0, %r11d
	cmovns	%edi, %r11d
	leal	(%rdx,%rax), %edi
	testl	%edi, %edi
	movl	$0, %r10d
	cmovs	%r10d, %edi
	movl	cv_w(%rip), %ebx
	addl	%esi, %r9d
	cmpl	%ebx, %r9d
	movl	%r9d, %r10d
	cmovg	%ebx, %r10d
	leal	(%rax,%rcx), %r9d
	addl	%edx, %r9d
	movl	cv_h(%rip), %eax
	cmpl	%eax, %r9d
	cmovg	%eax, %r9d
	cmpl	%r9d, %edi
	jge	.L20
	movl	%edi, %ecx
	imull	%ebx, %ecx
	addl	%r10d, %ecx
	movl	%r11d, %ebp
	subl	%r10d, %ebp
	leaq	cv_px(%rip), %rsi
	jmp	.L22
.L23:
	movl	%eax, %edx
	movw	%r8w, (%rsi,%rdx,2)
	addl	$1, %eax
	cmpl	%ecx, %eax
	jne	.L23
.L25:
	addl	$1, %edi
	addl	%ebx, %ecx
	cmpl	%r9d, %edi
	je	.L20
.L22:
	leal	0(%rbp,%rcx), %eax
	cmpl	%r10d, %r11d
	jl	.L23
	jmp	.L25
.L20:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE67:
	.size	cv_rect, .-cv_rect
	.type	glyph_at, @function
glyph_at:
.LFB77:
	.cfi_startproc
	movzbl	2(%rdi), %r9d
	movzbl	%r9b, %edx
	cmpl	%edx, %esi
	jnb	.L30
.L33:
	movzbl	4(%rdi), %eax
	testl	%eax, %eax
	je	.L37
	movq	40(%rdi), %r8
	movl	$0, %edx
.L35:
	movzbl	(%r8,%rdx), %ecx
	cmpl	%esi, %ecx
	je	.L38
	addq	$1, %rdx
	cmpl	%eax, %edx
	jb	.L35
	movl	$-1, %eax
	ret
.L37:
	movl	$-1, %eax
	ret
.L30:
	movzbl	3(%rdi), %eax
	cmpl	%esi, %eax
	jb	.L33
	movl	%esi, %eax
	subl	%edx, %eax
	ret
.L38:
	movzbl	3(%rdi), %eax
	movzbl	%r9b, %r9d
	subl	%r9d, %eax
	leal	1(%rax,%rdx), %eax
	ret
	.cfi_endproc
.LFE77:
	.size	glyph_at, .-glyph_at
	.type	glyph, @function
glyph:
.LFB78:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	movl	%esi, %ebp
	leal	-97(%rsi), %eax
	cmpl	$25, %eax
	ja	.L40
	cmpb	$96, 3(%rdi)
	ja	.L41
	subl	$32, %ebp
.L41:
	movl	%ebp, %esi
	movq	%rbx, %rdi
	call	glyph_at
	testl	%eax, %eax
	jns	.L42
.L43:
	movl	$63, %esi
	movq	%rbx, %rdi
	call	glyph_at
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
.L42:
	movzbl	48(%rbx), %ecx
	sall	%cl, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L40:
	.cfi_restore_state
	call	glyph_at
	testl	%eax, %eax
	jns	.L42
	cmpl	$133, %ebp
	jne	.L43
	movl	$46, %esi
	movq	%rbx, %rdi
	call	glyph_at
	testl	%eax, %eax
	jns	.L42
	jmp	.L43
	.cfi_endproc
.LFE78:
	.size	glyph, .-glyph
	.type	kern, @function
kern:
.LFB79:
	.cfi_startproc
	sall	$8, %esi
	orl	%edx, %esi
	movzwl	6(%rdi), %edx
	movl	$0, %r8d
.L50:
	cmpl	%edx, %r8d
	jnb	.L53
	leal	(%rdx,%r8), %eax
	shrl	%eax
	movl	%eax, %r9d
	movq	24(%rdi), %rcx
	movzwl	(%rcx,%r9,2), %ecx
	cmpl	%esi, %ecx
	je	.L54
	jb	.L55
	movl	%eax, %edx
	jmp	.L50
.L54:
	movq	32(%rdi), %rax
	movsbl	(%rax,%r9), %eax
	ret
.L55:
	leal	1(%rax), %r8d
	jmp	.L50
.L53:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE79:
	.size	kern, .-kern
	.type	text_w, @function
text_w:
.LFB81:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movzbl	(%rsi), %eax
	testb	%al, %al
	je	.L61
	movq	%rdi, %r13
	movq	%rsi, %rbp
	movl	$0, %esi
	movl	$0, %r12d
	jmp	.L60
.L58:
	testl	%esi, %esi
	jne	.L64
.L59:
	movq	8(%r13), %r14
	movl	%ebx, %esi
	movq	%r13, %rdi
	call	glyph
	movl	%eax, %eax
	movzwl	2(%r14,%rax,8), %eax
	addl	%eax, %r12d
	addq	$1, %rbp
	movzbl	0(%rbp), %eax
	testb	%al, %al
	je	.L57
	movl	%ebx, %esi
.L60:
	movzbl	%al, %ebx
	leal	-97(%rbx), %eax
	cmpl	$25, %eax
	ja	.L58
	cmpb	$96, 3(%r13)
	ja	.L58
	subl	$32, %ebx
	jmp	.L58
.L64:
	movl	%ebx, %edx
	movq	%r13, %rdi
	call	kern
	addl	%eax, %r12d
	jmp	.L59
.L61:
	movl	$0, %r12d
.L57:
	leal	8(%r12), %eax
	sarl	$4, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE81:
	.size	text_w, .-text_w
	.type	cr_clip_all, @function
cr_clip_all:
.LFB93:
	.cfi_startproc
	movw	$0, cr_clip(%rip)
	movw	$0, 2+cr_clip(%rip)
	movw	$240, 4+cr_clip(%rip)
	movw	$240, 6+cr_clip(%rip)
	ret
	.cfi_endproc
.LFE93:
	.size	cr_clip_all, .-cr_clip_all
	.type	cr_row0, @function
cr_row0:
.LFB94:
	.cfi_startproc
	movl	cv_oy(%rip), %eax
	negl	%eax
	movswl	2+cr_clip(%rip), %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	ret
	.cfi_endproc
.LFE94:
	.size	cr_row0, .-cr_row0
	.type	cr_row1, @function
cr_row1:
.LFB95:
	.cfi_startproc
	movl	cv_h(%rip), %eax
	subl	cv_oy(%rip), %eax
	movswl	6+cr_clip(%rip), %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	ret
	.cfi_endproc
.LFE95:
	.size	cr_row1, .-cr_row1
	.type	cr_blend, @function
cr_blend:
.LFB97:
	.cfi_startproc
	testl	%ecx, %ecx
	je	.L72
	movl	%edi, %eax
	movl	%edx, %edi
	movl	%ecx, %edx
	movswl	cr_clip(%rip), %ecx
	cmpl	%eax, %ecx
	jg	.L72
	movswl	4+cr_clip(%rip), %ecx
	cmpl	%eax, %ecx
	jle	.L72
	movswl	2+cr_clip(%rip), %ecx
	cmpl	%esi, %ecx
	jg	.L72
	movswl	6+cr_clip(%rip), %ecx
	cmpl	%esi, %ecx
	jle	.L72
	movl	cv_w(%rip), %ecx
	cmpl	%ecx, %eax
	jnb	.L72
	addl	cv_oy(%rip), %esi
	cmpl	cv_h(%rip), %esi
	jb	.L74
.L72:
	ret
.L74:
	imull	%esi, %ecx
	addl	%eax, %ecx
	cmpl	$255, %edx
	ja	.L75
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	cv_px(%rip), %r8
	movl	%ecx, %ecx
	movzwl	(%r8,%rcx,2), %eax
	movzbl	%ah, %esi
	sall	$8, %eax
	orl	%esi, %eax
	movzwl	%ax, %esi
	movl	$256, %r10d
	subl	%edx, %r10d
	movl	%edi, %r9d
	shrw	$11, %r9w
	movzwl	%r9w, %r9d
	imull	%edx, %r9d
	movl	%esi, %r11d
	shrl	$11, %r11d
	imull	%r10d, %r11d
	leal	128(%r9,%r11), %r11d
	shrl	$8, %r11d
	sall	$11, %r11d
	movl	%edi, %ebx
	andl	$31, %ebx
	imull	%edx, %ebx
	movl	%eax, %r9d
	andl	$31, %r9d
	imull	%r10d, %r9d
	leal	128(%rbx,%r9), %eax
	shrl	$8, %eax
	orl	%r11d, %eax
	shrw	$5, %di
	andl	$63, %edi
	imull	%edi, %edx
	shrl	$5, %esi
	andl	$63, %esi
	imull	%r10d, %esi
	leal	128(%rdx,%rsi), %edx
	shrl	$8, %edx
	sall	$5, %edx
	orl	%edx, %eax
	movzbl	%ah, %edx
	sall	$8, %eax
	orl	%edx, %eax
	movw	%ax, (%r8,%rcx,2)
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L75:
	.cfi_restore 3
	movl	%ecx, %ecx
	movl	%edi, %edx
	rolw	$8, %dx
	leaq	cv_px(%rip), %rax
	movw	%dx, (%rax,%rcx,2)
	ret
	.cfi_endproc
.LFE97:
	.size	cr_blend, .-cr_blend
	.type	cr_fill, @function
cr_fill:
.LFB98:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movl	%edi, %r14d
	movl	%esi, %ebx
	movl	%r8d, %r15d
	leal	(%rdi,%rdx), %r13d
	leal	(%rsi,%rcx), %ebp
	call	cr_row0
	movl	%eax, %r12d
	call	cr_row1
	movl	%r15d, %r8d
	rolw	$8, %r8w
	movswl	cr_clip(%rip), %r10d
	cmpl	%r14d, %r10d
	cmovl	%r14d, %r10d
	movswl	4+cr_clip(%rip), %r11d
	cmpl	%r13d, %r11d
	cmovg	%r13d, %r11d
	cmpl	%r12d, %ebx
	movl	%r12d, %ecx
	cmovge	%ebx, %ecx
	cmpl	%eax, %ebp
	cmovle	%ebp, %eax
	cmpl	%ecx, %eax
	jle	.L76
	movl	%eax, %r9d
	movl	cv_w(%rip), %ebx
	movl	%ecx, %esi
	addl	cv_oy(%rip), %esi
	imull	%ebx, %esi
	movslq	%r10d, %r12
	leaq	cv_px(%rip), %rdi
	movl	%r11d, %ebp
	subl	%r10d, %ebp
	addq	%r12, %rbp
.L80:
	movl	%esi, %edx
	cmpl	%r10d, %r11d
	jle	.L78
	leaq	(%rdx,%r12), %rax
	leaq	(%rdi,%rax,2), %rax
	addq	%rbp, %rdx
	leaq	(%rdi,%rdx,2), %rdx
.L79:
	movw	%r8w, (%rax)
	addq	$2, %rax
	cmpq	%rdx, %rax
	jne	.L79
.L78:
	addl	$1, %ecx
	addl	%ebx, %esi
	cmpl	%ecx, %r9d
	jne	.L80
.L76:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE98:
	.size	cr_fill, .-cr_fill
	.type	cr_frect, @function
cr_frect:
.LFB99:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	%edi, %ebp
	movl	%esi, %r15d
	movl	%r8d, %ebx
	leal	(%rdi,%rdx), %r12d
	leal	(%rsi,%rcx), %r9d
	movl	%r9d, (%rsp)
	movl	%edi, %eax
	sarl	$4, %eax
	movl	%eax, 20(%rsp)
	leal	15(%r12), %r14d
	sarl	$4, %r14d
	call	cr_row0
	movl	%r15d, %r13d
	sarl	$4, %r13d
	cmpl	%eax, %r13d
	cmovl	%eax, %r13d
	call	cr_row1
	movl	(%rsp), %r9d
	leal	15(%r9), %edx
	sarl	$4, %edx
	cmpl	%eax, %edx
	cmovg	%eax, %edx
	cmpl	%r13d, %edx
	jle	.L84
	movzwl	%bx, %eax
	movl	%eax, (%rsp)
	movl	%r13d, %r8d
	movl	%r15d, %r10d
	jmp	.L89
.L87:
	cmpl	%r14d, %ebx
	je	.L93
.L88:
	movl	%ebx, %edi
	addl	$1, %ebx
	movl	%ebx, %eax
	sall	$4, %eax
	cmpl	%r12d, %eax
	movl	%r12d, %ecx
	cmovle	%eax, %ecx
	subl	$16, %eax
	cmpl	%ebp, %eax
	cmovl	%ebp, %eax
	subl	%eax, %ecx
	testl	%ecx, %ecx
	jle	.L87
	imull	%r15d, %ecx
	movl	(%rsp), %edx
	movl	%r13d, %esi
	call	cr_blend
	jmp	.L87
.L93:
	movl	4(%rsp), %r8d
	movl	8(%rsp), %edx
	movl	12(%rsp), %r9d
	movl	16(%rsp), %r10d
.L86:
	cmpl	%edx, %r8d
	je	.L84
.L89:
	movl	%r8d, %r13d
	addl	$1, %r8d
	movl	%r8d, %eax
	sall	$4, %eax
	cmpl	%r9d, %eax
	movl	%r9d, %esi
	cmovle	%eax, %esi
	subl	$16, %eax
	cmpl	%r10d, %eax
	cmovl	%r10d, %eax
	subl	%eax, %esi
	movl	%esi, %r15d
	testl	%esi, %esi
	jle	.L86
	movl	20(%rsp), %eax
	cmpl	%r14d, %eax
	jge	.L86
	movl	%eax, %ebx
	movl	%r8d, 4(%rsp)
	movl	%edx, 8(%rsp)
	movl	%r9d, 12(%rsp)
	movl	%r10d, 16(%rsp)
	jmp	.L88
.L84:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE99:
	.size	cr_frect, .-cr_frect
	.type	cr_sin, @function
cr_sin:
.LFB100:
	.cfi_startproc
	movl	%edi, %ecx
	shrl	$14, %ecx
	movl	%edi, %edx
	andl	$16383, %edx
	testl	$16384, %edi
	je	.L95
	movl	$16384, %eax
	subl	%edx, %eax
	movl	%eax, %edx
	shrl	$8, %edx
	cmpl	$16383, %eax
	jbe	.L101
	movl	$16384, %eax
	jmp	.L96
.L101:
	movzbl	%al, %edi
	jmp	.L98
.L95:
	shrl	$8, %edx
	movzbl	%dil, %edi
.L98:
	leaq	CR_SIN(%rip), %rax
	movl	%edx, %esi
	movswl	(%rax,%rsi,2), %esi
	addl	$1, %edx
	movl	%edx, %edx
	movswl	(%rax,%rdx,2), %eax
	subl	%esi, %eax
	imull	%edi, %eax
	sarl	$8, %eax
	addl	%esi, %eax
.L96:
	movl	%eax, %edx
	negl	%edx
	testb	$2, %cl
	cmovne	%edx, %eax
	ret
	.cfi_endproc
.LFE100:
	.size	cr_sin, .-cr_sin
	.type	cr_atan2, @function
cr_atan2:
.LFB102:
	.cfi_startproc
	movl	%esi, %edx
	negl	%edx
	cmovs	%esi, %edx
	movl	%edi, %ecx
	negl	%ecx
	cmovs	%edi, %ecx
	movl	$0, %eax
	movl	%edx, %r10d
	orl	%ecx, %r10d
	je	.L102
	movl	%edx, %r9d
	cmpl	%ecx, %edx
	jb	.L104
	movl	%ecx, %eax
	sall	$12, %eax
	movl	$0, %edx
	divl	%r9d
	movl	%eax, %r8d
	shrl	$6, %r8d
	movl	%r8d, %ecx
	leaq	CR_ATAN(%rip), %rdx
	movzwl	(%rdx,%rcx,2), %r9d
	movzwl	%r9w, %edx
	movl	$0, %ecx
	cmpl	$63, %r8d
	ja	.L105
	addl	$1, %r8d
	movl	%r8d, %r8d
	leaq	CR_ATAN(%rip), %rcx
	movzwl	(%rcx,%r8,2), %r8d
	subl	%edx, %r8d
	andl	$63, %eax
	movl	%r8d, %ecx
	imull	%eax, %ecx
	shrl	$6, %ecx
.L105:
	leal	(%rdx,%rcx), %eax
.L106:
	movl	$32768, %edx
	subl	%eax, %edx
	testl	%esi, %esi
	cmovs	%edx, %eax
	movl	$65536, %edx
	subl	%eax, %edx
	testl	%edi, %edi
	cmovs	%edx, %eax
	movzwl	%ax, %eax
.L102:
	ret
.L104:
	movl	%edx, %eax
	sall	$12, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%eax, %ecx
	shrl	$6, %ecx
	movl	%ecx, %r8d
	leaq	CR_ATAN(%rip), %rdx
	movzwl	(%rdx,%r8,2), %r8d
	movzwl	%r8w, %r9d
	movl	$0, %edx
	cmpl	$63, %ecx
	ja	.L107
	addl	$1, %ecx
	movl	%ecx, %ecx
	leaq	CR_ATAN(%rip), %rdx
	movzwl	(%rdx,%rcx,2), %ecx
	subl	%r9d, %ecx
	andl	$63, %eax
	imull	%eax, %ecx
	movl	%ecx, %edx
	shrl	$6, %edx
.L107:
	movl	$16384, %eax
	subl	%r9d, %eax
	subl	%edx, %eax
	jmp	.L106
	.cfi_endproc
.LFE102:
	.size	cr_atan2, .-cr_atan2
	.type	cr_isqrt, @function
cr_isqrt:
.LFB103:
	.cfi_startproc
	cmpl	$1073741823, %edi
	ja	.L120
	movl	$1073741824, %edx
.L115:
	shrl	$2, %edx
	cmpl	%edx, %edi
	jb	.L115
	testl	%edx, %edx
	je	.L124
.L114:
	movl	$0, %eax
	jmp	.L119
.L120:
	movl	$1073741824, %edx
	jmp	.L114
.L117:
	shrl	%eax
.L118:
	shrl	$2, %edx
	je	.L125
.L119:
	leal	(%rax,%rdx), %ecx
	cmpl	%ecx, %edi
	jb	.L117
	subl	%ecx, %edi
	shrl	%eax
	addl	%edx, %eax
	jmp	.L118
.L125:
	ret
.L124:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE103:
	.size	cr_isqrt, .-cr_isqrt
	.type	cr_disc, @function
cr_disc:
.LFB104:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	%edi, %ebp
	movl	%esi, %r14d
	movl	%edx, %ebx
	movl	%ecx, %r13d
	movl	%edi, %eax
	subl	%edx, %eax
	sarl	$4, %eax
	movl	%eax, 20(%rsp)
	leal	15(%rdi,%rdx), %eax
	sarl	$4, %eax
	movl	%eax, 8(%rsp)
	movl	%edx, %r12d
	imull	%edx, %r12d
	call	cr_row0
	movl	%eax, %edx
	movl	%r14d, %eax
	subl	%ebx, %eax
	sarl	$4, %eax
	cmpl	%edx, %eax
	cmovge	%eax, %edx
	movl	%edx, %r15d
	call	cr_row1
	movl	%eax, %edx
	leal	15(%r14,%rbx), %eax
	sarl	$4, %eax
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	movl	%edx, 16(%rsp)
	movzwl	%r13w, %edi
	movl	%edi, 12(%rsp)
	leaq	4+CR_SS(%rip), %rbx
	movl	%r15d, %r9d
	cmpl	%r15d, %edx
	jg	.L127
.L126:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L130:
	.cfi_restore_state
	sall	$4, %esi
	movl	%esi, %ecx
	movl	12(%rsp), %edx
	movl	4(%rsp), %esi
	movl	%r13d, %edi
	call	cr_blend
	addl	$1, %r13d
	cmpl	%r13d, 8(%rsp)
	je	.L137
.L133:
	movl	%r13d, %r8d
	sall	$4, %r8d
	leaq	CR_SS(%rip), %rdi
	movl	$0, %esi
.L132:
	movzbl	(%rdi), %ecx
	addl	%r15d, %ecx
	subl	%r14d, %ecx
	imull	%ecx, %ecx
	leaq	CR_SS(%rip), %rdx
.L129:
	movzbl	(%rdx), %eax
	addl	%r8d, %eax
	subl	%ebp, %eax
	imull	%eax, %eax
	addl	%ecx, %eax
	cmpl	%r12d, %eax
	setle	%al
	movzbl	%al, %eax
	addl	%eax, %esi
	addq	$1, %rdx
	cmpq	%rbx, %rdx
	jne	.L129
	addq	$1, %rdi
	cmpq	%rbx, %rdi
	jne	.L132
	jmp	.L130
.L137:
	movl	4(%rsp), %r9d
.L131:
	addl	$1, %r9d
	cmpl	%r9d, 16(%rsp)
	je	.L126
.L127:
	movl	20(%rsp), %r13d
	movl	8(%rsp), %eax
	cmpl	%eax, %r13d
	jge	.L131
	movl	%r9d, %r15d
	sall	$4, %r15d
	movl	%r9d, 4(%rsp)
	jmp	.L133
	.cfi_endproc
.LFE104:
	.size	cr_disc, .-cr_disc
	.type	cr_tri, @function
cr_tri:
.LFB105:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movl	%edi, %ebx
	movl	%esi, 20(%rsp)
	movl	%edx, %r14d
	movl	%ecx, 24(%rsp)
	movl	%r8d, 4(%rsp)
	movl	%r9d, 28(%rsp)
	movzwl	128(%rsp), %eax
	movw	%ax, 62(%rsp)
	subl	%edi, %edx
	movl	%edx, 36(%rsp)
	subl	%esi, %ecx
	movl	%ecx, 16(%rsp)
	movl	%r9d, %eax
	subl	%esi, %eax
	imull	%edx, %eax
	movl	%r8d, %edx
	subl	%edi, %edx
	imull	%ecx, %edx
	subl	%edx, %eax
	js	.L148
	movl	$1, %r15d
	testl	%eax, %eax
	jne	.L140
.L139:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L148:
	.cfi_restore_state
	movl	$-1, %r15d
.L140:
	movl	4(%rsp), %esi
	cmpl	%esi, %r14d
	movl	%esi, %eax
	cmovle	%r14d, %eax
	cmpl	%ebx, %eax
	cmovg	%ebx, %eax
	movl	28(%rsp), %edi
	movl	24(%rsp), %ecx
	cmpl	%ecx, %edi
	movl	%ecx, %edx
	cmovle	%edi, %edx
	movl	20(%rsp), %r9d
	cmpl	%r9d, %edx
	cmovg	%r9d, %edx
	movl	%edx, %r12d
	sarl	$4, %eax
	movl	%eax, %r13d
	movl	%esi, %eax
	cmpl	%esi, %r14d
	cmovge	%r14d, %eax
	cmpl	%ebx, %eax
	cmovl	%ebx, %eax
	addl	$15, %eax
	movl	%eax, %edx
	sarl	$4, %edx
	movl	%edx, 56(%rsp)
	cmpl	%ecx, %edi
	cmovge	%edi, %ecx
	movl	%ecx, %eax
	cmpl	%r9d, %ecx
	cmovl	%r9d, %eax
	leal	15(%rax), %ebp
	call	cr_row0
	movl	%r12d, %edx
	sarl	$4, %edx
	cmpl	%eax, %edx
	movl	%eax, %r12d
	cmovge	%edx, %r12d
	call	cr_row1
	movl	%ebp, %edx
	sarl	$4, %edx
	cmpl	%eax, %edx
	movl	%eax, %ecx
	cmovle	%edx, %ecx
	movl	%ecx, 64(%rsp)
	leaq	4+CR_SS(%rip), %rbp
	movl	4(%rsp), %eax
	movl	%eax, %esi
	subl	%r14d, %esi
	movl	%esi, 40(%rsp)
	movl	%ebx, %esi
	subl	%eax, %esi
	movl	%esi, 44(%rsp)
	cmpl	%r12d, %ecx
	jle	.L139
	movl	%r13d, 68(%rsp)
	movl	%r12d, %eax
	movl	%r14d, %r13d
	movl	%ebx, %r14d
	jmp	.L142
.L144:
	movl	%edx, %r13d
	movl	%r9d, %ecx
	sall	$4, %ecx
	movzwl	62(%rsp), %edx
	movl	52(%rsp), %esi
	movl	48(%rsp), %ebx
	movl	%ebx, %edi
	call	cr_blend
	movl	%ebx, %eax
	addl	$1, %eax
	movl	%eax, 48(%rsp)
	cmpl	%eax, 56(%rsp)
	je	.L152
.L147:
	movl	48(%rsp), %r14d
	sall	$4, %r14d
	leaq	CR_SS(%rip), %rdx
	movl	$0, %r9d
	movl	28(%rsp), %eax
	movl	%eax, %r12d
	movl	24(%rsp), %ebx
	subl	%ebx, %r12d
	movl	20(%rsp), %ebx
	subl	%eax, %ebx
	movq	%rdx, %rax
	movl	%r13d, %edx
.L146:
	movzbl	(%rax), %r10d
	movl	32(%rsp), %esi
	addl	%esi, %r10d
	movl	%r10d, %r13d
	movl	20(%rsp), %esi
	subl	%esi, %r13d
	movl	36(%rsp), %esi
	imull	%esi, %r13d
	movl	%r10d, %r11d
	movl	24(%rsp), %esi
	subl	%esi, %r11d
	movl	40(%rsp), %esi
	imull	%esi, %r11d
	movl	28(%rsp), %esi
	subl	%esi, %r10d
	movl	44(%rsp), %esi
	imull	%esi, %r10d
	leaq	CR_SS(%rip), %rsi
	movq	%rax, 8(%rsp)
.L143:
	movzbl	(%rsi), %ecx
	addl	%r14d, %ecx
	movl	%ecx, %eax
	movl	(%rsp), %edi
	subl	%edi, %eax
	imull	%r12d, %eax
	movl	%r11d, %edi
	subl	%eax, %edi
	imull	%r15d, %edi
	movl	%ecx, %r8d
	subl	%edx, %r8d
	movl	16(%rsp), %eax
	imull	%eax, %r8d
	movl	%r13d, %eax
	subl	%r8d, %eax
	imull	%r15d, %eax
	orl	%edi, %eax
	movl	4(%rsp), %edi
	subl	%edi, %ecx
	imull	%ebx, %ecx
	movl	%r10d, %edi
	subl	%ecx, %edi
	imull	%r15d, %edi
	orl	%edi, %eax
	notl	%eax
	shrl	$31, %eax
	addl	%eax, %r9d
	addq	$1, %rsi
	cmpq	%rbp, %rsi
	jne	.L143
	movq	8(%rsp), %rax
	addq	$1, %rax
	cmpq	%rbp, %rax
	jne	.L146
	jmp	.L144
.L152:
	movl	52(%rsp), %eax
	movl	%r13d, %r14d
	movl	(%rsp), %r13d
.L145:
	addl	$1, %eax
	cmpl	%eax, 64(%rsp)
	je	.L139
.L142:
	movl	68(%rsp), %edx
	movl	56(%rsp), %ebx
	cmpl	%ebx, %edx
	jge	.L145
	movl	%eax, %ebx
	sall	$4, %ebx
	movl	%ebx, 32(%rsp)
	movl	%edx, 48(%rsp)
	movl	%eax, 52(%rsp)
	movl	%r13d, (%rsp)
	movl	%r14d, %r13d
	jmp	.L147
	.cfi_endproc
.LFE105:
	.size	cr_tri, .-cr_tri
	.type	cr_arc_px, @function
cr_arc_px:
.LFB107:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$32, %rsp
	.cfi_def_cfa_offset 88
	movq	%rdi, %rbx
	sall	$4, %esi
	leal	8(%rsi), %ebp
	subl	(%rdi), %ebp
	sall	$4, %edx
	movl	%edx, 8(%rsp)
	leal	8(%rdx), %r14d
	movl	4(%rdi), %eax
	movl	%eax, 12(%rsp)
	movl	%r14d, %r15d
	subl	%eax, %r15d
	movl	%ebp, %r13d
	imull	%ebp, %r13d
	movl	%r15d, %eax
	imull	%r15d, %eax
	addl	%eax, %r13d
	movl	12(%rdi), %eax
	addl	$12, %eax
	imull	%eax, %eax
	movl	$0, %edi
	cmpl	%r13d, %eax
	jl	.L154
	movl	%esi, %r12d
	movl	16(%rbx), %edx
	leal	-12(%rdx), %eax
	imull	%eax, %eax
	cmpl	%r13d, %eax
	jle	.L174
	cmpl	$12, %edx
	jg	.L154
.L174:
	movl	%ebp, %esi
	movl	%r15d, %edi
	call	cr_atan2
	movl	%eax, 16(%rsp)
	movl	%r13d, %edi
	call	cr_isqrt
	testl	%eax, %eax
	movl	$1, %edx
	movl	%edx, %edi
	cmovg	%eax, %edi
	movl	%edi, 20(%rsp)
	movl	72(%rbx), %ecx
	movl	%ecx, 24(%rsp)
	movl	$-1, 4(%rsp)
	testl	%ecx, %ecx
	jne	.L157
	cmpl	$0, 56(%rbx)
	jne	.L157
	movl	16(%rsp), %ecx
	subl	60(%rbx), %ecx
	movzwl	%cx, %ecx
	leal	1(%rdi), %eax
	imull	$88508, %eax, %eax
	movl	%edi, %esi
	imull	%edi, %esi
	cltd
	idivl	%esi
	addl	$1, %eax
	cmpl	%eax, %ecx
	jb	.L158
	leal	(%rcx,%rax), %edx
	movl	$1, 4(%rsp)
	cmpl	%edx, 64(%rbx)
	jnb	.L157
.L158:
	movl	%eax, %edx
	addl	64(%rbx), %edx
	movl	$-1, 4(%rsp)
	cmpl	%ecx, %edx
	jnb	.L157
	addl	%eax, %ecx
	cmpl	$65535, %ecx
	seta	%al
	movzbl	%al, %eax
	negl	%eax
	movl	%eax, 4(%rsp)
.L157:
	movl	20(%rbx), %r10d
	leaq	4+CR_SS(%rip), %r9
	leaq	-4(%r9), %rcx
	movl	$0, %edi
	movl	12(%rsp), %eax
	subl	%r14d, %eax
	movl	%eax, 28(%rsp)
	jmp	.L159
.L180:
	movl	28(%rsp), %edx
	imull	%edx, %eax
	movl	12(%rsp), %edx
	imull	%ebp, %edx
	addl	%edx, %eax
	imull	$10430, %eax, %eax
	movl	20(%rsp), %r14d
	cltd
	idivl	%r14d
	cltd
	idivl	%r14d
	movl	16(%rsp), %edx
	subl	60(%rbx), %edx
	addl	%edx, %eax
	movzwl	%ax, %eax
	cmpl	$0, 24(%rsp)
	jne	.L162
	cmpl	%eax, 64(%rbx)
	jb	.L160
.L162:
	movl	56(%rbx), %r14d
	movl	$1, %edx
	testl	%r14d, %r14d
	je	.L163
	imull	48(%rbx), %eax
	shrl	$16, %eax
	cltd
	idivl	%r14d
	cmpl	52(%rbx), %edx
	jl	.L178
.L160:
	movl	68(%rbx), %edx
	testl	%edx, %edx
	je	.L163
	addl	%r12d, %esi
	movl	%esi, %edx
	subl	32(%rbx), %edx
	movl	%r13d, %eax
	subl	36(%rbx), %eax
	movl	28(%rbx), %r14d
	imull	%edx, %edx
	imull	%eax, %eax
	addl	%edx, %eax
	movl	$1, %edx
	cmpl	%r14d, %eax
	jle	.L163
	subl	40(%rbx), %esi
	movl	%r13d, %eax
	subl	44(%rbx), %eax
	imull	%esi, %esi
	imull	%eax, %eax
	addl	%eax, %esi
	cmpl	%esi, %r14d
	setge	%dl
	movzbl	%dl, %edx
.L163:
	addl	%edx, %edi
	addq	$1, %r8
	cmpq	%r9, %r8
	je	.L179
.L164:
	movzbl	(%r8), %esi
	leal	-8(%rsi), %eax
	leal	0(%rbp,%rax), %edx
	imull	%edx, %edx
	addl	%r11d, %edx
	cmpl	%edx, %r10d
	jl	.L160
	cmpl	%edx, 24(%rbx)
	jg	.L160
	cmpl	$0, 4(%rsp)
	js	.L180
	movl	$1, %edx
	cmpl	$0, 4(%rsp)
	je	.L160
	jmp	.L163
.L178:
	movl	$1, %edx
	jmp	.L163
.L179:
	addq	$1, %rcx
	cmpq	%r9, %rcx
	je	.L154
.L159:
	movzbl	(%rcx), %r13d
	leal	-8(%r13), %r14d
	leal	(%r15,%r14), %r11d
	imull	%r11d, %r11d
	movl	8(%rsp), %eax
	addl	%eax, %r13d
	leaq	CR_SS(%rip), %r8
	movl	%r14d, 12(%rsp)
	jmp	.L164
.L154:
	movl	%edi, %eax
	addq	$32, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE107:
	.size	cr_arc_px, .-cr_arc_px
	.type	cr_poly, @function
cr_poly:
.LFB109:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$1000, %rsp
	.cfi_def_cfa_offset 1056
	movl	%esi, %eax
	movl	%edx, %esi
	movl	%ecx, 56(%rsp)
	movl	%r8d, 28(%rsp)
	movw	%r9w, 90(%rsp)
	movq	%fs:40, %rdx
	movq	%rdx, 984(%rsp)
	xorl	%edx, %edx
	cmpl	$1, %eax
	jbe	.L181
	movq	%rdi, %r12
	movl	$48, %edx
	cmpl	%edx, %eax
	cmovbe	%eax, %edx
	movl	%edx, %ecx
	movq	%rdi, %rax
	movl	%edx, %edx
	leaq	(%rdi,%rdx,4), %rdi
	movl	$-99999, %r15d
	movl	$-99999, %ebx
	movl	$99999, %r13d
	movl	$99999, %r14d
.L183:
	movswl	(%rax), %edx
	cmpl	%edx, %r14d
	cmovg	%edx, %r14d
	cmpl	%edx, %ebx
	cmovl	%edx, %ebx
	movswl	2(%rax), %edx
	cmpl	%edx, %r13d
	cmovg	%edx, %r13d
	cmpl	%edx, %r15d
	cmovl	%edx, %r15d
	addq	$4, %rax
	cmpq	%rdi, %rax
	jne	.L183
	movl	%esi, %eax
	shrl	$31, %eax
	addl	%esi, %eax
	sarl	%eax
	movl	%eax, 64(%rsp)
	leal	-1(%rcx), %eax
	movq	%rax, 16(%rsp)
	movl	$0, %ebp
	movl	%r15d, 32(%rsp)
	movl	%r13d, 36(%rsp)
	movl	%ebx, 40(%rsp)
	movl	%r14d, 44(%rsp)
	jmp	.L191
.L185:
	movl	64(%rsp), %esi
	movl	%esi, %edx
	movzwl	8(%rsp), %eax
	subl	%esi, %eax
	movw	%ax, 112(%rsp,%rbp,2)
	cmpl	%r14d, %r15d
	jle	.L186
	movzwl	(%rsp), %eax
.L187:
	addl	%edx, %eax
	movw	%ax, 208(%rsp,%rbp,2)
	cmpl	%ebx, %r13d
	jge	.L188
	movzwl	4(%rsp), %eax
	subl	%edx, %eax
	movw	%ax, 304(%rsp,%rbp,2)
.L189:
	movzwl	24(%rsp), %eax
	jmp	.L190
.L188:
	movzwl	24(%rsp), %eax
	subl	%edx, %eax
	movw	%ax, 304(%rsp,%rbp,2)
	cmpl	%ebx, %r13d
	jle	.L189
	movzwl	4(%rsp), %eax
.L190:
	addl	%eax, %edx
	movw	%dx, 400(%rsp,%rbp,2)
	addq	$1, %rbp
	movq	16(%rsp), %rax
	cmpq	%rax, %rbp
	je	.L245
.L191:
	movzwl	(%r12,%rbp,4), %eax
	movw	%ax, (%rsp)
	movswl	%ax, %r15d
	movzwl	2(%r12,%rbp,4), %eax
	movw	%ax, 4(%rsp)
	movswl	%ax, %r13d
	movzwl	4(%r12,%rbp,4), %eax
	movw	%ax, 8(%rsp)
	movswl	%ax, %r14d
	movzwl	6(%r12,%rbp,4), %eax
	movw	%ax, 24(%rsp)
	movswl	%ax, %ebx
	movl	%r14d, %eax
	subl	%r15d, %eax
	movl	%ebx, %edx
	subl	%r13d, %edx
	imull	%eax, %eax
	imull	%edx, %edx
	leal	(%rax,%rdx), %edi
	call	cr_isqrt
	movl	%eax, 496(%rsp,%rbp,4)
	movl	$0, %eax
	testl	%ebp, %ebp
	je	.L184
	leal	-1(%rbp), %edx
	movl	496(%rsp,%rdx,4), %eax
	addl	688(%rsp,%rdx,4), %eax
.L184:
	movl	%eax, 688(%rsp,%rbp,4)
	cmpl	%r14d, %r15d
	jge	.L185
	movl	64(%rsp), %esi
	movl	%esi, %edx
	movzwl	(%rsp), %eax
	subl	%esi, %eax
	movw	%ax, 112(%rsp,%rbp,2)
.L186:
	movzwl	8(%rsp), %eax
	jmp	.L187
.L245:
	movl	32(%rsp), %r15d
	movl	36(%rsp), %r13d
	movl	40(%rsp), %ebx
	movl	44(%rsp), %r14d
	call	cr_row0
	movl	%eax, %edx
	movl	%r13d, %eax
	movl	64(%rsp), %ebp
	subl	%ebp, %eax
	sarl	$4, %eax
	cmpl	%edx, %eax
	cmovge	%eax, %edx
	movl	%edx, 72(%rsp)
	call	cr_row1
	movl	%eax, %r13d
	leal	15(%r15,%rbp), %eax
	sarl	$4, %eax
	cmpl	%r13d, %eax
	cmovle	%eax, %r13d
	movl	%r14d, %eax
	subl	%ebp, %eax
	sarl	$4, %eax
	movswl	cr_clip(%rip), %edx
	cmpl	%edx, %eax
	movl	%edx, %r14d
	cmovge	%eax, %r14d
	leal	15(%rbx,%rbp), %eax
	sarl	$4, %eax
	movswl	4+cr_clip(%rip), %edx
	cmpl	%edx, %eax
	movl	%edx, %ebx
	cmovle	%eax, %ebx
	movl	%ebx, 108(%rsp)
	movl	72(%rsp), %edx
	cmpl	%edx, %r13d
	jle	.L181
	movl	%ebp, %eax
	imull	%ebp, %eax
	movl	%eax, 32(%rsp)
	leal	9(%rbp), %eax
	movl	%eax, 36(%rsp)
	imull	%eax, %eax
	movl	%eax, 44(%rsp)
	movl	%r13d, %r11d
	movl	%r14d, %r15d
	movq	16(%rsp), %r13
	movq	%r12, %r14
	jmp	.L217
.L193:
	addq	$1, %rax
	cmpq	%r13, %rax
	je	.L246
.L194:
	movswl	(%rsi,%rax,2), %edx
	cmpl	%edi, %edx
	jl	.L193
	movswl	(%r9,%rax,2), %edx
	cmpl	%r10d, %edx
	jg	.L193
	movl	%r12d, %edx
	movb	%al, 880(%rsp,%rdx)
	movswl	(%rbx,%rax,2), %edx
	cmpl	%edx, %r8d
	cmovg	%edx, %r8d
	movswl	0(%rbp,%rax,2), %edx
	cmpl	%edx, %ecx
	cmovl	%edx, %ecx
	leal	1(%r12), %r12d
	jmp	.L193
.L246:
	movl	%r12d, 76(%rsp)
	testl	%r12d, %r12d
	jne	.L247
.L195:
	addl	$1, 72(%rsp)
	movl	72(%rsp), %eax
	cmpl	%eax, %r11d
	je	.L181
.L217:
	movl	72(%rsp), %eax
	sall	$4, %eax
	movl	%eax, 68(%rsp)
	leal	2(%rax), %edi
	leal	14(%rax), %r10d
	movl	$0, %eax
	movl	$-99999, %ecx
	movl	$99999, %r8d
	movl	$0, %r12d
	leaq	400(%rsp), %rsi
	leaq	304(%rsp), %r9
	leaq	112(%rsp), %rbx
	leaq	208(%rsp), %rbp
	jmp	.L194
.L247:
	subl	$14, %r8d
	leal	-2(%rcx), %eax
	sarl	$4, %eax
	sarl	$4, %r8d
	cmpl	%r15d, %r8d
	cmovl	%r15d, %r8d
	addl	$1, %eax
	movl	108(%rsp), %ebx
	cmpl	%ebx, %eax
	cmovg	%ebx, %eax
	movl	%eax, 80(%rsp)
	cmpl	%eax, %r8d
	jge	.L195
	movl	%r8d, %eax
	sall	$4, %eax
	leal	14(%rax), %ebx
	movl	%ebx, (%rsp)
	addl	$2, %eax
	movl	%eax, 60(%rsp)
	movl	68(%rsp), %eax
	addl	$8, %eax
	movl	%eax, 16(%rsp)
	movl	%r11d, 92(%rsp)
	movl	%r15d, 104(%rsp)
	movl	%r8d, %r12d
	movq	%r13, 96(%rsp)
	jmp	.L216
.L250:
	imull	%r8d, %r8d
	imull	%r11d, %r11d
	addl	%r11d, %r8d
	movl	44(%rsp), %r11d
	cmpl	%r11d, %r8d
	jle	.L198
	jmp	.L196
.L199:
	leal	(%rax,%rax,8), %r9d
	testl	%r10d, %r10d
	setne	%r8b
	cmpl	$0, 28(%rsp)
	sete	%al
	testb	%al, %r8b
	je	.L200
	cmpl	%r9d, %esi
	jg	.L248
.L200:
	movl	8(%rsp), %esi
	movl	%esi, %eax
	movb	%dil, 928(%rsp,%rax)
	leal	1(%rsi), %eax
	movl	%eax, 8(%rsp)
.L196:
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L249
.L202:
	movzbl	(%rdx), %edi
	movzbl	%dil, %eax
	movl	%eax, %ecx
	movswl	208(%rsp,%rcx,2), %ecx
	cmpl	%r13d, %ecx
	jl	.L196
	movl	%eax, %ecx
	movswl	112(%rsp,%rcx,2), %ecx
	movl	(%rsp), %esi
	cmpl	%esi, %ecx
	jg	.L196
	leal	(%rax,%rax), %esi
	movl	%esi, %ecx
	movswl	(%r14,%rcx,2), %r10d
	leal	1(%rsi), %ecx
	movl	%ecx, %ecx
	movswl	(%r14,%rcx,2), %ecx
	leal	2(%rsi), %r8d
	movl	%r8d, %r8d
	movswl	(%r14,%r8,2), %r12d
	movl	%r12d, %r9d
	subl	%r10d, %r9d
	addl	$3, %esi
	movl	%esi, %esi
	movswl	(%r14,%rsi,2), %ebp
	movl	%ebp, %esi
	subl	%ecx, %esi
	movl	4(%rsp), %r8d
	subl	%r10d, %r8d
	movl	16(%rsp), %r11d
	subl	%ecx, %r11d
	movl	%esi, %ecx
	imull	%r8d, %ecx
	movl	%r9d, %r10d
	imull	%r11d, %r10d
	movl	%r10d, %r15d
	subl	%ecx, %r15d
	subl	%r10d, %ecx
	cmovs	%r15d, %ecx
	movl	%eax, %eax
	movl	496(%rsp,%rax,4), %r10d
	leal	1(%r10), %eax
	movl	36(%rsp), %r15d
	imull	%eax, %r15d
	cmpl	%ecx, %r15d
	jl	.L196
	imull	%r8d, %r9d
	imull	%r11d, %esi
	addl	%r9d, %esi
	testl	%esi, %esi
	jle	.L250
.L198:
	movl	%eax, %r8d
	imull	%eax, %r8d
	cmpl	%esi, %r8d
	jg	.L199
	movl	4(%rsp), %r8d
	subl	%r12d, %r8d
	movl	16(%rsp), %r9d
	subl	%ebp, %r9d
	imull	%r8d, %r8d
	imull	%r9d, %r9d
	addl	%r9d, %r8d
	cmpl	%r8d, 44(%rsp)
	jge	.L199
	jmp	.L196
.L248:
	movl	%r10d, %eax
	imull	%r10d, %eax
	subl	%r9d, %eax
	cmpl	%esi, %eax
	jle	.L200
	movl	64(%rsp), %eax
	imull	%eax, %r10d
	subl	%r9d, %r10d
	cmpl	%ecx, %r10d
	jl	.L200
	movl	24(%rsp), %r12d
	movzwl	90(%rsp), %edx
	movl	$256, %ecx
	movl	72(%rsp), %esi
	movl	%r12d, %edi
	call	cr_blend
	jmp	.L219
.L254:
	movl	%r12d, %edi
	sall	$4, %edi
	leaq	CR_SS(%rip), %r9
	movl	$0, %ebp
	leaq	927(%rsp), %r11
	movl	%edi, 40(%rsp)
	movl	%r12d, 84(%rsp)
	movq	%r9, %r13
	jmp	.L204
.L206:
	testl	%eax, %eax
	jg	.L208
.L207:
	imull	%edi, %edi
	imull	%r10d, %r10d
	addl	%r10d, %edi
	movl	$0, %eax
	movl	32(%rsp), %ebx
	cmpl	%ebx, %edi
	jg	.L205
	movl	%edx, %edx
	movl	688(%rsp,%rdx,4), %eax
	jmp	.L210
.L208:
	movl	%esi, %eax
	subl	%ebp, %eax
	movl	%r8d, %edi
	subl	%ebx, %edi
	imull	%edi, %edi
	imull	%eax, %eax
	addl	%eax, %edi
	movl	32(%rsp), %eax
	cmpl	%eax, %edi
	jg	.L251
	movl	%edx, %edx
	movl	%r9d, %eax
	addl	688(%rsp,%rdx,4), %eax
.L210:
	movl	28(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L229
	cltd
	idivl	%ebx
	movl	56(%rsp), %eax
	cmpl	%eax, %edx
	setl	%al
	movzbl	%al, %eax
	jmp	.L205
.L223:
	movl	$0, %eax
.L205:
	cmpl	%r15d, %ecx
	setb	%dil
	testl	%eax, %eax
	sete	%dl
	addq	$1, %rcx
	testb	%dl, %dil
	je	.L252
.L213:
	movzbl	(%r11,%rcx), %edx
	movl	%edx, %eax
	movswl	112(%rsp,%rax,2), %eax
	cmpl	%esi, %eax
	jg	.L223
	movl	%edx, %eax
	movswl	208(%rsp,%rax,2), %eax
	cmpl	%esi, %eax
	jl	.L224
	movl	%edx, %eax
	movswl	304(%rsp,%rax,2), %eax
	cmpl	%r8d, %eax
	jg	.L225
	movl	%edx, %eax
	movswl	400(%rsp,%rax,2), %eax
	cmpl	%r8d, %eax
	jl	.L226
	leal	(%rdx,%rdx), %edi
	movl	%edi, %eax
	movswl	(%r14,%rax,2), %r9d
	leal	1(%rdi), %eax
	movl	%eax, %eax
	movswl	(%r14,%rax,2), %eax
	leal	2(%rdi), %r10d
	movl	%r10d, %r10d
	movswl	(%r14,%r10,2), %ebp
	movl	%ebp, %r13d
	subl	%r9d, %r13d
	addl	$3, %edi
	movl	%edi, %edi
	movswl	(%r14,%rdi,2), %ebx
	movl	%ebx, %r12d
	subl	%eax, %r12d
	movl	%esi, %edi
	subl	%r9d, %edi
	movl	%r8d, %r10d
	subl	%eax, %r10d
	movl	%r13d, %eax
	imull	%edi, %eax
	movl	%r12d, 24(%rsp)
	movl	%r12d, %r9d
	imull	%r10d, %r9d
	addl	%r9d, %eax
	movl	%edx, %r9d
	movl	496(%rsp,%r9,4), %r9d
	testl	%r9d, %r9d
	je	.L206
	testl	%eax, %eax
	jle	.L207
	movl	%r9d, %r12d
	imull	%r9d, %r12d
	cmpl	%eax, %r12d
	jle	.L208
	movl	24(%rsp), %r12d
	imull	%r12d, %edi
	imull	%r13d, %r10d
	movl	%r10d, %ebx
	subl	%edi, %ebx
	subl	%r10d, %edi
	cmovs	%ebx, %edi
	movl	64(%rsp), %r10d
	imull	%r9d, %r10d
	cmpl	%edi, %r10d
	jl	.L227
	movl	%edx, %edi
	cltd
	idivl	%r9d
	addl	688(%rsp,%rdi,4), %eax
	jmp	.L210
.L224:
	movl	$0, %eax
	jmp	.L205
.L225:
	movl	$0, %eax
	jmp	.L205
.L226:
	movl	$0, %eax
	jmp	.L205
.L227:
	movl	$0, %eax
	jmp	.L205
.L251:
	movl	$0, %eax
	jmp	.L205
.L252:
	movl	4(%rsp), %ebp
	movq	8(%rsp), %rbx
	jmp	.L212
.L229:
	movl	4(%rsp), %ebp
	movq	8(%rsp), %rbx
	movl	$1, %eax
.L212:
	addl	%eax, %ebp
	addq	$1, %rbx
	leaq	4+CR_SS(%rip), %rax
	cmpq	%rbx, %rax
	je	.L253
.L214:
	movzbl	(%rbx), %esi
	movl	40(%rsp), %eax
	addl	%eax, %esi
	movl	$1, %ecx
	movl	%ebp, 4(%rsp)
	movq	%rbx, 8(%rsp)
	jmp	.L213
.L253:
	movq	48(%rsp), %r13
	addq	$1, %r13
	cmpq	%r13, %rax
	je	.L215
.L204:
	movzbl	0(%r13), %r8d
	movl	68(%rsp), %eax
	addl	%eax, %r8d
	leaq	CR_SS(%rip), %rbx
	movq	%r13, 48(%rsp)
	jmp	.L214
.L215:
	movl	84(%rsp), %r12d
	movl	%ebp, %ecx
	sall	$4, %ecx
	movzwl	90(%rsp), %edx
	movl	72(%rsp), %esi
	movl	%r12d, %edi
	call	cr_blend
	jmp	.L219
.L255:
	movl	92(%rsp), %r11d
	movl	104(%rsp), %r15d
	movq	96(%rsp), %r13
	jmp	.L195
.L249:
	movl	8(%rsp), %r15d
	movl	24(%rsp), %r12d
	testl	%r15d, %r15d
	jne	.L254
.L219:
	addl	$1, %r12d
	addl	$16, (%rsp)
	addl	$16, 60(%rsp)
	cmpl	%r12d, 80(%rsp)
	je	.L255
.L216:
	movl	60(%rsp), %r13d
	leal	6(%r13), %eax
	movl	%eax, 4(%rsp)
	leaq	880(%rsp), %rdx
	movl	76(%rsp), %ebx
	addq	%rdx, %rbx
	movl	$0, %r15d
	movl	%r15d, 8(%rsp)
	movl	%r12d, 24(%rsp)
	jmp	.L202
.L181:
	movq	984(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L256
	addq	$1000, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L256:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE109:
	.size	cr_poly, .-cr_poly
	.type	cr_glyph_of, @function
cr_glyph_of:
.LFB112:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	movl	%esi, %ebp
	call	glyph_at
	testl	%eax, %eax
	jns	.L258
	cmpl	$133, %ebp
	je	.L261
.L258:
	testl	%eax, %eax
	js	.L262
.L259:
	movzbl	48(%rbx), %ecx
	sall	%cl, %eax
	movq	8(%rbx), %rdx
	leaq	(%rdx,%rax,8), %rax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L261:
	.cfi_restore_state
	movl	$46, %esi
	movq	%rbx, %rdi
	call	glyph_at
	jmp	.L258
.L262:
	movl	$63, %esi
	movq	%rbx, %rdi
	call	glyph_at
	testl	%eax, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	jmp	.L259
	.cfi_endproc
.LFE112:
	.size	cr_glyph_of, .-cr_glyph_of
	.type	cr_covers, @function
cr_covers:
.LFB113:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	movzbl	(%rsi), %esi
	testb	%sil, %sil
	je	.L266
.L265:
	movzbl	%sil, %esi
	movq	%rbp, %rdi
	call	glyph_at
	testl	%eax, %eax
	js	.L267
	addq	$1, %rbx
	movzbl	(%rbx), %esi
	testb	%sil, %sil
	jne	.L265
	movl	$1, %eax
	jmp	.L263
.L266:
	movl	$1, %eax
	jmp	.L263
.L267:
	movl	$0, %eax
.L263:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE113:
	.size	cr_covers, .-cr_covers
	.type	cr_adv8, @function
cr_adv8:
.LFB114:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movl	%edx, %r14d
	movzbl	(%rsi), %edx
	testb	%dl, %dl
	je	.L274
	movq	%rdi, %r13
	movq	%rsi, %rbx
	movl	$0, %ebp
	movl	$0, %r12d
	jmp	.L273
.L272:
	movl	%ebp, %esi
	movq	%r13, %rdi
	call	cr_glyph_of
	movzwl	2(%rax), %eax
	addl	%eax, %r12d
	addq	$1, %rbx
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	je	.L271
.L273:
	movl	%ebp, %esi
	movzbl	%dl, %ebp
	testl	%esi, %esi
	je	.L272
	movl	%ebp, %edx
	movq	%r13, %rdi
	call	kern
	addl	%eax, %r12d
	jmp	.L272
.L274:
	movl	$0, %r12d
.L271:
	movl	%r14d, %eax
	imull	%r12d, %eax
	sarl	$8, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE114:
	.size	cr_adv8, .-cr_adv8
	.type	cr_rgb, @function
cr_rgb:
.LFB121:
	.cfi_startproc
	leal	-1(%rdi), %eax
	cmpl	$7, %eax
	jbe	.L291
	subl	$9, %edi
	cmpl	$8, %edi
	ja	.L290
	movl	%edi, %edi
	leaq	.L281(%rip), %rdx
	movslq	(%rdx,%rdi,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L281:
	.long	.L289-.L281
	.long	.L288-.L281
	.long	.L287-.L281
	.long	.L286-.L281
	.long	.L285-.L281
	.long	.L284-.L281
	.long	.L283-.L281
	.long	.L282-.L281
	.long	.L280-.L281
	.text
.L291:
	movl	%edi, %edi
	leaq	CR_NAMED(%rip), %rax
	movzwl	(%rax,%rdi,2), %eax
	ret
.L289:
	movzwl	ux(%rip), %eax
	ret
.L288:
	movzwl	2+ux(%rip), %eax
	ret
.L287:
	movzwl	4+ux(%rip), %eax
	ret
.L286:
	movzwl	6+ux(%rip), %eax
	ret
.L285:
	movzwl	8+ux(%rip), %eax
	ret
.L284:
	movzwl	10+ux(%rip), %eax
	ret
.L283:
	movzwl	12+ux(%rip), %eax
	ret
.L282:
	movzwl	14+ux(%rip), %eax
	ret
.L280:
	movzwl	22+ux(%rip), %eax
	ret
.L290:
	movl	%esi, %eax
	ret
	.cfi_endproc
.LFE121:
	.size	cr_rgb, .-cr_rgb
	.type	cr_face, @function
cr_face:
.LFB122:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%esi, %ebx
	testl	%edx, %edx
	je	.L293
	cmpl	$40, %esi
	ja	.L300
.L294:
	movl	%ebx, %eax
	sall	$12, %eax
	movl	$0, %ecx
	leaq	AF_CRB(%rip), %rdi
	movl	$40, %esi
	jmp	.L296
.L300:
	movq	%rdi, %rsi
	leaq	AF_CRX(%rip), %rdi
	call	cr_covers
	testl	%eax, %eax
	je	.L294
	movl	%ebx, %eax
	sall	$12, %eax
	movl	$0, %ecx
	leaq	AF_CRX(%rip), %rdi
	movl	$104, %esi
	jmp	.L296
.L293:
	cmpl	$12, %esi
	ja	.L297
	sete	%cl
	movzbl	%cl, %ecx
	movl	%esi, %eax
	sall	$12, %eax
	leaq	AF_S(%rip), %rdi
	movl	$12, %esi
	jmp	.L296
.L297:
	movl	$1, %ecx
	leaq	AF_M(%rip), %rdi
	movl	$61440, %eax
	movl	$15, %esi
.L296:
	salq	$32, %rcx
	movl	$0, %edx
	divl	%esi
	orq	%rcx, %rax
	movq	%rax, %rdx
	movq	%rdi, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE122:
	.size	cr_face, .-cr_face
	.type	cr_tw, @function
cr_tw:
.LFB123:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	call	cr_face
	movq	%rax, %rdi
	movq	%rdx, %rax
	sarq	$32, %rax
	testl	%eax, %eax
	je	.L302
	movq	%rbx, %rsi
	call	text_w
	sall	$8, %eax
.L303:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L302:
	.cfi_restore_state
	movq	%rbx, %rsi
	call	cr_adv8
	jmp	.L303
	.cfi_endproc
.LFE123:
	.size	cr_tw, .-cr_tw
	.type	cr_fit, @function
cr_fit:
.LFB125:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movl	%esi, 12(%rsp)
	movq	%rdx, %r12
	movl	%ecx, %esi
	movl	%r8d, %edx
	movl	%r9d, %r13d
	movq	%r12, %rdi
	call	cr_face
	movq	%rax, %r14
	movl	%edx, %r15d
	sarq	$32, %rdx
	movl	%edx, 8(%rsp)
	testl	%edx, %edx
	jne	.L306
	movzbl	(%r12), %edx
	testb	%dl, %dl
	je	.L331
	movl	%ebp, %edi
	movl	$1, %eax
	cmpl	$1, %ebp
	ja	.L320
	movb	$0, (%rbx)
	cmpb	$0, (%r12)
	je	.L345
.L330:
	movl	12(%rsp), %ebp
	subl	$2, %ebp
	jmp	.L322
.L306:
	sarl	$8, %r13d
	movzbl	(%r12), %edx
	testb	%dl, %dl
	je	.L332
	movl	12(%rsp), %eax
	cmpl	$1, %eax
	jbe	.L311
	movl	%eax, %edi
	movl	$1, %eax
	jmp	.L312
.L333:
	movq	%rcx, %rax
.L312:
	movl	%eax, %ebp
	movb	%dl, -1(%rbx,%rax)
	leaq	(%r12,%rax), %rsi
	movzbl	(%r12,%rax), %edx
	testb	%dl, %dl
	je	.L310
	leaq	1(%rax), %rcx
	cmpq	%rdi, %rcx
	jne	.L333
.L310:
	movb	$0, (%rbx,%rax)
	cmpb	$0, (%rsi)
	je	.L346
.L313:
	leal	2(%rbp), %eax
	cmpl	%eax, 12(%rsp)
	jb	.L328
.L315:
	leal	-1(%rbp), %r12d
	movl	%ebp, %ebp
	addq	%rbx, %rbp
	jmp	.L316
.L332:
	movq	%r12, %rsi
	movl	$0, %ebp
	movl	$0, %eax
	jmp	.L310
.L346:
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	text_w
	movl	$0, 8(%rsp)
	cmpl	%eax, %r13d
	jge	.L339
	jmp	.L313
.L335:
	movq	%rcx, %rax
.L320:
	movl	%eax, %ebp
	movb	%dl, -1(%rbx,%rax)
	leaq	(%r12,%rax), %rsi
	movzbl	(%r12,%rax), %edx
	testb	%dl, %dl
	je	.L307
	leaq	1(%rax), %rcx
	cmpq	%rdi, %rcx
	jne	.L335
.L307:
	movb	$0, (%rbx,%rax)
	cmpb	$0, (%rsi)
	je	.L347
.L321:
	leal	2(%rbp), %eax
	cmpl	%eax, 12(%rsp)
	jb	.L330
.L322:
	leal	-1(%rbp), %r12d
	movl	%ebp, %ebp
	addq	%rbx, %rbp
	jmp	.L323
.L331:
	movq	%r12, %rsi
	movl	$0, %ebp
	movl	$0, %eax
	jmp	.L307
.L347:
	movl	%r15d, %edx
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	cr_adv8
	cmpl	%r13d, %eax
	jle	.L339
	jmp	.L321
.L348:
	movl	$1, 8(%rsp)
	jmp	.L339
.L350:
	movl	$1, 8(%rsp)
	jmp	.L339
.L342:
	movb	$-123, 0(%rbp)
	leal	2(%r12), %eax
	movb	$0, (%rbx,%rax)
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	text_w
	cmpl	%eax, %r13d
	jge	.L348
.L318:
	subl	$1, %r12d
	subq	$1, %rbp
.L316:
	cmpl	$-1, %r12d
	je	.L317
	movl	%r12d, %eax
	cmpb	$32, (%rbx,%rax)
	jne	.L342
	jmp	.L318
.L317:
	movb	$-123, (%rbx)
	movb	$0, 1(%rbx)
	movl	$1, 8(%rsp)
	jmp	.L339
.L311:
	movb	$0, (%rbx)
	cmpb	$0, (%r12)
	je	.L349
.L328:
	movl	12(%rsp), %ebp
	subl	$2, %ebp
	jmp	.L315
.L343:
	movb	$-123, 0(%rbp)
	leal	2(%r12), %eax
	movb	$0, (%rbx,%rax)
	movl	%r15d, %edx
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	cr_adv8
	cmpl	%r13d, %eax
	jle	.L350
.L325:
	subl	$1, %r12d
	subq	$1, %rbp
.L323:
	cmpl	$-1, %r12d
	je	.L324
	movl	%r12d, %eax
	cmpb	$32, (%rbx,%rax)
	jne	.L343
	jmp	.L325
.L324:
	movb	$-123, (%rbx)
	movb	$0, 1(%rbx)
	movl	$1, 8(%rsp)
.L339:
	movl	8(%rsp), %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L349:
	.cfi_restore_state
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	text_w
	movl	$0, 8(%rsp)
	cmpl	%eax, %r13d
	jge	.L339
	jmp	.L328
.L345:
	movl	%r15d, %edx
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	cr_adv8
	cmpl	%eax, %r13d
	jl	.L330
	jmp	.L339
	.cfi_endproc
.LFE125:
	.size	cr_fit, .-cr_fit
	.type	cr_ease_out, @function
cr_ease_out:
.LFB127:
	.cfi_startproc
	movl	%edi, %eax
	movl	$4096, %ecx
	cmpl	%esi, %edi
	jnb	.L351
	sall	$12, %eax
	movl	$0, %edx
	divl	%esi
	movl	%ecx, %edx
	subl	%eax, %edx
	imull	%edx, %edx
	sarl	$12, %edx
	subl	%edx, %ecx
.L351:
	movl	%ecx, %eax
	ret
	.cfi_endproc
.LFE127:
	.size	cr_ease_out, .-cr_ease_out
	.type	cr_battery, @function
cr_battery:
.LFB134:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movl	%edi, %ebx
	movl	%esi, %ebp
	movzwl	10+ux(%rip), %r12d
	leal	1(%rdi), %r13d
	movl	%r12d, %r8d
	movl	$1, %ecx
	movl	$14, %edx
	movl	$7, %esi
	movl	%r13d, %edi
	call	cr_fill
	movl	%r12d, %r8d
	movl	$1, %ecx
	movl	$14, %edx
	movl	$16, %esi
	movl	%r13d, %edi
	call	cr_fill
	movl	%r12d, %r8d
	movl	$8, %ecx
	movl	$1, %edx
	movl	$8, %esi
	movl	%ebx, %edi
	call	cr_fill
	leal	15(%rbx), %edi
	movl	%r12d, %r8d
	movl	$8, %ecx
	movl	$1, %edx
	movl	$8, %esi
	call	cr_fill
	addl	$16, %ebx
	sall	$4, %ebx
	leal	8(%rbx), %edi
	movl	%r12d, %r8d
	movl	$80, %ecx
	movl	$32, %edx
	movl	$152, %esi
	call	cr_frect
	testl	%ebp, %ebp
	je	.L354
	cmpl	$2, %ebp
	sbbl	%eax, %eax
	andl	$5083, %eax
	movl	$4, %edx
	cmpl	%edx, %ebp
	cmova	%edx, %ebp
	leal	0(%rbp,%rbp,2), %edx
	sall	$6, %edx
	shrl	$2, %edx
	leal	-224(%rbx), %edi
	leal	57797(%rax), %r8d
	movl	$96, %ecx
	movl	$144, %esi
	call	cr_frect
.L354:
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE134:
	.size	cr_battery, .-cr_battery
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	""
	.text
	.type	cr_item, @function
cr_item:
.LFB140:
	.cfi_startproc
	leaq	.LC0(%rip), %rax
	testl	%esi, %esi
	js	.L359
	movzbl	315(%rdi), %edx
	cmpl	%esi, %edx
	jle	.L359
	movzbl	316(%rdi), %eax
	subl	%eax, %esi
	leaq	.LC0(%rip), %rax
	cmpl	$7, %esi
	ja	.L359
	movslq	%esi, %rsi
	salq	$5, %rsi
	leaq	322(%rdi,%rsi), %rax
.L359:
	ret
	.cfi_endproc
.LFE140:
	.size	cr_item, .-cr_item
	.type	cr_pick_marks, @function
cr_pick_marks:
.LFB141:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	movl	%esi, 4(%rsp)
	movl	%edx, 8(%rsp)
	movw	%cx, 14(%rsp)
	movl	$200, %eax
	movl	$0, %edx
	idivl	%edi
	leal	-3(%rax), %r12d
	testl	%r12d, %r12d
	movl	$1, %eax
	cmovle	%eax, %r12d
	movl	$8, %eax
	cmpl	%eax, %r12d
	cmovg	%eax, %r12d
	movl	%edi, %eax
	imull	%r12d, %eax
	leal	-4(%rax,%rdi,4), %eax
	movl	%eax, %ebx
	shrl	$31, %ebx
	addl	%eax, %ebx
	sarl	%ebx
	negl	%ebx
	addl	$120, %ebx
	testl	%edi, %edi
	jle	.L364
	movl	%edi, %r13d
	leal	4(%r12), %r14d
	movl	$0, %ebp
	leaq	ux(%rip), %r15
	jmp	.L368
.L367:
	movl	$4, %ecx
	movl	%r12d, %edx
	movl	8(%rsp), %esi
	movl	%ebx, %edi
	call	cr_fill
	addl	$1, %ebp
	addl	%r14d, %ebx
	cmpl	%ebp, %r13d
	je	.L364
.L368:
	movzwl	14(%rsp), %r8d
	cmpl	%ebp, 4(%rsp)
	je	.L367
	movzwl	14(%r15), %r8d
	jmp	.L367
.L364:
	addq	$16, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE141:
	.size	cr_pick_marks, .-cr_pick_marks
	.type	cr_mshape, @function
cr_mshape:
.LFB149:
	.cfi_startproc
	cmpl	$4, %edi
	ja	.L373
	movl	%edi, %edi
	leaq	.L374(%rip), %rcx
	movslq	(%rcx,%rdi,4), %rax
	addq	%rcx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L374:
	.long	.L378-.L374
	.long	.L377-.L374
	.long	.L376-.L374
	.long	.L375-.L374
	.long	.L383-.L374
	.text
.L378:
	sall	$4, %esi
	movl	%esi, %edi
	call	cr_sin
	sarl	$2, %eax
	negl	%eax
	ret
.L377:
	addl	$3072, %esi
	movl	%esi, %edx
	andl	$4095, %edx
	testl	$2048, %esi
	jne	.L380
	leal	-4096(,%rdx,4), %eax
	ret
.L380:
	movl	$3072, %eax
	subl	%edx, %eax
	sall	$2, %eax
	ret
.L376:
	leal	-4096(%rsi,%rsi), %eax
	ret
.L375:
	cmpl	$2047, %esi
	jle	.L381
	cmpl	$2048, %esi
	jne	.L382
	testl	%edx, %edx
	je	.L382
.L381:
	negl	%esi
	leal	(%rsi,%rsi), %eax
	ret
.L382:
	movl	$4096, %eax
	subl	%esi, %eax
	addl	%eax, %eax
	ret
.L383:
	movl	$2048, %ecx
.L373:
	cmpl	%esi, %ecx
	jg	.L384
	jne	.L385
	testl	%edx, %edx
	jne	.L386
.L385:
	movl	$4096, %eax
	ret
.L386:
	movl	$-4096, %eax
	ret
.L384:
	movl	$-4096, %eax
	ret
	.cfi_endproc
.LFE149:
	.size	cr_mshape, .-cr_mshape
	.type	cr_srect, @function
cr_srect:
.LFB151:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	movl	%esi, %r12d
	movl	%ecx, 4(%rsp)
	movl	%r8d, %ebp
	movzwl	%r9w, %r13d
	movl	%edx, 12(%rsp)
	leal	(%rdx,%r8), %r15d
	movl	%r8d, %ebx
	shrl	$31, %ebx
	addl	%r8d, %ebx
	sarl	%ebx
	negl	%ebx
	movl	%edi, 8(%rsp)
	leal	(%rbx,%rdi), %r14d
	leal	(%rbx,%rsi), %esi
	movl	%r13d, %r8d
	movl	%ebp, %ecx
	movl	%r15d, %edx
	movl	%r14d, %edi
	call	cr_frect
	movl	4(%rsp), %eax
	leal	(%r12,%rax), %esi
	addl	%ebx, %esi
	movl	%r13d, %r8d
	movl	%ebp, %ecx
	movl	%r15d, %edx
	movl	%r14d, %edi
	call	cr_frect
	movl	4(%rsp), %r15d
	subl	%ebp, %r15d
	subl	%ebx, %r12d
	movl	%r13d, %r8d
	movl	%r15d, %ecx
	movl	%ebp, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	cr_frect
	movl	12(%rsp), %edx
	movl	8(%rsp), %edi
	addl	%edx, %edi
	addl	%ebx, %edi
	movl	%r13d, %r8d
	movl	%r15d, %ecx
	movl	%ebp, %edx
	movl	%r12d, %esi
	call	cr_frect
	addq	$16, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE151:
	.size	cr_srect, .-cr_srect
	.type	cr_moon_in, @function
cr_moon_in:
.LFB152:
	.cfi_startproc
	movq	%rdx, %r10
	movq	%rcx, %r11
	movslq	%edi, %rax
	imulq	%rax, %rax
	movq	%rax, %rdx
	movslq	%esi, %rax
	imulq	%rax, %rax
	leaq	(%rdx,%rax), %rsi
	movl	$0, %ecx
	cmpq	%r10, %rsi
	jg	.L389
	imulq	%r10, %rdx
	imulq	%r11, %rax
	addq	%rdx, %rax
	testl	%r9d, %r9d
	je	.L391
	notl	%edi
	shrl	$31, %edi
	cmpq	%r8, %rax
	setle	%cl
	movzbl	%cl, %ecx
	orl	%edi, %ecx
.L389:
	movl	%ecx, %eax
	ret
.L391:
	notl	%edi
	shrl	$31, %edi
	cmpq	%r8, %rax
	setge	%cl
	andl	%edi, %ecx
	jmp	.L389
	.cfi_endproc
.LFE152:
	.size	cr_moon_in, .-cr_moon_in
	.type	cr_lfo_y, @function
cr_lfo_y:
.LFB155:
	.cfi_startproc
	cmpl	$6, %edi
	ja	.L394
	movl	%edi, %edi
	leaq	.L396(%rip), %rdx
	movslq	(%rdx,%rdi,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L396:
	.long	.L401-.L396
	.long	.L394-.L396
	.long	.L400-.L396
	.long	.L399-.L396
	.long	.L398-.L396
	.long	.L397-.L396
	.long	.L395-.L396
	.text
.L401:
	cmpl	$1023, %esi
	jg	.L402
	movl	%esi, %eax
	sall	$4, %eax
	ret
.L402:
	cmpl	$3071, %esi
	jg	.L404
	movl	$2048, %eax
	subl	%esi, %eax
	sall	$4, %eax
	ret
.L404:
	subl	$4096, %esi
	movl	%esi, %eax
	sall	$4, %eax
	ret
.L400:
	cmpl	$2047, %esi
	movl	$-16384, %eax
	movl	$16384, %edx
	cmovle	%edx, %eax
	ret
.L399:
	leal	-16384(,%rsi,8), %eax
	ret
.L398:
	movl	$2048, %eax
	subl	%esi, %eax
	sall	$3, %eax
	ret
.L397:
	movl	%esi, %eax
	sarl	$8, %eax
	movzbl	%sil, %edi
	cmpl	$4095, %esi
	jg	.L406
	leaq	EX.3(%rip), %rdx
	movslq	%eax, %rcx
	movswl	(%rdx,%rcx,2), %ecx
	addl	$1, %eax
	cltq
	movswl	(%rdx,%rax,2), %edx
	subl	%ecx, %edx
	imull	%edi, %edx
	leal	255(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$8, %eax
	addl	%ecx, %eax
	ret
.L395:
	sarl	$9, %esi
	movl	$7, %eax
	cmpl	%eax, %esi
	cmovg	%eax, %esi
	movslq	%esi, %rsi
	leaq	RN.2(%rip), %rax
	movswl	(%rax,%rsi,2), %eax
	sall	$6, %eax
	ret
.L394:
	sall	$4, %esi
	movl	%esi, %edi
	call	cr_sin
	ret
.L406:
	movl	$-16384, %eax
	ret
	.cfi_endproc
.LFE155:
	.size	cr_lfo_y, .-cr_lfo_y
	.type	cr_hbar, @function
cr_hbar:
.LFB158:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movl	%r9d, 4(%rsp)
	movzbl	27(%rdi), %eax
	movzbl	%al, %ebx
	cmpb	$-1, %al
	movl	$256, %eax
	cmove	%eax, %ebx
	testb	$2, 24(%rdi)
	jne	.L415
.L407:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L415:
	.cfi_restore_state
	movq	%rdi, %rbp
	movl	%esi, %r15d
	movl	%edx, %r14d
	movl	%ecx, %r12d
	movl	%r8d, %r13d
	movzwl	14+ux(%rip), %r8d
	movl	%r13d, %ecx
	movl	%r12d, %esi
	movl	%r15d, %edi
	call	cr_frect
	testb	$4, 24(%rbp)
	je	.L410
	movl	%r14d, %ebp
	shrl	$31, %ebp
	addl	%r14d, %ebp
	sarl	%ebp
	addl	%r15d, %ebp
	addl	$-128, %ebx
	imull	%r14d, %ebx
	leal	255(%rbx), %edx
	testl	%ebx, %ebx
	cmovns	%ebx, %edx
	sarl	$8, %edx
	cmpl	$255, %ebx
	jg	.L416
	cmpl	$-255, %ebx
	jl	.L417
.L412:
	leal	64(%r13), %ecx
	leal	-32(%r12), %esi
	leal	-8(%rbp), %edi
	movzwl	4(%rsp), %r8d
	movl	$16, %edx
	call	cr_frect
	jmp	.L407
.L416:
	movzwl	4(%rsp), %r8d
	movl	%r13d, %ecx
	movl	%r12d, %esi
	movl	%ebp, %edi
	call	cr_frect
	jmp	.L412
.L417:
	movl	%edx, %eax
	negl	%eax
	leal	0(%rbp,%rdx), %edi
	movzwl	4(%rsp), %r8d
	movl	%r13d, %ecx
	movl	%eax, %edx
	movl	%r12d, %esi
	call	cr_frect
	jmp	.L412
.L410:
	testl	%ebx, %ebx
	je	.L407
	imull	%r14d, %ebx
	leal	255(%rbx), %edx
	testl	%ebx, %ebx
	cmovns	%ebx, %edx
	sarl	$8, %edx
	movzwl	4(%rsp), %r8d
	movl	%r13d, %ecx
	movl	%r12d, %esi
	movl	%r15d, %edi
	call	cr_frect
	jmp	.L407
	.cfi_endproc
.LFE158:
	.size	cr_hbar, .-cr_hbar
	.type	cr_log2, @function
cr_log2:
.LFB165:
	.cfi_startproc
	movl	$0, %eax
	testl	%edi, %edi
	je	.L418
	js	.L423
	movl	$31, %eax
.L421:
	subl	$1, %eax
	movl	%edi, %edx
	movl	%eax, %ecx
	shrl	%cl, %edx
	testl	%edx, %edx
	je	.L421
.L420:
	movl	$31, %ecx
	subl	%eax, %ecx
	sall	%cl, %edi
	shrl	$19, %edi
	andl	$4095, %edi
	sall	$12, %eax
	addl	%edi, %eax
.L418:
	ret
.L423:
	movl	$31, %eax
	jmp	.L420
	.cfi_endproc
.LFE165:
	.size	cr_log2, .-cr_log2
	.type	cr_full_band, @function
cr_full_band:
.LFB171:
	.cfi_startproc
	movzbl	1855(%rdi), %eax
	cmpb	$12, %al
	ja	.L426
	cmpb	$7, %al
	seta	%al
	movzbl	%al, %eax
	ret
.L426:
	subl	$14, %eax
	cmpb	$5, %al
	setbe	%al
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE171:
	.size	cr_full_band, .-cr_full_band
	.type	cr_ccol, @function
cr_ccol:
.LFB179:
	.cfi_startproc
	movzwl	12+ux(%rip), %eax
	testl	%esi, %esi
	je	.L428
	andl	$3, %edi
	leaq	CR_KC(%rip), %rax
	movzbl	(%rax,%rdi), %edx
	leaq	CR_NAMED(%rip), %rax
	movzwl	(%rax,%rdx,2), %eax
.L428:
	ret
	.cfi_endproc
.LFE179:
	.size	cr_ccol, .-cr_ccol
	.type	cr_in_strip, @function
cr_in_strip:
.LFB180:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebp
	movl	%esi, %ebx
	call	cr_row0
	movl	%eax, %edx
	movl	$0, %eax
	cmpl	%ebx, %edx
	jge	.L431
	call	cr_row1
	cmpl	%ebp, %eax
	setg	%al
	movzbl	%al, %eax
.L431:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE180:
	.size	cr_in_strip, .-cr_in_strip
	.type	cr_hcol, @function
cr_hcol:
.LFB181:
	.cfi_startproc
	movl	%esi, %eax
	movzbl	1854(%rdi), %edi
	testb	%dil, %dil
	je	.L436
	movzwl	%si, %esi
	movzbl	%dil, %edi
	call	cr_rgb
.L436:
	ret
	.cfi_endproc
.LFE181:
	.size	cr_hcol, .-cr_hcol
	.type	cr_mark, @function
cr_mark:
.LFB182:
	.cfi_startproc
	movzwl	24(%rdi), %edi
	shrw	$4, %di
	andl	$15, %edi
	jne	.L443
	ret
.L443:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%esi, %ebx
	movl	%edx, %ebp
	movl	$63389, %esi
	call	cr_rgb
	leal	-4(%rbx), %edi
	movzwl	%ax, %r8d
	movl	$4, %ecx
	movl	$4, %edx
	movl	%ebp, %esi
	call	cr_fill
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE182:
	.size	cr_mark, .-cr_mark
	.type	cr_hash, @function
cr_hash:
.LFB197:
	.cfi_startproc
	movl	%edi, %eax
	leal	-1(%rdx), %ecx
	testl	%edx, %edx
	je	.L444
	movl	%ecx, %ecx
	leaq	1(%rsi,%rcx), %rcx
.L446:
	addq	$1, %rsi
	movzbl	-1(%rsi), %edx
	xorl	%edx, %eax
	imull	$16777619, %eax, %eax
	cmpq	%rcx, %rsi
	jne	.L446
.L444:
	ret
	.cfi_endproc
.LFE197:
	.size	cr_hash, .-cr_hash
	.type	cr_cv_begin, @function
cr_cv_begin:
.LFB199:
	.cfi_startproc
	movzwl	ux(%rip), %edx
	movzbl	%dh, %eax
	sall	$8, %edx
	orl	%eax, %edx
	movl	$240, cv_w(%rip)
	movl	$40, cv_h(%rip)
	movw	$0, cv_cy0(%rip)
	movw	$40, cv_cy1(%rip)
	leaq	cv_px(%rip), %rax
	leaq	19200(%rax), %rcx
.L450:
	movw	%dx, (%rax)
	addq	$2, %rax
	cmpq	%rcx, %rax
	jne	.L450
	ret
	.cfi_endproc
.LFE199:
	.size	cr_cv_begin, .-cr_cv_begin
	.type	cr_strips_of, @function
cr_strips_of:
.LFB203:
	.cfi_startproc
	movl	$40, %r8d
	movl	$0, %edx
	movl	$0, %eax
	movl	$1, %r11d
	jmp	.L457
.L464:
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L463:
	.cfi_restore 3
	addl	$40, %r8d
	cmpl	$6, %edx
	je	.L462
.L457:
	movl	%edx, %ecx
	addl	$1, %edx
	cmpl	%r8d, %edi
	jge	.L463
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
.L458:
	leal	-40(%r8), %r9d
	movl	%eax, %r10d
	movl	%r11d, %ebx
	sall	%cl, %ebx
	orl	%ebx, %eax
	cmpl	%r9d, %esi
	cmovle	%r10d, %eax
.L453:
	addl	$40, %r8d
	cmpl	$6, %edx
	je	.L464
	movl	%edx, %ecx
	addl	$1, %edx
	cmpl	%r8d, %edi
	jge	.L453
	jmp	.L458
.L462:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE203:
	.size	cr_strips_of, .-cr_strips_of
	.type	cr_ed_row_strips, @function
cr_ed_row_strips:
.LFB204:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbp
	movl	%esi, %ebx
	movzbl	(%rdi), %eax
	cmpb	$13, %al
	je	.L481
	cmpb	$14, %al
	je	.L482
	cmpb	$0, 1856(%rdi)
	jne	.L476
	cmpl	$1, %esi
	ja	.L476
	call	cr_full_band
	testl	%eax, %eax
	jne	.L483
	cmpb	$0, 1855(%rbp)
	jne	.L484
	cmpl	$1, %ebx
	sbbl	%esi, %esi
	andl	$-104, %esi
	addl	$236, %esi
	cmpl	$1, %ebx
	sbbl	%edi, %edi
	andl	$-104, %edi
	addl	$132, %edi
	call	cr_strips_of
	jmp	.L465
.L481:
	movzbl	1850(%rdi), %eax
	movl	$8, %edx
	cmpb	%dl, %al
	cmova	%edx, %eax
	testb	%al, %al
	movl	$1, %edx
	cmove	%edx, %eax
	movzbl	%al, %ecx
	movl	$50688, %eax
	movl	$0, %edx
	idivl	%ecx
	imull	%eax, %ebx
	leal	10496(%rbx), %edi
	leal	(%rax,%rdi), %esi
	movl	%esi, %eax
	sarl	$8, %eax
	leal	1(%rax), %esi
	sarl	$8, %edi
	subl	$1, %edi
	call	cr_strips_of
	jmp	.L465
.L482:
	cmpb	$1, 47(%rdi)
	sbbl	%edi, %edi
	andl	$42, %edi
	addl	$170, %edi
	movl	$0, %eax
	testl	%esi, %esi
	jne	.L465
	leal	30(%rdi), %esi
	subl	$46, %edi
	call	cr_strips_of
	jmp	.L465
.L483:
	movl	$0, %eax
	testl	%ebx, %ebx
	jne	.L465
	movl	$240, %esi
	movl	$182, %edi
	call	cr_strips_of
	jmp	.L465
.L484:
	cmpl	$1, %ebx
	sbbl	%esi, %esi
	andl	$-60, %esi
	addl	$242, %esi
	cmpl	$1, %ebx
	sbbl	%edi, %edi
	andl	$-60, %edi
	addl	$182, %edi
	call	cr_strips_of
	jmp	.L465
.L476:
	movl	$63, %eax
.L465:
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE204:
	.size	cr_ed_row_strips, .-cr_ed_row_strips
	.type	cr_ed_strips, @function
cr_ed_strips:
.LFB205:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	movq	%rdi, %r12
	movq	%rsi, %r13
	movl	%edx, 12(%rsp)
	movl	%ecx, 4(%rsp)
	movzbl	(%rdi), %r15d
	cmpb	$12, %r15b
	je	.L502
	leal	-12(%r15), %eax
	movl	$63, %ebp
	cmpb	$2, %al
	ja	.L485
	movl	$63, 8(%rsp)
.L495:
	movl	$0, %ebx
	movl	$0, %ebp
	leaq	488+cr_dc(%rip), %r14
	jmp	.L491
.L502:
	movl	$63, 8(%rsp)
	cmpb	$0, 1855(%rdi)
	je	.L495
	cmpb	$0, 1856(%rdi)
	jne	.L495
	call	cr_full_band
	cmpl	$1, %eax
	sbbl	%esi, %esi
	andl	$-60, %esi
	addl	$182, %esi
	movl	$20, %edi
	call	cr_strips_of
	movl	%eax, 8(%rsp)
	jmp	.L495
.L490:
	addq	$1, %rbx
	cmpq	$8, %rbx
	je	.L503
.L491:
	movl	(%r14,%rbx,4), %eax
	cmpl	%eax, 0(%r13,%rbx,4)
	je	.L490
	movl	%ebx, %esi
	movq	%r12, %rdi
	call	cr_ed_row_strips
	orl	%eax, %ebp
	jmp	.L490
.L503:
	movl	12(%rsp), %eax
	cmpl	%eax, 520+cr_dc(%rip)
	je	.L492
	movl	8(%rsp), %eax
	orl	%eax, %ebp
.L492:
	movl	524+cr_dc(%rip), %esi
	movl	4(%rsp), %eax
	cmpl	%eax, %esi
	je	.L485
	andl	$255, %esi
	je	.L493
	subl	$1, %esi
	movq	%r12, %rdi
	call	cr_ed_row_strips
	orl	%eax, %ebp
.L493:
	movl	4(%rsp), %esi
	andl	$255, %esi
	je	.L494
	subl	$1, %esi
	movq	%r12, %rdi
	call	cr_ed_row_strips
	orl	%eax, %ebp
.L494:
	cmpb	$0, 1855(%r12)
	setne	%dl
	cmpb	$12, %r15b
	sete	%al
	movzbl	%al, %eax
	andl	%edx, %eax
	negl	%eax
	movl	8(%rsp), %ecx
	andl	%ecx, %eax
	orl	%eax, %ebp
.L485:
	movl	%ebp, %eax
	addq	$16, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE205:
	.size	cr_ed_strips, .-cr_ed_strips
	.section	.rodata.str1.1
.LC1:
	.string	"MOD"
	.text
	.type	mod_index, @function
mod_index:
.LFB214:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	leaq	UI_PALETTES(%rip), %rbp
	movl	$0, %ebx
	leaq	.LC1(%rip), %r12
.L506:
	movq	0(%rbp), %rdi
	movq	%r12, %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L504
	addl	$1, %ebx
	addq	$24, %rbp
	cmpl	$9, %ebx
	jne	.L506
.L504:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE214:
	.size	mod_index, .-mod_index
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC2:
	.string	"LINT %-34s %-22s '%s' (%d,%d)-(%d,%d)"
	.section	.rodata.str1.1
.LC3:
	.string	" / '%s' (%d,%d)-(%d,%d)"
	.text
	.type	finding, @function
finding:
.LFB208:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %r8
	movq	%rcx, %rbx
	addl	$1, nfind(%rip)
	movswl	6(%rdx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 24
	movswl	4(%rdx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 32
	movswl	2(%rdx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 40
	movswl	(%rdx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 48
	leaq	9(%rdx), %r9
	movq	%rdi, %rcx
	leaq	.LC2(%rip), %rdx
	movl	$2, %esi
	movq	rep(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	testq	%rbx, %rbx
	je	.L510
	leaq	9(%rbx), %rcx
	movswl	6(%rbx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 24
	movswl	4(%rbx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 32
	movswl	2(%rbx), %r9d
	movswl	(%rbx), %r8d
	leaq	.LC3(%rip), %rdx
	movl	$2, %esi
	movq	rep(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
.L510:
	movq	rep(%rip), %rsi
	movl	$10, %edi
	call	fputc@PLT
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE208:
	.size	finding, .-finding
	.section	.rodata.str1.1
.LC4:
	.string	"off the screen"
.LC5:
	.string	"note %-34s ellipsised '%s'\n"
.LC6:
	.string	"overlaps"
.LC7:
	.string	"on the ring"
	.text
	.type	lint, @function
lint:
.LFB210:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, 8(%rsp)
	movq	%rsi, (%rsp)
	cmpl	$0, nbox(%rip)
	je	.L512
	leaq	boxes(%rip), %r14
	movl	$1, %r15d
	movq	%r14, %r12
	jmp	.L527
.L534:
	movl	$0, %ecx
	movq	%rbp, %rdx
	leaq	.LC4(%rip), %rsi
	movq	8(%rsp), %rdi
	call	finding
	jmp	.L515
.L535:
	addl	$1, nell(%rip)
	leaq	9(%r14), %r8
	movq	8(%rsp), %rcx
	leaq	.LC5(%rip), %rdx
	movl	$2, %esi
	movq	rep(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	jmp	.L516
.L518:
	addl	$1, %r10d
	addl	$2, %edi
	cmpl	%r11d, %r10d
	jne	.L522
.L517:
	movq	(%rsp), %rax
	cmpb	$0, 122(%rax)
	je	.L523
	cmpw	$233, 0(%rbp)
	jg	.L523
	cmpw	$6, 4(%rbp)
	jle	.L523
	cmpw	$139, 2(%rbp)
	jg	.L523
	cmpw	$100, 6(%rbp)
	jle	.L523
.L524:
	addq	$1, %r15
	addq	$50, %r14
	leal	-1(%r15), %eax
	cmpl	nbox(%rip), %eax
	jnb	.L512
.L527:
	movq	%r14, %rbp
	cmpw	$0, (%r14)
	js	.L514
	cmpw	$0, 2(%r14)
	js	.L514
	cmpw	$240, 4(%r14)
	jg	.L514
	cmpw	$240, 6(%r14)
	jle	.L515
.L514:
	testb	$32, 8(%rbp)
	je	.L534
.L515:
	testb	$1, 8(%rbp)
	jne	.L535
.L516:
	movq	(%rsp), %rax
	cmpb	$0, 111(%rax)
	je	.L517
	testb	$32, 8(%rbp)
	jne	.L517
	movzwl	2(%rbp), %eax
	movswl	%ax, %r10d
	movswl	6(%rbp), %r11d
	cmpl	%r11d, %r10d
	jge	.L517
	movswl	0(%rbp), %r9d
	movswl	4(%rbp), %ecx
	leal	-239(%r9,%r9), %r8d
	imull	%r8d, %r8d
	leal	-239(%r10,%r10), %edi
.L522:
	cmpl	%ecx, %r9d
	jge	.L518
	movl	%edi, %esi
	imull	%edi, %esi
	leal	-48400(%r8,%rsi), %eax
	cmpl	$5424, %eax
	jbe	.L519
	movl	%r9d, %edx
.L520:
	addl	$1, %edx
	cmpl	%ecx, %edx
	je	.L518
	leal	-239(%rdx,%rdx), %eax
	imull	%eax, %eax
	leal	-48400(%rsi,%rax), %eax
	cmpl	$5424, %eax
	ja	.L520
.L519:
	movl	$0, %ecx
	movq	%rbp, %rdx
	leaq	.LC7(%rip), %rsi
	movq	8(%rsp), %rdi
	call	finding
	jmp	.L517
.L523:
	movl	%r15d, %ebx
	cmpl	nbox(%rip), %r15d
	jnb	.L512
	leaq	50(%r14), %r13
	jmp	.L526
.L525:
	addl	$1, %ebx
	addq	$50, %r13
	cmpl	nbox(%rip), %ebx
	jnb	.L524
.L526:
	movl	%ebx, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rdx
	movzbl	8(%rbp), %eax
	orb	8(%r12,%rdx,2), %al
	testb	$32, %al
	jne	.L525
	movzwl	4(%r12,%rdx,2), %eax
	cmpw	%ax, 0(%rbp)
	jge	.L525
	movzwl	4(%rbp), %edi
	cmpw	%di, (%r12,%rdx,2)
	jge	.L525
	movzwl	6(%r12,%rdx,2), %eax
	cmpw	%ax, 2(%rbp)
	jge	.L525
	movzwl	6(%rbp), %ecx
	cmpw	%cx, 2(%r12,%rdx,2)
	jge	.L525
	movq	%r13, %rcx
	movq	%rbp, %rdx
	leaq	.LC6(%rip), %rsi
	movq	8(%rsp), %rdi
	call	finding
	jmp	.L525
.L512:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE210:
	.size	lint, .-lint
	.section	.rodata.str1.1
.LC8:
	.string	"%s/ppm/%s.ppm"
.LC9:
	.string	"wb"
	.section	.rodata.str1.8
	.align 8
.LC10:
	.string	"cr_draw_test: cannot write %s\n"
	.section	.rodata.str1.1
.LC11:
	.string	"P6\n240 240\n255\n"
	.text
	.type	write_ppm, @function
write_ppm:
.LFB211:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$552, %rsp
	.cfi_def_cfa_offset 592
	movq	%rdi, %r9
	movq	%fs:40, %rax
	movq	%rax, 536(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 600
	pushq	%rsi
	.cfi_def_cfa_offset 608
	leaq	.LC8(%rip), %r8
	movl	$512, %ecx
	movl	$2, %edx
	movl	$512, %esi
	movq	%rbx, %rdi
	call	__snprintf_chk@PLT
	leaq	.LC9(%rip), %rsi
	movq	%rbx, %rdi
	call	fopen@PLT
	addq	$16, %rsp
	.cfi_def_cfa_offset 592
	testq	%rax, %rax
	je	.L543
	movq	%rax, %rbp
	movq	%rax, %rcx
	movl	$15, %edx
	movl	$1, %esi
	leaq	.LC11(%rip), %rdi
	call	fwrite@PLT
	leaq	host_screen(%rip), %rbx
	leaq	115200(%rbx), %r13
	leaq	13(%rsp), %r12
.L539:
	movzwl	(%rbx), %edx
	movzbl	%dh, %eax
	sall	$8, %edx
	orl	%eax, %edx
	movzwl	%dx, %ecx
	movl	%ecx, %esi
	shrl	$11, %esi
	movl	%esi, %eax
	sall	$8, %eax
	subl	%esi, %eax
	movl	%eax, %esi
	imulq	$138547333, %rsi, %rsi
	shrq	$32, %rsi
	subl	%esi, %eax
	shrl	%eax
	addl	%esi, %eax
	shrl	$4, %eax
	movb	%al, 13(%rsp)
	shrl	$5, %ecx
	andl	$63, %ecx
	movl	%ecx, %eax
	sall	$8, %eax
	subl	%ecx, %eax
	movl	%eax, %ecx
	imulq	$68174085, %rcx, %rcx
	shrq	$32, %rcx
	subl	%ecx, %eax
	shrl	%eax
	addl	%ecx, %eax
	shrl	$5, %eax
	movb	%al, 14(%rsp)
	andl	$31, %edx
	movl	%edx, %eax
	sall	$8, %eax
	subl	%edx, %eax
	movl	%eax, %edx
	imulq	$138547333, %rdx, %rdx
	shrq	$32, %rdx
	subl	%edx, %eax
	shrl	%eax
	addl	%edx, %eax
	shrl	$4, %eax
	movb	%al, 15(%rsp)
	movq	%rbp, %rcx
	movl	$3, %edx
	movl	$1, %esi
	movq	%r12, %rdi
	call	fwrite@PLT
	addq	$2, %rbx
	cmpq	%r13, %rbx
	jne	.L539
	movq	%rbp, %rdi
	call	fclose@PLT
.L536:
	movq	536(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L544
	addq	$552, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L543:
	.cfi_restore_state
	movq	%rbx, %rcx
	leaq	.LC10(%rip), %rdx
	movl	$2, %esi
	movq	stderr(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	addl	$1, nfail(%rip)
	jmp	.L536
.L544:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE211:
	.size	write_ppm, .-write_ppm
	.section	.rodata.str1.1
.LC12:
	.string	"FAIL"
.LC13:
	.string	"cr_draw: %-78s %s\n"
.LC14:
	.string	"check %-78s %s\n"
.LC15:
	.string	"ok"
	.text
	.type	check, @function
check:
.LFB212:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	testl	%esi, %esi
	jne	.L546
	leaq	.LC12(%rip), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	leaq	.LC13(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movq	%rbp, %r8
	movq	%rbx, %rcx
	leaq	.LC14(%rip), %rdx
	movl	$2, %esi
	movq	rep(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	addl	$1, nfail(%rip)
.L545:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L546:
	.cfi_restore_state
	leaq	.LC15(%rip), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	leaq	.LC13(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movq	%rbp, %r8
	movq	%rbx, %rcx
	leaq	.LC14(%rip), %rdx
	movl	$2, %esi
	movq	rep(%rip), %rdi
	movl	$0, %eax
	call	__fprintf_chk@PLT
	jmp	.L545
	.cfi_endproc
.LFE212:
	.size	check, .-check
	.section	.rodata.str1.1
.LC16:
	.string	"%s"
	.text
	.type	hk_text, @function
hk_text:
.LFB207:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$64, %rsp
	.cfi_def_cfa_offset 112
	movl	%ecx, %eax
	movq	%r8, %rcx
	movq	%fs:40, %r8
	movq	%r8, 56(%rsp)
	xorl	%r8d, %r8d
	movw	%di, (%rsp)
	movw	%dx, 4(%rsp)
	subw	cv_oy(%rip), %si
	movw	%si, 2(%rsp)
	subw	cv_oy(%rip), %ax
	movw	%ax, 6(%rsp)
	andl	$-3, %r9d
	movb	%r9b, 8(%rsp)
	leaq	9(%rsp), %rdi
	leaq	.LC16(%rip), %rdx
	movl	$40, %esi
	movl	$0, %eax
	call	snprintf@PLT
	movl	nbox(%rip), %r14d
	testl	%r14d, %r14d
	je	.L551
	leaq	boxes(%rip), %rbx
	movl	%r14d, %eax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rax,%rax,4), %rax
	leaq	(%rbx,%rax,2), %r12
	movq	%rsp, %rbp
	leaq	9(%rsp), %r13
	jmp	.L554
.L552:
	addq	$50, %rbx
	cmpq	%r12, %rbx
	je	.L559
.L554:
	movl	$8, %edx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L552
	leaq	9(%rbx), %rdi
	movq	%r13, %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L552
	jmp	.L550
.L559:
	cmpl	$255, %r14d
	jbe	.L551
.L550:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L560
	addq	$64, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L551:
	.cfi_restore_state
	leal	1(%r14), %eax
	movl	%eax, nbox(%rip)
	movl	%r14d, %r14d
	leaq	(%r14,%r14,4), %rax
	leaq	(%rax,%rax,4), %rdx
	leaq	boxes(%rip), %rax
	leaq	(%rax,%rdx,2), %rax
	movdqa	(%rsp), %xmm0
	movups	%xmm0, (%rax)
	movdqa	16(%rsp), %xmm1
	movups	%xmm1, 16(%rax)
	movdqa	32(%rsp), %xmm2
	movups	%xmm2, 32(%rax)
	movzwl	48(%rsp), %edx
	movw	%dx, 48(%rax)
	jmp	.L550
.L560:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE207:
	.size	hk_text, .-hk_text
	.type	cv_rrect, @function
cv_rrect:
.LFB72:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$64, %rsp
	.cfi_def_cfa_offset 120
	movl	%edi, 44(%rsp)
	movl	%esi, %ebx
	movl	%edx, %r12d
	movl	%ecx, %ebp
	movw	%r9w, 24(%rsp)
	movzwl	120(%rsp), %eax
	movw	%ax, 26(%rsp)
	movl	%ecx, %eax
	shrl	$31, %eax
	addl	%ecx, %eax
	sarl	%eax
	cmpl	%r8d, %eax
	cmovg	%r8d, %eax
	shrl	$31, %edx
	addl	%r12d, %edx
	sarl	%edx
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	movl	%edx, 48(%rsp)
	testl	%edx, %edx
	jle	.L587
	movzwl	%r9w, %eax
	movl	48(%rsp), %r15d
	leal	(%r15,%r15), %r13d
	movl	%r12d, %edx
	subl	%r13d, %edx
	movl	44(%rsp), %esi
	leal	(%r15,%rsi), %edi
	movl	%eax, 36(%rsp)
	movl	%eax, %r8d
	movl	%ebx, %esi
	call	cv_rect
	movl	%ebp, %r14d
	subl	%r13d, %r14d
	leal	(%r15,%rbx), %r13d
	movl	36(%rsp), %r8d
	movl	%r14d, %ecx
	movl	%r15d, %edx
	movl	%r13d, %esi
	movl	44(%rsp), %edi
	call	cv_rect
	movl	44(%rsp), %esi
	leal	(%r12,%rsi), %edi
	movl	%edi, 52(%rsp)
	subl	%r15d, %edi
	movl	36(%rsp), %r8d
	movl	%r14d, %ecx
	movl	%r15d, %edx
	movl	%r13d, %esi
	call	cv_rect
	movl	%r15d, %eax
	movl	%r15d, %esi
	imull	%r15d, %eax
	sall	$6, %eax
	movl	%eax, %r13d
	movl	cv_oy(%rip), %eax
	movl	cv_w(%rip), %r15d
	movl	cv_h(%rip), %ecx
	movl	%ecx, 4(%rsp)
	leal	-1(%rax,%rbx), %edx
	leal	(%rdx,%rbp), %ecx
	movl	%ecx, 16(%rsp)
	addl	%ebx, %eax
	movl	%eax, 8(%rsp)
	leal	-9(,%rsi,8), %r14d
	movl	%r14d, 56(%rsp)
	movl	%eax, %r8d
	imull	%r15d, %r8d
	addl	%esi, %eax
	movl	%eax, 60(%rsp)
	movzwl	26(%rsp), %eax
	movl	%eax, 40(%rsp)
	jmp	.L564
.L587:
	movzwl	%r9w, %r8d
	movl	%r12d, %edx
	call	cv_rect
.L561:
	addq	$64, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L588:
	.cfi_restore_state
	subl	$2, %esi
	cmpl	%r14d, %esi
	je	.L566
.L575:
	movl	%esi, %edi
	imull	%esi, %edi
	leal	8(%rbx), %eax
.L565:
	movl	%eax, %edx
	imull	%eax, %edx
	addl	%edi, %edx
	cmpl	%r13d, %edx
	setle	%dl
	movzbl	%dl, %edx
	addl	%edx, %ecx
	subl	$2, %eax
	cmpl	%ebx, %eax
	jne	.L565
	jmp	.L588
.L566:
	movzwl	24(%rsp), %eax
	cmpl	$15, %ecx
	ja	.L567
	movzwl	26(%rsp), %eax
	testl	%ecx, %ecx
	je	.L567
	imull	$100, %ecx, %edx
	shrl	$4, %edx
	movl	36(%rsp), %esi
	movl	40(%rsp), %edi
	call	ux_mix
.L567:
	cmpl	%r15d, %r12d
	jnb	.L568
	movl	4(%rsp), %edi
	cmpl	%edi, 8(%rsp)
	jnb	.L569
	movl	28(%rsp), %esi
	leal	(%r12,%rsi), %esi
	movzbl	%ah, %ecx
	movl	%eax, %edx
	sall	$8, %edx
	orl	%ecx, %edx
	leaq	cv_px(%rip), %rdi
	movw	%dx, (%rdi,%rsi,2)
	cmpl	%r15d, %ebp
	jnb	.L571
	jmp	.L570
.L580:
	movl	4(%rsp), %edi
	cmpl	%edi, 8(%rsp)
	jnb	.L572
.L570:
	movl	32(%rsp), %esi
	leal	(%rsi,%rbp), %esi
	movzbl	%ah, %ecx
	movl	%eax, %edx
	sall	$8, %edx
	orl	%ecx, %edx
	leaq	cv_px(%rip), %rcx
	movw	%dx, (%rcx,%rsi,2)
.L572:
	cmpl	%r15d, %r12d
	jb	.L571
	movl	4(%rsp), %ecx
	cmpl	%ecx, 16(%rsp)
	jnb	.L573
.L577:
	movl	20(%rsp), %esi
	leal	(%rsi,%rbp), %edx
	movzbl	%ah, %ecx
	sall	$8, %eax
	orl	%ecx, %eax
	leaq	cv_px(%rip), %rsi
	movw	%ax, (%rsi,%rdx,2)
	jmp	.L573
.L574:
	movl	28(%rsp), %r8d
	subl	$1, 16(%rsp)
	addl	$1, 8(%rsp)
	movl	8(%rsp), %eax
	subl	$8, %r14d
	addl	%r15d, %r8d
	movl	60(%rsp), %ebx
	cmpl	%ebx, %eax
	je	.L561
.L564:
	movl	44(%rsp), %r12d
	movl	52(%rsp), %eax
	leal	-1(%rax), %ebp
	movl	%ebp, %eax
	movl	48(%rsp), %ebx
	subl	%ebx, %eax
	movl	%eax, 12(%rsp)
	movl	56(%rsp), %ebx
	movl	16(%rsp), %eax
	imull	%r15d, %eax
	movl	%eax, 20(%rsp)
	movl	8(%rsp), %eax
	imull	%r15d, %eax
	movl	%eax, 32(%rsp)
	movl	%r8d, 28(%rsp)
	jmp	.L576
.L569:
	cmpl	%r15d, %ebp
	jb	.L572
	cmpl	%r15d, %r12d
	jnb	.L573
.L571:
	movl	4(%rsp), %edi
	cmpl	%edi, 16(%rsp)
	jnb	.L573
	movl	20(%rsp), %esi
	leal	(%rsi,%r12), %esi
	movzbl	%ah, %ecx
	movl	%eax, %edx
	sall	$8, %edx
	orl	%ecx, %edx
	leaq	cv_px(%rip), %rdi
	movw	%dx, (%rdi,%rsi,2)
	cmpl	%r15d, %ebp
	jnb	.L573
	jmp	.L577
.L568:
	cmpl	%r15d, %ebp
	jb	.L580
.L573:
	addl	$1, %r12d
	subl	$1, %ebp
	subl	$8, %ebx
	movl	12(%rsp), %eax
	cmpl	%eax, %ebp
	je	.L574
.L576:
	leal	8(%r14), %esi
	movl	$0, %ecx
	jmp	.L575
	.cfi_endproc
.LFE72:
	.size	cv_rrect, .-cv_rrect
	.type	cr_frame, @function
cr_frame:
.LFB130:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	movl	%esi, %r12d
	movq	%rdx, %rbp
	leaq	36(%rdx), %rcx
.L590:
	movb	$0, (%rdx)
	addq	$1, %rdx
	cmpq	%rcx, %rdx
	jne	.L590
	movl	$4096, 0(%rbp)
	movzwl	672(%rbx), %eax
	movzbl	676(%rbx), %edx
	testb	%dl, %dl
	movl	$12, %ecx
	cmove	%ecx, %edx
	movzbl	%dl, %r13d
	imull	%eax, %r13d
	subl	$-128, %r13d
	shrl	$8, %r13d
	movb	%r13b, 34(%rbp)
	movzbl	692(%rbx), %eax
	leal	(%rax,%rax,4), %eax
	sall	$3, %eax
	movl	%eax, 8(%rbp)
	cmpb	$2, (%rbx)
	je	.L619
.L592:
	movzbl	(%rbx), %eax
	cmpb	$3, %al
	je	.L614
	cmpb	$14, %al
	jne	.L596
.L614:
	testb	$2, 1(%rbx)
	je	.L589
	cmpb	$0, 319(%rbx)
	je	.L589
	cmpl	$159, %r12d
	jbe	.L620
.L589:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L619:
	.cfi_restore_state
	testb	$1, 1(%rbx)
	je	.L593
	cmpl	$119, %r12d
	jbe	.L621
.L593:
	cmpb	$1, (%rbx)
	jne	.L589
	testb	$8, 1(%rbx)
	je	.L603
	cmpw	$0, 694(%rbx)
	je	.L603
	movb	$1, 35(%rbp)
	movzwl	694(%rbx), %ecx
	movl	%r12d, %eax
	movl	$0, %edx
	divl	%ecx
	movl	%edx, %eax
	sall	$8, %eax
	movl	$0, %edx
	divl	%ecx
	addb	692(%rbx), %al
	movzbl	%al, %eax
	leal	(%rax,%rax,4), %eax
	sall	$3, %eax
	movl	%eax, 8(%rbp)
.L603:
	testb	$16, 1(%rbx)
	je	.L604
	leaq	12(%rbp), %r14
	movl	$0, %r13d
	jmp	.L607
.L621:
	movb	$1, 35(%rbp)
	movzbl	191(%rbx), %eax
	cmpl	$59, %r12d
	ja	.L594
	testb	%al, %al
	jne	.L622
.L594:
	testb	%al, %al
	je	.L595
	leal	-60(%r12), %edi
	movl	$60, %esi
	call	cr_ease_out
	imull	$3766, %eax, %eax
	sarl	$12, %eax
	addl	$330, %eax
	movl	%eax, 0(%rbp)
	jmp	.L592
.L622:
	movl	%r12d, %eax
	sall	$12, %eax
	movl	%eax, %eax
	movl	$2290649225, %edx
	imulq	%rdx, %rax
	shrq	$37, %rax
	movb	$1, 33(%rbp)
	imull	%eax, %eax
	sarl	$12, %eax
	imull	$3766, %eax, %eax
	sarl	$12, %eax
	movl	$4096, %edx
	subl	%eax, %edx
	movl	%edx, 0(%rbp)
	jmp	.L592
.L595:
	movl	$120, %esi
	movl	%r12d, %edi
	call	cr_ease_out
	imull	$3766, %eax, %eax
	sarl	$12, %eax
	addl	$330, %eax
	movl	%eax, 0(%rbp)
	jmp	.L592
.L620:
	movb	$1, 35(%rbp)
	movl	$160, %esi
	movl	%r12d, %edi
	call	cr_ease_out
	movl	%eax, %edx
	movl	$4096, %eax
	subl	%edx, %eax
	movl	%eax, 4(%rbp)
.L596:
	cmpb	$4, (%rbx)
	jne	.L593
	testb	$4, 1(%rbx)
	je	.L589
	movzwl	674(%rbx), %edx
	movzbl	676(%rbx), %eax
	testb	%al, %al
	movl	$12, %ecx
	cmove	%ecx, %eax
	movzbl	%al, %eax
	imull	%edx, %eax
	subl	$-128, %eax
	shrl	$8, %eax
	movzbl	%r13b, %r13d
	cmpl	%r13d, %eax
	jnb	.L600
	movl	%r12d, %edx
	movl	$2290649225, %ecx
	imulq	%rcx, %rdx
	shrq	$36, %rdx
	subl	%eax, %r13d
	cmpl	%r13d, %edx
	jnb	.L589
	addl	%edx, %eax
.L612:
	movb	$1, 35(%rbp)
	movb	%al, 34(%rbp)
	jmp	.L593
.L600:
	movl	%r12d, %edx
	movl	$2290649225, %ecx
	imulq	%rcx, %rdx
	shrq	$36, %rdx
	movl	%eax, %ecx
	subl	%r13d, %ecx
	cmpl	%ecx, %edx
	jnb	.L589
	subl	%edx, %eax
	jmp	.L612
.L604:
	testb	$32, 1(%rbx)
	je	.L589
	leaq	12(%rbp), %r13
	movl	$0, %ebx
	movl	$76800, %r14d
	movl	$4096, %r15d
	jmp	.L610
.L609:
	addl	$90, %ebx
	addq	$4, %r13
	cmpl	$360, %ebx
	je	.L623
.L610:
	movl	%r14d, %eax
	cmpl	%r12d, %ebx
	jnb	.L608
	movl	%r12d, %edi
	subl	%ebx, %edi
	movl	$220, %esi
	call	cr_ease_out
	movl	%eax, %edx
	movl	%r15d, %eax
	subl	%edx, %eax
	imull	$300, %eax, %eax
	sarl	$4, %eax
.L608:
	subl	%eax, 0(%r13)
	leal	220(%rbx), %eax
	cmpl	%eax, %r12d
	jnb	.L609
	movb	$1, 35(%rbp)
	jmp	.L609
.L623:
	cmpl	$299, %r12d
	setbe	32(%rbp)
	cmpl	$449, %r12d
	ja	.L589
	movb	$1, 35(%rbp)
	cmpl	$299, %r12d
	jbe	.L589
	leal	-300(%r12), %edi
	movl	$150, %esi
	call	cr_ease_out
	movl	%eax, %edx
	movl	$4096, %eax
	subl	%edx, %eax
	leal	(%rax,%rax,2), %eax
	sall	$3, %eax
	sarl	$4, %eax
	movl	%eax, 28(%rbp)
	jmp	.L589
.L605:
	movl	$0, (%r14)
.L611:
	movb	$1, 35(%rbp)
.L606:
	addl	$40, %r13d
	addq	$4, %r14
	cmpl	$160, %r13d
	je	.L604
.L607:
	cmpl	%r12d, %r13d
	jnb	.L605
	movl	%r12d, %edi
	subl	%r13d, %edi
	movl	$240, %esi
	call	cr_ease_out
	imull	$300, %eax, %eax
	sarl	$4, %eax
	movl	%eax, (%r14)
	leal	240(%r13), %eax
	cmpl	%eax, %r12d
	jnb	.L606
	jmp	.L611
	.cfi_endproc
.LFE130:
	.size	cr_frame, .-cr_frame
	.type	cr_arc_geom, @function
cr_arc_geom:
.LFB106:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	movl	%esi, %r14d
	movl	%edx, %r13d
	movl	%ecx, %ebp
	movl	%r9d, %r12d
	movl	%esi, (%rdi)
	movl	%edx, 4(%rdi)
	movl	%ecx, 8(%rdi)
	movl	%r8d, %eax
	shrl	$31, %eax
	leal	(%rax,%r8), %eax
	sarl	%eax
	leal	(%rax,%rcx), %ecx
	movl	%ecx, 12(%rdi)
	movl	%ebp, %edx
	subl	%eax, %edx
	movl	%edx, 16(%rdi)
	imull	%ecx, %ecx
	movl	%ecx, 20(%rdi)
	imull	%edx, %edx
	movl	%edx, 24(%rdi)
	imull	%eax, %eax
	movl	%eax, 28(%rdi)
	leal	16384(%r9), %edi
	call	cr_sin
	imull	%ebp, %eax
	sarl	$14, %eax
	addl	%r14d, %eax
	movl	%eax, 32(%rbx)
	movl	%r12d, %edi
	call	cr_sin
	imull	%ebp, %eax
	sarl	$14, %eax
	addl	%r13d, %eax
	movl	%eax, 36(%rbx)
	movl	%r12d, %r15d
	addl	56(%rsp), %r15d
	leal	16384(%r15), %edi
	call	cr_sin
	imull	%ebp, %eax
	sarl	$14, %eax
	addl	%r14d, %eax
	movl	%eax, 40(%rbx)
	movl	%r15d, %edi
	call	cr_sin
	imull	%ebp, %eax
	sarl	$14, %eax
	addl	%r13d, %eax
	movl	%eax, 44(%rbx)
	imull	$6434, %ebp, %ebp
	sarl	$10, %ebp
	movl	%ebp, 48(%rbx)
	movl	%r12d, 60(%rbx)
	movl	56(%rsp), %eax
	movl	%eax, 64(%rbx)
	movl	64(%rsp), %eax
	movl	%eax, 68(%rbx)
	cmpl	$65535, 56(%rsp)
	seta	%al
	movzbl	%al, %eax
	movl	%eax, 72(%rbx)
	movl	72(%rsp), %eax
	movl	%eax, 52(%rbx)
	movl	80(%rsp), %eax
	movl	%eax, 56(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE106:
	.size	cr_arc_geom, .-cr_arc_geom
	.type	cr_arc, @function
cr_arc:
.LFB108:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$120, %rsp
	.cfi_def_cfa_offset 176
	movl	%edi, %ebx
	movl	%esi, %r13d
	movzwl	200(%rsp), %r14d
	movq	%fs:40, %rax
	movq	%rax, 104(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rdi
	movl	192(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 184
	movl	192(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 192
	movl	192(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 200
	pushq	%r9
	.cfi_def_cfa_offset 208
	movl	%r8d, %r9d
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movl	%esi, %edx
	movl	%ebx, %esi
	call	cr_arc_geom
	movl	60(%rsp), %r12d
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	call	cr_row0
	movl	%r13d, %ebp
	subl	%r12d, %ebp
	sarl	$4, %ebp
	cmpl	%eax, %ebp
	cmovl	%eax, %ebp
	call	cr_row1
	movl	%eax, %edx
	leal	15(%r12,%r13), %eax
	sarl	$4, %eax
	cmpl	%edx, %eax
	movl	%edx, %esi
	cmovle	%eax, %esi
	movl	%esi, 12(%rsp)
	movl	%ebx, %r15d
	subl	%r12d, %r15d
	sarl	$4, %r15d
	movswl	cr_clip(%rip), %eax
	cmpl	%eax, %r15d
	cmovl	%eax, %r15d
	leal	15(%r12,%rbx), %r12d
	sarl	$4, %r12d
	movswl	4+cr_clip(%rip), %eax
	cmpl	%eax, %r12d
	cmovg	%eax, %r12d
	leaq	16(%rsp), %r13
	cmpl	%ebp, %esi
	jg	.L627
.L626:
	movq	104(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L637
	addq	$120, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L629:
	.cfi_restore_state
	movl	%ebp, %edx
	movl	%ebx, %esi
	movq	%r13, %rdi
	call	cr_arc_px
	sall	$4, %eax
	movl	%eax, %ecx
	movzwl	%r14w, %edx
	movl	%ebp, %esi
	movl	%ebx, %edi
	call	cr_blend
	addl	$1, %ebx
	cmpl	%ebx, %r12d
	jne	.L629
.L630:
	addl	$1, %ebp
	cmpl	%ebp, 12(%rsp)
	je	.L626
.L627:
	movl	%r15d, %ebx
	cmpl	%r15d, %r12d
	jg	.L629
	jmp	.L630
.L637:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE108:
	.size	cr_arc, .-cr_arc
	.type	cr_cglyph, @function
cr_cglyph:
.LFB157:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$584, %rsp
	.cfi_def_cfa_offset 640
	movq	%rdi, %r12
	movl	%esi, %ebp
	movl	%edx, 24(%rsp)
	movl	%ecx, %edx
	movl	%r8d, %ebx
	movl	%r9d, 36(%rsp)
	movw	%r9w, 16(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 568(%rsp)
	xorl	%eax, %eax
	movzbl	27(%rdi), %esi
	shrl	$31, %ecx
	addl	%edx, %ecx
	sarl	%ecx
	leal	(%rcx,%rbp), %eax
	movl	%eax, 8(%rsp)
	cmpl	$254, %esi
	movl	$256, %ecx
	cmovle	%esi, %ecx
	movl	%ecx, %r15d
	movzbl	26(%rdi), %edi
	cmpb	$24, %dil
	ja	.L640
	leal	0(,%r8,4), %r14d
	movzbl	%dil, %ecx
	leaq	.L642(%rip), %r8
	movslq	(%r8,%rcx,4), %rcx
	addq	%r8, %rcx
	notrack jmp	*%rcx
	.section	.rodata
	.align 4
	.align 4
.L642:
	.long	.L640-.L642
	.long	.L651-.L642
	.long	.L650-.L642
	.long	.L649-.L642
	.long	.L648-.L642
	.long	.L648-.L642
	.long	.L647-.L642
	.long	.L646-.L642
	.long	.L645-.L642
	.long	.L644-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L640-.L642
	.long	.L643-.L642
	.long	.L638-.L642
	.text
.L650:
	testb	$4, 24(%r12)
	je	.L652
	sall	$2, %edx
	movl	$224, %ebp
	cmpl	$2239, %edx
	jg	.L653
	movslq	%edx, %rbp
	imulq	$1717986919, %rbp, %rbp
	sarq	$34, %rbp
	sarl	$31, %edx
	subl	%edx, %ebp
.L653:
	movl	%ebp, %eax
	shrl	$31, %eax
	addl	%ebp, %eax
	sarl	%eax
	movl	8(%rsp), %r14d
	subl	%eax, %r14d
	movl	%ebx, %r12d
	shrl	$31, %r12d
	addl	%ebx, %r12d
	sarl	%r12d
	movl	24(%rsp), %esi
	addl	%esi, %r12d
	leal	-128(%r15), %r13d
	imull	%ebx, %r13d
	leal	255(%r13), %r15d
	testl	%r13d, %r13d
	cmovns	%r13d, %r15d
	sarl	$8, %r15d
	movzwl	14+ux(%rip), %r8d
	movl	%ebx, %ecx
	movl	%ebp, %edx
	movl	%r14d, %edi
	call	cr_frect
	cmpl	$255, %r13d
	jg	.L860
	cmpl	$-255, %r13d
	jl	.L861
.L655:
	leal	96(%rbp), %edx
	leal	-8(%r12), %esi
	leal	-48(%r14), %edi
	movzwl	36(%rsp), %r8d
	movl	$16, %ecx
	call	cr_frect
	jmp	.L638
.L860:
	movl	%r12d, %esi
	subl	%r15d, %esi
	movzwl	36(%rsp), %r8d
	movl	%r15d, %ecx
	movl	%ebp, %edx
	movl	%r14d, %edi
	call	cr_frect
	jmp	.L655
.L861:
	movl	%r15d, %ecx
	negl	%ecx
	movzwl	36(%rsp), %r8d
	movl	%ebp, %edx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	cr_frect
	jmp	.L655
.L652:
	leal	0(,%rbx,4), %edx
	leal	(%rdx,%rbx), %r12d
	sall	$8, %r12d
	sarl	$12, %r12d
	addl	%ebx, %edx
	sall	$7, %edx
	sarl	$12, %edx
	movl	8(%rsp), %eax
	subl	%edx, %eax
	movl	$0, %ebp
	leaq	ux(%rip), %r13
	movl	%r15d, 16(%rsp)
	movl	24(%rsp), %r15d
	movl	%ebx, 40(%rsp)
	movl	%eax, %ebx
.L656:
	movslq	%ebp, %rsi
	imulq	$715827883, %rsi, %rsi
	shrq	$32, %rsi
	movl	%ebp, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	addl	$64, %esi
	imull	%r14d, %esi
	sarl	$12, %esi
	addl	%r15d, %esi
	movzwl	14(%r13), %r8d
	movl	$13, %ecx
	movl	%r12d, %edx
	movl	%ebx, %edi
	call	cr_frect
	addl	$896, %ebp
	cmpl	$6272, %ebp
	jne	.L656
	movl	16(%rsp), %r15d
	movl	40(%rsp), %ebx
	imull	$896, %r15d, %edx
	cmpl	$255, %edx
	jle	.L638
	shrl	$8, %edx
	movl	%r14d, %ecx
	imull	%edx, %ecx
	sarl	$12, %ecx
	leal	0(,%rbx,8), %r8d
	leal	(%r8,%rbx), %edi
	sall	$7, %edi
	sarl	$12, %edi
	movl	$960, %esi
	subl	%edx, %esi
	imull	%r14d, %esi
	sarl	$12, %esi
	movl	24(%rsp), %eax
	addl	%eax, %esi
	leal	(%r8,%rbx), %eax
	sall	$6, %eax
	sarl	$12, %eax
	movl	8(%rsp), %r9d
	subl	%eax, %r9d
	movzwl	36(%rsp), %r8d
	movl	%edi, %edx
	movl	%r9d, %edi
	call	cr_frect
	jmp	.L638
.L646:
	leal	(%r15,%r15,4), %edx
	leal	128(%r15,%rdx,2), %edx
	sarl	$8, %edx
	leal	1(%rdx), %eax
	movl	%eax, 36(%rsp)
	movl	%ebx, %r15d
	shrl	$31, %r15d
	addl	%ebx, %r15d
	sarl	%r15d
	movl	24(%rsp), %eax
	addl	%r15d, %eax
	movl	%eax, 24(%rsp)
	movl	$0, %r13d
	movzwl	16(%rsp), %eax
	movl	%eax, 16(%rsp)
	jmp	.L659
.L862:
	leaq	ux(%rip), %rax
	movzwl	14(%rax), %r15d
	movl	$32, %r12d
.L658:
	call	cr_sin
	leal	(%rax,%rax,4), %ebx
	sall	$6, %ebx
	sarl	$14, %ebx
	imull	%r14d, %ebx
	sarl	$12, %ebx
	movl	24(%rsp), %eax
	addl	%eax, %ebx
	leal	65536(%rbp), %edi
	call	cr_sin
	movl	%r12d, %edx
	imull	%r14d, %edx
	sarl	$12, %edx
	leal	(%rax,%rax,4), %edi
	sall	$6, %edi
	sarl	$14, %edi
	imull	%r14d, %edi
	sarl	$12, %edi
	movl	8(%rsp), %eax
	addl	%eax, %edi
	movl	%r15d, %ecx
	movl	%ebx, %esi
	call	cr_disc
	addl	$1, %r13d
	cmpl	$12, %r13d
	je	.L638
.L659:
	movl	%r13d, %ebp
	sall	$16, %ebp
	movl	%ebp, %ebp
	movl	$2863311531, %eax
	imulq	%rax, %rbp
	shrq	$35, %rbp
	leal	49152(%rbp), %edi
	cmpl	%r13d, 36(%rsp)
	jle	.L862
	movl	16(%rsp), %r15d
	movl	$56, %r12d
	jmp	.L658
.L649:
	imull	$179, %r15d, %eax
	sarl	$8, %eax
	addl	$77, %eax
	imull	$1408, %ebx, %ecx
	sarl	$12, %ecx
	imull	%ecx, %eax
	leal	255(%rax), %r14d
	testl	%eax, %eax
	cmovns	%eax, %r14d
	sarl	$8, %r14d
	leal	(%rbx,%rbx,2), %eax
	sall	$7, %eax
	sarl	$12, %eax
	leal	(%rax,%rbp), %esi
	movl	%esi, 8(%rsp)
	movl	%ebx, %r13d
	shrl	$31, %r13d
	addl	%ebx, %r13d
	sarl	%r13d
	addw	24(%rsp), %r13w
	addl	%eax, %eax
	subl	%eax, %edx
	movl	%edx, %ebp
	movl	$0, %ebx
	movl	$0, %r12d
	leaq	322(%rsp), %r15
.L660:
	movslq	%r12d, %rax
	imulq	$1717986919, %rax, %rax
	sarq	$35, %rax
	movl	%r12d, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	addw	8(%rsp), %ax
	movw	%ax, 320(%rsp,%rbx)
	movl	%ebx, %eax
	sall	$14, %eax
	movslq	%eax, %rdi
	imulq	$1717986919, %rdi, %rdi
	sarq	$34, %rdi
	sarl	$31, %eax
	subl	%eax, %edi
	call	cr_sin
	imull	%r14d, %eax
	sarl	$14, %eax
	movl	%r13d, %edx
	subl	%eax, %edx
	movw	%dx, (%r15,%rbx)
	addl	%ebp, %r12d
	addq	$4, %rbx
	cmpq	$84, %rbx
	jne	.L660
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$21, %esi
	call	cr_poly
.L638:
	movq	568(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L863
	addq	$584, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L648:
	.cfi_restore_state
	leal	(%rbx,%rbx,2), %eax
	sall	$7, %eax
	sarl	$12, %eax
	leal	(%rax,%rbp), %ecx
	addl	%eax, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	shrl	$31, %eax
	addl	%edx, %eax
	sarl	%eax
	leal	(%rbx,%rbx,4), %edx
	sall	$7, %edx
	sarl	$12, %edx
	movl	24(%rsp), %r11d
	leal	(%rdx,%r11), %esi
	addl	%r11d, %ebx
	subl	%edx, %ebx
	cmpb	$4, %dil
	je	.L864
	movl	%r15d, %edi
	imull	%eax, %edi
	leal	255(%rdi), %edx
	testl	%edi, %edi
	cmovns	%edi, %edx
	sarl	$8, %edx
	movw	%cx, 320(%rsp)
	movw	%bx, 322(%rsp)
	movw	%cx, 324(%rsp)
	movw	%si, 326(%rsp)
	leal	(%rcx,%rdx), %edi
	movw	%di, 328(%rsp)
	movw	%si, 330(%rsp)
	movw	%di, 332(%rsp)
	movw	%bx, 334(%rsp)
	leal	(%rax,%rcx), %edi
	movw	%di, 336(%rsp)
	movw	%bx, 338(%rsp)
	addl	%eax, %ecx
	movw	%cx, 340(%rsp)
	movw	%bx, 342(%rsp)
	movw	%cx, 344(%rsp)
	movw	%si, 346(%rsp)
	addl	%ecx, %edx
	movw	%dx, 348(%rsp)
	movw	%si, 350(%rsp)
	movw	%dx, 352(%rsp)
	movw	%bx, 354(%rsp)
	addl	%ecx, %eax
	movw	%ax, 356(%rsp)
	movw	%bx, 358(%rsp)
	movl	$10, %esi
.L662:
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	call	cr_poly
	jmp	.L638
.L864:
	movw	%cx, 320(%rsp)
	movw	%bx, 322(%rsp)
	leal	(%rcx,%rax), %edx
	movw	%dx, 324(%rsp)
	movw	%si, 326(%rsp)
	movw	%dx, 328(%rsp)
	movw	%bx, 330(%rsp)
	leal	(%rcx,%rax,2), %eax
	movw	%ax, 332(%rsp)
	movw	%si, 334(%rsp)
	movw	%ax, 336(%rsp)
	movw	%bx, 338(%rsp)
	movl	$5, %esi
	jmp	.L662
.L645:
	addl	$1, %esi
	movl	%esi, %edi
	sall	$7, %edi
	subl	%esi, %edi
	movslq	%edi, %rsi
	imulq	$-2139062143, %rsi, %rsi
	shrq	$32, %rsi
	addl	%edi, %esi
	sarl	$7, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	leal	(%rbx,%rbx,2), %eax
	sall	$7, %eax
	sarl	$12, %eax
	leal	(%rax,%rbp), %r8d
	addl	%eax, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	shrl	$31, %eax
	addl	%edx, %eax
	sarl	%eax
	movl	%eax, 16(%rsp)
	leal	(%rbx,%rbx,4), %eax
	sall	$7, %eax
	sarl	$12, %eax
	movl	24(%rsp), %r11d
	addl	%r11d, %ebx
	leal	(%rbx,%r11), %ecx
	movl	%ecx, %edx
	shrl	$31, %edx
	addl	%ecx, %edx
	sarl	%edx
	movl	%edx, 40(%rsp)
	subl	%eax, %ebx
	addl	%r11d, %eax
	subl	%eax, %ebx
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%ebx, %eax
	sarl	%eax
	movl	%eax, 44(%rsp)
	movl	$2048, %ecx
	cmpl	$24734, %edi
	jle	.L663
	leal	-96(%rsi), %eax
	imull	$1843, %eax, %eax
	movslq	%eax, %rcx
	imulq	$-2078209981, %rcx, %rcx
	shrq	$32, %rcx
	addl	%eax, %ecx
	sarl	$4, %ecx
	sarl	$31, %eax
	subl	%eax, %ecx
	addl	$2048, %ecx
.L663:
	leaq	KX.13(%rip), %r9
	leaq	KL.12(%rip), %r10
	leaq	20(%r9), %rbx
	movl	$0, %r13d
	jmp	.L666
.L665:
	movslq	%r13d, %rdx
	movw	%cx, 128(%rsp,%rdx,2)
	leal	1(%r13), %eax
	movb	$1, 512(%rsp,%rdx)
	cltq
	movw	%cx, 128(%rsp,%rax,2)
	leal	2(%r13), %r14d
	movb	$0, 512(%rsp,%rax)
.L664:
	movslq	%r14d, %rax
	movzwl	(%r9), %edx
	movw	%dx, 128(%rsp,%rax,2)
	leal	1(%r14), %r13d
	movzbl	(%r10), %edx
	movb	%dl, 512(%rsp,%rax)
	addq	$2, %r9
	addq	$1, %r10
	cmpq	%rbx, %r9
	je	.L865
.L666:
	movl	%r13d, %r14d
	cmpl	$24734, %edi
	jle	.L664
	movswl	(%r9), %eax
	cmpl	%ecx, %eax
	jle	.L664
	testl	%r13d, %r13d
	je	.L665
	leal	-1(%r13), %eax
	cltq
	movswl	128(%rsp,%rax,2), %eax
	cmpl	%ecx, %eax
	jge	.L664
	jmp	.L665
.L865:
	movslq	%esi, %r9
	imulq	$715827883, %r9, %r9
	sarq	$34, %r9
	movl	%esi, %edx
	sarl	$31, %edx
	subl	%edx, %r9d
	leal	(%r9,%r9,2), %edx
	sall	$3, %edx
	subl	%edx, %esi
	movl	$24, %edx
	subl	%esi, %edx
	movl	%edx, 80(%rsp)
	leal	1(%r9), %eax
	movl	%eax, 84(%rsp)
	movl	$2, 100(%rsp)
	movl	$0, %r15d
	leaq	128(%rsp), %rax
	movq	%rax, 48(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 56(%rsp)
	movl	%r14d, 64(%rsp)
	movl	%r13d, 104(%rsp)
	movl	%esi, 88(%rsp)
	movl	%r8d, %ebp
	movl	%ecx, %ebx
	movl	%edi, 72(%rsp)
	movl	%r9d, 92(%rsp)
	jmp	.L667
.L867:
	movl	%r14d, %ecx
	movl	%r13d, %edx
	movl	%ebp, %esi
	movl	$5, %edi
	call	cr_mshape
	jmp	.L669
.L670:
	leal	(%r15,%r15), %eax
	movl	%eax, %ecx
	movw	%bx, 320(%rsp,%rcx,2)
	leal	1(%rax), %eax
	movw	%dx, 320(%rsp,%rax,2)
	addl	$1, %r15d
.L671:
	addq	$1, %r12
	leal	-1(%r12), %eax
	cmpl	%eax, 64(%rsp)
	jle	.L866
.L672:
	movq	48(%rsp), %rax
	movswl	(%rax,%r12,2), %ebp
	movl	16(%rsp), %eax
	imull	%ebp, %eax
	leal	4095(%rax), %ebx
	testl	%eax, %eax
	cmovns	%eax, %ebx
	sarl	$12, %ebx
	movl	24(%rsp), %eax
	addl	%eax, %ebx
	movq	56(%rsp), %rax
	movzbl	(%r12,%rax), %r13d
	cmpl	$24479, 72(%rsp)
	jg	.L867
	movl	%r14d, %ecx
	movl	%r13d, %edx
	movl	%ebp, %esi
	movl	92(%rsp), %edi
	call	cr_mshape
	movl	80(%rsp), %esi
	imull	%esi, %eax
	movl	%eax, 8(%rsp)
	movl	%r14d, %ecx
	movl	%r13d, %edx
	movl	%ebp, %esi
	movl	84(%rsp), %edi
	call	cr_mshape
	movl	88(%rsp), %ecx
	imull	%ecx, %eax
	movl	8(%rsp), %esi
	leal	(%rax,%rsi), %edx
	movslq	%edx, %rax
	imulq	$715827883, %rax, %rax
	sarq	$34, %rax
	sarl	$31, %edx
	subl	%edx, %eax
.L669:
	movl	44(%rsp), %esi
	imull	%esi, %eax
	leal	4095(%rax), %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	sarl	$12, %eax
	movl	40(%rsp), %edx
	subl	%eax, %edx
	testl	%r15d, %r15d
	je	.L670
	leal	-2(%r15,%r15), %eax
	movl	%eax, %ecx
	cmpw	%bx, 320(%rsp,%rcx,2)
	jne	.L670
	leal	1(%rax), %eax
	cmpw	%dx, 320(%rsp,%rax,2)
	jne	.L670
	jmp	.L671
.L866:
	movl	%r14d, %ebx
	movl	96(%rsp), %ebp
.L675:
	movl	16(%rsp), %eax
	addl	%eax, %ebp
	subl	$1, 100(%rsp)
	je	.L673
.L667:
	movl	%ebp, 24(%rsp)
	movl	$0, %r12d
	cmpl	$0, 104(%rsp)
	jle	.L675
	movl	%ebx, %r14d
	movl	%ebp, 96(%rsp)
	jmp	.L672
.L673:
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	%r15d, %esi
	call	cr_poly
	jmp	.L638
.L644:
	leal	(%rbx,%rbx,2), %eax
	sall	$7, %eax
	sarl	$12, %eax
	leal	(%rax,%rbp), %r13d
	addl	%eax, %eax
	subl	%eax, %edx
	movl	%edx, %ebp
	leal	(%rbx,%rbx,4), %eax
	sall	$7, %eax
	sarl	$12, %eax
	movl	24(%rsp), %esi
	addl	%esi, %ebx
	leal	(%rbx,%rsi), %edx
	movl	%edx, %r12d
	shrl	$31, %r12d
	addl	%edx, %r12d
	sarl	%r12d
	subl	%eax, %ebx
	addl	%esi, %eax
	subl	%eax, %ebx
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%eax, %ebx
	sarl	%ebx
	leal	(%r15,%r15,2), %eax
	sarl	$8, %eax
	jne	.L676
	leaq	WN.11(%rip), %rsi
	leaq	322(%rsp), %rcx
	leaq	21(%rsi), %rdi
	movl	$0, %edx
.L677:
	movslq	%edx, %rax
	imulq	$1717986919, %rax, %rax
	sarq	$35, %rax
	movl	%edx, %r8d
	sarl	$31, %r8d
	subl	%r8d, %eax
	addl	%r13d, %eax
	movw	%ax, -2(%rcx)
	movsbl	(%rsi), %r8d
	imull	%ebx, %r8d
	movslq	%r8d, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%r8d, %eax
	sarl	$6, %eax
	sarl	$31, %r8d
	subl	%r8d, %eax
	movl	%r12d, %r8d
	subl	%eax, %r8d
	movw	%r8w, (%rcx)
	addl	%ebp, %edx
	addq	$1, %rsi
	addq	$4, %rcx
	cmpq	%rdi, %rsi
	jne	.L677
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$24, %edx
	movl	$21, %esi
	call	cr_poly
	jmp	.L638
.L676:
	cmpl	$1, %eax
	jne	.L678
	leaq	BN.10(%rip), %rsi
	leaq	322(%rsp), %rcx
	leaq	11(%rsi), %rdi
	movl	$0, %edx
.L679:
	movslq	%edx, %rax
	imulq	$1717986919, %rax, %rax
	sarq	$34, %rax
	movl	%edx, %r8d
	sarl	$31, %r8d
	subl	%r8d, %eax
	addl	%r13d, %eax
	movw	%ax, -2(%rcx)
	movsbl	(%rsi), %r8d
	imull	%ebx, %r8d
	movslq	%r8d, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%r8d, %eax
	sarl	$6, %eax
	sarl	$31, %r8d
	subl	%r8d, %eax
	movl	%r12d, %r8d
	subl	%eax, %r8d
	movw	%r8w, (%rcx)
	addl	%ebp, %edx
	addq	$1, %rsi
	addq	$4, %rcx
	cmpq	%rdi, %rsi
	jne	.L679
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$11, %esi
	call	cr_poly
	jmp	.L638
.L678:
	leal	-8(%r12), %esi
	movzwl	14+ux(%rip), %r8d
	movl	$16, %ecx
	movl	%ebp, %edx
	movl	%r13d, %edi
	call	cr_frect
	leaq	SX.9(%rip), %r14
	leaq	SY.8(%rip), %r15
	movzwl	16(%rsp), %eax
	movl	%eax, 8(%rsp)
.L681:
	movswl	(%r14), %eax
	imull	%ebp, %eax
	leal	255(%rax), %ecx
	testl	%eax, %eax
	cmovns	%eax, %ecx
	sarl	$8, %ecx
	movsbl	(%r15), %edx
	imull	%ebx, %edx
	movslq	%edx, %rax
	imulq	$-2130574327, %rax, %rax
	shrq	$32, %rax
	addl	%edx, %eax
	sarl	$6, %eax
	movl	%edx, %esi
	sarl	$31, %esi
	subl	%esi, %eax
	movl	%eax, %edi
	negl	%edi
	cmovs	%eax, %edi
	movl	%r12d, %esi
	subl	%eax, %esi
	cmpl	$126, %edx
	cmovle	%r12d, %esi
	leal	-12(%r13,%rcx), %eax
	movl	8(%rsp), %r8d
	movl	%edi, %ecx
	movl	$24, %edx
	movl	%eax, %edi
	call	cr_frect
	addq	$2, %r14
	addq	$1, %r15
	leaq	8+SX.9(%rip), %rax
	cmpq	%rax, %r14
	jne	.L681
	jmp	.L638
.L647:
	leal	(%rbx,%rbx,4), %esi
	sall	$6, %esi
	sarl	$12, %esi
	leal	(%rsi,%rsi), %ecx
	subl	%ecx, %edx
	leal	7(%rdx), %ecx
	cmovns	%edx, %ecx
	sarl	$3, %ecx
	sall	$3, %r15d
	leal	(%rbx,%rbx), %edx
	leal	(%rdx,%rbx), %r12d
	sall	$6, %r12d
	sarl	$12, %r12d
	movl	%ebx, %edi
	sall	$7, %edi
	sarl	$12, %edi
	movl	%ecx, %eax
	subl	%edi, %eax
	movl	%eax, 8(%rsp)
	movl	24(%rsp), %r13d
	addl	%ebx, %r13d
	addl	%ebx, %edx
	sall	$7, %edx
	sarl	$12, %edx
	subl	%edx, %r13d
	sall	$6, %ebx
	sarl	$12, %ebx
	addl	%ebp, %esi
	addl	%esi, %ebx
	movl	$0, %ebp
	movl	%r12d, 24(%rsp)
	movl	%ecx, %r12d
	jmp	.L684
.L868:
	leaq	ux(%rip), %rax
	movzwl	14(%rax), %r8d
.L683:
	leal	0(,%rdx,8), %eax
	subl	%edx, %eax
	movslq	%eax, %rdx
	imulq	$780903145, %rdx, %rdx
	sarq	$33, %rdx
	movl	%eax, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	leal	(%rdx,%rdx,4), %ecx
	leal	(%rdx,%rcx,2), %edx
	subl	%edx, %eax
	imull	$800, %eax, %edx
	movslq	%edx, %rax
	imulq	$780903145, %rax, %rax
	sarq	$33, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	imull	%r14d, %eax
	sarl	$12, %eax
	movl	%r13d, %esi
	subl	%eax, %esi
	movl	24(%rsp), %ecx
	movl	8(%rsp), %edx
	movl	%ebx, %edi
	call	cr_frect
	addl	$1, %ebp
	addl	%r12d, %ebx
	cmpl	$8, %ebp
	je	.L638
.L684:
	movl	%ebp, %edx
	movl	%ebp, %eax
	sall	$8, %eax
	movzwl	16(%rsp), %r8d
	cmpl	%eax, %r15d
	jge	.L683
	jmp	.L868
.L651:
	leal	(%r15,%r15,2), %r13d
	sall	$6, %r13d
	leal	24576(%r13), %eax
	movl	%eax, 16(%rsp)
	leal	(%rbx,%rbx,4), %r14d
	sall	$8, %r14d
	sarl	$12, %r14d
	movl	%ebx, %ebp
	shrl	$31, %ebp
	addl	%ebx, %ebp
	sarl	%ebp
	movl	24(%rsp), %esi
	addl	%esi, %ebp
	movzwl	14+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 648
	pushq	$0
	.cfi_def_cfa_offset 656
	pushq	$0
	.cfi_def_cfa_offset 664
	pushq	$1
	.cfi_def_cfa_offset 672
	movl	$49152, %r9d
	movl	$24576, %r8d
	movl	$51, %ecx
	movl	%r14d, %edx
	movl	%ebp, %esi
	movl	40(%rsp), %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	testb	$4, 24(%r12)
	je	.L685
	cmpl	$49152, 16(%rsp)
	ja	.L869
	cmpl	$49151, 16(%rsp)
	jbe	.L870
.L687:
	movl	%ebx, %ecx
	sall	$8, %ecx
	sarl	$12, %ecx
	imull	$1824, %ebx, %eax
	sarl	$12, %eax
	movl	%ebp, %esi
	subl	%eax, %esi
	movl	8(%rsp), %eax
	leal	-13(%rax), %edi
	movzwl	36(%rsp), %r8d
	movl	$26, %edx
	call	cr_frect
.L688:
	leal	(%rbx,%rbx,2), %r12d
	sall	$7, %r12d
	sarl	$12, %r12d
	leal	40960(%r13), %edi
	call	cr_sin
	movl	%eax, %r13d
	movl	%r12d, %eax
	imull	%r13d, %eax
	sarl	$14, %eax
	movl	8(%rsp), %r15d
	addl	%r15d, %eax
	movw	%ax, 320(%rsp)
	movl	16(%rsp), %edi
	call	cr_sin
	imull	%eax, %r12d
	sarl	$14, %r12d
	leal	0(%rbp,%r12), %edx
	movw	%dx, 322(%rsp)
	imull	$896, %ebx, %ebx
	sarl	$12, %ebx
	imull	%ebx, %r13d
	sarl	$14, %r13d
	movl	%r15d, %edx
	addl	%r13d, %edx
	movw	%dx, 324(%rsp)
	imull	%ebx, %eax
	sarl	$14, %eax
	addl	%eax, %ebp
	movw	%bp, 326(%rsp)
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$38, %edx
	movl	$2, %esi
	call	cr_poly
	jmp	.L638
.L869:
	movzwl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 648
	pushq	$0
	.cfi_def_cfa_offset 656
	pushq	$0
	.cfi_def_cfa_offset 664
	pushq	$1
	.cfi_def_cfa_offset 672
	leal	-24576(%r13), %r9d
	movl	$49152, %r8d
	movl	$51, %ecx
	movl	%r14d, %edx
	movl	%ebp, %esi
	movl	40(%rsp), %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	jmp	.L687
.L870:
	movzwl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 648
	pushq	$0
	.cfi_def_cfa_offset 656
	pushq	$0
	.cfi_def_cfa_offset 664
	pushq	$1
	.cfi_def_cfa_offset 672
	movl	$49152, %r9d
	movl	48(%rsp), %eax
	subl	%eax, %r9d
	movl	%eax, %r8d
	movl	$51, %ecx
	movl	%r14d, %edx
	movl	%ebp, %esi
	movl	40(%rsp), %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	jmp	.L687
.L685:
	testl	%r15d, %r15d
	je	.L688
	movzwl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 648
	pushq	$0
	.cfi_def_cfa_offset 656
	pushq	$0
	.cfi_def_cfa_offset 664
	pushq	$1
	.cfi_def_cfa_offset 672
	movl	%r13d, %r9d
	movl	$24576, %r8d
	movl	$51, %ecx
	movl	%r14d, %edx
	movl	%ebp, %esi
	movl	40(%rsp), %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	jmp	.L688
.L643:
	testb	$2, 25(%r12)
	setne	%cl
	movzbl	%cl, %ecx
	addl	$1, %ecx
	movzbl	29(%r12), %esi
	movzbl	%sil, %eax
	movl	%eax, 40(%rsp)
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%ebx, %eax
	sarl	%eax
	movl	24(%rsp), %edi
	addl	%eax, %edi
	movl	%edi, 44(%rsp)
	leal	-64(%rbx), %eax
	movl	%eax, 8(%rsp)
	leal	96(%rbp), %eax
	movl	%eax, 56(%rsp)
	leal	-128(%rdx), %eax
	movl	%eax, 64(%rsp)
	movl	%ecx, %edi
	sall	$12, %edi
	sall	$4, %r15d
	movl	%r15d, %r8d
	cmpb	$6, %sil
	ja	.L814
	ja	.L691
	movzbl	%sil, %esi
	leaq	.L693(%rip), %rdx
	movslq	(%rdx,%rsi,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L693:
	.long	.L696-.L693
	.long	.L695-.L693
	.long	.L815-.L693
	.long	.L691-.L693
	.long	.L691-.L693
	.long	.L816-.L693
	.long	.L692-.L693
	.text
.L692:
	movl	$6, 40(%rsp)
	movl	$1, %r11d
	movl	$8, %r13d
	leaq	B_RN.4(%rip), %rax
	jmp	.L694
.L695:
	movl	$1, 40(%rsp)
	movl	$0, %r13d
	jmp	.L690
.L691:
	movl	$0, 128(%rsp)
	movb	$0, 512(%rsp)
	movl	%edi, 132(%rsp)
	movb	$0, 513(%rsp)
	movl	$1, %r13d
	movl	$1, %r11d
	leaq	B_0.7(%rip), %rax
	movl	$2, %ebx
	jmp	.L699
.L871:
	movslq	%ebx, %r9
	movl	%eax, 128(%rsp,%r9,4)
	movb	%r11b, 512(%rsp,%r9)
	leal	1(%rbx), %ebx
.L700:
	addq	$2, %rdx
	cmpq	%r10, %rdx
	je	.L704
.L701:
	movswl	(%rdx), %eax
	addl	%ecx, %eax
	subl	%r8d, %eax
	testl	%eax, %eax
	setg	%r15b
	cmpl	%eax, %edi
	setg	%r9b
	testb	%r9b, %r15b
	je	.L700
	cmpl	$45, %ebx
	jg	.L700
	jmp	.L871
.L704:
	addl	$4096, %esi
	cmpl	%r12d, %esi
	je	.L702
.L697:
	movl	%esi, %ecx
	movq	%r14, %rdx
	testl	%r13d, %r13d
	jg	.L701
	jmp	.L704
.L702:
	cmpl	$1, %ebx
	jle	.L705
	leaq	132(%rsp), %r9
	leaq	513(%rsp), %rsi
	movl	$1, %ecx
	leaq	512(%rsp), %r11
	jmp	.L706
.L708:
	movzbl	(%rax), %r14d
	movl	%r10d, 0(%r13)
	movzbl	-1(%rax), %r10d
	movb	%r10b, (%rax)
	movl	%r12d, -4(%r13)
	movb	%r14b, -1(%rax)
	subq	$4, %rdx
	subq	$1, %rax
	cmpq	%r11, %rax
	je	.L707
.L711:
	movq	%rdx, %r13
	movl	-4(%rdx), %r10d
	movl	(%rdx), %r12d
	cmpl	%r12d, %r10d
	jg	.L708
	jne	.L707
	movzbl	-1(%rax), %r15d
	cmpb	%r15b, (%rax)
	jb	.L708
.L707:
	addl	$1, %ecx
	addq	$4, %r9
	addq	$1, %rsi
	cmpl	%ebx, %ecx
	je	.L709
.L706:
	testl	%ecx, %ecx
	je	.L710
	movq	%rsi, %rax
	movq	%r9, %rdx
	jmp	.L711
.L705:
	testl	%ebx, %ebx
	jle	.L712
.L709:
	movl	8(%rsp), %esi
	movl	%esi, %eax
	shrl	$31, %eax
	addl	%esi, %eax
	sarl	%eax
	movl	%eax, 48(%rsp)
	movl	$0, %r12d
	movl	$0, %r15d
	leal	-1(%rbx), %eax
	movl	%eax, 24(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 72(%rsp)
	movl	%edi, 80(%rsp)
	movl	%ebp, 84(%rsp)
	movl	%r8d, %ebp
	jmp	.L721
.L874:
	movq	72(%rsp), %rax
	cmpb	$0, (%r12,%rax)
	je	.L872
.L715:
	leal	(%r15,%r15), %r14d
	movl	%r14d, %eax
	movzwl	16(%rsp), %esi
	movw	%si, 320(%rsp,%rax,2)
	movl	8(%rsp), %esi
	movl	$4096, %eax
	subl	$1, %esi
	cmovc	%eax, %esi
	movl	40(%rsp), %edi
	call	cr_lfo_y
	leal	1(%r14), %ecx
	movl	48(%rsp), %edx
	imull	%eax, %edx
	leal	16383(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$14, %eax
	movzwl	44(%rsp), %edx
	subl	%eax, %edx
	movw	%dx, 320(%rsp,%rcx,2)
	addl	$1, %r15d
.L716:
	cmpl	%r12d, 24(%rsp)
	jle	.L718
	leal	(%r15,%r15), %r14d
	movl	%r14d, %eax
	movzwl	16(%rsp), %esi
	movw	%si, 320(%rsp,%rax,2)
	movl	8(%rsp), %esi
	movl	40(%rsp), %edi
	call	cr_lfo_y
	leal	1(%r14), %ecx
	movl	48(%rsp), %edx
	imull	%eax, %edx
	leal	16383(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$14, %eax
	movzwl	44(%rsp), %edx
	subl	%eax, %edx
	movw	%dx, 320(%rsp,%rcx,2)
	addl	$1, %r15d
.L718:
	cmpl	%r13d, %ebx
	jle	.L719
	addq	$1, %r12
	leal	2(%r15), %eax
	cmpl	$48, %eax
	ja	.L873
.L721:
	movl	128(%rsp,%r12,4), %ecx
	leal	0(%rbp,%rcx), %eax
	andl	$4095, %eax
	movl	%eax, 8(%rsp)
	movl	64(%rsp), %eax
	imull	%ecx, %eax
	cltd
	idivl	80(%rsp)
	movl	56(%rsp), %esi
	addl	%esi, %eax
	movl	%eax, 16(%rsp)
	leal	1(%r12), %r13d
	cmpl	%r13d, %ebx
	jle	.L713
	cmpl	132(%rsp,%r12,4), %ecx
	je	.L874
.L713:
	movq	72(%rsp), %rax
	cmpb	$0, (%r12,%rax)
	jne	.L715
	cmpl	%r12d, 24(%rsp)
	jne	.L716
	jmp	.L715
.L873:
	movl	84(%rsp), %ebp
	movzwl	36(%rsp), %ebx
	leaq	320(%rsp), %rdi
	movl	%ebx, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	%r15d, %esi
	call	cr_poly
.L802:
	movswl	322(%rsp), %esi
	subl	$64, %esi
	leal	20(%rbp), %edi
	movl	%ebx, %r8d
	movl	$128, %ecx
	movl	$24, %edx
	call	cr_frect
	jmp	.L638
.L719:
	movl	84(%rsp), %ebp
	movzwl	36(%rsp), %ebx
	leaq	320(%rsp), %rdi
	movl	%ebx, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	%r15d, %esi
	call	cr_poly
	testl	%r15d, %r15d
	je	.L638
	jmp	.L802
.L640:
	leal	-10(%rdi), %eax
	cmpb	$18, %al
	ja	.L638
	movzbl	28(%r12), %eax
	movzbl	%al, %ecx
	cmpb	$-1, %al
	movl	$256, %eax
	cmovne	%ecx, %eax
	movl	%eax, 72(%rsp)
	leal	32(%rbp), %eax
	movl	%eax, 40(%rsp)
	addl	%ebp, %edx
	leal	-32(%rdx), %esi
	movl	%esi, 64(%rsp)
	movl	24(%rsp), %r11d
	leal	32(%r11), %r9d
	movl	%r9d, 56(%rsp)
	leal	(%rbx,%r11), %ecx
	leal	-32(%rcx), %r14d
	subl	%eax, %esi
	movl	%esi, 48(%rsp)
	movl	%r14d, %r12d
	subl	%r9d, %r12d
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%ebx, %eax
	sarl	%eax
	addl	%r11d, %eax
	movl	%eax, 44(%rsp)
	cmpl	%r12d, %esi
	cmovg	%r12d, %esi
	leal	-10(%rdi), %eax
	cmpb	$18, %al
	ja	.L638
	movzbl	%al, %eax
	leaq	.L726(%rip), %rdi
	movslq	(%rdi,%rax,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L726:
	.long	.L742-.L726
	.long	.L741-.L726
	.long	.L740-.L726
	.long	.L739-.L726
	.long	.L738-.L726
	.long	.L737-.L726
	.long	.L736-.L726
	.long	.L735-.L726
	.long	.L734-.L726
	.long	.L733-.L726
	.long	.L732-.L726
	.long	.L731-.L726
	.long	.L730-.L726
	.long	.L638-.L726
	.long	.L638-.L726
	.long	.L729-.L726
	.long	.L728-.L726
	.long	.L727-.L726
	.long	.L725-.L726
	.text
.L742:
	imull	$14, %r12d, %eax
	movslq	%eax, %rbx
	imulq	$1717986919, %rbx, %rbx
	sarq	$34, %rbx
	sarl	$31, %eax
	subl	%eax, %ebx
	movl	48(%rsp), %eax
	cmpl	%eax, %ebx
	cmovg	%eax, %ebx
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%ebx, %eax
	sarl	%eax
	movl	8(%rsp), %esi
	movl	%esi, %r11d
	subl	%eax, %r11d
	imull	$1966, %r15d, %eax
	sarl	$8, %eax
	negl	%eax
	addl	$2867, %eax
	movl	%ebx, %edx
	imull	%eax, %edx
	movl	%edx, %r15d
	sarl	$12, %r15d
	imull	%r12d, %eax
	movl	%eax, %ebp
	sarl	$12, %ebp
	shrl	$31, %edx
	addl	%r15d, %edx
	sarl	%edx
	subl	%edx, %esi
	movl	%esi, 16(%rsp)
	shrl	$31, %eax
	addl	%ebp, %eax
	sarl	%eax
	movl	44(%rsp), %esi
	subl	%eax, %esi
	movl	%esi, 24(%rsp)
	movzwl	36(%rsp), %r13d
	movl	%r13d, %r9d
	movl	$32, %r8d
	movl	%r12d, %ecx
	movl	%ebx, %edx
	movl	56(%rsp), %esi
	movl	%r11d, 8(%rsp)
	movl	%r11d, %edi
	call	cr_srect
	movl	%r13d, %r9d
	movl	$32, %r8d
	movl	%ebp, %ecx
	movl	%r15d, %edx
	movl	24(%rsp), %esi
	movl	16(%rsp), %edi
	call	cr_srect
	movl	$0, %r12d
	movzwl	8(%rsp), %eax
	movw	%ax, 36(%rsp)
.L751:
	movzwl	8(%rsp), %eax
	addl	%ebx, %eax
	movl	%r12d, %ecx
	andl	$1, %ecx
	cmove	36(%rsp), %ax
	movw	%ax, 320(%rsp)
	movl	%r12d, %edx
	andl	$2, %edx
	movzwl	56(%rsp), %eax
	cmovne	%r14d, %eax
	movw	%ax, 322(%rsp)
	movl	16(%rsp), %esi
	movl	%esi, %eax
	addl	%r15d, %eax
	testl	%ecx, %ecx
	cmove	%esi, %eax
	movw	%ax, 324(%rsp)
	movl	24(%rsp), %esi
	movl	%esi, %eax
	addl	%ebp, %eax
	testl	%edx, %edx
	cmove	%esi, %eax
	movw	%ax, 326(%rsp)
	leaq	320(%rsp), %rdi
	movl	%r13d, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$2, %esi
	call	cr_poly
	addl	$1, %r12d
	cmpl	$4, %r12d
	jne	.L751
	jmp	.L638
.L741:
	movl	%esi, %eax
	shrl	$31, %eax
	addl	%esi, %eax
	sarl	%eax
	movl	%eax, %ebp
	movl	%eax, 92(%rsp)
	imull	$3768, %r15d, %edx
	sarl	$8, %edx
	movl	$1720, %eax
	subl	%edx, %eax
	leal	(%rax,%rax), %edx
	movzwl	36(%rsp), %ebx
	movl	%ebx, 84(%rsp)
	shrl	$31, %eax
	movl	%eax, %r12d
	movl	8(%rsp), %ecx
	movl	%ecx, %eax
	subl	%ebp, %eax
	sarl	$4, %eax
	movl	%eax, %r13d
	leal	15(%rcx,%rbp), %eax
	sarl	$4, %eax
	movl	%eax, 72(%rsp)
	movslq	%ebp, %rax
	imulq	%rax, %rax
	movq	%rax, %rbx
	movl	%edx, %eax
	negl	%eax
	cmovs	%edx, %eax
	imull	%ebp, %eax
	sarl	$12, %eax
	testl	%eax, %eax
	movl	$1, %edx
	cmovle	%edx, %eax
	cltq
	imulq	%rax, %rax
	movq	%rax, %r14
	movq	%rbx, %r15
	imulq	%rax, %r15
	call	cr_row0
	movl	%eax, %edx
	movl	44(%rsp), %eax
	subl	%ebp, %eax
	sarl	$4, %eax
	cmpl	%edx, %eax
	movl	%edx, %edi
	cmovge	%eax, %edi
	movl	%edi, 16(%rsp)
	call	cr_row1
	movl	44(%rsp), %r11d
	leal	15(%r11,%rbp), %edx
	sarl	$4, %edx
	cmpl	%eax, %edx
	cmovg	%eax, %edx
	movl	16(%rsp), %edi
	cmpl	%edx, %edi
	jge	.L752
	movl	%edi, %eax
	sall	$4, %eax
	subl	%r11d, %eax
	leal	2(%rax), %ecx
	movl	%r13d, %eax
	sall	$4, %eax
	addl	$2, %eax
	movl	8(%rsp), %esi
	subl	%esi, %eax
	movl	%eax, %ebp
	movl	%edx, %r10d
	movl	%r12d, %r9d
	movq	%r15, %r12
	movq	%r14, %r15
	movq	%rbx, %r14
	movl	%ecx, %ebx
	movl	%r13d, %ecx
	jmp	.L753
.L875:
	movq	64(%rsp), %rdx
	addq	$1, %rdx
	cmpq	%rdx, %rax
	je	.L758
.L756:
	movzbl	(%rdx), %r12d
	movl	80(%rsp), %eax
	addl	%eax, %r12d
	movl	44(%rsp), %eax
	subl	%eax, %r12d
	leaq	CR_SS(%rip), %rbx
	movq	%rdx, 64(%rsp)
.L757:
	movzbl	(%rbx), %edi
	addl	%ebp, %edi
	movl	8(%rsp), %eax
	subl	%eax, %edi
	movl	36(%rsp), %r9d
	movq	24(%rsp), %r8
	movq	%r15, %rcx
	movq	%r14, %rdx
	movl	%r12d, %esi
	call	cr_moon_in
	addl	%eax, %r13d
	addq	$1, %rbx
	leaq	4+CR_SS(%rip), %rax
	cmpq	%rax, %rbx
	jne	.L757
	jmp	.L875
.L758:
	movq	24(%rsp), %r12
	movl	36(%rsp), %ebp
	testl	%r13d, %r13d
	je	.L755
	jmp	.L754
.L819:
	movl	$16, %r13d
.L754:
	movl	%r13d, %ecx
	sall	$4, %ecx
	movl	84(%rsp), %edx
	movl	88(%rsp), %esi
	movl	40(%rsp), %edi
	call	cr_blend
.L755:
	addl	$1, 40(%rsp)
	movl	40(%rsp), %eax
	addl	$16, 16(%rsp)
	cmpl	%eax, 72(%rsp)
	je	.L876
.L759:
	movl	16(%rsp), %eax
	leal	12(%rax), %r13d
	movl	%ebp, %r9d
	movq	%r12, %r8
	movq	%r15, %rcx
	movq	%r14, %rdx
	movl	48(%rsp), %esi
	movl	%eax, %edi
	call	cr_moon_in
	movl	%eax, %ebx
	movl	%ebp, %r9d
	movq	%r12, %r8
	movq	%r15, %rcx
	movq	%r14, %rdx
	movl	48(%rsp), %esi
	movl	%r13d, %edi
	call	cr_moon_in
	addl	%eax, %ebx
	movl	%ebp, %r9d
	movq	%r12, %r8
	movq	%r15, %rcx
	movq	%r14, %rdx
	movl	56(%rsp), %esi
	movl	16(%rsp), %edi
	call	cr_moon_in
	addl	%eax, %ebx
	movl	%ebp, %r9d
	movq	%r12, %r8
	movq	%r15, %rcx
	movq	%r14, %rdx
	movl	56(%rsp), %esi
	movl	%r13d, %edi
	call	cr_moon_in
	addl	%eax, %ebx
	cmpl	$4, %ebx
	je	.L819
	testl	%ebx, %ebx
	je	.L755
	movl	40(%rsp), %eax
	sall	$4, %eax
	leaq	CR_SS(%rip), %rdx
	movl	$0, %r13d
	movq	%r12, 24(%rsp)
	movl	%ebp, 36(%rsp)
	movl	%eax, %ebp
	jmp	.L756
.L876:
	movl	100(%rsp), %ecx
	movl	104(%rsp), %r10d
	movl	88(%rsp), %edi
	movl	108(%rsp), %ebx
	movl	%ebp, %r9d
	movl	96(%rsp), %ebp
.L761:
	addl	$1, %edi
	addl	$16, %ebx
	cmpl	%edi, %r10d
	je	.L752
.L753:
	movl	72(%rsp), %eax
	cmpl	%eax, %ecx
	jge	.L761
	movl	%edi, %eax
	sall	$4, %eax
	movl	%eax, 80(%rsp)
	movl	%ebx, 48(%rsp)
	leal	12(%rbx), %eax
	movl	%eax, 56(%rsp)
	movl	%ebp, 16(%rsp)
	movl	%ecx, 40(%rsp)
	movl	%ebp, 96(%rsp)
	movl	%ecx, 100(%rsp)
	movl	%r10d, 104(%rsp)
	movl	%edi, 88(%rsp)
	movl	%ebx, 108(%rsp)
	movl	%r9d, %ebp
	jmp	.L759
.L752:
	movl	84(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 648
	pushq	$0
	.cfi_def_cfa_offset 656
	pushq	$0
	.cfi_def_cfa_offset 664
	pushq	$0
	.cfi_def_cfa_offset 672
	movl	$65536, %r9d
	movl	$0, %r8d
	movl	$32, %ecx
	movl	124(%rsp), %edx
	movl	76(%rsp), %esi
	movl	40(%rsp), %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	jmp	.L638
.L740:
	movl	72(%rsp), %eax
	orl	%r15d, %eax
	jne	.L762
	movzwl	36(%rsp), %r8d
	movl	$16, %ecx
	movl	48(%rsp), %edx
	movl	%r14d, %esi
	movl	40(%rsp), %edi
	call	cr_frect
	jmp	.L638
.L762:
	movl	48(%rsp), %eax
	leal	-48(%rax), %edx
	movl	%edx, %eax
	shrl	$31, %eax
	addl	%edx, %eax
	sarl	%eax
	subl	$80, %eax
	imull	%r15d, %eax
	leal	255(%rax), %ebx
	testl	%eax, %eax
	cmovns	%eax, %ebx
	sarl	$8, %ebx
	addl	$80, %ebx
	movl	$64, %eax
	cmpl	%eax, %ebx
	cmovl	%eax, %ebx
	movzwl	36(%rsp), %r13d
	movl	%r13d, %r8d
	movl	%r12d, %ecx
	movl	$48, %edx
	movl	56(%rsp), %esi
	movl	40(%rsp), %r15d
	movl	%r15d, %edi
	call	cr_frect
	leal	(%r15,%rbx), %ebp
	leal	48(%rbp), %eax
	cmpl	%eax, 64(%rsp)
	jl	.L763
	movl	72(%rsp), %eax
	leal	(%rax,%rax,2), %eax
	leal	819(,%rax,4), %r15d
	movl	%r12d, %eax
	imull	%r15d, %eax
	movl	%eax, %r12d
	sarl	$12, %r12d
	cmpl	$98303, %eax
	jle	.L763
.L764:
	movl	%r14d, %esi
	subl	%r12d, %esi
	movl	%r13d, %r8d
	movl	%r12d, %ecx
	movl	$48, %edx
	movl	%ebp, %edi
	call	cr_frect
	addl	%ebx, %ebp
	leal	48(%rbp), %eax
	cmpl	%eax, 64(%rsp)
	jl	.L763
	movl	%r12d, %eax
	imull	%r15d, %eax
	movl	%eax, %r12d
	sarl	$12, %r12d
	cmpl	$98303, %eax
	jg	.L764
.L763:
	movl	%r13d, %r8d
	movl	$16, %ecx
	movl	48(%rsp), %edx
	movl	%r14d, %esi
	movl	40(%rsp), %edi
	call	cr_frect
	jmp	.L638
.L739:
	addl	$64, %r15d
	imull	$3768, 72(%rsp), %eax
	sarl	$8, %eax
	addl	$328, %eax
	movl	%r12d, %edx
	shrl	$31, %edx
	addl	%r12d, %edx
	sarl	%edx
	imull	%edx, %eax
	movl	%eax, %r13d
	sarl	$12, %r13d
	movl	%r15d, %ebx
	sall	$6, %ebx
	addl	$4095, %ebx
	sarl	$12, %ebx
	sall	$3, %ebx
	movl	$44, %eax
	cmpl	%eax, %ebx
	cmovg	%eax, %ebx
	movl	$16, %eax
	cmpl	%eax, %ebx
	cmovl	%eax, %ebx
	leaq	320(%rsp), %rbp
	sall	$10, %r15d
	movl	%ebx, 16(%rsp)
	movl	%ebx, %eax
	leaq	324(%rsp,%rax,4), %rax
	movq	%rax, 8(%rsp)
	movl	$0, %r14d
	movl	$0, %r12d
.L766:
	movl	%r12d, %eax
	cltd
	idivl	%ebx
	addw	40(%rsp), %ax
	movw	%ax, 0(%rbp)
	movl	%r14d, %eax
	cltd
	idivl	%ebx
	movl	%eax, %edi
	call	cr_sin
	imull	%r13d, %eax
	sarl	$14, %eax
	movzwl	44(%rsp), %edx
	subl	%eax, %edx
	movw	%dx, 2(%rbp)
	movl	48(%rsp), %eax
	addl	%eax, %r12d
	addq	$4, %rbp
	addl	%r15d, %r14d
	cmpq	%rbp, 8(%rsp)
	jne	.L766
	movl	16(%rsp), %esi
	addl	$1, %esi
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	call	cr_poly
	jmp	.L638
.L725:
	movl	72(%rsp), %eax
	leal	(%rax,%rax,4), %eax
	shrl	$3, %eax
	addl	$96, %eax
	movslq	%r12d, %rdx
	imulq	$1431655766, %rdx, %rdx
	shrq	$32, %rdx
	movl	%r12d, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	imull	%edx, %eax
	leal	255(%rax), %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	sarl	$8, %eax
	movl	%eax, %ebx
	movl	$3, %edx
	cmpl	$192, %r15d
	jg	.L767
	cmpl	$64, %r15d
	setg	%dl
	movzbl	%dl, %edx
	addl	$1, %edx
.L767:
	movl	56(%rsp), %ecx
	subl	%r14d, %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	sarl	$31, %ecx
	subl	%ecx, %eax
	movl	44(%rsp), %esi
	addl	%esi, %eax
	movw	%ax, 44(%rsp)
	movslq	%r12d, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movl	%r12d, %ecx
	sarl	$31, %ecx
	subl	%ecx, %eax
	addl	%esi, %eax
	movw	%ax, 56(%rsp)
	sall	$16, %edx
	movl	%edx, 24(%rsp)
	movl	$0, %r14d
	leaq	452(%rsp), %r15
	movl	%ebx, %r13d
	jmp	.L768
.L769:
	movzwl	8(%rsp), %edx
	subl	%eax, %edx
	movw	%dx, 2(%rbp)
	movl	24(%rsp), %eax
	addl	%eax, %r12d
	movl	48(%rsp), %eax
	addl	%eax, %ebx
	addq	$4, %rbp
	cmpq	%r15, %rbp
	je	.L877
.L772:
	movl	%r12d, %edi
	shrl	$5, %edi
	call	cr_sin
	imull	%r13d, %eax
	sarl	$14, %eax
	leal	31(%rbx), %edx
	testl	%ebx, %ebx
	cmovns	%ebx, %edx
	sarl	$5, %edx
	addw	40(%rsp), %dx
	movw	%dx, 0(%rbp)
	testl	%r14d, %r14d
	je	.L769
	addw	8(%rsp), %ax
	movw	%ax, 2(%rbp)
	movl	24(%rsp), %eax
	addl	%eax, %r12d
	movl	48(%rsp), %eax
	addl	%eax, %ebx
	addq	$4, %rbp
	cmpq	%r15, %rbp
	jne	.L772
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$33, %esi
	call	cr_poly
	jmp	.L638
.L877:
	leaq	320(%rsp), %rdi
	movzwl	16(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$33, %esi
	call	cr_poly
	addl	$1, %r14d
	cmpl	$2, %r14d
	je	.L638
.L768:
	testl	%r14d, %r14d
	movzwl	44(%rsp), %eax
	cmovne	56(%rsp), %ax
	movw	%ax, 8(%rsp)
	leaq	320(%rsp), %rbp
	movl	$0, %ebx
	movl	$0, %r12d
	jmp	.L772
.L738:
	leal	(%r15,%r15,8), %eax
	sall	$4, %eax
	leal	4096(%rax), %r13d
	movl	%r12d, %eax
	shrl	$31, %eax
	addl	%r12d, %eax
	sarl	%eax
	movl	%eax, %r14d
	movl	$0, %ebx
	movl	$0, %ebp
	leaq	322(%rsp), %r12
	movl	%r15d, 8(%rsp)
	movl	%edx, 56(%rsp)
	movl	%ecx, 72(%rsp)
	movl	48(%rsp), %r15d
.L773:
	movl	%ebx, %edi
	sall	$9, %edi
	call	cr_sin
	leal	31(%rbp), %edx
	testl	%ebp, %ebp
	cmovns	%ebp, %edx
	sarl	$5, %edx
	addw	40(%rsp), %dx
	movw	%dx, 320(%rsp,%rbx)
	imull	%r13d, %eax
	sarl	$12, %eax
	movl	$-16384, %edx
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	movl	$16384, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	imull	%r14d, %eax
	sarl	$14, %eax
	movzwl	44(%rsp), %edx
	subl	%eax, %edx
	movw	%dx, (%r12,%rbx)
	addl	%r15d, %ebp
	addq	$4, %rbx
	cmpq	$132, %rbx
	jne	.L773
	movl	8(%rsp), %r15d
	movl	56(%rsp), %edx
	movl	72(%rsp), %ecx
	cmpl	$25, %r15d
	jle	.L774
	movl	40(%rsp), %ebp
	movl	64(%rsp), %eax
	cmpl	%eax, %ebp
	jge	.L774
	leal	-32(%rdx), %ebx
	movl	%ecx, %r14d
.L775:
	movl	%ebx, %r12d
	subl	%ebp, %r12d
	movl	$32, %eax
	cmpl	%eax, %r12d
	cmovg	%eax, %r12d
	movzwl	16(%rsp), %r13d
	movl	24(%rsp), %eax
	leal	24(%rax), %esi
	movl	%r13d, %r8d
	movl	$16, %ecx
	movl	%r12d, %edx
	movl	%ebp, %edi
	call	cr_frect
	leal	-40(%r14), %esi
	movl	%r13d, %r8d
	movl	$16, %ecx
	movl	%r12d, %edx
	movl	%ebp, %edi
	call	cr_frect
	addl	$64, %ebp
	cmpl	%ebp, 64(%rsp)
	jg	.L775
.L774:
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$33, %esi
	call	cr_poly
	jmp	.L638
.L729:
	movl	40(%rsp), %edi
	movw	%di, 320(%rsp)
	movw	%r14w, 322(%rsp)
	movl	48(%rsp), %esi
	movslq	%esi, %rax
	imulq	$715827883, %rax, %rax
	movq	%rax, %rbx
	shrq	$32, %rbx
	sarq	$33, %rax
	sarl	$31, %esi
	movl	%esi, %ebp
	subl	%esi, %eax
	movl	%edi, %esi
	leal	(%rax,%rsi), %edx
	movw	%dx, 324(%rsp)
	movl	44(%rsp), %r9d
	movw	%r9w, 326(%rsp)
	movl	8(%rsp), %r11d
	movw	%r11w, 328(%rsp)
	leal	7(%r12), %edx
	testl	%r12d, %r12d
	cmovns	%r12d, %edx
	sarl	$3, %edx
	movl	56(%rsp), %esi
	movl	%esi, %ecx
	addl	%edx, %ecx
	movw	%cx, 330(%rsp)
	movl	64(%rsp), %r15d
	movw	%r15w, 332(%rsp)
	movw	%si, 334(%rsp)
	movl	%r15d, %ecx
	subl	%eax, %ecx
	movw	%cx, 336(%rsp)
	movw	%r9w, 338(%rsp)
	movw	%r11w, 340(%rsp)
	movl	%r14d, %eax
	subl	%edx, %eax
	movw	%ax, 342(%rsp)
	movw	%di, 344(%rsp)
	movw	%r14w, 346(%rsp)
	movzwl	36(%rsp), %r14d
	leaq	320(%rsp), %r13
	movl	%r14d, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$7, %esi
	movq	%r13, %rdi
	call	cr_poly
	subl	%ebp, %ebx
	movl	%r15d, %eax
	subl	%ebx, %eax
	movw	%ax, 324(%rsp)
	movslq	%r12d, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movl	%r12d, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	addw	56(%rsp), %ax
	movw	%ax, 326(%rsp)
	movl	%r14d, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$2, %esi
	movq	%r13, %rdi
	call	cr_poly
	jmp	.L638
.L728:
	movslq	%r12d, %rbp
	imulq	$1431655766, %rbp, %rbp
	shrq	$32, %rbp
	movl	%r12d, %eax
	sarl	$31, %eax
	subl	%eax, %ebp
	movl	56(%rsp), %eax
	addl	%eax, %ebp
	movl	$32, %ebx
	cmpl	$223, %esi
	jle	.L776
	movslq	%esi, %rbx
	imulq	$-1840700269, %rbx, %rbx
	shrq	$32, %rbx
	addl	%esi, %ebx
	sarl	$2, %ebx
	sarl	$31, %esi
	subl	%esi, %ebx
.L776:
	movzwl	36(%rsp), %r14d
	movl	%ebx, %eax
	shrl	$31, %eax
	addl	%ebx, %eax
	sarl	%eax
	movl	%eax, %r13d
	negl	%r13d
	movl	8(%rsp), %edi
	addl	%r13d, %edi
	movl	%r14d, %r8d
	movl	%r12d, %ecx
	movl	%ebx, %edx
	movl	56(%rsp), %esi
	call	cr_frect
	movl	48(%rsp), %ecx
	leal	(%rcx,%rcx,2), %eax
	leal	3(%rax), %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	sarl	$2, %edx
	leal	0(%rbp,%r13), %esi
	leal	7(%rcx), %edi
	testl	%ecx, %ecx
	cmovns	%ecx, %edi
	sarl	$3, %edi
	movl	40(%rsp), %eax
	addl	%eax, %edi
	movl	%r14d, %r8d
	movl	%ebx, %ecx
	call	cr_frect
	jmp	.L638
.L737:
	movl	48(%rsp), %esi
	leal	(%rsi,%rsi,2), %edx
	sall	$2, %edx
	movslq	%edx, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	movl	40(%rsp), %ebx
	leal	(%rbx,%rax), %r8d
	addl	%eax, %eax
	subl	%eax, %esi
	movl	%esi, %r9d
	leal	(%r12,%r12,8), %eax
	sall	$2, %eax
	movslq	%eax, %rdx
	imulq	$1374389535, %rdx, %rdx
	sarq	$37, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	movw	%bx, 320(%rsp)
	movl	44(%rsp), %eax
	movw	%ax, 322(%rsp)
	movw	%r8w, 324(%rsp)
	movw	%ax, 326(%rsp)
	leal	(%rsi,%rsi), %r11d
	movl	%esi, %edi
	leaq	330(%rsp), %rsi
	movl	$0, %ecx
	movl	%edx, %r10d
	negl	%edx
.L779:
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	sarq	$35, %rax
	movl	%edi, %ebx
	sarl	$31, %ebx
	subl	%ebx, %eax
	addl	%r8d, %eax
	movw	%ax, -2(%rsi)
	testb	$1, %cl
	movl	%r10d, %eax
	cmove	%edx, %eax
	addw	44(%rsp), %ax
	movw	%ax, (%rsi)
	addl	$1, %ecx
	addl	%r11d, %edi
	addq	$4, %rsi
	cmpl	$13, %ecx
	jne	.L779
	addl	%r9d, %r8d
	movw	%r8w, 380(%rsp)
	movl	44(%rsp), %eax
	movw	%ax, 382(%rsp)
	movzwl	64(%rsp), %esi
	movw	%si, 384(%rsp)
	movw	%ax, 386(%rsp)
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$17, %esi
	call	cr_poly
	jmp	.L638
.L736:
	leal	(%rsi,%rsi,8), %eax
	sall	$3, %eax
	movslq	%eax, %rbx
	imulq	$1374389535, %rbx, %rbx
	sarq	$37, %rbx
	sarl	$31, %eax
	subl	%eax, %ebx
	movl	%esi, %ebp
	subl	%ebx, %ebp
	movl	%esi, %eax
	shrl	$31, %eax
	addl	%esi, %eax
	sarl	%eax
	negl	%eax
	movl	8(%rsp), %edi
	addl	%eax, %edi
	movl	44(%rsp), %esi
	addl	%eax, %esi
	leal	0(%rbp,%rdi), %r12d
	addl	%esi, %ebp
	imull	%ebx, %r15d
	movzwl	36(%rsp), %r14d
	movl	%r14d, %r9d
	movl	$32, %r8d
	movl	%ebx, %ecx
	movl	%ebx, %edx
	call	cr_srect
	leal	64(%rbx), %edx
	leal	-32(%rbp), %esi
	leal	-32(%r12), %edi
	movzwl	ux(%rip), %r8d
	movl	%edx, %ecx
	call	cr_frect
	cmpl	$255, %r15d
	jg	.L878
.L780:
	movl	%r14d, %r9d
	movl	$32, %r8d
	movl	%ebx, %ecx
	movl	%ebx, %edx
	movl	%ebp, %esi
	movl	%r12d, %edi
	call	cr_srect
	jmp	.L638
.L878:
	movl	$256, %ecx
	movl	%r15d, %eax
	cltd
	idivl	%ecx
	movl	%eax, %ecx
	leal	(%rbx,%rbp), %esi
	subl	%eax, %esi
	movl	%r14d, %r8d
	movl	%ebx, %edx
	movl	%r12d, %edi
	call	cr_frect
	jmp	.L780
.L727:
	testl	%r15d, %r15d
	jne	.L781
	movzwl	40(%rsp), %eax
	movw	%ax, 320(%rsp)
	movl	44(%rsp), %eax
	movw	%ax, 322(%rsp)
	movzwl	64(%rsp), %esi
	movw	%si, 324(%rsp)
	movw	%ax, 326(%rsp)
	movl	$2, %esi
.L782:
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	call	cr_poly
	jmp	.L638
.L781:
	movslq	%r12d, %rsi
	imulq	$1717986919, %rsi, %rsi
	sarq	$34, %rsi
	movl	%r12d, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	40(%rsp), %r11d
	movw	%r11w, 320(%rsp)
	movl	56(%rsp), %edx
	addl	%esi, %edx
	movw	%dx, 322(%rsp)
	movl	48(%rsp), %ebx
	movslq	%ebx, %rax
	imulq	$1374389535, %rax, %rcx
	sarq	$35, %rcx
	movl	%ebx, %edi
	sarl	$31, %edi
	subl	%edi, %ecx
	addl	%r11d, %ecx
	movw	%cx, 324(%rsp)
	movl	%r14d, %ecx
	subl	%esi, %ecx
	movw	%cx, 326(%rsp)
	imulq	$1717986919, %rax, %rax
	sarq	$34, %rax
	subl	%edi, %eax
	addl	%r11d, %eax
	movw	%ax, 328(%rsp)
	movw	%cx, 330(%rsp)
	leal	(%rbx,%rbx,2), %ecx
	leal	3(%rcx), %eax
	testl	%ecx, %ecx
	cmovns	%ecx, %eax
	sarl	$2, %eax
	addl	%r11d, %eax
	movw	%ax, 332(%rsp)
	movw	%dx, 334(%rsp)
	movzwl	64(%rsp), %eax
	movw	%ax, 336(%rsp)
	movw	%dx, 338(%rsp)
	movl	$5, %esi
	jmp	.L782
.L735:
	movl	40(%rsp), %esi
	movw	%si, 320(%rsp)
	movw	%r14w, 322(%rsp)
	movw	%si, 324(%rsp)
	leal	(%r12,%r12,2), %edx
	sall	$2, %edx
	movslq	%edx, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	movl	56(%rsp), %ebx
	addl	%ebx, %eax
	movw	%ax, 326(%rsp)
	imull	$230, %r15d, %edx
	sarl	$8, %edx
	addl	$26, %edx
	movl	48(%rsp), %ebx
	imull	%ebx, %edx
	leal	255(%rdx), %ecx
	testl	%edx, %edx
	cmovs	%ecx, %edx
	sarl	$8, %edx
	addl	%esi, %edx
	movw	%dx, 328(%rsp)
	movw	%ax, 330(%rsp)
	movw	%dx, 332(%rsp)
	movw	%r14w, 334(%rsp)
	movzwl	64(%rsp), %eax
	movw	%ax, 336(%rsp)
	movw	%r14w, 338(%rsp)
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$5, %esi
	call	cr_poly
	jmp	.L638
.L734:
	movl	40(%rsp), %ebp
	movw	%bp, 320(%rsp)
	leal	3(%r12), %eax
	testl	%r12d, %r12d
	cmovns	%r12d, %eax
	sarl	$2, %eax
	movl	44(%rsp), %r14d
	movl	%r14d, %edx
	subl	%eax, %edx
	movw	%dx, 322(%rsp)
	movw	%bp, 324(%rsp)
	addl	%r14d, %eax
	movw	%ax, 326(%rsp)
	movw	%bp, 328(%rsp)
	movw	%r14w, 330(%rsp)
	movl	64(%rsp), %esi
	movw	%si, 332(%rsp)
	movw	%r14w, 334(%rsp)
	movw	%si, 336(%rsp)
	movw	%dx, 338(%rsp)
	movw	%si, 340(%rsp)
	movw	%ax, 342(%rsp)
	movzwl	36(%rsp), %ebx
	leaq	320(%rsp), %rdi
	movl	%ebx, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$6, %esi
	call	cr_poly
	imull	$230, %r15d, %eax
	sarl	$8, %eax
	addl	$26, %eax
	movl	48(%rsp), %esi
	imull	%esi, %eax
	leal	255(%rax), %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	sarl	$8, %edx
	movl	%r14d, %esi
	subl	$40, %esi
	movl	%ebx, %r8d
	movl	$80, %ecx
	movl	%ebp, %edi
	call	cr_frect
	jmp	.L638
.L733:
	imull	$30, 48(%rsp), %eax
	movslq	%eax, %rbx
	imulq	$1374389535, %rbx, %rbx
	sarq	$37, %rbx
	sarl	$31, %eax
	subl	%eax, %ebx
	movl	%r12d, %edx
	sall	$5, %edx
	movslq	%edx, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	cmpl	%eax, %ebx
	cmovg	%eax, %ebx
	cmpl	$63, %r15d
	jg	.L783
	movl	8(%rsp), %eax
	movl	%eax, 120(%rsp)
	movl	$1, 128(%rsp)
	movl	$1, %r12d
.L784:
	movslq	%r12d, %r12
	movl	$0, %ebp
	leaq	128(%rsp), %r13
	jmp	.L789
.L783:
	cmpl	$127, %r15d
	jg	.L785
	movl	8(%rsp), %eax
	movl	%eax, 120(%rsp)
	movl	$0, 128(%rsp)
	movl	$1, %r12d
	jmp	.L784
.L785:
	cmpl	$191, %r15d
	jg	.L786
	imull	$14, %ebx, %eax
	movl	$10, %ecx
	cltd
	idivl	%ecx
	movl	%eax, %ecx
	imull	$22, 48(%rsp), %eax
	movl	$100, %esi
	cltd
	idivl	%esi
	cmpl	%eax, %ecx
	cmovg	%eax, %ecx
	movl	8(%rsp), %esi
	movl	%esi, %eax
	subl	%ecx, %eax
	movl	%eax, 120(%rsp)
	movl	$1, 128(%rsp)
	addl	%ecx, %esi
	movl	%esi, 124(%rsp)
	movl	$0, 132(%rsp)
	movl	$2, %r12d
	jmp	.L784
.L786:
	movl	%esi, %eax
	sall	$5, %eax
	movl	$100, %ecx
	cltd
	idivl	%ecx
	movl	%eax, %ebx
	movzwl	36(%rsp), %ebp
	movl	44(%rsp), %r15d
	movl	%r15d, %esi
	subl	%eax, %esi
	movl	%ebp, %ecx
	movl	$40, %edx
	movl	8(%rsp), %r14d
	movl	%r14d, %edi
	call	cr_disc
	imull	$6, %ebx, %eax
	movl	$10, %ecx
	cltd
	idivl	%ecx
	addl	%eax, %r15d
	imull	$95, %ebx, %ebx
	movl	$-100, %ecx
	movl	%ebx, %eax
	cltd
	idivl	%ecx
	movl	%eax, %ebx
	leal	(%r14,%rax), %edi
	movl	%ebp, %ecx
	movl	$40, %edx
	movl	%r15d, %esi
	call	cr_disc
	subl	%ebx, %r14d
	movl	%r14d, %edi
	movl	%ebp, %ecx
	movl	$40, %edx
	movl	%r15d, %esi
	call	cr_disc
	jmp	.L638
.L823:
	movl	%r14d, %ecx
	movl	56(%rsp), %esi
	movl	$-1, %eax
.L788:
	movl	120(%rsp,%rbp,4), %edx
	movw	%dx, 320(%rsp)
	movw	%si, 322(%rsp)
	movw	%dx, 324(%rsp)
	movw	%cx, 326(%rsp)
	movl	%edx, %esi
	subl	%ebx, %esi
	movw	%si, 328(%rsp)
	imull	%ebx, %eax
	addl	%ecx, %eax
	movw	%ax, 330(%rsp)
	movw	%dx, 332(%rsp)
	movw	%cx, 334(%rsp)
	addl	%ebx, %edx
	movw	%dx, 336(%rsp)
	movw	%ax, 338(%rsp)
	leaq	320(%rsp), %rdi
	movzwl	16(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$5, %esi
	call	cr_poly
	addq	$1, %rbp
	cmpq	%r12, %rbp
	je	.L638
.L789:
	cmpl	$0, 0(%r13,%rbp,4)
	je	.L823
	movl	56(%rsp), %ecx
	movl	%r14d, %esi
	movl	$1, %eax
	jmp	.L788
.L732:
	movl	$64, %edx
	cmpl	$324, %r12d
	jle	.L790
	movslq	%r12d, %rdx
	imulq	$1717986919, %rdx, %rdx
	sarq	$33, %rdx
	movl	%r12d, %eax
	sarl	$31, %eax
	subl	%eax, %edx
.L790:
	movl	%edx, %eax
	shrl	$31, %eax
	addl	%edx, %eax
	sarl	%eax
	movl	56(%rsp), %edi
	addl	%eax, %edi
	movl	%r14d, %esi
	subl	%eax, %esi
	movl	%esi, %ecx
	subl	%edi, %ecx
	leal	3(%rcx), %ebx
	cmovns	%ecx, %ebx
	sarl	$2, %ebx
	movl	%r12d, %ecx
	sall	$4, %ecx
	movslq	%ecx, %rbp
	imulq	$1717986919, %rbp, %rbp
	sarq	$34, %rbp
	sarl	$31, %ecx
	subl	%ecx, %ebp
	movl	48(%rsp), %ecx
	cmpl	%ecx, %ebp
	cmovg	%ecx, %ebp
	movl	%ebp, %ecx
	shrl	$31, %ecx
	addl	%ebp, %ecx
	sarl	%ecx
	movl	8(%rsp), %r8d
	subl	%ecx, %r8d
	leal	-16(%r8), %r14d
	leal	-16(%rdi), %r12d
	movl	$5, 24(%rsp)
	movzwl	16(%rsp), %r13d
	movl	%r15d, 16(%rsp)
	movl	%edx, 36(%rsp)
	movl	%esi, %r15d
	movl	%eax, 40(%rsp)
.L791:
	leal	32(%rbp), %edx
	movl	%r13d, %r8d
	movl	$32, %ecx
	movl	%r12d, %esi
	movl	%r14d, %edi
	call	cr_frect
	addl	%ebx, %r12d
	subl	$1, 24(%rsp)
	jne	.L791
	movl	36(%rsp), %edx
	movl	%r15d, %esi
	movl	16(%rsp), %r15d
	movl	40(%rsp), %eax
	leal	128(,%r15,4), %ecx
	sarl	$8, %ecx
	imull	%ebx, %ecx
	subl	%ecx, %esi
	subl	%eax, %esi
	movl	8(%rsp), %edi
	subl	%eax, %edi
	movl	%r13d, %r8d
	movl	%edx, %ecx
	call	cr_frect
	jmp	.L638
.L731:
	leal	-256(%r15,%r15), %edi
	testl	%edi, %edi
	movl	$0, %r14d
	cmovns	%edi, %r14d
	negl	%edi
	movl	%edi, %r15d
	movl	$0, %eax
	cmovs	%eax, %r15d
	movq	$0, 8(%rsp)
	movl	$1, %esi
	movl	%r12d, 24(%rsp)
	movl	%esi, 16(%rsp)
	jmp	.L794
.L880:
	movq	8(%rsp), %rsi
	movl	%ebp, 128(%rsp,%rsi,4)
	movl	%ebp, %eax
	negl	%eax
	cmovs	%ebp, %eax
	movl	16(%rsp), %ebx
	cmpl	%eax, %ebx
	cmovge	%ebx, %eax
	movl	%eax, 16(%rsp)
	addq	$1, %rsi
	movq	%rsi, 8(%rsp)
	cmpq	$41, %rsi
	je	.L879
.L794:
	movl	8(%rsp), %eax
	sall	$16, %eax
	movslq	%eax, %r13
	imulq	$1717986919, %r13, %r13
	sarq	$36, %r13
	sarl	$31, %eax
	subl	%eax, %r13d
	movl	%r13d, %edi
	call	cr_sin
	movl	%eax, %ebp
	leal	(%r13,%r13), %r12d
	movl	$2, %ebx
.L793:
	movl	%r12d, %edi
	call	cr_sin
	movl	%eax, %ecx
	movl	%ebx, %edx
	andl	$1, %edx
	cmovne	%r14d, %edx
	leal	(%r15,%rdx), %eax
	imull	%ecx, %eax
	movl	%ebx, %ecx
	sall	$8, %ecx
	cltd
	idivl	%ecx
	addl	%eax, %ebp
	addl	$1, %ebx
	addl	%r13d, %r12d
	cmpl	$8, %ebx
	jne	.L793
	jmp	.L880
.L879:
	movl	24(%rsp), %r12d
	movl	%eax, %esi
	movl	%r12d, %r9d
	shrl	$31, %r9d
	addl	%r12d, %r9d
	sarl	%r9d
	leaq	128(%rsp), %r8
	leaq	322(%rsp), %rdi
	leaq	292(%rsp), %r10
	movl	$0, %ecx
	movl	48(%rsp), %r11d
	movl	44(%rsp), %ebx
.L795:
	movslq	%ecx, %rax
	imulq	$1717986919, %rax, %rax
	sarq	$36, %rax
	movl	%ecx, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	addw	40(%rsp), %ax
	movw	%ax, -2(%rdi)
	movl	%r9d, %eax
	imull	(%r8), %eax
	cltd
	idivl	%esi
	movl	%ebx, %edx
	subl	%eax, %edx
	movw	%dx, (%rdi)
	addl	%r11d, %ecx
	addq	$4, %r8
	addq	$4, %rdi
	cmpq	%r10, %r8
	jne	.L795
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$41, %esi
	call	cr_poly
	jmp	.L638
.L730:
	imull	$115, %r12d, %r12d
	leal	255(%r12), %eax
	testl	%r12d, %r12d
	cmovns	%r12d, %eax
	sarl	$8, %eax
	imull	%r15d, %eax
	leal	255(%rax), %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	sarl	$8, %eax
	movl	%eax, %r12d
	movl	$0, %ebp
	movl	$0, %ebx
	movl	$0, %esi
	leaq	JT.1(%rip), %r13
	movzwl	16(%rsp), %eax
	movl	%eax, 8(%rsp)
	leaq	320(%rsp), %r14
	movq	%r14, 16(%rsp)
	movl	48(%rsp), %r14d
	jmp	.L801
.L796:
	cmpl	$76, %r15d
	jle	.L798
	movslq	%ebx, %rax
	imulq	$1431655766, %rax, %rax
	shrq	$32, %rax
	movl	%ebx, %ecx
	sarl	$31, %ecx
	subl	%ecx, %eax
	leal	(%rax,%rax,2), %eax
	subl	%eax, %edx
	cmpl	$2, %edx
	je	.L797
.L798:
	testl	%esi, %esi
	jne	.L800
	leal	15(%rbp), %eax
	testl	%ebp, %ebp
	cmovns	%ebp, %eax
	sarl	$4, %eax
	addw	40(%rsp), %ax
	movw	%ax, 320(%rsp)
	movswl	0(%r13,%rbx,2), %edx
	imull	%r12d, %edx
	leal	255(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$8, %eax
	addw	44(%rsp), %ax
	movw	%ax, 322(%rsp)
	movl	$1, %esi
.L800:
	leal	(%rsi,%rsi), %ecx
	movl	%ecx, %edi
	leal	0(%rbp,%r14), %edx
	leal	15(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$4, %eax
	addw	40(%rsp), %ax
	movw	%ax, 320(%rsp,%rdi,2)
	leal	1(%rcx), %ecx
	leaq	2+JT.1(%rip), %rax
	movswl	(%rax,%rbx,2), %edx
	imull	%r12d, %edx
	leal	255(%rdx), %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	sarl	$8, %eax
	addw	44(%rsp), %ax
	movw	%ax, 320(%rsp,%rcx,2)
	addl	$1, %esi
.L799:
	addq	$1, %rbx
	addl	%r14d, %ebp
	cmpq	$16, %rbx
	je	.L881
.L801:
	movl	%ebx, %edx
	cmpl	$179, %r15d
	jle	.L796
	testb	$1, %bl
	je	.L798
.L797:
	cmpl	$1, %esi
	ja	.L882
	movl	$0, %esi
	jmp	.L799
.L882:
	movl	8(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movq	16(%rsp), %rdi
	call	cr_poly
	movl	$0, %esi
	jmp	.L799
.L881:
	cmpl	$1, %esi
	jbe	.L638
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	call	cr_poly
	jmp	.L638
.L712:
	leaq	320(%rsp), %rdi
	movzwl	36(%rsp), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$32, %edx
	movl	$0, %esi
	call	cr_poly
	jmp	.L638
.L696:
	movl	$0, 40(%rsp)
	movl	$0, %r11d
	movl	$2, %r13d
	leaq	B_TRI.6(%rip), %rax
.L694:
	movl	$0, 128(%rsp)
	movb	$0, 512(%rsp)
	movl	%edi, 132(%rsp)
	movb	$0, 513(%rsp)
	movl	$2, %ebx
	jmp	.L699
.L815:
	movl	$2, 40(%rsp)
	movl	$1, %r11d
	movl	$2, %r13d
	leaq	B_SQ.5(%rip), %rax
	jmp	.L694
.L814:
	movl	$1, 40(%rsp)
	movl	$0, %r13d
.L690:
	movl	$0, 128(%rsp)
	movb	$0, 512(%rsp)
	movl	%edi, 132(%rsp)
	movb	$0, 513(%rsp)
	movl	%ecx, %r9d
	sall	$4, %r9d
	movl	$1, %eax
	leaq	513(%rsp), %rsi
.L698:
	movl	%eax, %ebx
	movl	%eax, %edx
	sall	$8, %edx
	movl	%edx, 132(%rsp,%rax,4)
	movb	$0, (%rsi,%rax)
	addq	$1, %rax
	cmpl	%eax, %r9d
	jg	.L698
	addl	$2, %ebx
	movl	$1, %r11d
	leaq	B_0.7(%rip), %rax
.L699:
	leal	1(%rcx), %r12d
	sall	$12, %r12d
	movq	%rax, %r14
	movslq	%r13d, %rdx
	leaq	(%rax,%rdx,2), %r10
	movl	$-4096, %esi
	jmp	.L697
.L816:
	movl	$5, 40(%rsp)
	movl	$1, %r13d
	jmp	.L690
.L872:
	addq	$1, %r12
	jmp	.L721
.L710:
	addl	$1, %ecx
	addq	$4, %r9
	addq	$1, %rsi
	jmp	.L706
.L863:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE157:
	.size	cr_cglyph, .-cr_cglyph
	.type	cr_ring_draw, @function
cr_ring_draw:
.LFB194:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	movq	%rdi, %rbx
	movq	%fs:40, %rax
	movq	%rax, 248(%rsp)
	xorl	%eax, %eax
	movzwl	14+ux(%rip), %eax
	movw	%ax, 68(%rsp)
	cmpb	$0, 112(%rdi)
	je	.L884
	movzwl	22+ux(%rip), %eax
	movw	%ax, 62(%rsp)
.L885:
	movzwl	116(%rbx), %eax
	movl	$0, 56(%rsp)
	testw	%ax, %ax
	je	.L886
	movzwl	%ax, %edx
	sall	$8, %edx
	cmpw	$256, %ax
	movl	$65536, %eax
	cmovb	%edx, %eax
	movl	%eax, 56(%rsp)
.L886:
	call	cr_row0
	movl	%eax, 16(%rsp)
	call	cr_row1
	movl	%eax, %ebx
	movzbl	6100+cr_ring(%rip), %eax
	testb	%al, %al
	je	.L937
	cmpb	$1, %al
	jne	.L898
.L897:
	cmpl	$0, 56(%rsp)
	jne	.L938
.L901:
	cmpl	%ebx, 16(%rsp)
	jge	.L883
	movl	cv_w(%rip), %r15d
	movswl	cr_clip(%rip), %r13d
	movswl	4+cr_clip(%rip), %eax
	movl	%eax, 24(%rsp)
	movl	16(%rsp), %ecx
	movl	%ecx, %eax
	addl	cv_oy(%rip), %eax
	imull	%r15d, %eax
	movl	%eax, %ebp
	movslq	%ecx, %rax
	leaq	cr_ring(%rip), %rdx
	leaq	(%rdx,%rax,2), %rax
	movq	%rax, 40(%rsp)
	movzwl	62(%rsp), %eax
	rolw	$8, %ax
	movw	%ax, 70(%rsp)
	movl	%r15d, 72(%rsp)
	movl	%r13d, %r15d
	movl	%ebx, 76(%rsp)
	movl	%ecx, %edx
	jmp	.L917
.L884:
	movzbl	113(%rdi), %edi
	movl	$57797, %esi
	call	cr_rgb
	movw	%ax, 62(%rsp)
	jmp	.L885
.L937:
	leaq	80(%rsp), %rdi
	pushq	$0
	.cfi_def_cfa_offset 328
	pushq	$0
	.cfi_def_cfa_offset 336
	pushq	$0
	.cfi_def_cfa_offset 344
	pushq	$65536
	.cfi_def_cfa_offset 352
	movl	$0, %r9d
	movl	$80, %r8d
	movl	$1808, %ecx
	movl	$1920, %edx
	movl	$1920, %esi
	call	cr_arc_geom
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	leaq	160(%rsp), %rdi
	pushq	$96
	.cfi_def_cfa_offset 328
	pushq	$32
	.cfi_def_cfa_offset 336
	pushq	$0
	.cfi_def_cfa_offset 344
	pushq	$65536
	.cfi_def_cfa_offset 352
	movl	$0, %r9d
	movl	$80, %r8d
	movl	$1808, %ecx
	movl	$1920, %edx
	movl	$1920, %esi
	call	cr_arc_geom
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	movl	$1, %r8d
	movl	$0, %edi
	movl	$0, %esi
	leaq	cr_ring(%rip), %rcx
	jmp	.L888
.L939:
	leal	1(%rsi,%rdi), %edi
	addl	$1, %esi
	addl	$1, %r8d
	cmpl	$17, %esi
	je	.L890
.L888:
	movl	$0, %eax
.L889:
	leal	(%rax,%rdi), %edx
	movb	%sil, 1442(%rcx,%rdx)
	movb	%al, 1595(%rcx,%rdx)
	addl	$1, %eax
	cmpl	%r8d, %eax
	jne	.L889
	jmp	.L939
.L890:
	movb	$2, 6100+cr_ring(%rip)
	leaq	cr_ring(%rip), %rax
	movl	$0, %r15d
	leaq	80(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	movl	%ebx, 36(%rsp)
	movl	%r15d, %r14d
.L896:
	movw	%r15w, (%rax)
	movb	$0, 963(%rax)
	movb	$0, 962(%rax)
	movl	$0, %r12d
	movl	$0, 32(%rsp)
	movl	$0, %ebp
	movslq	%r14d, %rdx
	leaq	cr_ring(%rip), %rcx
	leaq	(%rcx,%rdx,2), %r13
	movq	%rax, 24(%rsp)
	jmp	.L895
.L892:
	cmpl	$4351, %r15d
	ja	.L898
.L894:
	leaq	160(%rsp), %rdi
	movl	%r14d, %edx
	movl	%ebp, %esi
	call	cr_arc_px
	movl	%eax, %ecx
	movl	%r15d, %edx
	leal	1(%rbx), %eax
	imull	%ebx, %eax
	shrl	%eax
	addl	%ecx, %eax
	leaq	cr_ring(%rip), %rcx
	movb	%al, 1748(%rcx,%rdx)
	leal	-1(%r12), %eax
	cltq
	addb	$1, 962(%rax,%r13)
	leal	1(%r15), %r15d
	movl	$1, 32(%rsp)
.L891:
	addl	$1, %ebp
	cmpl	$240, %ebp
	je	.L940
.L895:
	movl	%r14d, %edx
	movl	%ebp, %esi
	movq	8(%rsp), %rdi
	call	cr_arc_px
	movl	%eax, %ebx
	testl	%eax, %eax
	je	.L924
	cmpl	$0, 32(%rsp)
	jne	.L892
	cmpl	$2, %r12d
	je	.L898
	cmpl	$4351, %r15d
	ja	.L898
	movslq	%r12d, %rax
	movb	%bpl, 482(%rax,%r13)
	leal	1(%r12), %r12d
	jmp	.L894
.L924:
	movl	$0, 32(%rsp)
	jmp	.L891
.L940:
	movq	24(%rsp), %rax
	addl	$1, %r14d
	addq	$2, %rax
	cmpl	$240, %r14d
	jne	.L896
	movl	36(%rsp), %ebx
	movw	%r15w, 480+cr_ring(%rip)
	movb	$1, 6100+cr_ring(%rip)
	jmp	.L897
.L898:
	movzwl	68(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 328
	pushq	$96
	.cfi_def_cfa_offset 336
	pushq	$32
	.cfi_def_cfa_offset 344
	pushq	$0
	.cfi_def_cfa_offset 352
	movl	$65536, %r9d
	movl	$0, %r8d
	movl	$80, %ecx
	movl	$1808, %edx
	movl	$1920, %esi
	movl	$1920, %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	cmpl	$0, 56(%rsp)
	jne	.L941
.L883:
	movq	248(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L942
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L941:
	.cfi_restore_state
	movzwl	62(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 328
	pushq	$0
	.cfi_def_cfa_offset 336
	pushq	$0
	.cfi_def_cfa_offset 344
	pushq	$0
	.cfi_def_cfa_offset 352
	movl	88(%rsp), %r9d
	movl	$49152, %r8d
	movl	$80, %ecx
	movl	$1808, %edx
	movl	$1920, %esi
	movl	$1920, %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	jmp	.L883
.L938:
	leaq	160(%rsp), %rdi
	pushq	$0
	.cfi_def_cfa_offset 328
	pushq	$0
	.cfi_def_cfa_offset 336
	pushq	$0
	.cfi_def_cfa_offset 344
	movl	80(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 352
	movl	$49152, %r9d
	movl	$80, %r8d
	movl	$1808, %ecx
	movl	$1920, %edx
	movl	$1920, %esi
	call	cr_arc_geom
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	jmp	.L901
.L945:
	movl	%r13d, %eax
	leaq	cr_ring(%rip), %rsi
	movzbl	1442(%rsi,%rax), %ecx
.L907:
	cmpl	$15, %ecx
	ja	.L943
	movl	%r13d, %r13d
	leaq	cr_ring(%rip), %rax
	movzbl	1595(%rax,%r13), %eax
	testb	%al, %al
	jne	.L920
.L912:
	testl	%ecx, %ecx
	je	.L905
	sall	$4, %ecx
	movzwl	0(%rbp), %edx
	movzbl	%dh, %eax
	sall	$8, %edx
	orl	%eax, %edx
	movzwl	%dx, %eax
	movl	$256, %esi
	subl	%ecx, %esi
	movzwl	62(%rsp), %r10d
	movl	%r10d, %r8d
	shrw	$5, %r8w
	andl	$63, %r8d
	imull	%ecx, %r8d
	movl	%eax, %edi
	shrl	$5, %edi
	andl	$63, %edi
	imull	%esi, %edi
	leal	128(%r8,%rdi), %edi
	shrl	$8, %edi
	sall	$5, %edi
	movl	%r10d, %r8d
	shrw	$11, %r8w
	movzwl	%r8w, %r8d
	imull	%ecx, %r8d
	shrl	$11, %eax
	imull	%esi, %eax
	leal	128(%r8,%rax), %eax
	shrl	$8, %eax
	sall	$11, %eax
	orl	%edi, %eax
	movl	%r10d, %edi
	andl	$31, %edi
	imull	%edi, %ecx
	andl	$31, %edx
	imull	%esi, %edx
	leal	128(%rcx,%rdx), %edx
	shrl	$8, %edx
	orl	%edx, %eax
	movzbl	%ah, %edx
	sall	$8, %eax
	orl	%edx, %eax
	movw	%ax, 0(%rbp)
.L905:
	addq	$1, %rbx
	addq	$2, %rbp
	cmpl	%ebx, %r12d
	jle	.L944
.L914:
	cmpl	%ebx, %r15d
	jg	.L905
	cmpl	%ebx, 24(%rsp)
	jle	.L905
	movq	8(%rsp), %rax
	subq	%r14, %rax
	movzbl	(%rax,%rbx), %r13d
	cmpl	$1, 32(%rsp)
	je	.L945
	cmpl	$2, 32(%rsp)
	je	.L946
.L908:
	movl	%r13d, %r13d
	leaq	cr_ring(%rip), %rax
	movzbl	1595(%rax,%r13), %eax
	testb	%al, %al
	je	.L905
	movl	$0, %ecx
.L920:
	movzbl	%al, %eax
	sall	$4, %eax
	cmpl	$255, %eax
	ja	.L947
	movzwl	0(%rbp), %edx
	movzbl	%dh, %esi
	movl	%edx, %edi
	sall	$8, %edi
	orl	%esi, %edi
	movzwl	%di, %edx
	movl	$256, %esi
	subl	%eax, %esi
	movzwl	68(%rsp), %r11d
	movl	%r11d, %r9d
	shrw	$5, %r9w
	andl	$63, %r9d
	imull	%eax, %r9d
	movl	%edx, %r8d
	shrl	$5, %r8d
	andl	$63, %r8d
	imull	%esi, %r8d
	leal	128(%r9,%r8), %r8d
	shrl	$8, %r8d
	sall	$5, %r8d
	movl	%r11d, %r9d
	shrw	$11, %r9w
	movzwl	%r9w, %r9d
	imull	%eax, %r9d
	shrl	$11, %edx
	imull	%esi, %edx
	leal	128(%r9,%rdx), %edx
	shrl	$8, %edx
	sall	$11, %edx
	orl	%r8d, %edx
	movl	%r11d, %r8d
	andl	$31, %r8d
	imull	%eax, %r8d
	movl	%edi, %eax
	andl	$31, %eax
	imull	%esi, %eax
	leal	128(%r8,%rax), %eax
	shrl	$8, %eax
	orl	%edx, %eax
	movzbl	%ah, %edx
	sall	$8, %eax
	orl	%edx, %eax
	movw	%ax, 0(%rbp)
	jmp	.L912
.L946:
	movl	%ebx, %esi
	sall	$4, %esi
	subl	$1912, %esi
	movl	36(%rsp), %edi
	sall	$4, %edi
	subl	$1912, %edi
	call	cr_atan2
	subl	$49152, %eax
	movzwl	%ax, %edx
	testl	$65472, %eax
	je	.L909
	leal	64(%rdx), %eax
	cmpl	%eax, 56(%rsp)
	jb	.L909
	movl	%r13d, %eax
	leaq	cr_ring(%rip), %rdx
	movzbl	1442(%rdx,%rax), %ecx
	jmp	.L907
.L909:
	movl	56(%rsp), %eax
	addl	$64, %eax
	cmpl	%edx, %eax
	jnb	.L930
	cmpl	$65471, %edx
	jbe	.L908
.L930:
	leaq	160(%rsp), %rdi
	movl	36(%rsp), %edx
	movl	%ebx, %esi
	call	cr_arc_px
	movl	%eax, %ecx
	jmp	.L907
.L943:
	movzwl	70(%rsp), %eax
	movw	%ax, 0(%rbp)
	jmp	.L905
.L947:
	movzwl	68(%rsp), %eax
	movzbl	%ah, %edx
	sall	$8, %eax
	orl	%edx, %eax
	movw	%ax, 0(%rbp)
	jmp	.L912
.L944:
	movzbl	61(%rsp), %r13d
	movzbl	%r13b, %r13d
	subl	%r13d, %r12d
	leal	-1(%r12), %eax
	movq	8(%rsp), %rcx
	leaq	1(%rcx,%rax), %rax
	movq	%rax, 8(%rsp)
	addq	$1, 16(%rsp)
	movq	16(%rsp), %rcx
	movq	40(%rsp), %rax
	addq	$2, %rax
	cmpq	%rax, %rcx
	je	.L915
.L902:
	movq	16(%rsp), %rax
	movzbl	962(%rax), %r12d
	testb	%r12b, %r12b
	je	.L915
	movq	16(%rsp), %rax
	movzbl	482(%rax), %r13d
	movzbl	%r13b, %esi
	movzbl	%r12b, %r12d
	addl	%esi, %r12d
	movl	$0, 32(%rsp)
	movl	56(%rsp), %r14d
	testl	%r14d, %r14d
	je	.L903
	movl	$1, 32(%rsp)
	cmpl	$65535, %r14d
	ja	.L903
	movl	36(%rsp), %ebp
	sall	$4, %ebp
	subl	$1912, %ebp
	sall	$4, %esi
	subl	$1912, %esi
	movl	%ebp, %edi
	call	cr_atan2
	movl	%eax, %ebx
	movl	%r12d, %esi
	sall	$4, %esi
	subl	$1928, %esi
	movl	%ebp, %edi
	call	cr_atan2
	leal	-49152(%rbx), %edx
	movzwl	%dx, %edx
	subl	%ebx, %eax
	cwtl
	addl	%edx, %eax
	movl	$2, 32(%rsp)
	cmpl	$65535, %eax
	ja	.L903
	cmpl	%eax, %edx
	movl	%eax, %ecx
	cmovle	%edx, %ecx
	cmovl	%eax, %edx
	cmpl	$95, %ecx
	jle	.L904
	leal	95(%rdx), %eax
	movl	$1, 32(%rsp)
	cmpl	%r14d, %eax
	jl	.L903
.L904:
	movl	56(%rsp), %eax
	addl	$96, %eax
	cmpl	%eax, %ecx
	setg	%al
	cmpl	$65439, %edx
	setle	%dl
	andl	%edx, %eax
	xorl	$1, %eax
	movzbl	%al, %eax
	addl	%eax, %eax
	movl	%eax, 32(%rsp)
.L903:
	movzbl	%r13b, %r14d
	movq	48(%rsp), %rax
	leaq	(%rax,%r14), %rdx
	leaq	cv_px(%rip), %rax
	leaq	(%rax,%rdx,2), %rbp
	movq	%r14, %rbx
	movb	%r13b, 61(%rsp)
	jmp	.L914
.L915:
	movl	36(%rsp), %edx
	movl	64(%rsp), %ebp
	addl	$1, %edx
	movl	72(%rsp), %eax
	addl	%eax, %ebp
	addq	$2, 40(%rsp)
	cmpl	%edx, 76(%rsp)
	je	.L883
.L917:
	movl	%ebp, %eax
	movq	%rax, 48(%rsp)
	movq	40(%rsp), %rsi
	movzwl	(%rsi), %ecx
	leaq	1748+cr_ring(%rip), %rax
	addq	%rcx, %rax
	movq	%rax, 8(%rsp)
	movq	%rsi, 16(%rsp)
	movl	%edx, 36(%rsp)
	movl	%ebp, 64(%rsp)
	jmp	.L902
.L942:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE194:
	.size	cr_ring_draw, .-cr_ring_draw
	.type	cr_text, @function
cr_text:
.LFB124:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$296, %rsp
	.cfi_def_cfa_offset 352
	movl	%edi, %r12d
	movl	%esi, 72(%rsp)
	movq	%rdx, %rbx
	movq	%rdx, 80(%rsp)
	movl	%ecx, %esi
	movl	%r8d, %edx
	movl	%r9d, %r15d
	movl	360(%rsp), %r14d
	movl	368(%rsp), %r13d
	movw	%r14w, 112(%rsp)
	movw	%r13w, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 280(%rsp)
	xorl	%eax, %eax
	movq	%rbx, %rdi
	call	cr_face
	movq	%rax, 16(%rsp)
	movzbl	(%rbx), %ebx
	movl	%r12d, 68(%rsp)
	testb	%bl, %bl
	je	.L949
	movq	%rdx, %rbp
	movl	%edx, 40(%rsp)
	movq	%rdx, %rax
	sarq	$32, %rax
	testl	%eax, %eax
	je	.L950
	cmpl	$4096, 352(%rsp)
	je	.L1133
.L950:
	movl	40(%rsp), %edx
	movq	80(%rsp), %rsi
	movq	16(%rsp), %rdi
	call	cr_adv8
	imull	352(%rsp), %eax
	sarl	$12, %eax
	cmpl	$1, %r15d
	je	.L1134
	cmpl	$2, %r15d
	movl	$0, %edx
	cmovne	%edx, %eax
.L1002:
	subl	%eax, %r12d
	movl	%r12d, 68(%rsp)
	movl	%ebp, %eax
	imull	352(%rsp), %eax
	sarl	$12, %eax
	movl	%eax, 28(%rsp)
	movq	80(%rsp), %r13
	movl	$-32767, 60(%rsp)
	movl	$-32767, 32(%rsp)
	movl	$32767, 56(%rsp)
	movl	$32767, %r14d
	movl	$0, %eax
	movl	$0, %r15d
	movl	%r15d, %ebp
	movl	%r14d, 48(%rsp)
	movl	%eax, %r14d
	jmp	.L1063
.L1133:
	movq	80(%rsp), %rsi
	movq	16(%rsp), %rdi
	call	text_w
	sall	$8, %eax
	cmpl	$1, %r15d
	je	.L1135
	cmpl	$2, %r15d
	movl	$0, %edx
	cmovne	%edx, %eax
.L952:
	movl	%r12d, %edi
	subl	%eax, %edi
	movl	%edi, 68(%rsp)
	movl	72(%rsp), %eax
	subl	$-128, %eax
	sarl	$8, %eax
	movq	16(%rsp), %rbx
	movzbl	1(%rbx), %edx
	subl	%edx, %eax
	movl	%eax, 168(%rsp)
	leal	128(%rdi), %eax
	sarl	$8, %eax
	movl	%eax, 144(%rsp)
	cmpb	$0, 32+ux(%rip)
	leaq	CURVE_DARK(%rip), %rdx
	leaq	CURVE_LIGHT(%rip), %rax
	cmove	%rdx, %rax
	movq	%rax, %rbp
	movl	36+ux(%rip), %eax
	cmpl	%eax, 216+rc(%rip)
	je	.L954
	movl	%eax, 216+rc(%rip)
	movb	$0, 220+rc(%rip)
.L955:
	movzbl	220+rc(%rip), %eax
	leal	1(%rax), %ecx
	movl	%ecx, %edx
	movl	$2863311531, %esi
	imulq	%rsi, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,2), %edx
	addl	%edx, %edx
	subl	%edx, %ecx
	movb	%cl, 220+rc(%rip)
	movl	$0, %esi
.L1066:
	addl	$1, %esi
	movb	%sil, 221+rc(%rip)
	jmp	.L959
.L1135:
	sarl	%eax
	jmp	.L952
.L954:
	movzbl	221+rc(%rip), %esi
	movzbl	%sil, %ecx
	testb	%sil, %sil
	je	.L955
	movl	$0, %eax
	leaq	rc(%rip), %rdx
	leaq	12(%rdx), %rdi
	movzwl	112(%rsp), %r8d
	movzwl	8(%rsp), %r9d
	jmp	.L958
.L956:
	addq	$1, %rax
	cmpl	%ecx, %eax
	jnb	.L1136
.L958:
	cmpw	(%rdx,%rax,2), %r8w
	jne	.L956
	cmpw	(%rdi,%rax,2), %r9w
	jne	.L956
	movl	%eax, %eax
	salq	$5, %rax
	leaq	rc(%rip), %rdx
	leaq	24(%rdx,%rax), %rax
	movq	%rax, 32(%rsp)
	movq	16(%rsp), %rax
	movzbl	48(%rax), %ecx
	movl	$16, %eax
	sarl	%cl, %eax
	movl	%eax, 152(%rsp)
	movq	80(%rsp), %rax
	movzbl	(%rax), %eax
	jmp	.L957
.L1136:
	movzbl	220+rc(%rip), %eax
	leal	1(%rax), %ecx
	movl	%ecx, %edx
	movl	$2863311531, %edi
	imulq	%rdi, %rdx
	shrq	$34, %rdx
	leal	(%rdx,%rdx,2), %edx
	addl	%edx, %edx
	subl	%edx, %ecx
	movb	%cl, 220+rc(%rip)
	cmpb	$5, %sil
	jbe	.L1066
.L959:
	leaq	rc(%rip), %rdx
	movl	%eax, %eax
	movw	%r14w, (%rdx,%rax,2)
	movw	%r13w, 12(%rdx,%rax,2)
	salq	$5, %rax
	leaq	24(%rdx,%rax), %r10
	movq	%r10, 32(%rsp)
	movzbl	33+ux(%rip), %r9d
	movl	%r13d, %eax
	shrw	$11, %ax
	movzwl	%ax, %r8d
	movl	%r14d, %eax
	shrw	$11, %ax
	movzwl	%ax, %eax
	subl	%r8d, %eax
	movl	%eax, %r14d
	movl	$0, %esi
	leaq	SH.17(%rip), %r12
	leaq	MK.16(%rip), %r13
	movzwl	8(%rsp), %r11d
	movzwl	112(%rsp), %ebx
	movl	%r8d, %r15d
	jmp	.L963
.L960:
	movzbl	0(%rbp,%rsi), %r8d
	movl	$0, %edi
	movl	$0, %edx
	movq	%r10, 8(%rsp)
	movb	%r9b, 28(%rsp)
.L962:
	movzbl	(%r12,%rdi), %ecx
	movzbl	0(%r13,%rdi), %r10d
	movl	%r11d, %r9d
	sarl	%cl, %r9d
	andl	%r10d, %r9d
	movl	%ebx, %eax
	sarl	%cl, %eax
	andl	%r10d, %eax
	subl	%r9d, %eax
	imull	%r8d, %eax
	subl	$-128, %eax
	sarl	$8, %eax
	addl	%r9d, %eax
	sall	%cl, %eax
	orl	%eax, %edx
	addq	$1, %rdi
	cmpq	$3, %rdi
	jne	.L962
	movq	8(%rsp), %r10
	movzbl	28(%rsp), %r9d
.L961:
	rolw	$8, %dx
	movw	%dx, (%r10,%rsi,2)
	addq	$1, %rsi
	cmpq	$16, %rsi
	je	.L1137
.L963:
	testb	%r9b, %r9b
	je	.L960
	movzbl	0(%rbp,%rsi), %eax
	imull	%r14d, %eax
	subl	$-128, %eax
	sarl	$8, %eax
	addl	%r15d, %eax
	movl	%eax, %edx
	sall	$11, %edx
	movl	%eax, %ecx
	sall	$6, %ecx
	orl	%ecx, %edx
	orl	%eax, %edx
	movzwl	%dx, %edx
	jmp	.L961
.L1137:
	movq	16(%rsp), %rax
	movzbl	48(%rax), %ecx
	movl	$16, %eax
	sarl	%cl, %eax
	movl	%eax, 152(%rsp)
	movq	80(%rsp), %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L949
.L957:
	movl	cv_oy(%rip), %edi
	movl	%edi, 136(%rsp)
	movswl	cv_cy0(%rip), %edi
	movl	%edi, 56(%rsp)
	movswl	cv_cy1(%rip), %r15d
	movl	cv_w(%rip), %edi
	movl	%edi, 172(%rsp)
	movq	80(%rsp), %rbx
	movq	%rbx, 88(%rsp)
	movl	$-32767, 120(%rsp)
	movl	$-32767, 116(%rsp)
	movl	$32767, 104(%rsp)
	movl	$32767, %ebp
	movl	$0, 100(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, %esi
	leaq	hc_tab(%rip), %r12
	movl	%ebp, 128(%rsp)
	movl	%r15d, 96(%rsp)
	movl	%edi, %r15d
	jmp	.L998
.L1144:
	movl	60(%rsp), %edx
	movq	16(%rsp), %rdi
	call	kern
	addl	%eax, 64(%rsp)
	jmp	.L965
.L966:
	movl	64(%rsp), %eax
	leal	8(%rax), %edx
	andl	$-16, %edx
.L968:
	movl	%edx, %eax
	movl	64(%rsp), %edi
	subl	%edi, %eax
	movl	%eax, 100(%rsp)
	movzbl	6(%r10), %eax
	testb	%al, %al
	je	.L969
	sarl	$4, %edx
	movl	144(%rsp), %edi
	addl	%edi, %edx
	movsbl	4(%r10), %ecx
	leal	(%rdx,%rcx), %edi
	movl	%edi, 28(%rsp)
	movzbl	5(%r10), %edx
	movl	168(%rsp), %edi
	addl	%edx, %edi
	movl	%edi, 112(%rsp)
	movq	16(%rsp), %rcx
	movq	56(%rcx), %rdi
	testq	%rdi, %rdi
	je	.L970
	movzwl	(%r10), %edx
	addq	16(%rcx), %rdx
	movzbl	7(%r10), %ecx
	movl	%ecx, 52(%rsp)
	movzbl	%al, %eax
	movq	(%r12), %rcx
	cmpq	%rcx, %rdi
	setne	%sil
	testq	%rcx, %rcx
	setne	%cl
	andl	%ecx, %esi
	movl	%esi, %r9d
	movzbl	%sil, %r11d
	movl	%r11d, %esi
	movq	%rsi, %rcx
	salq	$6, %rcx
	addq	%rsi, %rcx
	cmpq	(%r12,%rcx,8), %rdi
	je	.L971
	movq	%rsi, %rcx
	salq	$6, %rcx
	addq	%rsi, %rcx
	movq	%rdi, (%r12,%rcx,8)
	movzbl	%r9b, %r8d
	negq	%r8
	andl	$520, %r8d
	leaq	8(%r12,%r8), %rcx
	leaq	520+hc_tab(%rip), %rsi
	addq	%r8, %rsi
.L972:
	movw	$0, (%rcx)
	addq	$2, %rcx
	cmpq	%rcx, %rsi
	jne	.L972
	movl	$1, %r14d
	movl	$15, %r13d
	movl	$0, %ebx
	movl	%r11d, %ecx
	movq	%rcx, %rsi
	salq	$6, %rsi
	addq	%rcx, %rsi
	leaq	0(,%rsi,4), %r11
	movq	%r10, 8(%rsp)
	movl	%eax, 40(%rsp)
	movb	%r9b, 48(%rsp)
	movq	%rdx, 72(%rsp)
	movl	%r15d, 160(%rsp)
	jmp	.L973
.L1138:
	addl	$1, %ebp
	addl	$1, %ebx
	addl	$1, %r13d
	movzbl	-1(%rdi,%r14), %eax
	cmpl	%eax, %ebp
	jnb	.L977
.L975:
	movl	%ebx, %r8d
	sall	%cl, %r8d
	leal	(%r8,%r15), %eax
	movl	%r13d, %r9d
.L974:
	movl	%eax, %edx
	addq	%r11, %rdx
	movzbl	(%rdi,%r9), %esi
	orl	%r10d, %esi
	movw	%si, 8(%r12,%rdx,2)
	movl	%eax, %edx
	subl	$1, %eax
	cmpl	%edx, %r8d
	jne	.L974
	jmp	.L1138
.L977:
	addl	%ebx, %ebx
	addq	$1, %r14
	cmpq	$9, %r14
	je	.L1123
.L973:
	cmpb	$0, -1(%rdi,%r14)
	je	.L977
	movl	$8, %ecx
	subl	%r14d, %ecx
	movl	$1, %r15d
	sall	%cl, %r15d
	subl	$1, %r15d
	movl	%r14d, %r10d
	sall	$8, %r10d
	movl	$0, %ebp
	jmp	.L975
.L1123:
	movq	8(%rsp), %r10
	movl	40(%rsp), %eax
	movzbl	48(%rsp), %r9d
	movq	72(%rsp), %rdx
	movl	160(%rsp), %r15d
.L971:
	movzbl	%r9b, %ecx
	negq	%rcx
	andl	$520, %ecx
	addq	$8, %rcx
	movq	%rcx, 40(%rsp)
	movl	112(%rsp), %ecx
	movl	136(%rsp), %ebx
	leal	(%rcx,%rbx), %r14d
	cmpl	$0, 52(%rsp)
	je	.L978
	movl	$0, %ecx
	movl	$0, %r8d
	movl	$0, %r9d
	movl	$0, %r13d
	movl	$0, %ebp
	movq	%r10, 160(%rsp)
	movl	%r14d, 72(%rsp)
	jmp	.L991
.L1141:
	cmpl	$15, %ecx
	ja	.L1076
	movl	%ecx, %r9d
	movq	%rdx, %rsi
.L982:
	sall	$8, %r8d
	addq	$1, %rsi
	movzbl	-1(%rsi), %r10d
	orl	%r10d, %r8d
	addl	$8, %r9d
	cmpl	$15, %r9d
	jbe	.L982
	movl	$15, %r9d
	subl	%ecx, %r9d
	movl	%r9d, %esi
	shrl	$3, %esi
	addl	$1, %esi
	movl	%esi, %esi
	addq	%rsi, %rdx
	andl	$-8, %r9d
	leal	8(%rcx,%r9), %ebp
.L981:
	leal	-8(%rbp), %ecx
	movl	%r8d, %esi
	shrl	%cl, %esi
	movzbl	%sil, %ecx
	leaq	(%r12,%rcx,2), %rcx
	movq	40(%rsp), %rsi
	movzwl	(%rcx,%rsi), %esi
	movzwl	%si, %r10d
	testl	%r10d, %r10d
	je	.L983
	shrl	$8, %r10d
	movl	%ebp, %ecx
	subl	%r10d, %ecx
	movzbl	%sil, %r9d
.L984:
	movl	%r9d, %r13d
	andl	$15, %r13d
	shrl	$4, %r9d
	addl	$1, %r9d
	jmp	.L980
.L1076:
	movl	%ecx, %ebp
	jmp	.L981
.L983:
	leal	-1(%rbp), %ecx
	movl	%r8d, %esi
	shrl	%cl, %esi
	andl	$1, %esi
	movzbl	(%rdi), %r9d
	cmpl	%r9d, %esi
	jb	.L1077
	movl	%r10d, %r13d
.L986:
	addl	%r9d, %r13d
	addl	%r10d, %r9d
	leal	(%r9,%r9), %r10d
	addl	%esi, %esi
	movl	%ebp, %r9d
	subl	%ecx, %r9d
	subl	$1, %ecx
	movl	%r8d, %r14d
	shrl	%cl, %r14d
	andl	$1, %r14d
	orl	%r14d, %esi
	movl	%r9d, %r9d
	movzbl	(%rdi,%r9), %r9d
	movl	%esi, %r14d
	subl	%r10d, %r14d
	cmpl	%r9d, %r14d
	jnb	.L986
.L985:
	leal	15(%rsi,%r13), %esi
	subl	%r10d, %esi
	movzbl	(%rdi,%rsi), %r9d
	jmp	.L984
.L1077:
	movl	%r10d, %r13d
	jmp	.L985
.L988:
	addq	$1, %rsi
	cmpq	%rsi, %rbp
	je	.L1139
.L989:
	cmpl	%r15d, %esi
	jnb	.L988
	movzwl	(%r14), %eax
	movw	%ax, (%rbx,%rsi,2)
	jmp	.L988
.L1139:
	movl	8(%rsp), %eax
.L987:
	addl	%r10d, %r11d
	subl	%r10d, %r9d
	cmpl	%eax, %r11d
	jnb	.L1140
.L990:
	testl	%r9d, %r9d
	je	.L1141
.L980:
	movl	%eax, %r10d
	subl	%r11d, %r10d
	cmpl	%r9d, %r10d
	cmova	%r9d, %r10d
	testl	%r13d, %r13d
	je	.L987
	testq	%rbx, %rbx
	je	.L987
	movl	28(%rsp), %esi
	addl	%r11d, %esi
	testl	%r10d, %r10d
	je	.L987
	movl	%r13d, %ebp
	movq	32(%rsp), %r14
	leaq	(%r14,%rbp,2), %r14
	movslq	%esi, %rsi
	movl	%r10d, %ebp
	addq	%rsi, %rbp
	movl	%eax, 8(%rsp)
	jmp	.L989
.L1140:
	movl	48(%rsp), %ebp
	addl	$1, %ebp
	cmpl	%ebp, 52(%rsp)
	je	.L1142
.L991:
	movl	72(%rsp), %ebx
	leal	0(%rbp,%rbx), %esi
	movl	$0, %ebx
	movl	56(%rsp), %r14d
	cmpl	%r14d, %esi
	jl	.L979
	movl	96(%rsp), %r11d
	cmpl	%r11d, %esi
	jge	.L979
	imull	%r15d, %esi
	leaq	cv_px(%rip), %rbx
	leaq	(%rbx,%rsi,2), %rbx
.L979:
	movl	$0, %r11d
	movl	%ebp, 48(%rsp)
	jmp	.L990
.L1142:
	movq	160(%rsp), %r10
.L978:
	movl	128(%rsp), %eax
	movl	28(%rsp), %edi
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	movl	%eax, 128(%rsp)
	movl	104(%rsp), %eax
	movl	112(%rsp), %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	movl	%eax, 104(%rsp)
	movzbl	6(%r10), %eax
	addl	%edi, %eax
	movl	116(%rsp), %edi
	cmpl	%eax, %edi
	cmovge	%edi, %eax
	movl	%eax, 116(%rsp)
	movzbl	7(%r10), %eax
	addl	%ecx, %eax
	movl	120(%rsp), %edi
	cmpl	%eax, %edi
	cmovge	%edi, %eax
	movl	%eax, 120(%rsp)
.L969:
	movzwl	2(%r10), %eax
	addl	%eax, 64(%rsp)
	addq	$1, 88(%rsp)
	movq	88(%rsp), %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L1143
	movl	60(%rsp), %esi
.L998:
	movzbl	%al, %edi
	movl	%edi, 60(%rsp)
	leal	-97(%rdi), %eax
	cmpl	$25, %eax
	ja	.L964
	movq	16(%rsp), %rax
	cmpb	$96, 3(%rax)
	ja	.L964
	subl	$32, %edi
	movl	%edi, 60(%rsp)
.L964:
	testl	%esi, %esi
	jne	.L1144
.L965:
	movq	16(%rsp), %r14
	movq	8(%r14), %rbx
	movl	60(%rsp), %esi
	movq	%r14, %rdi
	call	glyph
	movl	%eax, %eax
	leaq	(%rbx,%rax,8), %r10
	movzbl	48(%r14), %esi
	testb	%sil, %sil
	je	.L966
	movzwl	(%r10), %eax
	cmpw	%ax, 8(%r10)
	je	.L966
	movl	152(%rsp), %ebx
	movl	%ebx, %edx
	negl	%edx
	movl	64(%rsp), %edi
	andl	%edi, %edx
	movl	%edx, %eax
	subl	%edi, %eax
	movl	100(%rsp), %edi
	subl	%edi, %eax
	movl	%eax, %edi
	negl	%edi
	cmovs	%eax, %edi
	addl	%ebx, %eax
	movl	%eax, %ecx
	negl	%ecx
	cmovns	%ecx, %eax
	leal	(%rdx,%rbx), %ecx
	cmpl	%eax, %edi
	cmovg	%ecx, %edx
	movl	$4, %ecx
	subl	%esi, %ecx
	movl	%edx, %edi
	shrl	%cl, %edi
	movl	$-1, %eax
	movl	%esi, %ecx
	sall	%cl, %eax
	notl	%eax
	andl	%eax, %edi
	leaq	(%r10,%rdi,8), %r10
	jmp	.L968
.L970:
	movq	16(%rsp), %rdi
	movq	16(%rdi), %rdx
	movzwl	(%r10), %ecx
	movzbl	7(%r10), %r14d
	movzbl	%al, %eax
	movl	112(%rsp), %edi
	movl	136(%rsp), %ebx
	leal	(%rdi,%rbx), %r13d
	testl	%r14d, %r14d
	je	.L978
	movl	$0, %ebp
	movl	$0, %edi
	movl	28(%rsp), %ebx
	addl	%eax, %ebx
	leaq	(%rdx,%rcx), %r11
	movq	%r10, 40(%rsp)
	movl	%eax, %ecx
	movl	56(%rsp), %edx
	jmp	.L997
.L992:
	addl	%ecx, %ebp
.L994:
	addl	$1, %edi
	cmpl	%edi, %r14d
	je	.L1145
.L997:
	leal	(%rdi,%r13), %r9d
	cmpl	%edx, %r9d
	jl	.L992
	movl	96(%rsp), %eax
	cmpl	%eax, %r9d
	jge	.L992
	imull	%r15d, %r9d
	movl	28(%rsp), %eax
	movl	%eax, %r8d
	movl	%ebp, %r10d
	subl	%eax, %r10d
	movl	%ecx, %esi
	movl	%edx, 8(%rsp)
	jmp	.L996
.L995:
	addl	$1, %r8d
	cmpl	%r8d, %ebx
	je	.L1146
.L996:
	leal	(%r10,%r8), %ecx
	movl	%ecx, %eax
	shrl	%eax
	movl	%eax, %eax
	movzbl	(%r11,%rax), %eax
	xorl	$1, %ecx
	andl	$1, %ecx
	sall	$2, %ecx
	sarl	%cl, %eax
	andl	$15, %eax
	je	.L995
	cmpl	%r15d, %r8d
	jnb	.L995
	movslq	%r8d, %rcx
	addq	%r9, %rcx
	movl	%eax, %eax
	movq	32(%rsp), %rdx
	movzwl	(%rdx,%rax,2), %eax
	leaq	cv_px(%rip), %rdx
	movw	%ax, (%rdx,%rcx,2)
	jmp	.L995
.L1146:
	movl	%esi, %ecx
	movl	8(%rsp), %edx
	addl	%esi, %ebp
	jmp	.L994
.L1145:
	movq	40(%rsp), %r10
	jmp	.L978
.L1143:
	movl	128(%rsp), %ebp
	movl	96(%rsp), %r15d
	movl	116(%rsp), %eax
	cmpl	%eax, %ebp
	jge	.L949
	testl	%ebp, %ebp
	js	.L999
	cmpl	%eax, 172(%rsp)
	jl	.L999
	movl	104(%rsp), %eax
	movl	136(%rsp), %edi
	addl	%edi, %eax
	movl	56(%rsp), %ebx
	cmpl	%ebx, %eax
	jl	.L999
	movl	120(%rsp), %eax
	addl	%edi, %eax
	cmpl	%r15d, %eax
	jle	.L1000
.L999:
	orl	$2, 376(%rsp)
.L1000:
	movl	120(%rsp), %ecx
	movl	136(%rsp), %eax
	addl	%eax, %ecx
	movl	104(%rsp), %esi
	addl	%eax, %esi
	movl	376(%rsp), %r9d
	movq	80(%rsp), %r8
	movl	116(%rsp), %edx
	movl	%ebp, %edi
	call	hk_text
	jmp	.L949
.L1134:
	movl	%eax, %edx
	shrl	$31, %edx
	addl	%edx, %eax
	sarl	%eax
	jmp	.L1002
.L1158:
	movl	%ebp, %edx
	movq	16(%rsp), %rdi
	call	kern
	addl	%eax, %r14d
	jmp	.L1003
.L1159:
	testl	%edi, %edi
	je	.L1009
	movl	%edi, %r10d
	movl	$0, %edx
	leaq	cr_gbuf(%rip), %r8
.L1010:
	movl	%edx, %ecx
	shrl	%ecx
	movl	%ecx, %ecx
	movq	136(%rsp), %rdi
	movzbl	(%rdi,%rcx), %edi
	movl	%edx, %ecx
	xorl	$1, %ecx
	andl	$1, %ecx
	sall	$2, %ecx
	sarl	%cl, %edi
	movl	%edi, %ecx
	andl	$15, %ecx
	movb	%cl, (%r8,%rdx)
	addq	$1, %rdx
	cmpq	%r10, %rdx
	jne	.L1010
	jmp	.L1009
.L1081:
	movl	$0, %edx
.L1011:
	movl	%edx, %edx
	negq	%rdx
	andl	$520, %edx
	leaq	cr_hc(%rip), %rcx
	leaq	8(%rcx,%rdx), %rdi
	movq	%rdi, 144(%rsp)
	jmp	.L1013
.L1147:
	addl	$1, %r13d
	addl	$1, %edi
	addl	$1, %edx
	movzbl	-1(%r8,%r14), %eax
	cmpl	%eax, %r13d
	jnb	.L1019
.L1017:
	movl	%edi, %ebx
	sall	%cl, %ebx
	leal	(%rbx,%r15), %eax
	movl	%edx, %ebp
.L1016:
	movl	%eax, %esi
	addq	%r10, %rsi
	movzbl	(%r8,%rbp), %r9d
	orl	%r12d, %r9d
	movw	%r9w, 8(%r11,%rsi,2)
	movl	%eax, %esi
	subl	$1, %eax
	cmpl	%esi, %ebx
	jne	.L1016
	jmp	.L1147
.L1019:
	addl	%edi, %edi
	addq	$1, %r14
	cmpq	$9, %r14
	je	.L1124
.L1015:
	cmpb	$0, -1(%r8,%r14)
	je	.L1019
	movl	$8, %ecx
	subl	%r14d, %ecx
	movl	$1, %r15d
	sall	%cl, %r15d
	subl	$1, %r15d
	movl	%r14d, %r12d
	sall	$8, %r12d
	movl	$0, %r13d
	jmp	.L1017
.L1124:
	movl	152(%rsp), %ebp
	movl	160(%rsp), %r15d
	movl	172(%rsp), %ebx
	movl	184(%rsp), %r9d
	movl	188(%rsp), %eax
	movl	192(%rsp), %esi
	movl	196(%rsp), %r14d
	movq	200(%rsp), %r13
.L1013:
	movq	16(%rsp), %rdi
	movq	56(%rdi), %rdi
	movl	$0, %r11d
	movl	$0, %edx
	movl	$0, %r12d
	leaq	cr_gbuf(%rip), %r10
	cmpl	$0, 168(%rsp)
	je	.L1009
	movl	%ebp, 152(%rsp)
	movl	%r15d, 160(%rsp)
	movl	%ebx, 172(%rsp)
	movl	%r9d, %r15d
	movl	%eax, 184(%rsp)
	movq	%rdi, %rax
	movl	%r11d, %ecx
	movl	168(%rsp), %r11d
	jmp	.L1020
.L1022:
	leal	-1(%rbp), %ecx
	movl	%edx, %edi
	shrl	%cl, %edi
	andl	$1, %edi
	movzbl	(%rax), %r8d
	cmpl	%r8d, %edi
	jb	.L1083
	movl	%r9d, %ebx
	movl	%r15d, 168(%rsp)
.L1025:
	addl	%r8d, %ebx
	addl	%r9d, %r8d
	leal	(%r8,%r8), %r9d
	leal	(%rdi,%rdi), %r15d
	movl	%ebp, %r8d
	subl	%ecx, %r8d
	subl	$1, %ecx
	movl	%edx, %edi
	shrl	%cl, %edi
	andl	$1, %edi
	orl	%r15d, %edi
	movl	%r8d, %r8d
	movzbl	(%rax,%r8), %r8d
	movl	%edi, %r15d
	subl	%r9d, %r15d
	cmpl	%r8d, %r15d
	jnb	.L1025
	movl	168(%rsp), %r15d
.L1024:
	leal	15(%rdi,%rbx), %edi
	subl	%r9d, %edi
	movzbl	(%rax,%rdi), %edi
	jmp	.L1023
.L1083:
	movl	%r9d, %ebx
	jmp	.L1024
.L1089:
	cmpl	%r11d, %edi
	jnb	.L1127
	movl	%edi, %r12d
.L1020:
	movl	%ecx, %r8d
	movq	136(%rsp), %rdi
	movl	%ecx, %ebp
	cmpl	$15, %ecx
	ja	.L1028
.L1021:
	sall	$8, %edx
	addq	$1, %rdi
	movzbl	-1(%rdi), %r9d
	orl	%r9d, %edx
	addl	$8, %r8d
	cmpl	$15, %r8d
	jbe	.L1021
	movl	$15, %r8d
	subl	%ecx, %r8d
	movl	%r8d, %edi
	shrl	$3, %edi
	addl	$1, %edi
	movl	%edi, %edi
	addq	%rdi, 136(%rsp)
	andl	$-8, %r8d
	leal	8(%rcx,%r8), %ebp
.L1028:
	leal	-8(%rbp), %ecx
	movl	%edx, %edi
	shrl	%cl, %edi
	movzbl	%dil, %ecx
	movq	144(%rsp), %rdi
	movzwl	(%rdi,%rcx,2), %edi
	movzwl	%di, %r9d
	testl	%r9d, %r9d
	je	.L1022
	shrl	$8, %r9d
	movl	%ebp, %ecx
	subl	%r9d, %ecx
	movzbl	%dil, %edi
.L1023:
	movl	%edi, %r9d
	andl	$15, %r9d
	shrl	$4, %edi
	movl	%edi, %r8d
	cmpl	%r11d, %r12d
	jnb	.L1126
	movl	%r12d, %edi
	leal	1(%r8,%r12), %ebx
.L1026:
	movl	%edi, %r8d
	addl	$1, %edi
	movl	%r8d, %r8d
	movb	%r9b, (%r10,%r8)
	cmpl	%edi, %ebx
	je	.L1089
	cmpl	%r11d, %edi
	jb	.L1026
	jmp	.L1089
.L1126:
	movl	152(%rsp), %ebp
	movl	172(%rsp), %ebx
	movl	%r15d, %r9d
	movl	160(%rsp), %r15d
	movl	184(%rsp), %eax
.L1009:
	movq	8(%rsp), %rdi
	movq	%rdi, cr_gbuf_g(%rip)
.L1007:
	cmpl	$4096, 28(%rsp)
	jne	.L1070
	cmpl	$4096, 40(%rsp)
	jne	.L1070
	movl	64(%rsp), %edi
	leal	128(%rdi), %edx
	sarl	$8, %edx
	movl	%edx, 100(%rsp)
	leal	128(%r15), %edx
	sarl	$8, %edx
	cmpl	$0, 88(%rsp)
	jle	.L1005
	movzbl	52(%rsp), %esi
	movl	176(%rsp), %edi
	addl	%edx, %edi
	movl	%edi, 52(%rsp)
	movl	$0, %edi
	movzwl	112(%rsp), %ebx
	movl	%ebx, 104(%rsp)
	movl	%r14d, %ebx
	movl	%edi, %r14d
	movq	%r13, 120(%rsp)
	movl	%edx, %r13d
	movl	%r15d, %ecx
	movl	%eax, %r15d
	movl	%ebx, %edi
	jmp	.L1032
.L1127:
	movl	152(%rsp), %ebp
	movl	172(%rsp), %ebx
	movl	%r15d, %r9d
	movl	160(%rsp), %r15d
	movl	184(%rsp), %eax
	jmp	.L1009
.L1030:
	addq	$1, %rbx
	cmpl	%ebx, 116(%rsp)
	jle	.L1148
.L1031:
	movzbl	(%r12,%rbx), %eax
	testb	%al, %al
	je	.L1030
	movzbl	%al, %eax
	movq	128(%rsp), %rdi
	movzbl	(%rdi,%rax), %eax
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movzbl	%al, %eax
	addl	%eax, %ecx
	movl	100(%rsp), %eax
	leal	(%rax,%rbx), %edi
	movl	104(%rsp), %edx
	movl	88(%rsp), %esi
	call	cr_blend
	jmp	.L1030
.L1148:
	movl	%ebp, %ecx
	movl	144(%rsp), %ebp
	movl	%r13d, %edi
	movl	168(%rsp), %r13d
	movl	%r14d, %esi
	movl	136(%rsp), %r14d
.L1029:
	addl	$1, %r13d
	addl	%esi, %r14d
	movl	52(%rsp), %eax
	cmpl	%eax, %r13d
	je	.L1149
.L1032:
	movl	%r13d, 88(%rsp)
	cmpl	%r13d, 96(%rsp)
	jg	.L1029
	cmpl	%r13d, %r15d
	jle	.L1029
	movl	$0, %ebx
	movslq	%r14d, %r12
	leaq	cr_gbuf(%rip), %rax
	addq	%rax, %r12
	movl	%r14d, 136(%rsp)
	movl	%r13d, 168(%rsp)
	movl	%ebp, 144(%rsp)
	movl	%ecx, %ebp
	movl	%edi, %r13d
	movl	%esi, %r14d
	jmp	.L1031
.L1149:
	movl	%ecx, %r15d
	movl	%edi, %r14d
	movq	120(%rsp), %r13
	jmp	.L1005
.L1070:
	cmpl	%esi, %ebx
	movl	%esi, %edi
	cmovge	%ebx, %edi
	movl	%edi, 160(%rsp)
	movl	120(%rsp), %ecx
	cmpl	%ecx, %r9d
	movl	%ecx, %esi
	cmovle	%r9d, %esi
	subl	%edi, %esi
	leal	256(%rdi), %edx
	cmpl	%ecx, %r9d
	cmovle	%r9d, %ecx
	cmpl	$257, %esi
	movl	%edx, %ebx
	cmovl	%ecx, %ebx
	movl	%ebx, 120(%rsp)
	movl	104(%rsp), %edx
	movl	96(%rsp), %ecx
	cmpl	%ecx, %edx
	cmovge	%edx, %ecx
	movl	%ecx, 96(%rsp)
	movl	100(%rsp), %edx
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	%eax, 172(%rsp)
	cmpl	%ebx, %edi
	jge	.L1005
	cmpl	%eax, %ecx
	jge	.L1005
	sall	$8, %edi
	movl	%edi, %eax
	movl	%edi, %edx
	movl	64(%rsp), %r9d
	subl	%r9d, %edx
	sall	$4, %edx
	movl	%edx, 168(%rsp)
	leal	256(%rdi), %edi
	movl	%edi, 152(%rsp)
	movl	%eax, 144(%rsp)
	leaq	cr_cw(%rip), %rax
	movq	%rax, 104(%rsp)
	movl	$0, 100(%rsp)
	movq	%rax, %r11
	movl	28(%rsp), %ebx
	movl	%ebp, 184(%rsp)
	movl	%r15d, %r12d
	movl	116(%rsp), %ebp
	movq	%r13, 176(%rsp)
	jmp	.L1044
.L1151:
	testl	%esi, %esi
	jne	.L1041
	movw	%r8w, 0(%r13)
.L1041:
	cmpl	%r8d, %ebp
	jle	.L1130
	cmpl	$15, %esi
	jg	.L1150
	movl	%ecx, %edx
	sarl	$4, %edx
	addl	%r9d, %edx
	addl	%ebx, %ecx
	movl	%ecx, %eax
	sarl	$4, %eax
	addl	%r9d, %eax
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	cmpl	%edx, %r10d
	movl	%edx, %r12d
	cmovge	%r10d, %r12d
	subl	%r12d, %eax
	addl	$1, %r8d
	cmpl	%edx, %edi
	jle	.L1129
.L1039:
	testl	%eax, %eax
	jle	.L1151
	movslq	%esi, %r12
	addq	%r15, %r12
	movl	$256, %edx
	cmpl	%edx, %eax
	cmovle	%eax, %edx
	movw	%dx, 4(%r11,%r12,2)
	leal	1(%rsi), %esi
	jmp	.L1041
.L1150:
	movl	136(%rsp), %r12d
	jmp	.L1038
.L1086:
	movl	$0, %esi
	jmp	.L1038
.L1129:
	movl	136(%rsp), %r12d
.L1038:
	movslq	116(%rsp), %rax
	leaq	(%rax,%rax,8), %rax
	movw	%si, 2(%r11,%rax,4)
	addl	$1, 100(%rsp)
	movl	100(%rsp), %eax
	addl	$4096, 168(%rsp)
	addl	$256, 152(%rsp)
	addl	$256, 144(%rsp)
	addq	$36, 104(%rsp)
	movl	160(%rsp), %edi
	addl	%edi, %eax
	cmpl	%eax, 120(%rsp)
	jle	.L1152
.L1044:
	movl	144(%rsp), %ecx
	movl	%ecx, %r10d
	movl	152(%rsp), %edi
	movl	168(%rsp), %eax
	cltd
	idivl	%ebx
	testl	%eax, %eax
	movl	$0, %esi
	cmovns	%eax, %esi
	jle	.L1034
	movl	%ebx, %edx
	imull	%esi, %edx
	movl	%edx, %eax
	sarl	$4, %eax
	addl	%r9d, %eax
	cmpl	%eax, %ecx
	jge	.L1035
	subl	%ebx, %edx
.L1037:
	subl	$1, %esi
	testl	%esi, %esi
	jle	.L1036
	movl	%edx, %eax
	sarl	$4, %eax
	addl	%r9d, %eax
	subl	%ebx, %edx
	cmpl	%eax, %r10d
	jl	.L1037
.L1035:
	movl	100(%rsp), %eax
	movl	%eax, 116(%rsp)
	movq	104(%rsp), %rax
	movw	%si, (%rax)
	cmpl	%esi, %ebp
	jg	.L1067
	movl	$0, %esi
	jmp	.L1038
.L1130:
	movl	136(%rsp), %r12d
	jmp	.L1038
.L1152:
	movl	184(%rsp), %ebp
	movl	%r12d, %r15d
	movq	176(%rsp), %r13
	movl	96(%rsp), %eax
	sall	$8, %eax
	subl	%r12d, %eax
	sall	$4, %eax
	movl	%eax, 100(%rsp)
	movl	40(%rsp), %r12d
	movl	%ebp, %edi
	movl	%r14d, %esi
	movl	88(%rsp), %r14d
	movq	%r13, %rcx
	jmp	.L1062
.L1048:
	cmpl	%edx, %r14d
	jle	.L1047
	cmpl	$15, %r13d
	jg	.L1047
	movl	%r9d, %r8d
	sarl	$4, %r8d
	addl	%r15d, %r8d
	addl	%r12d, %r9d
	movl	%r9d, %eax
	sarl	$4, %eax
	addl	%r15d, %eax
	cmpl	%r11d, %eax
	cmovg	%r11d, %eax
	cmpl	%r8d, %r10d
	movl	%r8d, %ebx
	cmovge	%r10d, %ebx
	subl	%ebx, %eax
	addl	$1, %edx
	cmpl	%r8d, %r11d
	jle	.L1047
.L1051:
	testl	%eax, %eax
	jle	.L1048
	leal	-1(%rdx), %r8d
	testl	%r13d, %r13d
	cmove	%r8d, %ebp
	movslq	%r13d, %rbx
	movl	$256, %r8d
	cmpl	%r8d, %eax
	cmovle	%eax, %r8d
	movl	%r8d, 208(%rsp,%rbx,4)
	leal	1(%r13), %r13d
	jmp	.L1048
.L1047:
	testl	%r13d, %r13d
	jne	.L1153
.L1055:
	addl	$1, 96(%rsp)
	movl	96(%rsp), %eax
	addl	$4096, 100(%rsp)
	cmpl	%eax, 172(%rsp)
	jle	.L1154
.L1062:
	movl	96(%rsp), %r10d
	sall	$8, %r10d
	leal	256(%r10), %r11d
	movl	100(%rsp), %eax
	cltd
	idivl	%r12d
	testl	%eax, %eax
	movl	$0, %edx
	cmovns	%eax, %edx
	jle	.L1045
	movl	%r12d, %r8d
	imull	%edx, %r8d
	movl	%r8d, %eax
	sarl	$4, %eax
	addl	%r15d, %eax
	cmpl	%r10d, %eax
	jle	.L1045
	subl	%r12d, %r8d
.L1046:
	subl	$1, %edx
	testl	%edx, %edx
	jle	.L1045
	movl	%r8d, %eax
	sarl	$4, %eax
	addl	%r15d, %eax
	subl	%r12d, %r8d
	cmpl	%r10d, %eax
	jg	.L1046
.L1045:
	cmpl	%edx, %r14d
	jle	.L1055
	movl	%r12d, %r9d
	imull	%edx, %r9d
	movl	%r9d, %r8d
	sarl	$4, %r8d
	addl	%r15d, %r8d
	addl	$1, %edx
	addl	%r12d, %r9d
	movl	%r9d, %eax
	sarl	$4, %eax
	addl	%r15d, %eax
	cmpl	%r11d, %eax
	cmovg	%r11d, %eax
	cmpl	%r8d, %r10d
	movl	%r8d, %ebx
	cmovge	%r10d, %ebx
	subl	%ebx, %eax
	cmpl	%r8d, %r11d
	jle	.L1055
	movl	$0, %ebp
	movl	$0, %r13d
	jmp	.L1051
.L1153:
	movzbl	52(%rsp), %eax
	imull	%ebp, %eax
	cltq
	movq	%rax, 88(%rsp)
	leaq	208(%rsp), %rax
	movslq	%r13d, %rdx
	leaq	(%rax,%rdx,4), %rbx
	leaq	cr_cw(%rip), %rbp
	movl	160(%rsp), %edx
	movl	%r12d, 104(%rsp)
	movl	%edi, 116(%rsp)
	movl	%r15d, 136(%rsp)
	movl	%r14d, 168(%rsp)
	movq	%rax, %r14
	movl	%esi, 144(%rsp)
	movq	%rcx, 152(%rsp)
	movl	%edx, %r12d
	jmp	.L1061
.L1087:
	movl	$0, %ecx
.L1057:
	imull	(%r10), %ecx
	addl	%ecx, %r11d
	addq	$4, %r10
	addq	%r15, %rdi
	cmpq	%rbx, %r10
	je	.L1155
.L1059:
	testl	%r8d, %r8d
	jle	.L1087
	movl	$0, %eax
	movl	$0, %ecx
.L1058:
	movzbl	(%rdi,%rax), %edx
	movzwl	4(%r9,%rax,2), %esi
	imull	%esi, %edx
	addl	%edx, %ecx
	addq	$1, %rax
	cmpl	%eax, %r8d
	jg	.L1058
	jmp	.L1057
.L1155:
	addl	$32768, %r11d
	movl	%r11d, %eax
	shrl	$16, %eax
	cmpl	$1048575, %r11d
	ja	.L1088
	testl	%eax, %eax
	je	.L1056
.L1060:
	movl	%eax, %eax
	movq	128(%rsp), %rdi
	movzbl	(%rdi,%rax), %eax
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movzbl	%al, %eax
	addl	%eax, %ecx
	movzwl	112(%rsp), %edx
	movl	96(%rsp), %esi
	movl	%r12d, %edi
	call	cr_blend
.L1056:
	addl	$1, %r12d
	addq	$36, %rbp
	cmpl	%r12d, 120(%rsp)
	jle	.L1156
.L1061:
	movq	%rbp, %r9
	movzwl	2(%rbp), %r8d
	movzwl	0(%rbp), %edi
	testl	%r13d, %r13d
	jle	.L1056
	movzbl	52(%rsp), %r15d
	movzwl	%di, %edi
	movq	88(%rsp), %rax
	addq	%rax, %rdi
	leaq	cr_gbuf(%rip), %rax
	addq	%rax, %rdi
	movq	%r14, %r10
	movl	$0, %r11d
	jmp	.L1059
.L1088:
	movl	$15, %eax
	jmp	.L1060
.L1156:
	movl	104(%rsp), %r12d
	movl	116(%rsp), %edi
	movl	136(%rsp), %r15d
	movl	168(%rsp), %r14d
	movl	144(%rsp), %esi
	movq	152(%rsp), %rcx
	jmp	.L1055
.L1154:
	movl	%edi, %ebp
	movl	%esi, %r14d
	movq	%rcx, %r13
.L1005:
	movl	64(%rsp), %edi
	leal	128(%rdi), %eax
	sarl	$8, %eax
	movl	48(%rsp), %ecx
	cmpl	%eax, %ecx
	cmovle	%ecx, %eax
	movl	%eax, 48(%rsp)
	leal	128(%r15), %eax
	sarl	$8, %eax
	movl	56(%rsp), %ebx
	cmpl	%eax, %ebx
	cmovle	%ebx, %eax
	movl	%eax, 56(%rsp)
	movq	8(%rsp), %rcx
	movzbl	6(%rcx), %eax
	movl	28(%rsp), %ebx
	imull	%ebx, %eax
	sarl	$4, %eax
	leal	128(%rdi,%rax), %eax
	sarl	$8, %eax
	movl	32(%rsp), %edi
	cmpl	%eax, %edi
	cmovge	%edi, %eax
	movl	%eax, 32(%rsp)
	movzbl	7(%rcx), %eax
	movl	40(%rsp), %edi
	imull	%edi, %eax
	sarl	$4, %eax
	leal	128(%r15,%rax), %eax
	sarl	$8, %eax
	movl	60(%rsp), %edi
	cmpl	%eax, %edi
	cmovge	%edi, %eax
	movl	%eax, 60(%rsp)
.L1004:
	movq	8(%rsp), %rax
	movzwl	2(%rax), %eax
	addl	%eax, %r14d
	addq	$1, %r13
	movzbl	0(%r13), %ebx
	testb	%bl, %bl
	je	.L1157
.L1063:
	movl	%ebp, %esi
	movzbl	%bl, %ebp
	testl	%esi, %esi
	jne	.L1158
.L1003:
	movl	%ebp, %esi
	movq	16(%rsp), %r15
	movq	%r15, %rdi
	call	cr_glyph_of
	movq	%rax, %rbx
	movq	%rax, 8(%rsp)
	movzbl	6(%rax), %eax
	movb	%al, 52(%rsp)
	testb	%al, %al
	je	.L1004
	movl	28(%rsp), %ecx
	movl	%ecx, %edx
	imull	%r14d, %edx
	sarl	$8, %edx
	movl	68(%rsp), %esi
	addl	%esi, %edx
	movsbl	4(%rbx), %eax
	imull	%ecx, %eax
	sarl	$4, %eax
	leal	(%rdx,%rax), %edi
	movl	%edi, 64(%rsp)
	movzbl	5(%rbx), %eax
	movzbl	1(%r15), %edx
	subl	%edx, %eax
	movl	40(%rsp), %esi
	imull	%esi, %eax
	sarl	$4, %eax
	movl	72(%rsp), %r15d
	addl	%eax, %r15d
	movzbl	7(%rbx), %r12d
	movzbl	%r12b, %ebx
	movl	%ebx, 88(%rsp)
	imull	%ebx, %esi
	movl	%esi, %eax
	sarl	$4, %eax
	leal	255(%r15,%rax), %eax
	movl	%eax, %ebx
	sarl	$8, %ebx
	movl	%ebx, 100(%rsp)
	call	cr_row0
	movl	%eax, 96(%rsp)
	cmpl	%eax, %ebx
	jle	.L1005
	movl	%r15d, %ebx
	sarl	$8, %ebx
	movl	%ebx, 104(%rsp)
	call	cr_row1
	cmpl	%eax, %ebx
	jge	.L1005
	movzbl	52(%rsp), %ebx
	movl	%ebx, 116(%rsp)
	movl	28(%rsp), %edx
	imull	%ebx, %edx
	sarl	$4, %edx
	movl	64(%rsp), %edi
	leal	255(%rdi,%rdx), %edx
	sarl	$8, %edx
	movl	%edx, %r9d
	movswl	cr_clip(%rip), %esi
	cmpl	%esi, %edx
	jle	.L1005
	movl	%edi, %ebx
	sarl	$8, %ebx
	movswl	4+cr_clip(%rip), %edi
	movl	%edi, 120(%rsp)
	cmpl	%edi, %ebx
	jge	.L1005
	cmpb	$0, 32+ux(%rip)
	leaq	CURVE_DARK(%rip), %rcx
	leaq	CURVE_LIGHT(%rip), %rdx
	cmove	%rcx, %rdx
	movq	%rdx, 128(%rsp)
	movzbl	%r12b, %ecx
	movl	%ecx, 176(%rsp)
	movzbl	52(%rsp), %edx
	movl	%edx, %edi
	imull	%ecx, %edi
	movl	%edi, 168(%rsp)
	cmpl	$8192, %edi
	ja	.L1005
	movq	8(%rsp), %rcx
	cmpq	cr_gbuf_g(%rip), %rcx
	je	.L1007
	movzwl	(%rcx), %edx
	movq	16(%rsp), %rcx
	addq	16(%rcx), %rdx
	movq	%rdx, 136(%rsp)
	movq	56(%rcx), %r8
	testq	%r8, %r8
	je	.L1159
	cmpq	%r8, cr_hc(%rip)
	je	.L1081
	movl	$1, %edx
	cmpq	520+cr_hc(%rip), %r8
	je	.L1011
	movzbl	cr_hc_next(%rip), %edx
	movzbl	%dl, %edi
	movl	%edi, 152(%rsp)
	movl	%edx, %ecx
	xorl	$1, %ecx
	movb	%cl, cr_hc_next(%rip)
	leaq	cr_hc(%rip), %r10
	movl	%edi, %edi
	movq	%rdi, %rcx
	salq	$6, %rcx
	addq	%rdi, %rcx
	movq	%r8, (%r10,%rcx,8)
	movzbl	%dl, %edx
	movq	%rdx, %rcx
	salq	$6, %rcx
	addq	%rdx, %rcx
	leaq	0(,%rcx,8), %rdi
	leaq	8(%r10,%rdi), %rcx
	movq	%rcx, 144(%rsp)
	movq	%rcx, %rdx
	leaq	520(%r10), %rcx
	addq	%rdi, %rcx
.L1014:
	movw	$0, (%rdx)
	addq	$2, %rdx
	cmpq	%rcx, %rdx
	jne	.L1014
	movl	$1, %r12d
	movl	$15, %edx
	movl	$0, %edi
	leaq	cr_hc(%rip), %r11
	movl	152(%rsp), %ecx
	movq	%rcx, %r10
	salq	$6, %r10
	addq	%r10, %rcx
	leaq	0(,%rcx,4), %r10
	movl	%ebp, 152(%rsp)
	movl	%r15d, 160(%rsp)
	movl	%ebx, 172(%rsp)
	movl	%r9d, 184(%rsp)
	movl	%eax, 188(%rsp)
	movl	%esi, 192(%rsp)
	movl	%r14d, 196(%rsp)
	movq	%r13, 200(%rsp)
	movq	%r12, %r14
	jmp	.L1015
.L1157:
	movl	48(%rsp), %r14d
	movl	32(%rsp), %eax
	cmpl	%eax, %r14d
	jge	.L949
	testl	%r14d, %r14d
	js	.L1064
	cmpl	%eax, cv_w(%rip)
	jl	.L1064
	movl	cv_oy(%rip), %eax
	movl	56(%rsp), %edi
	addl	%eax, %edi
	js	.L1064
	movl	60(%rsp), %edi
	addl	%edi, %eax
	cmpl	cv_h(%rip), %eax
	jle	.L1065
.L1064:
	orl	$2, 376(%rsp)
.L1065:
	movl	cv_oy(%rip), %eax
	movl	60(%rsp), %ecx
	addl	%eax, %ecx
	movl	56(%rsp), %esi
	addl	%eax, %esi
	movl	376(%rsp), %r9d
	movq	80(%rsp), %r8
	movl	32(%rsp), %edx
	movl	%r14d, %edi
	call	hk_text
.L949:
	movq	280(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1160
	movl	68(%rsp), %eax
	addq	$296, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1034:
	.cfi_restore_state
	movl	100(%rsp), %eax
	movl	%eax, 116(%rsp)
	movq	104(%rsp), %rax
	movw	$0, (%rax)
	jmp	.L1067
.L1036:
	movl	100(%rsp), %eax
	movl	%eax, 116(%rsp)
	movq	104(%rsp), %rax
	movw	%si, (%rax)
.L1067:
	movl	%ebx, %ecx
	imull	%esi, %ecx
	movl	%ecx, %edx
	sarl	$4, %edx
	addl	%r9d, %edx
	leal	1(%rsi), %r8d
	addl	%ebx, %ecx
	movl	%ecx, %eax
	sarl	$4, %eax
	addl	%r9d, %eax
	cmpl	%edi, %eax
	cmovg	%edi, %eax
	cmpl	%edx, %r10d
	movl	%edx, %esi
	cmovge	%r10d, %esi
	subl	%esi, %eax
	cmpl	%edx, %edi
	jle	.L1086
	movl	$0, %esi
	movslq	116(%rsp), %rdx
	leaq	(%rdx,%rdx,8), %rdx
	leaq	(%rdx,%rdx), %r15
	leaq	(%r11,%rdx,4), %r13
	movl	%r12d, 136(%rsp)
	jmp	.L1039
.L1160:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE124:
	.size	cr_text, .-cr_text
	.type	cr_text_fit, @function
cr_text_fit:
.LFB126:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	movl	%edi, 12(%rsp)
	movl	%esi, %r12d
	movl	%ecx, %ebx
	movl	%r8d, %ebp
	movl	%r9d, %r13d
	movl	144(%rsp), %r14d
	movl	152(%rsp), %r15d
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rdi
	movl	160(%rsp), %r9d
	movl	$48, %esi
	call	cr_fit
	negl	%eax
	sbbl	%eax, %eax
	andl	$9, %eax
	leaq	16(%rsp), %rdx
	pushq	%rax
	.cfi_def_cfa_offset 152
	movzwl	%r15w, %r15d
	pushq	%r15
	.cfi_def_cfa_offset 160
	movzwl	%r14w, %r14d
	pushq	%r14
	.cfi_def_cfa_offset 168
	pushq	$4096
	.cfi_def_cfa_offset 176
	movl	%r13d, %r9d
	movl	%ebp, %r8d
	movl	%ebx, %ecx
	movl	%r12d, %esi
	movl	44(%rsp), %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 144
	movq	72(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1166
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1166:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE126:
	.size	cr_text_fit, .-cr_text_fit
	.type	cr_header, @function
cr_header:
.LFB136:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, %rbx
	movzbl	3(%rdi), %r13d
	testb	%r13b, %r13b
	je	.L1168
	cmpb	$0, 2(%rdi)
	je	.L1167
	cmpb	$1, %r13b
	jne	.L1170
	movl	$-88, %ebp
	leaq	ux(%rip), %r12
.L1171:
	movl	%ebp, %edx
	negl	%edx
	cmovs	%ebp, %edx
	movl	$96, %eax
	subl	%edx, %eax
	leal	(%rax,%rax,4), %edx
	leal	(%rax,%rdx,2), %eax
	movslq	%eax, %rdx
	imulq	$715827883, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$31, %eax
	subl	%eax, %edx
	leal	184(%rbp), %esi
	movzwl	6(%r12), %r8d
	movl	$16, %ecx
	movl	$128, %edi
	call	cr_frect
	addl	$16, %ebp
	cmpl	$104, %ebp
	jne	.L1171
.L1172:
	movl	$12, %r14d
	movl	$4224, 12(%rsp)
	movl	$26, %r15d
	jmp	.L1185
.L1170:
	cmpb	$2, %r13b
	jne	.L1173
	movzwl	22+ux(%rip), %ecx
	movl	$88, %edx
	movl	$192, %esi
	movl	$224, %edi
	call	cr_disc
.L1174:
	movl	$12, %r14d
	movl	$4224, 12(%rsp)
	movl	$26, %r15d
	jmp	.L1185
.L1173:
	cmpb	$3, %r13b
	jne	.L1172
	movzwl	6+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 88
	pushq	$0
	.cfi_def_cfa_offset 96
	pushq	$0
	.cfi_def_cfa_offset 104
	pushq	$0
	.cfi_def_cfa_offset 112
	movl	$54215, %r9d
	movl	$3129, %r8d
	movl	$32, %ecx
	movl	$80, %edx
	movl	$192, %esi
	movl	$224, %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 80
	jmp	.L1174
.L1193:
	leaq	31(%rbx), %rdi
	movl	$1, %edx
	movl	$12, %esi
	call	cr_tw
	sarl	$8, %eax
	leal	8(%r12,%rax), %r12d
	jmp	.L1177
.L1194:
	movzbl	5(%rbx), %edi
	movl	$63389, %esi
	call	cr_rgb
	movl	%eax, %ecx
	leaq	7(%rbx), %rdx
	leal	8(%r15), %edi
	sall	$8, %edi
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	$236, %eax
	subl	%r12d, %eax
	subl	%r15d, %eax
	subl	$10, %eax
	sall	$8, %eax
	pushq	%rax
	.cfi_def_cfa_offset 96
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 104
	movzwl	%cx, %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	movl	$0, %r9d
	movl	$1, %r8d
	movl	%r14d, %ecx
	movl	44(%rsp), %esi
	call	cr_text_fit
	addq	$32, %rsp
	.cfi_def_cfa_offset 80
	jmp	.L1178
.L1195:
	movzbl	%sil, %esi
	leal	-20(%rbp), %edi
	call	cr_battery
	subl	$26, %ebp
	jmp	.L1179
.L1196:
	movzwl	120(%rbx), %edx
	movzwl	%dx, %eax
	sall	$8, %eax
	cmpw	$256, %dx
	movl	$65536, %edx
	cmovb	%eax, %edx
	movl	%edx, 12(%rsp)
	call	cr_row0
	cmpl	$23, %eax
	jg	.L1167
	movl	$0, %r13d
	movl	$3435973837, %r15d
	leaq	ux(%rip), %r14
.L1183:
	movl	%r13d, %r12d
	imulq	%r15, %r12
	shrq	$35, %r12
	movl	%r12d, %edi
	call	cr_sin
	movl	%eax, %ebp
	leal	16384(%r12), %edi
	call	cr_sin
	movzwl	14(%r14), %ecx
	sall	$7, %ebp
	sarl	$14, %ebp
	leal	192(%rbp), %esi
	sall	$7, %eax
	movl	%eax, %edi
	sarl	$14, %edi
	addl	$3664, %edi
	movl	$20, %edx
	call	cr_disc
	addl	$65536, %r13d
	cmpl	$655360, %r13d
	jne	.L1183
	movl	12(%rsp), %r9d
	testl	%r9d, %r9d
	je	.L1167
	cmpb	$1, 119(%rbx)
	sbbl	%ecx, %ecx
	andl	$-32, %ecx
	addl	$80, %ecx
	pushq	$57797
	.cfi_def_cfa_offset 88
	pushq	$0
	.cfi_def_cfa_offset 96
	pushq	$0
	.cfi_def_cfa_offset 104
	pushq	$0
	.cfi_def_cfa_offset 112
	movl	$49152, %r8d
	movl	$128, %edx
	movl	$192, %esi
	movl	$3664, %edi
	call	cr_arc
	addq	$32, %rsp
	.cfi_def_cfa_offset 80
	jmp	.L1167
.L1168:
	cmpb	$0, 2(%rdi)
	je	.L1167
	movl	$15, %r14d
	movl	$4608, 12(%rsp)
	movl	$0, %r15d
.L1185:
	movzbl	118(%rbx), %eax
	negb	%al
	sbbl	%r12d, %r12d
	andl	$22, %r12d
	cmpb	$1, 118(%rbx)
	sbbl	%ebp, %ebp
	andl	$22, %ebp
	addl	$214, %ebp
	cmpb	$-1, 4(%rbx)
	je	.L1176
	addl	$26, %r12d
.L1176:
	cmpb	$0, 31(%rbx)
	jne	.L1193
.L1177:
	cmpb	$0, 7(%rbx)
	jne	.L1194
.L1178:
	movzbl	4(%rbx), %esi
	cmpb	$-1, %sil
	jne	.L1195
.L1179:
	cmpb	$0, 31(%rbx)
	je	.L1180
	movzwl	ux(%rip), %r12d
	movl	$63389, %esi
	testb	%r13b, %r13b
	je	.L1181
	movzwl	10+ux(%rip), %esi
.L1181:
	movzbl	6(%rbx), %edi
	call	cr_rgb
	leaq	31(%rbx), %rdx
	movl	%ebp, %edi
	sall	$8, %edi
	pushq	$0
	.cfi_def_cfa_offset 88
	pushq	%r12
	.cfi_def_cfa_offset 96
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 104
	pushq	$4096
	.cfi_def_cfa_offset 112
	movl	$2, %r9d
	movl	$1, %r8d
	movl	%r14d, %ecx
	movl	44(%rsp), %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 80
.L1180:
	cmpb	$0, 118(%rbx)
	jne	.L1196
.L1167:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE136:
	.size	cr_header, .-cr_header
	.type	cr_name, @function
cr_name:
.LFB137:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbx
	movl	%esi, %r14d
	movl	%edx, 16(%rsp)
	movl	%ecx, %r13d
	movl	%r8d, %r12d
	movl	%r9d, %r15d
	imull	$58, %ecx, %eax
	addl	$50, %eax
	movl	%eax, %eax
	imulq	$1374389535, %rax, %rax
	shrq	$37, %rax
	movq	%rax, 8(%rsp)
	imull	$38, %ecx, %eax
	addl	$50, %eax
	movl	%eax, %eax
	imulq	$1374389535, %rax, %rax
	shrq	$37, %rax
	movq	%rax, 24(%rsp)
	movl	$1, %edx
	movl	%ecx, %esi
	call	cr_tw
	movl	%eax, 4(%rsp)
	movl	$0, 20(%rsp)
	movl	$0, %ebp
	cmpb	$0, 4(%rbx)
	jne	.L1207
.L1198:
	movl	4(%rsp), %eax
	addl	%eax, %ebp
	movl	$0, %eax
	cmpb	$0, 10(%rbx)
	jne	.L1208
.L1199:
	addl	%eax, %ebp
	testl	%ebp, %ebp
	jle	.L1197
	movl	%r12d, %eax
	sall	$8, %eax
	movl	$4096, %r12d
	cmpl	%ebp, %eax
	jge	.L1201
	sall	$12, %eax
	cltd
	idivl	%ebp
	movl	%eax, %r12d
.L1201:
	movzbl	18(%rbx), %edi
	movl	$63389, %esi
	call	cr_rgb
	movl	%eax, %edx
	imull	%r15d, %r12d
	sarl	$12, %r12d
	movl	$300, %eax
	cmpl	%eax, %r12d
	cmovl	%eax, %r12d
	movl	%ebp, %edi
	shrl	$31, %edi
	addl	%ebp, %edi
	sarl	%edi
	negl	%edi
	leal	(%rdi,%r14), %r15d
	movzwl	%dx, %ebp
	imull	%r12d, %edi
	sarl	$12, %edi
	addl	%r14d, %edi
	pushq	$0
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	pushq	%rbp
	.cfi_def_cfa_offset 120
	pushq	%r12
	.cfi_def_cfa_offset 128
	movl	$0, %r9d
	movl	$1, %r8d
	movl	%r13d, %ecx
	movq	%rbx, %rdx
	movl	48(%rsp), %esi
	call	cr_text
	movl	36(%rsp), %eax
	leal	512(%rax,%r15), %r15d
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	cmpb	$0, 4(%rbx)
	jne	.L1209
.L1202:
	cmpb	$0, 10(%rbx)
	jne	.L1210
.L1197:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1207:
	.cfi_restore_state
	leaq	4(%rbx), %rdi
	movl	$1, %edx
	movl	8(%rsp), %esi
	call	cr_tw
	movl	%eax, 20(%rsp)
	leal	512(%rax), %ebp
	jmp	.L1198
.L1208:
	leaq	10(%rbx), %rdi
	movl	$1, %edx
	movl	24(%rsp), %esi
	call	cr_tw
	addl	$768, %eax
	jmp	.L1199
.L1209:
	movzbl	19(%rbx), %edi
	movl	%ebp, %esi
	call	cr_rgb
	leaq	4(%rbx), %rdx
	movl	%r15d, %edi
	subl	%r14d, %edi
	imull	%r12d, %edi
	sarl	$12, %edi
	addl	%r14d, %edi
	pushq	$0
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %ecx
	pushq	%rcx
	.cfi_def_cfa_offset 112
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 120
	pushq	%r12
	.cfi_def_cfa_offset 128
	movl	$0, %r9d
	movl	$1, %r8d
	movl	40(%rsp), %ecx
	movl	48(%rsp), %esi
	call	cr_text
	movl	52(%rsp), %eax
	leal	512(%r15,%rax), %r15d
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	jmp	.L1202
.L1210:
	movzbl	20(%rbx), %edi
	movl	$57797, %esi
	call	cr_rgb
	leaq	10(%rbx), %rdx
	imull	$133, %r13d, %r13d
	movl	16(%rsp), %esi
	subl	%r13d, %esi
	leal	256(%r15), %edi
	subl	%r14d, %edi
	imull	%r12d, %edi
	sarl	$12, %edi
	addl	%r14d, %edi
	pushq	$0
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %ecx
	pushq	%rcx
	.cfi_def_cfa_offset 112
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 120
	pushq	%r12
	.cfi_def_cfa_offset 128
	movl	$0, %r9d
	movl	$1, %r8d
	movl	56(%rsp), %ecx
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	jmp	.L1197
	.cfi_endproc
.LFE137:
	.size	cr_name, .-cr_name
	.type	cr_p_chord, @function
cr_p_chord:
.LFB139:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	movq	%rdi, %rbx
	movq	%rsi, 8(%rsp)
	movl	%edx, 4(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	movzbl	111(%rdi), %r15d
	movzbl	658(%rdi), %ebp
	testb	%bpl, %bpl
	movl	$104, %eax
	cmove	%eax, %ebp
	movzbl	216(%rdi), %eax
	movb	%al, 16(%rsp)
	movzbl	312(%rdi), %r13d
	movl	%r13d, %eax
	negb	%al
	sbbl	%r12d, %r12d
	andl	$410, %r12d
	movl	%r15d, %eax
	negb	%al
	sbbl	%r14d, %r14d
	andl	$22, %r14d
	movzwl	212(%rdi), %edx
	movzwl	%dx, %eax
	sall	$4, %eax
	testw	%dx, %dx
	movl	$4096, %edx
	movl	%edx, %edi
	cmovne	%eax, %edi
	movl	%edi, 28(%rsp)
	movl	(%rsi), %eax
	movl	%eax, 24(%rsp)
	movzbl	214(%rbx), %edi
	movzwl	ux(%rip), %eax
	movw	%ax, 2(%rsp)
	testb	%dil, %dil
	je	.L1217
	movzbl	%dil, %edi
	movl	$57797, %esi
	call	cr_rgb
	movw	%ax, 2(%rsp)
	movzwl	%ax, %r8d
	movl	4(%rsp), %ecx
	movl	$240, %edx
	movl	$28, %esi
	movl	$0, %edi
	call	cr_fill
.L1217:
	cmpb	$0, 170(%rbx)
	jne	.L1218
	movq	8(%rsp), %rax
	cmpb	$0, 33(%rax)
	je	.L1211
	cmpb	$0, 191(%rbx)
	je	.L1211
.L1220:
	leaq	191(%rbx), %rdi
	jmp	.L1222
.L1218:
	leaq	170(%rbx), %rdi
	movq	8(%rsp), %rax
	cmpb	$0, 33(%rax)
	jne	.L1220
.L1222:
	movzbl	%bpl, %ecx
	movl	4(%rsp), %esi
	leal	18(%rsi), %eax
	subl	%r14d, %eax
	sall	$8, %eax
	movl	%eax, 4(%rsp)
	movl	24(%rsp), %r9d
	movl	28(%rsp), %eax
	imull	%eax, %r9d
	testb	%r13b, %r13b
	setne	%dl
	testb	%r15b, %r15b
	setne	%al
	movzbl	%al, %eax
	andl	%edx, %eax
	sall	$9, %eax
	cmpb	$0, 16(%rsp)
	setne	%dl
	movzbl	%dl, %edx
	sall	$8, %edx
	addl	%r12d, %edx
	addl	%edx, %eax
	leal	(%rax,%rax,8), %eax
	leal	56(%rsi), %edx
	sall	$7, %edx
	imull	$87, %ecx, %esi
	addl	%esi, %edx
	subl	%eax, %edx
	sarl	$12, %r9d
	movl	$224, %r8d
	movl	$30720, %esi
	call	cr_name
	cmpb	$0, 216(%rbx)
	jne	.L1238
.L1223:
	movzbl	312(%rbx), %r15d
	testb	%r15b, %r15b
	je	.L1211
	cmpb	$6, %r15b
	sbbl	%ecx, %ecx
	andl	$3, %ecx
	addl	$13, %ecx
	movl	4(%rsp), %eax
	subl	$3072, %eax
	movl	%eax, 8(%rsp)
	movzbl	%r15b, %r15d
	leaq	248(%rbx), %rbp
	movq	%rbp, %r13
	movl	$0, %r12d
	movl	$0, %r14d
	movq	%rbp, 16(%rsp)
	movl	%ecx, %ebp
.L1226:
	movl	$1, %edx
	movl	%ebp, %esi
	movq	%r13, %rdi
	call	cr_tw
	movl	%eax, 32(%rsp,%r12,4)
	movl	%r12d, %ecx
	negl	%ecx
	sbbl	%edx, %edx
	andl	$3584, %edx
	addl	%edx, %eax
	addl	%eax, %r14d
	addq	$1, %r12
	addq	$8, %r13
	cmpl	%r15d, %r12d
	jb	.L1226
	movl	%ebp, %ecx
	movq	16(%rsp), %rbp
	movl	%r14d, %r13d
	shrl	$31, %r13d
	addl	%r14d, %r13d
	sarl	%r13d
	negl	%r13d
	addl	$30720, %r13d
	movl	8(%rsp), %eax
	sarl	$4, %eax
	addl	$160, %eax
	movl	%eax, 8(%rsp)
	movl	$0, %r12d
	movl	4(%rsp), %r15d
	subl	$1792, %r15d
	movl	%ecx, 4(%rsp)
	jmp	.L1228
.L1238:
	movzwl	10+ux(%rip), %esi
	movzbl	215(%rbx), %edi
	call	cr_rgb
	leaq	216(%rbx), %rdx
	pushq	$0
	.cfi_def_cfa_offset 152
	movzwl	10(%rsp), %ecx
	pushq	%rcx
	.cfi_def_cfa_offset 160
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 168
	pushq	$4096
	.cfi_def_cfa_offset 176
	movl	$1, %r9d
	movl	$0, %r8d
	movl	$14, %ecx
	movl	36(%rsp), %r15d
	movl	%r15d, %esi
	movl	$30720, %edi
	call	cr_text
	movl	%r15d, %eax
	subl	$4608, %eax
	movl	%eax, 36(%rsp)
	addq	$32, %rsp
	.cfi_def_cfa_offset 144
	jmp	.L1223
.L1227:
	movl	32(%rsp,%r12,4), %eax
	leal	3584(%r13,%rax), %r13d
	addq	$1, %r12
	addq	$8, %rbp
	movzbl	312(%rbx), %eax
	cmpl	%eax, %r12d
	jnb	.L1211
.L1228:
	movzbl	6(%rbp), %edi
	movl	$63389, %esi
	call	cr_rgb
	movzwl	%ax, %r14d
	pushq	$0
	.cfi_def_cfa_offset 152
	movzwl	10(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	pushq	%r14
	.cfi_def_cfa_offset 168
	pushq	$4096
	.cfi_def_cfa_offset 176
	movl	$0, %r9d
	movl	$1, %r8d
	movl	36(%rsp), %ecx
	movq	%rbp, %rdx
	movl	%r15d, %esi
	movl	%r13d, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 144
	cmpb	$0, 7(%rbp)
	je	.L1227
	movl	32(%rsp,%r12,4), %edx
	sarl	$4, %edx
	movl	%r13d, %edi
	sarl	$4, %edi
	movl	%r14d, %r8d
	movl	$48, %ecx
	movl	8(%rsp), %esi
	call	cr_frect
	jmp	.L1227
.L1211:
	movq	72(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1239
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1239:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE139:
	.size	cr_p_chord, .-cr_p_chord
	.type	cr_pick_sides, @function
cr_pick_sides:
.LFB142:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	movq	%rdi, %r14
	movl	%esi, %ebx
	movl	%edx, %ebp
	movl	%ecx, %r13d
	movl	%r9d, 12(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	cmpl	$6144, 144(%rsp)
	setg	%r15b
	testl	%edx, %edx
	jle	.L1241
	movl	%r8d, %r12d
	testb	%r15b, %r15b
	jne	.L1247
.L1241:
	subl	$1, %ebx
	cmpl	%ebp, %ebx
	jle	.L1240
	testb	%r15b, %r15b
	jne	.L1248
.L1240:
	movq	72(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1249
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1247:
	.cfi_restore_state
	leal	-1(%rdx), %esi
	call	cr_item
	movq	%rax, %rdx
	leal	-1024(%r13), %esi
	movl	%r12d, %edi
	sall	$8, %edi
	subq	$8, %rsp
	.cfi_def_cfa_offset 152
	movl	152(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 168
	movzwl	12+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 176
	movl	$0, %r9d
	movl	$0, %r8d
	movl	$13, %ecx
	call	cr_text_fit
	addq	$32, %rsp
	.cfi_def_cfa_offset 144
	jmp	.L1241
.L1248:
	leal	1(%rbp), %esi
	movq	%r14, %rdi
	call	cr_item
	movq	%rax, %rdx
	leaq	16(%rsp), %rdi
	movl	144(%rsp), %r9d
	movl	$0, %r8d
	movl	$13, %ecx
	movl	$48, %esi
	call	cr_fit
	negl	%eax
	sbbl	%eax, %eax
	andl	$9, %eax
	leaq	16(%rsp), %rdx
	leal	-1024(%r13), %esi
	movl	12(%rsp), %edi
	sall	$8, %edi
	pushq	%rax
	.cfi_def_cfa_offset 152
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	movzwl	12+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 168
	pushq	$4096
	.cfi_def_cfa_offset 176
	movl	$2, %r9d
	movl	$0, %r8d
	movl	$13, %ecx
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 144
	jmp	.L1240
.L1249:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE142:
	.size	cr_pick_sides, .-cr_pick_sides
	.type	cr_pick_item, @function
cr_pick_item:
.LFB143:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbp
	movq	%rsi, %r14
	movl	%edx, 12(%rsp)
	movl	%ecx, %ebx
	movl	%r8d, %r15d
	movl	%r8d, 20(%rsp)
	movl	%r9d, 16(%rsp)
	movl	120(%rsp), %r12d
	movl	%edx, %esi
	call	cr_item
	movq	%rax, (%rsp)
	movl	$1, %edx
	movl	%ebx, %esi
	movq	%rax, %rdi
	call	cr_tw
	sall	$8, %r15d
	movl	%r15d, %r13d
	movl	$4096, 8(%rsp)
	cmpl	%eax, %r15d
	jge	.L1251
	movl	%eax, %ecx
	movl	%r15d, %eax
	sall	$12, %eax
	cltd
	idivl	%ecx
	movl	%eax, 8(%rsp)
.L1251:
	movl	4(%r14), %r14d
	testl	%r14d, %r14d
	je	.L1252
	movzbl	319(%rbp), %r15d
	testb	%r15b, %r15b
	jne	.L1264
.L1252:
	pushq	$0
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	movzwl	%r12w, %r12d
	pushq	%r12
	.cfi_def_cfa_offset 120
	movl	32(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	%ebx, %ecx
	movq	32(%rsp), %rdx
	movl	128(%rsp), %esi
	movl	$30720, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
.L1250:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1264:
	.cfi_restore_state
	movsbl	%r15b, %eax
	movl	12(%rsp), %esi
	subl	%eax, %esi
	movq	%rbp, %rdi
	call	cr_item
	movq	%rax, 24(%rsp)
	movl	$1, %edx
	movl	%ebx, %esi
	movq	%rax, %rdi
	call	cr_tw
	movl	%eax, %ecx
	movl	$4096, 12(%rsp)
	cmpl	%eax, %r13d
	jge	.L1253
	movl	%r13d, %eax
	sall	$12, %eax
	cltd
	idivl	%ecx
	movl	%eax, 12(%rsp)
.L1253:
	cmpl	$0, 16(%rsp)
	je	.L1254
	movl	20(%rsp), %edi
	movl	%edi, %eax
	shrl	$31, %eax
	addl	%edi, %eax
	sarl	%eax
	addl	$60, %eax
	sall	$8, %eax
	movl	%eax, %r13d
	imull	%eax, %r14d
	sarl	$12, %r14d
	testb	%r15b, %r15b
	setg	%bpl
	movzbl	%bpl, %ebp
	leal	-1(%rbp,%rbp), %ebp
	movl	%edi, %eax
	shrl	$31, %eax
	addl	%edi, %eax
	sarl	%eax
	movl	$116, %edx
	subl	%eax, %edx
	movl	$0, %ecx
	cmovs	%ecx, %edx
	movw	%dx, cr_clip(%rip)
	movw	$0, 2+cr_clip(%rip)
	addl	$124, %eax
	movl	$240, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movw	%ax, 4+cr_clip(%rip)
	movw	$240, 6+cr_clip(%rip)
	movzwl	%r12w, %r12d
	movl	%r14d, %edi
	imull	%ebp, %edi
	addl	$30720, %edi
	pushq	$32
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	pushq	%r12
	.cfi_def_cfa_offset 120
	movl	32(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	%ebx, %ecx
	movq	32(%rsp), %rdx
	movl	128(%rsp), %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	subl	%r13d, %r14d
	imull	%ebp, %r14d
	leal	30720(%r14), %edi
	pushq	$32
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	pushq	%r12
	.cfi_def_cfa_offset 120
	movl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	%ebx, %ecx
	movq	56(%rsp), %rdx
	movl	128(%rsp), %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
.L1257:
	call	cr_clip_all
	jmp	.L1250
.L1254:
	movl	112(%rsp), %r13d
	subl	104(%rsp), %r13d
	imull	%r13d, %r14d
	sarl	$12, %r14d
	testb	%r15b, %r15b
	setg	%bpl
	movzbl	%bpl, %ebp
	leal	-1(%rbp,%rbp), %ebp
	movw	$0, cr_clip(%rip)
	movl	104(%rsp), %eax
	sarl	$8, %eax
	movl	$0, %edx
	cmovs	%edx, %eax
	movw	%ax, 2+cr_clip(%rip)
	movw	$240, 4+cr_clip(%rip)
	movl	112(%rsp), %eax
	addl	$255, %eax
	sarl	$8, %eax
	addl	$4, %eax
	movl	$240, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movw	%ax, 6+cr_clip(%rip)
	movzwl	%r12w, %r12d
	movl	%r14d, %esi
	imull	%ebp, %esi
	addl	96(%rsp), %esi
	pushq	$32
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	pushq	%r12
	.cfi_def_cfa_offset 120
	movl	32(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	%ebx, %ecx
	movq	32(%rsp), %rdx
	movl	$30720, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	subl	%r13d, %r14d
	imull	%ebp, %r14d
	movl	%r14d, %esi
	addl	96(%rsp), %esi
	pushq	$32
	.cfi_def_cfa_offset 104
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	pushq	%r12
	.cfi_def_cfa_offset 120
	movl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	%ebx, %ecx
	movq	56(%rsp), %rdx
	movl	$30720, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	jmp	.L1257
	.cfi_endproc
.LFE143:
	.size	cr_pick_item, .-cr_pick_item
	.type	cr_p_picker, @function
cr_p_picker:
.LFB144:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, %rbx
	movq	%rsi, 32(%rsp)
	movl	%edx, 16(%rsp)
	movzbl	111(%rdi), %r15d
	movzbl	318(%rdi), %r14d
	cmpb	$1, %r14b
	sete	%al
	movzbl	%al, %eax
	movl	%eax, 28(%rsp)
	movzbl	315(%rdi), %eax
	movzbl	%al, %ecx
	movl	%ecx, %edi
	movl	%ecx, 8(%rsp)
	movzbl	317(%rbx), %edx
	movzbl	%dl, %ecx
	leal	-1(%rdi), %r12d
	cmpb	%al, %dl
	cmovb	%ecx, %r12d
	movzbl	658(%rbx), %eax
	testb	%al, %al
	je	.L1268
	movzbl	%al, %eax
	movl	%eax, 4(%rsp)
	cmpb	$1, %r14b
	je	.L1269
.L1270:
	cmpl	$1, %r15d
	sbbl	%r13d, %r13d
	andl	$54, %r13d
	addl	$170, %r13d
.L1271:
	movl	4(%rsp), %r11d
	imull	$282, %r11d, %r10d
	movl	%r10d, 24(%rsp)
	movzbl	610(%rbx), %eax
	negb	%al
	sbbl	%edi, %edi
	andl	$6656, %edi
	movl	%edi, 60(%rsp)
	cmpb	$1, %r14b
	movl	$5632, %eax
	movl	$0, %edx
	cmove	%edx, %eax
	movzbl	578(%rbx), %ecx
	negb	%cl
	sbbl	%edx, %edx
	andl	$4608, %edx
	cmpl	$1, %r15d
	sbbl	%esi, %esi
	andl	$2560, %esi
	movl	%esi, 56(%rsp)
	movl	16(%rsp), %ecx
	sall	$8, %ecx
	movl	%ecx, 44(%rsp)
	movl	%ecx, %ebp
	subl	%edx, %ebp
	subl	%esi, %ebp
	leal	(%rdi,%rax,2), %edx
	leal	(%rdx,%r10), %edx
	subl	%edx, %ebp
	sarl	%ebp
	leal	6656(%rax,%rbp), %ecx
	movl	%ecx, 20(%rsp)
	imull	$1128, %r11d, %eax
	cltq
	imulq	$1717986919, %rax, %rax
	sarq	$33, %rax
	addl	%ecx, %eax
	movl	%eax, 12(%rsp)
	movzbl	320(%rbx), %edi
	movl	$63389, %esi
	call	cr_rgb
	movw	%ax, 42(%rsp)
	movl	%r12d, %esi
	movq	%rbx, %rdi
	call	cr_item
	movq	%rax, 48(%rsp)
	cmpb	$0, 634(%rbx)
	jne	.L1295
.L1276:
	cmpb	$1, %r14b
	je	.L1296
	testl	%r12d, %r12d
	jg	.L1297
.L1280:
	movl	8(%rsp), %eax
	subl	$1, %eax
	cmpl	%r12d, %eax
	jg	.L1298
.L1279:
	movzwl	42(%rsp), %r14d
	movl	24(%rsp), %ebp
	movl	20(%rsp), %eax
	addl	%eax, %ebp
	pushq	%r14
	.cfi_def_cfa_offset 136
	pushq	%rbp
	.cfi_def_cfa_offset 144
	pushq	%rax
	.cfi_def_cfa_offset 152
	movl	36(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	movl	60(%rsp), %r9d
	movl	%r13d, %r8d
	movl	36(%rsp), %ecx
	movl	%r12d, %edx
	movq	64(%rsp), %rsi
	movq	%rbx, %rdi
	call	cr_pick_item
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
	cmpb	$0, 610(%rbx)
	jne	.L1299
.L1281:
	cmpb	$0, 578(%rbx)
	je	.L1282
	movzwl	ux(%rip), %edi
	movzwl	10+ux(%rip), %ecx
	leaq	578(%rbx), %rdx
	movl	44(%rsp), %esi
	addl	$7168, %esi
	movl	56(%rsp), %eax
	subl	%eax, %esi
	cmpl	$1, %r15d
	sbbl	%eax, %eax
	andl	$-6656, %eax
	addl	$8704, %eax
	subl	%eax, %esi
	pushq	$0
	.cfi_def_cfa_offset 136
	pushq	%rdi
	.cfi_def_cfa_offset 144
	pushq	%rcx
	.cfi_def_cfa_offset 152
	pushq	$4096
	.cfi_def_cfa_offset 160
	movl	$1, %r9d
	movl	$0, %r8d
	movl	$13, %ecx
	movl	$30720, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
.L1282:
	movl	8(%rsp), %edi
	cmpl	$1, %edi
	jle	.L1265
	testl	%r15d, %r15d
	je	.L1300
.L1265:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1268:
	.cfi_restore_state
	movl	$40, 4(%rsp)
	cmpb	$1, %r14b
	jne	.L1270
	movl	$36, 4(%rsp)
.L1269:
	cmpl	$1, %r15d
	sbbl	%r13d, %r13d
	andl	$30, %r13d
	addl	$120, %r13d
	jmp	.L1271
.L1295:
	movzwl	10+ux(%rip), %esi
	movzbl	321(%rbx), %edi
	call	cr_rgb
	leaq	634(%rbx), %rdx
	pushq	$0
	.cfi_def_cfa_offset 136
	movzwl	ux(%rip), %ecx
	pushq	%rcx
	.cfi_def_cfa_offset 144
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 152
	pushq	$4096
	.cfi_def_cfa_offset 160
	movl	$0, %r9d
	movl	$1, %r8d
	movl	$14, %ecx
	movl	$11264, %esi
	movl	$2560, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L1276
.L1296:
	cmpl	$1, %r15d
	sbbl	%r14d, %r14d
	andl	$-30, %r14d
	addl	$36, %r14d
	cmpl	$1, %r15d
	sbbl	%ebp, %ebp
	andl	$30, %ebp
	addl	$204, %ebp
	movl	$1, %edx
	movl	4(%rsp), %esi
	movq	48(%rsp), %rdi
	call	cr_tw
	movl	%eax, %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movl	%ebp, %edx
	subl	%r14d, %edx
	sall	$8, %edx
	movl	%r13d, %eax
	sall	$8, %eax
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	shrl	$31, %eax
	addl	%edx, %eax
	sarl	%eax
	subl	$2560, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	movl	%ebp, %r9d
	movl	%r14d, %r8d
	movl	28(%rsp), %ecx
	movl	%r12d, %edx
	movl	24(%rsp), %esi
	movq	%rbx, %rdi
	call	cr_pick_sides
	addq	$16, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L1279
.L1297:
	leal	-1(%r12), %esi
	movq	%rbx, %rdi
	call	cr_item
	movq	%rax, %rdx
	leal	10240(%rbp), %esi
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movl	%r13d, %eax
	sall	$8, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 152
	movzwl	12+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	movl	$1, %r9d
	movl	$0, %r8d
	movl	$15, %ecx
	movl	$30720, %edi
	call	cr_text_fit
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L1280
.L1298:
	leal	1(%r12), %esi
	movq	%rbx, %rdi
	call	cr_item
	movq	%rax, %rdx
	movl	20(%rsp), %eax
	movl	24(%rsp), %ecx
	addl	%ecx, %eax
	movl	60(%rsp), %ecx
	leal	4096(%rcx,%rax), %esi
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movl	%r13d, %eax
	sall	$8, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 152
	movzwl	12+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 160
	movl	$1, %r9d
	movl	$0, %r8d
	movl	$15, %ecx
	movl	$30720, %edi
	call	cr_text_fit
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L1279
.L1299:
	leaq	610(%rbx), %rdx
	leal	5120(%rbp), %esi
	pushq	$0
	.cfi_def_cfa_offset 136
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	pushq	%r14
	.cfi_def_cfa_offset 152
	pushq	$4096
	.cfi_def_cfa_offset 160
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$20, %ecx
	movl	$30720, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 128
	jmp	.L1281
.L1300:
	movl	16(%rsp), %edx
	addl	$20, %edx
	movl	%r14d, %ecx
	movl	%r12d, %esi
	call	cr_pick_marks
	jmp	.L1265
	.cfi_endproc
.LFE144:
	.size	cr_p_picker, .-cr_p_picker
	.type	cr_keyboard, @function
cr_keyboard:
.LFB138:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %r15
	leal	(%rdx,%rdx,2), %eax
	sall	$5, %eax
	movslq	%eax, %rcx
	imulq	$1717986919, %rcx, %rcx
	sarq	$34, %rcx
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, 12(%rsp)
	movl	%edx, %eax
	sall	$4, %eax
	movl	%eax, 8(%rsp)
	movl	%esi, %ecx
	sall	$4, %ecx
	leal	-3(%rsi,%rdx), %eax
	sall	$8, %eax
	movl	%eax, 24(%rsp)
	leaq	727(%rdi), %r13
	movq	%r13, %r12
	movl	$0, %ebx
	movl	$0, %r14d
	movl	%ecx, (%rsp)
	movq	%r13, 16(%rsp)
	jmp	.L1306
.L1303:
	leaq	ux(%rip), %rax
	movzwl	26(%rax), %r8d
.L1304:
	sall	$4, %ebp
	leal	8(%rbp), %edi
	movl	8(%rsp), %ecx
	movl	$208, %edx
	movl	(%rsp), %esi
	call	cr_frect
	cmpb	$0, (%r12)
	jne	.L1318
.L1305:
	addl	$1, %r14d
.L1302:
	addq	$1, %rbx
	addq	$3, %r12
	cmpq	$27, %rbx
	je	.L1319
.L1306:
	leal	5(%rbx), %edx
	movl	%edx, %eax
	movl	$2863311531, %esi
	imulq	%rsi, %rax
	shrq	$35, %rax
	leal	(%rax,%rax,2), %eax
	sall	$2, %eax
	subl	%eax, %edx
	movl	$1354, %eax
	btl	%edx, %eax
	jc	.L1302
	imull	$14, %r14d, %r13d
	leal	8(%r13), %ebp
	movl	696(%r15), %eax
	btl	%ebx, %eax
	jnc	.L1303
	movzbl	700(%r15,%rbx), %edi
	movl	$57797, %esi
	call	cr_rgb
	movzwl	%ax, %r8d
	jmp	.L1304
.L1318:
	leal	15(%r13), %edi
	sall	$8, %edi
	pushq	$0
	.cfi_def_cfa_offset 104
	leaq	ux(%rip), %rcx
	movzwl	26(%rcx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	movzwl	(%rcx), %eax
	pushq	%rax
	.cfi_def_cfa_offset 120
	pushq	$4096
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$7, %ecx
	movq	%r12, %rdx
	movl	56(%rsp), %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
	jmp	.L1305
.L1319:
	movl	(%rsp), %ecx
	movq	16(%rsp), %r13
	leal	-8(%rcx), %eax
	movl	%eax, 8(%rsp)
	leal	8(%rcx), %eax
	movl	%eax, 24(%rsp)
	movl	12(%rsp), %esi
	leal	-32(%rcx,%rsi), %eax
	sall	$4, %eax
	movl	%eax, 28(%rsp)
	movl	$0, %ebx
	movl	$0, %r14d
	leal	16(%rsi), %eax
	movl	%eax, 16(%rsp)
	movq	%r15, (%rsp)
	jmp	.L1312
.L1307:
	movq	(%rsp), %rax
	movl	696(%rax), %r15d
	imull	$14, %r14d, %r12d
	leal	4(%r12), %ebp
	sall	$4, %ebp
	leal	-8(%rbp), %edi
	leaq	ux(%rip), %rsi
	movzwl	14(%rsi), %r8d
	movl	16(%rsp), %ecx
	movl	$144, %edx
	movl	8(%rsp), %esi
	call	cr_frect
	btl	%ebx, %r15d
	jnc	.L1309
	movq	(%rsp), %rax
	movzbl	700(%rax,%rbx), %edi
	movl	$62880, %esi
	call	cr_rgb
	movl	12(%rsp), %esi
	leal	-16(%rsi), %ecx
	leal	8(%rbp), %edi
	movzwl	%ax, %r8d
	movl	$112, %edx
	movl	24(%rsp), %esi
	call	cr_frect
	cmpb	$0, 0(%r13)
	je	.L1308
	leaq	ux(%rip), %rax
	movzwl	(%rax), %eax
	movl	%eax, %r15d
	jmp	.L1313
.L1309:
	leaq	ux(%rip), %rax
	movzwl	(%rax), %r15d
	movl	12(%rsp), %eax
	leal	-16(%rax), %ecx
	leal	8(%rbp), %edi
	movl	%r15d, %r8d
	movl	$112, %edx
	movl	24(%rsp), %esi
	call	cr_frect
	cmpb	$0, 0(%r13)
	je	.L1308
	leaq	ux(%rip), %rax
	movzwl	10(%rax), %eax
.L1313:
	leal	8(%r12), %edi
	sall	$8, %edi
	pushq	$0
	.cfi_def_cfa_offset 104
	pushq	%r15
	.cfi_def_cfa_offset 112
	pushq	%rax
	.cfi_def_cfa_offset 120
	pushq	$4096
	.cfi_def_cfa_offset 128
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$6, %ecx
	movq	%r13, %rdx
	movl	60(%rsp), %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 96
.L1308:
	addq	$1, %rbx
	addq	$3, %r13
	cmpq	$27, %rbx
	je	.L1320
.L1312:
	leal	5(%rbx), %edx
	movl	%edx, %eax
	movl	$2863311531, %ecx
	imulq	%rcx, %rax
	shrq	$35, %rax
	leal	(%rax,%rax,2), %eax
	sall	$2, %eax
	subl	%eax, %edx
	movl	$1354, %eax
	btl	%edx, %eax
	jc	.L1307
	addl	$1, %r14d
	jmp	.L1308
.L1320:
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE138:
	.size	cr_keyboard, .-cr_keyboard
	.section	.rodata.str1.1
.LC17:
	.string	"fine"
	.text
	.type	cr_ed_title, @function
cr_ed_title:
.LFB164:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rbx
	movzbl	4(%rdi), %esi
	movl	$232, %r12d
	cmpb	$-1, %sil
	jne	.L1331
.L1322:
	cmpb	$0, 809(%rbx)
	jne	.L1332
	movl	$232, %ebp
	subl	%r12d, %ebp
	sall	$8, %ebp
.L1327:
	cmpb	$0, 1857(%rbx)
	je	.L1324
	movl	$59392, %edi
	subl	%ebp, %edi
	movl	%ebp, %eax
	negl	%eax
	sbbl	%eax, %eax
	andl	$1536, %eax
	subl	%eax, %edi
	pushq	$0
	.cfi_def_cfa_offset 56
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 64
	movzwl	4+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 72
	pushq	$4096
	.cfi_def_cfa_offset 80
	movl	$2, %r9d
	movl	$1, %r8d
	movl	$9, %ecx
	leaq	.LC17(%rip), %r12
	movq	%r12, %rdx
	movl	$4096, %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 48
	movl	$1, %edx
	movl	$9, %esi
	movq	%r12, %rdi
	call	cr_tw
	leal	1536(%rbp,%rax), %ebp
.L1324:
	cmpb	$0, 634(%rbx)
	je	.L1321
	movl	$57344, %edx
	subl	%ebp, %edx
	testl	%ebp, %ebp
	setne	%al
	movzbl	%al, %eax
	sall	$11, %eax
	subl	%eax, %edx
	movl	%edx, %ebp
	movzwl	4+ux(%rip), %esi
	movzbl	321(%rbx), %edi
	call	cr_rgb
	leaq	634(%rbx), %rdx
	subq	$8, %rsp
	.cfi_def_cfa_offset 56
	pushq	%rbp
	.cfi_def_cfa_offset 64
	movzwl	ux(%rip), %ecx
	pushq	%rcx
	.cfi_def_cfa_offset 72
	movzwl	%ax, %eax
	pushq	%rax
	.cfi_def_cfa_offset 80
	movl	$0, %r9d
	movl	$1, %r8d
	movl	$13, %ecx
	movl	$4352, %esi
	movl	$2048, %edi
	call	cr_text_fit
	addq	$32, %rsp
	.cfi_def_cfa_offset 48
.L1321:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L1331:
	.cfi_restore_state
	movzbl	%sil, %esi
	movl	$214, %edi
	call	cr_battery
	movl	$208, %r12d
	jmp	.L1322
.L1332:
	leaq	809(%rbx), %r13
	movl	$1, %edx
	movl	$11, %esi
	movq	%r13, %rdi
	call	cr_tw
	movl	$232, %ebp
	subl	%r12d, %ebp
	sall	$8, %ebp
	addl	%eax, %ebp
	movl	%r12d, %edi
	sall	$8, %edi
	pushq	$0
	.cfi_def_cfa_offset 56
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 64
	movzwl	10+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 72
	pushq	$4096
	.cfi_def_cfa_offset 80
	movl	$2, %r9d
	movl	$1, %r8d
	movl	$11, %ecx
	movq	%r13, %rdx
	movl	$4352, %esi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 48
	jmp	.L1327
	.cfi_endproc
.LFE164:
	.size	cr_ed_title, .-cr_ed_title
	.section	.rodata.str1.1
.LC18:
	.string	"ALGO"
.LC19:
	.string	"Y"
.LC20:
	.string	"X"
	.text
	.type	cr_algo_band, @function
cr_algo_band:
.LFB167:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$120, %rsp
	.cfi_def_cfa_offset 176
	movq	%fs:40, %rax
	movq	%rax, 104(%rsp)
	xorl	%eax, %eax
	movzbl	1858(%rdi), %eax
	movl	$8, %edx
	cmpb	%dl, %al
	cmova	%edx, %eax
	testb	%al, %al
	movl	$1, %edx
	cmove	%edx, %eax
	movzbl	1859(%rdi), %r12d
	movzbl	1860(%rdi), %esi
	movl	%esi, 32(%rsp)
	movzbl	%al, %edx
	leal	-1(%rdx), %r14d
	addl	$48, %eax
	movb	%al, 102(%rsp)
	movb	$0, 103(%rsp)
	movslq	%r14d, %rbx
	leaq	(%rbx,%rbx,8), %rdx
	leaq	CR_ALGOS(%rip), %rax
	leaq	(%rax,%rdx,2), %r15
	movq	%r15, %rcx
	movl	$0, %edx
	leaq	ROWY.19(%rip), %rsi
.L1334:
	movzbl	11(%rcx), %eax
	imulq	$2464, %rax, %rax
	imulq	$1374389535, %rax, %rax
	sarq	$37, %rax
	addl	$960, %eax
	movl	%eax, 64(%rsp,%rdx,4)
	movzbl	10(%rcx), %eax
	movl	(%rsi,%rax,4), %eax
	movl	%eax, 80(%rsp,%rdx,4)
	addq	$1, %rdx
	addq	$2, %rcx
	cmpq	$4, %rdx
	jne	.L1334
	pushq	$0
	.cfi_def_cfa_offset 184
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 192
	movzwl	10+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 200
	pushq	$4096
	.cfi_def_cfa_offset 208
	movl	$0, %r9d
	movl	$1, %r8d
	movl	$10, %ecx
	leaq	.LC18(%rip), %rdx
	movl	$9216, %esi
	movl	$2048, %edi
	call	cr_text
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	leaq	102(%rsp), %rdx
	pushq	$0
	.cfi_def_cfa_offset 184
	movzwl	ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 192
	movzwl	4+ux(%rip), %eax
	pushq	%rax
	.cfi_def_cfa_offset 200
	pushq	$4096
	.cfi_def_cfa_offset 208
	movl	$0, %r9d
	movl	$1, %r8d
	movl	$24, %ecx
	movl	$16384, %esi
	movl	$2048, %edi
	call	cr_text
	movslq	%r14d, %rax
	leaq	(%rax,%rax,8), %rdx
	leaq	CR_ALGOS(%rip), %rax
	movzbl	(%rax,%rdx,2), %eax
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	testb	%al, %al
	je	.L1335
	leaq	(%rbx,%rbx,8), %rdx
	movzbl	%al, %eax
	leal	-1(%rax), %eax
	addq	%rdx, %rax
	leaq	2+CR_ALGOS(%rip), %rdx
	leaq	(%rdx,%rax,2), %rax
	movq	%rax, (%rsp)
	movl	%r14d, 8(%rsp)
	movl	%r12d, 20(%rsp)
	movq	%r15, %r14
	jmp	.L1338
.L1336:
	addq	$2, %r14
	movq	(%rsp), %rax
	cmpq	%rax, %r14
	je	.L1372
.L1338:
	movzbl	1(%r14), %eax
	movl	64(%rsp,%rax,4), %esi
	movl	80(%rsp,%rax,4), %r13d
	movzbl	2(%r14), %eax
	movl	64(%rsp,%rax,4), %r15d
	movl	80(%rsp,%rax,4), %r12d
	movl	%r15d, %ebp
	movl	%esi, 16(%rsp)
	subl	%esi, %ebp
	movl	%r12d, %ebx
	subl	%r13d, %ebx
	movl	%ebp, %edi
	imull	%ebp, %edi
	movl	%ebx, %eax
	imull	%ebx, %eax
	addl	%eax, %edi
	call	cr_isqrt
	movl	%eax, %ecx
	testl	%eax, %eax
	je	.L1336
	sall	$12, %ebp
	movl	%ebp, %eax
	cltd
	idivl	%ecx
	movl	%eax, %ebp
	sall	$12, %ebx
	movl	%ebx, %eax
	cltd
	idivl	%ecx
	movl	%eax, %ebx
	movl	%eax, %ecx
	negl	%ecx
	cmovs	%eax, %ecx
	movl	%ebp, %eax
	negl	%eax
	cmovs	%ebp, %eax
	cmpl	%eax, %ecx
	cmovl	%eax, %ecx
	testl	%ecx, %ecx
	movl	$1, %eax
	cmove	%eax, %ecx
	movl	$458752, %eax
	movl	$0, %edx
	idivl	%ecx
	leal	16(%rax), %ecx
	movl	%ebp, %eax
	imull	%ecx, %eax
	leal	4095(%rax), %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	sarl	$12, %edx
	negl	%edx
	addl	%edx, %r15d
	imull	%ebx, %ecx
	leal	4095(%rcx), %eax
	testl	%ecx, %ecx
	cmovns	%ecx, %eax
	sarl	$12, %eax
	negl	%eax
	addl	%eax, %r12d
	movzwl	16(%rsp), %ecx
	subl	%edx, %ecx
	movw	%cx, 56(%rsp)
	subl	%eax, %r13d
	movw	%r13w, 58(%rsp)
	leal	0(%rbp,%rbp,2), %edx
	sall	$4, %edx
	leal	4095(%rdx), %eax
	cmovns	%edx, %eax
	sarl	$12, %eax
	movl	%r15d, %edx
	subl	%eax, %edx
	movw	%dx, 60(%rsp)
	leal	(%rbx,%rbx,2), %edx
	sall	$4, %edx
	leal	4095(%rdx), %eax
	cmovns	%edx, %eax
	sarl	$12, %eax
	movl	%r12d, %edx
	subl	%eax, %edx
	movw	%dx, 62(%rsp)
	leaq	ux(%rip), %rax
	movzwl	10(%rax), %r13d
	leaq	56(%rsp), %rdi
	movl	%r13d, %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$24, %edx
	movl	$2, %esi
	call	cr_poly
	leal	(%rbx,%rbx,8), %edx
	sall	$3, %edx
	leal	0(%rbp,%rbp,4), %edi
	sall	$3, %edi
	leal	0(%rbp,%rbp,8), %eax
	sall	$3, %eax
	imull	$-40, %ebx, %ebx
	leal	(%rdx,%rdi), %ecx
	leal	4095(%rcx), %esi
	testl	%ecx, %ecx
	cmovns	%ecx, %esi
	sarl	$12, %esi
	leal	(%rax,%rbx), %r8d
	leal	4095(%r8), %ecx
	testl	%r8d, %r8d
	cmovns	%r8d, %ecx
	sarl	$12, %ecx
	subl	%edi, %edx
	leal	4095(%rdx), %edi
	cmovns	%edx, %edi
	sarl	$12, %edi
	movl	%r12d, %edx
	subl	%edi, %edx
	subl	%ebx, %eax
	leal	4095(%rax), %edi
	cmovs	%edi, %eax
	sarl	$12, %eax
	movl	%r15d, %edi
	subl	%eax, %edi
	subq	$8, %rsp
	.cfi_def_cfa_offset 184
	pushq	%r13
	.cfi_def_cfa_offset 192
	movl	%r12d, %r9d
	subl	%esi, %r9d
	movl	%r15d, %r8d
	subl	%ecx, %r8d
	movl	%edx, %ecx
	movl	%edi, %edx
	movl	%r12d, %esi
	movl	%r15d, %edi
	call	cr_tri
	addq	$16, %rsp
	.cfi_def_cfa_offset 176
	jmp	.L1336
.L1372:
	movl	8(%rsp), %r14d
	movl	20(%rsp), %r12d
.L1335:
	movslq	%r14d, %rax
	leaq	(%rax,%rax,8), %rdx
	leaq	CR_ALGOS(%rip), %rax
	movzbl	8(%rax,%rdx,2), %ecx
	movl	$0, %edx
	movl	$0, %esi
	movl	$0, %eax
	jmp	.L1340
.L1339:
	addq	$1, %rdx
	cmpq	$4, %rdx
	je	.L1373
.L1340:
	btl	%edx, %ecx
	jnc	.L1339
	addl	64(%rsp,%rdx,4), %eax
	addl	$1, %esi
	jmp	.L1339
.L1373:
	testl	%esi, %esi
	movl	$1, %edx
	cmove	%edx, %esi
	cltd
	idivl	%esi
	movl	%eax, %edi
	movl	%eax, 48(%rsp)
	movslq	%r14d, %rax
	leaq	(%rax,%rax,8), %rdx
	leaq	CR_ALGOS(%rip), %rax
	movzbl	9(%rax,%rdx,2), %r8d
	movl	$0, %edx
	movl	$0, %esi
	movl	$0, %eax
	jmp	.L1343
.L1342:
	addq	$1, %rdx
	cmpq	$4, %rdx
	je	.L1374
.L1343:
	btl	%edx, %r8d
	jnc	.L1342
	addl	64(%rsp,%rdx,4), %eax
	addl	$1, %esi
	jmp	.L1342
.L1374:
	testl	%esi, %esi
	movl	$1, %edx
	cmove	%edx, %esi
	cltd
	idivl	%esi
	movl	%eax, 52(%rsp)
	cmpl	%edi, %eax
	jge	.L1345
	movl	%edi, %edx
	subl	%eax, %edx
	cmpl	$255, %edx
	setle	%dl
.L1346:
	testb	%dl, %dl
	je	.L1359
	addl	%edi, %eax
	movl	%eax, %edx
	shrl	$31, %edx
	addl	%edx, %eax
	sarl	%eax
	leal	-192(%rax), %edx
	movl	%edx, 48(%rsp)
	addl	$192, %eax
	movl	%eax, 52(%rsp)
.L1359:
	movl	$0, %r13d
	movslq	%r14d, %rax
	leaq	(%rax,%rax,8), %rax
	addq	%rax, %rax
	movq	%rax, 24(%rsp)
	movl	%r14d, 36(%rsp)
	movl	%ecx, 44(%rsp)
	movl	%r12d, 40(%rsp)
.L1355:
	movl	%r13d, (%rsp)
	testl	%r13d, %r13d
	je	.L1347
	leaq	CR_ALGOS(%rip), %rax
	movq	24(%rsp), %rsi
	movzbl	9(%rax,%rsi), %r15d
	cmpl	$127, 32(%rsp)
	jg	.L1348
.L1349:
	movzwl	12+ux(%rip), %eax
	jmp	.L1350
.L1345:
	movl	%eax, %edx
	subl	%edi, %edx
	cmpl	$255, %edx
	setle	%dl
	jmp	.L1346
.L1347:
	cmpl	$128, 32(%rsp)
	jg	.L1363
	movl	44(%rsp), %r15d
.L1348:
	movzwl	4+ux(%rip), %eax
.L1350:
	movl	48(%rsp,%r13,4), %r14d
	movl	%r14d, %ebp
	movl	%r14d, %r12d
	movl	$0, %ebx
	movzwl	%ax, %esi
	movl	%esi, 16(%rsp)
	movq	%r13, 8(%rsp)
	movw	%ax, 20(%rsp)
	jmp	.L1352
.L1363:
	movl	44(%rsp), %r15d
	jmp	.L1349
.L1351:
	addq	$1, %rbx
	cmpq	$4, %rbx
	je	.L1375
.L1352:
	btl	%ebx, %r15d
	jnc	.L1351
	movl	64(%rsp,%rbx,4), %r13d
	leal	-12(%r13), %edi
	movl	16(%rsp), %r8d
	movl	$136, %ecx
	movl	$24, %edx
	movl	$1476, %esi
	call	cr_frect
	cmpl	%r13d, %r12d
	cmovg	%r13d, %r12d
	cmpl	%r13d, %ebp
	cmovl	%r13d, %ebp
	jmp	.L1351
.L1375:
	movq	8(%rsp), %r13
	movzwl	20(%rsp), %eax
	movzwl	%ax, %ebx
	subl	%r12d, %ebp
	leal	24(%rbp), %edx
	leal	-12(%r12), %edi
	movl	%ebx, %r8d
	movl	$24, %ecx
	movl	$1588, %esi
	call	cr_frect
	leal	-12(%r14), %edi
	movl	%ebx, %r8d
	movl	$120, %ecx
	movl	$24, %edx
	movl	$1588, %esi
	call	cr_frect
	movzwl	ux(%rip), %eax
	cmpl	$0, (%rsp)
	je	.L1353
	movl	%r14d, %edi
	sall	$4, %edi
	pushq	$0
	.cfi_def_cfa_offset 184
	pushq	%rax
	.cfi_def_cfa_offset 192
	pushq	%rbx
	.cfi_def_cfa_offset 200
	pushq	$4096
	.cfi_def_cfa_offset 208
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$11, %ecx
	leaq	.LC19(%rip), %rdx
	movl	$29696, %esi
	call	cr_text
	addq	$1, %r13
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	cmpq	$2, %r13
	jne	.L1355
	movl	36(%rsp), %r14d
	movl	40(%rsp), %r12d
	movl	$0, %ebp
	movl	%r14d, (%rsp)
	movl	%r12d, 8(%rsp)
.L1356:
	leaq	ux(%rip), %r13
	movzwl	0(%r13), %r14d
	movl	80(%rsp,%rbp), %ebx
	leal	-112(%rbx), %r15d
	movl	64(%rsp,%rbp), %r12d
	leal	-112(%r12), %eax
	movl	%r14d, %r8d
	movl	$224, %ecx
	movl	$224, %edx
	movl	%r15d, %esi
	movl	%eax, 16(%rsp)
	movl	%eax, %edi
	call	cr_frect
	movzwl	4(%r13), %r13d
	movl	%r13d, %r9d
	movl	$24, %r8d
	movl	$224, %ecx
	movl	$224, %edx
	movl	%r15d, %esi
	movl	16(%rsp), %edi
	call	cr_srect
	leaq	CR_OPS(%rip), %rax
	movq	(%rax,%rbp,2), %rdx
	sall	$4, %ebx
	leal	819(%rbx), %esi
	movl	%r12d, %edi
	sall	$4, %edi
	pushq	$0
	.cfi_def_cfa_offset 184
	pushq	%r14
	.cfi_def_cfa_offset 192
	pushq	%r13
	.cfi_def_cfa_offset 200
	pushq	$4096
	.cfi_def_cfa_offset 208
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$9, %ecx
	call	cr_text
	addq	$4, %rbp
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	cmpq	$16, %rbp
	jne	.L1356
	movl	(%rsp), %r14d
	movl	8(%rsp), %r12d
	movslq	%r14d, %rax
	leaq	(%rax,%rax,8), %rdx
	movzwl	4+ux(%rip), %r13d
	leaq	CR_ALGOS(%rip), %rax
	movzbl	7(%rax,%rdx,2), %eax
	movl	80(%rsp,%rax,4), %ebp
	movl	64(%rsp,%rax,4), %ebx
	movl	%r12d, %eax
	sall	$5, %eax
	movslq	%eax, %rdx
	imulq	$-2139062143, %rdx, %rdx
	shrq	$32, %rdx
	leal	(%rax,%rdx), %ecx
	movl	%ecx, %eax
	sarl	$7, %eax
	leal	16(%rax), %ecx
	leal	128(%rbx), %edi
	pushq	%r13
	.cfi_def_cfa_offset 184
	pushq	$0
	.cfi_def_cfa_offset 192
	pushq	$0
	.cfi_def_cfa_offset 200
	pushq	$1
	.cfi_def_cfa_offset 208
	movl	$32768, %r9d
	movl	$49152, %r8d
	movl	$80, %edx
	movl	%ebp, %esi
	call	cr_arc
	leal	192(%rbx), %edx
	addq	$24, %rsp
	.cfi_def_cfa_offset 184
	leal	32(%rbp), %ecx
	leal	80(%rbp), %esi
	leal	120(%rbx), %edi
	pushq	%r13
	.cfi_def_cfa_offset 192
	leal	128(%rbp), %r9d
	movl	%edx, %r8d
	call	cr_tri
	addq	$16, %rsp
	.cfi_def_cfa_offset 176
	movq	104(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1376
	addq	$120, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1353:
	.cfi_restore_state
	movl	%r14d, %edi
	sall	$4, %edi
	pushq	$0
	.cfi_def_cfa_offset 184
	pushq	%rax
	.cfi_def_cfa_offset 192
	pushq	%rbx
	.cfi_def_cfa_offset 200
	pushq	$4096
	.cfi_def_cfa_offset 208
	movl	$1, %r9d
	movl	$1, %r8d
	movl	$11, %ecx
	leaq	.LC20(%rip), %rdx
	movl	$29696, %esi
	call	cr_text
	addq	$1, %r13
	addq	$32, %rsp
	.cfi_def_cfa_offset 176
	jmp	.L1355
.L1376:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE167:
	.size	cr_algo_band, .-cr_algo_band
	.section	.rodata.str1.1
.LC21:
	.string	"B"
.LC22:
	.string	"A"
	.text
	.type	cr_ade2_band, @function
cr_ade2_band:
.LFB168:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$200, %rsp
	.cfi_def_cfa_offset 256
	movq	%rdi, 48(%rsp)
	movw	%si, 34(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 184(%rsp)
	xorl	%eax, %eax
	movzbl	1866(%rdi), %eax
	subl	$1, %eax
	movl	%eax, %ebx
	movl	%eax, 44(%rsp)
	movzwl	14+ux(%rip), %r8d
	movl	$16, %ecx
	movl	$3584, %edx
	movl	$1744, %esi
	movl	$128, %edi
	call	cr_frect
	movl	%ebx, 36(%rsp)
	movl	$0, %r12d
	leaq	112(%rsp), %rax
	movq	%rax, 56(%rsp)
.L1392:
	movl	%r12d, 20(%rsp)
	cmpl	$1, %r12d
	sbbl	%ebp, %ebp
	andl	$-1920, %ebp
	addl	$2048, %ebp
	cmpl	$1, %r12d
	sbbl	%esi, %esi
	andl	$-1920, %esi
	addl	$3712, %esi
	leal	-64(%rsi), %eax
	movl	%eax, 12(%rsp)
	subl	$160, %esi
	movl	%esi, %ecx
	subl	%ebp, %ecx
	leal	0(,%r12,4), %eax
	movl	$-1, %r13d
	movl	44(%rsp), %ebx
	cmpl	%eax, %ebx
	jl	.L1379
	leal	4(,%r12,4), %eax
	cmpl	%eax, %ebx
	cmovl	36(%rsp), %r13d
.L1379:
	movq	48(%rsp), %rbx
	movzbl	1861(%rbx,%r12,4), %eax
	imull	$1056, %eax, %eax
	movslq	%eax, %rdx
	imulq	$-2139062143, %rdx, %rdx
	shrq	$32, %rdx
	addl	%edx, %eax
	sarl	$7, %eax
	negl	%eax
	movl	%eax, 40(%rsp)
	leal	1728(%rax), %r10d
	movl	%r10d, 16(%rsp)
	movzbl	1860(%rbx,%r12,4), %eax
	imull	$1056, %eax, %eax
	movslq	%eax, %rdx
	imulq	$-2139062143, %rdx, %rdx
	shrq	$32, %rdx
	addl	%eax, %edx
	sarl	$7, %edx
	negl	%edx
	addl	$1728, %edx
	movzbl	1858(%rbx,%r12,4), %edi
	imull	%ecx, %edi
	addl	%edi, %edi
	movslq	%edi, %rax
	imulq	$-845519051, %rax, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	sarl	$10, %eax
	sarl	$31, %edi
	subl	%edi, %eax
	addl	%ebp, %eax
	movzbl	1859(%rbx,%r12,4), %edi
	imull	%ecx, %edi
	addl	%edi, %edi
	movslq	%edi, %rcx
	imulq	$-845519051, %rcx, %rcx
	shrq	$32, %rcx
	addl	%edi, %ecx
	sarl	$10, %ecx
	sarl	$31, %edi
	subl	%edi, %ecx
	addl	%eax, %ecx
	movl	%ebp, 64(%rsp)
	movl	%eax, 68(%rsp)
	movl	%ecx, 72(%rsp)
	movl	%esi, 76(%rsp)
	movl	$1728, 80(%rsp)
	movl	%r10d, 84(%rsp)
	movl	%edx, 88(%rsp)
	movl	%edx, 92(%rsp)
	leaq	64(%rsp), %r14
	leaq	80(%rsp), %rbx
	movl	$0, %r9d
	movl	$0, %r15d
	movl	%ebp, 24(%rsp)
	movl	%r13d, 28(%rsp)
	movq	%r12, %r10
	jmp	.L1382
.L1380:
	movl	%r15d, 96(%rsp,%r9,4)
	leal	(%r15,%r15), %eax
	movl	%eax, %edx
	movl	(%r14), %ecx
	movw	%cx, 112(%rsp,%rdx,2)
	leal	1(%rax), %eax
	movl	(%rbx), %edx
	movw	%dx, 112(%rsp,%rax,2)
	addl	$1, %r15d
	addq	$1, %r9
	addq	$4, %r14
	addq	$4, %rbx
	cmpq	$4, %r9
	je	.L1403
.L1382:
	testl	%r9d, %r9d
	je	.L1380
	movl	-4(%rbx), %r13d
	movl	(%rbx), %r11d
	subl	%r13d, %r11d
	movl	%r11d, %edx
	negl	%edx
	cmovs	%r11d, %edx
	movslq	%edx, %rax
	imulq	$1321528399, %rax, %rax
	sarq	$39, %rax
	sarl	$31, %edx
	subl	%edx, %eax
	leal	1(%rax), %esi
	cmpl	$1, %esi
	jle	.L1380
	movl	-4(%r14), %edx
	movw	%dx, 10(%rsp)
	movl	(%r14), %ebp
	subl	%edx, %ebp
	leal	(%r15,%r15), %ecx
	addl	%eax, %r15d
	leal	(%r15,%r15), %r12d
	movl	%r11d, %r8d
	movl	%ebp, %edi
	movq	%r9, (%rsp)
	movl	%r13d, %r9d
.L1381:
	movl	%ecx, %r13d
	movl	%edi, %eax
	cltd
	idivl	%esi
	addw	10(%rsp), %ax
	movw	%ax, 112(%rsp,%r13,2)
	leal	1(%rcx), %r13d
	movl	%r8d, %eax
	cltd
	idivl	%esi
	addl	%r9d, %eax
	movw	%ax, 112(%rsp,%r13,2)
	addl	%ebp, %edi
	addl	$2, %ecx
	addl	%r11d, %r8d
	cmpl	%r12d, %ecx
	jne	.L1381
	movq	(%rsp), %r9
	jmp	.L1380
.L1403:
	movl	24(%rsp), %ebp
	movl	28(%rsp), %r13d
	movq	%r10, %r12
	leaq	ux(%rip), %rax
	movzwl	4(%rax), %r9d
	movl	$0, %r8d
	movl	$0, %ecx
	movl	$48, %edx
	movl	%r15d, %esi
	movq	56(%rsp), %rdi
	call	cr_poly
	cmpl	$2, %r13d
	jbe	.L1404
	leaq	ux(%rip), %rax
	movzwl	14(%rax), %r8d
	movl	$1056, %ecx
	movl	$64, %edx
	movl	$672, %esi
	movl	12(%rsp), %edi
	call	cr_frect
	cmpl	$1727, 16(%rsp)
	jg	.L1386
	testl	%r13d, %r13d
	jns	.L1384
	movzwl	10+ux(%rip), %r8d
	jmp	.L1387
.L1404:
	movzwl	34(%rsp), %ebx
	leal	1(%r13), %r14d
	movslq	%r13d, %r15
	movl	96(%rsp,%r15,4), %eax
	movslq	%r14d, %r14
	movl	96(%rsp,%r14,4), %esi
	subl	%eax, %esi
	addl	$1, %esi
	leal	(%rax,%rax), %eax
	leaq	112(%rsp,%rax,2), %rdi
	movl	%ebx, %r9d
	movl	$0, %r8d
	movl	$