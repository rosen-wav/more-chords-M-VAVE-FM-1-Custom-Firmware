/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the engine's three note streams -> Felucca's parts and MIDI (docs/INTEGRATION.md section 2),
 * the engine's clock and its input queue (section 4).
 *
 *   part 0 CHORD  <- stream MAIN  (the chord / performance sound: PRESETS)
 *   part 1 BASS   <- stream BASS  (the bass sound: ALGORITHM, P_VOICE = V_MONO)
 *   RAW           MIDI only (Options can route it to part 0 too)
 *
 * Everything here that touches the engine runs in the audio ISR: cr_audio_block() is called at the top of every
 * CTL-sample block, before fx.c renders it (the mix_block shim in choralroot.c / emu_firmware.h), drains the
 * events the UI posted (cr_post: a lock-free single-producer ring), ticks the engine with the sample clock and
 * emits the MIDI clock. The engine's callbacks below end in voice.c's trk_note_on / trk_note_off and usb.c's
 * midi_out_event, exactly as Felucca's seq.c key_on / key_off did. The UI never calls a note path of the engine.
 * Included after voice.c, fx.c, usb.c and cr_engine.c.
 *
 * FELUCCA_SEQ 0 (choralroot.c, the emulator, tests/cr_trans_test.c): Felucca's sequencer (seq.c with song_chain.c,
 * chord.c, motion.c, midi_control.c, midi_clock.c) is not in the unit. What the kept files called of it is here, under
 * the same names (docs/INTEGRATION.md section 1): events_block (fx.c, every block: the engine switches, the releases
 * a sound load asks for with panic_req), midi_event (the parts' MIDI in, below), and the few names upreset.c, main.c
 * and audio.c still use (transport_req, trk_index, drum_track, motion_guard / motion_base_value, chain_defaults). */

#if !FELUCCA_SEQ
/* ---------------------------------------------- what seq.c provided --- */
static volatile uint8_t panic_req;               /* bit per part: its notes released (a sound load, M-UPGRADE) */
static const uint8_t transport_req = 0;          /* (upreset.c, cr_bank.c: Felucca's transport never runs) */
#define chain_defaults(c) ((void)0)              /* (main.c felucca_init: no song chain) */
#ifdef FM1_INPUT_LAT
static uint32_t kb_out_tick;                     /* (audio.c: seq.c's key latency stamp; nothing reads it here) */
#endif
static uint32_t trk_index(const track_t *t) { return (uint32_t)(t - trk); }
static int drum_track(const track_t *t) { return ENGINES[eng_idx(t->eng_req)] == &ENG_DRUM; }
/* motion.c's: no motion lanes, so a part's sounding value is its saved one; the guard keeps the audio IRQ out while
 * a part's parameters are copied (cr_bank.c fm4_apply), as motion.c's did */
static int16_t motion_base_value(const track_t *t, uint32_t id) { return t->p[id]; }
static uint32_t motion_guard(void)
{
#if defined(FM1_IRQ_TARGET)
    uint32_t f = fm1_icfg();
    fm1_irq_off();
    return f;
#else
    return 0;
#endif
}
static void motion_unguard(uint32_t f)
{
#if defined(FM1_IRQ_TARGET)
    fm1_icfg_set(f);
#else
    (void)f;
#endif
}

/* ------------------------------------------------- the parts' MIDI in --- */
/* cr_midi_in routes Perform notes/sustain through cr_perform_input (musical engine).
 * Bass-channel notes and the native synth controllers reach this helper as
 * midi_event(status, part, d1, d2), as it handed them to midi_control.c before; what of that ChoralRoot uses:
 *   note on / off       trk_note_on / trk_note_off on the part (a repeated note-on restarts it; velocity 0: off)
 *   CC 64 sustain       a released note is held while the pedal is down, released with it
 *   pitch bend          voice.c's midi_bend_target, +-2 semitones (RPN 0 sets 0..24 semitones, 0..99 cents); FM6 bends by its
 *                       own BEND range (track_t.bend_raw, docs/FM6.md)
 *   CC 1 / 11, pressure mod.c's MODW / EXPR / AT sources (mod_midi)
 *   CC 120              all sound off: the part's voices cut (a short fade), the pedal ignored
 *   CC 121              reset controllers: bend, wheel, pressure, expression, the pedal up (the bend range kept)
 *   CC 123              all notes off: the part's MIDI notes released (the pedal honoured), the part's voices too
 *                       when no MIDI note is held then
 * Felucca's chords (CHRD), its arpeggiator and live recording were the sequencer's: gone. A part's MIDI notes and the
 * engine's stream share its voices exactly as before (a MIDI note-off ends that note, whoever started it). */
#define CR_MPED 0x80u                            /* cr_mnote: the key is up, the pedal holds the note */
typedef struct {
    int16_t bend;                                /* signed 14-bit, 0 = centre */
    uint8_t pedal, semis, cents, rpn_msb, rpn_lsb, ready;
} cr_mch_t;
static cr_mch_t cr_mch[2];                       /* parts 0 / 1 (CHORD / BASS) */
static uint8_t cr_mnote[2][128];                 /* 1: a MIDI note-on holds it; | CR_MPED: the pedal does */
static uint8_t cr_mheld[2];                      /* notes cr_mnote holds per part (CC 123's check), at most 128 */

static cr_mch_t *cr_mchan(uint32_t p)
{
    cr_mch_t *c = &cr_mch[p];
    if (!c->ready) {
        c->semis = 2;
        c->rpn_msb = c->rpn_lsb = 127;
        c->ready = 1;
    }
    return c;
}
static void cr_mbend(uint32_t p)                 /* the channel's bend -> the part's (voice.c glides to it) */
{
    const cr_mch_t *c = cr_mchan(p);
    int32_t range = ((int32_t)c->semis * 100 + c->cents) * 256 / 100;
    midi_bend_target[p] = (int32_t)c->bend * range / (c->bend < 0 ? 8192 : 8191);
    trk[p].bend_raw = c->bend;                   /* (FM6 bends by its own BEND range: its patch's, docs/FM6.md) */
}
static void cr_mrelease(uint32_t p, uint32_t note)
{
    if (cr_mnote[p][note]) {
        cr_mnote[p][note] = 0;
        if (cr_mheld[p])
            cr_mheld[p]--;
        trk_note_off(&trk[p], note);
    }
}
static void cr_mpedal_up(uint32_t p)
{
    uint32_t n;
    cr_mchan(p)->pedal = 0;
    for (n = 0; n < 128u; n++)
        if (cr_mnote[p][n] & CR_MPED)
            cr_mrelease(p, n);
}
static void cr_mforget(uint32_t p)               /* a panic: the part's MIDI notes forgotten (their offs end nothing) */
{
    if (p < 2u) {
        memset(cr_mnote[p], 0, sizeof cr_mnote[p]);
        cr_mheld[p] = 0;
    }
    midi_bend_q8[p] = midi_bend_target[p] = 0;
    trk[p].bend_raw = 0;
}
static void cr_mcontrol(uint32_t p, uint32_t cc, uint32_t v)
{
    cr_mch_t *c = cr_mchan(p);
    track_t *t = &trk[p];
    uint32_t n;
    switch (cc) {
    case 64:
        if (v >= 64u)
            c->pedal = 1;
        else
            cr_mpedal_up(p);
        break;
    case 120:                                    /* all sound off: ignores the pedal */
        trk_all_off(t);
        for (n = 0; n < NVOICE; n++)
            if (t->v[n].active)
                voice_kill(&t->v[n]);
        cr_mforget(p);
        break;
    case 121:                                    /* reset all controllers (mod_midi: wheel, pressure, expression) */
        c->bend = 0;
        c->rpn_msb = c->rpn_lsb = 127;
        cr_mbend(p);
        cr_mpedal_up(p);
        break;
    case 123:                                    /* all notes off: normal releases, the pedal honoured */
        for (n = 0; n < 128u; n++)
            if (cr_mnote[p][n] && !(cr_mnote[p][n] & CR_MPED)) {
                if (c->pedal)
                    cr_mnote[p][n] |= CR_MPED;
                else
                    cr_mrelease(p, n);
            }
        if (!cr_mheld[p])
            trk_all_off(t);
        break;
    case 101: c->rpn_msb = (uint8_t)v; break;
    case 100: c->rpn_lsb = (uint8_t)v; break;
    case 99: case 98: c->rpn_msb = c->rpn_lsb = 127; break;   /* NRPN selected: no RPN data entry */
    case 6: case 38:
        if (!c->rpn_msb && !c->rpn_lsb) {        /* RPN 0, pitch bend sensitivity */
            if (cc == 6u)
                c->semis = (uint8_t)(v > 24u ? 24u : v);
            else
                c->cents = (uint8_t)(v > 99u ? 99u : v);
            cr_mbend(p);
        }
        break;
    default: break;
    }
}
/* st: the status' high nibble (0x80..0xE0); p: the part 0 / 1 (cr_midi.c crm_map) */
static void __attribute__((noinline)) midi_event(uint32_t st, uint32_t p, uint32_t d1, uint32_t d2)
{
    if (p >= 2u)
        return;
    if (st == 0x90u && d2) {
        if (cr_mnote[p][d1])                     /* a repeated note replaces the previous press (a pedal-held one too) */
            cr_mrelease(p, d1);
        cr_mbend(p);
        trk_note_on(&trk[p], d1, d2);
        cr_mnote[p][d1] = 1;
        if (cr_mheld[p] < 128u)
            cr_mheld[p]++;
    } else if (st == 0x80u || st == 0x90u) {
        if (cr_mnote[p][d1] && cr_mchan(p)->pedal)
            cr_mnote[p][d1] |= CR_MPED;
        else
            cr_mrelease(p, d1);
    } else if (st == 0xE0u) {
        cr_mchan(p)->bend = (int16_t)((int32_t)(d1 | d2 << 7) - 8192);
        cr_mbend(p);
    } else if (st == 0xB0u) {
        mod_midi(&trk[p], st, d1, d2);
        cr_mcontrol(p, d1, d2);
    } else if (st == 0xD0u) {
        mod_midi(&trk[p], st, d1, d2);
    }
}

/* fx.c's, between two rendered blocks (after cr_audio_block): the releases asked for, the engine switches. A MIDI in
 * queue that overflowed (a lost note-off) is dropped and every part released: no stuck note */
static void cr_perform_forget(void);
static void cr_rosen_flush(void);
static void cr_chord_reconcile(void);
static void events_block(uint32_t n)
{
    uint32_t i, pr = panic_req;
    (void)n;
    panic_req = 0;
    if (midi_in_overflow) {
        mi_r = mi_w;
        cr_perform_forget();
        pr |= (1u << NTRK) - 1u;
        RING_PUBLISH();
        midi_in_overflow = 0;
    }
    for (i = 0; i < NTRK; i++) {
        if ((pr >> i) & 1u) {
            if (i < 2u)
                cr_mchan(i)->pedal = 0;
            cr_mforget(i);
            trk_all_off(&trk[i]);
        }
        engine_block(&trk[i]);                   /* engine switch: fade, then switch (voice.c) */
    }
    cr_rosen_flush();
    cr_chord_reconcile();
}
#endif /* !FELUCCA_SEQ */

/* --------------------------------------------------------------- routing --- */
#define CR_PART_CHORD 0u
#define CR_PART_BASS 1u
#define CR_NOPART 0xFFu
typedef struct {
    uint8_t part[CR_NSTREAM];        /* the Felucca part a stream plays (CR_NOPART: none) */
    uint8_t midi_en[CR_NSTREAM];     /* the stream goes out on MIDI */
    uint8_t ch[CR_NSTREAM];          /* its MIDI channel 0..15 (Orchid: 1 / 2 / 3) */
    uint8_t clock_out;               /* 24 PPQN MIDI clock out (Options > MIDI Clock: OUT) */
    uint8_t clock_in;                /* follow 0xF8 / FA / FB / FC in (Options > MIDI Clock: IN; nothing is sent) */
} cr_route_t;
/* written by the UI (Options), read by the ISR: a byte each, a change applies to the next note */
static volatile cr_route_t cr_route = {{CR_PART_CHORD, CR_PART_BASS, CR_NOPART}, {1, 1, 1}, {0, 1, 2}, 0, 0};

static cr_t cr;                                  /* the engine (owned by the audio ISR) */
static cr_loop_t crl;                            /* the looper (cr_loop.c; the audio ISR's too) */
static crl_data_t crl_stage;                     /* a slot loaded by the UI, waiting to be taken (CRE_LOOP) */
static volatile uint8_t crl_stage_busy;          /* 1: posted, 2: queued for the cycle's end; 0: the UI's again */
static volatile uint8_t crl_did;                 /* the last transport result (CRL_DID_*) .. */
static volatile uint32_t crl_did_n;              /* .. and a count of them (the UI's message) */
/* each sounding note of a stream: its MIDI channel + 1 (bits 0-4: its note-off goes there) and its part + 1 (bits 5-7:
 * a re-route never strands one); one byte for both (RAM) */
static uint8_t cr_ono[CR_NSTREAM][128];
#define CR_OCH(s, n) (cr_ono[s][n] & 31u)
#define CR_OPART(s, n) ((uint32_t)cr_ono[s][n] >> 5)
#define CR_OCH_SET(s, n, v) (cr_ono[s][n] = (uint8_t)((cr_ono[s][n] & 0xE0u) | (v)))
#define CR_OPART_SET(s, n, v) (cr_ono[s][n] = (uint8_t)((cr_ono[s][n] & 31u) | (v) << 5))
static uint32_t cr_now_ms, cr_ms_rem;            /* the engine clock: audio samples -> ms */
static uint32_t cr_clk_acc;                      /* MIDI clock: samples x bpm x 24 since the last pulse */
static volatile uint16_t cr_out_bpm = 120;       /* the tempo the clock pulses at (the UI sets it with the engine's) */
static volatile uint32_t cr_out_notes;           /* note-ons emitted (diagnostics, the emulator's dump) */
static volatile uint8_t cr_ready;                /* the engine is initialised (the ISR may run before the UI's power-on) */

static void cr_midi(uint32_t status, uint32_t d1, uint32_t d2)
{
    midi_out_event((status >> 4) | status << 8 | (d1 & 0x7Fu) << 16 | (d2 & 0x7Fu) << 24);
}

/* TRANSPOSE (the part's P_TRANS, MIX page): the part's notes play P_TRANS semitones away (clamped to 0..127). The
 * MIDI out of the stream is not transposed: it carries the harmony as played. A part's transposition is taken when
 * none of its notes from here sound (cr_tr_n: started and not ended) and kept while any does, so every note-off
 * ends the note its note-on started; a change applies from the next chord after a release */
static int8_t cr_tr[NPART];                      /* the transposition the part's sounding notes started with */
static uint8_t cr_tr_n[NPART];                   /* .. how many of them sound */
static uint32_t cr_tr_note(uint32_t p, uint32_t note)
{
    int32_t x = (int32_t)note + cr_tr[p];
    return (uint32_t)(x < 0 ? 0 : x > 127 ? 127 : x);
}
static void cr_tr_end(uint32_t p)                /* a note of part p ended */
{
    if (p < NPART && cr_tr_n[p])
        cr_tr_n[p]--;
}

/* ROSEN: the ISR requests a sound; the UI loads it; notes wait until the
 * next audio block has consumed the preset's panic and engine switch. */
static volatile uint8_t cr_rosen_mode, cr_rosen_pending;
static volatile uint32_t cr_rosen_generation;
static uint8_t cr_rosen_notes[128], cr_rosen_valid;
static uint8_t cr_chord_skipped[128];
static int16_t cr_rosen_root;
static uint8_t cr_rosen_quality, cr_rosen_extensions;
static void cr_cb_prepare(void *ud, int16_t root, uint8_t q, uint8_t ext)
{
    (void)ud;
    if (!cr.keys_only && trk[0].eng_req==ENGI_MORPH) {
        uint32_t owner=0,serial=0,slot=0;
        for(uint32_t i=0;i<CR_NVOICE;i++){
            const cr_voice_t *v=&cr.v[i];
            if(v->used && v->rq==q && v->sx==ext && v->root+v->transpose==root && v->serial>=serial){
                slot=i;serial=v->serial;owner=v->loop?(v->serial<<1)|1u:v->gid<<1;
            }
        }
        morph_chord(slot,owner);
    }
    if (cr.keys_only || !cr_rosen_mode || trk[0].eng_req==ENGI_MORPH) { cr_rosen_valid = 0; return; }
    if (cr_rosen_valid && root == cr_rosen_root && q == cr_rosen_quality && ext == cr_rosen_extensions)
        return;
    cr_rosen_valid = 1; cr_rosen_root = root;
    cr_rosen_quality = q; cr_rosen_extensions = ext;
    { uint32_t n; for (n = 0; n < 128u; n++)
        if (cr.reg[CR_STREAM_MAIN][n]) cr_rosen_notes[n] = 100; }
    cr_rosen_generation++; cr_rosen_pending = 1;
}
/* Complete generated chords: CZ-1 and Prophet omit the sixth first.
 * If the preferred tone is absent, fall back to the seventh, then the fifth.
 * They use their real root, not the lowest inversion
 * note. Only synth notes are reduced; MIDI and the BASS stream stay complete.
 * Arps/patterns/harps retain every step because they are not a held six-note chord. */
static int cr_chord_omit_tone(uint32_t p, uint32_t note)
{
    uint32_t e, i, j; int fifth = 0;
    if (p >= NPART) return 0;
    e = trk[p].eng_req;
    if ((e != ENGI_CZ && e != ENGI_PROPHET && ((e != ENGI_SWARM && e != ENGI_CLUSTER && !eng_novel(e)) && e != ENGI_CLOUD) && e != ENGI_CS1) || trk[p].p[P_VOICE] != V_POLY ||
        (cr.perform_on && cr.perform_mode != CR_PM_STRUM && cr.perform_mode != CR_PM_SLOP)) return 0;
    for (i = 0; i < CR_NVOICE; i++) {
        const cr_voice_t *v = &cr.v[i];
        if (!v->used || !v->rq) continue;
        for (j = 0; j < v->nnotes; j++) if (v->notes[j] == note) {
            uint32_t root = (uint32_t)(v->root + v->transpose + 1200) % 12u;
            uint32_t k, pc = (note + 12u - root) % 12u;
            uint32_t cap = 5u, reserved = 0, part, units;
#if CHORALROOT_DUAL_CORE
            int paired = cr_dualcore_active();
            if(paired && p == 0u)cap=6u;
#else
            int paired = 0;
#endif
            int seventh = 0, sixth = 0, omit = 0;
            /* Reserve the BASS before its note-on (MAIN is emitted first). */
            if (e == ENGI_PROPHET || ((e == ENGI_SWARM || e == ENGI_CLUSTER || eng_novel(e)) || e == ENGI_CLOUD) || e == ENGI_CS1 || paired) {
                for (part = 0; part < NPART; part++) if (part != p && VB_SAME(part,p)) {
                    uint32_t held = 0;
                    for (k = 0; k < NVOICE; k++)
                        held += trk[part].v[k].active && trk[part].v[k].gate && trk[part].v[k].stage != 4u;
                    if (part == cr_route.part[CR_STREAM_BASS] && cr.bass_on &&
                        cr.stream_on[CR_STREAM_BASS] && held == 0u) held = 1u;
                    units = voice_units(&trk[part]);
                    reserved += held * units;
                }
                cap = reserved < VBUDGET ? (VBUDGET - reserved) / ((e == ENGI_PROPHET || ((e == ENGI_SWARM || e == ENGI_CLUSTER || eng_novel(e)) || e == ENGI_CLOUD) || e == ENGI_CS1) ? 3u : 2u) : 1u;
                if (paired && p == 0u) cap += chord_worker_voices(e);
                /* BASS enabled caps Prophet at four, including one-unit basses. */
                if (!paired && cr.bass_on && cr.stream_on[CR_STREAM_BASS] &&
                    cr_route.part[CR_STREAM_BASS] < NPART &&
                    cr_route.part[CR_STREAM_BASS] != p && cap > 4u) cap = 4u;
                if (cap > (paired && p == 0u ? 6u : 5u)) cap = paired && p == 0u ? 6u : 5u;
                if (cap < 1u) cap = 1u;
            }
            for (k = 0; k < v->nnotes; k++) {
                uint32_t tone = (v->notes[k] + 12u - root) % 12u;
                if (tone == 10u || tone == 11u) seventh = 1;
                if (tone == 9u) sixth = 1;
            }
            if (v->nnotes > cap) {
                uint32_t need = v->nnotes - cap;
                if (sixth) { omit = pc == 9u; need--; }
                if (need && seventh) { omit |= pc == 10u || pc == 11u; need--; }
                if (need) omit |= pc == 7u;
            }
            /* The third is never a candidate; another chord can protect a shared note. */
            if (!omit) return 0;
            fifth = 1;
        }
    }
    return fifth;
}
/* Exact degree priorities also apply when the shared allocator or CPU guard
 * must remove a sounding generated chord note. Match actual transposed MIDI
 * notes, use the captured root, and take the strongest shared-owner priority. */
static uint32_t cr_synth_chord_rank(const track_t *t, uint32_t note)
{
    uint32_t p = (uint32_t)(t - trk), i, j, best = 0;
    int found = 0;
    uint32_t newest = 0;
    uint32_t engine=voice_alloc_engine(t);
    if(p>=NPART || p!=cr_route.part[CR_STREAM_MAIN] || !voice_chord_replace(engine))return UINT32_MAX;
    for(i=0;i<CR_NVOICE;i++)if(cr.v[i].used && cr.v[i].rq &&
        (!newest || (int32_t)(cr.v[i].serial-newest)>0))newest=cr.v[i].serial;
    for (i = 0; i < CR_NVOICE; i++) {
        const cr_voice_t *v = &cr.v[i];
        if (!v->used || !v->rq) continue;
        for (j = 0; j < v->nnotes; j++) if (cr_tr_note(p, v->notes[j]) == note) {
            uint32_t root = (uint32_t)(v->root + v->transpose + 1200) % 12u;
            uint32_t pc = (v->notes[j] + 12u - root) % 12u, rank = 3u;
            uint32_t third = (v->rq == CR_Q_MIN || v->rq == CR_Q_DIM || v->rq == CR_Q_MIN4) ? 3u : 4u;
            if (pc == 0u) rank = 5u;
            else if (pc == third && v->rq != CR_Q_SUS && v->rq != CR_Q_POW) rank = 6u;
            else if (pc == 7u) rank = 4u;
            else if (pc == 9u) rank = 0u;
            else if (pc == 10u || pc == 11u) rank = 1u;
            if(v->serial == newest)rank += 8u;
            if (!found || rank > best) best = rank;
            found = 1;
        }
    }
    return found ? best : UINT32_MAX;
}
/* Physical keyboard preference; MIDI and saved notes retain their velocity. */
static volatile uint8_t cr_dynamic_velocity = 1u;
static void cr_cb_note_on(void *ud, cr_stream_t s, uint8_t note, uint8_t vel)
{
    uint32_t p = cr_route.part[s], old;
    (void)ud;
    note &= 0x7Fu;
    /* Dynamic Velocity affects physical FM1 keys only; keep MIDI and recorded velocity. */
    if (s == CR_STREAM_MAIN && cr_rosen_pending) {
        cr_rosen_notes[note] = vel ? vel : 1u;
        return;
    }
    if (s == CR_STREAM_MAIN) cr_chord_skipped[note] = (uint8_t)cr_chord_omit_tone(p, note);
    if (p < NPART && !(s == CR_STREAM_MAIN && cr_chord_skipped[note])) {
        old = CR_OPART(s, note);
        if (old != p + 1u) {                     /* (a note already on for this part: counted once) */
            if (old)
                cr_tr_end(old - 1u);
            if (!cr_tr_n[p]) {
                int32_t tp = clamp(trk[p].p[P_TRANS], -24, 24);
#if defined(CR_TRACE) && CR_TRACE
                if (tp != cr_tr[p])
                    printf("transpose: part %u %+d\n", (unsigned)p, (int)tp);
#endif
                cr_tr[p] = (int8_t)tp;
            }
            if (cr_tr_n[p] < 255u)
                cr_tr_n[p]++;
        }
        trk_note_on(&trk[p], cr_tr_note(p, note), vel);
        CR_OPART_SET(s, note, p + 1u);
    }
    if (cr_route.midi_en[s]) {
        uint32_t ch = cr_route.ch[s] & 15u;
        cr_midi(0x90u | ch, note, vel ? vel : 1u);
        CR_OCH_SET(s, note, ch + 1u);
    }
    cr_out_notes++;
}

static void cr_cb_note_off(void *ud, cr_stream_t s, uint8_t note)
{
    (void)ud;
    note &= 0x7Fu;
    if (s == CR_STREAM_MAIN) { cr_rosen_notes[note] = 0; cr_chord_skipped[note] = 0; }
    if (CR_OPART(s, note)) {
        uint32_t p = CR_OPART(s, note) - 1u;
        trk_note_off(&trk[p], cr_tr_note(p, note));
        cr_tr_end(p);
        CR_OPART_SET(s, note, 0u);
    }
    if (CR_OCH(s, note)) {
        cr_midi(0x80u | (CR_OCH(s, note) - 1u), note, 0);
        CR_OCH_SET(s, note, 0u);
    }
}

/* panic (the engine calls it for all three streams): every voice of the part released, CC 123 on the channel */
static void cr_cb_all_off(void *ud, cr_stream_t s)
{
    uint32_t n, p = cr_route.part[s];
    (void)ud;
    if (s == CR_STREAM_MAIN) {
        memset(cr_rosen_notes, 0, sizeof cr_rosen_notes);
        memset(cr_chord_skipped, 0, sizeof cr_chord_skipped);
        cr_rosen_pending = cr_rosen_valid = 0;
    }
    for (n = 0; n < 128u; n++) {
        if (CR_OPART(s, n))
            cr_tr_end(CR_OPART(s, n) - 1u);
        if (CR_OPART(s, n) && CR_OPART(s, n) - 1u != p)
            trk_all_off(&trk[CR_OPART(s, n) - 1u]);
        if (CR_OCH(s, n) && CR_OCH(s, n) - 1u != (cr_route.ch[s] & 15u))
            cr_midi(0xB0u | (CR_OCH(s, n) - 1u), 123, 0);
        cr_ono[s][n] = 0;
    }
    if (p < NPART)
        trk_all_off(&trk[p]);
    cr_midi(0xB0u | (cr_route.ch[s] & 15u), 123, 0);   /* (always: the channel may hold another device's notes) */
}

/* a chord gesture began / ended: the looper's capture */
static void cr_cb_gesture(void *ud, uint32_t gid, int16_t root, uint8_t q, uint8_t ext, uint8_t vel, int on)
{
    (void)ud;
    cr_loop_gesture(&crl, gid, root, q, ext, vel, on);

}

static void cr_chord_reconcile(void)
{
    uint32_t n, p = cr_route.part[CR_STREAM_MAIN];
    if (cr_rosen_pending || p >= NPART) return;
    for (n = 0; n < 128u; n++) if (cr.reg[CR_STREAM_MAIN][n]) {
        int omit = cr_chord_omit_tone(p, n);
        if (omit && CR_OPART(CR_STREAM_MAIN, n)) {
            uint32_t owner = CR_OPART(CR_STREAM_MAIN, n) - 1u;
            trk_note_off(&trk[owner], cr_tr_note(owner, n));
            cr_tr_end(owner); CR_OPART_SET(CR_STREAM_MAIN, n, 0);
            cr_chord_skipped[n] = 1;
        } else if (!omit && cr_chord_skipped[n]) {
            uint8_t midi = cr_route.midi_en[CR_STREAM_MAIN];
            cr_route.midi_en[CR_STREAM_MAIN] = 0;
            cr_cb_note_on(0, CR_STREAM_MAIN, (uint8_t)n, 100);
            cr_route.midi_en[CR_STREAM_MAIN] = midi;
        }
    }
}

static void cr_rosen_flush(void)
{
    uint32_t n;
    if (cr_rosen_pending != 2u) return;
    cr_rosen_pending = 0;
    for (n = 0; n < 128u; n++) if (cr_rosen_notes[n]) {
        uint8_t vel = cr_rosen_notes[n]; cr_rosen_notes[n] = 0;
        cr_cb_note_on(0, CR_STREAM_MAIN, (uint8_t)n, vel);
    }
}
static const cr_out_t CR_OUT = {cr_cb_note_on, cr_cb_note_off, cr_cb_all_off, 0, cr_cb_gesture, cr_cb_prepare};

/* ------------------------------------------------------------ the queue --- */
/* UI -> ISR. One producer (the main loop), one consumer (the audio ISR): the index stores are the publication */
enum {
    CRE_KEY,          /* a: note, b: vel, v: down */
    CRE_MOD,          /* a: cr_mod_t, v: down */
    CRE_CHORD_LOCK, CRE_CHORD_PHYS, /* shared LOCK toggle; physical held-modifier mask */
    CRE_MIDI_CHORD_BASE, /* v: first external chord-control note, 0..118 */
    CRE_VOICING,      /* v: +-steps */
    CRE_BASS_VOICING, /* v: +-steps */
    CRE_PANIC,
    CRE_PLAYSTYLE, CRE_EXTADD, CRE_SECRET,
    CRE_GATE,         /* a: 0 Off/1 Gate, b: rate 0 eighth/1 sixteenth/2 thirty-second/3 quarter */
    CRE_SWAG,         /* v: 0 off, 1 ping pong, 2 random, 3 tennis */
    CRE_KEYS_ONLY,    /* v */
    CRE_TRANSPOSE,    /* v */
    CRE_BASS, CRE_BASS_MODE, CRE_CRYSTAL_BASS,
    CRE_PERFORM, CRE_PERFORM_MODE,
    CRE_PARAM,        /* a: mode, b: param, v: value */
    CRE_STICKY, CRE_TEMPO, CRE_STREAM, /* a: stream, v: on */
    CRE_SINGLE,       /* a: cr_single_t, v: split point 0..11 */
    CRE_LOOP          /* a: LP_*, b / v: its argument */
};
static uint8_t cr_gate_on, cr_gate_rate = 1;
static int32_t cr_gate_gain = 32768;

static uint8_t cr_sidechain_on;
static uint8_t cr_sidechain_running;
static uint32_t cr_sidechain_anchor;
static uint8_t cr_sidechain_midi_seen, cr_sidechain_midi_step;
static uint32_t cr_sidechain_midi_age, cr_sidechain_midi_stamp;
static int32_t cr_sidechain_gain = 32768; /* Q15 unity */
/* CRE_LOOP's operations */
enum { LP_REC, LP_PLAY, LP_UNDO, LP_CLEAR, LP_SET, LP_QUEUE, LP_CONF, LP_METRO, LP_IDEA };   /* LP_SET / QUEUE: b 1 = empty */
enum { LC_SYNC, LC_QUANT, LC_COUNTIN, LC_LEVEL, LC_SIG, LC_VOL, LC_TRANSPOSE, LC_SIDECHAIN, LC_MODE, LC_STEP, LC_GRID_OPEN, LC_GRID_TOGGLE, LC_GRID_DUR, LC_GRID_PREVIEW, LC_GRID_GATE, LC_GRID_MOVE };                  /* LP_CONF: b, v */
typedef struct { uint8_t op, a, b, rsv; int16_t v; } cr_ev_in_t;
#define CR_EVQ 128u                              /* a power of two */
static cr_ev_in_t cr_evq[CR_EVQ];
static volatile uint32_t cr_evq_w, cr_evq_r;
static volatile uint32_t cr_evq_lost;

static int cr_post(uint32_t op, uint32_t a, uint32_t b, int32_t v)
{
    cr_ev_in_t *e;
    if (cr_evq_w - cr_evq_r >= CR_EVQ) {
        cr_evq_lost++;                           /* (a note-off lost here: the engine's panic is the way out) */
        return 0;
    }
    e = &cr_evq[cr_evq_w % CR_EVQ];
    e->op = (uint8_t)op;
    e->a = (uint8_t)a;
    e->b = (uint8_t)b;
    e->v = (int16_t)v;
    RING_PUBLISH();
    cr_evq_w++;
    return 1;
}

static volatile uint8_t cr_grid_preview_desired;
static uint8_t cr_grid_preview_active;
static volatile int8_t cr_grid_result;
static volatile uint32_t cr_grid_result_serial;
static void cr_grid_feedback(int r){cr_grid_result=(int8_t)r;cr_grid_result_serial++;}
static void cr_loop_did(int r)
{
    crl_did = (uint8_t)r;
    crl_did_n++;
}
/* Candidate audition borrows only the four staged semantic chords. The
 * current sequence/dirty flag remain untouched; audio owns its voice/clock. */
static struct {uint32_t origin,boundary,cycle;volatile uint16_t token;volatile uint8_t active,armed,index;uint8_t voice;} cr_idea;
static void cr_idea_stop(void){
 if(cr_idea.voice)cr_loop_event(&cr,0,0,0,0,0,0);
 cr_idea.voice=cr_idea.active=cr_idea.armed=0;cr_idea.index=255u;
}
static void cr_idea_boundary(void){if(cr_idea.armed){cr_idea.origin=crl.t;cr_idea.active=1;cr_idea.armed=0;cr_idea.index=255u;}}
static void cr_idea_tick(void){
 if(crl_stage_busy!=3u){cr_idea_stop();return;}
 if(cr_idea.armed==1u && (int32_t)(crl.t-cr_idea.boundary)>=0)cr_idea_boundary();
 if(!cr_idea.active || !crl_stage.len || crl_stage.nev!=4u)return;
 if(cr_route.clock_in && (!cr_sidechain_midi_seen || cr_sidechain_midi_age>FS*300u/1000u))return;
 uint32_t elapsed=crl.t-cr_idea.origin,cycle=elapsed/crl_stage.len,pos=elapsed%crl_stage.len,index=0;
 for(uint32_t i=1;i<4u;i++)if(crl_stage.ev[i].t<=pos)index=i;
 if(index==cr_idea.index && cycle==cr_idea.cycle)return;
 if(cr_idea.voice)cr_loop_event(&cr,0,0,0,0,0,0);
 const crl_ev_t *v=&crl_stage.ev[index];
 cr_loop_event(&cr,0,v->root,v->qx>>4,v->qx&15u,v->vel,1);
 cr_idea.voice=1;cr_idea.index=(uint8_t)index;cr_idea.cycle=cycle;
}
static void cr_loop_op(const cr_ev_in_t *e)
{
    if(e->a!=LP_IDEA && e->a!=LP_CONF && e->a!=LP_METRO && (cr_idea.active||cr_idea.armed))cr_idea_stop();
    switch (e->a) {
    case LP_IDEA:
        if(crl_stage_busy!=3u || (uint16_t)e->v!=cr_idea.token || crl.cap!=CRL_CAP_NONE)break;
        if(cr_idea.active||cr_idea.armed){cr_idea_stop();break;}
        cr_loop_stop(&crl,&cr);cr_preview_clear(&cr);cr_grid_preview_active=cr_grid_preview_desired=0;
        cr_idea.armed=(uint8_t)(cr_route.clock_in?2:1);cr_idea.index=255u;
        cr_idea.boundary=crl.t+CRL_PPQN-(crl.t-crl.met0)%CRL_PPQN;
        break;
    case LP_REC: cr_loop_did(cr_loop_rec(&crl, &cr)); break;
    case LP_PLAY:
        cr_loop_did(e->b ? cr_loop_play(&crl, &cr) : cr_loop_play_synced(&crl, &cr, cr_route.clock_in));
        if(crl.state==CRL_PLAYING){cr_grid_preview_desired=cr_grid_preview_active=0;cr_preview_clear(&cr);}
        break;
    case LP_UNDO: cr_loop_did(cr_loop_undo(&crl, &cr)); break;
    case LP_CLEAR: cr_loop_did(cr_loop_clear(&crl, &cr)); break;
    case LP_SET:
        cr_loop_set(&crl, &cr, e->b ? 0 : &crl_stage);
        if(e->v==1)crl.dirty=1;
        crl_stage_busy = 0;
        break;
    case LP_QUEUE:
        cr_loop_queue(&crl, &cr, e->b ? 0 : &crl_stage);
        crl_stage_busy = crl.next_on ? 2u : 0u;    /* (the block frees it once the switch is taken) */
        break;
    case LP_METRO: cr_loop_metro(&crl, e->v); break;
    case LP_CONF:
        switch (e->b) {
        case LC_SYNC: if(crl.d.grid_global)cr_grid_feedback(cr_loop_grid_resize(&crl,&cr,(uint32_t)e->v)); else crl.sync=(uint8_t)(e->v>=0 && e->v<CRL_NSYNC?e->v:0); break;
        case LC_QUANT: crl.quant = (uint8_t)(e->v < (int)CRL_NQUANT ? e->v : 0); break;
        case LC_COUNTIN: crl.count_in = (uint8_t)(e->v != 0); break;
        case LC_LEVEL: crl.level = (uint8_t)(e->v > 100 ? 100 : e->v); break;
        case LC_SIG: if (crl.cap == CRL_CAP_NONE) crl.sig = CRL_SIG_44; break;
        case LC_SIDECHAIN: cr_sidechain_on = (uint8_t)(e->v != 0); break;
        case LC_TRANSPOSE: cr_set_loop_transpose(&cr, e->v); break;
        case LC_MODE: if(crl.cap==CRL_CAP_NONE)crl.mode=(uint8_t)(e->v>=0 && e->v<CRL_NMODE?e->v:0); break;
        case LC_STEP: cr_loop_step(&crl,e->v); break;
        case LC_GRID_OPEN: crl.grid_editor=(uint8_t)(e->v!=0); if(!e->v){cr_grid_preview_desired=cr_grid_preview_active=0;cr_preview_clear(&cr);} break;
        case LC_GRID_TOGGLE: cr_grid_feedback(cr_loop_grid_edit(&crl,&cr,(uint32_t)e->v,-1)); break;
        case LC_GRID_DUR: {
            uint32_t step=(uint32_t)e->v>>8;
            int rate=(int)cr_loop_grid_rate(&crl,step)+(int8_t)e->v;
            cr_grid_feedback(cr_loop_grid_edit(&crl,&cr,step,rate<0?0:rate>4?4:rate)); break;
        }
        case LC_GRID_GATE: cr_grid_feedback(cr_loop_grid_gate_edit(&crl,&cr,(uint32_t)e->v>>8,(int8_t)e->v)); break;
        case LC_GRID_MOVE: {
            uint32_t from=((uint16_t)e->v)>>8,to=(uint8_t)e->v;
            int result=cr_loop_grid_move(&crl,&cr,from,to);
            cr_grid_feedback(result);
            if(result>0 && cr_grid_preview_desired){
                cr_grid_preview_active=(uint8_t)(cr_loop_grid_preview(&crl,&cr,to,crl.grid_editor)>0);
            }
            break;
        }
        case LC_GRID_PREVIEW: {
            int on=e->v>=0 && cr_grid_preview_desired && crl.grid_editor;
            int count=cr_loop_grid_preview(&crl,&cr,e->v<0?0u:(uint32_t)e->v,on);
            cr_grid_preview_active=(uint8_t)(count>0);
            if(count<0)cr_grid_feedback(-3);
            break;
        }
        case LC_VOL: crl.metro_vol = (uint8_t)(e->v > 100 ? 100 : e->v); break;
        default: break;
        }
        break;
    default: break;
    }
}

/* MIDI Perform enters the musical engine, not the native synth note API.
 * Physical keys, USB and TRS have separate key IDs; a release cannot end
 * another source's identical root. Bass-channel MIDI remains a direct input. */
static uint8_t cr_perform_note[2][128], cr_perform_pedal[2];
static uint8_t cr_perform_en, cr_perform_ch;
/* External chord block: configurable first note, independent of OCT. */
static uint8_t cr_perform_base = 53u;
#define CR_MIDI_NOT_CONTROL 254u
static uint8_t cr_midi_mod_map[11];
static void cr_perform_map_build(void)
{
    static const uint8_t white[5] = {CR_MOD_6, CR_MOD_M7, CR_MOD_MAJ7, 255u, CR_MOD_9};
    static const uint8_t black[4] = {CR_MOD_DIM, CR_MOD_MIN, CR_MOD_MAJ, CR_MOD_SUS};
    uint32_t w = 0, b = 0;
    for (uint32_t k = 0; k < 11u; k++) {
        uint32_t note = (uint32_t)cr_perform_base + k;
        cr_midi_mod_map[k] = CR_MIDI_NOT_CONTROL;
        if (note > 127u) continue;
        if ((0x54Au >> (note % 12u)) & 1u) {
            if (b < 4u) cr_midi_mod_map[k] = black[b++];
        } else if (w < 5u) cr_midi_mod_map[k] = white[w++];
    }
}
static uint8_t cr_mmod_held[2], cr_mmod_kill[2], cr_mmod_latch;
static uint8_t cr_mlock, cr_mlock_held, cr_phys_mods, cr_phys_held;

static uint32_t cr_mmods(void) { return cr_mmod_held[0] | cr_mmod_held[1]; }
static void cr_mmod_up(uint32_t m)
{
    uint32_t bit = 1u << m;
    if (!((cr_mmods() | cr_mmod_latch | cr_phys_mods) & bit)) cr_mod(&cr, (cr_mod_t)m, 0);
}
static void cr_mmod_unlatch(void)
{
    uint32_t old = cr_mmod_latch; cr_mmod_latch = 0;
    for (uint32_t m = 0; m < CR_NMOD; m++) if (old & (1u << m)) cr_mmod_up(m);
}
static void cr_chord_lock_toggle(void)
{
    cr_mlock ^= 1u;
    if (!cr_mlock) {
        uint32_t old = cr_phys_mods & (uint32_t)~cr_phys_held;
        cr_mmod_unlatch();
        cr_phys_mods &= cr_phys_held;
        for (uint32_t m = 0; m < CR_NMOD; m++) if (old & (1u << m)) cr_mmod_up(m);
    }
}
static void cr_chord_replace_quality(uint32_t bit)
{
    uint32_t old = (cr_mmod_latch | (cr_phys_mods & (uint32_t)~cr_phys_held)) & 15u & ~bit;
    cr_mmod_latch &= (uint8_t)~15u;
    cr_phys_mods &= (uint8_t)~(15u & (uint32_t)~cr_phys_held & ~bit);
    for (uint32_t m = 0; m < 4u; m++) if (old & (1u << m)) cr_mmod_up(m);
}
static void cr_mmod_key(uint32_t source, uint32_t m, int down)
{
    uint32_t bit, others;
    if (m == 255u) {
        bit = 1u << source;
        if (down && !(cr_mlock_held & bit)) {
            cr_chord_lock_toggle();
        }
        if (down) cr_mlock_held |= (uint8_t)bit;
        else cr_mlock_held &= (uint8_t)~bit;
        return;
    }
    bit = 1u << m;
    if (down) {
        if (cr_mmod_held[source] & bit) return;
        others = cr_mmods() & ~bit;
        cr_mmod_held[source] |= (uint8_t)bit;
        cr_mmod_kill[source] &= (uint8_t)~bit;
        if (m == CR_MOD_M7 || m == CR_MOD_MAJ7) {
            uint32_t other = 1u << (m == CR_MOD_M7 ? CR_MOD_MAJ7 : CR_MOD_M7);
            cr_mmod_latch &= (uint8_t)~other;
            cr_phys_mods &= (uint8_t)~other;
            for (uint32_t src = 0; src < 2u; src++)
                cr_mmod_kill[src] |= (uint8_t)(cr_mmod_held[src] & other);
        }
        if (cr_mlock && !(others | (cr_phys_held & ~bit)) && (cr_mmod_latch | (cr_phys_mods & (uint32_t)~cr_phys_held))) {
            if (m <= CR_MOD_SUS) {
                cr_chord_replace_quality(bit);
            } else if ((cr_mmod_latch | (cr_phys_mods & (uint32_t)~cr_phys_held)) & bit) {
                cr_mmod_latch &= (uint8_t)~bit;
                cr_phys_mods &= (uint8_t)~bit;
                cr_mmod_kill[source] |= (uint8_t)bit;
                cr_mod(&cr, (cr_mod_t)m, 0);
                return;
            }
        }
        cr_mod(&cr, (cr_mod_t)m, 1);
    } else {
        if (!(cr_mmod_held[source] & bit)) return;
        cr_mmod_held[source] &= (uint8_t)~bit;
        if (cr_mmod_kill[source] & bit) cr_mmod_kill[source] &= (uint8_t)~bit;
        else if (cr_mlock) cr_mmod_latch |= (uint8_t)bit;
        else cr_mmod_up(m);
    }
}
static void cr_mmod_release_source(uint32_t source)
{
    /* Channel panic releases control keys immediately, regardless of sustain. */
    uint32_t held = cr_mmod_held[source];
    cr_mmod_held[source] = cr_mmod_kill[source] = 0;
    cr_mlock_held &= (uint8_t)~(1u << source);
    for (uint32_t m = 0; m < CR_NMOD; m++) if (held & (1u << m)) cr_mmod_up(m);
}


static void cr_live_key(uint32_t note, uint32_t id, uint32_t vel, int down, int force)
{
    uint8_t bit = (uint8_t)(1u << id), others;
    int vi;
    if (note >= 128u || id > 2u) return;
    if (!down && !(cr.phys[note] & bit)) return;
    others = cr.phys[note] & (uint8_t)~bit;
    if (!down) {
        vi = crx_find_voice(&cr, (int)note);
        if (vi >= 0 && cr.v[vi].id == id && others) {
            uint32_t next = 0;
            while (!(others & (1u << next))) next++;
            cr.v[vi].id = (uint8_t)next;
            cr.v[vi].superseded &= (uint8_t)~(1u << next);
        }
        /* Explicit MIDI panic also clears a Sticky/arp-Hold owner. */
        if (force && !others && vi >= 0) crx_kill_voice(&cr, vi);
    }
    cr_key_ex(&cr, (uint8_t)note, (uint8_t)id, (uint8_t)vel, down);
    if (force) crx_keys_bass_sync(&cr);
    if (!down && !force && crl.cap == CRL_CAP_STEP && !crl.grid_editor && !cr.phys_n)
        cr_loop_step(&crl, CRL_STEP_KEYSUP);
}

static void cr_perform_release(uint32_t source, uint32_t note, int force)
{
    if (cr_perform_note[source][note]) {
        cr_perform_note[source][note] = 0;
        cr_live_key(note, source + 1u, 0, 0, force);
    }
}
static void cr_perform_drop_latched(uint32_t source)
{
    for (int vi = 0; vi < CR_MAX_VOICES; vi++) {
        cr_voice_t *v = &cr.v[vi];
        if (v->used && !v->is_free && v->id == source + 1u && !cr.phys[v->key])
            crx_kill_voice(&cr, vi);
    }
    crx_keys_bass_sync(&cr);
}
static void cr_perform_forget(void)
{
    for (uint32_t source = 0; source < 2u; source++) {
        for (uint32_t note = 0; note < 128u; note++)
            cr_perform_release(source, note, 1);
        cr_perform_pedal[source] = 0;
        cr_perform_drop_latched(source);
        cr_mmod_release_source(source);
    }
    cr_mmod_unlatch();
}
static void cr_perform_input(uint32_t st, uint32_t note, uint32_t vel, uint32_t source)
{
    source = source == 2u ? 1u : 0u; /* queue tags: USB=1, TRS=2 */
    if (!cr.keys_only && note >= cr_perform_base && note < (uint32_t)cr_perform_base + 11u && (st == 0x80u || st == 0x90u)) {
        uint32_t control = cr_midi_mod_map[note - cr_perform_base];
        if (control != CR_MIDI_NOT_CONTROL) {
            cr_mmod_key(source, control, st == 0x90u && vel != 0u);
            return;
        }
    }
    if (st == 0x90u && vel) {
        cr_perform_note[source][note] = 1;
        cr_mbend(0);
        cr_live_key(note, source + 1u, vel, 1, 0);
    } else if (st == 0x80u || st == 0x90u) {
        if (cr_perform_note[source][note] && cr_perform_pedal[source])
            cr_perform_note[source][note] |= CR_MPED;
        else cr_perform_release(source, note, 0);
    } else if (st == 0xB0u && (note == 64u || note == 120u || note == 121u || note == 123u)) {
        if (note == 64u && vel >= 64u) { cr_perform_pedal[source] = 1; return; }
        if (note == 64u || note == 121u || note == 120u) cr_perform_pedal[source] = 0;
        for (uint32_t n = 0; n < 128u; n++) {
            if (note == 123u && cr_perform_pedal[source] && cr_perform_note[source][n])
                cr_perform_note[source][n] |= CR_MPED;
            else if (note == 120u || note == 123u || (cr_perform_note[source][n] & CR_MPED))
                cr_perform_release(source, n, note == 120u);
        }
        if (note == 120u || note == 123u) cr_mmod_release_source(source);
        if (note == 120u) { cr_perform_drop_latched(source); cr_mmod_unlatch(); }
        if (note == 121u) midi_event(st, 0, note, vel);
    } else midi_event(st, 0, note, vel);
}

static void cr_apply(const cr_ev_in_t *e)
{
    switch (e->op) {
    case CRE_KEY:
        cr_live_key(e->a, 0, e->b, e->v != 0, 0);
        break;
    case CRE_MOD:
        if (e->a < CR_NMOD) {
            uint32_t bit = 1u << e->a;
            if (e->v) {
                if (e->a == CR_MOD_M7 || e->a == CR_MOD_MAJ7) {
                    uint32_t other = 1u << (e->a == CR_MOD_M7 ? CR_MOD_MAJ7 : CR_MOD_M7);
                    cr_mmod_latch &= (uint8_t)~other; cr_phys_mods &= (uint8_t)~other;
                    for (uint32_t src = 0; src < 2u; src++) cr_mmod_kill[src] |= (uint8_t)(cr_mmod_held[src] & other);
                }
                if (cr_mlock && e->a <= CR_MOD_SUS && !((cr_mmods() | cr_phys_held) & ~bit))
                    cr_chord_replace_quality(bit);
                cr_phys_mods |= (uint8_t)bit; cr_mod(&cr, (cr_mod_t)e->a, 1);
            }
            else if (!(cr_mlock && !(cr_phys_held & bit) && (cr_phys_mods & bit))) {
                /* A real release obeys shared LOCK even before the UI has seen a MIDI toggle.
                 * An up posted during a held-key press is an explicit latch toggle. */
                if (cr_mlock && (cr_phys_held & bit)) cr_mmod_latch &= (uint8_t)~bit;
                cr_phys_mods &= (uint8_t)~bit; cr_mmod_up(e->a);
            }
        }
        break;
    case CRE_CHORD_LOCK: cr_chord_lock_toggle(); break;
    case CRE_CHORD_PHYS: cr_phys_held = (uint8_t)e->v; break;
    case CRE_MIDI_CHORD_BASE:
        if (e->v >= 0 && e->v <= 118 && cr_perform_base != (uint8_t)e->v) {
            cr_perform_forget(); /* old note-offs must not be decoded against a new map */
            cr_mlock = cr_mlock_held = 0;
            cr_perform_base = (uint8_t)e->v;
            cr_perform_map_build();
        }
        break;
    case CRE_VOICING: cr_voicing_step(&cr, e->v); break;
    case CRE_BASS_VOICING: cr_bass_voicing_step(&cr, e->v); break;
    case CRE_PANIC: cr_idea_stop();cr_perform_forget(); cr_phys_mods = cr_phys_held = 0; cr_panic(&cr); cr_loop_panic(&crl); break;
    case CRE_PLAYSTYLE: cr_set_playstyle(&cr, (cr_playstyle_t)e->v); break;
    case CRE_EXTADD: cr_set_ext_addition(&cr, (cr_extadd_t)e->v); break;
    case CRE_SECRET: cr_set_secret(&cr, (cr_secret_t)e->v); break;
    case CRE_GATE:
        cr_gate_on = (uint8_t)(e->a <= 1u ? e->a : 0u);
        cr_gate_rate = (uint8_t)(e->b < 4u ? e->b : 1u);
        break;
    case CRE_SWAG: cr_set_swag(&cr, e->v); break;
    case CRE_KEYS_ONLY:
        if (cr_mlock) cr_chord_lock_toggle();
        if (cr.keys_only != (e->v != 0)) cr_perform_forget();
        if (cr.keys_only != (e->v != 0)) { cr_phys_mods = cr_phys_held = 0; cr_mlock = cr_mlock_held = 0; }
        cr_set_keys_only(&cr, e->v); break;
    case CRE_TRANSPOSE: cr_set_transpose(&cr, e->v); break;
    case CRE_CRYSTAL_BASS: cr_set_crystal_bass(&cr, e->v); break;
    case CRE_BASS: cr_set_bass(&cr, e->v); break;
    case CRE_BASS_MODE: cr_set_bass_mode(&cr, (cr_bassmode_t)e->v); break;
    case CRE_PERFORM: cr_set_perform(&cr, e->v); break;
    case CRE_PERFORM_MODE: cr_set_perform_mode(&cr, (cr_pmode_t)e->v); break;
    case CRE_PARAM: cr_set_param(&cr, (cr_pmode_t)e->a, (cr_eparam_t)e->b, e->v); break;
    case CRE_STICKY: cr_set_sticky(&cr, e->v); break;
    case CRE_TEMPO: cr_set_tempo(&cr, e->v); cr_out_bpm = (uint16_t)e->v; break;
    case CRE_STREAM: cr_set_stream(&cr, (cr_stream_t)e->a, e->v); break;
    case CRE_SINGLE: cr_set_single_notes(&cr, (cr_single_t)e->a, e->v); break;
    case CRE_LOOP: cr_loop_op(e); break;
    default: break;
    }
}

/* ------------------------------------------------------------- MIDI in --- */
/* usb.c's midi_in_q (USB and TRS) is drained here, in the audio ISR, before fx.c's events_block runs in the same block
 * (its overflow recovery stays there: on an overflow the queue is left to it).
 *   0xF8 / FA / FB / FC   Options > MIDI Clock = In: the tempo (cr_midi.c's follower -> cr_set_tempo) and the loop's
 *                         transport (the LP_PLAY path); otherwise ignored
 *   the CHORD / BASS channels (Options' channels; Off: ignored): CC 7 / 91 / 93 / 94 and program changes go to the UI
 *                         (cr_min_q: it applies them as a knob would, with the meter); notes, pedal, bend, pressure and
 *                         controllers reach the native synth; Perform notes/sustain enter the chord engine.
 *   other channels        ignored */
#include "cr_midi.c"
static crm_clock_t cr_cin;
static uint8_t cr_cin_mode;                      /* clock_in as last seen (a change resets the follower) */
static volatile uint16_t cr_in_bpm;              /* the tempo the clock set (the UI mirrors it into cs.bpm) .. */
static volatile uint32_t cr_in_bpm_n;            /* .. and a count of its changes */
static volatile uint32_t cr_in_rt_n;             /* start / stop received (In) */
static volatile uint8_t cr_in_rt_last;
#define CR_MINQ 32u                              /* ISR -> UI: CC / program change (a power of two) */
static crm_act_t cr_minq[CR_MINQ];
static volatile uint32_t cr_minq_w, cr_minq_r;

static void cr_min_post(const crm_act_t *a)
{
    if (cr_minq_w - cr_minq_r >= CR_MINQ)
        return;                                  /* (a burst of controllers: the latest values lost, nothing stuck) */
    cr_minq[cr_minq_w % CR_MINQ] = *a;
    RING_PUBLISH();
    cr_minq_w++;
}
static int cr_min_take(crm_act_t *a)             /* the UI */
{
    if (cr_minq_r == cr_minq_w)
        return 0;
    *a = cr_minq[cr_minq_r % CR_MINQ];
    RING_PUBLISH();
    cr_minq_r++;
    return 1;
}

static void cr_loop_op(const cr_ev_in_t *e);
static void cr_in_transport(uint32_t st)         /* FA start / FB continue: the loop plays (FA: from its start); FC */
{
    if(crl_stage_busy==3u){
        cr_idea_stop();cr_loop_stop(&crl,&cr);
        if(st!=0xFCu){cr_idea.origin=crl.t;cr_idea.index=255u;cr_idea.active=1;cr_idea.armed=0;}
        return;
    }
    cr_ev_in_t e = {CRE_LOOP, LP_PLAY, 1, 0, 0};
    int n;
    crl.play_armed = 0; /* MIDI transport supersedes a manual pending start. */
    cr_in_rt_last = (uint8_t)st;
    cr_in_rt_n++;
    n = crm_transport(st, crl.state == CRL_PLAYING, crl.state == CRL_STOPPED, crl.cap != CRL_CAP_NONE);
    while (n-- > 0)
        cr_loop_op(&e);
}

static volatile int8_t cr_nudge_request;
static volatile uint8_t cr_nudge_up,cr_nudge_down;
static uint8_t cr_nudge_up_seen,cr_nudge_down_seen;
static int8_t cr_nudge_last_dir;
static uint32_t cr_nudge_held;
static int32_t cr_nudge_debt;
static uint32_t cr_nudge_rem;
static int32_t cr_nudge_phase_samples;
static void cr_midi_in(void)
{
    uint32_t w = mi_w;
    uint8_t en[2], ch[2];
    if (cr_cin_mode != cr_route.clock_in) {
        if (crl.play_armed && crl.play_armed != (cr_route.clock_in ? 2u : 1u))
            crl.play_armed = 0; /* Cancel only a request made for the old clock source. */
        if(cr_idea.armed && cr_idea.armed!=(cr_route.clock_in?2u:1u))cr_idea_stop();
        cr_cin_mode = cr_route.clock_in;
        cr_nudge_phase_samples=0;cr_nudge_rem=0;cr_nudge_debt=0;
        cr_nudge_up_seen=cr_nudge_up;cr_nudge_down_seen=cr_nudge_down;
        crm_clock_reset(&cr_cin);
        cr_sidechain_midi_seen = cr_sidechain_midi_step = 0;
        cr_sidechain_running = 0;
    }
    if (midi_in_overflow)                        /* events_block's recovery: the queue dropped, every part released */
        return;
    en[0] = cr_route.midi_en[CR_STREAM_MAIN];
    en[1] = cr_route.midi_en[CR_STREAM_BASS];
    ch[0] = cr_route.ch[CR_STREAM_MAIN];
    ch[1] = cr_route.ch[CR_STREAM_BASS];
    if (cr_perform_en != en[0] || cr_perform_ch != ch[0]) {
        cr_perform_forget();
        cr_perform_en = en[0]; cr_perform_ch = ch[0];
    }
    while (mi_r != w) {
        uint32_t at = mi_r % MQ, pkt = midi_in_q[at], status = (pkt >> 8) & 0xFFu;
        uint32_t d1 = (pkt >> 16) & 0x7Fu, d2 = (pkt >> 24) & 0x7Fu, ms = midi_in_ms[at];
        uint32_t source = midi_in_source[at];
        mi_r++;
        if (status >= 0xF8u) {
            if (!cr_cin_mode)
                continue;
            if (status == 0xF8u) {
                uint32_t prev_w = cr_cin.w;
                int b = crm_clock_pulse(&cr_cin, ms);
                if (cr_cin.w != prev_w) { /* accepted pulses only: ignore duplicates/bursts */
                    int32_t lag = (int32_t)(fm1_ms - ms);
                    if (!cr_sidechain_midi_seen || ms - cr_sidechain_midi_stamp > 150u)
                        cr_sidechain_midi_step = 0;
                    else cr_sidechain_midi_step = (uint8_t)((cr_sidechain_midi_step + 1u) % 24u);
                    cr_sidechain_midi_seen = 1;
                    cr_sidechain_midi_stamp = ms;
                    cr_sidechain_midi_age = (uint32_t)clamp(lag, 0, 301) * FS / 1000u;
                    if (cr_sidechain_midi_step == 0u && cr_cin.bpm) {cr_loop_play_boundary(&crl, &cr);if(cr_idea.armed==2u)cr_idea_boundary();}
                }
                if (b) {
                    cr_in_bpm = (uint16_t)b;
                    cr_in_bpm_n++;
                }
                if (cr_cin.bpm && cr.bpm != cr_cin.bpm) {    /* (a SELECT turn meanwhile: the clock wins) */
                    cr_set_tempo(&cr, cr_cin.bpm);
                    cr_out_bpm = cr_cin.bpm;
                    if (!b)
                        cr_in_bpm_n++;
                }
            } else if (status == 0xFAu || status == 0xFBu || status == 0xFCu) {
                if (status == 0xFAu) {cr_sidechain_midi_seen = cr_sidechain_midi_step = 0;cr_nudge_phase_samples=0;cr_nudge_debt=0;cr_nudge_up_seen=cr_nudge_up;cr_nudge_down_seen=cr_nudge_down;}
                cr_in_transport(status);
            }
        } else if (status >= 0x80u && status < 0xF0u) {
            crm_act_t a[2];
            int i, n = crm_map(status, d1, d2, en, ch, a);
            for (i = 0; i < n; i++) {
                if (a[i].kind == CRM_FORWARD) {
                    if (a[i].part == 0u)
                        cr_perform_input(status & 0xF0u, d1, d2, source);
                    else midi_event(status & 0xF0u, a[i].part, d1, d2);
                }
                else
                    cr_min_post(&a[i]);
            }
        }
    }
}

/* ------------------------------------------------------- the audio side --- */
/* A brief tap adds 2ms of phase, paid smoothly at <=25% clock bend.
 * Held bend is immediately15%, increasing to25% after500ms. All time
 * remains monotonic; release keeps the phase without altering the BPM. */
static uint32_t cr_nudge_samples(uint32_t n){
 uint8_t up=cr_nudge_up,down=cr_nudge_down;
 uint32_t nu=(uint8_t)(up-cr_nudge_up_seen),nd=(uint8_t)(down-cr_nudge_down_seen);
 cr_nudge_up_seen=up;cr_nudge_down_seen=down;
 if(nu>16u)nu=16u;if(nd>16u)nd=16u;
 cr_nudge_debt=clamp(cr_nudge_debt+((int32_t)nu-(int32_t)nd)*(FS/500u),-(int32_t)(FS/10u),(int32_t)(FS/10u));
 int32_t dir=cr_nudge_request,shift=0;
 if(dir!=cr_nudge_last_dir){cr_nudge_held=cr_nudge_rem=0;cr_nudge_last_dir=(int8_t)dir;}
 if(dir){
  uint32_t rate=cr_nudge_held<FS/2u?150u:250u;
  uint32_t q=n*rate+cr_nudge_rem;cr_nudge_rem=q%1000u;
  shift=dir>0?(int32_t)(q/1000u):-(int32_t)(q/1000u);
  if(cr_nudge_held<FS*2u)cr_nudge_held+=n;
 }else{cr_nudge_held=cr_nudge_rem=0;}
 int32_t maxstep=(int32_t)(n/4u);if(!maxstep)maxstep=1;
 int32_t kick=clamp(cr_nudge_debt,-maxstep,maxstep);
 cr_nudge_debt-=kick;shift+=kick;
 cr_nudge_phase_samples+=shift;
 if(cr_nudge_phase_samples>=(int32_t)(FS*60u))cr_nudge_phase_samples-=(int32_t)(FS*60u);
 if(cr_nudge_phase_samples<=-(int32_t)(FS*60u))cr_nudge_phase_samples+=(int32_t)(FS*60u);
 return (uint32_t)((int32_t)n+shift);
}
static uint32_t cr_nudge_external_phase(void){
 return (uint32_t)(((int64_t)cr_nudge_phase_samples*cr.bpm*1048576)/(FS*60u));
}
static void cr_out_init(void)                    /* power-on (the audio ISR may already run: IRQ off) */
{
    fm1_irq_off();
    cr_ready = 0;
    cr_perform_base = 53u;
    cr_perform_map_build();
    memset(cr_perform_note, 0, sizeof cr_perform_note);
    memset(cr_perform_pedal, 0, sizeof cr_perform_pedal);
    memset(cr_mmod_held, 0, sizeof cr_mmod_held);
    memset(cr_mmod_kill, 0, sizeof cr_mmod_kill);
    cr_mmod_latch = cr_mlock = cr_mlock_held = cr_phys_mods = cr_phys_held = 0;
    cr_perform_en = cr_route.midi_en[CR_STREAM_MAIN];
    cr_perform_ch = cr_route.ch[CR_STREAM_MAIN];
    cr_init(&cr, &CR_OUT);
    cr_seed(&cr, 0x43524631u);
    voice_fade_steal = 1;                        /* voice.c: a stolen voice fades out, its new note waits a block */
    fx_smooth = 1;                               /* fx.c: the limiter's gain eased (no audio-rate crackle), the delay's
                                                  * new times crossfaded (no click on a tempo change) */
    cr_loop_init(&crl);
    crl_stage_busy = 0;memset(&cr_idea,0,sizeof cr_idea);cr_idea.index=255u;
    cr_now_ms = cr_ms_rem = cr_clk_acc = 0;
    cr_nudge_request=0;cr_nudge_rem=0;cr_nudge_phase_samples=0;
    cr_nudge_up=cr_nudge_down=cr_nudge_up_seen=cr_nudge_down_seen=0;
    cr_nudge_last_dir=0;cr_nudge_held=0;cr_nudge_debt=0;
    cr_evq_r = cr_evq_w = 0;
    cr_gate_on=0; cr_gate_rate=1; cr_gate_gain=32768;

    cr_sidechain_on = cr_sidechain_running = 0; cr_sidechain_anchor = 0; cr_sidechain_gain = 32768;
    cr_sidechain_midi_seen = cr_sidechain_midi_step = 0;
    cr_sidechain_midi_age = cr_sidechain_midi_stamp = 0;
    cr_ready = 1;
    fm1_irq_on();
}

/* MIDI start / stop with the loop (Options > MIDI Clock = Out): 0xFA when it starts playing (LOOP from stopped, a
 * take committed into playback), 0xFC when it stops; the UI traces them (cr_rt_n, cr_rt_last) */
static uint8_t cr_rt_was;
static volatile uint32_t cr_rt_n;
static volatile uint8_t cr_rt_last;

/* the audio ISR, once per CTL-sample block, before the block renders: input, the scheduler, the clock */
static void cr_audio_block(uint32_t n)
{
    uint32_t w = cr_evq_w;
    voice_chord_rank = cr_synth_chord_rank;
    if (!cr_ready)
        return;
    while (cr_evq_r != w) {
        cr_apply(&cr_evq[cr_evq_r % CR_EVQ]);
        cr_evq_r++;
    }
    /* A dropped release event must never leave an audition owner sounding. */
    if(cr_grid_preview_active && !cr_grid_preview_desired){cr_preview_clear(&cr);cr_grid_preview_active=0;}
    cr_midi_in();
    if (!cr.keys_only && cr.playstyle == CR_PS_SIMPLE) {
        uint32_t expired = (uint32_t)~cr.mods_down & 240u;
        cr_mmod_latch &= (uint8_t)~expired;
        cr_phys_mods &= (uint8_t)~expired;
        for (uint32_t src = 0; src < 2u; src++)
            cr_mmod_kill[src] |= (uint8_t)(cr_mmod_held[src] & expired);
    }
    if (cr_sidechain_midi_seen && cr_sidechain_midi_age < FS)
        cr_sidechain_midi_age += n; /* sample age: independent of the HAL/engine ms origins */
    uint32_t clock_samples=cr_nudge_samples(n);
    cr_ms_rem += clock_samples * 1000u;                      /* samples -> ms, the remainder kept (no drift) */
    while (cr_ms_rem >= FS) {
        cr_ms_rem -= FS;
        cr_now_ms++;
    }
    cr_tick(&cr, cr_now_ms);
    cr_loop_tick(&crl, &cr, cr_now_ms);
    cr_idea_tick();          /* the loop's playback and capture, the click */
    if (crl.state == CRL_PLAYING && cr_grid_preview_active) {
        cr_grid_preview_desired = cr_grid_preview_active = 0; cr_preview_clear(&cr);
    }
    /* Same clock origin as Gate and the looper; external clock freezes
     * on loss instead of inventing new bass notes. Twelve MIDI ticks = 1/8. */
    if (cr_route.clock_in) {
        if (cr_sidechain_midi_seen && cr_cin.bpm && cr_sidechain_midi_age <= FS * 300u / 1000u)
            cr_bass_clock_phase(&cr, ((cr_sidechain_midi_step*1048576u/24u+cr_nudge_external_phase())&1048575u)>=524288u);
    } else cr_bass_clock_phase(&cr, ((crl.t - crl.met0) % CRL_PPQN) >= CRL_PPQN / 2u);

    if (crl_stage_busy == 2u && !crl.next_on)
        crl_stage_busy = 0;
    if ((crl.state == CRL_PLAYING) != cr_rt_was) {
        cr_rt_was = crl.state == CRL_PLAYING;
        if (cr_route.clock_out && !cr_route.clock_in) {   /* USB MIDI CIN 0x0F: a single-byte system real-time message */
            cr_rt_last = cr_rt_was ? 0xFAu : 0xFCu;
            if (cr_rt_was)
                cr_clk_acc = 0;                  /* the pulses start with it */
            midi_out_event(0x0Fu | (uint32_t)cr_rt_last << 8);
            cr_rt_n++;
        }
    }
    if (cr_route.clock_out && !cr_route.clock_in) {   /* 24 PPQN: a pulse every FS * 60 / (bpm * 24) samples */
        cr_clk_acc += clock_samples * (uint32_t)cr_out_bpm * 24u;
        while (cr_clk_acc >= FS * 60u) {
            cr_clk_acc -= FS * 60u;
            midi_out_event(0x0Fu | 0xF8u << 8);
        }
    } else {
        cr_clk_acc = 0;
    }
}

/* the metronome's click (crl.click, set by the loop's clock in this block): a decaying sine, 1.5 kHz on a beat and
 * 2.5 kHz on the bar's first, from a two-pole resonator (Q14), mixed after fx.c's master (the mix_block shim) */
static int32_t cr_ck_y1, cr_ck_y2, cr_ck_a1;
static uint32_t cr_ck_n, cr_ck_wait;
#define CR_CK_A2 16335                           /* r^2, r = 0.9985 per sample: ~25 ms */
/* Quarter-note master ducking, internal clock or phase-locked MIDI Clock in.
 * One phase conversion per block; only bounded integer arithmetic per sample.
 * The master control/limiter and recorded loop data are never changed. */
/* Post-master tempo effects keep Clean's fractional bits; Classic remains bit-identical. */
static void cr_output_gain(int32_t *out, uint32_t i, int32_t gain)
{
    if (gain == 32768) return; /* Exact bypass, no work on quiet/off tempo effects. */
    uint32_t k, sh = fx_usb_fixed ? 2u : 7u;
    for (k = 2u * i; k < 2u * i + 2u; k++) {
        if (fx_out_blk) {
            uint32_t j = k & (2u * CTL - 1u);
            int32_t x = out[k] * (int32_t)(1u << sh) + out_frac[j];
            x = clean_gain(x, gain);
            out[k] = x >> sh;
            out_frac[j] = (uint8_t)(x & ((1u << sh) - 1u));
        } else out[k] = mulq15(out[k], gain);
    }
}
static void cr_sidechain_mix(int32_t *out, uint32_t n)
{
    uint32_t i, phase = 0, inc = 0;
    int external = cr_route.clock_in != 0;
    int clock_live = !external || (cr_sidechain_midi_seen && cr_cin.bpm &&
                                     cr_sidechain_midi_age <= FS * 300u / 1000u);
    int active = cr_sidechain_on && clock_live;
    if (!active) cr_sidechain_running = 0;
    else if (!cr_sidechain_running) { cr_sidechain_anchor = crl.state == CRL_PLAYING ? crl.cyc0 : crl.met0; cr_sidechain_running = 1; }
    if (!active && cr_sidechain_gain == 32768) return; /* exact bypass */
    if (active) {
        if (external) {
            phase = cr_sidechain_midi_step * 1048576u / 24u +
                    (uint32_t)((uint64_t)cr_sidechain_midi_age * cr.bpm * 1048576u / (FS * 60u)) + cr_nudge_external_phase();
        } else {
            uint32_t tick = (crl.t - cr_sidechain_anchor) % CRL_PPQN;
            phase = (uint32_t)(((uint64_t)(tick * 60000u + crl.acc) << 20) / (CRL_PPQN * 60000u));
        }
        inc = (uint32_t)(cr.bpm ? cr.bpm : 120u) * 1048576u / (FS * 60u);
    }
    for (i = 0; i < n; i++) {
        int32_t target = 32768;
        if (active) {
            uint32_t p = (phase & 1048575u) >> 4;
            /* Strong pump: -24 dB for 10% of the beat; recover over the next 65%. */
            if (p < 6554u) target = 2048;
            else if (p < 49152u) target = 2048 + (int32_t)((p - 6554u) * 30720u / 42598u);
            phase += inc;
        }
        /* ~5.4 ms attack; eased release and on/off/clock loss to avoid gain steps. */
        cr_sidechain_gain += clamp(target - cr_sidechain_gain, -128, 64);
        cr_output_gain(out, i, cr_sidechain_gain);
    }
}

/* Tempo-synced Gate after FX/master and sidechain, before USB master and click. */
static void cr_gate_mix(int32_t *out, uint32_t n)
{
    int external = cr_route.clock_in != 0;
    int live = !external || (cr_sidechain_midi_seen && cr_cin.bpm && cr_sidechain_midi_age <= FS * 300u / 1000u);
    uint32_t phase = 0;
    uint32_t div = cr_gate_rate == 3u ? 1u : 2u << cr_gate_rate;
    uint32_t inc = (cr.bpm ? cr.bpm : 120u) * 1048576u / (FS * 60u);
    if (external)
        phase = cr_sidechain_midi_step * 1048576u / 24u +
            (uint32_t)((uint64_t)cr_sidechain_midi_age * cr.bpm * 1048576u / (FS * 60u)) + cr_nudge_external_phase();
    else {
        uint32_t tick = (crl.t - crl.met0) % CRL_PPQN;
        phase = (uint32_t)(((uint64_t)(tick * 60000u + crl.acc) << 20) / (CRL_PPQN * 60000u));
    }
    for (uint32_t i = 0; i < n; i++, phase += inc) {
        uint32_t p = (phase & 1048575u) * div;
        int32_t target = live && cr_gate_on == 1u && (p & 1048575u) >= 524288u ? 0 : 32768;
        cr_gate_gain += clamp(target - cr_gate_gain, -256, 256);
        cr_output_gain(out, i, cr_gate_gain);
    }
}
static void cr_click_mix(int32_t *out, uint32_t n)
{
    uint32_t i;
    if (crl.click) {
        int32_t amp = 10000 * (int32_t)crl.metro_vol / 100;
        if (crl.click == 2u) { cr_ck_a1 = 30665; cr_ck_y1 = amp * 3487 / 10000; }   /* 2 r cos w, amp sin w */
        else { cr_ck_a1 = 32011; cr_ck_y1 = amp * 2121 / 10000; }
        cr_ck_y2 = 0;
        cr_ck_n = amp ? 2400u : 0u;
        cr_ck_wait = fx_out_blk ? CLN_LA : 0u;
        crl.click = 0;
    }
    i = cr_ck_wait < n ? cr_ck_wait : n;
    cr_ck_wait -= i;
    for (; i < n && cr_ck_n; i++, cr_ck_n--) {
        int32_t y = ((cr_ck_a1 * cr_ck_y1) >> 14) - ((CR_CK_A2 * cr_ck_y2) >> 14);
        cr_ck_y2 = cr_ck_y1;
        cr_ck_y1 = y;
        out[2u * i] += y;
        out[2u * i + 1u] += y;
    }
}

/* the UI's copy of what the screen and the LEDs show, taken with the audio IRQ off (cr_engine is not reentrant) */
typedef struct {
    cr_chord_info_t ci;
    uint32_t simple_reset_serial;
    uint8_t midi_chord_lock, chord_ctrl_latch;
    uint8_t mods_held, mods_active, latching, perform_on, perform_mode, bass_on, playstyle;
    int8_t voicing, bass_voicing;
    int perf_pos;
    uint8_t perf_note;
    uint16_t scale_mask;
    int voices, pending;
    uint8_t sound[128];              /* bit s: stream s sounds note n (registry) */
    /* the looper */
    uint8_t lstate, lcap, lnlayers, lfull, lnext, ldirty, lsig, larmed;
    uint16_t lnev, lring;
    uint32_t llen, lbar, lbeat, lplayed, lpos;
    uint8_t lnote[16];               /* bit n: a loop voice sounds note n (PLAN 6: their keys glow dim) */
    uint8_t grid_mask[CRL_GRID_MAX/8u], grid_rate[CRL_GRID_MAX], grid_count, lsync;
    uint16_t grid_gate[CRL_GRID_MAX];
    uint8_t grid_carry[CRL_GRID_MAX/8u],grid_outgoing[CRL_GRID_MAX/8u];
    uint32_t vector_xy[2];
    uint8_t vector_live;
    uint8_t ldisp;                   /* the chord shown (ci) is a loop voice's, not the player's */
} cr_snap_t;
static cr_snap_t cr_snap;

static void cr_snapshot(void)
{
    uint32_t n;
    fm1_irq_off();
    cr_snap.vector_live=0;
    int vector_idle=1;
#if CR_CPU1
    vector_idle=!AW_C1_BUSY();
#endif
    /* Main-loop snapshot only; never inspect CPU1-owned voice state while busy. */
    for(uint32_t part=0;part<2;part++)if(vector_idle && trk[part].engine==ENGI_VECTOR && trk[part].eng_req==ENGI_VECTOR){
        uint32_t vi=NVOICE;
        for(uint32_t j=0;j<NVOICE;j++)if(trk[part].v[j].active && trk[part].v[j].stage!=4u && (vi==NVOICE || trk[part].v[j].age>trk[part].v[vi].age))vi=j;
        if(vi<NVOICE){cr_snap.vector_xy[part]=kv_part(part)->voice[vi].ph[3];cr_snap.vector_live|=(uint8_t)(1u<<part);}
    }
    cr_chord_info(&cr, &cr_snap.ci);
    cr_snap.simple_reset_serial=cr.simple_reset_serial;
    cr_snap.midi_chord_lock = cr_mlock;
    cr_snap.chord_ctrl_latch = (uint8_t)(cr_mmod_latch | (cr_phys_mods & (uint32_t)~cr_phys_held));
    cr_snap.mods_held = cr_mods_held(&cr);
    cr_snap.mods_active = cr_mods_active(&cr);
    cr_snap.latching = (uint8_t)cr_latching(&cr);
    cr_snap.perform_on = cr.perform_on;
    cr_snap.perform_mode = cr.perform_mode;
    cr_snap.bass_on = cr.bass_on;
    cr_snap.playstyle = cr.playstyle;
    cr_snap.voicing = cr.voicing;
    cr_snap.bass_voicing = cr.bass_voicing;
    cr_snap.perf_pos = cr_perform_pos(&cr, &cr_snap.perf_note);
    cr_snap.scale_mask = cr_scale_mask(&cr);
    cr_snap.voices = cr_voices(&cr);
    cr_snap.pending = cr_pending(&cr);
    for (n = 0; n < 128u; n++)
        cr_snap.sound[n] = (uint8_t)((cr.reg[0][n] ? 1u : 0u) | (cr.reg[1][n] ? 2u : 0u) | (cr.reg[2][n] ? 4u : 0u));
    cr_snap.lstate = crl.state;
    cr_snap.larmed = crl.play_armed;
    cr_snap.lcap = crl.cap;
    cr_snap.lnlayers = crl.d.nlayers;
    cr_snap.lfull = crl.full;
    cr_snap.lnext = crl.next_on;
    cr_snap.ldirty = crl.dirty;
    cr_snap.lsig = crl.sig;
    cr_snap.lnev = crl.d.nev;
    cr_snap.llen = crl.d.len;
    cr_snap.lpos = cr_loop_pos(&crl);
    cr_snap.lring = cr_loop_ring(&crl);
    cr_loop_where(&crl, &cr_snap.lbar, &cr_snap.lbeat);
    cr_snap.lplayed = crl.played;
    for (n = 0; n < 16u; n++)
        cr_snap.lnote[n] = 0;
    for (n = 0; n < (uint32_t)CR_MAX_LOOPV; n++) {    /* the 8 loop voices' voiced notes */
        const cr_voice_t *v = &cr.v[CR_MAX_VOICES + CR_MAX_PADS + n];
        uint32_t i;
        if (v->used)
            for (i = 0; i < v->nnotes; i++)
                cr_snap.lnote[(v->notes[i] >> 3) & 15u] |= (uint8_t)(1u << (v->notes[i] & 7u));
    }
    cr_snap.grid_count=(uint8_t)cr_loop_grid_count(&crl);cr_snap.lsync=crl.sync;
    if(crl.grid_editor){
        cr_loop_grid_snapshot_ex(&crl,cr_snap.grid_mask,cr_snap.grid_gate,cr_snap.grid_carry,cr_snap.grid_outgoing);
        for(n=0;n<CRL_GRID_MAX;n++)cr_snap.grid_rate[n]=(uint8_t)cr_loop_grid_rate(&crl,n);
    }
    cr_snap.ldisp = (uint8_t)(cr.disp_vi >= CR_MAX_VOICES + CR_MAX_PADS && cr.disp_vi < CR_NVOICE);
    fm1_irq_on();
}

/* parts 0 / 1: voices still sounding (gate or release): the "no stuck notes" check */
static uint32_t cr_parts_busy(void)
{
    uint32_t p, i, n = 0;
    for (p = 0; p < 2u; p++)
        for (i = 0; i < NVOICE; i++)
            n += trk[p].v[i].active;
    return n;
}
