/* SPDX-License-Identifier: GPL-3.0-only
 * Original more chords! synthesis implementations, 2026.
 * Fixed limits, voice-private state, no heap or runtime floating point.
 * Design and references: docs/NEW-ENGINES.md. */
#include "new_engine_tables.h"
_Static_assert(sizeof novel_saw+sizeof novel_terrain==3584u,"bounded new-engine table budget");
typedef struct {
 orbit_bridge_t bridge;
 uint32_t ph[6], slow[5], deadline[5], rng, age, packet;
 int32_t drift[5], target[5], tone;
} novel_voice_t;
typedef struct {novel_voice_t voice[NVOICE];} novel_part_t;
static novel_part_t *novel_part(uint32_t part);
static novel_voice_t *novel_state(track_t *t,voice_t *v){return &novel_part((uint32_t)(t-trk))->voice[v-t->v];}
static uint32_t novel_rand(novel_voice_t *s){uint32_t x=s->rng;x^=x<<13;x^=x>>17;x^=x<<5;return s->rng=x;}
static void novel_note(track_t *t,voice_t *v){
 novel_voice_t *s=novel_state(t,v);orbit_bridge_note(&s->bridge);
 if(!s->rng)s->rng=0x853c49e7u^((uint32_t)(t-trk)+1u)*0x9e3779b9u^((uint32_t)(v-t->v)+1u)*0x85ebca6bu;
 if(!voice_was){s->age=s->packet=0;s->tone=0;
  for(unsigned k=0;k<6;k++)s->ph[k]=novel_rand(s);
  for(unsigned k=0;k<5;k++){s->slow[k]=novel_rand(s);s->deadline[k]=0;s->drift[k]=s->target[k]=0;}}
}
static int32_t novel_lerp(int32_t a,int32_t b,uint32_t f){return a+(((b-a)*(int32_t)f)>>15);}
static int32_t novel_lookup(const int16_t *a,uint32_t ph){unsigned j=ph>>25;return novel_lerp(a[j],a[(j+1u)&127u],(ph>>10)&32767u);}
static uint32_t novel_pitch(uint32_t inc,int32_t d){if(inc>0x60000000u)inc=0x60000000u;return inc+(uint32_t)((int32_t)(inc>>15)*clamp(d,-4096,4096));}
static void novel_emit(int32_t *out,uint32_t i,int32_t x,const vmod_t *m){out[i]+=mulq15(mulq15(x,amp_at(m,i)),VOICE_FS)*2;}
static void drift_raw(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 novel_voice_t *s=novel_state(t,v);uint32_t inc[5];unsigned band[5];
 int32_t spread=clamp(t->p[P_E0],0,127),drift=clamp(t->p[P_E1],0,127),density=clamp(t->p[P_E2],0,127);
 int32_t tone=clamp(t->p[P_E3]+(m->cutoff>>8),0,127),a=256+tone*tone;
 int32_t rate=clamp(t->p[P_E4],-64,63),phase_depth=8+clamp(t->p[P_E5],0,127),round=clamp(t->p[P_E6],0,127)*256,tilt=clamp(t->p[P_E7],-64,63);
 static const int16_t off[5]={0,-32,29,-67,71};
 for(unsigned k=0;k<5;k++){
  if((int32_t)(s->age-s->deadline[k])>=0){s->target[k]=((int32_t)(novel_rand(s)&2047u)-1024)*65536;s->deadline[k]=s->age+(uint32_t)(22050-rate*250)+(novel_rand(s)&65535u);}
  s->drift[k]+=(s->target[k]-s->drift[k])>>(9-rate/32);
  inc[k]=novel_pitch(m->inc,(off[k]*spread>>3)+((s->drift[k]>>16)*drift>>9));
  band[k]=5;while(band[k]&&inc[k]>(0x60000000u>>band[k]))band[k]--;
 }
 int32_t gain=32768/(127+4*density);
 for(uint32_t i=0;i<n;i++){
  int32_t sum=0;
  for(unsigned k=0;k<5;k++){
   uint32_t warp=(uint32_t)((s->drift[k]>>16)*drift*phase_depth);
   int32_t wave=novel_lookup(novel_saw[band[k]],s->ph[k]+warp);
   if(round)wave=novel_lerp(wave,sine_i(s->ph[k]+warp),(uint32_t)round);
   int32_t weight=k?density:127;if(k)weight=weight*(127+(k&1?-1:1)*tilt)/127;
   sum+=wave*weight;s->ph[k]+=inc[k];
  }
  int32_t x=(sum>>7)*gain>>8;s->tone+=((x-s->tone)*a)>>15;novel_emit(out,i,s->tone,m);
 }
 s->age+=n;
}
static int32_t novel_surface(unsigned map,uint32_t x,uint32_t y){
 unsigned ix=x>>28,iy=y>>28;uint32_t fx=(x>>13)&32767u,fy=(y>>13)&32767u;const int16_t (*a)[16]=novel_terrain[map];
 return novel_lerp(novel_lerp(a[iy][ix],a[iy][(ix+1u)&15u],fx),novel_lerp(a[(iy+1u)&15u][ix],a[(iy+1u)&15u][(ix+1u)&15u],fx),fy);
}
/* Monotonic control slew with an exact endpoint; all values fit signed32. */
static int32_t terrain_slew(int32_t now,int32_t target){
 int32_t d=target-now;return now+(d>0?(d+511)>>9:d<0?-((-d+511)>>9):0);
}
static void terrain_raw(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 novel_voice_t *s=novel_state(t,v);
 /* Reuse Terrain-unused Drift state: no arena growth and no shared mutable state. */
 int32_t want_map=clamp(t->p[P_E0],0,3)*65536;
 int32_t want_x=clamp(t->p[P_E4],-64,63)*65536,want_y=clamp(t->p[P_E5],-64,63)*65536;
 if(s->packet!=0x54524e31u){s->drift[0]=want_map;s->drift[1]=want_x;s->drift[2]=want_y;s->packet=0x54524e31u;}
 int32_t mapq=s->drift[0],xq=s->drift[1],yq=s->drift[2];
 int moving=mapq!=want_map || xq!=want_x || yq!=want_y;
 int32_t orbit=clamp(t->p[P_E1],0,127),motion=clamp(t->p[P_E2],0,127),depth=clamp(t->p[P_E3],0,127);
 uint32_t inc=m->inc;
 int32_t xoff=xq*256,yoff=yq*256;
 int32_t skew=clamp(t->p[P_E6],-64,63),smooth=clamp(t->p[P_E7],0,127);
 int32_t soften=inc>0x08000000u?(int32_t)((inc-0x08000000u)>>13):0;soften=clamp(soften,0,32767);
 for(uint32_t i=0;i<n;i++){
  /* ~11.6ms time constant, ~53ms to99%; fractional XY never steps in whole knob units. */
  if(moving){mapq=terrain_slew(mapq,want_map);xq=terrain_slew(xq,want_x);yq=terrain_slew(yq,want_y);xoff=xq*256;yoff=yq*256;}

  int32_t cx=sine_i(s->ph[0]),cy=sine_i(s->ph[0]+0x40000000u+(uint32_t)(orbit*1048576));
  int32_t ox=sine_i(s->ph[1]),oy=sine_i(s->ph[1]+0x40000000u);
  uint32_t x=0x80000000u+(uint32_t)xoff+(uint32_t)(cx*(2048+orbit*96))+(uint32_t)(ox*depth*64);
  uint32_t y=0x80000000u+(uint32_t)yoff+(uint32_t)(cx*skew*128)+(uint32_t)(cy*(2048+orbit*64))+(uint32_t)(oy*depth*64);
  unsigned map=(unsigned)mapq>>16;uint32_t blend=((uint32_t)mapq&65535u)>>1;
  int32_t sample=novel_surface(map,x,y);
  if(blend && map<3u)sample=novel_lerp(sample,novel_surface(map+1u,x,y),blend);sample=novel_lerp(sample,sine_i(s->ph[0]),(uint32_t)soften);s->tone+=(sample-s->tone)>>9;sample-=s->tone;
  if(smooth){s->target[0]+=((sample-s->target[0])*(32768-smooth*240))>>15;sample=s->target[0];}else s->target[0]=sample;novel_emit(out,i,sample,m);
  s->ph[0]+=inc;s->ph[1]+=10000u+(uint32_t)motion*1800u;
 }
 s->drift[0]=mapq;s->drift[1]=xq;s->drift[2]=yq;
}
static void drift_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){if(!n)return;if(n>CTL)n=CTL;int32_t f=out[0],l=out[n-1];drift_raw(t,v,out,n,m);orbit_bridge_apply(&novel_state(t,v)->bridge,out,n,f,l);}
static void terrain_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){if(!n)return;if(n>CTL)n=CTL;int32_t f=out[0],l=out[n-1];terrain_raw(t,v,out,n,m);orbit_bridge_apply(&novel_state(t,v)->bridge,out,n,f,l);}
static const preset_t DRIFT_PRESETS[]={
 {"SLOW CURRENT",{35,45,75,95,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
 {"FIVE LIGHTS",{65,75,105,110,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
 {"THIN AIR",{12,25,45,65,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
};
static const engine_t ENG_DRIFT={
 .name="DRIFT",.page_title={"FIVE OSCILLATORS","TEXTURE"},.edit={
 {"SPREAD",F_PCT,0,127,35,0,0},
 {"DRIFT",F_PCT,0,127,45,0,0},
 {"DENSITY",F_PCT,0,127,75,0,0},
 {"TONE",F_PCT,0,127,95,0,0},
 {"RATE",F_INT,-64,63,0,0,0},
 {"PHASE",F_PCT,0,127,0,0,0},
 {"ROUND",F_PCT,0,127,0,0,0},
 {"TILT",F_INT,-64,63,0,0,0},
 },.presets=DRIFT_PRESETS,.npresets=NELEM(DRIFT_PRESETS),.note_on=novel_note,.render=drift_render,.poly=6,.cap=cloud_cap,.units=cloud_units,.knob={P_E0,P_E1,P_E2,P_E3}
};

static const preset_t TERRAIN_PRESETS[]={
 {"ROUND TRIP",{0,65,35,50,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
 {"CONTOURS",{1,85,55,75,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
 {"RIDGE",{2,45,75,60,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
 {"TIDAL GRID",{3,100,45,90,0,0,0,0},{20,75,100,65},0,0,FX(0,0,10,20)},
};
static const char *const NOVEL_TERRAIN_NAMES[]={"DUNES","DIAGONAL","RIDGES","CELLS"};
static const engine_t ENG_TERRAIN={
 .name="WAVE TERRAIN",.page_title={"TERRAIN ORBIT","TEXTURE"},.edit={
 {"TERRAIN",F_ENUM,0,3,0,NOVEL_TERRAIN_NAMES,0},
 {"ORBIT",F_PCT,0,127,65,0,0},
 {"MOTION",F_PCT,0,127,35,0,0},
 {"DEPTH",F_PCT,0,127,50,0,0},
 {"X SHIFT",F_INT,-64,63,0,0,0},
 {"Y SHIFT",F_INT,-64,63,0,0,0},
 {"SKEW",F_INT,-64,63,0,0,0},
 {"SMOOTH",F_PCT,0,127,0,0,0},
 },.presets=TERRAIN_PRESETS,.npresets=NELEM(TERRAIN_PRESETS),.note_on=novel_note,.render=terrain_render,.poly=6,.cap=cloud_cap,.units=cloud_units,.knob={P_E0,P_E1,P_E2,P_E3}
};

