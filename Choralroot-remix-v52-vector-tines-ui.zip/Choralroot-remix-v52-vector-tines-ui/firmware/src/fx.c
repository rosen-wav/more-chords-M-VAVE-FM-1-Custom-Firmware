/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Clean output port: ChoralRoot FM-1 0.19 contributors, GPL-3.0-only.
 * The look-ahead design follows SLOOP 2.6 (GPL-3.0-only); upstream reimplementation.
 * Adapted to Remix stereo reverb returns, CPU1 mixer and post-master tempo effects.
 * See README_AUDIO019.md and docs/UPSTREAM-019-AUDIO-QUALITY.md. */
/* Effects: per-track DIST insert, then sends into three
 * shared buses (chorus, tempo delay, reverb). Mono buses, stereo dry mix. */
#define DLY_LEN 65536u           /* 1.49 s: 1/4 at 40 BPM fits */
#define CHO_LEN 1024u
static int16_t dly_buf[DLY_LEN] __attribute__((section(".pool")));
static int16_t cho_buf[CHO_LEN] __attribute__((section(".pool")));
static const uint16_t REV_COMB[4] = {1116, 1188, 1277, 1356};
static const uint16_t REV_AP[2] = {556, 441};
static int16_t rev_comb[1116 + 1188 + 1277 + 1356] __attribute__((section(".pool")));
static union {                          /* ROOM's allpasses; SPRING's allpass chain (int32: no clamps) */
    int16_t ap[556 + 441];
    int32_t sp[(556 + 441) / 2];
} rev_u __attribute__((section(".pool")));
#define rev_ap (rev_u.ap)
static struct {
    uint32_t dly_w, cho_w, cho_ph;
    int32_t dly_lp;
    uint16_t comb_i[4], ap_i[2];
    int32_t comb_lp[4];
    uint8_t rtype;                       /* the reverb model running (G_RTYPE: 0 ROOM, 1 SPRING, 2 AMBIENT, 3 CHURCH) */
    uint16_t sp_w;                       /* SPRING: the loop's write index (SP_MASK) */
    int32_t sp_lp, sp_hp, sp_he, sp_size;   /* .. its loop low-pass, low cut (and its remainder), the loop
                                             * length (Q8, glides) */
    uint32_t sp_ph;                      /* .. the output tap's wobble */
    uint16_t dly_dl, dly_old, dly_xf;    /* DELAY: the tap in use, the one it fades from, samples left of the fade */
} fx;
#define DLY_XF 512u                      /* fx_smooth: a new delay time (TIME, the tempo, a MIDI clock) crossfades in
                                          * 11.6 ms: the read index jumping was a click on every tempo step while it rang */

/* SPRING (G_RTYPE 1): one spring of a spring tank, mono like the other buses, in the ROOM's own buffers (no
 * RAM of its own): the input and the loop's return -> a low cut (~110 Hz: a spring carries little bass) ->
 * SP_N stretched first-order allpasses, (a + z^-4) / (1 + a z^-4) (after Valimaki, Parker and Abel: below
 * fs / 8 = 5.5 kHz the group delay rises with frequency, the chirp; each pass round the loop adds more of
 * it: the "boing", the drips) -> the loop's delay line (rev_comb, SP_LEN) -> back through a one-pole
 * low-pass (DAMP) and the decay gain (SIZE). The output: the spring's far end, half way along the loop
 * (the first sound 15 .. 30 ms after the send: the tank's own pre-delay; a slow wobble of a sample or two
 * on it), plus a second, quieter pickup at three quarters (a shorter spring beside it: denser). SIZE sets
 * the loop's length (30 .. 60 ms) and its decay; DAMP the loop's low-pass. The allpasses' states: 4
 * samples each (int32), in rev_ap's memory. Changing the model fades the old one's block out and clears both buffers. */
#define SP_LEN 4096u                     /* the loop's line in rev_comb (4937 samples) */
#define SP_MASK (SP_LEN - 1u)
#define SP_N 10u                         /* allpass stages */
#define SP_A 2867                        /* their coefficient, Q12 (0.7: Q12 keeps (x - o) * a in 32 bits up to
                                          * |x - o| < 749000, far past any peak the chain reaches) */
_Static_assert(sizeof rev_comb / 2u >= SP_LEN && sizeof rev_u.sp / 4u >= 4u * (SP_N + 1u), "SPRING in ROOM's buffers");

/* DIST: low cut -> drive (1x..8x, exponential) -> asymmetric soft clip
 * (a little bias = even harmonics) -> tone low-pass that closes with drive ->
 * make-up gain (straight into tanh over the full band, it would sound like a
 * broken digital fuzz). State per part (track_t dist_*). */
static void track_dist(track_t *t, int32_t *b, uint32_t n)
{
    int32_t d = t->p[P_DIST], i, g, k, mk, bias = 2400, b0;
    if (!d)
        return;                                         /* states kept: switching on does not click */
    g = 4096 + d * d * 2;                                /* Q12: 1x .. ~9x, gentle at first */
    k = 32000 - d * 95;                                  /* tone: transparent at low drive .. ~3 kHz, Q15 */
    mk = 30000 - d * 120;                                /* make-up */
    b0 = softclip(bias);
    for (i = 0; i < (int32_t)n; i++) {
        int32_t x = b[i], y;
        t->dist_hp += (x - t->dist_hp + 64) >> 7;           /* ~55 Hz low cut: keep the bass out of the clipper */
        x = clamp(x - t->dist_hp, -230000, 230000);         /* (x >> 2) * g fits 32 bits; the clip is flat out there */
        y = softclip((((x >> 2) * g) >> 10) + bias) - b0;   /* >> 2 first: no overflow for loud poly */
        t->dist_lp1 += mulq15(y - t->dist_lp1, k);         /* two poles: tames the fizz */
        t->dist_lp2 += mulq15(t->dist_lp1 - t->dist_lp2, k);
        b[i] = mulq15(t->dist_lp2, mk);
    }
}

/* master: peak limiter in front of the soft clipper. Fast attack (~0.1 ms),
 * ~150 ms release, threshold where tanh is still nearly linear, so chords
 * get quieter instead of crushed. */
#define LIM_T 18000
static int32_t lim_env = LIM_T;
/* ChoralRoot (cr_out.c sets it; 0 in Felucca, its golden renders and reverb_test's bit-exact buses): the delay's
 * new times crossfade (DLY_XF), and the limiter is smoothed. A 6-note chord with the bass keeps the limiter
 * working (pre-limiter peaks ~2x LIM_T on ANALOG / WHEEL sounds, 60 % of the samples limited), and its 4-sample
 * attack re-attacking on every new peak of the beating chord modulated the gain at audio rate: -49 dB of
 * sidebands above 1 kHz, a crackle on held chords, louder with the FX sends. Smoothed (lim_g): -57 dB, the same
 * loudness; the peaks the slower gain lets through (to ~25000) go into the soft clipper's near-linear part */
static uint8_t fx_smooth;
static int32_t lim_g = 32768;
/* Options > USB Level = Fixed (Felucca 1.0.5's MENU > USB LEVEL FIXED, #42: record over USB with the speaker turned
 * down): the mix goes to master_out at the full MASTER level, USB audio's master pair takes that (choralroot.c's
 * mix_block shim, usb_audio_stream.c), and only then does MASTER scale what the DAC gets (usb_fixed_dac, audio.c).
 * 0 (Master, the default): MASTER before master_out, as always (USB follows the knob) */
static volatile uint8_t fx_usb_fixed;
#define MASTER_FULL 4096                /* main.c: the MASTER knob's top, Q12 */
static uint8_t fx_out_blk;              /* Options > Output: 1, this block went through the Clean chain (below) */
static void clean_post(int32_t *out, uint32_t n);
static __attribute__((noinline)) void usb_fixed_dac(int32_t *out, uint32_t n)   /* audio ISR, after the USB tap */
{
    uint32_t i;
    int32_t m = (int32_t)song.master_q12;
    if (fx_out_blk) {                               /* Output Clean: MASTER into the 24-bit word */
        clean_post(out, n);
        return;
    }
    for (i = 0; i < 2u * n; i++)
        out[i] = (out[i] * m) >> 12;                /* (|out| <= 32767 after the soft clip: fits) */
}
static volatile uint8_t fx_lowcut;     /* settings: 1 LOWCUT 12 dB/oct ~110 Hz, 2 BASS+ (the small speaker):
                                        * 12 dB/oct ~220 Hz plus the harmonics of the bass (spk_bass) */
static int32_t lc_l1, lc_l2, lc_r1, lc_r2, dc_l, dc_r, dce_l, dce_r;

/* DC blocker (~2 Hz), always on: a leaky integrator of the input (Q6 state) subtracted from it.
 * The >> 12 step keeps its remainder (error feedback, 0..4095) and adds it to the next one, so no
 * part of the step is lost: the state follows the input exactly, down to 0 after the sound stops.
 * (A rounded step of (x - dc) / 4096 would stop moving at |x - dc| < 2048 and leave an offset of up
 * to +-31 at the output after silence.) */
static inline int32_t dc_block(int32_t x, int32_t *dc, int32_t *err)
{
    int32_t e = (x * 64) - *dc + *err, d = e >> 12;
    *err = e - (d * 4096);
    *dc += d;
    return x - ((*dc + 32) >> 6);
}

static int32_t lce[4];
static inline int32_t lowcut1(int32_t x, int32_t *lc, int32_t *err, uint32_t sh)   /* x minus its one-pole low-pass */
{
    int32_t e = x - *lc + *err, d = e >> sh;
    *err = e - (d << sh);
    *lc += d;
    return x - *lc;
}

/* BASS+: what the speaker cannot play, heard through its harmonics. The bass below ~150 Hz is clipped at its
 * own envelope (a level-following trapezoid: odd harmonics), then band-passed ~220 Hz..1 kHz and added.
 * The low-pass has 4 poles (Felucca 1.0.5, #42: with 2, the trapezoid rebuilt the 300 .. 600 Hz of the mix itself,
 * late, and cancelled up to 6 dB of it; now under 0.5 dB) */
static int32_t sb_lp1, sb_lp2, sb_lp3, sb_lp4, sb_env, sb_h1, sb_h2, sb_hl;
enum { SB_LP1, SB_LP2, SB_LP3, SB_LP4, SB_ENV, SB_H1, SB_H2, SB_HL, SB_N };   /* (the states above, in a block's copy) */
static inline int32_t spk_bass(int32_t *sb, int32_t m)
{
    int32_t a, t, u;
    sb[SB_LP1] += ((m - sb[SB_LP1]) * 692) >> 15;
    sb[SB_LP2] += ((sb[SB_LP1] - sb[SB_LP2]) * 692) >> 15;
    sb[SB_LP3] += ((sb[SB_LP2] - sb[SB_LP3]) * 692) >> 15;
    sb[SB_LP4] += ((sb[SB_LP3] - sb[SB_LP4]) * 692) >> 15;
    a = sb[SB_LP4] < 0 ? -sb[SB_LP4] : sb[SB_LP4];
    if (a > sb[SB_ENV])
        sb[SB_ENV] += (a - sb[SB_ENV]) >> 2;
    else if (sb[SB_ENV] > 0)
        sb[SB_ENV] -= (sb[SB_ENV] >> 11) + 1;
    t = clamp(sb[SB_LP4] * 8, -sb[SB_ENV], sb[SB_ENV]);
    sb[SB_H1] += (t - sb[SB_H1]) >> 5;
    u = t - sb[SB_H1];
    sb[SB_H2] += (u - sb[SB_H2]) >> 5;
    u -= sb[SB_H2];
    sb[SB_HL] += (u - sb[SB_HL]) >> 3;
    return sb[SB_HL] * 3;
}

/* The master over a block, in place on its frames (o: left, right, ...): the DC blocker, LOWCUT / BASS+, the limiter,
 * the soft clip. The states are the globals above, held in locals over the block (a call a sample loaded and stored
 * them every sample); lowcut and smooth are constants where a loop is built for them (master_block), so a sample has
 * no test of the settings. */
static inline __attribute__((always_inline)) void master_loop(int32_t *o, uint32_t n, uint32_t lowcut, int smooth)
{
    int32_t dl = dc_l, el = dce_l, dr = dc_r, er = dce_r, env = lim_env, lg = lim_g;
    int32_t l1 = lc_l1, l2 = lc_l2, r1 = lc_r1, r2 = lc_r2, e0 = lce[0], e1 = lce[1], e2 = lce[2], e3 = lce[3];
    int32_t sb[SB_N] = {sb_lp1, sb_lp2, sb_lp3, sb_lp4, sb_env, sb_h1, sb_h2, sb_hl};
    uint32_t i;
    for (i = 0; i < n; i++) {
        int32_t l = o[2u * i], r = o[2u * i + 1u], al, ar, a;
        l = dc_block(l, &dl, &el);
        r = dc_block(r, &dr, &er);
        if (lowcut) {                 /* two one-pole high-passes, error feedback as dc_block (the */
            uint32_t sh = lowcut == 2u ? 5u : 6u;       /* rounded step stopped at |x - lc| < 32: an offset) */
            int32_t b = lowcut == 2u ? spk_bass(sb, (l + r) >> 1) : 0;
            l = lowcut1(l, &l1, &e0, sh);
            l = lowcut1(l, &l2, &e1, sh) + b;
            r = lowcut1(r, &r1, &e2, sh);
            r = lowcut1(r, &r2, &e3, sh) + b;
        }
        al = l < 0 ? -l : l;
        ar = r < 0 ? -r : r;
        a = al > ar ? al : ar;
        if (smooth) {                /* ChoralRoot: the peak held at once, the gain eased down over ~1.5 ms */
            int32_t gt;
            if (a > env)
                env = a;
            else if (env > LIM_T)
                env -= ((env - LIM_T) >> 12) + 1;
            gt = env > LIM_T ? (int32_t)(((uint32_t)LIM_T << 15) / (uint32_t)env) : 32768;
            if (gt < lg)
                lg += (gt - lg) >> 6;
            else
                lg = gt;
            if (lg < 32768) {
                l = ((l >> 4) * lg) >> 11;
                r = ((r >> 4) * lg) >> 11;
            }
        } else {
            if (a > env)
                env += (a - env) >> 2;
            else if (env > LIM_T)
                env -= ((env - LIM_T) >> 12) + 1;
            if (env > LIM_T) {
                int32_t g = (int32_t)(((uint32_t)LIM_T << 15) / (uint32_t)env);   /* < 32768 */
                l = ((l >> 4) * g) >> 11;                    /* >> 4 first: |l| may be far above Q15 */
                r = ((r >> 4) * g) >> 11;
            }
        }
        o[2u * i] = softclip(l);
        o[2u * i + 1u] = softclip(r);
    }
    dc_l = dl;
    dce_l = el;
    dc_r = dr;
    dce_r = er;
    lim_env = env;
    lim_g = lg;
    if (lowcut) {
        lc_l1 = l1;
        lc_l2 = l2;
        lc_r1 = r1;
        lc_r2 = r2;
        lce[0] = e0;
        lce[1] = e1;
        lce[2] = e2;
        lce[3] = e3;
    }
    if (lowcut == 2u) {
        sb_lp1 = sb[SB_LP1];
        sb_lp2 = sb[SB_LP2];
        sb_lp3 = sb[SB_LP3];
        sb_lp4 = sb[SB_LP4];
        sb_env = sb[SB_ENV];
        sb_h1 = sb[SB_H1];
        sb_h2 = sb[SB_H2];
        sb_hl = sb[SB_HL];
    }
}
static __attribute__((noinline)) void master_block(int32_t *o, uint32_t n)
{
    uint32_t lowcut = fx_lowcut;                        /* (the main loop's: it does not run under this block) */
    if (fx_smooth) {
        if (!lowcut)
            master_loop(o, n, 0u, 1);
        else if (lowcut == 2u)
            master_loop(o, n, 2u, 1);
        else
            master_loop(o, n, 1u, 1);
    } else {
        if (!lowcut)
            master_loop(o, n, 0u, 0);
        else if (lowcut == 2u)
            master_loop(o, n, 2u, 0);
        else
            master_loop(o, n, 1u, 0);
    }
}

/* ------------------------------------------------------------------------------------------------------------
 * Options > Output: Classic / Clean (ChoralRoot 0.19, docs/AUDIO-QUALITY.md; GitHub issue 3).
 * Classic is the master above, untouched: 0.18's sound bit for bit. Clean is another chain on the same mix:
 *   the mix at a FIXED gain (CLN_TRIM: MASTER is not in front of anything any more), with the two bits the Classic
 *   line shifts out kept (the chain's samples are Q17: a quarter of a Q15 unit) -> the same DC blocker -> a limiter
 *   that is a safety, not a part of the sound (threshold CLN_T instead of LIM_T: the knee below leaves it the room;
 *   the peak HELD for CLN_HOLD samples and released slowly, so a bass note's own period no longer moves the gain;
 *   the gain applied to all the sample's bits) -> a knee that is a straight line up to CLN_K and a tanh only above it
 *   (to full scale) -> MASTER, last, into the DAC's 24-bit word (out_frac: the 7 bits under the Q15 sample, which
 *   Classic leaves at 0): the knob turns the level down and nothing else, a quiet setting keeps its resolution, and
 *   the limiter's work no longer depends on it.
 * No LOWCUT / BASS+ in it: ChoralRoot has no control for them and holds them off (cr_settings.c cr_settings_boot).
 * fx_out_want is what Options asks for (the main loop writes it), fx_out_mode what runs: a change is taken at a
 * block's start, the mix faded to nothing over OUT_FADE_BLK blocks, the chain changed at that zero with its limiter
 * at rest, and faded in again: no step in the sound. Felucca's builds never ask: Classic. */
#ifndef CLN_TRIM
#define CLN_TRIM 3072                   /* Q12, a multiple of 16: the mix into the Clean chain, -2.5 dB (x 0.75) */
#endif
#ifndef CLN_T
#define CLN_T 26000                     /* the limiter's threshold in Q15 units (LIM_T + 3.2 dB) */
#endif
#define CLN_K 26000                     /* the knee: a straight line up to here (-2.0 dBFS: the limiter's threshold, so
                                         * nothing the limiter lets through meets the curve), then
                                         * K + R tanh((a - K) / R), R = 32767 - K: to full scale. A safety net only */
/* The hold (0.19's third round, docs/AUDIO-QUALITY.md "Round 3"). What Clean had left on a loud chord was the envelope
 * letting go between the chord's beats and stepping the level 0.1 to 2 dB at the next one. So the envelope is held
 * CLN_HOLD (200 ms) and held again by every block's peak within 1.2 dB of it (CLN_REHOLD): a chord, a wet tail, an
 * arp keep one gain. A HIT, a peak more than 3.5 dB above the envelope (CLN_HIT), gets the short hold of the first
 * rounds (CLN_HOLD_HIT, 40 ms: a period of 25 Hz) until the envelope has begun to let go: a kick or a slammed chord
 * is released as it was (12 dB down: back within half a dB after 0.47 s), not held down for the long one. */
#ifndef CLN_HOLD
#define CLN_HOLD 8820u                  /* 200 ms */
#endif
#ifndef CLN_HOLD_HIT
#define CLN_HOLD_HIT 1764u              /* 40 ms: after a hit */
#endif
#ifndef CLN_HIT
#define CLN_HIT 1                       /* a hit: a peak more than env >> CLN_HIT (3.5 dB) above the envelope */
#endif
#ifndef CLN_REHOLD
#define CLN_REHOLD 3                    /* a block's peak within env >> CLN_REHOLD (1.2 dB) of the envelope holds it again */
#endif
#ifndef CLN_CREEP
#define CLN_CREEP 10                    /* .. and, once CLN_HOLD samples of such blocks have gone by without the
                                         * top itself (a peak within 0.03 dB of the envelope), draws the envelope a
                                         * 1024th of the way down to itself: an envelope held up to 1.2 dB above a
                                         * steady sound (a release that stopped in the window) comes down to it
                                         * within a second or two, too slowly to be a step; a sound whose top comes
                                         * back (a bass note's period, a chord's beat) keeps its gain exactly */
#endif
#ifndef CLN_REL
#define CLN_REL 13                     /* the release: (env - T) >> CLN_REL a sample, 186 ms */
#endif
/* The look-ahead (0.19, docs/AUDIO-QUALITY.md "The look-ahead"). The chain's output is its input CLN_LA samples late,
 * and the limiter's gain is a straight line across each block of CLN_LA_B samples, from what the last block ended on
 * to the mean of the last CLN_LA_K blocks' gains, each of them the gain that fits the loudest sample of its own block
 * and of the CLN_LA_K before it under the threshold. So the gain has arrived before the peak comes out of the delay:
 * no sample leaves the limiter above CLN_T (cr_output_test.c proves it), where the gain used to ease down over 1.5 ms
 * AFTER the peak and the first samples went into the knee. One block of look-ahead and the linear glide between
 * blocks are Sloop 2.6's design (sloop-fm1 firmware/src/fx.c lim_block, GPL-3.0: LICENSING.md); the hold, the
 * release, the mean over CLN_LA_K blocks, the block maximum kept from block to block instead of a scan of the delay,
 * and the arithmetic are ChoralRoot's. CLN_LA_B divides CTL (the audio ISR's block: the block's peak is known before
 * its first sample goes out); a call with fewer samples (tests) takes a slower, safe way. */
#ifndef CLN_LA_B
#define CLN_LA_B 32u                    /* a block of the look-ahead, samples */
#endif
#ifndef CLN_LA_K
#define CLN_LA_K 1u                     /* blocks of look-ahead */
#endif
#define CLN_LA (CLN_LA_B * CLN_LA_K)    /* the delay: 32 samples, 0.73 ms */
#define CLN_DLEN (CLN_LA <= 16u ? 16u : CLN_LA <= 32u ? 32u : CLN_LA <= 64u ? 64u : 128u)
#ifndef CLN_MAKEUP
#define CLN_MAKEUP 4096                 /* Q12 after the knee, with MASTER: 4096 = none, the DAC word stays under the
                                         * Q15 sample's full scale as in every release. The word has 6 dB above that
                                         * (audio.c OUT_SHIFT): a build with 5461 gives the trim back there. NOT the
                                         * default: nobody has heard this unit's output stage up there
                                         * (docs/AUDIO-QUALITY.md "Proposed") */
#endif
#define CLN_T4 (4 * CLN_T)              /* (Q17) */
#define CLN_K4 (4 * CLN_K)
#define CLN_R4 (4 * (32767 - CLN_K))    /* the knee's range above K (Q17) */
#define CLN_KS (268435456 / CLN_R4)     /* 32768 / R4 in Q13: the tanh table's own scale */
#define CLN_G1 ((int32_t)(CLN_LA_K << 15))             /* the sum of CLN_LA_K block gains at rest */
#define OUT_FADE_BLK 16u                /* 512 samples, 11.6 ms, each way */
#define OUT_FADE_FLUSH ((CLN_LA + CTL - 1u) / CTL)     /* silent blocks between: the delay runs out */
_Static_assert(OUT_FADE_BLK * CTL == 512u, "the fade's step is 4096 / 512");
_Static_assert(!(CLN_TRIM & 15) && CLN_T <= CLN_K && CLN_K <= 30000 && CLN_MAKEUP <= 8192, "the Clean chain's ranges");
_Static_assert(CLN_LA_K >= 1u && CLN_LA_K <= 8u && CLN_LA <= 128u && CTL % CLN_LA_B == 0u, "the look-ahead's blocks");
static volatile uint8_t fx_out_want;
static uint8_t fx_out_mode, fx_out_fade;
static int32_t cln_dl[2u * CLN_DLEN];   /* the delay: the chain's samples (Q17, after the DC blocker), L R. In RAM
                                         * (.bss, 256 bytes): the ISR reads and writes it every sample; the pool is
                                         * the tight resource (docs/FX.md "The cost on the unit") */
static uint32_t cln_w, cln_hold, cln_hlen = CLN_HOLD, cln_top;
static int32_t cln_pk[CLN_LA_K];        /* the peaks of the blocks in the delay, the newest first */
static int32_t cln_wh[CLN_LA_K];        /* their gains (Q15), a ring; cln_gs is their sum */
static uint32_t cln_wi;
static int32_t cln_env = CLN_T4, cln_wg = 32768, cln_gs = CLN_G1, cln_g = 32768, cln_mq;
static uint8_t out_frac[2u * CTL];      /* Clean: the bits under each of the block's Q15 samples: the DAC word's 7
                                         * (audio.c), or between clean_block and a later clean_post the chain's 2 */
#ifdef CLN_GAIN_TAP                     /* (tests/master_measure.c: the gain of each sample of the last call) */
static int32_t cln_gtap[CTL];
#endif

/* the limiter at rest and its delay empty (power-on; Options > Output changed, at the fade's zero) */
static void clean_rest(void)
{
    uint32_t i;
    for (i = 0; i < 2u * CLN_DLEN; i++)
        cln_dl[i] = 0;
    for (i = 0; i < CLN_LA_K; i++) {
        cln_pk[i] = 0;
        cln_wh[i] = 32768;
    }
    cln_w = cln_wi = cln_hold = cln_top = 0;
    cln_hlen = CLN_HOLD;
    cln_env = CLN_T4;
    cln_wg = cln_g = 32768;
    cln_gs = CLN_G1;
}

/* (Q17) */
static inline int32_t clean_knee(int32_t y)
{
    int32_t a = y < 0 ? -y : y;
    if (a <= CLN_K4)
        return y;
    a -= CLN_K4;
    if (a > 2 * CLN_R4)                 /* (the table ends at tanh 2) */
        a = 2 * CLN_R4;
    a = CLN_K4 + ((softclip((a * CLN_KS) >> 13) * CLN_R4) >> 15);
    return y < 0 ? -a : a;
}
/* x * g / 32768 with every bit of x (|x| < 2^23, g Q15, 32768 the identity): the limiter's gain (Classic's
 * (x >> 4) * g >> 11 drops four bits and, rounding down from them, shifts the sample by up to 16 while it limits) */
static inline int32_t clean_gain(int32_t x, int32_t g)
{
    return (((x >> 8) * g) >> 7) + (((x & 255) * g) >> 15);
}

/* the slow way's part (a call that is not whole blocks: tests): every peak the limiter knows of and the delay's own */
static __attribute__((noinline)) int32_t clean_short(int32_t p)
{
    uint32_t i;
    for (i = 0; i < CLN_LA_K; i++)
        if (cln_pk[i] > p)
            p = cln_pk[i];
    for (i = 0; i < 2u * CLN_DLEN; i++) {
        int32_t a = cln_dl[i] < 0 ? -cln_dl[i] : cln_dl[i];
        if (a > p)
            p = a;
    }
    for (i = 0; i < CLN_LA_K; i++)
        cln_pk[i] = p;
    return p;
}

static __attribute__((noinline)) void clean_block(int32_t *o, uint32_t n)
{
    int32_t dl = dc_l, el = dce_l, dr = dc_r, er = dce_r;
    uint32_t w = cln_w;
#ifdef CLN_GAIN_TAP
    uint32_t tap = 0;
#endif
    while (n) {
        uint32_t m = n < CLN_LA_B ? n : CLN_LA_B, i;
        int32_t p = 0, wm, env = cln_env, g0 = cln_gs, g1;
        /* in: through the DC blocker into the delay, the block's peak; out: what went in CLN_LA samples ago */
        for (i = 0; i < m; i++) {
            int32_t l = dc_block(o[2u * i], &dl, &el), r = dc_block(o[2u * i + 1u], &dr, &er);
            int32_t al = l < 0 ? -l : l, ar = r < 0 ? -r : r;
            uint32_t rd = (w + CLN_DLEN - CLN_LA) & (CLN_DLEN - 1u);
            if (al > p)
                p = al;
            if (ar > p)
                p = ar;
            o[2u * i] = cln_dl[2u * rd];
            o[2u * i + 1u] = cln_dl[2u * rd + 1u];
            cln_dl[2u * w] = l;
            cln_dl[2u * w + 1u] = r;
            w = (w + 1u) & (CLN_DLEN - 1u);
        }
        if (p > 0x7FFFFF) {             /* (clean_gain's range; 36 dB over the threshold: no sound gets there) */
            for (i = 1; i <= m; i++) {
                uint32_t j = (w - i) & (CLN_DLEN - 1u);
                cln_dl[2u * j] = clamp(cln_dl[2u * j], -0x7FFFFF, 0x7FFFFF);
                cln_dl[2u * j + 1u] = clamp(cln_dl[2u * j + 1u], -0x7FFFFF, 0x7FFFFF);
            }
            p = 0x7FFFFF;
        }
        /* the loudest of this block and of those still in the delay */
        if (m == CLN_LA_B) {
            wm = p;
            for (i = CLN_LA_K; i-- > 0u;) {
                if (cln_pk[i] > wm)
                    wm = cln_pk[i];
                cln_pk[i] = i ? cln_pk[i - 1u] : p;
            }
        } else {
            wm = p = clean_short(p);
        }
        /* the envelope: a new peak at once, held (CLN_HOLD; after a hit CLN_HOLD_HIT), held again by every peak
         * within 1.2 dB of it, then released */
        if (wm > env) {
            if (wm - env > (env >> CLN_HIT))            /* a hit: the short hold, until the envelope has let go */
                cln_hlen = CLN_HOLD_HIT;
            env = wm;
            cln_hold = cln_hlen;
            cln_top = 0;
        } else if (p > env - (env >> CLN_REHOLD)) {
            if (cln_hold < cln_hlen)
                cln_hold = cln_hlen;
            if (p >= env - (env >> 8))                  /* the top itself again: nothing to creep to */
                cln_top = 0;
            else if (cln_top < CLN_HOLD)
                cln_top += m;
            else                                        /* (never under the delay's own peak) */
                env -= (env - (wm > CLN_T4 ? wm : CLN_T4)) >> CLN_CREEP;
        } else if (cln_hold) {
            cln_hold = cln_hold > m ? cln_hold - m : 0u;
        } else if (env > CLN_T4) {
            cln_hlen = CLN_HOLD;                        /* (letting go: from here on the long hold again) */
            env -= (((env - CLN_T4) >> CLN_REL) + 4) * (int32_t)m;
            if (env < wm)
                env = wm;
            if (env < CLN_T4)
                env = CLN_T4;
        }
        if (env != cln_env) {           /* (one division a block, and only while the envelope moves) */
            cln_env = env;
            cln_wg = env > CLN_T4 ? (int32_t)(((uint32_t)CLN_T4 << 15) / (uint32_t)env) : 32768;
        }
        g1 = g0 - cln_wh[cln_wi] + cln_wg;              /* the mean of the last CLN_LA_K gains, as their sum */
        cln_wh[cln_wi] = cln_wg;
        cln_wi = cln_wi + 1u < CLN_LA_K ? cln_wi + 1u : 0u;
        if (m != CLN_LA_B) {            /* (the slow way: no older gain above this one) */
            for (i = 0, g1 = 0; i < CLN_LA_K; i++) {
                if (cln_wh[i] > cln_wg)
                    cln_wh[i] = cln_wg;
                g1 += cln_wh[i];
            }
        }
        cln_gs = g1;
        if (g0 != CLN_G1 || g1 != CLN_G1) {             /* limiting: the gain glides from g0 to g1 over the block */
            int32_t acc = g0 * (int32_t)m, d = g1 - g0;
            for (i = 0; i < m; i++) {
                int32_t g;
                acc += d;
                g = m == CLN_LA_B ? (int32_t)((uint32_t)acc / (CLN_LA_K * CLN_LA_B))
                                  : (int32_t)((uint32_t)acc / (CLN_LA_K * m));
                o[2u * i] = clean_knee(clean_gain(o[2u * i], g));
                o[2u * i + 1u] = clean_knee(clean_gain(o[2u * i + 1u], g));
#ifdef CLN_GAIN_TAP
                cln_gtap[(tap + i) & (CTL - 1u)] = g;
#endif
            }
        }
#ifdef CLN_GAIN_TAP
        else
            for (i = 0; i < m; i++)
                cln_gtap[(tap + i) & (CTL - 1u)] = 32768;
        tap += m;
#endif
        /* (at rest nothing in the delay is over the threshold: the samples go out as they are, under the knee) */
        o += 2u * m;
        n -= m;
    }
    dc_l = dl;
    dce_l = el;
    dc_r = dr;
    dce_r = er;
    cln_w = w;
    cln_g = cln_gs / (int32_t)CLN_LA_K;
}
/* Clean's last stage: MASTER (eased over the block: a turned knob is a ramp, not 32-sample steps) on the block, kept
 * as the DAC's 24-bit word: out = its upper 17 bits (the Q15 sample: what USB, the scope and the click see), out_frac
 * the 7 under them (audio.c adds them to the word). q17: the block is the chain's own (Q17); else it is Q15 samples
 * with the chain's two bits in out_frac (clean_split: USB Level = Fixed, where USB's tap and the click come between) */
static inline __attribute__((always_inline)) void clean_post_loop(int32_t *out, uint32_t n, int q17)
{
    int32_t m = ((int32_t)song.master_q12 * CLN_MAKEUP >> 12) << 8, mq = cln_mq, d = (m - mq) >> CTL_LOG2;
    uint32_t i;
    for (i = 0; i < n; i++) {
        uint32_t j = (2u * i) & (2u * CTL - 1u);
        int32_t g, l = out[2u * i], r = out[2u * i + 1u];
        if (!q17) {
            l = l * 4 + out_frac[j];
            r = r * 4 + out_frac[j + 1u];
        }
        mq += d;
        g = mq >> 8;
        l = (l * g) >> 7;                               /* Q17 x Q12 -> Q22 (|l| < 2^18) */
        r = (r * g) >> 7;
        out[2u * i] = l >> 7;
        out[2u * i + 1u] = r >> 7;
        out_frac[j] = (uint8_t)(l & 127);
        out_frac[j + 1u] = (uint8_t)(r & 127);
    }
    cln_mq = m;
}
static __attribute__((noinline)) void clean_post(int32_t *out, uint32_t n) { clean_post_loop(out, n, 0); }
static __attribute__((noinline)) void clean_post17(int32_t *out, uint32_t n) { clean_post_loop(out, n, 1); }
static __attribute__((noinline)) void clean_split(int32_t *out, uint32_t n)   /* Q17 -> Q15 and the two bits under */
{
    uint32_t i;
    for (i = 0; i < 2u * n; i++) {
        out_frac[i & (2u * CTL - 1u)] = (uint8_t)(out[i] & 3);
        out[i] >>= 2;
    }
}
/* Options changed Output: this block of the chain's input (o, n = CTL) faded, and the chain changed at the zero: the
 * mix down to nothing over OUT_FADE_BLK blocks, then OUT_FADE_FLUSH silent blocks through the old chain (Clean's
 * delay plays its last samples out: nothing of the fade's end is cut off), the other chain from rest with an empty
 * delay, and up again */
static __attribute__((noinline)) void out_fade(int32_t *o, uint32_t n)
{
    uint32_t i, k;
    if (!fx_out_fade)
        fx_out_fade = 1;
    k = fx_out_fade - 1u;
    for (i = 0; i < n; i++) {
        int32_t g = k < OUT_FADE_BLK ? 4096 - 8 * (int32_t)(k * CTL + i + 1u)
                  : k < OUT_FADE_BLK + OUT_FADE_FLUSH ? 0
                  : 8 * (int32_t)((k - OUT_FADE_BLK - OUT_FADE_FLUSH) * CTL + i + 1u);
        g = clamp(g, 0, 4096);
        o[2u * i] = ((clamp(o[2u * i], -0x7FFFFF, 0x7FFFFF) >> 4) * g) >> 8;
        o[2u * i + 1u] = ((clamp(o[2u * i + 1u], -0x7FFFFF, 0x7FFFFF) >> 4) * g) >> 8;
    }
    if (fx_out_fade == OUT_FADE_BLK + OUT_FADE_FLUSH)   /* silent now: the other chain from the next block on */
        fx_out_mode = !fx_out_mode;                     /* (out_master puts both at rest after this one) */
    fx_out_fade = fx_out_fade == 2u * OUT_FADE_BLK + OUT_FADE_FLUSH ? 0u : (uint8_t)(fx_out_fade + 1u);
}
/* the mix (l, r, and Felucca's mono wet w: its chorus, delay and reverb; 0 where the mix already holds every return,
 * ChoralRoot's unit: mix_block) through its chain into out: fx_out_mode's, read once for the block */
static inline __attribute__((always_inline)) void out_master(int32_t *out, const int32_t *l, const int32_t *r,
                                                             const int32_t *w, uint32_t n)
{
    uint32_t i, mode = fx_out_mode;
    if (mode) {
        for (i = 0; i < n; i++) {                       /* (x 3 for the default trim: nothing shifted out) */
            int32_t ww = w ? w[i] : 0;
            out[2u * i] = ((l[i] + ww) * (CLN_TRIM >> 4)) >> 6;
            out[2u * i + 1u] = ((r[i] + ww) * (CLN_TRIM >> 4)) >> 6;
        }
    } else {
        int32_t mg = fx_usb_fixed ? MASTER_FULL : (int32_t)song.master_q12;
        for (i = 0; i < n; i++) {
            int32_t ww = w ? w[i] : 0;
            out[2u * i] = (((l[i] + ww) >> 2) * mg) >> 10;
            out[2u * i + 1u] = (((r[i] + ww) >> 2) * mg) >> 10;
        }
    }
    if (fx_out_fade || fx_out_want != mode)
        out_fade(out, n);
    fx_out_blk = (uint8_t)mode;
    if (!mode) {
        master_block(out, n);
    } else {
        clean_block(out, n);
        if (fx_usb_fixed)
            clean_split(out, n);
        else
            clean_post17(out, n);
    }
    if (fx_out_mode != mode) {                          /* the fade's zero: this was the old chain's last block. Both
                                                         * limiters at rest and Clean's delay empty for the new one */
        lim_env = LIM_T;
        lim_g = 32768;
        clean_rest();
        cln_mq = ((int32_t)song.master_q12 * CLN_MAKEUP >> 12) << 8;
    }
}
/* Options > Output (cr_ui.c) and the settings at boot (now: before the first block, no fade) */
static uint8_t fx_out_pin;              /* the emulator's EMU_OUTPUT=classic (the proof that Classic is 0.18's, bit for
                                         * bit, on scripts whose settings say Clean): Classic whatever is asked */
static void fx_output_set(uint32_t clean, int now)
{
    if (fx_out_pin)
        clean = 0;
    fx_out_want = (uint8_t)(clean != 0u);
    if (now) {
        fx_out_mode = fx_out_want;
        fx_out_fade = 0;
        clean_rest();
        cln_mq = ((int32_t)song.master_q12 * CLN_MAKEUP >> 12) << 8;
    }
}
/* MASTER at once, no ramp (master.c master_boot: the pot as it stands before the audio starts, 0.19; Felucca 1.1.5's
 * fix for its #137): song.master_q12, and Output Clean's eased copy of it, which would glide from where it was over
 * the first block. master_pot_q12: the pot's level + 1 as master.c last read it (0: never read: a host test, a unit
 * whose ADC did not answer); cr_out.c cr_out_init goes back to it after the UI's power-on defaults */
static uint32_t master_pot_q12;
static void fx_master_now(uint32_t q12)
{
    song.master_q12 = q12;
    master_pot_q12 = q12 + 1u;
    cln_mq = ((int32_t)q12 * CLN_MAKEUP >> 12) << 8;
}

/* one frame through the master (tests/speaker_test.c: its response sample by sample) */
static inline void master_out(int32_t *l, int32_t *r)
{
    int32_t o[2];
    o[0] = *l;
    o[1] = *r;
    master_block(o, 1u);
    *l = o[0];
    *r = o[1];
}

/* length of one division (N_DIV order) in samples at the song tempo */
static const uint8_t DIV_DEN[6] = {1, 2, 4, 8, 3, 6};    /* original IDs stay fixed; slow rates append */
static uint32_t midi_beat_samples;                    /* zero until an external clock has a measured tempo */
static uint32_t beat_samples(void)
{
    return song.g[G_CLOCK] && midi_beat_samples ? midi_beat_samples : (uint32_t)FS * 60u / (uint32_t)song.g[G_BPM];
}
static uint32_t div_samples(uint32_t div)
{
    uint32_t quarter = beat_samples();
    return div < 6u ? quarter / DIV_DEN[div] : div < 10u ? quarter << (div - 5u) : quarter / DIV_DEN[div % 6u];
}

#include "perform.c"                                 /* the FX hold layer's effects (the master) */

static uint32_t delay_samples(void)
{
    uint32_t s = div_samples((uint32_t)song.g[G_DTIME]);
    return s < 16u ? 16u : s >= DLY_LEN ? DLY_LEN - 1u : s;
}

/* ROOM (G_RTYPE 0): 4 damped combs + 2 allpasses (Freeverb-like, mono), added to out */


/* Hall implementation from Melodee 1.1.0, GPL-3.0-only. */
/* HALL (G_RTYPE 2, 1.2): a smooth, dense, stereo reverb, again in ROOM's buffers (its few states and one block
 * of work in the pool, no .bss). ROOM's 4 combs each ring on their own (the metallic tone); here every echo
 * goes round 8 lines that all feed each other, and they run at half the rate (22.05 kHz: the same memory holds
 * twice the time, so twice the resonances, at half the work; the tail stops near 10 kHz, as a hall's air
 * does). The send (every other sample of it, low-passed 1 2 1; ROOM's level) -> a low cut (~110 Hz: no boom
 * in a long tail) -> 2 allpass diffusers (rev_ap: a drum's click smeared into a burst) -> into the 8 lines
 * (rev_comb, mutually prime lengths, 21 .. 34 ms). Lines 1, 2, 4, 7 are read through slow sines (+-HL_MOD
 * samples, between samples; 0.37 or 0.74 Hz, each in its own phase): the resonances drift instead of ringing.
 * Lines 0, 3, 5, 6, read at their ends, go through a one-pole low-pass (DAMP: the mixing takes every echo
 * through them); every
 * line through its gain (from its length: all decay alike; RT60 below the damping 0.5 s at SIZE 0, 4 s at
 * 90, 9 s at 127; ~2.4 s heard at 90 with DAMP 60); then the 8 x 8 mixing: a conference matrix (Paley,
 * order 8: every line feeds the 7 others, +-1 each, none itself: no flutter at a line's own length), with
 * the send added. Stereo: left lines 0 3 4 -7, right 1 2 5 6 (sums spread over the matrix's rows); the wet
 * bus (mono) gets left + right, rev_side left - right, which mix_block adds to the left and takes from the
 * right (rev_side_mix). Back to 44.1 kHz between samples. Rounding: a loud line's gain rounds to the nearest
 * (the tail decays as it should), a quiet one's towards zero (it ends in exact silence: no limit cycle), and
 * the low-passes keep their steps' remainders (no offset). */
#define HL_NL 8u                         /* lines */
#define HL_NAP 2u                        /* diffusers */
#define HL_NC (CTL / 2u)                 /* a block at half the rate */
#define HL_MOD 8                         /* the taps' swing, samples (read 2 .. 18 samples short of the end) */
#define HL_LPM 0x69u                     /* the lines with a low-pass */
#define HL_KD(d) (32767 - (d) * 180)     /* its coefficient (Q15) for DAMP d: none at 0 .. ~1 kHz at 127 */
#define HL_LOUD 32                       /* a line this loud (two samples' sum) rounds its gain to the nearest */
#define HL_OUT 4                         /* the outputs' gain: the level of ROOM's tail */
static const uint16_t HL_LEN[HL_NL] = {467, 509, 547, 593, 631, 673, 709, 743};   /* (+1 each: the mirror) */
static const uint16_t HL_AP[HL_NAP] = {131, 307};
static const int16_t HL_APG[HL_NAP] = {11469, 10240};               /* Q14: 0.7, 0.625 */
_Static_assert(467 + 509 + 547 + 593 + 631 + 673 + 709 + 743 + HL_NL <= (sizeof rev_comb / sizeof rev_comb[0]) &&
               131 + 307 <= sizeof rev_u.ap / 2u, "HALL in ROOM's buffers");
_Static_assert(CTL % 2u == 0u && HL_NC + 2u * HL_MOD + 2u < 467u && HL_NC <= 131u, "HALL: one wrap a block at most");
static struct {                          /* HALL's state (in the pool: no .bss) */
    uint16_t i[HL_NL], d[HL_NAP];        /* the lines' write indices, the diffusers' */
    int32_t lp[HL_NL], le[HL_NL];        /* the low-passes and their steps' remainders */
    int32_t x, m, s, hp, he;             /* the send's last sample, its low cut and that step's remainder; the
                                          * last mid and side out (half rate) */
    int16_t g[HL_NL], sz;                /* the lines' gains / sqrt(7) (Q14), for SIZE sz - 1 (0: none yet) */
    uint32_t ph;                         /* the taps' drift */
    uint8_t side;                        /* sd holds this block's stereo difference (HALL running) */
    int32_t sd[CTL];                     /* the block's left minus right (mix_block: rev_side_mix) */
    int32_t bx[HL_NC], l[HL_NC], r[HL_NC];   /* the block at half the rate: the diffused send, left, right */
    int16_t y[HL_NL][HL_NC];             /* the lines' ends, then what goes back into them */
} hl __attribute__((section(".pool")));
#define rev_side (hl.sd)

/* HALL's helpers: m / 2^sh rounded towards zero (a product that feeds back must not floor: a loop of floors
 * holds an offset and a little noise for ever) */
static inline int32_t sh_tz(int32_t m, uint32_t sh) { return (m + ((m >> 31) & ((1 << sh) - 1))) >> sh; }
/* 2^-x, x Q16 (0 .. 16): Q15 (32768 at x = 0). 2^-x = 2^u / 2^(i + 1), u = 1 - frac(x); 2^u by a cubic (1e-4) */
static uint32_t exp2_neg(uint32_t x)
{
    uint32_t i = x >> 16, u = 32768u - ((x & 0xFFFFu) >> 1), p = 2579u;
    p = ((p * u) >> 15) + 7409u;
    p = ((p * u) >> 15) + 22780u;
    p = ((p * u) >> 15) + 32768u;
    return i < 15u ? p >> (i + 1u) : 0u;
}
/* the lines' gains for SIZE s: RT60 = 0.5 s * 2^(s / 30); a line of D samples (22.05 kHz) loses 60 dB in
 * RT60 * 22050 / D passes: g = 2^(-D * 3 log2(10) / (22050 * RT60)) = 2^(-D * 59.2 / 65536 * 2^(-s / 30)),
 * at most 0.99, over sqrt(7) (the matrix's rows have 7 entries of +-1: / sqrt(7) makes it orthogonal) */
static __attribute__((noinline)) void hall_gains(int32_t s)
{
    uint32_t q = exp2_neg((uint32_t)s * 65536u / 30u), k, g;
    for (k = 0; k < HL_NL; k++) {
        g = exp2_neg((HL_LEN[k] * 59u * q) >> 15);
        hl.g[k] = (int16_t)(((g > 32440u ? 32440u : g) * 6193u) >> 15);
    }
    hl.sz = (int16_t)(s + 1);
}

/* an allpass diffuser over x[0 .. n) from q (its next samples, no wrap): its state rounded towards zero */
static inline void hall_ap(int16_t *q, int32_t g, int32_t *x, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        int32_t y = q[i], v = x[i] + sh_tz(y * g, 14);
        q[i] = (int16_t)clamp(v, -32768, 32767);
        x[i] = y - ((v * g + 8192) >> 14);
    }
}
/* a line's end over y[0 .. n) from b (no wrap; b[n] is still the line's: its mirror at the end): between b[i]
 * and b[i + 1], f / 256 of the way (rounded to the nearest: it stays between the two), times its gain g (Q14).
 * The gain's product: rounded to the nearest while the line is loud (lo 0: the tail decays as it should; a
 * truncation would make it die early, the sooner the quieter), towards zero once it is quiet (lo 1: the last
 * steps of the tail, which then ends in exact silence) */
static inline void hall_end(const int16_t *b, int32_t f, int16_t *y, uint32_t n, int32_t g, int lo)
{
    uint32_t i;
    if (lo)
        for (i = 0; i < n; i++)
            y[i] = (int16_t)sh_tz((b[i] + (((b[i + 1u] - b[i]) * f + 128) >> 8)) * g, 14);
    else
        for (i = 0; i < n; i++)
            y[i] = (int16_t)(((b[i] + (((b[i + 1u] - b[i]) * f + 128) >> 8)) * g + 8192) >> 14);
}
/* a line's end over y[0 .. n) from b (no wrap), through the low-pass (kd, Q15; the state *lp and its step's
 * remainder *le), times its gain g (rounded as hall_end's) */
static inline void hall_end_lp(const int16_t *b, int16_t *y, uint32_t n, int32_t g, int lo, int32_t *lp, int32_t *le,
                               int32_t kd)
{
    uint32_t i;
    int32_t l = *lp, r = *le, e;
    if (lo)
        for (i = 0; i < n; i++) {
            e = (b[i] - l) * kd + r, r = e & 32767, l += e >> 15;
            y[i] = (int16_t)sh_tz(l * g, 14);
        }
    else
        for (i = 0; i < n; i++) {
            e = (b[i] - l) * kd + r, r = e & 32767, l += e >> 15;
            y[i] = (int16_t)((l * g + 8192) >> 14);
        }
    *lp = l;
    *le = r;
}
/* the block's HL_NC samples of a circular buffer of len from index d in at most two runs, no wrap inside them:
 * body with s (the run's start in the block) and k (its length); d moves on */
#define HL_RUNS(d, len, k, s, body)                                                         \
    for (s = 0; s < HL_NC; s += k) {                                                        \
        k = (len) - (d) < HL_NC - s ? (len) - (d) : HL_NC - s;                              \
        body;                                                                               \
        d = (d) + k >= (len) ? 0u : (d) + k;                                                \
    }

/* HALL (see the top): a block of the send (n = CTL samples: audio.c) -> the mid added to out, the side into
 * rev_side. At half the rate (HL_NC samples) in passes over the block, each with few states (every line is
 * longer than a block: what the lines give in this block was written before it): the send, every other
 * sample, low cut, diffusers (hl.bx); the lines' ends at their drifting taps, low-passed, scaled (hl.y); the
 * outputs and the matrix; back into the lines; the outputs back to 44.1 kHz. */
#define HL_LFO ((uint32_t)(0.37 * CTL / FS * 4294967296.0))   /* the drift: 0.37 Hz (even lines), 0.74 Hz (odd) */
static __attribute__((noinline)) void rev_hall(const int32_t *rev_in, int32_t *out, uint32_t n)
{
    int16_t *b = rev_comb, *a = rev_ap;
    uint32_t i, k, s, m, d;
    int32_t kd = HL_KD(song.g[G_RDAMP]);
    int32_t xp = hl.x, hp = hl.hp, he = hl.he, mp = hl.m, sp = hl.s;
    (void)n;
    if (hl.sz != song.g[G_RSIZE] + 1)
        hall_gains(song.g[G_RSIZE]);
    for (i = 0; i < HL_NC; i++) {
        int32_t x = (xp + 2 * rev_in[2u * i] + rev_in[2u * i + 1u]) >> 2, v;   /* every other sample, 1 2 1 */
        xp = rev_in[2u * i + 1u];
        x = mulq15(clamp(x, -262143, 262143), 2580);    /* (ROOM's level) */
        v = x - hp + he;                                /* the low cut, its step's remainder kept */
        he = v & 31;
        hp += v >> 5;
        hl.bx[i] = x - hp;
    }
    hl.x = xp, hl.hp = hp, hl.he = he;
    for (k = 0; k < HL_NAP; k++) {                      /* the diffusers */
        d = hl.d[k];
        HL_RUNS(d, HL_AP[k], m, s, hall_ap(a + d, HL_APG[k], hl.bx + s, m));
        hl.d[k] = (uint16_t)d;
        a += HL_AP[k];
    }
    hl.ph += HL_LFO;
    for (k = 0; k < HL_NL; k++) {                       /* the lines' ends */
        int32_t g = hl.g[k], f = 0, lo;
        if ((HL_LPM >> k) & 1u)
            d = hl.i[k];                                /* (low-passed: the line's end) */
        else {                                          /* (drifting: HL_MOD + 2 +- HL_MOD samples short of it) */
            uint32_t r = (uint32_t)(((HL_MOD + 2) << 8) +
                                    ((osc_sine(hl.ph * (1u + (k & 1u)) + k * 0x2C000000u) * HL_MOD) >> 7));
            f = (int32_t)(r & 255u);
            d = hl.i[k] + (r >> 8);
            d = d >= HL_LEN[k] ? d - HL_LEN[k] : d;
        }
        s = d + HL_LEN[k] / 2u;                         /* quiet? (two samples half a line apart) */
        s = s >= HL_LEN[k] ? s - HL_LEN[k] : s;
        lo = (b[d] < 0 ? -b[d] : b[d]) + (b[s] < 0 ? -b[s] : b[s]) < HL_LOUD;
        if ((HL_LPM >> k) & 1u) {
            HL_RUNS(d, HL_LEN[k], m, s, hall_end_lp(b + d, hl.y[k] + s, m, g, lo, &hl.lp[k], &hl.le[k], kd));
        } else {
            HL_RUNS(d, HL_LEN[k], m, s, hall_end(b + d, f, hl.y[k] + s, m, g, lo));
        }
        b += HL_LEN[k] + 1u;
    }
    for (i = 0; i < HL_NC; i++) {
        int32_t y0 = hl.y[0][i], y1 = hl.y[1][i], y2 = hl.y[2][i], y3 = hl.y[3][i];
        int32_t y4 = hl.y[4][i], y5 = hl.y[5][i], y6 = hl.y[6][i], y7 = hl.y[7][i], x = hl.bx[i];
        int32_t t, p0, p1, p2, p3, p4, p5, p6;
        hl.l[i] = y0 + y3 + y4 - y7;                    /* the outputs */
        hl.r[i] = y1 + y2 + y5 + y6;
        /* the matrix: C = [0 1; -1 Q], Q (7 x 7) = chi(j - i), the quadratic character mod 7 (+1 at distances
         * 1 2 4, -1 at 3 5 6): row 1 + i of Q y = 2 (the three at +1) - (the sum of the 7) + y_1+i */
        t = y1 + y2 + y3 + y4 + y5 + y6 + y7;
        p0 = y2 + y3 + y5, p1 = y3 + y4 + y6, p2 = y4 + y5 + y7, p3 = y5 + y6 + y1;
        p4 = y6 + y7 + y2, p5 = y7 + y1 + y3, p6 = y1 + y2 + y4;
        y0 += t;
        hl.y[0][i] = (int16_t)clamp(t + x, -32768, 32767);   /* (+ the send: signs spread over the rows) */
        hl.y[1][i] = (int16_t)clamp(2 * p0 + y1 - y0 + x, -32768, 32767);
        hl.y[2][i] = (int16_t)clamp(2 * p1 + y2 - y0 + x, -32768, 32767);
        hl.y[3][i] = (int16_t)clamp(2 * p2 + y3 - y0 + x, -32768, 32767);
        hl.y[4][i] = (int16_t)clamp(2 * p3 + y4 - y0 + x, -32768, 32767);
        hl.y[5][i] = (int16_t)clamp(2 * p4 + y5 - y0 + x, -32768, 32767);
        hl.y[6][i] = (int16_t)clamp(2 * p5 + y6 - y0 + x, -32768, 32767);
        hl.y[7][i] = (int16_t)clamp(2 * p6 + y7 - y0 - x, -32768, 32767);
    }
    b = rev_comb;
    for (k = 0; k < HL_NL; k++) {                       /* back into the lines (and the mirror after a wrap) */
        d = hl.i[k];
        HL_RUNS(d, HL_LEN[k], m, s, for (i = 0; i < m; i++) b[d + i] = hl.y[k][s + i]; if (!d) b[HL_LEN[k]] = b[0]);
        hl.i[k] = (uint16_t)d;
        b += HL_LEN[k] + 1u;
    }
    for (i = 0; i < HL_NC; i++) {                       /* back to 44.1 kHz, between samples */
        int32_t mm = (hl.l[i] + hl.r[i]) * HL_OUT, ss = (hl.l[i] - hl.r[i]) * HL_OUT;
        out[2u * i] += (mp + mm) >> 1;
        out[2u * i + 1u] += mm;
        rev_side[2u * i] = (sp + ss) >> 1;
        rev_side[2u * i + 1u] = ss;
        mp = mm;
        sp = ss;
    }
    hl.m = mp, hl.s = sp;
    hl.side = 1;
}



static int32_t rev_stereo[CTL]; /* survives the old-model fade and clear */
/* CHURCH shares Ambient's exact Melodee Hall tail, with a stereo early
 * reflection field after the input diffusion/low cut. Feed-forward taps only:
 * no new feedback resonances and no change to the Hall decay/stability. */
#define CHURCH_ER_LEN 1024u
static int16_t church_er[CHURCH_ER_LEN] __attribute__((section(".pool")));
static uint32_t church_w;
static int32_t church_mid, church_side;
static __attribute__((noinline)) void rev_church(const int32_t *in, int32_t *out, uint32_t n)
{
    rev_hall(in, out, n);
    for (uint32_t i = 0; i < HL_NC; i++) {
        uint32_t w = church_w++;
        church_er[w & (CHURCH_ER_LEN - 1u)] = (int16_t)clamp(hl.bx[i], -32768, 32767);
        /* ~7..40 ms, different left/right paths; no coherent mono echo stack. */
        int32_t l = (church_er[(w-149u)&1023u]*14000 +
                     church_er[(w-431u)&1023u]*10000 - church_er[(w-881u)&1023u]*6000) >> 15;
        int32_t r = (church_er[(w-283u)&1023u]*14000 -
                     church_er[(w-619u)&1023u]*10000 + church_er[(w-881u)&1023u]*6000) >> 15;
        int32_t mid = (l+r)*HL_OUT, side = (l-r)*HL_OUT;
        out[2u*i] += (church_mid+mid)>>1;
        out[2u*i+1u] += mid;
        rev_side[2u*i] += (church_side+side)>>1;
        rev_side[2u*i+1u] += side;
        church_mid=mid; church_side=side;
    }
}

/* SPRING (see the top), added to out */


/* the reverb's buffers and states to silence (the model changed) */
static void rev_clear(void)
{
    uint32_t i;
    for (i = 0; i < sizeof rev_comb / 2u; i++)
        rev_comb[i] = 0;
    for (i = 0; i < sizeof rev_u.sp / 4u; i++)
        rev_u.sp[i] = 0;
    for (i = 0; i < 4u; i++)
        fx.comb_lp[i] = 0;
    for (i = 0; i < 4u; i++) fx.comb_i[i] = 0;
    for (i = 0; i < 2u; i++) fx.ap_i[i] = 0;
    fx.sp_w = 0; fx.sp_size = 0; fx.sp_ph = 0;
    fx.sp_lp = fx.sp_hp = fx.sp_he = 0;
    memset(&hl, 0, sizeof hl);
    memset(church_er, 0, sizeof church_er);
    church_w=0; church_mid=church_side=0;
}

static void rev_render(uint32_t type, const int32_t *in, int32_t *out, uint32_t n)
{
    (void)type;rev_church(in,out,n);
}
static int32_t part_buf[CTL];                            /* a part's block (mix_part); the fade of a model change */

static void fx_buses(const int32_t *cho_in, const int32_t *dly_in, const int32_t *rev_in, int32_t *wet,
                     uint32_t n)
{
    uint32_t i, dl = delay_samples();
    int32_t fb = song.g[G_DFDBK] * 230, col = 2000 + song.g[G_DCOLOR] * 240;
    int32_t dmix = song.g[G_DMIX] * 258;
    int32_t cdepth = song.g[G_CDEPTH] * 6;
    uint32_t cinc = LFO_INC[song.g[G_CRATE] & 127] / CTL;
    if (dl != fx.dly_dl) {                              /* ChoralRoot (fx_smooth): a new delay time crossfades */
        if (fx.dly_dl && fx_smooth) {
            fx.dly_old = fx.dly_xf > DLY_XF / 2u ? fx.dly_old : fx.dly_dl;   /* (mid-fade: the nearer of the two) */
            fx.dly_xf = DLY_XF;
        }
        fx.dly_dl = (uint16_t)dl;
    }
    for (i = 0; i < n; i++) {
        int32_t y = 0, x, r;
        /* chorus: modulated short delay, 5..15 ms */
        cho_buf[fx.cho_w & (CHO_LEN - 1u)] = (int16_t)clamp(cho_in[i] >> 1, -32768, 32767);
        fx.cho_ph += cinc;
        r = (400 << 8) + ((osc_sine(fx.cho_ph) + 32768) * cdepth >> 8);   /* Q8 delay: read between samples */
        {
            uint32_t ri = (uint32_t)r >> 8;
            int32_t f = r & 255, c0 = cho_buf[(fx.cho_w - ri) & (CHO_LEN - 1u)];
            int32_t c1 = cho_buf[(fx.cho_w - ri - 1u) & (CHO_LEN - 1u)];
            y += (c0 + (((c1 - c0) * f) >> 8)) * 2;
        }
        fx.cho_w++;
        /* delay with a low-passed feedback */
        x = dly_buf[(fx.dly_w - dl) & (DLY_LEN - 1u)];
        if (fx.dly_xf) {                                /* from the old tap to the new one, linear */
            int32_t xo = dly_buf[(fx.dly_w - fx.dly_old) & (DLY_LEN - 1u)];
            x += (int32_t)(((xo - x) * (int32_t)fx.dly_xf) / (int32_t)DLY_XF);
            fx.dly_xf--;
        }
        fx.dly_lp += mulq15(x - fx.dly_lp, col);
        dly_buf[fx.dly_w & (DLY_LEN - 1u)] =
            (int16_t)clamp((dly_in[i] >> 1) + mulq15(fx.dly_lp, fb), -32768, 32767);
        fx.dly_w++;
        y += mulq15(x * 2, dmix);
        wet[i] = y;
    }
    hl.side = 0;
    for (i = 0; i < n; i++) rev_stereo[i] = 0;
    if(fx.rtype!=3)rev_clear();
    fx.rtype=3; /* Church is the only running algorithm. */
    rev_church(rev_in,wet,n);
    if(hl.side){uint32_t width=(uint32_t)clamp(song.g[G_RTYPE],0,127)*516u;for(i=0;i<n;i++)rev_stereo[i]=mulq16(rev_side[i],width); }

}

/* one block of the whole mix (shared with hostsim.c): events -> each part (with its modulation matrix)
 * -> dist -> SLICER -> level / pan / sends -> buses -> master; out: stereo Q15 */
static void events_block(uint32_t n);                    /* seq.c */
static int32_t send_c[CTL], send_d[CTL], send_r[CTL], wet[CTL], mix_l[CTL], mix_r[CTL];
#if FELUCCA_UAC
/* USB audio's "ChoralRoot In" (usb_audio_stream.c ua_audio), one block's frames of six channels: 0-1 the master
 * (choralroot.c's mix_block shim: before the click), 2-3 the CHORD part, 4-5 the BASS part,
 * each part's dry stereo as it goes into the mix (after DIST, LEVEL, pan and the stereo side, before the sends, the
 * FX buses and MASTER), at half level (-6 dB: a loud chord there is ~2x the limiter's threshold) and saturated to
 * 16 bits. Filled only while the computer records (ua_stage_on: the shim sets it for the block from ChoralRoot In's
 * alternate setting); else the ISR does none of this */
#define UA_CAP_CHANNELS 6u
#define UA_PART_CAPTURED 2u                             /* parts 0 (CHORD) and 1 (BASS) */
static int16_t ua_stage[CTL * UA_CAP_CHANNELS] __attribute__((aligned(4)));
static uint8_t ua_stage_on;
static inline int16_t ua_sat(int32_t x) { return (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x); }
typedef uint32_t __attribute__((may_alias)) ua_pair_t;  /* a part's stereo frame, two int16, moved as one word (the
                                                         * stage is 4-aligned and a frame is 12 bytes: its part pairs
                                                         * are at 4 and 8) */
static uint32_t ua_dl[CLN_DLEN * UA_PART_CAPTURED];
static uint32_t ua_dl_w;
static uint8_t ua_dl_on;
_Static_assert(UA_PART_CAPTURED == 2u && UA_CAP_CHANNELS == 6u, "ua_parts_late's frame");
static __attribute__((noinline)) void ua_parts_late(int16_t *st, uint32_t n)
{
    uint32_t i, w = ua_dl_w;
    if (!ua_dl_on) {
        for (i = 0; i < CLN_DLEN * UA_PART_CAPTURED; i++)
            ua_dl[i] = 0;
        ua_dl_on = 1;
    }
    for (i = 0; i < n; i++) {
        ua_pair_t *s = (ua_pair_t *)(void *)(st + i * UA_CAP_CHANNELS + 2u);
        uint32_t *in = ua_dl + 2u * w, *o = ua_dl + 2u * ((w + CLN_DLEN - CLN_LA) & (CLN_DLEN - 1u));
        uint32_t c = s[0], b = s[1];                    /* (CLN_LA = CLN_DLEN: the same cell, read before written) */
        s[0] = o[0];
        s[1] = o[1];
        in[0] = c;
        in[1] = b;
        w = (w + 1u) & (CLN_DLEN - 1u);
    }
    ua_dl_w = w;
}
#endif

/* one synth part into the dry mix and the sends; a part with no voice sounding costs
 * the LFO tick and a cleared buffer only (after the DIST tail has run out) */
static void mix_part_out(track_t *t, int32_t *b, int32_t *side, uint8_t side_on, uint32_t nr, uint32_t n)
{
    morph_fade_pcm(t,b,side_on?side:0,n);

    int32_t *sd;
    uint32_t i;
#if FELUCCA_UAC
    int16_t *pc = ua_stage_on && (uint32_t)(t - trk) < UA_PART_CAPTURED ? ua_stage + 2u + 2u * (uint32_t)(t - trk) : 0;
#endif
    if (nr)
        t->tail = 16;                                   /* blocks of DIST state to run out after the last voice */
    else if ((!t->tail || !t->p[P_DIST] || !--t->tail) && !slicer_busy(t)) {
        slicer_track(t, 0, n);                          /* (the SLICER's step clock runs on) */
        if (MODP(t).on)
            mod_end(t);
        morph_end(t);
        return;
    }
    {
        int32_t lv = t->p[P_LEVEL] & 127, lvl, pan = t->p[P_PAN];
        if (t->trim && lv)                              /* the sound's trim (ChoralRoot), after LEVEL: 0.5 dB steps */
            lv = clamp(lv + t->trim, 1, 127);
        lvl = LEVEL_Q12[lv];
        /* -2.5dB engine balance, after distortion; calculated once per block. */
        if((FELUCCA_PROPHET && t->engine==ENGI_PROPHET) || (FELUCCA_CZ && t->engine==ENGI_CZ) || (FELUCCA_BASS && t->engine==ENGI_BASS))lvl=mulq15(lvl,24573);
#if FELUCCA_VA
        pan = va_pan(t, pan);                           /* eng_va.c: VA's matrix PAN */
#endif
#if FELUCCA_QUAD
        pan = quad_pan(t, pan);                         /* eng_quad.c: QUAD's LFO -> PAN */
#endif
        int32_t gl = 4096 - (pan > 0 ? pan * 64 : 0), gr = 4096 + (pan < 0 ? pan * 64 : 0);
        int32_t c = t->p[P_CHOR] * 258, d = t->p[P_DLY] * 258, r = t->p[P_REV] * 258, pk = t->peak;
        int32_t xmax = c > d ? c : d;
        xmax = 0x7FFFFFFF / ((xmax > r ? xmax : r) | 1);   /* sends: loud chords at a high LEVEL */
        /* a stereo side (voice.c part_side: VA's SPREAD / USPREAD): DIST works on the mid, the SLICER plays the part
         * mono, the FX layer's mute fades both; the sends take the mid */
        sd = side_on && !t->p[P_SLCR] && !slicer_busy(t) ? side : 0;
        track_dist(t, b, n);
        slicer_track(t, b, n);                          /* slicer.c: before the level, pan and sends */
        if ((pf.mute >> (t - trk)) & 1u) {
            if (sd) {
                int32_t mg = pf.mg[t - trk];
                perf_mute((uint32_t)(t - trk), sd, n);
                pf.mg[t - trk] = mg;
            }
            perf_mute((uint32_t)(t - trk), b, n);       /* perform.c: a black key in the FX layer */
        }
        if (sd) {
            for (i = 0; i < n; i++) {
                int32_t x = ((b[i] >> 2) * lvl) >> 10, a = x < 0 ? -x : x;
                int32_t xs = clamp(x, -xmax, xmax), y = ((sd[i] >> 2) * lvl) >> 10;
                if (a > pk)
                    pk = a;
                if (c)
                    send_c[i] += mulq15(xs, c);
                if (d)
                    send_d[i] += mulq15(xs, d);
                if (r)
                    send_r[i] += mulq15(xs, r);
                {
                    int32_t l = ((x - y) * gl) >> 12, rr = ((x + y) * gr) >> 12;
                    mix_l[i] += l;
                    mix_r[i] += rr;
#if FELUCCA_UAC
                    if (pc) {
                        pc[i * UA_CAP_CHANNELS] = ua_sat(l >> 1);
                        pc[i * UA_CAP_CHANNELS + 1u] = ua_sat(rr >> 1);
                    }
#endif
                }
            }
            t->peak = pk;
            if (MODP(t).on)
                mod_end(t);
            morph_end(t);
            return;
        }
        for (i = 0; i < n; i++) {
            /* pre-shift: 8 loud voices; saturate where the level (+7.5 dB) or the pan would overflow (FM6's 16
             * voices keep Dexed's headroom; Melodee's) */
            int32_t x = clamp(((clamp(b[i], -884000, 884000) >> 2) * lvl) >> 10, -524287, 524287), a = x < 0 ? -x : x;
            int32_t xs = clamp(x, -xmax, xmax);         /* sends: mulq15 would overflow */
            if (a > pk)
                pk = a;
            if (c)
                send_c[i] += mulq15(xs, c);
            if (d)
                send_d[i] += mulq15(xs, d);
            if (r)
                send_r[i] += mulq15(xs, r);
            {
                int32_t l = (x * gl) >> 12, rr = (x * gr) >> 12;
                mix_l[i] += l;
                mix_r[i] += rr;
#if FELUCCA_UAC
                if (pc) {
                    pc[i * UA_CAP_CHANNELS] = ua_sat(l >> 1);
                    pc[i * UA_CAP_CHANNELS + 1u] = ua_sat(rr >> 1);
                }
#endif
            }
        }
        t->peak = pk;
    }
    if (MODP(t).on)
        mod_end(t);                                     /* the stored values back */
    morph_end(t);
}

/* Both native patches belong to the chord MIDI channel. Publish controller
 * values before starting CPU1; each core then owns its render state. */
static void morph_shadow_live(void)
{
    if (!morph_dual || trk[0].engine != ENGI_MORPH) return;
    track_t *a=&trk[0], *b=&trk[2];
    b->mw=a->mw;b->at=a->at;b->foot=a->foot;b->breath=a->breath;
    b->porta=a->porta;b->bend_raw=a->bend_raw;b->ex_off=a->ex_off;
    midi_bend_target[2]=midi_bend_target[0];midi_bend_q8[2]=midi_bend_q8[0];
}

static void mix_part(track_t *t, uint32_t n)
{
    uint32_t nr;
    CR_PROF(CRP_FX);
    morph_begin(t,n);
    if(t==&trk[0])morph_shadow_live();
    mod_begin(t);                                       /* the matrix's per-block values into t->p (mod.c) */
    nr = track_render(t, part_buf, n);
    if(t==&trk[0] && t->engine==ENGI_MORPH && morph_dual){
        morph_b_nr=track_render_x(&trk[2],morph_b_pcm,morph_b_side,&morph_b_side_on,n,0);
    }
    CR_PROF(t == &trk[0] ? CRP_PART0 : t == &trk[1] ? CRP_PART1 : CRP_FX);
    if(t==&trk[0] && t->engine==ENGI_MORPH && morph_dual){
        if(!part_side_on)memset(part_side,0,n*sizeof part_side[0]);
        if(!morph_b_side_on)memset(morph_b_side,0,n*sizeof morph_b_side[0]);
        nr+=morph_b_nr;
        part_side_on|=morph_b_side_on;
    }
    mix_part_out(t, part_buf, part_side, part_side_on, nr, n);
}

#if CR_CPU1
/* ChoralRoot's second core (cr_cpu1.h, docs/DUALCORE.md): part 1's render as core 1's job, into its own buffers.
 * It touches trk[1] (its voices, its LFO's value, its patch, P_E0..7 during an engine fade), its engine's state
 * (eng_state[1], the engine's per-part arrays, fm6_core.c's second scratch) and these; nothing else */
static int32_t c1_buf[CTL] __attribute__((section(".pool"))), c1_side[CTL] __attribute__((section(".pool")));
static uint8_t c1_side_on;
static uint32_t c1_nr;
static uint8_t c1_chord_split;
static uint32_t c1_chord_count, c1_chord_jobs;
static int32_t c1_lfo[2];                               /* the parts' LFO values before this block's tick */
static void c1_part1_job(uint32_t n)
{
    uint32_t t0 = cr_dbg.prof_on ? cr_prof_now() : 0u;
    if (c1_chord_split) chord_render_range(&trk[0], 0, c1_chord_count, n);
    c1_nr = track_render_x(&trk[1], c1_buf, c1_side, &c1_side_on, n, &c1_lfo[1]);
    if(morph_dual && trk[0].engine==ENGI_MORPH)
        morph_b_nr=track_render_x(&trk[2],morph_b_pcm,morph_b_side,&morph_b_side_on,n,0);
    if (cr_dbg.prof_on)
        cr_dbg.cur[CRP_PART1] += cr_prof_less(cr_prof_now() - t0);
}
/* the split is one core's samples bit for bit unless part 0's render draws from the shared generator itself
 * (PHYS: a model change under a note) or both parts play VOICE (one breath-noise generator, eng_formant.c): then
 * this block renders on core 0 alone, as before */
static int c1_split_ok(void)
{
    return trk[0].engine != ENGI_PHYS;
}
/* parts 0 and 1: everything shared first on core 0 (the matrices, the LFOs: their draws from the shared generator in
 * one core's order), part 1 to core 1, part 0 here, then both mixed in one core's order */
static void mix_parts_split(uint32_t n)
{
    track_t *t0 = &trk[0], *t1 = &trk[1];
    uint32_t nr0;
    int ran;
    CR_PROF(CRP_FX);
    morph_begin(t0,n);
    morph_shadow_live();
    mod_begin(t0);
    c1_lfo[0] = mulq15(t0->lfo_val, t0->lfo_fade);
    track_lfo_tick(t0);
    mod_begin(t1);
    c1_lfo[1] = mulq15(t1->lfo_val, t1->lfo_fade);
    track_lfo_tick(t1);
    c1_chord_split = !t0->xf_on && !t0->xf && n <= CTL &&
        (t0->engine == ENGI_CZ || t0->engine == ENGI_PROPHET || ((t0->engine == ENGI_SWARM || t0->engine == ENGI_CLUSTER || eng_novel(t0->engine) || eng_kv(t0->engine)) || t0->engine == ENGI_CLOUD) || t0->engine == ENGI_CS1);
    if (c1_chord_split) {
        chord_plan.count = 0;
        chord_prepare = 1;
        nr0 = track_render_x(t0, part_buf, part_side, &part_side_on, n, &c1_lfo[0]);
        chord_prepare = 0;
        uint32_t limit=chord_worker_voices(t0->engine);
        c1_chord_count = chord_plan.count < limit ? chord_plan.count : limit;
    }
    cr_c1_split = 1;
    ran = cr_c1_run(c1_part1_job, n);
    CR_PROF_SKIP();                                     /* (the host's stub ran it here: counted as part1) */
    if (c1_chord_split)
        chord_render_range(t0, c1_chord_count, chord_plan.count, n);
    else
        nr0 = track_render_x(t0, part_buf, part_side, &part_side_on, n, &c1_lfo[0]);
    CR_PROF(CRP_PART0);
    if (ran && cr_c1_wait()) {                          /* fault injection: do not replay a partial job */
        cr_dbg.c1 = C1_GAVE_UP;
        cr_c1_fault();
    }
    CR_PROF(CRP_WAIT);
    cr_c1_split = 0;
    if (ran)
        cr_dbg.c1_jobs++;
    else
        c1_part1_job(n);
    CR_PROF_SKIP();
    if (c1_chord_split) {
        for (uint32_t j = 0; j < chord_plan.count; j++)
            for (uint32_t k = 0; k < n; k++) part_buf[k] += chord_plan.pcm[j][k];
        if (ran) c1_chord_jobs += c1_chord_count;
        if (ENGINES[t0->engine]->post) ENGINES[t0->engine]->post(t0, part_buf, n, nr0);
        if(ENGINES[t0->engine]->post2)part_side_on |= (uint8_t)ENGINES[t0->engine]->post2(t0,part_buf,part_side,n,nr0);
    }
    if(morph_dual && t0->engine==ENGI_MORPH){
        if(!part_side_on)memset(part_side,0,n*sizeof part_side[0]);
        if(!morph_b_side_on)memset(morph_b_side,0,n*sizeof morph_b_side[0]);
        nr0+=morph_b_nr;
        part_side_on|=morph_b_side_on;
    }
    mix_part_out(t0, part_buf, part_side, part_side_on, nr0, n);
    mix_part_out(t1, c1_buf, c1_side, c1_side_on, c1_nr, n);
}
#endif



/* the master with the FX layer's effects between its level and master_out (perform.c) */
static __attribute__((noinline)) void perf_master(int32_t *out, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        mix_l[i] += wet[i] + rev_stereo[i];
        mix_r[i] += wet[i] - rev_stereo[i];
    }
    perf_block(mix_l, mix_r, n);
    out_master(out, mix_l, mix_r, (const int32_t *)0, n);
}

static void mix_block(int32_t *out, uint32_t n)
{
    uint32_t i;
    int perf;
#if FELUCCA_UAC
    if (ua_stage_on)
        for (i = 0; i < n * UA_CAP_CHANNELS; i++)
            ua_stage[i] = 0;                            /* (a silent part: mix_part leaves its channels) */
#endif
    for (i = 0; i < n; i++)
        send_c[i] = send_d[i] = send_r[i] = mix_l[i] = mix_r[i] = 0;
    CR_PROF_START();
    events_block(n);
    CR_PROF(CRP_TICK);
    perf = perf_begin(n);                               /* the FX hold layer at work (perform.c) */
#if CR_CPU1
    if(cr_dualcore_active() && c1_split_ok()
#ifdef CR_C1_THREADED_TEST
       && !cr_c1_test_serial
#endif
    ) { mix_parts_split(n);i=2; }
    else
#endif
    i=0;
    for (;i<NPART;i++) {
        if(i==2u && morph_dual)continue; /* shadow B is mixed into A */
        mix_part(&trk[i],n);
    }
    if (perf)
        perf_pre(mix_l, mix_r, send_d, send_r, n);
    fx_buses(send_c, send_d, send_r, wet, n);
    if (perf) {
        perf_master(out, n);
        return;
    }
    for (i = 0; i < n; i++) {
        mix_l[i] += wet[i] + rev_stereo[i];
        mix_r[i] += wet[i] - rev_stereo[i];
    }
    out_master(out, mix_l, mix_r, (const int32_t *)0, n);
#if FELUCCA_UAC
    if (ua_stage_on && fx_out_blk) ua_parts_late(ua_stage, n);
    else ua_dl_on = 0;
#endif
}
