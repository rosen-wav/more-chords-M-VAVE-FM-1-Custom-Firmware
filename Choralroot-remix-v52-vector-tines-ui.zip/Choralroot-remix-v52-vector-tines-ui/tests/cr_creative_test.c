/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void image_screen(const char *path){
 cr_screen_t s;cr_build_screen(&s,cu_now());cr_draw(&s,CR_ANIM_SETTLED);FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned i=0;i<240*240;i++){uint16_t c=emu_hal.lcd[i];c=(c>>8)|(c<<8);uint8_t rgb[3]={(uint8_t)(((c>>11)&31)*255/31),(uint8_t)(((c>>5)&63)*255/63),(uint8_t)((c&31)*255/31)};fwrite(rgb,1,3,f);}fclose(f);
}
static void drain(void){cr_audio_block(CTL);cr_snapshot();}
int main(void)
{
 emu_fw_options(0,1,0,1);emu_fw_init(0);unsigned random_cases=0,ideas=0;
 uint8_t before[ENG_BLOB_MAX],after[ENG_BLOB_MAX];int16_t params[P_COUNT];
 for(unsigned e=0;e<NENGINES;e++)if(eng_ok(e))for(unsigned part=0;part<2;part++){
  if(part && e==ENGI_MORPH)continue;
  for(unsigned pr=0;pr<ENGINES[e]->npresets;pr++){
   cu_load(&trk[part],e,pr,part);engine_block(&trk[part]);panic_req=0;
   creative_random.part=part;creative_random.amount=0;creative_random.valid=0;
   fm1_irq_off();creative_capture();fm1_irq_on();
   track_t *t=&trk[part];const eng_deep_t *d=creative_deep(t);
   memcpy(params,t->p,sizeof params);if(d&&d->blob_get)d->blob_get(t,before);
   uint32_t sends[]={P_CHOR,P_REV,P_DLY,P_DIST,P_LEVEL,P_VOICE};
   creative_random_action(0);assert(!memcmp(params,t->p,sizeof params));
   if(d&&d->blob_get){d->blob_get(t,after);assert(!memcmp(before,after,d->blob_size));}
   for(unsigned amount=20;amount<=100;amount+=20){
    creative_random.amount=amount;creative_random_action(0);
    assert(t->eng_req==e);
    for(unsigned k=0;k<NELEM(sends);k++)if(t->p[sends[k]]!=params[sends[k]]){fprintf(stderr,"send mismatch engine%u part%u pr%u id%u before%d after%d\n",e,part,pr,sends[k],params[sends[k]],t->p[sends[k]]);abort();}
    if(d&&d->get && e!=ENGI_MORPH)for(unsigned pg=0;pg<d->npages;pg++)for(unsigned c=0;c<4;c++){
     const param_desc_t *pd=d->desc?d->desc(t,pg,c):0;if(!pd)pd=&d->pages[pg].col[c];
     int value=d->get(t,pg,c);if(pd->max>pd->min && (value<pd->min || value>pd->max)){fprintf(stderr,"range engine%u part%u pr%u pg%u col%u %s value%d range%d..%d\n",e,part,pr,pg,c,pd->label,value,pd->min,pd->max);abort();}
    }
    creative_random_action(1);assert(!memcmp(params,t->p,sizeof params));
    if(d&&d->blob_get){d->blob_get(t,after);assert(!memcmp(before,after,d->blob_size));}
    random_cases++;
   }
  }
 }
 /* Native edits survive normal user encoding. Prophet full record and FM6,
  * CZ/QUAD/VA use their existing blob stores, unchanged by the tool. */
 /* The generated patch is saved through the real USER path, including
  * each native blob family; simulated reboot reloads the complete patch. */
 static const unsigned stored[]={ENGI_FM6,ENGI_VA,ENGI_QUAD,ENGI_CZ,ENGI_PROPHET,ENGI_BASS,ENGI_MORPH};
 for(unsigned i=0;i<NELEM(stored);i++){
  unsigned e=stored[i];cu_load(&trk[0],e,0,0);engine_block(&trk[0]);creative_random.part=0;creative_random.amount=50;creative_random.valid=0;
  creative_random_action(0);const eng_deep_t *d=creative_deep(&trk[0]);memcpy(params,trk[0].p,sizeof params);
  if(d && d->blob_get)d->blob_get(&trk[0],before);
  assert(cb_store(&trk[0],0,31,"RANDOM SAVE",0)==0);
  cu_load(&trk[0],ENGI_FM6,1,0);memset(up_bank,0,sizeof up_bank);up_boot();cu_load_user(&trk[0],31,0);
  assert(trk[0].eng_req==e);
  for(unsigned k=0;k<P_COUNT;k++)if(params[k]!=trk[0].p[k]){fprintf(stderr,"USER save engine%u param%u expected%d actual%d\n",e,k,params[k],trk[0].p[k]);abort();}
  if(d && d->blob_get){d->blob_get(&trk[0],after);assert(!memcmp(before,after,d->blob_size));}
 }
 /* Editor tap MIX is unchanged; a formerly unused REC hold opens the tool
  * for the exact edited part, without navigating away from its page. */
 for(unsigned part=0;part<2;part++){
  ce.part=part;cu.page=PG_EDIT;cu.lock=L_NONE;cx.grp[part]=CE_OSC;
  ce_button(B_REC,CE_TAP);assert(cx.grp[part]==CE_MIX || !ce_has(&trk[part],CE_MIX));
  cx.grp[part]=CE_ENV;unsigned group=cx.grp[part],lane=cx.lane[part][group],screen=cx.scr[part][group];
  assert(ce_button(B_REC,CE_HOLD));assert(cu.page==PG_RANDOMIZER && creative_random.part==part);
  cu_knob(EN_K2,part? -1:1);assert(creative_random.part==part);
  cu_oct_tap(B_OCTDN);assert(cu.page==PG_EDIT && ce.part==part && cx.grp[part]==group && cx.lane[part][group]==lane && cx.scr[part][group]==screen);
  ce_button(B_REC,CE_HOLD);cu_home_tap();assert(cu.page==PG_EDIT);
  ce_button(B_REC,CE_HOLD);cu_tap(BT_EDIT);assert(cu.page==PG_EDIT && ce.part==part);
  ce_button(B_REC,CE_HOLD);unsigned gen=crl.gen;cu_opened(BT_REC);assert(cu.page==PG_RANDOMIZER && crl.gen==gen);
  cu_tap(B_REC);assert(cu.page==PG_EDIT && crl.gen==gen);
  cx.grp[part]=group;
  ce_button(B_REC,CE_HOLD);cu_tap(BT_SAVE);assert(cu.page==PG_SAVE && ce.save_part==part && ce.save_from_edit);cu_save_close();assert(cu.page==PG_EDIT);
 }
 /* Real scanned press/hold/release path: no recording/undo side effect. */
 for(unsigned part=0;part<2;part++){
  cu_load(&trk[part],ENGI_FM6,0,part);ce.part=part;cu.page=PG_EDIT;cu.lock=L_NONE;cu.armed=NB;cu.open=cu.combo=0;cu.bheld=0;
  drain();unsigned generation=crl.gen;
  uint32_t time=fm1_ms+20u;emu_hal.buttons=1u<<panel.btn[B_REC];emu_fw_tick(time);cr_ui_input();
  emu_fw_tick(time+HOLD_MS[settings_hold%4u]+1u);cr_ui_input();drain();
  assert(cu.page==PG_RANDOMIZER && creative_random.part==part && crl.gen==generation);
  emu_hal.buttons=0;emu_fw_tick(fm1_ms+20u);cr_ui_input();drain();assert(cu.page==PG_RANDOMIZER);
  cu_oct_tap(B_OCTDN);assert(cu.page==PG_EDIT && ce.part==part);
 }
 ce.part=1;cu.page=PG_EDIT;creative_open_random();assert(cu.page==PG_RANDOMIZER);
 cu_knob(EN_K2,1);assert(creative_random.part==1);
 cu_knob(EN_K1,100);assert(creative_random.amount==100);
 cu_knob(EN_K1,-200);assert(creative_random.amount==0);
 cu_knob(EN_K3,1);cu_knob(EN_K4,1);
 if(getenv("CREATIVE_SCREENSHOTS"))image_screen("build/creative-tests/randomizer.ppm");
 cu_oct_tap(B_OCTDN);assert(cu.page==PG_EDIT);
 /* All tonics/modes/patterns and supported loop lengths: semantic chords,
  * legal four/four grid, packed roundtrip, staged without touching loop. */
 cr_loop_clear(&crl,&cr);cr_snapshot();
 crl_data_t old=crl.d,roundtrip;uint8_t packed[CRL_REC_MAX];
 for(unsigned len=0;len<5;len++)for(unsigned tonic=0;tonic<12;tonic++)for(unsigned minor=0;minor<2;minor++)for(unsigned pattern=0;pattern<7;pattern++){
  cs.loop_len=len;creative_ideas.tonic=tonic;creative_ideas.minor=minor;creative_ideas.pattern=pattern;
  creative_generate();assert(creative_ideas.ready&&crl_stage_busy==3);
  assert(!memcmp(&crl.d,&old,sizeof old));assert(crl_stage.nev==4 && crl_stage.sig==CRL_SIG_44);
  assert(crl_stage.len<=CRL_MAX_LEN && crl_stage.grid_n<=CRL_GRID_MAX);
  assert(crl_stage.ev[0].root==48+tonic+(pattern==3?(minor?8:9):pattern==6?2:0));
  for(unsigned i=0;i<4;i++){
   const crl_ev_t *e=&crl_stage.ev[i];assert(e->root<72&&e->vel==100);
   assert(e->dur && e->t+e->dur<=crl_stage.len);
   assert((e->qx>>4)==CR_Q_MAJ || (e->qx>>4)==CR_Q_MIN || (e->qx>>4)==CR_Q_DIM || (e->qx>>4)==CR_Q_SUS);
  }
  unsigned bytes=cr_loop_pack(&crl_stage,packed,sizeof packed);assert(bytes);
  assert(cr_loop_unpack(packed,bytes,&roundtrip));assert(roundtrip.nev==4 && roundtrip.len==crl_stage.len);assert(!memcmp(roundtrip.ev,crl_stage.ev,4*sizeof(crl_ev_t)));
  creative_cancel_ideas();assert(!crl_stage_busy);ideas++;
 }
 cu.step_editor=1;cu.lock=L_METRO;cu.page=PG_NONE;
 cu_opened(BT_REC);assert(cu.page==PG_IDEAS&&creative_ideas.ready);
 cu_knob(EN_K1,-100);cu_knob(EN_K2,-100);cu_knob(EN_K3,-100);
 assert(!creative_ideas.tonic&&!creative_ideas.minor&&!creative_ideas.pattern);
 cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(screen.kind==CR_K_KNOBROW && !strcmp(screen.title,"Chord Ideas"));
 assert(screen.n_items==4 && strstr(screen.item[0],"C") && strstr(screen.item[2],"Am"));
 if(getenv("CREATIVE_SCREENSHOTS"))image_screen("build/creative-tests/ideas.ppm");
 cu_tap(BT_FX);assert(!memcmp(&crl.d,&old,sizeof old));
 cu_oct_tap(B_OCTDN);assert(cu.page==PG_NONE&&!crl_stage_busy&&cu.step_editor);
 creative_open_ideas();cu_home_tap();assert(!crl_stage_busy&&!creative_ideas.ready);
 creative_open_ideas();cu_oct_tap(B_OCTUP);drain();assert(crl.d.nev==4&&crl.dirty&&crl.state==CRL_STOPPED);
 assert(cu.step_editor&&cu.page==PG_NONE&&!crl_stage_busy);
 cr_loop_play(&crl,&cr);cr_snapshot();old=crl.d;
 creative_open_ideas();cu_tap(BT_LOOP);drain();assert(cr_idea.armed);
 for(unsigned i=0;i<3000u && !cr_idea.active;i++)drain();assert(cr_idea.active && !memcmp(&crl.d,&old,sizeof old));
 creative_accept();drain();assert(!creative_ideas.ready&&!crl_stage_busy && !cr_idea.active && crl.dirty);
 /* Another pending load cannot be overwritten; REC capture refuses generation. */
 creative_open_ideas();assert(creative_ideas.ready);crl_stage_busy=0;creative_accept();assert(!creative_ideas.ready);
 crl_stage_busy=1;creative_open_ideas();assert(!creative_ideas.ready);crl_stage_busy=0;
 crl.cap=CRL_CAP_REC;cr_snapshot();creative_generate();assert(!creative_ideas.ready);crl.cap=CRL_CAP_NONE;
 printf("Creative pool state %zu B, ideas control %zu B; loop staging reused\n",sizeof creative_random,sizeof creative_ideas);
 printf("PASS: creative tools %u engine/preset/part/amount randomizer + exact Undo fixtures; %u tonal progression/storage fixtures, native USER reboot saves, confirm/cancel and transport guards\n",random_cases,ideas);
 return 0;
}
