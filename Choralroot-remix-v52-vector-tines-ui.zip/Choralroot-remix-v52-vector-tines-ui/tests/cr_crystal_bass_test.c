/* UI + real queued internal/external clock + bass note ownership. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned active(void){unsigned n=0;for(unsigned i=0;i<128;i++)n+=cr.reg[CR_STREAM_BASS][i]!=0;return n;}
static int pitch(void){for(int i=0;i<128;i++)if(cr.reg[CR_STREAM_BASS][i])return i;return -1;}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 unsigned old=cs.perf_sel; unsigned performing=cs.perform_on;
 assert(O_CRYSTAL_BASS==0 && cu.opt_sel==0 && !strcmp(O_NAME[0],"crystal castles bass mode"));
 assert(cu_layer_count(L_PERF)==7);
 opt_set(O_CRYSTAL_BASS,1);cr_audio_block(CTL);assert(cr.crystal_bass&&cs.crystal_bass);
 assert(cs.perf_sel==old && cs.perform_on==performing);
 cr_screen_t s;memset(&s,0,sizeof s);cu_options_screen(&s);
 assert(!strcmp(s.value,"On")&&s.sel==0);
 char text[16];opt_text(O_CRYSTAL_BASS,text,sizeof text);assert(!strcmp(text,"On"));
 cr_set_bass(&cr,1);cr_set_stream(&cr,CR_STREAM_BASS,1);cr_set_bass_mode(&cr,CR_BASS_UNISON);cr_set_sticky(&cr,0);cr_set_perform(&cr,0);cr_key(&cr,60,100,1);
 cr_bass_clock_phase(&cr,0);int root=pitch();assert(root>=0&&active()==1);
 for(unsigned i=0;i<200;i++){cr_bass_clock_phase(&cr,i&1);assert(active()==1&&pitch()==root+12*(int)(i&1));}
 /* Internal quarter grid: exactly two alternating eighths, outside loops. */
 cr_route.clock_in=0;crl.met0=crl.t;cr_audio_block(CTL);assert(pitch()==root);
 crl.met0=crl.t-CRL_PPQN/2;cr_audio_block(CTL);assert(pitch()==root+12);
 opt_set(O_CRYSTAL_BASS,0);cr_audio_block(CTL);assert(pitch()==root&&!cr.crystal_bass);
 opt_set(O_CRYSTAL_BASS,1);cr_audio_block(CTL);
 /* External MIDI pulses routed through the production parser. */
 cr_route.clock_in=1;cr_audio_block(CTL);cr_cin.bpm=120;
 unsigned base=10000;for(unsigned i=0;i<25;i++){
  fm1_ms=base+i*60000u/(120u*24u);assert(midi_enqueue(0xF8u<<8|0x0Fu,2));cr_audio_block(CTL);
  assert(pitch()==root+(cr_sidechain_midi_step>=12?12:0));assert(active()==1);
 }
 for(unsigned i=0;i<FS/CTL;i++)cr_audio_block(CTL);
 int frozen=pitch();for(unsigned i=0;i<20;i++)cr_audio_block(CTL);assert(pitch()==frozen);
 cr_key(&cr,60,0,0);assert(!active());cr_bass_clock_phase(&cr,1);assert(!active());
 cr_key(&cr,62,100,1);assert(active()==1);cr_panic(&cr);assert(!active());
 /* Highest bass register must never wrap an octave beyond MIDI 127. */
 cr.bass_mode=CR_BASS_UNISON;cr.bass_voicing=0;cr_key(&cr,120,100,1);cr_bass_clock_phase(&cr,1);assert(pitch()==120);cr_panic(&cr);
 cu_layer_pick(L_PERF,3);assert(cs.perf_sel==3);
 puts("PASS: crystal castles bass mode first setting/UI/queue, root/octave ownership, internal and TRS MIDI eighth grid, clock loss, release/panic, range, independent chord arp");
}
