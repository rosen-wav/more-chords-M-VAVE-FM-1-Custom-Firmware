/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define NVOICE 16
#define CTL 32u
#define FS 44100u
#define NELEM(a) (sizeof(a)/sizeof((a)[0]))
#include "../firmware/src/cs1_native.h"
#include "../firmware/src/cs1_tones.h"
#include "../firmware/src/cs1_factory.h"
static cs1_part_t e;
static csn_patch_t p;
int main(void){uint64_t energy=0;unsigned count=0;uint32_t rng=12345;
 for(unsigned preset=0;preset<52;preset++)for(unsigned stress=0;stress<3;stress++){
  memset(&e,0,sizeof e);cs1_factory(&p,preset);e.patch_ptr=&p;e.noise_st=1234;
  if(stress){uint8_t *b=(uint8_t*)&p;for(unsigned i=0;i<sizeof p;i++)b[i]=stress==1?127:csn_noise32(&rng)%128;p.ch[0].feet%=6;p.ch[1].feet%=6;p.ch[0].wave%=3;p.ch[1].wave%=3;p.lfo_wave%=5;p.cho_mode%=3;p.gliss%=2;}
  csn_voice_t *v=&e.voices[0];v->note=(preset*11)%128;v->vel=127;v->trig=1;v->active=v->gate=1;v->drift_rng=123;
  for(unsigned k=0;k<4096;k++){int32_t mix[CTL]={0},out[2*CTL]={0};if(k==128)v->gate=0;csn_block_prepare(&e);cs1_kernel(&e,v,v->note*256,mix);for(unsigned j=0;j<CTL;j++){energy+=llabs(mix[j]);mix[j]/=4;}csn_output(&e,mix,out,CTL);count+=CTL;}
 }
 assert(energy);printf("PASS: CS-1 native DSP %u samples, 52 recipes and extreme/random panels under UBSan\n",count);return 0;
}
