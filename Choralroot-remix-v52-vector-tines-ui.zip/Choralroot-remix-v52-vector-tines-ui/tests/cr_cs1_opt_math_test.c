/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define NVOICE 16
#define CTL 32u
#define FS 44100u
#include "../firmware/src/cs1_native.h"
int main(void){
 uint32_t seed=74;csn_div_t d={0};unsigned count=0;
 for(unsigned i=0;i<3000000;i++){
  seed=seed*1664525u+1013904223u;uint32_t den=seed?seed:1;
  if(i<131072u)den=i+1u;
  csn_div_prepare(&d,den);
  for(unsigned j=0;j<3;j++){
   uint32_t n=j==0?0:j==1?UINT32_MAX:seed^0x58a51273u;
   assert(csn_div_exact(&d,n)==n/den);count++;
  }
 }
 csn_div_t edge={0};
 for(unsigned i=0;i<1000000;i++){
  seed=seed*1664525u+1013904223u;uint32_t inc=200000u+(seed%1500000000u);
  uint32_t ph=(i%3u==0)?seed:(i%3u==1)?seed%inc:UINT32_MAX-(seed%inc);
  assert(csn_blep_cached(ph,inc,&edge)==csn_blep(ph,inc));
 }
 for(int cut=-16;cut<=2176;cut++)for(int k=1310;k<=8192;k+=127){
  csn_svf_t c={0};csn_svf_coef(&c,cut,k);csn_svf_t before=c;
  csn_svf_coef(&c,cut,k);assert(!memcmp(&before,&c,sizeof c));
  int32_t cl=cut<0?0:cut>2160?2160:cut,i=cl>>4;
  int32_t g=csn_SVF_G[i]+(((csn_SVF_G[i+1]-csn_SVF_G[i])*(cl&15))>>4);
  int32_t den=4096+((g*(g+k))>>12);
  assert(c.a1==(int32_t)((4096u<<13)/(uint32_t)den));
 }
 printf("PASS: %u exact reciprocal divisions, 1000000 BLEP edges, complete cutoff/coefficient cache ranges under UBSan\n",count);
}
