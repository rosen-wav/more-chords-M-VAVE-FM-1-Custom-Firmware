/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#define NVOICE 16
#define CTL 32u
#define FS 44100u
#define NELEM(a) (sizeof(a)/sizeof((a)[0]))
#ifndef CS1_NATIVE_HEADER
#define CS1_NATIVE_HEADER "../firmware/src/cs1_native.h"
#endif
#include CS1_NATIVE_HEADER
#include "../firmware/src/cs1_tones.h"
#include "../firmware/src/cs1_factory.h"
static cs1_part_t e;static csn_patch_t p;
int main(int argc,char **argv){
 assert(argc==2);FILE *f=fopen(argv[1],"wb");assert(f);uint32_t rng=774;
 for(unsigned preset=0;preset<52;preset++)for(unsigned stress=0;stress<3;stress++){
  memset(&e,0,sizeof e);cs1_factory(&p,preset);e.patch_ptr=&p;e.noise_st=1234;
  if(stress){uint8_t *b=(uint8_t*)&p;for(unsigned i=0;i<sizeof p;i++)b[i]=stress==1?127:csn_noise32(&rng)%128;p.ch[0].feet%=6;p.ch[1].feet%=6;p.ch[0].wave%=3;p.ch[1].wave%=3;p.lfo_wave%=5;p.cho_mode%=3;p.gliss%=2;}
  for(unsigned v=0;v<6;v++){csn_voice_t *w=&e.voices[v];w->note=36+v*5;w->vel=40+v*15;w->trig=1;w->active=w->gate=1;w->drift_rng=123+v;}
  for(unsigned block=0;block<384;block++){
   if(block%47==0){p.brill=(p.brill+11)%128;p.aat_level=(p.aat_level+31)%128;p.ch[1].hp_cut=(p.ch[1].hp_cut+13)%128;}
   int32_t mix[CTL]={0},out[CTL*2]={0};csn_block_prepare(&e);
   for(unsigned v=0;v<6;v++){
    csn_voice_t *w=&e.voices[v];w->at=(block*3+v*7)%128;
    if(block==200)w->gate=0;
    if(block==230){w->gate=1;w->trig++;w->note+=2;w->vel=127-w->vel;}
    if(block==300)w->gate=0;
    cs1_kernel(&e,w,w->note*256,mix);
    for(unsigned ch=0;ch<2;ch++){
     csn_chan_state_t *c=&w->c[ch];
     int32_t state[]={c->h1,c->h2,c->l1,c->l2,c->fenv,c->fenv_inc,c->venv,c->amp,c->at16,c->fstage,c->vstage,c->hp.a1,c->hp.a2,c->hp.a3,c->hp.k,c->lp.a1,c->lp.a2,c->lp.a3,c->lp.k};
     fwrite(state,sizeof state,1,f);fwrite(&c->ph,sizeof c->ph,1,f);
    }
   }
   fwrite(mix,sizeof mix,1,f);for(unsigned i=0;i<CTL;i++)mix[i]/=4;
   csn_output(&e,mix,out,CTL);fwrite(out,sizeof out,1,f);
  }
 }
 fclose(f);return 0;
}
