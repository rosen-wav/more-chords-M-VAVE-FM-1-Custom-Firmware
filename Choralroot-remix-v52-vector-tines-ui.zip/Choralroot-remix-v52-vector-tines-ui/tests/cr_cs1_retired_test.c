#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(!eng_ok(ENGI_CS1));assert(ENGINES[ENGI_CS1]==&ENG_GONE);
 for(unsigned i=0;i<NENG_SHOWN;i++){assert(ENGINE_ORDER[i]!=ENGI_CS1);assert(eng_ok(ENGINE_ORDER[i]));for(unsigned j=0;j<i;j++)assert(ENGINE_ORDER[i]!=ENGINE_ORDER[j]);}
 for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)assert(MORPH_SOURCE[i]!=ENGI_CS1);
 assert(eng_ok(ENGI_KR106)&&eng_ok(ENGI_PROPHET)&&eng_ok(ENGI_CZ));
 assert(up_heir(ENGI_CS1)==ENGI_FM6);
 up_rec_t r={0};r.used=UP_USED;r.ver=6;r.engine=ENGI_CS1;r.np=P_COUNT;memcpy(r.name,"OLD CS1",8);assert(!up_valid(&r));
 for(unsigned part=0;part<NPART;part++){assert(!crs_sound(part,ENGI_CS1<<8));}
 assert(chord_worker_voices(ENGI_PROPHET)==2&&chord_worker_voices(ENGI_CZ)==2&&chord_worker_voices(ENGI_KR106)==2);
 puts("PASS: CS1 retired ID, hidden engine/order/Morph, rejected legacy CS1 USER/settings, other engines and 4+2 policies intact");return 0;
}
