/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 pthread_t th;int32_t pcm[2*CTL];unsigned cases=0;uint64_t total=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(ENGI_CS1==21&&NENGINES==22);assert(ENGINES[ENGI_CS1]->npresets==52);
 for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)assert(MORPH_SOURCE[i]!=ENGI_CS1);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 printf("CS-1 sizes: native part %zu; existing FM6 union member %zu; patch %zu; patch pool %zu\n",sizeof(cs1_part_t),sizeof(fm6_part_t),sizeof(csn_patch_t),sizeof cs1_patch);
 const unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_QUAD,ENGI_VA,ENGI_CZ,ENGI_PROPHET,ENGI_KR106};
 for(unsigned p=0;p<52;p++)for(unsigned b=0;b<NELEM(basses);b++){
  unsigned bass=basses[b];
  cr_c1_test_serial=1;setup(ENGI_CS1,p,bass,0,6,0);
  for(unsigned k=0;k<128;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);
  cr_c1_test_serial=0;setup(ENGI_CS1,p,bass,0,6,0);
  unsigned active=0;for(unsigned i=0;i<NVOICE;i++)active+=trk[0].v[i].active&&trk[0].v[i].gate;assert(active==6);
  uint64_t energy=0;for(unsigned k=0;k<128;k++){block(k,pcm);if(k==0)assert(c1_chord_count==3);assert(!memcmp(pcm,reference[k],sizeof pcm));for(unsigned j=0;j<2*CTL;j++){assert(pcm[j]>=-32768&&pcm[j]<=32767);energy+=llabs(pcm[j]);}}
  if(memcmp(states,eng_state,sizeof states)){printf("state mismatch preset %u bass %u\n",p,bass);return 1;}
  assert(energy>0);total+=energy;cases++;
 }
 /* CS-1 must be audible by itself, not merely the Bass in the mixed fixtures. */
 for(unsigned preset=0;preset<52;preset++){
  setup(ENGI_CS1,preset,ENGI_BASS,0,6,0);trk_all_off(&trk[1]);uint64_t energy=0;
  for(unsigned k=0;k<512;k++){for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);for(unsigned j=0;j<2*CTL;j++)energy+=llabs(pcm[j]);}
  assert(energy>1000);cases++;
 }
 for(unsigned part=0;part<1;part++)for(unsigned preset=0;preset<52;preset++){
  track_t *t=&trk[part];cu_load(t,ENGI_CS1,preset,part);engine_block(t);assert(cs1_blob_valid((uint8_t*)cs1_patch_of(t)));
  for(unsigned pg=0;pg<NELEM(CS1_PAGES);pg++)for(unsigned c=0;c<4;c++)cs1_set(t,pg,c,CS1_PAGES[pg].col[c].max/2);
  t->p[P_REV]=77;t->p[P_DLY]=23;t->p[P_PAN]=-22;
  uint8_t expected[102],actual[102];cs1_blob_get(t,expected);
  assert(cb_store(t,part,31,"CS1 SAVE",0)==0);assert(up_valid(up_rec(31)));assert(up_rec(31)->ver==6);
  memset(cs1_patch_of(t),0,102);cu_load_user(t,31,part);engine_block(t);cs1_blob_get(t,actual);assert(!memcmp(expected,actual,102));assert(t->p[P_REV]==77&&t->p[P_DLY]==23);
  cs1_set(t,4,2,37);cs1_blob_get(t,expected);assert(cb_store(t,part,31,"CS1 OVER",preset+1)==0);
  memset(cs1_ready,0,sizeof cs1_ready);memset(eng_state,0,sizeof eng_state);cu_load_user(t,31,part);engine_block(t);cs1_blob_get(t,actual);assert(!memcmp(expected,actual,102));cases++;
 }
 cu_load(&trk[0],ENGI_CS1,0,0);engine_block(&trk[0]);ce_open(0);
 unsigned in_group[5]={0};
 for(unsigned pg=0;pg<NELEM(CS1_SCREENS);pg++){
  unsigned group=CS1_SCREENS[pg].sec;cx.grp[0]=group;cx.scr[0][group]=in_group[group]++;cx.lane[0][group]=0;
  unsigned page=CS1_SCREENS[pg].pg[0];cs1_set(&trk[0],page,0,0);cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(strstr(screen.page,"CS-1"));
  ce_knob(0,1,0);assert(cs1_get(&trk[0],page,0)>0);
 }
 ce_close();
 uint8_t blob[102];cs1_blob_get(&trk[0],blob);blob[0]=255;assert(!cs1_blob_apply(&trk[0],blob));
 cr_dbg.c1=C1_FAILED;audio_worker_online=0;assert(cs1_cap(&trk[0])==5&&cs1_cap(&trk[1])==1);
 pthread_cancel(th);pthread_join(th,0);
 printf("PASS: CS-1 %u native factory/worker/USER fixtures, exact serial and CPU1 PCM/state, six voices, complete overwrite/reload, Morph exclusion; energy %llu\n",cases,(unsigned long long)total);return 0;
}
