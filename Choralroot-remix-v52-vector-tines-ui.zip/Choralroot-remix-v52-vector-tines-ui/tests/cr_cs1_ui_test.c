/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static void shot(unsigned group,unsigned index,const char *name){
 cx.grp[0]=group;cx.scr[0][group]=index;cx.lane[0][group]=0;cu.pop.until=cu.msg.until=0;
 cr_screen_t s;cr_build_screen(&s,cu_now());assert(strstr(s.page,"CS-1"));
 if(group==2u){assert(s.wide==CR_W_ADE2&&s.wv[9]==2);assert(s.cell[1][0].label[0]);}
 if(group==0u)assert(s.cell[1][0].label[0]);
 cr_draw(&s,CR_ANIM_SETTLED);char path[160];snprintf(path,sizeof path,"build/host/cs1-%s.ppm",name);
 FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned i=0;i<240*240;i++){uint16_t c=emu_hal.lcd[i];c=(c>>8)|(c<<8);uint8_t rgb[3]={(uint8_t)(((c>>11)&31)*255/31),(uint8_t)(((c>>5)&63)*255/63),(uint8_t)((c&31)*255/31)};fwrite(rgb,1,3,f);}fclose(f);
}
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);setup(ENGI_CS1,0,ENGI_BASS,0,0,0);engine_block(&trk[0]);ce_open(0);
 cs1_set(&trk[0],0,0,0);cs1_set(&trk[0],2,0,0);
 cx.grp[0]=0;cx.scr[0][0]=0;cx.lane[0][0]=1;ce_knob(0,1,0);
 assert(cs1_get(&trk[0],2,0)>0&&cs1_get(&trk[0],0,0)==0);
 shot(0,0,"osc");shot(0,1,"color");shot(1,0,"filter");shot(2,0,"vca");ce_close();
 puts("PASS: CS1 dual-row oscillator/color, channel I/II ADSR graphs, native filter screen");return 0;}
