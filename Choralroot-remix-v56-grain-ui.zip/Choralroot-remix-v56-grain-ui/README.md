# more chords! — V55 development

Start here: [V55 GRAIN Synth Source](README-V55.md). Emulator/test source build; hardware memory work and PI32V2 validation are pending. The stable web installer is not updated by this package.

Latest: [V37 CLUSTER Character, six oscillators](README-V37.md).

Latest: [V36 CLUSTER Light, output level restored](README-V36.md).

Latest: [V35 voice continuity and CLUSTER -6dB](README-V35.md).

Latest: [V34 original Orbit levels](README-V34.md).

Latest: [V33 CLOUD two grains](README-V33.md).

Latest: [V32 levels, lighter engines and SWARM/CLUSTER Bass](README-V32.md).

Latest: [V31 SWARM and CLUSTER UI](README-V31.md).

Latest: [V30 SWARM, CLUSTER and original chorus](README-V30.md).

Latest: [V29 KR106 light, 4+2](README-V29.md).

Latest: [V28 KR106 5+1 and startup fix](README-V28.md).

Latest: [V27 startup artwork](README-V27.md).

# Remix V26

See [README-V26.md](README-V26.md): KR106 shared controls and same-block parallel chorus on CPU1.

# Remix V25

See [README-V25.md](README-V25.md): stronger temporary nudge and shared chorus input filtering.

# Remix V24

See [README-V24.md](README-V24.md): lighter shared chorus and finer PLAY+OCT nudge.

# Remix V23

See [README-V23.md](README-V23.md): KR106 optimization, Cloud Morph, chorus UI and PLAY+OCT nudge.

# Remix V22

See [README-V22.md](README-V22.md) for KR106 optimization and the new shared Juno chorus.

## V21 — KR106 replacement and three parts

See [README-V21.md](README-V21.md) for the current version and validation.

## V20 — Cloud with three grains per voice

See [README-V20.md](README-V20.md) for the current version.

## V19 — Cloud UI

See [README-V19.md](README-V19.md) for the current version.

## V18 — Cloud

See [README-V18.md](README-V18.md) for the current engine and test limits.

## V17 — CS-1 removed

See [README-V17.md](README-V17.md) for the current version.

## V16 CS-1 Light

See [README-V16.md](README-V16.md) for the current version and test limits.

## V15 CS-1 optimization

See [README-V15.md](README-V15.md) for the current changes and device-test limits.

# Latest revision: V14

See [README-V14.md](README-V14.md): V11 base, CS-1 3+3, no CS-1 Bass, tests and timing limitations.

# Latest revision: V11

See [README-V11.md](README-V11.md) for soft physical velocity, checks and target-build limits.

# Latest revision: V10

See [README-V10.md](README-V10.md) for engine trims, the CS-1 editor and overlapping-chord fix, test results and known limitations.

> **Latest: [PI32V2 velocity conversion/link fix](README-BUILD-FIX.md).**

> **Latest: [engine level adjustment](README-LEVELS.md): CS-1 +12 dB total, KR106 +1.5 dB.**

> **Remix V9 / CS-1:** start with [README-V9-CS1.md](README-V9-CS1.md). This archive includes the complete V8 plus the native CS-1 integration.

> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](README-V8.md).

> Latest Remix update: [global Step grid, held preview, 20 loops, Simple, Prophet USER and Morph](README-REMIX-STEP.md). Test the emulator before building device firmware.

# ChoralRoot FM-1

Custom Stage25 keys-only / Ambient / Church / Gate source: see [controls and validation scope](docs/AMBIENT-CHURCH-GATE.md).

A Telepathic Orchid-style chord instrument as a firmware for the **M-VAVE FM-1**: one hand plays
roots, the other shapes chords; voicing, Key Mode, performance modes, bass, a looper — with the
FM-1's own sound engines, a colour screen, USB and TRS MIDI. Built on
[Felucca](https://github.com/hugelton/Felucca) (Leo Kuroshita, Hügelton Instruments) for the
platform and the engines, and on [choralroot](https://github.com/Quixotic7/choralroot) (the monome
grid version) for the musical engine. Independent of and unaffiliated with Telepathic Instruments
and M-VAVE.

See also [no chords, just keys](docs/KEYS-ONLY.md).

## Install

Try it in the browser first: <https://quixotic7.github.io/ChoralRootFM1/emu/> (the same firmware, with sound, no
FM-1 needed).

**From the browser:** open the web installer at <https://quixotic7.github.io/ChoralRootFM1/> in Chrome or
Edge, connect the FM-1 by USB and press Install. Nothing is installed on the computer: the page talks to the
FM-1 over Web MIDI. Do not unplug while it writes; an interrupted install is resumed by pressing Install again.
Afterwards the FM-1 restarts and reports the identity `FM-1_920`. Before installing, the page saves a backup of what
is stored on the FM-1 (settings, user sounds, loops, FM6 patches) to a file, and after installing over
Felucca it offers that backup back; its Back up and Restore buttons do the same at any time.

**Before any install:** charge the FM-1 fully (it updates on its battery), connect it straight to the computer with a
data cable (no hub), keep the computer awake, and leave the cable alone until the installer prints "done". An update
interrupted mid-write can leave the FM-1 dark with no USB device at all (docs/INSTALL-COMPAT.md, "Before an install").

**From the command line:** download `choralroot-X.Y.fwsc` from
[Releases](https://github.com/Quixotic7/ChoralRootFM1/releases) (`SHA256SUMS` next to it), then

```
pip3 install mido python-rtmidi
python3 tools/fm1_install.py choralroot-X.Y.fwsc --backup .   # back up to ./choralroot-backup-YYYYMMDD.json, install
python3 tools/fm1_install.py --info          # identity of the connected FM-1 (FM-1_920 after the install)
python3 tools/fm1_install.py --restore FILE  # a backup back onto the FM-1
python3 tools/fm1_install.py --sounds        # the 32 user sounds; --export-sound N FILE / --import-sound N FILE /
                                             # --rename-sound N NAME / --delete-sound N (docs/SOUNDS.md)
```

**Single sounds as files:** the installer page's Sounds section and the commands above export, import, rename and
delete one user sound at a time (its record and its VA / FM6 / CZ-1 patch) as a small JSON file, without a restart.

**Back to the stock firmware:** the installer's "Return to official V15" section installs the official FM-1
V15 firmware, `FM-1.fwsc`, which you download yourself from M-VAVE's
[downloads page](https://www.m-vave.com/download) (or `python3 tools/fm1_install.py FM-1.fwsc --backup .`). It
saves a backup first: the stock firmware cannot use ChoralRoot's user sounds, loops or settings; reinstall ChoralRoot
and press Restore to bring them back. Backups move between firmwares too: a Felucca backup restores its settings,
user sounds and FM6 patches on ChoralRoot (its samples stay in the file: ChoralRoot is all-synth), and back (BUILDING.md, "Backup and restore").

**Over which firmware:** the stock firmware, Felucca 1.0 or later, Melodee and ChoralRoot. The installers refuse
Sloop, the Felucca 0.x betas and firmwares they cannot identify: an FM-1 has been bricked by an install over Sloop,
and Felucca 0.9-beta to 1.0 bricked several (the loader wrote correctly both times; the cause is still open;
[docs/INSTALL-COMPAT.md](docs/INSTALL-COMPAT.md)). Return to the official V15 with that firmware's installer first.

**SAFE MODE.** If ChoralRoot crashes twice in a row within 30 s of starting (switching it off and on does not count),
it starts in SAFE MODE (a yellow screen, "Safe mode" on the top line): it plays its factory sounds and ignores what is
stored in the flash (settings, user sounds, FM6 bank, loops), which stays untouched. Options > Flash Data (OCT+ twice)
erases that data and restarts; switching off and on tries the stored data again. Installing and Backup still work in
SAFE MODE, so you can save a backup first. Only if SAFE MODE itself crashes twice does the unit go to update mode
(ROM boot).

**If the FM-1 no longer starts** (black screen, the computer shows a USB disk "WL82 UBOOT1.00"): leave it on for 2
minutes to see whether it restarts by itself, try holding OCT- and OCT+ while switching on (10 s), and check what the
computer sees (docs/INSTALL-COMPAT.md, "If an FM-1 is dark"); then
[MvaveFM1Unbricker](https://github.com/Quixotic7/MvaveFM1Unbricker). If it does not show up as that disk either, the
hardware route is [FM-1-transporter](https://github.com/kurogedelic/FM-1-transporter).

Installing firmware is at your own risk.

## Status

A first public beta (0.1). The instrument plays: the chord block, Key Mode, the performance modes,
the bass, the views; the sound editor, the looper, MIDI (USB and TRS) and the VA engine are in. The engines: ANALOG,
FM6 (Melodee's: DX7 voices rendered as Dexed renders them, DX7 SysEx import, [docs/FM6.md](docs/FM6.md)), VA, PHASE,
CZ-1 (Melodee's, [docs/CZ1.md](docs/CZ1.md)), LOFI, VOICE, TRIO, WHEEL, PHYS, NOISE. **USB audio recording** (Melodee's,
class compliant, no driver): the computer records the FM-1 through **ChoralRoot In**: the master, the CHORD part and
the BASS part as three stereo pairs; Options > USB Record switches it (Off: the serial console instead)
([docs/USB-AUDIO.md](docs/USB-AUDIO.md)). Open: the
Orchid parity passes (M8: the secret-chord map, chromatic Key Mode quantization, Key Mode sevenths and the
factory patterns, which ship as labelled fallbacks until they are captured from an Orchid).
[PLAN.md](PLAN.md) is the plan and the interface specification; [design/](design/) holds the screen and
panel mock-ups (made with the [ChoralRoot FM-1 designer](../ChoralRootFM1Designer/)).

## Layout

| Path | What |
| --- | --- |
| `PLAN.md` | the plan: controls, interaction grammar, screens, architecture, milestones |
| `design/` | the mock-ups (`make_mockups.py` generates the JSON; the PNG sheets are its renders) |
| `docs/INTEGRATION.md` | how the engine, the screens and Felucca's sound are wired together |
| `firmware/` | the firmware: Felucca's `hal/`, `src/` and `loader/`, plus ChoralRoot's `src/cr_*.c` |
| `tools/` | Felucca's build, generators, installer; `tools/emu/` the Mac emulator |
| `tools/emu/web/` | the emulator built for the browser (Emscripten) |
| `tests/` | host tests; `tests/cr_*` are ChoralRoot's |
| `web/` | the landing page (`web/site/`), the web installer and `make_site.py` (the GitHub Pages site) |
| `.github/workflows/` | `release.yml` builds the package on a tag, `pages.yml` publishes the site |
| `assets/`, `LICENSES/` | the UI font, icons, CC0 samples and their licences |

## Building

See [BUILDING.md](BUILDING.md). The host side (tests and the emulator) needs only Xcode's clang,
Python 3 with Pillow and fontTools, and SDL2; the device build needs Docker and the JieLi toolchain
(on Linux x86-64 the toolchain runs natively, without Docker).

## Licence

GPL-3.0-only ([LICENSE](LICENSE)). Built on Felucca by Leo Kuroshita (@kurogedelic), Hügelton Instruments, and its FM6
from [Melodee](https://github.com/keremimo/melodee) by Kerem Kilic (Ellic Studio);
the chord logic after the Telepathic Instruments Orchid. The firmware is all-synth (no samples in it: Felucca's
SAMPLE engine and its CC0 instruments by Versilian Studios stay in the tree for Felucca builds); the package carries three JieLi AC79 SDK files under Apache-2.0. The bundled font, icons,
ported DSP and SDK files keep their own licences ([LICENSES/](LICENSES/)); [LICENSING.md](LICENSING.md) has
the whole list. Orchid, M-VAVE and FM-1 are trademarks of their owners.
