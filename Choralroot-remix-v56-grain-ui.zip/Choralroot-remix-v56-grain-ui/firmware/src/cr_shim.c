/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the names main.c (kept unedited) calls of Felucca's dropped UI (ui.c, ui_input.c, ui_draw.c,
 * project.c, editor.c), with ChoralRoot's meaning (docs/INTEGRATION.md section 1). Device unit only (choralroot.c);
 * the emulator calls cr_ui_* itself (tools/emu/emu_fw.c).
 *
 *   felucca_init (main.c's power-on) -> track_defaults / set_engine_of / apply_preset_to: the parts get a sound
 *     (Felucca's TRK_DEF; ChoralRoot's own sounds replace them at the first frame); the step / pattern calls: none
 *   the main loop: ui_input -> cr_ui_input (the first call: cr_ui_init, the engine's power-on), ui_leds ->
 *     cr_ui_frame, ui_draw -> cr_ui_draw (the UPDATE MODE countdown of OCT- + OCT+ held: a big message)
 *   persist_boot: the flash part (the user sample sets with FELUCCA_SAMPLE only), the user sounds and the settings
 *     record; settings_save / settings_poll: cr_settings.c; panel_setup: main.c's own (cr_panel_setup); ed_service:
 *     cr_backup.c's (backup and restore over SysEx: Felucca's protocol, a subset; editor.c is dropped) */

/* ---------------------------------------------------------- ui.c's state --- */
/* (`ui`, ui_message and load_pat16: cr_bank.c / cr_ui.c, which upreset.c needs in the emulator too) */
static uint32_t undo_depth;            /* (main.c: no undo copy of the power-on loads; ChoralRoot keeps none) */
static uint32_t pat_sig[NTRK];
static uint8_t pat_last[NTRK];
static uint8_t cr_booted;


/* ---------------------------------------------------------- the power-on --- */
static void track_defaults(track_t *t)
{
    uint32_t i;
    for (i = 0; i < P_E0; i++)
        t->p[i] = TP[i].def;
}
static void track_defaults_steps(track_t *t) { (void)t; }
static void set_engine_of(track_t *t, uint32_t ei)
{
#if FELUCCA_PROPHET
    if(t==&trk[CR_PART_BASS] && ei%NENGINES==ENGI_PROPHET){cu_bass_engine_block(1,ENGI_PROPHET);return;}
#endif
    if(t==&trk[CR_PART_BASS] && (ei%NENGINES==ENGI_CLOUD)){cu_bass_engine_block(1,ei%NENGINES);return;}
    const engine_t *e = ENGINES[ei % NENGINES];
    uint32_t i;
    t->eng_req = (uint8_t)(eng_ok(ei % NENGINES) ? ei % NENGINES : ENGI_FM6);
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = e->edit[i].def;
}
static void apply_preset_to(track_t *t, uint32_t pi) { cu_load(t, t->eng_req, pi, t == &trk[CR_PART_BASS]); }
static uint32_t steps_sig(const track_t *t) { (void)t; return 0; }

static void persist_boot(void)         /* before settings_init / panel_init (project.c's, without the stores) */
{
#if FELUCCA_FLASH
    uint32_t f = irq_save(), k;
    CR_STAGE(BS_FLASH);
    flash_ok = FL_FAR(fl_jedec_ram)() == 0x856014u;       /* the expected 1 MiB part, else stay RAM-only */
    irq_restore(f);
    if (!flash_ok)
        return;
    fl_plain_window_init();                                /* the data region reads as plaintext through XIP */
    /* SAFE MODE (main.c, cr_bootguard.h): flash_ok stays (the installer's update and the backup's reads need it),
     * but no object is read: storage.c st_load / st_save and the loop slots answer "none" (core.h ST_BLOCKED), so
     * the sounds, the stores, the FM6 bank and the settings start as on an erased flash; the flash is not touched */
#if FELUCCA_SAMPLE
    for (k = 0; !cr_safe && k < SMP_USER_SLOTS; k++)       /* (user sample sets play from flash through XIP) */
        smp_user_scan(k);
#else
    (void)k;                                               /* (no SAMPLE engine: no user sample sets to scan) */
#endif
    cr_bank_boot();                                        /* the 32 user sounds (upreset.c) and the FM6 bank */
#if CR_HAVE_SETTINGS
    CR_STAGE(BS_SETTINGS);
    cr_settings_boot();                                    /* the settings record with ChoralRoot's block */
#endif
#endif
}
#if CR_HAVE_SETTINGS
static void settings_poll(void)                    /* saved on change, deferred while a loop plays (SAFE MODE: never) */
{
    if (!cr_safe)
        cr_settings_poll();
}
static void settings_save(void)
{
    if (!cr_safe)
        cr_settings_save();
}
#else
static void settings_poll(void) {}
static void settings_save(void) {}
#endif
#ifndef CR_BACKUP_SERVICE
static void ed_service(void) {}        /* (no SysEx service: cr_backup.c's is the device's, FELUCCA_OTA) */
#endif

/* ------------------------------------------------------- the power-on splash --- */
/* Supplied startup artwork, using the same strip renderer as the UI.
 * Safe-mode diagnostics retain priority; the normal idle screen follows after boot. */
#define CR_SPLASH_PLAY_MS 480u
static void cr_splash(void)
{
    static cr_screen_t s;                          /* (static: ~1 KB off the boot stack) */
    uint32_t t, mo = CR_MOTION_FULL;
#if CR_HAVE_SETTINGS
    if (crs_booted && crs_rec.cr.motion < CR_MOTION_N)
        mo = crs_rec.cr.motion;
#endif
    palette_set(NPALETTES - 1u);                   /* MOD (cr_ui_init sets it again, then the saved one) */
    if (cr_safe) {                                 /* SAFE MODE: its screen (cr_ui.c cu_safe_screen), no slide */
        cr_screen_clear(&s);
        cu_safe_screen(&s);
        cr_draw_invalidate();
        cr_draw(&s, CR_ANIM_SETTLED);
        cr_draw_invalidate();
        return;
    }
    cr_screen_clear(&s);
    s.kind = CR_K_BOOT;
    cr_draw_invalidate();
    cr_draw(&s, CR_ANIM_SETTLED);
    lcd_sync();
    for (t = 0; mo != CR_MOTION_OFF && t < CR_SPLASH_PLAY_MS; t += 16u) {
        fm1_wdt_feed();
        fm1_delay_ms(16);
    }
    cu_intro_played = 1;
    cr_draw_invalidate();                          /* the UI's first frame draws everything */
}

/* ------------------------------------------------------------ the frame --- */
static void ui_input(void)
{
    if (!cr_booted) {                  /* the first scan: ChoralRoot's power-on (the engine, its sounds) */
        cr_ui_init();
        cr_booted = 1;
    }
    cr_ui_input();
#if FELUCCA_GRAIN
    grain_poll();
#endif
}
static void ui_leds(void)
{
    if (cr_booted)
        cr_ui_frame();
}
static void ui_draw(void)
{
    if (!cr_booted)
        return;
    if (ui.force) {
        ui.force = 0;
        cr_draw_invalidate();
    }
    if (ui.uboot) {                    /* OCT- + OCT+ held 2..5 s (main.c): the update countdown */
        char n[2] = {(char)('0' + ui.uboot % 10u), 0};
        cu.msg.until = cu_now() + 100u;
        cu.msg.big = 1;
        cu_cpy(cu.msg.text, n, sizeof cu.msg.text);
        cu_cpy(cu.msg.label, "update mode: let go to cancel", sizeof cu.msg.label);
    }
    cr_ui_draw();
}
