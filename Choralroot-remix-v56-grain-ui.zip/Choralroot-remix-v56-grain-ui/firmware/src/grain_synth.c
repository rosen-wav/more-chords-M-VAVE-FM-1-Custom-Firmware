/* SPDX-License-Identifier: GPL-3.0-only
 * more chords! isolated main-loop renderer. Context index NPART is never a music part.
 * Reuses the actual Prophet/FM6 renderer, with separate patch, voices, LFO and scratch.
 */
static struct {uint32_t pos;int32_t fir[7];uint8_t fp;gs_source_t source;} gsynth __attribute__((section(".pool")));
static uint32_t gs_hash(const uint8_t *p,uint32_t n){uint32_t h=2166136261u;while(n--)h=(h^*p++)*16777619u;return h;}
static uint32_t gs_source_hash(unsigned engine,unsigned patch){
 if(engine==ENGI_FM6&&patch<FM6_NFACTORY)return gs_hash(FM6_FACTORY[patch],128);
 if(engine==ENGI_PROPHET&&patch<NELEM(P5_TEST_PRESETS)){const p5_patch_t *p=patch?&P5_FACTORY[patch-1]:0;p5_patch_t init;if(!p){p5_patch_init(&init);p=&init;}return gs_hash(p->raw,sizeof p->raw);}
 return 0;
}
static unsigned gs_source_count(unsigned engine){return engine==ENGI_FM6?FM6_NFACTORY:engine==ENGI_PROPHET?NELEM(P5_TEST_PRESETS):0;}
static int gsynth_begin(const gs_source_t *q){
 unsigned e=q->engine&127u;if(!q->hash||q->hash!=gs_source_hash(e,q->patch))return 0;
 memset(&gsynth,0,sizeof gsynth);gsynth.source=*q;
 track_t *t=&trk[NPART];memset(t,0,sizeof *t);memset(&eng_state[NPART],0,sizeof eng_state[NPART]);
 t->engine=t->eng_req=(uint8_t)e;t->p[P_VOICE]=V_POLY;t->p[P_ATK]=0;t->p[P_SUS]=127;
 for(unsigned i=0;i<8;i++)t->p[P_E0+i]=0;
 voice_t *v=&t->v[0];v->note=60;v->pitch16=v->pitch_cur=960;v->vel=v->mvel=q->vel?q->vel:100;v->gate=v->active=1;v->age=q->seed+1u;v->env=1<<24;
 if(e==ENGI_FM6){uint8_t pk[128];fm6_factory(q->patch,pk);fm6_unpack(pk,fm6_patch[NPART]);memcpy(fm6_fn[NPART],FM6_FNDEF,FM6_NFN);fm6_on[NPART]=63;fm6_pgen[NPART]++;fm6_eff[NPART].ok=0;fm6_note_on(t,v);}
 else {p5_ready[NPART]=0;p5_preset_loaded(t,q->patch);p5_note_on(t,v);}
 return 1;
}
static unsigned gsynth_step(int16_t *dst,unsigned maximum){
 track_t *t=&trk[NPART];voice_t *v=&t->v[0];unsigned made=0;
 while(maximum-made>=CTL/2u && gsynth.pos<GS_N*2u){
  int32_t pcm[CTL]={0};vmod_t m={0};m.inc=pitch_inc(960);m.pitch16=960;m.shape=16384;m.amp0=m.amp1=32767;
  if(gsynth.pos>=GS_N*3u/2u)v->gate=0;
  if(t->engine==ENGI_FM6){fm6_block(t);fm6_render(t,v,pcm,CTL,&m);fm6_post(t,pcm,CTL,1);}else{p5_block(t);p5_render(t,v,pcm,CTL,&m);}
  for(unsigned i=0;i<CTL;i++){
   gsynth.fir[gsynth.fp]=pcm[i];gsynth.fp=(uint8_t)((gsynth.fp+1u)%7u);
   if(gsynth.pos&1u){
    /* Seven-tap half-band decimator; fixed point, no shared signal path. */
    int32_t y=0;static const int8_t tap[7]={-1,0,9,16,9,0,-1};
    for(unsigned k=0;k<7;k++)y+=gsynth.fir[(gsynth.fp+k)%7u]*tap[k];
    /* FIR /32, then 1/8 headroom: even FM6's 16-sine bound fits PCM16.
     * The subsequent measured gain restores up to 18 dB without pre-normalization clipping. */
    dst[made++]=(int16_t)clamp(y/256,-32767,32767);
   }gsynth.pos++;
  }
 }
 if(gsynth.pos>=GS_N*2u)v->active=v->gate=0;
 return made;
}
