/* SPDX-License-Identifier: GPL-3.0-only */
/* U33..U64: sixteen240-byte sound records per logical bank. Two banks use
 * the three-sector shared-spare journal at F9000..FBFFF. Old32 banks untouched.
 * Common controls use their exact descriptor bit widths (layout1,91 params).
 * Full native VA/FM6/CZ/QUAD patch, Prophet tail and signed16 macros are kept. */
#define UPX_REC 240u
#define UPX_BANK (16u*UPX_REC)
_Static_assert(P_COUNT==91 && P_E0==83,"UPX layout1 schema: version before changing parameter order/ranges");
_Static_assert(UPX_BANK<=ST_PAYLOAD_MAX,"extended bank payload");
static uint8_t upx_aux[32][144] __attribute__((section(".pool")));
static uint8_t upx_len[32];
static uint8_t upx_raw[UPX_BANK] __attribute__((section(".pool")));
static unsigned upx_width(unsigned i){unsigned v=(unsigned)(TP[i].max-TP[i].min),n=0;while(v){v>>=1;n++;}return n;}
static uint32_t upx_bits(uint8_t *p,uint32_t at,uint32_t value,unsigned n,int put){
 uint32_t out=0;for(unsigned j=0;j<n;j++){
  uint8_t mask=(uint8_t)(1u<<((at+j)%8u));uint8_t *b=p+(at+j)/8u;
  if(put){if(value&(1u<<j))*b|=mask;else *b&=(uint8_t)~mask;}
  else if(*b&mask)out|=1u<<j;
 }return out;
}
static unsigned upx_native_len(unsigned e){return e==ENGI_VA?VA_BLOB:e==ENGI_FM6?FM6_BLOB:e==ENGI_CZ?CZ_BYTES:e==ENGI_QUAD?QUAD_BLOB:0;}
static int upx_encode(uint8_t *p,const up_rec_t *r,const uint8_t *aux,unsigned len){
 memset(p,0,UPX_REC);if(!r->used)return 0;
 if(!up_valid(r)||r->ver!=4)return 1;
 for(unsigned j=0;j<15;j++)if(r->note[j]||r->flags[j])return 1;
 memcpy(p,r,16);p[1]=1;p[3]=P_COUNT;p[16]=r->note[15];p[17]=r->flags[15];
 int16_t values[P_COUNT],def[P_COUNT];for(unsigned i=0;i<P_COUNT;i++)def[i]=param_desc_of(r->engine,i)->def;
 up_params(r,values,def);unsigned bit=18*8;
 for(unsigned i=0;i<P_E0;i++){unsigned n=upx_width(i);int32_t v=values[i];if(v<TP[i].min||v>TP[i].max)return 1;upx_bits(p,bit,(uint32_t)(v-TP[i].min),n,1);bit+=n;}
 unsigned at=(bit+7)/8;if(at+16+1+144>UPX_REC)return 1;
 for(unsigned i=0;i<8;i++){uint16_t v=(uint16_t)values[P_E0+i];p[at++]=(uint8_t)v;p[at++]=(uint8_t)(v>>8);}
 if(up_p5_has(r)){len=53;aux=r->packed+91;}
 if(len>144||(!up_p5_has(r)&&len&&len!=upx_native_len(r->engine)))return 1;
 p[at++]=(uint8_t)len;if(len)memcpy(p+at,aux,len);return 0;
}
static int upx_native_ok(unsigned e,const uint8_t *b,unsigned n){
 if(!n)return 1;
 return e==ENGI_VA?va_blob_ok(b):e==ENGI_FM6?fm6_blob_ok(b):e==ENGI_CZ?cz_patch_valid(b):e==ENGI_QUAD?quad_blob_ok(b):0;
}
static int upx_decode(const uint8_t *p,up_rec_t *r,uint8_t *aux,uint8_t *len){
 memset(r,0,sizeof *r);*len=0;if(!p[0])return 0;
 if(p[0]!=UP_USED||p[1]!=1||p[2]>=NENGINES||p[3]!=P_COUNT)return 1;
 memcpy(r,p,16);r->ver=4;r->note[15]=p[16];r->flags[15]=p[17];unsigned bit=18*8;
 for(unsigned i=0;i<P_E0;i++){unsigned n=upx_width(i);uint32_t x=upx_bits((uint8_t *)p,bit,0,n,0);bit+=n;if(x>(unsigned)(TP[i].max-TP[i].min))return 1;up_set_value(r,i,(int16_t)(TP[i].min+(int32_t)x));}
 unsigned at=(bit+7)/8;
 for(unsigned i=0;i<8;i++){uint16_t x=p[at]|((uint16_t)p[at+1]<<8);at+=2;up_set_value(r,P_E0+i,(int16_t)x);}
 unsigned n=p[at++];if(n>144||at+n>UPX_REC)return 1;
 if(r->engine==ENGI_PROPHET&&n==53){memcpy(r->packed+91,p+at,53);}
 else {if((n&&n!=upx_native_len(r->engine))||!upx_native_ok(r->engine,p+at,n))return 1;if(n)memcpy(aux,p+at,n);*len=(uint8_t)n;}
 return !up_valid(r);
}
static int upx_valid_bank(const uint8_t *raw){up_rec_t r;uint8_t aux[144],n;for(unsigned j=0;j<16;j++)if(upx_decode(raw+j*UPX_REC,&r,aux,&n))return 0;return 1;}
static int upx_commit(unsigned bank){
 for(unsigned j=0;j<16;j++){unsigned x=bank*16+j;if(upx_encode(upx_raw+j*UPX_REC,up_rec(32+x),upx_aux[x],upx_len[x]))return 2;}
#if FELUCCA_FLASH
 if(flash_ok&&st_save(OBJ_UPEXT0+bank,upx_raw,sizeof upx_raw))return 2;
 if(flash_ok)return 0;
#endif
 return 3;
}
static void upx_boot(void){
 for(unsigned bank=0;bank<2;bank++){
  memset(&up_bank[2+bank],0,sizeof up_bank[0]);
#if FELUCCA_FLASH
  int n=flash_ok?st_load(OBJ_UPEXT0+bank,upx_raw,sizeof upx_raw):-1;
#else
  int n=-1;
#endif
  for(unsigned j=0;j<16;j++){unsigned x=bank*16+j;upx_len[x]=0;memset(upx_aux[x],0,144);if(n==(int)sizeof upx_raw&&upx_decode(upx_raw+j*UPX_REC,up_rec(32+x),upx_aux[x],&upx_len[x]))memset(up_rec(32+x),0,sizeof(up_rec_t));}
 }
}
static int upx_blob_get(uint32_t k,uint32_t engine,uint8_t *b){
 if(k<32||k>=64||!up_used(k)||up_rec(k)->engine!=engine||upx_len[k-32]!=upx_native_len(engine))return 1;
 memcpy(b,upx_aux[k-32],upx_len[k-32]);return 0;
}
static int upx_blob_put(uint32_t k,uint32_t engine,const uint8_t *b){
 if(k<32||k>=64||(!up_used(k)&&b)||(b&&up_rec(k)->engine!=engine))return 1;
 unsigned x=k-32,n=upx_native_len(engine);if(!n||(b&&!upx_native_ok(engine,b,n)))return 1;
 uint8_t old[144],len=upx_len[x];memcpy(old,upx_aux[x],144);
 upx_len[x]=b?(uint8_t)n:0;if(b)memcpy(upx_aux[x],b,n);
 int rc=upx_commit(x/16);if(rc==2){upx_len[x]=len;memcpy(upx_aux[x],old,144);}return rc;
}
static int upx_put(uint32_t k,const up_rec_t *r){
 unsigned x=k-32;up_rec_t old=*up_rec(k);uint8_t oldaux[144],oldlen=upx_len[x];memcpy(oldaux,upx_aux[x],144);
 if(r)*up_rec(k)=*r;else memset(up_rec(k),0,sizeof(up_rec_t));
 if(!r||old.engine!=r->engine)upx_len[x]=0;
 if(r&&upx_source){
  const track_t *t=upx_source;unsigned n=upx_native_len(r->engine);upx_len[x]=(uint8_t)n;
  if(r->engine==ENGI_VA)va_blob_get(t,upx_aux[x]);
  else if(r->engine==ENGI_FM6)fm6_blob_get(t,upx_aux[x]);
  else if(r->engine==ENGI_CZ)memcpy(upx_aux[x],cz_patch[t-trk].raw,CZ_BYTES);
  else if(r->engine==ENGI_QUAD)quad_blob_get(t,upx_aux[x]);
 }
 int rc=upx_commit(x/16);
 if(rc==2){*up_rec(k)=old;upx_len[x]=oldlen;memcpy(upx_aux[x],oldaux,144);return rc;}
 if(!r){favorite_set(ENG_USER_REF,k,0);for(unsigned i=0;i<NTRK;i++)if(trk[i].user==k+1)trk[i].user=0;}
 up_gen++;return rc;
}
