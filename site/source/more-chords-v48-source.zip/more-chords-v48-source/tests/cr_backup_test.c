/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* Host test of the backup / restore SysEx handler (firmware/src/cr_backup.c, web/EDITOR_PROTOCOL.md "ChoralRoot:
 * backup and restore"): the firmware as the emulator builds it (tools/emu/emu_firmware.h: tests/hostsim.c's sound
 * side, the ChoralRoot UI, storage.c on emu_hal_fw.h's RAM NOR), requests fed to crb_handle as the main loop would,
 * the replies taken at CRB_SEND.
 *   sh tests/run_cr_tests.sh
 * Checks: INFO; LIST of every object (settings, banks, FM6 bank, VA, FM6 patches, CZ-1 tones and banks, the QUAD
 * store (22), 10 loops; no sample slots) with sizes
 * and CRCs; GET of
 * all of them in 256-byte pieces; a restore of everything onto an erased flash (PUT) gives a LIST and bytes
 * identical to the backup and reloads the mirrors; a CRC error, a short object, a malformed record are refused
 * with nothing written; a playing loop answers busy (3) and the commit goes through once it stops; stale sessions
 * (the UI's buffer, a USB reset, 15 s); Felucca's objects: a PER4 settings record becomes PER5 with ChoralRoot's
 * defaults, the banks and the FM6 bank as they are (Felucca 1.0's 27-slot FM6 bank too, imported at the next boot),
 * ids 0 / 2..5 / 32..34 refused, the SMP_* commands unanswered; the Sounds (docs/SOUNDS.md): single slots imported,
 * renamed, deleted and replaced by another engine through whole-object PUTs, usable at once (name, engine, patch), a
 * bad blob / bank header refused with nothing written, LIST's sizes and CRCs; RESTART. */
#include <os/lock.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../tools/emu/emu_hooks.h"

emu_hal_t emu_hal;
const int8_t emu_keymap[6][EMU_NCOL] = {
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
    { 5, 11,  4, 10,  3,  9,  2,  8, -1, -1, -1},
    {34, 35, 36, 37, 38, 40, 39, 13,  7,  6, 12},
    {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33},
    { 0,  1, 15, 14, 17, 16, 19, 18, 20, 21, 22},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
};

/* the replies */
static uint8_t rx[4096];
static uint32_t rx_n, rx_count;
#define CRB_SEND(p, n) (memcpy(rx, (p), (n)), rx_n = (n), rx_count++)
#include "../tools/emu/emu_firmware.h"

static int fails, checks;
#define CHECK(c, ...)                                                   \
    do {                                                                \
        checks++;                                                       \
        if (!(c)) {                                                     \
            fails++;                                                    \
            printf("  FAIL %s:%d: ", __FILE__, __LINE__);               \
            printf(__VA_ARGS__);                                        \
            printf("\n");                                               \
        }                                                               \
    } while (0)

/* ------------------------------------------------------------------- the wire --- */
static uint8_t tx[1024];
static uint32_t txn;
static void t_begin(uint32_t cmd) { tx[0] = 0x7D; tx[1] = 0x46; tx[2] = 0x4C; tx[3] = (uint8_t)cmd; txn = 4; }
static void t_b(uint32_t v) { tx[txn++] = (uint8_t)(v & 127u); }
static void t_u32(uint32_t v) { for (int i = 0; i < 5; i++) t_b(v >> (7 * i)); }
static void t_pack(const uint8_t *p, uint32_t n)
{
    while (n) {
        uint32_t k = n > 7u ? 7u : n, m = 0, i;
        for (i = 0; i < k; i++) m |= (uint32_t)(p[i] >> 7) << i;
        t_b(m);
        for (i = 0; i < k; i++) t_b(p[i]);
        p += k; n -= k;
    }
}
/* send; -> the reply's payload (after F0 7D 46 4C cmd), its length in *n; 0: no reply */
static const uint8_t *t_send(uint32_t *n)
{
    uint32_t before = rx_count;
    crb_handle(tx, txn);
    if (rx_count == before) { *n = 0; return 0; }
    if (rx_n < 6 || rx[0] != 0xF0 || rx[1] != 0x7D || rx[2] != 0x46 || rx[3] != 0x4C || rx[4] != tx[3] || rx[rx_n - 1] != 0xF7) {
        printf("  bad reply frame\n");
        *n = 0;
        return 0;
    }
    for (uint32_t i = 1; i + 1 < rx_n; i++)
        if (rx[i] > 127u) { printf("  8-bit byte in a reply\n"); fails++; }
    *n = rx_n - 6;
    return rx + 5;
}
static uint32_t r32(const uint8_t *p) { return p[0] | p[1] << 7 | p[2] << 14 | (uint32_t)p[3] << 21 | (uint32_t)p[4] << 28; }
static uint32_t unpack(const uint8_t *a, uint32_t na, uint8_t *out)
{
    uint32_t n = 0;
    while (na) {
        uint32_t m = *a++, k;
        na--;
        k = na > 7 ? 7 : na;
        for (uint32_t j = 0; j < k; j++, na--) out[n++] = (uint8_t)(*a++ | ((m >> j) & 1u) << 7);
    }
    return n;
}

/* ------------------------------------------------------------------ the objects --- */
typedef struct { uint8_t id; uint32_t size, crc; uint8_t *bytes; } obj_t;
static obj_t man[64];
static uint32_t nman;

static int t_list(void)                              /* -> rc; man[] filled */
{
    uint32_t n, i;
    const uint8_t *a;
    t_begin(65);
    a = t_send(&n);
    if (!a || n < 3 || a[0] != 1) return -1;
    if (a[1]) return a[1];
    nman = a[2];
    if (n != 3 + nman * 11) return -2;
    for (i = 0; i < nman; i++) {
        const uint8_t *p = a + 3 + i * 11;
        free(man[i].bytes);
        man[i].id = p[0];
        man[i].size = r32(p + 1);
        man[i].crc = r32(p + 6);
        man[i].bytes = 0;
    }
    return 0;
}
static int t_get(uint32_t id, uint32_t off, uint32_t count, uint8_t *out)   /* -> rc */
{
    uint32_t n;
    const uint8_t *a;
    t_begin(66); t_b(id); t_u32(off); t_b(count & 127); t_b(count >> 7);
    a = t_send(&n);
    if (!a || n < 9 || a[0] != id || r32(a + 2) != off) return -1;
    if (a[1]) return a[1];
    if ((a[7] | a[8] << 7) != (int)count || unpack(a + 9, n - 9, out) != count) return -2;
    return 0;
}
static int t_capture(void)                           /* LIST, then every object read and checked against its CRC */
{
    uint32_t i, off;
    if (t_list()) return -1;
    for (i = 0; i < nman; i++) {
        man[i].bytes = malloc(man[i].size + 1);
        for (off = 0; off < man[i].size; off += 256) {
            uint32_t k = man[i].size - off < 256 ? man[i].size - off : 256;
            if (t_get(man[i].id, off, k, man[i].bytes + off)) return -2;
        }
        if (st_crc32(man[i].bytes, man[i].size) != man[i].crc) return -3;
    }
    return 0;
}
static obj_t *find(obj_t *m, uint32_t n, uint32_t id)
{
    for (uint32_t i = 0; i < n; i++) if (m[i].id == id) return &m[i];
    return 0;
}

static int t_put_op(uint32_t op, uint32_t id)       /* -> rc of commit (2) / abort (3) */
{
    uint32_t n;
    const uint8_t *a;
    t_begin(67); t_b(op); t_b(id);
    a = t_send(&n);
    return a && n == 3 && a[0] == op && a[1] == id ? a[2] : -1;
}
static int t_put_begin(uint32_t id, uint32_t size, uint32_t crc)
{
    uint32_t n;
    const uint8_t *a;
    t_begin(67); t_b(0); t_b(id); t_u32(size); t_u32(crc);
    a = t_send(&n);
    return a && n == 3 && a[0] == 0 && a[1] == id ? a[2] : -1;
}
static int t_put_data(uint32_t id, uint32_t off, const uint8_t *p, uint32_t k)
{
    uint32_t n;
    const uint8_t *a;
    t_begin(67); t_b(1); t_b(id); t_u32(off); t_pack(p, k);
    a = t_send(&n);
    return a && n == 3 && a[0] == 1 && a[1] == id ? a[2] : -1;
}
static int t_put(uint32_t id, const uint8_t *p, uint32_t size)   /* begin, data, commit: the first nonzero rc */
{
    int rc = t_put_begin(id, size, st_crc32(p, size));
    for (uint32_t off = 0; !rc && off < size; off += 256)
        rc = t_put_data(id, off, p + off, size - off < 256 ? size - off : 256);
    return rc ? rc : t_put_op(2, id);
}
static int t_smp(uint32_t cmd, uint32_t slot)        /* SMP_BEGIN / SMP_ERASE: answered? (-1: no reply) */
{
    uint32_t n;
    const uint8_t *a;
    t_begin(cmd); t_b(slot);
    a = t_send(&n);
    return a ? (int)n : -1;
}

/* ------------------------------------------------------------------ the content --- */
static void power_on(void)                           /* persist_boot + the UI, on the flash as it is */
{
    st_ext_ready=0;
    up_boot();
    cr_settings_boot();
    cu_loop_scan();
}
static uint32_t make_loop(uint32_t k, uint32_t nev)   /* slot k: nev events; -> the record's length */
{
    static crl_data_t d;
    uint32_t i, n;
    memset(&d, 0, sizeof d);
    d.len = 4u * CRL_PPQN * 2u;
    d.nlayers = 1;
    d.nev = (uint16_t)nev;
    for (i = 0; i < nev; i++) {
        d.ev[i].t = (uint16_t)(i * 24u % d.len);
        d.ev[i].dur = 12;
        d.ev[i].root = (uint8_t)(48 + (i + k) % 24u);
        d.ev[i].vel = 100;
        d.ev[i].qx = 0;
    }
    n = cr_loop_pack(&d, cu_loop_buf, sizeof cu_loop_buf);
    crl_fl_save(k, cu_loop_buf, n);
    return n;
}

#ifndef CR_BACKUP_TEST_HELPERS_ONLY
int main(void)
{
    uint32_t n, i, k;
    const uint8_t *a;
    static obj_t ref[64];
    uint32_t nref;

    emu_flash_open();                                /* (no file: RAM only, erased) */
    memset(emu_flash, 0xFF, sizeof emu_flash);
    cr_bank_boot();
    cr_settings_boot();
    cr_ui_init();
    usb.config = 1;

    /* ---- INFO ---- */
    t_begin(1);
    a = t_send(&n);
    CHECK(a && n > 12 && !memcmp(a, "EMU", 4) && a[n - 6] == 0x42 && a[n - 4] == 3 && a[n - 3] == 0x43 && a[n - 1] == 2,
          "INFO: version, no engines, tags 42 01 03 and 43 01 02");
    t_begin(2); t_b(0); t_b(0);
    CHECK(!t_send(&n), "an editor command (GET 2) gets no reply");

    /* ---- an empty device: every object listed, sizes 0 but the settings ---- */
    CHECK(t_list() == 0 && nman == 50, "LIST on a fresh flash: 48 objects");
    for (i = 0, k = 0; i < nman; i++) k += man[i].size != 0;
    CHECK(k <= 1, "fresh flash: nothing stored (the settings at most)");

    /* ---- content: settings, both banks, FM6, VA, three loops ---- */
    cs.bpm = 133;
    cs.tonic = 5; /* deliberately obsolete: saving must discard this field */
    cs.vel = 77;
    cr_settings_save();
    {
        static up_bank_t b;
        static fm6_bank_t f;
        static va_store_t v;
        static fm6u_t fu[2];
        uint8_t blob[VA_BLOB], fb[FM6_BLOB], rec[FM6_PACKED];
        for (k = 0; k < 2; k++) {
            memset(&b, 0, sizeof b);
            b.magic = UP_BANK_MAGIC;
            b.rsize = sizeof(up_rec_t);
            b.nslot = UP_PER_BANK;
            b.r[3 + k].used = UP_USED;
            b.r[3 + k].ver = UP_VER;
            b.r[3 + k].engine = ENGI_VA;
            b.r[3 + k].np = P_COUNT;
            memcpy(b.r[3 + k].name, k ? "PAD TWO" : "PAD ONE", 7);
            for (i = 0; i < P_COUNT; i++) b.r[3 + k].packed[i] = (uint8_t)(64 + (int)(i % 9));
            CHECK(st_save(OBJ_UPRESET0 + k, &b, sizeof b) == 0, "setup: bank %u", (unsigned)k);
        }
        memset(&f, 0, sizeof f);
        f.magic = FM6_BANK_MAGIC; f.ver = FM6_BANK_VER; f.nslot = FM6_BANK_N; f.used = 5;
        memcpy(f.fn, FM6_FNDEF, FM6_NFN);
        for (i = 0; i < FM6_PACKED; i++) rec[i] = (uint8_t)(i & 127u);
        fm6_pack7(f.pk[0], rec, FM6_PACKED);
        for (i = 0; i < FM6_PACKED; i++) rec[i] = (uint8_t)((i * 3u) & 127u);
        fm6_pack7(f.pk[2], rec, FM6_PACKED);
        CHECK(fm6_bank_valid(&f) && st_save(OBJ_FM6BANK, &f, sizeof f) == 0, "setup: FM6 bank");
        trk[1].eng_req = ENGI_FM6;
        fm6_load_slot(1, 14);                        /* (F15: STRINGS) */
        fm6_blob_get(&trk[1], fb);
        CHECK(fm6_blob_ok(fb), "setup: an FM6 blob");
        for (k = 0; k < 2; k++) {
            memset(&fu[k], 0, sizeof fu[k]);
            fu[k].magic = FM6U_MAGIC; fu[k].ver = FM6U_VER; fu[k].nslot = FM6U_HALF; fu[k].first = (uint16_t)(k * FM6U_HALF);
            fu[k].blob = FM6_BLOB; fu[k].used = 1u << 3;
            memcpy(fu[k].b[3], fb, FM6_BLOB);
            CHECK(fm6u_valid(&fu[k], k) && st_save(OBJ_FM6STORE0 + k, &fu[k], sizeof fu[k]) == 0, "setup: FM6 store %u", (unsigned)k);
        }
        memset(&v, 0, sizeof v);
        v.magic = VA_STORE_MAGIC; v.ver = 3; v.nslot = UP_LEGACY_SLOTS; v.blob = VA_BLOB;
        trk[0].eng_req = ENGI_VA;
        va_blob_get(&trk[0], blob);
        CHECK(va_blob_ok(blob), "setup: a VA blob");
        memcpy(v.p[3], blob, VA_BLOB);
        memcpy(v.p[19], blob, VA_BLOB);
        v.used = 1u << 3 | 1u << 19;
        CHECK(va_store_valid(&v) && st_save(OBJ_VASTORE, &v, sizeof v) == 0, "setup: VA store");
        {                                            /* CZ-1: U04 / U20 hold D-1 PIANO 1, bank C saved with its name */
            static czu_t cu2[2];
            static cz_bank_t cb;
            for (k = 0; k < 2; k++) {
                memset(&cu2[k], 0, sizeof cu2[k]);
                cu2[k].magic = CZU_MAGIC; cu2[k].ver = CZU_VER; cu2[k].nslot = CZU_HALF; cu2[k].first = (uint16_t)(k * CZU_HALF);
                cu2[k].blob = CZ_BYTES; cu2[k].used = 1u << 3;
                memcpy(cu2[k].b[3], CZ_FACTORY[24], CZ_BYTES);
                CHECK(czu_valid(&cu2[k], k) && st_save(czu_obj(k), &cu2[k], sizeof cu2[k]) == 0, "setup: CZ-1 store %u", (unsigned)k);
            }
            cz_bank_default(&cb, 2);
            memcpy(cb.name, "MY CZ BANK", 10);
            CHECK(cz_bank_valid(&cb) && st_save(OBJ_CZBANK0 + 2, &cb, sizeof cb) == 0, "setup: CZ-1 bank C");
        }
        {                                            /* QUAD: U06 holds the BELL preset's patch */
            static quad_store_t qs;
            uint8_t qb[QUAD_BLOB];
            trk[0].eng_req = ENGI_QUAD;
            quad_blob_preset(&trk[0], 1);
            quad_blob_get(&trk[0], qb);
            memset(&qs, 0, sizeof qs);
            qs.magic = QUAD_STORE_MAGIC; qs.ver = QUAD_STORE_VER; qs.nslot = UP_LEGACY_SLOTS; qs.blob = QUAD_BLOB; qs.used = 1u << 5;
            memcpy(qs.p[5], qb, QUAD_BLOB);
            CHECK(quad_blob_ok(qb) && quad_store_valid(&qs) && st_save(OBJ_QUADSTORE, &qs, sizeof qs) == 0, "setup: QUAD store");
        }
    }
    make_loop(0, 4);
    make_loop(4, 300);
    make_loop(9, CRL_MAX_EV);
    power_on();
    CHECK(cs.loop_used == (1u | 1u << 4 | 1u << 9), "setup: loops in slots 1, 5, 10");

    /* ---- backup: LIST, GET everything, CRCs ---- */
    CHECK(t_capture() == 0, "backup: LIST + GET of every object, each CRC as listed");
    {
        static const uint8_t ids[50] = {1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
                                        40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71};
        int same = nman == 50;
        for (i = 0; same && i < 50; i++) same = man[i].id == ids[i];
        CHECK(same, "LIST: ids 1 6..22 (12 13 the CZ-1 tones, 14..21 its banks, 22 QUAD's patches) 40..59 in order (no sample slots)");
    }
    CHECK(find(man, nman, 1)->size == sizeof(persist_t) && find(man, nman, 6)->size == sizeof(up_bank_t) &&
          find(man, nman, 8)->size == sizeof(fm6_bank_t) && find(man, nman, 9)->size == sizeof(va_store_t) &&
          find(man, nman, 10)->size == sizeof(fm6u_t) && find(man, nman, 11)->size == sizeof(fm6u_t) &&
          find(man, nman, 12)->size == sizeof(czu_t) && find(man, nman, 13)->size == sizeof(czu_t) &&
          find(man, nman, 16)->size == sizeof(cz_bank_t) && find(man, nman, 14)->size == 0 &&
          find(man, nman, 22)->size == sizeof(quad_store_t) && sizeof(quad_store_t) == 2576u &&
          find(man, nman, 40)->size > 16 && find(man, nman, 41)->size == 0 && find(man, nman, 49)->size == CRL_REC_HDR + 2u + 7u * CRL_MAX_EV,
          "LIST: the sizes (settings PER5, banks, FM6, VA, FM6 patches, loops; empty slots 0)");
    {
        const persist_t *p = (const persist_t *)find(man, nman, 1)->bytes;
        CHECK(p->magic == PERSIST_MAGIC && p->cr.bpm == 133 && p->cr.vel == 77 && p->cr.tonic == 0 && !p->cr.key_on && !p->cr.scale, "backup: the settings carry the last change");
    }
    t_begin(66); t_b(6); t_u32(3000); t_b(200 & 127); t_b(200 >> 7);
    a = t_send(&n);
    CHECK(a && a[1] == 1, "GET past the end: rc 1 (%d %d)", a ? a[0] : -1, a ? a[1] : -1);
    t_begin(66); t_b(2); t_u32(0); t_b(16); t_b(0);
    a = t_send(&n);
    CHECK(a && a[1] == 1, "GET of id 2 (a Felucca project): rc 1");
    nref = nman;
    for (i = 0; i < nman; i++) { ref[i] = man[i]; man[i].bytes = 0; }

    /* ---- a USB reset makes the snapshot stale ---- */
    usb.resets++;
    t_begin(66); t_b(1); t_u32(0); t_b(16); t_b(0);
    a = t_send(&n);
    CHECK(a && a[1] == 5, "GET after a USB reset: rc 5 (LIST again)");

    /* ---- restore everything onto an erased flash ---- */
    memset(emu_flash, 0xFF, sizeof emu_flash);
    power_on();
    CHECK(t_list() == 0 && find(man, nman, 6)->size == 0 && !find(man, nman, 32), "erased: banks empty (no sample object)");
    {
        int rc = 0;
        for (i = 0; i < nref && !rc; i++) {
            const obj_t *o = &ref[i];
            if (o->id == 1) continue;                /* the settings last, as the page does */
            rc = t_put(o->id, o->bytes, o->size);
            if (rc) printf("  restore id %u: rc %d\n", o->id, rc);
        }
        CHECK(!rc, "restore: every object accepted (PUT)");
        CHECK(!cr_restore_lock, "restore: no settings lock before the settings");
        rc = t_put(1, find(ref, nref, 1)->bytes, find(ref, nref, 1)->size);
        CHECK(rc == 0 && cr_restore_lock && CR_SETTINGS_BUSY(), "restore: settings committed, the settings saves held until the restart");
    }
    CHECK(up_used(3) && up_used(16 + 4) && cs.loop_used == (1u | 1u << 4 | 1u << 9) &&
          fm6_bank.used == 5u && va_store.used == (1u << 3 | 1u << 19) && fm6u[0].used == 1u << 3 && fm6u[1].used == 1u << 3 &&
          quad_store.used == 1u << 5,
          "restore: the mirrors reloaded (user sounds, loops, FM6, VA, FM6 patches, QUAD patches)");
    CHECK(t_capture() == 0 && nman == nref, "restore: LIST + GET again");
    {
        int same = 1;
        for (i = 0; i < nref; i++) {
            const obj_t *o = find(man, nman, ref[i].id);
            if (!o || o->size != ref[i].size || o->crc != ref[i].crc || memcmp(o->bytes, ref[i].bytes, o->size)) {
                printf("  id %u differs (%u / %u bytes)\n", ref[i].id, o ? o->size : 0, ref[i].size);
                same = 0;
            }
        }
        CHECK(same, "restore: every object identical to the backup (list -> read -> write back -> identical)");
    }

    /* ---- refused: CRC, size, content; nothing written ---- */
    {
        obj_t *o = find(ref, nref, 6);
        uint32_t erases = emu_stalls;
        uint8_t bad[CRL_REC_MAX];
        int rc = t_put_begin(6, o->size, o->crc ^ 1u);
        for (i = 0; !rc && i < o->size; i += 256) rc = t_put_data(6, i, o->bytes + i, o->size - i < 256 ? o->size - i : 256);
        CHECK(!rc && t_put_op(2, 6) == 2 && emu_stalls == erases, "a CRC error: commit rc 2, nothing erased");
        CHECK(t_put_begin(6, 100, 0) == 1 && t_put_begin(1, 4000, 0) == 1 && t_put_begin(9, 17, 0) == 1, "a wrong size: begin rc 1");
        memcpy(bad, o->bytes, o->size);
        bad[0] ^= 1;                                 /* the bank's magic */
        CHECK(t_put(6, bad, o->size) == 2 && emu_stalls == erases, "a bank with a bad magic: rc 2, nothing written");
        o = find(ref, nref, 40);
        memcpy(bad, o->bytes, o->size);
        bad[4] = 9;                                  /* the loop record's version */
        CHECK(t_put(40, bad, o->size) == 2, "a loop record of another version: rc 2");
        o = find(ref, nref, 8);
        memcpy(bad, o->bytes, o->size);
        bad[12] = 200;                               /* a function setting out of its range */
        CHECK(t_put(8, bad, o->size) == 2, "an FM6 bank with a bad function setting: rc 2");
        o = find(ref, nref, 10);
        memcpy(bad, o->bytes, o->size);
        bad[16 + 3 * FM6_BLOB + 112] = 0;            /* slot 4's blob: its magic */
        CHECK(t_put(10, bad, o->size) == 2, "an FM6 patch store with a bad blob: rc 2");
        CHECK(t_put_data(6, 0, bad, 16) == 5 && t_put_op(2, 6) == 5, "data / commit without a begin: rc 5");
        o = find(ref, nref, 6);
        CHECK(t_put_begin(6, o->size, o->crc) == 0 && t_put_data(6, 256, o->bytes, 256) == 1, "data out of order: rc 1");
        CHECK(t_put_op(3, 6) == 0 && t_put_op(2, 6) == 5, "abort ends the session");
    }

    /* ---- stale sessions ---- */
    {
        obj_t *o = find(ref, nref, 7);
        CHECK(t_put_begin(7, o->size, o->crc) == 0 && t_put_data(7, 0, o->bytes, 256) == 0, "stale: begin + data");
        cu_loop_gen++;                               /* the UI loaded a loop slot through cu_loop_buf */
        CHECK(t_put_data(7, 256, o->bytes + 256, 256) == 5, "stale: the UI reused the staging buffer -> rc 5");
        CHECK(t_put_begin(7, o->size, o->crc) == 0, "stale: begin again");
        fm1_ms += 16000u;
        CHECK(t_put_data(7, 0, o->bytes, 256) == 5, "stale: 15 s without a request -> rc 5");
        CHECK(t_put_begin(7, o->size, o->crc) == 0, "stale: begin again");
        usb.resets++;
        CHECK(t_put_data(7, 0, o->bytes, 256) == 5, "stale: a USB reset -> rc 5");
    }

    /* ---- busy: a playing loop ---- */
    {
        obj_t *o = find(ref, nref, 41 + 3);          /* (an empty slot: a begin of size 0 deletes) */
        obj_t *l = find(ref, nref, 40);
        uint32_t erases = emu_stalls;
        cr_snap.lstate = CRL_PLAYING;
        CHECK(t_put_begin(41, l->size, l->crc) == 3, "busy: a begin while a loop plays: rc 3");
        cr_snap.lstate = CRL_STOPPED;
        CHECK(t_put_begin(41, l->size, l->crc) == 0, "busy: the begin once it stopped");
        for (i = 0; i < l->size; i += 256) t_put_data(41, i, l->bytes + i, l->size - i < 256 ? l->size - i : 256);
        cr_snap.lstate = CRL_PLAYING;
        CHECK(t_put_op(2, 41) == 3 && emu_stalls == erases, "busy: a commit while it plays: rc 3, nothing written");
        cr_snap.lstate = CRL_STOPPED;
        CHECK(t_put_op(2, 41) == 0 && (cs.loop_used >> 1 & 1u), "busy: the same commit once it stopped (slot 2 now holds the loop)");
        CHECK(t_put(41, 0, 0) == 0 && !(cs.loop_used >> 1 & 1u), "a loop slot of size 0: deleted");
        (void)o;
    }

    /* ---- Felucca's objects ---- */
    {
        const persist_t *p0 = (const persist_t *)find(ref, nref, 1)->bytes;
        static uint8_t per4[sizeof(persist_t)];
        uint32_t n4 = sizeof(persist_t) - sizeof(cr_settings_t);
        persist_t *rd = (persist_t *)cu_loop_buf;
        memcpy(per4, p0, n4);
        per4[0] = 0x34;                              /* "PER4" */
        CHECK(t_put(1, per4, n4) == 0, "Felucca: a PER4 settings record is taken");
        CHECK(st_load(OBJ_SETTINGS, rd, sizeof *rd) == (int)sizeof *rd && rd->magic == PERSIST_MAGIC &&
              rd->panel.magic == PANEL_MAGIC && rd->cr.magic == CRS_MAGIC && rd->cr.bpm == 120,
              "Felucca: stored as PER5, Felucca's fields kept, ChoralRoot's block the defaults");
        CHECK(t_put_begin(0, 3584, 0) == 1 && t_put_begin(2, 3584, 0) == 1 && t_put_begin(5, 0, 0) == 1,
              "Felucca: ids 0 (the music) and 2..5 (projects) refused (rc 1)");
        CHECK(t_put_begin(32, 4096, 0) == 1 && t_put_begin(33, 0, 0) == 1 && t_put_begin(34, 0, 0) == 1,
              "Felucca: ids 32..34 (sample slots) refused (rc 1)");
        CHECK(t_smp(11, 0) == -1 && t_smp(14, 0) == -1 && t_smp(11, 2) == -1, "SMP_BEGIN / SMP_ERASE: no reply (no SAMPLE engine)");
        CHECK(t_put(6, find(ref, nref, 6)->bytes, sizeof(up_bank_t)) == 0 && t_put(8, find(ref, nref, 8)->bytes, sizeof(fm6_bank_t)) == 0,
              "Felucca: user preset banks and the FM6 bank restore");
        {   /* Felucca 1.0's FM6 bank (27 unpacked records, version 1): taken, imported at the next boot */
            static uint8_t fel[16 + 27 * 128];
            uint8_t v1[FP_SIZE + 1u], rec[FM6_PACKED];
            memset(fel, 0, sizeof fel);
            fel[0] = 0x46; fel[1] = 0x4D; fel[2] = 0x36; fel[3] = 0x42;   /* "FM6B" */
            fel[4] = 1; fel[6] = 27; fel[8] = 1u << 1;                   /* slot 2 used */
            fm6_unpack(FM6_FACTORY[3], v1);
            fm6_pack(v1, fel + 16 + 128);
            CHECK(t_put(8, fel, sizeof fel) == 0, "Felucca 1.0: its 27-slot FM6 bank restores");
            fm6_bank_boot();
            CHECK(fm6_bank.used == 1u << 1 && fm6_bank_get(1, rec) == 0 && !memcmp(rec, FM6_FACTORY[3], FM6_PACKED),
                  "Felucca 1.0: its FM6 bank imported (B2 = the record)");
        }
        CHECK(t_put(6, 0, 0) == 0 && !up_used(3), "a bank of size 0: emptied");
    }

    /* ---- sounds: single slots through PUT (docs/SOUNDS.md: export / import / rename / delete as whole objects) ---- */
    {
        static up_bank_t b0, b1, bad_b;
        static va_store_t vs, bad_v;
        static fm6u_t f0;
        static czu_t c1;
        static uint8_t got[4096];
        uint8_t vb[VA_BLOB], fb[FM6_BLOB], out[256];
        char nm[13];
        int rc;
        memset(emu_flash, 0xFF, sizeof emu_flash);   /* a fresh device */
        power_on();
        trk[0].eng_req = ENGI_VA;
        va_blob_get(&trk[0], vb);
        trk[1].eng_req = ENGI_FM6;
        fm6_load_slot(1, 3);
        fm6_blob_get(&trk[1], fb);
        CHECK(va_blob_ok(vb) && fm6_blob_ok(fb), "sounds: a VA blob and an FM6 blob");
        /* a: import U03 (VA "MY PAD") and U05 (FM6 "TINE 2"): the stores first, the bank last */
        memset(&b0, 0, sizeof b0);
        b0.magic = UP_BANK_MAGIC; b0.rsize = sizeof(up_rec_t); b0.nslot = UP_PER_BANK;
        b0.r[2].used = UP_USED; b0.r[2].ver = UP_VER; b0.r[2].engine = ENGI_VA; b0.r[2].np = P_COUNT;
        memcpy(b0.r[2].name, "MY PAD", 6);
        for (i = 0; i < P_COUNT; i++) b0.r[2].packed[i] = (uint8_t)(64 + (int)(i % 7));
        b0.r[4] = b0.r[2];
        b0.r[4].engine = ENGI_FM6;
        memset(b0.r[4].name, 0, 12);
        memcpy(b0.r[4].name, "TINE 2", 6);
        memset(&vs, 0, sizeof vs);
        vs.magic = VA_STORE_MAGIC; vs.ver = 3; vs.nslot = UP_LEGACY_SLOTS; vs.blob = VA_BLOB; vs.used = 1u << 2;
        memcpy(vs.p[2], vb, VA_BLOB);
        memset(&f0, 0, sizeof f0);
        f0.magic = FM6U_MAGIC; f0.ver = FM6U_VER; f0.nslot = FM6U_HALF; f0.first = 0; f0.blob = FM6_BLOB; f0.used = 1u << 4;
        memcpy(f0.b[4], fb, FM6_BLOB);
        CHECK(sizeof b0 == 3080 && sizeof vs == 3536 && sizeof f0 == 2064 && sizeof c1 == 2320, "sounds: the object sizes of docs/SOUNDS.md");
        CHECK(t_put(9, (uint8_t *)&vs, sizeof vs) == 0, "sounds: the VA store PUT");
        CHECK(t_put(10, (uint8_t *)&f0, sizeof f0) == 0, "sounds: FM6 store half 0 PUT");
        CHECK(t_put(6, (uint8_t *)&b0, sizeof b0) == 0, "sounds: bank 0 PUT");
        CHECK(up_used(2) && up_used(4), "sounds: U03 and U05 used at once (no restart)");
        up_name(2, nm);
        CHECK(!strcmp(nm, "MY PAD"), "sounds: U03's name (%s)", nm);
        up_name(4, nm);
        CHECK(!strcmp(nm, "TINE 2"), "sounds: U05's name (%s)", nm);
        CHECK(up_rec(2)->engine == ENGI_VA && up_rec(4)->engine == ENGI_FM6, "sounds: the engines");
        CHECK(va_store_get(2, out) == 0 && !memcmp(out, vb, VA_BLOB), "sounds: U03's VA patch reads back");
        CHECK(fm6u_get(4, out) == 0 && !memcmp(out, fb, FM6_BLOB), "sounds: U05's FM6 patch reads back");
        for (k = 0, i = 0; i < UP_SLOTS; i++) k += i != 2 && i != 4 && up_used(i);
        CHECK(k == 0, "sounds: the other slots empty");
        CHECK(va_store_get(4, out) != 0 && fm6u_get(2, out) != 0, "sounds: no VA patch in U05, no FM6 patch in U03");
        /* b: rename U03 */
        memset(b0.r[2].name, 0, 12);
        memcpy(b0.r[2].name, "RENAMED", 7);
        CHECK(t_put(6, (uint8_t *)&b0, sizeof b0) == 0, "sounds: rename: bank 0 PUT");
        up_name(2, nm);
        CHECK(!strcmp(nm, "RENAMED") && up_used(2) && va_store_get(2, out) == 0 && !memcmp(out, vb, VA_BLOB),
              "sounds: rename: the new name, the same patch (%s)", nm);
        /* c: delete U03 */
        vs.used &= ~(1u << 2);
        memset(vs.p[2], 0, VA_BLOB);
        memset(&b0.r[2], 0, sizeof b0.r[2]);
        CHECK(t_put(9, (uint8_t *)&vs, sizeof vs) == 0 && t_put(6, (uint8_t *)&b0, sizeof b0) == 0, "sounds: delete: store + bank PUT");
        CHECK(!up_used(2) && va_store_get(2, out) != 0, "sounds: delete: U03 empty, its patch gone");
        up_name(4, nm);
        CHECK(up_used(4) && !strcmp(nm, "TINE 2") && fm6u_get(4, out) == 0 && !memcmp(out, fb, FM6_BLOB), "sounds: delete: U05 intact");
        /* another engine over a slot: U05 becomes a VA sound, its FM6 bit cleared */
        f0.used = 0;
        memset(f0.b[4], 0, FM6_BLOB);
        vs.used |= 1u << 4;
        memcpy(vs.p[4], vb, VA_BLOB);
        b0.r[4].engine = ENGI_VA;
        CHECK(t_put(10, (uint8_t *)&f0, sizeof f0) == 0 && t_put(9, (uint8_t *)&vs, sizeof vs) == 0 &&
              t_put(6, (uint8_t *)&b0, sizeof b0) == 0, "sounds: U05 replaced by a VA sound: PUTs");
        CHECK(up_used(4) && up_rec(4)->engine == ENGI_VA && fm6u_get(4, out) != 0 && va_store_get(4, out) == 0 &&
              !memcmp(out, vb, VA_BLOB), "sounds: U05 now VA, the old FM6 patch unreadable");
#if FELUCCA_CZ
        /* d: a CZ-1 sound in U20 (bank 1, store half 1) */
        memset(&c1, 0, sizeof c1);
        c1.magic = CZU_MAGIC; c1.ver = CZU_VER; c1.nslot = CZU_HALF; c1.first = CZU_HALF; c1.blob = CZ_BYTES; c1.used = 1u << 3;
        memcpy(c1.b[3], CZ_FACTORY[24], CZ_BYTES);
        memset(&b1, 0, sizeof b1);
        b1.magic = UP_BANK_MAGIC; b1.rsize = sizeof(up_rec_t); b1.nslot = UP_PER_BANK;
        b1.r[3] = b0.r[4];
        b1.r[3].engine = ENGI_CZ;
        memset(b1.r[3].name, 0, 12);
        memcpy(b1.r[3].name, "CZ PIANO", 8);
        CHECK(t_put(13, (uint8_t *)&c1, sizeof c1) == 0 && t_put(7, (uint8_t *)&b1, sizeof b1) == 0, "sounds: CZ-1: store half 1 + bank 1 PUT");
        up_name(19, nm);
        CHECK(up_used(19) && up_rec(19)->engine == ENGI_CZ && !strcmp(nm, "CZ PIANO") && czu_get(19, out) == 0 &&
              !memcmp(out, CZ_FACTORY[24], CZ_BYTES), "sounds: CZ-1: U20 used, its tone reads back (%s)", nm);
        CHECK(czu_get(3, out) != 0, "sounds: CZ-1: half 0 empty");
#endif
        /* d2: a QUAD sound in U07 (bank 0, the QUAD store: object 22) */
        {
            static quad_store_t q, bad_q;
            uint8_t qb[QUAD_BLOB];
            trk[0].eng_req = ENGI_QUAD;
            quad_blob_preset(&trk[0], 11);           /* (STRINGS) */
            quad_blob_get(&trk[0], qb);
            memset(&q, 0, sizeof q);
            q.magic = QUAD_STORE_MAGIC; q.ver = QUAD_STORE_VER; q.nslot = UP_LEGACY_SLOTS; q.blob = QUAD_BLOB; q.used = 1u << 6;
            memcpy(q.p[6], qb, QUAD_BLOB);
            b0.r[6] = b0.r[4];
            b0.r[6].engine = ENGI_QUAD;
            memset(b0.r[6].name, 0, 12);
            memcpy(b0.r[6].name, "MY QUAD", 7);
            CHECK(sizeof q == 2576u && t_put(22, (uint8_t *)&q, sizeof q) == 0 && t_put(6, (uint8_t *)&b0, sizeof b0) == 0,
                  "sounds: QUAD: store (22) + bank 0 PUT");
            up_name(6, nm);
            CHECK(up_used(6) && up_rec(6)->engine == ENGI_QUAD && !strcmp(nm, "MY QUAD") && quad_store_get(6, out) == 0 &&
                  !memcmp(out, qb, QUAD_BLOB), "sounds: QUAD: U07 used, its patch reads back (%s)", nm);
            memcpy(&bad_q, &q, sizeof q);
            bad_q.p[6][1] = (uint8_t)(QUAD_VER + 1u); /* unsupported future blob version: must be refused */
            CHECK(t_put(22, (uint8_t *)&bad_q, sizeof bad_q) == 2 && t_put_begin(22, 100, 0) == 1 &&
                  quad_store_get(6, out) == 0 && !memcmp(out, qb, QUAD_BLOB), "sounds: QUAD: a bad blob / a wrong size refused, the patch kept");
            CHECK(t_list() == 0 && find(man, nman, 22)->size == 2576u && find(man, nman, 22)->crc == st_crc32((uint8_t *)&q, sizeof q),
                  "sounds: LIST: the QUAD store as written");
        }
        /* e: refusals */
        memcpy(&bad_v, &vs, sizeof vs);
        bad_v.p[4][0] = 'X';                         /* U05's blob: a wrong magic byte */
        CHECK(t_put(9, (uint8_t *)&bad_v, sizeof bad_v) == 2, "sounds: a VA store with a bad blob magic: rc 2");
        rc = t_list();
        for (i = 0; !rc && i < sizeof vs; i += 256) rc = t_get(9, i, sizeof vs - i < 256 ? sizeof vs - i : 256, got + i);
        CHECK(!rc && !memcmp(got, &vs, sizeof vs) && va_store_get(4, out) == 0 && !memcmp(out, vb, VA_BLOB),
              "sounds: refused: GET 9 still the previous store, the mirror too");
        memcpy(&bad_b, &b0, sizeof b0);
        bad_b.rsize = 190;
        bad_b.r[2] = b0.r[4];                        /* (would add U03) */
        CHECK(t_put(6, (uint8_t *)&bad_b, sizeof bad_b) == 2 && !up_used(2) && up_used(4), "sounds: a bank of rsize 190: rc 2, slots unchanged");
        /* f: LIST: sizes and CRCs of what was written */
        CHECK(t_list() == 0, "sounds: LIST");
        CHECK(find(man, nman, 6)->size == 3080 && find(man, nman, 6)->crc == st_crc32((uint8_t *)&b0, sizeof b0) &&
              find(man, nman, 9)->size == 3536 && find(man, nman, 9)->crc == st_crc32((uint8_t *)&vs, sizeof vs) &&
              find(man, nman, 10)->size == 2064 && find(man, nman, 10)->crc == st_crc32((uint8_t *)&f0, sizeof f0) &&
              find(man, nman, 11)->size == 0,
              "sounds: LIST: bank 0, the VA store, FM6 half 0 as written (FM6 half 1 never written: 0)");
#if FELUCCA_CZ
        CHECK(find(man, nman, 7)->size == 3080 && find(man, nman, 7)->crc == st_crc32((uint8_t *)&b1, sizeof b1) &&
              find(man, nman, 13)->size == 2320 && find(man, nman, 13)->crc == st_crc32((uint8_t *)&c1, sizeof c1) &&
              find(man, nman, 12)->size == 0, "sounds: LIST: bank 1 and CZ-1 half 1 as written");
#endif
    }

    /* ---- RESTART ---- */
    t_begin(CRB_DEBUG); a=t_send(&n);
    CHECK(a && a[0]==1 && n==2u+5u*a[1] && a[1]>=32u, "DEBUG: version/count and whole u32 telemetry");
    CHECK(a && crb_r32(a+2u+5u*29u)==0, "DEBUG: host reports no executed boot stub");
    t_begin(CRB_STUB);t_b(1);a=t_send(&n);
    CHECK(a && n==1u && a[0]==127u, "STUB: host without hardware stub refuses restart");
    t_begin(72);
    a = t_send(&n);
    CHECK(a && n == 1 && a[0] == 0 && crb.reboot, "RESTART: rc 0, the restart scheduled");

    printf("objects: settings %u (PER4 %u), bank %u, FM6 %u, VA %u, FM6 patches 2 x %u, QUAD %u, loop <= %u bytes\n",
           (unsigned)sizeof(persist_t), (unsigned)(sizeof(persist_t) - sizeof(cr_settings_t)), (unsigned)sizeof(up_bank_t),
           (unsigned)sizeof(fm6_bank_t), (unsigned)sizeof(va_store_t), (unsigned)sizeof(fm6u_t), (unsigned)sizeof(quad_store_t),
           (unsigned)CRL_REC_MAX);
    printf("%s: %d checks, %d failed\n", fails ? "CR BACKUP TESTS FAILED" : "cr backup tests passed", checks, fails);
    return fails ? 1 : 0;
}

#endif
