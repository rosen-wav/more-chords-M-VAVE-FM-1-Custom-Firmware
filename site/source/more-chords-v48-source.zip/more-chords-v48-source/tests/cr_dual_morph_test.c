/* Regression: both endpoints are independent audio voices; B renders through
 * the existing (unchanged) bass CPU1 worker in split mode. */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static int32_t out[2*CTL];
static int32_t snapshot[2*CTL];
static void morph_setup(uint32_t src,uint32_t target){
 setup(MORPH_SOURCE[src],0,ENGI_CZ,0,0,0);
 cu_load(&trk[0],ENGI_MORPH,0,0);engine_block(&trk[0]);panic_req=0;
 trk[0].p[P_E0]=src;
 trk[0].p[P_E1]=0;
 trk[0].p[P_E2]=target;
 trk[0].p[P_E3]=0; /* endpoint fixtures explicitly use Manual; factory default is Up/Down */
 trk[0].p[P_E5]=100;
 trk[0].p[P_E7]=(int16_t)(0x1200u | (ENGINES[MORPH_SOURCE[src]]->npresets>1 ? 1u : 0u));
 trk[0].p[P_CHOR]=trk[0].p[P_REV]=trk[0].p[P_DLY]=trk[0].p[P_DIST]=0;
 morph_sync(&trk[0]);
 assert(morph_dual && morph.ready && trk[2].engine==MORPH_SOURCE[src]);
 trk_note_on(&trk[0],60,100);
 assert(trk[2].v[0].active);
}
static void test_endpoints(uint32_t src){
 int32_t refA[2*CTL],refB[2*CTL];
 cr_c1_test_serial=1;
 morph_setup(src,0);
 for(unsigned j=0;j<12;j++){
  engine_block(&trk[0]);engine_block(&trk[1]);engine_block(&trk[2]);
  mix_block(out,CTL);
 }
 memcpy(refA,out,sizeof out);
 /* Regression: the real mixer must have consumed the A/B PCM.
  * Previously mix_part_out called morph_fade_pcm, but morph_begin never
  * entered the source-patch scope, so the fade was silently skipped. */
 assert(morph_gain_a==32767 && morph_gain_b==0);
 assert(!morph.inside);
 trk[0].p[P_E2]=127;
 morph.pos=127*256; morph.amount_q8=100*256;
 morph.motion_from=morph.motion_to=morph.target=morph.pos;
 morph.motion_time=0;
 for(unsigned j=0;j<12;j++){
  engine_block(&trk[0]);engine_block(&trk[1]);engine_block(&trk[2]);
  mix_block(out,CTL);
 }
 memcpy(refB,out,sizeof out);
 assert(morph_gain_a==0 && morph_gain_b==32767); /* B actually reached the mixer */
 assert(!morph.inside); /* source parameters were restored after mix */
 /* At the midpoint the mixer must render BOTH engines at non-zero gain. */
 trk[0].p[P_E2]=64;
 morph.pos=64*256;
 morph.motion_from=morph.motion_to=morph.target=morph.pos;
 morph.motion_time=0;
 engine_block(&trk[0]);engine_block(&trk[1]);engine_block(&trk[2]);
 mix_block(out,CTL);
 assert(morph_gain_a>10000 && morph_gain_a<30000);
 assert(morph_gain_b>10000 && morph_gain_b<30000);
 assert(!morph.inside);
 unsigned a=0,b=0;
 for(unsigned i=0;i<2*CTL;i++){a+=(refA[i]!=0);b+=(refB[i]!=0);assert(abs(out[i])<2000000);}
 /* A/B endpoints must run without crashing even for silent presets. */
 printf("src=%u A=%u B=%u shadow=%u\n",src,a,b,morph_dual);
 trk_note_off(&trk[0],60);
 assert(!trk[2].v[0].gate);
}
/* End-to-end UI regression.  In V5 the visible "Morph" control on page 0
 * changed the movement mode rather than Position, so turning it did not
 * reach Patch B. Test the actual first-page knob, not internal gain fields. */
static void test_front_page_position(void){
 int64_t energy_b=0, energy_out=0;
 cr_c1_test_serial=1;
 morph_setup(0,0);
 trk[1].p[P_MUTE]=1;trk_all_off(&trk[1]); /* no Bass hiding a silent Morph */
 assert(!strcmp(morph_deep_desc(&trk[0],0,3)->label,"Position"));
 assert(!strcmp(morph_deep_desc(&trk[0],1,3)->label,"Mode"));
 assert(morph_deep_get(&trk[0],0,3)==0);
 morph_deep_set(&trk[0],0,3,127);
 assert(trk[0].p[P_E2]==127 && trk[0].p[P_E3]==0);
 for(unsigned j=0;j<180;j++){
  for(unsigned i=0;i<NPART;i++)engine_block(&trk[i]);
  mix_block(out,CTL);
  if(j>=176){for(unsigned i=0;i<CTL;i++){
   energy_b+=llabs((long long)morph_b_pcm[i]);
   energy_out+=llabs((long long)out[2*i])+llabs((long long)out[2*i+1]);
  }}
 }
 assert(morph_gain_b>32500 && morph_gain_a<3000);
 assert(energy_b>500 && energy_out>500);
 printf("PASS: front-page Position reaches audible Patch B, pcm=%lld out=%lld\n",
       (long long)energy_b,(long long)energy_out);
}
/* UI-only regression: no stray preset sentence at Position=0 and no
 * Random explanation while Mode is Manual/Up and Down. */
static void test_morph_display(void){
 cr_screen_t screen;
 morph_setup(0,0);
 ce.part=0;
 cx.grp[0]=CE_OSC;
 cx.morph_focus[0]=3;
 trk[0].p[P_E2]=0;
 morph_publish(&trk[0]);
 cr_screen_clear(&screen);
 ce_morph_screen(&screen,&trk[0]);
 assert(!strcmp(screen.cell[0][3].label,"Position"));
 assert(!strcmp(screen.cell[0][3].value,"0"));
 assert(screen.value[0]==0); /* the unwanted sentence is gone */
 cx.grp[0]=CE_LFO;
 trk[0].p[P_E3]=0;
 morph_publish(&trk[0]);
 cr_screen_clear(&screen);
 ce_morph_screen(&screen,&trk[0]);
 assert(screen.value[0]==0);
 trk[0].p[P_E3]=2;
 morph_publish(&trk[0]);
 cr_screen_clear(&screen);
 ce_morph_screen(&screen,&trk[0]);
 assert(screen.wide==CR_W_MORPH && screen.wv[1]==2 && screen.n_rows==1);
 assert(screen.item[0][0] && screen.item[1][0]);
 printf("PASS: clean Morph Position=0 display and A/B overview and contextual mode\n");
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)test_endpoints(i);
 test_front_page_position();
 test_morph_display();
 printf("PASS: %u dual audio morph engine endpoints and note-off routing\n",(unsigned)NELEM(MORPH_SOURCE));
 return 0;
}
