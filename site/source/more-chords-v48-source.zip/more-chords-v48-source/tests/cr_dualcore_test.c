/* SPDX-License-Identifier: GPL-3.0-only */
/* Real concurrent BASS rendering through the common mixer. */
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <assert.h>
#include <stdio.h>
static uint32_t ticks(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint32_t)((uint64_t)t.tv_sec*1000000u+t.tv_nsec/1000);}
#define CHORALROOT_DUAL_CORE 1
#define CR_C1_THREADED_TEST 1
#define AW_WORD _Atomic uint32_t
#define AW_LOAD(p) atomic_load_explicit(p,memory_order_acquire)
#define AW_STORE(p,v) atomic_store_explicit(p,v,memory_order_release)
#define AW_TICKS() ticks()
#define AW_TIMEOUT_TICKS 10000000u
#define AW_FAULT() abort()
#define AW_RAM_LOOP static
#define AW_IDLE() pthread_testcancel()
#include "../firmware/src/audio_worker.h"
#define AW_C1_BUSY() (AW_LOAD(&audio_worker.request)!=AW_LOAD(&audio_worker.complete))
static int cr_c1_test_serial;
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void *worker(void *p){(void)p;audio_worker_loop();return 0;}
static int32_t reference[128][2*CTL];
static voice_t voices[NPART][NVOICE];
static unsigned char states[sizeof eng_state], va_states[sizeof va_vs], quad_states[sizeof quad_vs];
static unsigned engines[]={ENGI_CZ,ENGI_PROPHET,ENGI_FM6,ENGI_VA,ENGI_QUAD};
static void setup(unsigned e0,unsigned p0,unsigned e1,unsigned p1,unsigned count,unsigned reverb){
 memset(trk,0,sizeof trk);clear(e0,0,0);
 vage=0;unison_seed=0x1234567u;mod_seed=0x2545F491u;rng_state=0x1234567u;
 memset(mod_tab,0,sizeof mod_tab);memset(eng_state,0,sizeof eng_state);
 memset((void*)fm6_pgen,0,sizeof fm6_pgen);memset((void*)fm6_lgen,0,sizeof fm6_lgen);memset(fm6_eff,0,sizeof fm6_eff);
 memset(va_vs,0,sizeof va_vs);memset(va_lfo,0,sizeof va_lfo);memset(va_pan_off,0,sizeof va_pan_off);
 memset(quad_vs,0,sizeof quad_vs);memset(quad_lfo,0,sizeof quad_lfo);memset(quad_pan_off,0,sizeof quad_pan_off);
 memset(&fx,0,sizeof fx);memset(dly_buf,0,sizeof dly_buf);memset(cho_buf,0,sizeof cho_buf);
 memset(rev_comb,0,sizeof rev_comb);memset(&rev_u,0,sizeof rev_u);memset(&pf,0,sizeof pf);
 lim_env=LIM_T;lim_g=32768;fx_smooth=1;fx_lowcut=0;dc_l=dc_r=dce_l=dce_r=0;
 for(unsigned p=0;p<NPART;p++)for(unsigned k=0;k<P_COUNT;k++)trk[p].p[k]=TP[k].def;
 cu_load(&trk[0],e0,p0,0);cu_load(&trk[1],e1,p1,0);panic_req=0;
 for(unsigned p=0;p<2;p++){
  trk[p].engine=trk[p].eng_req=p?e1:e0;trk[p].xf_on=0;trk[p].xp_n=0;trk[p].p[P_VOICE]=p?V_MONO:V_POLY;
  trk[p].p[P_LWAVE]=4;trk[p].p[P_LRATE]=115+p*5;trk[p].p[P_LD_PIT]=7;trk[p].p[P_LD_FLT]=23;
  trk[p].p[P_M1SRC]=MS_LFO;trk[p].p[P_M1DST]=MD_CUT;trk[p].p[P_M1AMT]=31;
  trk[p].p[P_REV]=48;trk[p].p[P_DLY]=32;trk[p].p[P_CHOR]=16;
 }
 memset(midi_bend_q8,0,sizeof midi_bend_q8);memset(midi_bend_target,0,sizeof midi_bend_target);
 song.g[G_RTYPE]=reverb; song.master_q12=2048;
 fx_output_set(cs.out_clean,1); /* Reset the chosen output chain before each serial/CPU1 comparison. */
 cr_sidechain_on=0;cr_sidechain_gain=32768;cr_rosen_mode=0;
 for(unsigned i=0;i<count;i++)trk_note_on(&trk[0],48+i*3,100);
 trk_note_on(&trk[1],36,100);
}
static void block(unsigned k,int32_t *out){
 if(k==40){trk_note_off(&trk[0],48);trk_note_off(&trk[1],36);}
 if(k==60){trk_note_on(&trk[0],48,90);trk_note_on(&trk[1],38,110);}
 if(k==100){trk_all_off(&trk[0]);trk_all_off(&trk[1]);}
 for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);
 mix_block(out,CTL);
 assert(!AW_C1_BUSY());
}

#ifndef CR_C1_HELPERS_ONLY
int main(void){pthread_t th;unsigned cases=0;int32_t out[CTL*2];
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 for(unsigned a=0;a<5;a++)for(unsigned b=0;b<5;b++)for(unsigned rev=0;rev<4;rev++){
  unsigned e=engines[a],bass=engines[b];
  unsigned sweep=(a<2)?ENGINES[e]->npresets:4;
  for(unsigned preset=0;preset<sweep;preset++){
   unsigned bp=preset%ENGINES[bass]->npresets,count=6;
   cr_c1_test_serial=1;setup(e,preset,bass,bp,count,rev);
   for(unsigned k=0;k<128;k++)block(k,reference[k]);
   for(unsigned p=0;p<NPART;p++)memcpy(voices[p],trk[p].v,sizeof voices[p]);memcpy(states,eng_state,sizeof states);memcpy(va_states,va_vs,sizeof va_states);memcpy(quad_states,quad_vs,sizeof quad_states);
   cr_c1_test_serial=0;setup(e,preset,bass,bp,count,rev);
   for(unsigned k=0;k<128;k++){
    block(k,out);
    if(memcmp(out,reference[k],sizeof out)){printf("PCM FAIL chord=%u preset=%u bass=%u rev=%u block=%u\n",e,preset,bass,rev,k);return 1;}
   }
   for(unsigned p=0;p<NPART;p++)if(memcmp(voices[p],trk[p].v,sizeof voices[p])){printf("VOICE FAIL chord=%u preset=%u bass=%u rev=%u part=%u\n",e,preset,bass,rev,p);return 1;}
   if(memcmp(states,eng_state,sizeof states)){for(unsigned j=0;j<sizeof states;j++)if(states[j]!=((unsigned char*)eng_state)[j]){printf("ENGINE STATE FAIL chord=%u preset=%u bass=%u rev=%u byte=%u\n",e,preset,bass,rev,j);return 1;}}assert(!memcmp(va_states,va_vs,sizeof va_states));assert(!memcmp(quad_states,quad_vs,sizeof quad_states));cases++;
  }
 }
 for(unsigned a=0;a<2;a++)for(unsigned b=0;b<5;b++)for(unsigned count=1;count<=6;count++){
  cr_c1_test_serial=1;setup(engines[a],0,engines[b],0,count,0);
  for(unsigned k=0;k<128;k++)block(k,reference[k]);
  cr_c1_test_serial=0;setup(engines[a],0,engines[b],0,count,0);
  for(unsigned k=0;k<128;k++){block(k,out);assert(!memcmp(out,reference[k],sizeof out));}cases++;
 }
 for(unsigned eidx=0;eidx<2;eidx++)for(int rot=-3;rot<=5;rot++){
  clear(engines[eidx],1,0);cr_mod(&cr,CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);cr.voicing=rot;cr_key(&cr,60,100,1);settle();
  unsigned n=0;for(unsigned i=0;i<NVOICE;i++)n+=trk[0].v[i].active&&trk[0].v[i].gate&&trk[0].v[i].stage!=4;
  assert(n==6);assert(third_present());assert(voices_busy_of(&trk[0])<=VBUDGET);cases++;
 }
 cr_dbg.c1=C1_FAILED;audio_worker_online=0;assert(cz_voice_cap(&trk[0])==5);assert(p5_live_poly(&trk[0])==5);assert(p5_units(&trk[0])==3);
 assert(!audio_worker_submit(cr_c1_dispatch,0));
 assert(audio_worker.jobs>0);assert(c1_chord_jobs>0);pthread_cancel(th);pthread_join(th,0);
 printf("BASS CPU1: %u concurrent/serial cases PASS; PCM and voice/engine state identical, five engines, four reverbs, CZ and Prophet six voices with BASS and fallback; jobs=%u\n",cases,audio_worker.jobs);return 0;
}

#endif
