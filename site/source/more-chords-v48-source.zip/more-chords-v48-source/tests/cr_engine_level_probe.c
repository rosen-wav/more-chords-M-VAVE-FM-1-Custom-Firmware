#include "../tools/emu/emu_fw.c"
#include <assert.h>
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 unsigned es[]={ENGI_CZ,ENGI_CS1,ENGI_KR106};
 for(unsigned k=0;k<3;k++){
  memset(eng_state,0,sizeof eng_state);track_t *t=&trk[0];cu_load(t,es[k],0,0);t->engine=t->eng_req=es[k];engine_block(t);
  const engine_t *e=eng_audio(t);if(e->block)e->block(t);uint64_t energy=0;int32_t out[CTL],side[CTL];
  for(unsigned b=0;b<256;b++){
   for(unsigned i=0;i<CTL;i++){unsigned j=b*CTL+i;out[i]=(int32_t)(j%211u)*43-4500;side[i]=0;}
   if(e->post2)e->post2(t,out,side,CTL,6);
   for(unsigned i=0;i<CTL;i++)energy+=(uint64_t)llabs(out[i])+(uint64_t)llabs(side[i]);
  }
  printf("GAIN %s %llu\n",e->name,(unsigned long long)energy);
 }
}
