#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void turn(int n){cu_knob(EN_K3,n);cr_audio_block(CTL);}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cu.page=PG_NONE;cu.armed=NB;cu_tap(BT_SWAG);
 turn(1);assert(!cs.gate_on);turn(1);assert(!cs.gate_on);turn(1);assert(cs.gate_on==1);
 turn(1);assert(cs.gate_on==1);turn(1);assert(cs.gate_on==1);turn(1);assert(cs.gate_on==1);
 cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(screen.cell[0][2].glyph==CR_G_GATE);
 turn(-1);assert(cs.gate_on==1);turn(-2);assert(!cs.gate_on);turn(3);assert(cs.gate_on==1);
 cr_build_screen(&screen,cu_now());assert(screen.cell[0][2].glyph==CR_G_GATE);
 turn(-3);assert(!cs.gate_on);
 /* Partial turns cannot accumulate indefinitely, through direction changes,
  * through another knob, or after leaving/reopening SELECT. */
 turn(2);assert(!cs.gate_on);fm1_ms+=801;turn(1);assert(!cs.gate_on);
 turn(-1);turn(1);assert(!cs.gate_on);
 cu_knob(EN_K4,1);turn(2);assert(!cs.gate_on);
 cu_tap(BT_SWAG);cu_tap(BT_SWAG);turn(1);assert(!cs.gate_on);turn(2);assert(cs.gate_on==1);
 turn(6);assert(cs.gate_on==1);turn(-6);assert(!cs.gate_on);
 turn(-2);turn(1);assert(!cs.gate_on);
 assert(!cu_shift());puts("PASS: FX three-detent selection, per-mode thresholds, no SHIFT, reverse/timeout/menu/other-knob resets, icons");
}
