/* Actual emulator ISR path; direct effect tests alone missed this connection. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static int16_t pcm[HALF_WORDS];
static long long energy(void){long long e=0;for(unsigned i=0;i<HALF_WORDS;i++)e+=(long long)pcm[i]*pcm[i];return e;}
int main(void){
 emu_fw_options(0,1,0,1); emu_fw_init(0);song.master_q12=4096; cr_route.clock_in=0;crl.metro_vol=0;crl.click=0;
 for(unsigned j=0;j<4;j++)emu_fw_audio(pcm,HALF_FRAMES);
 assert(cr_post(CRE_GATE,0,1,0));assert(cr_post(CRE_KEY,60,100,1));
 long long e=0;for(unsigned j=0;j<10;j++){emu_fw_audio(pcm,HALF_FRAMES);e+=energy();}assert(e>0);
 assert(cr_post(CRE_GATE,1,1,0));
 for(unsigned j=0;j<10;j++){crl.met0=crl.t-CRL_PPQN*3u/8u;emu_fw_audio(pcm,HALF_FRAMES);}
 assert(cr_gate_gain==0 && energy()==0);
 assert(cr_post(CRE_GATE,0,1,0));for(unsigned j=0;j<10;j++)emu_fw_audio(pcm,HALF_FRAMES);assert(energy()>0);
 puts("PASS: actual emulator ISR Gate silence/Off recovery, live sound");return 0;
}
