#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static int32_t b[2*CTL],copy[2*CTL];
static void fill(void){for(unsigned i=0;i<CTL;i++){b[2*i]=30000;b[2*i+1]=-30000;}}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cu.page=PG_NONE;cu.armed=NB;cu_tap(BT_SWAG);
 assert(cs.gate_on==0 && cs.gate_rate==1);
 cu_knob(EN_K3,1);cr_audio_block(CTL);assert(!cs.gate_on && !cr_gate_on);
 cu_knob(EN_K3,2);cr_audio_block(CTL);assert(cs.gate_on==1 && cr_gate_on==1);
 cr_screen_t s;cr_build_screen(&s,cu_now());assert(!strcmp(s.item[0],"Gate")&&!strcmp(s.label,"gate")&&s.cell[0][2].glyph==CR_G_GATE);
 cu_knob(EN_K3,20);cr_audio_block(CTL);assert(cs.gate_on==1);
 cu_knob(EN_K4,1);cr_audio_block(CTL);assert(cs.gate_rate==2&&cr_gate_rate==2);
 cr_build_screen(&s,cu_now());assert(!strcmp(s.item[0],"1/32")&&s.hot_c==3);
 cu_knob(EN_K4,-20);cr_audio_block(CTL);assert(cr_gate_rate==3);
 cr_build_screen(&s,cu_now());assert(!strcmp(s.item[0],"1/4"));
 cu_knob(EN_K3,-20);cr_audio_block(CTL);assert(!cs.gate_on);
 cr_route.clock_in=0;unsigned checks=0;
 for(unsigned bpm=20;bpm<=300;bpm+=(bpm==20?100:180))for(unsigned rate=0;rate<4;rate++){
  cr.bpm=bpm;cr_gate_rate=rate;cr_gate_on=0;cr_gate_gain=32768;fill();memcpy(copy,b,sizeof b);cr_gate_mix(b,CTL);assert(!memcmp(copy,b,sizeof b));
  cr_gate_on=1;crl.t=crl.met0=crl.acc=0;fill();cr_gate_mix(b,CTL);assert(b[0]==30000);
  crl.t=CRL_PPQN/(2u*(rate == 3u ? 1u : 2u<<rate));
  for(unsigned j=0;j<8;j++){fill();cr_gate_mix(b,CTL);for(unsigned i=1;i<CTL;i++)assert(abs(b[2*i]-b[2*i-2])<=235);}
  assert(cr_gate_gain==0&&b[2*CTL-2]==0);
  cr_gate_on=0;for(unsigned j=0;j<8;j++){fill();cr_gate_mix(b,CTL);}assert(cr_gate_gain==32768);
  fill();cr_gate_mix(b,CTL);assert(!memcmp(copy,b,sizeof b));checks++;
 }
 cr_route.clock_in=0;cr_audio_block(CTL);cr_route.clock_in=1;cr_audio_block(CTL);
 cr_gate_on=1;cr_gate_rate=1;unsigned pulse=0,base=100000;int minimum=30000,maximum=0;
 for(unsigned samples=0;samples<FS*2;samples+=CTL){
  unsigned ms=(uint32_t)((uint64_t)samples*1000/FS);
  while(pulse*60000u/(120u*24u)<=ms){fm1_ms=base+pulse*60000u/(120u*24u);assert(midi_enqueue(0xF8u<<8|0x0Fu,(pulse&1)?1:2));pulse++;}
  fm1_ms=base+ms;cr_audio_block(CTL);fill();cr_gate_mix(b,CTL);
  if(samples>FS){if(b[2*CTL-2]<minimum)minimum=b[2*CTL-2];if(b[2*CTL-2]>maximum)maximum=b[2*CTL-2];}
 }
 assert(abs((int)cr.bpm-120)<=1&&minimum==0&&maximum==30000);
 for(unsigned j=0;j<FS/CTL/2;j++){cr_audio_block(CTL);fill();cr_gate_mix(b,CTL);}
 assert(cr_gate_gain==32768);fill();cr_gate_mix(b,CTL);assert(!memcmp(copy,b,sizeof b));
 assert(cr_post(CRE_GATE,0,1,0));assert(cr_post(CRE_PANIC,0,0,0));cr_audio_block(CTL);assert(cr_gate_gain==32768);
 assert(cr_post(CRE_GATE,2,1,0));cr_audio_block(CTL);assert(!cr_gate_on);
 /* Panic stops notes but must not force open a currently closed Gate. */
 assert(cr_post(CRE_GATE,1,1,0));cr_audio_block(CTL);cr_gate_gain=0;
 assert(cr_post(CRE_PANIC,0,0,0));cr_audio_block(CTL);assert(cr_gate_on && cr_gate_gain==0);
 puts("PASS: Gate-only UI, knob clamps/rates, 12 tempo/rate fixtures, exact bypass, stereo/smoothing, queued MIDI sync/dropout and panic");return 0;
}
