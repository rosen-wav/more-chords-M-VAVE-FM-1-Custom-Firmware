#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
#include "melodee_hall_reference.h"
static uint32_t seed=123;
static int32_t noise(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return (int32_t)seed/32768;}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 int32_t in[CTL],a[CTL],b[CTL],l[CTL],r[CTL],send[CTL],zero[CTL]={0};
 unsigned blocks=0;long long side_energy=0;
 for(unsigned size=0;size<128;size+=31)for(unsigned damp=0;damp<128;damp+=31){
  rev_clear();memset(&ref_hl,0,sizeof ref_hl);memset(ref_comb,0,sizeof ref_comb);memset(ref_ap,0,sizeof ref_ap);
  song.g[G_RSIZE]=size;song.g[G_RDAMP]=damp;
  for(unsigned j=0;j<1200;j++){
   for(unsigned i=0;i<CTL;i++){in[i]=j<300?noise():0;a[i]=b[i]=0;}
   rev_hall(in,a,CTL);reference_hall(in,b,CTL);
   assert(!memcmp(a,b,sizeof a));assert(!memcmp(hl.sd,ref_hl.sd,sizeof hl.sd));
   for(unsigned i=0;i<CTL;i++)side_energy+=(long long)hl.sd[i]*hl.sd[i];
   blocks++;
  }
 }
 assert(side_energy>0);
 /* Church must add early reflections while preserving the exact Hall tail
  * algorithm. Inspect stereo energy before the Hall's first line arrives. */
 long long early[2]={0},total[2]={0};
 for(unsigned model=2;model<=3;model++){
  rev_clear();song.g[G_RSIZE]=96;song.g[G_RDAMP]=64;
  memset(in,0,sizeof in);in[0]=100000;
  for(unsigned j=0;j<FS*2/CTL;j++){
   memset(a,0,sizeof a);rev_render(model,in,a,CTL);memset(in,0,sizeof in);
   for(unsigned i=0;i<CTL;i++){
    long long e=(long long)a[i]*a[i]+(long long)rev_side[i]*rev_side[i];
    total[model-2]+=e;if(j*CTL+i<FS/50)early[model-2]+=e;
    assert(abs(a[i]+rev_side[i])<400000&&abs(a[i]-rev_side[i])<400000);
   }
  }
 }
 assert(early[1]>early[0] && total[1]>0 && total[0]>0);
 /* Old-model stereo fades and then clears on the next block. */
 fx.rtype=3;song.g[G_RTYPE]=0;fx_buses(zero,zero,zero,a,CTL);fx_buses(zero,zero,zero,a,CTL);
 assert(!memcmp(rev_stereo,zero,sizeof zero));
 printf("PASS: Ambient bit-exact Melodee %u blocks; Church stereo reflections (early energy %lld vs %lld), bounded output/model clear; Church delay %zu B\n",blocks,early[1],early[0],sizeof church_er);
 return 0;
}
