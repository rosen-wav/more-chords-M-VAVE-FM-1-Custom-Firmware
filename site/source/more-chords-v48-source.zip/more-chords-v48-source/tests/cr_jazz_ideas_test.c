/* Independent interval oracle for generated jazz qualities/extensions. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned oracle(const crl_ev_t *e,uint8_t notes[6]){
 unsigned q=e->qx>>4,ext=e->qx&15,n=3;notes[0]=e->root;notes[1]=e->root+(q==CR_Q_MAJ?4:q==CR_Q_SUS?5:3);notes[2]=e->root+(q==CR_Q_DIM?6:7);
 if(ext&CR_EXT_6)notes[n++]=e->root+9;if(ext&CR_EXT_M7)notes[n++]=e->root+10;if(ext&CR_EXT_MAJ7)notes[n++]=e->root+11;if(ext&CR_EXT_9)notes[n++]=e->root+14;return n;
}
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);cr.voicing=0;cr.perform_on=0;unsigned qmask=0,xmask=0,cases=0;unsigned seen[128]={0};crl_data_t original=crl.d,decoded;uint8_t packed[CRL_REC_MAX];
 for(unsigned mode=0;mode<2;mode++)for(unsigned tonic=0;tonic<12;tonic++)for(unsigned pattern=0;pattern<7;pattern++)for(unsigned seed=1;seed<=20;seed++){
  creative_ideas.minor=mode;creative_ideas.tonic=tonic;creative_ideas.pattern=pattern;creative_ideas.rng=seed;creative_generate();assert(crl_stage.nev==4);
  assert(!memcmp(&original,&crl.d,sizeof original));unsigned size=cr_loop_pack(&crl_stage,packed,sizeof packed);assert(size&&cr_loop_unpack(packed,size,&decoded));assert(!memcmp(decoded.ev,crl_stage.ev,4*sizeof(crl_ev_t)));
  for(unsigned i=0;i<4;i++){
   const crl_ev_t *e=&crl_stage.ev[i];unsigned q=e->qx>>4,x=e->qx&15;qmask|=1u<<q;xmask|=x;seen[e->qx]++;assert(!((x&CR_EXT_M7)&&(x&CR_EXT_MAJ7)));
   uint8_t expected[6],actual[6];unsigned n=oracle(e,expected);assert(n>=3&&n<=5);assert((unsigned)cr_chord_base(e->root,q,x,actual)==n);assert(!memcmp(actual,expected,n));
   cr_idea.active=1;cr_idea.armed=0;cr_idea.origin=100;crl.t=100+e->t;cr_idea_tick();const cr_voice_t *v=&cr.v[CR_MAX_VOICES+CR_MAX_PADS];assert(v->used&&v->rq==q&&v->sx==x&&v->nnotes==n);assert(!memcmp(v->notes,expected,n));
   cr_screen_t screen;cr_build_screen(&screen,cu_now());char label[24];creative_chord_label(e,label,sizeof label);assert(label[0]);cases++;
  }
  creative_cancel_ideas();
 }
 assert(qmask&(1u<<CR_Q_MAJ));assert(qmask&(1u<<CR_Q_MIN));assert(qmask&(1u<<CR_Q_DIM));assert(qmask&(1u<<CR_Q_SUS));assert(xmask==15);assert(seen[CR_Q_SUS<<4|CR_EXT_M7|CR_EXT_9]);assert(seen[CR_Q_MIN<<4|CR_EXT_MAJ7]);assert(seen[CR_Q_DIM<<4]);
 /* Naming must match the actual seventh: DIM + minor seventh = half-diminished. */
 static const struct{uint8_t q,x;const char *name;} names[]={
 {CR_Q_MAJ,CR_EXT_6,"C6"},{CR_Q_MAJ,CR_EXT_MAJ7,"Cmaj7"},{CR_Q_MAJ,CR_EXT_MAJ7|CR_EXT_9,"Cmaj9"},{CR_Q_MAJ,CR_EXT_M7|CR_EXT_9,"C9"},{CR_Q_MAJ,CR_EXT_6|CR_EXT_9,"C6/9"},{CR_Q_MIN,CR_EXT_M7|CR_EXT_9,"Cm9"},{CR_Q_MIN,CR_EXT_MAJ7,"CmM7"},{CR_Q_DIM,CR_EXT_M7,"Cm7b5"},{CR_Q_SUS,CR_EXT_M7,"Csus7"}};
 for(unsigned i=0;i<NELEM(names);i++){crl_ev_t e={0};e.root=48;e.qx=names[i].q<<4|names[i].x;char name[24];creative_chord_label(&e,name,sizeof name);assert(!strcmp(name,names[i].name));}
 cu.page=PG_IDEAS;creative_ideas.pattern=6;creative_generate();cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(screen.n_items==4&&strlen(screen.item[0])<sizeof screen.item[0]);creative_knob(EN_SELECT,2);cr_build_screen(&screen,cu_now());assert(screen.sel==2);
 crl_data_t candidate=crl_stage;creative_accept();int32_t pcm[2*CTL];for(unsigned k=0;k<4;k++){cr_audio_block(CTL);for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);cr_snapshot();}assert(crl.d.nev==4&&crl.dirty&&!memcmp(crl.d.ev,candidate.ev,4*sizeof(crl_ev_t)));
 printf("PASS: jazz ideas %u actual chord/preview fixtures, full quality/extension coverage, independent intervals, exclusive sevenths, exact sequencer packing and chord names\n",cases);return 0;
}
