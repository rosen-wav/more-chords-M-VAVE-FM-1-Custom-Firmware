#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned bass_count(const cr_t *c){unsigned n=0;for(unsigned i=0;i<128;i++)n+=c->reg[CR_STREAM_BASS][i]!=0;return n;}
static int bass_pitch(const cr_t *c){for(int i=0;i<128;i++)if(c->reg[CR_STREAM_BASS][i])return i;return -1;}
static int expected(int note,int trans,int octave,unsigned mode){return mode==CR_BASS_UNISON?note+trans+12*octave:36+note%12+trans+12*octave;}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 static const unsigned order[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 unsigned cases=0;
 for(int root=24;root<=72;root++)for(int trans=-12;trans<=12;trans+=6)
 for(int oct=-2;oct<=4;oct++)for(unsigned mode=0;mode<4;mode++)for(unsigned ord=0;ord<6;ord++){
  cr_t c;cr_init(&c,0);cr_set_keys_only(&c,1);cr_set_bass(&c,1);cr_set_transpose(&c,trans);
  cr_set_bass_mode(&c,(cr_bassmode_t)mode);cr_bass_voicing_step(&c,oct);
  unsigned note[3]={(unsigned)root,(unsigned)root+3,(unsigned)root+8};
  for(unsigned k=0;k<3;k++){cr_key(&c,note[order[ord][k]],100,1);if(k<2)assert(!bass_count(&c));}
  int p=expected(root,trans,oct,mode);assert(bass_count(&c)==(unsigned)(p>=0&&p<=127));if(p>=0&&p<=127)assert(bass_pitch(&c)==p);
  for(unsigned k=0;k<3;k++)assert(c.reg[CR_STREAM_MAIN][note[k]+trans]==1);
  cr_key(&c,root-1,90,1);p=expected(root-1,trans,oct,mode);assert(bass_pitch(&c)==(p>=0&&p<=127?p:-1));
  cr_key(&c,root-1,0,0);p=expected(root,trans,oct,mode);assert(bass_pitch(&c)==(p>=0&&p<=127?p:-1));
  cr_key(&c,note[2],0,0);assert(!bass_count(&c));cr_key(&c,note[1],0,0);cr_key(&c,note[0],0,0);
  for(unsigned s=0;s<3;s++)for(unsigned n=0;n<128;n++)assert(!c.reg[s][n]);cases++;
 }
 cr_t c;cr_init(&c,0);cr_set_keys_only(&c,1);cr_set_bass(&c,1);
 cr_key_ex(&c,60,0,100,1);cr_key_ex(&c,60,1,100,1);cr_key(&c,64,100,1);assert(!bass_count(&c));
 cr_key(&c,67,100,1);assert(bass_pitch(&c)==36&&c.reg[CR_STREAM_BASS][36]==1);
 cr_key_ex(&c,60,0,0,0);assert(bass_pitch(&c)==36); /* second owner still holds C */
 cr_set_bass(&c,0);assert(!bass_count(&c));cr_set_bass(&c,1);assert(bass_pitch(&c)==36);
 cr_set_stream(&c,CR_STREAM_BASS,0);assert(!bass_count(&c));cr_set_stream(&c,CR_STREAM_BASS,1);assert(bass_pitch(&c)==36);
 cr_set_crystal_bass(&c,1);cr_bass_clock_phase(&c,1);assert(bass_pitch(&c)==48);cr_bass_clock_phase(&c,0);assert(bass_pitch(&c)==36);
 cr_bass_voicing_step(&c,-1);assert(bass_pitch(&c)==24);cr_set_crystal_bass(&c,0);
 crx_note_start(&c,CR_STREAM_BASS,24,100);assert(c.reg[CR_STREAM_BASS][24]==2);
 cr_key(&c,67,0,0);assert(c.reg[CR_STREAM_BASS][24]==1);crx_note_end(&c,CR_STREAM_BASS,24);assert(!bass_count(&c));
 cr_panic(&c);assert(!c.keys_bass.n&&!c.keys_bass.live&&!bass_count(&c));
 cr_key(&c,60,100,1);cr_key(&c,64,100,1);cr_key(&c,67,100,1);assert(bass_count(&c)==1);
 cr_panic(&c);assert(!c.keys_bass.n&&!c.keys_bass.live&&!bass_count(&c));
 cr_key(&c,60,100,1);cr_key(&c,64,100,1);cr_key(&c,67,100,1);assert(bass_count(&c)==1);
 cr_set_keys_only(&c,0);assert(!bass_count(&c)&&!c.keys_bass.n);
 /* Real queued keys reach the selected BASS synth, not a generated chord. */
 cr_panic(&cr);opt_set(O_KEYS_ONLY,1);cr_audio_block(CTL);cu_load(&trk[1],ENGI_BASS,2,1);engine_block(&trk[1]);panic_req=0;
 trk[1].p[P_TRANS]=0;cr.bass_voicing=0;cr_set_bass_mode(&cr,CR_BASS_CHORDS_ONLY);cr_set_crystal_bass(&cr,0);
 assert(cr_post(CRE_BASS,0,0,1));
 assert(cr_post(CRE_KEY,53,100,1));assert(cr_post(CRE_KEY,57,100,1));assert(cr_post(CRE_KEY,60,100,1));cr_audio_block(CTL);
 assert(bass_pitch(&cr)==41&&trk[1].engine==ENGI_BASS&&trk[1].preset==2);
 unsigned sounding=0;for(unsigned i=0;i<NVOICE;i++)sounding+=trk[1].v[i].active&&trk[1].v[i].gate&&trk[1].v[i].note==41;assert(sounding==1);
 assert(cr_post(CRE_KEY,60,0,0));cr_audio_block(CTL);assert(!bass_count(&cr));
 printf("PASS: keys-only BASS %u root/order/register/transpose/mode fixtures; threshold, ownership, clock, panic and actual selected synth\n",cases);
}
