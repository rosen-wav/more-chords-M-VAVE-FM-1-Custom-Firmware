/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned count(const cr_t *c){unsigned n=0;for(unsigned i=0;i<128;i++)n+=c->reg[CR_STREAM_BASS][i]!=0;return n;}
static int pitch(const cr_t *c){for(int i=0;i<128;i++)if(c->reg[CR_STREAM_BASS][i])return i;return -1;}
static void three(cr_t *c){for(unsigned k=0;k<3;k++)assert(cr_loop_event(c,k,60+(k==1?4:k==2?7:0),CR_Q_NONE,0,100,1));}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);unsigned cases=0;
 static const unsigned order[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 for(unsigned keyboard=0;keyboard<2;keyboard++)
 for(int root=24;root<=84;root+=12)for(int trans=-12;trans<=12;trans+=6)
 for(int oct=-2;oct<=4;oct++)for(unsigned mode=0;mode<4;mode++)for(unsigned ord=0;ord<6;ord++){
  cr_t c;cr_init(&c,0);cr_set_keys_only(&c,(int)keyboard);cr_set_bass(&c,1);cr_set_loop_transpose(&c,trans);
  cr_set_bass_mode(&c,(cr_bassmode_t)mode);cr_bass_voicing_step(&c,oct);
  unsigned note[3]={(unsigned)root,(unsigned)root+3,(unsigned)root+8};
  for(unsigned k=0;k<3;k++){assert(cr_loop_event(&c,(int)k,(int16_t)note[order[ord][k]],CR_Q_NONE,0,100,1));if(k<2)assert(!count(&c));}
  int p=(mode==CR_BASS_UNISON?root+trans:36+root%12+trans)+12*oct;
  assert(count(&c)==(unsigned)(p>=0&&p<=127));if(p>=0&&p<=127)assert(pitch(&c)==p);
  for(unsigned k=0;k<3;k++)assert(c.reg[CR_STREAM_MAIN][note[k]+trans]==1);
  for(unsigned k=0;k<3;k++)cr_loop_event(&c,(int)k,0,0,0,0,0);
  assert(!count(&c)&&!c.loop_keys_bass.n);cases++;
 }
 /* Separate thresholds and refcounts for loop and live chords. */
 cr_t c;cr_init(&c,0);cr_set_keys_only(&c,1);cr_set_bass(&c,1);
 cr_loop_event(&c,0,60,0,0,100,1);cr_loop_event(&c,1,64,0,0,100,1);cr_key(&c,67,100,1);assert(!count(&c));
 cr_loop_event(&c,2,67,0,0,100,1);assert(c.reg[CR_STREAM_BASS][36]==1);
 cr_key(&c,60,100,1);assert(c.reg[CR_STREAM_BASS][36]==1);cr_key(&c,64,100,1);assert(c.reg[CR_STREAM_BASS][36]==2);
 cr_loop_event(&c,2,0,0,0,0,0);assert(c.reg[CR_STREAM_BASS][36]==1);cr_key(&c,67,0,0);assert(!count(&c));cr_panic(&c);
 /* Duplicate notes and preview owners do not create an extra bass. */
 cr_loop_event(&c,0,60,0,0,100,1);cr_loop_event(&c,1,60,0,0,100,1);cr_loop_event(&c,2,64,0,0,100,1);
 assert(!count(&c));assert(cr_preview_add(&c,67,0,0,100));cr_bass_clock_phase(&c,0);assert(!count(&c));cr_preview_clear(&c);
 cr_loop_event(&c,3,67,0,0,100,1);assert(pitch(&c)==36);cr_panic(&c);assert(!c.loop_keys_bass.n&&!count(&c));
 three(&c);cr_set_loop_transpose(&c,7);assert(pitch(&c)==43);cr_set_loop_transpose(&c,-12);assert(pitch(&c)==24);
 cr_set_crystal_bass(&c,1);cr_bass_clock_phase(&c,1);assert(pitch(&c)==36);cr_bass_clock_phase(&c,0);assert(pitch(&c)==24);
 cr_set_stream(&c,CR_STREAM_BASS,0);assert(!count(&c));cr_set_stream(&c,CR_STREAM_BASS,1);assert(pitch(&c)==24);
 cr_set_bass(&c,0);assert(!count(&c));cr_set_bass(&c,1);assert(pitch(&c)==24);
 cr_bass_voicing_step(&c,-1);assert(pitch(&c)==12);cr_set_keys_only(&c,0);assert(pitch(&c)==12&&c.loop_keys_bass.n);
 /* A live/loop shared pitch releases only the live owner on a keyboard-mode change. */
 cr_panic(&c);cr_set_keys_only(&c,1);c.loop_transpose=0;c.bass_voicing=0;cr_set_crystal_bass(&c,0);
 three(&c);cr_key(&c,60,100,1);cr_key(&c,64,100,1);cr_key(&c,67,100,1);assert(c.reg[CR_STREAM_BASS][36]==2);
 cr_set_keys_only(&c,0);assert(c.reg[CR_STREAM_BASS][36]==1&&c.loop_keys_bass.n&&!c.keys_bass.n);
 for(unsigned k=0;k<3;k++)assert(c.reg[CR_STREAM_MAIN][60+(k==1?4:k==2?7:0)]==1);
 cr_voicing_step(&c,2);for(unsigned k=0;k<3;k++)assert(c.reg[CR_STREAM_MAIN][60+(k==1?4:k==2?7:0)]==1);
 cr_set_keys_only(&c,1);assert(pitch(&c)==36);cr_panic(&c);assert(!count(&c));
 /* Stored generated chords keep their bass too, in both keyboard modes. */
 cr_set_keys_only(&c,0);assert(cr_loop_event(&c,0,60,CR_Q_MAJ,0,100,1));assert(pitch(&c)==36);
 cr_set_keys_only(&c,1);assert(pitch(&c)==36);assert(cr_loop_event(&c,0,62,CR_Q_MIN,0,100,1));assert(pitch(&c)==38);
 cr_loop_event(&c,0,0,0,0,0,0);assert(!count(&c));cr_panic(&c);
 /* Actual Step capture, slot20 save/load, selected synth and scheduled release. */
 cr_panic(&cr);cr_loop_clear(&crl,&cr);cr_set_keys_only(&cr,1);cs.keys_only=1;
 cr_set_bass(&cr,1);cr_set_bass_mode(&cr,CR_BASS_CHORDS_ONLY);cr_set_crystal_bass(&cr,0);cr.bass_voicing=0;cr.loop_transpose=0;
 cu_pool_load(1,ENGI_BASS,pool_pos_factory(ENGI_BASS,2));engine_block(&trk[1]);cr_audio_block(CTL);panic_req=0;
 for(unsigned k=0;k<3;k++)cr_key(&cr,60+(k==1?4:k==2?7:0),100,1);
 crl.sync=2;assert(cr_loop_grid_edit(&crl,&cr,0,-1)>0&&crl.d.nev==3);
 for(unsigned k=0;k<3;k++)cr_key(&cr,60+(k==1?4:k==2?7:0),0,0);assert(!count(&cr));
 cr_snapshot();assert(cu_loop_save_now(19));crl_data_t saved=crl.d;cr_loop_clear(&crl,&cr);cu_loop_load(19);cr_audio_block(CTL);
 assert(!memcmp(saved.ev,crl.d.ev,saved.nev*sizeof(crl_ev_t))&&crl.d.nev==3);
 cr_set_keys_only(&cr,0);cs.keys_only=0; /* Slot20 raw notes keep their Bass after switching the keyboard back. */
 assert(cr_post(CRE_LOOP,LP_PLAY,0,0));cr_audio_block(CTL);for(unsigned i=0;crl.play_armed==1u&&i<5000u;i++)cr_audio_block(CTL);for(unsigned i=0;i<32;i++)cr_audio_block(CTL);assert(pitch(&cr)==36&&trk[1].engine==ENGI_BASS&&trk[1].preset==2);
 unsigned sounding=0;for(unsigned i=0;i<NVOICE;i++)sounding+=trk[1].v[i].active&&trk[1].v[i].gate&&trk[1].v[i].note==36;assert(sounding==1);
 opt_set(O_KEYS_ONLY,1);cr_audio_block(CTL);assert(pitch(&cr)==36&&cr.loop_keys_bass.n);
 opt_set(O_KEYS_ONLY,0);cr_audio_block(CTL);assert(pitch(&cr)==36&&cr.loop_keys_bass.n);
 cr_set_loop_transpose(&cr,7);assert(pitch(&cr)==43);assert(!memcmp(saved.ev,crl.d.ev,saved.nev*sizeof(crl_ev_t)));
 assert(cr_post(CRE_LOOP,LP_PLAY,0,0));cr_audio_block(CTL);assert(!count(&cr));
 cr_set_loop_transpose(&cr,0);assert(cr_post(CRE_LOOP,LP_PLAY,0,0));cr_audio_block(CTL);for(unsigned i=0;crl.play_armed==1u&&i<5000u;i++)cr_audio_block(CTL);for(unsigned i=0;i<32;i++)cr_audio_block(CTL);assert(pitch(&cr)==36);
 for(unsigned i=0;i<2u*FS*60u/(cr.bpm*CTL);i++)cr_audio_block(CTL);assert(!count(&cr)); /* quarter-note gate expired; cycle not wrapped */
 assert(cr_post(CRE_LOOP,LP_CLEAR,0,0));cr_audio_block(CTL);assert(!count(&cr)&&!cr.loop_keys_bass.n);
 printf("PASS: just-keys loop Bass %u pitch/order/mode/transpose fixtures; separate live/loop owners, duplicates, preview exclusion, clock, stream, panic, actual Step/slot20 restore/selected BASS synth/stop/scheduled release; three recorded notes, no extra loop event\n",cases);
}
