#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void) {
 emu_fw_options(0,1,0,1); emu_fw_init(0);
 cr_settings_t st, loaded; cr_t c;
 opt_set(O_KEYS_ONLY,1); cr_audio_block(CTL); assert(cs.keys_only && cr.keys_only);
 assert(O_KEYS_ONLY == O_STYLE+1 && O_EXTADD == O_KEYS_ONLY+1);
 cu.opt_open=0; cu.lock=L_NONE; cu.page=PG_NONE;
 for(unsigned k=0;k<CU_NKEY;k++) {
  cu_key_press(k); cr_audio_block(CTL); unsigned note=53+k;
  assert(cr.reg[CR_STREAM_MAIN][note] && !cu.clock);
  cu_key_release(k); cr_audio_block(CTL); assert(!cr.reg[CR_STREAM_MAIN][note]);
 }
 char label[40]; opt_text(O_KEYS_ONLY,label,sizeof label); assert(!strcmp(label,"On"));
 for(unsigned style=0;style<3;style++) for(unsigned note=24;note<=100;note++) {
  cr_init(&c,0); cr_set_playstyle(&c,(cr_playstyle_t)style);
  cr_set_bass(&c,1); cr_set_bass_mode(&c,CR_BASS_SOLO); cr_set_perform(&c,1); cr_set_sticky(&c,1);
  cr_mod(&c,CR_MOD_MAJ,1); cr_mod(&c,CR_MOD_M7,1); cr_voicing_step(&c,5); cr_set_swag(&c,3);
  cr_set_keys_only(&c,1); cr_mod(&c,CR_MOD_MIN,1); cr_mod(&c,CR_MOD_MAJ7,1);
  assert(!c.mods_down); cr_key(&c,note,100,1);
  assert(c.reg[CR_STREAM_MAIN][note]==1 && !c.nev);
  assert(c.v[0].nnotes==1 && c.v[0].notes[0]==note && !c.v[0].bass.live && !c.v[0].voicing);
  cr_voicing_step(&c,1); assert(c.v[0].notes[0]==note);
  cr_key(&c,note,0,0); assert(!c.reg[CR_STREAM_MAIN][note]);
 }
 cr_init(&c,0); cr_mod(&c,CR_MOD_MAJ,1); cr_key(&c,60,100,1);
 cr_set_keys_only(&c,1); assert(!c.nev && !c.phys_n);
 for(unsigned i=0;i<128;i++) assert(!c.reg[CR_STREAM_MAIN][i]);
 cr_key(&c,60,0,0); cr_key(&c,60,100,1); cr_key(&c,64,100,1); assert(c.reg[0][60] && c.reg[0][64]);
 cr_set_keys_only(&c,0); assert(!c.reg[0][60] && !c.reg[0][64]);
 cr_mod(&c,CR_MOD_MIN,1); cr_key(&c,60,100,1); assert(c.v[0].nnotes==3);
 cr_settings_defaults(&st); st.key_on=1; cr_settings_seal(&st);
 assert(cr_settings_import(&loaded,&st,sizeof st)==1 && loaded.key_on);
 cr_init(&c,0); cr_settings_apply(&loaded,&c,0); assert(c.keys_only);
 cr_settings_capture(&loaded,&c,0); assert(loaded.key_on);
 st.key_on=1; cr_settings_seal(&st); st.version=6;
 assert(cr_settings_import(&loaded,&st,sizeof st)==2 && !loaded.key_on);
 cr_settings_seal(&st); st.version=1; assert(cr_settings_import(&loaded,&st,sizeof st)==2 && !loaded.key_on);
 opt_set(O_KEYS_ONLY,0); cr_audio_block(CTL); assert(!cs.keys_only && !cr.keys_only);
 puts("PASS: keys-only 231 key/style fixtures, ordinary note ownership, release, BASS/performance/latch/voicing bypass, mode-switch cleanup, v7 persistence and old-settings migration");
 return 0;
}
