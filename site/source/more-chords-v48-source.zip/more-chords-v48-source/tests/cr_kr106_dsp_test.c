/* Standalone native DSP: no legacy Remix arithmetic in this sanitizer check. */
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include "../firmware/src/fm106_osc.h"
#include "../firmware/src/fm106_vcf.h"
#include "../firmware/src/fm106_adsr.h"
#include "../firmware/src/fm106_chorus.h"
static void cached_filter_test(void){
 fm106_vcf_t a,b;fm106_vcf_init(&a);fm106_vcf_init(&b);a.noise_seed=b.noise_seed=12345;
 for(unsigned setting=0;setting<128;setting++)for(unsigned i=0;i<512;i++){
  b.coef_valid=0; /* reference: recompute coefficients every sample */
  if(i==0)a.coef_valid=0;
  int32_t in=(int32_t)((i*977u)%24000)-12000;
  assert(fm106_vcf_process(&a,in,setting*129u,setting)==fm106_vcf_process(&b,in,setting*129u,setting));
 }
 puts("PASS: cached VCF exact against full coefficient recomputation at 128 static cutoff/resonance settings");
}
int main(void){cached_filter_test();fm106_dco_t d;fm106_vcf_t f;fm106_adsr_t e;fm106_hpf_t h;static fm106_chorus_t c;int64_t dc=0;uint64_t energy=0;
 fm106_dco_init(&d,0);fm106_vcf_init(&f);fm106_adsr_init(&e);fm106_hpf_init(&h);fm106_chorus_init(&c);
 for(unsigned k=0;k<512000;k++){
  unsigned phase=k/1000;
  if(k%1000==0){fm106_adsr_params(&e,phase%128,(phase*7)%128,(phase*13)%128,0);fm106_adsr_gate_on(&e);d.saw_on=phase&1;d.pulse_on=1;d.sub_on=1;d.sub_level=(phase*19)%128;d.noise_level=(phase*31)%128;c.mode=phase%4;h.mode=(phase/4)%4;}
  if(k%1000==750)fm106_adsr_gate_off(&e);
  int32_t env=fm106_adsr_process(&e);uint32_t note=phase%128,inc=FM106_INC_C9[note%12]>>(10-note/12);
  int32_t a=fm106_dco_process(&d,inc,phase%128,phase%2,(int32_t)(k%65536)-32768,env);
  int32_t b=fm106_vcf_process(&f,a,(uint16_t)((phase*129)%16384),phase%128);b=fm106_dc_block(b,&dc);b=fm106_hpf_process(&h,b/16);int32_t l,r;fm106_chorus_process(&c,b,&l,&r);energy+=(uint64_t)(l<0?-(int64_t)l:l);assert(env>=0&&env<=32766);
 }
 assert(energy);puts("PASS: KR106 native DSP 512000 stress samples under UBSan, all pitches, ADSR/PWM/resonance/HPF/chorus modes");return 0;
}
