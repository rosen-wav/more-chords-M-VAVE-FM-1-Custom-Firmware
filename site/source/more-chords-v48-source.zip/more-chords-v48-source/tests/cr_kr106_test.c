/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static unsigned active(void){unsigned n=0;for(unsigned i=0;i<NVOICE;i++)n+=trk[0].v[i].active&&trk[0].v[i].gate&&trk[0].v[i].stage!=4;return n;}
int main(void){pthread_t th;int32_t pcm[2*CTL];unsigned cases=0;uint64_t energy=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);assert(eng_ok(ENGI_KR106));assert(ENGINE_ORDER[0]==ENGI_PROPHET&&ENGINE_ORDER[1]==ENGI_KR106);assert(ENGINES[ENGI_KR106]->npresets==129);
 for(unsigned i=0;i<NELEM(MORPH_SOURCE);i++)assert(MORPH_SOURCE[i]!=ENGI_KR106);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 printf("sizes: shared engine state %zu B; KR106 part %zu B; native patches %zu B\n",sizeof eng_state,sizeof(kr106_part_t),sizeof kr106_patch);
 for(unsigned p=0;p<129;p++){
  for(unsigned b=0;b<3;b++){
   unsigned bass=b==0?ENGI_BASS:b==1?ENGI_PROPHET:ENGI_KR106;
   cr_c1_test_serial=1;setup(ENGI_KR106,p,bass,0,6,0);assert(active()==6);
   for(unsigned k=0;k<128;k++)block(k,reference[k]);
   memcpy(states,eng_state,sizeof states);for(unsigned t=0;t<NPART;t++)memcpy(voices[t],trk[t].v,sizeof voices[t]);
   cr_c1_test_serial=0;setup(ENGI_KR106,p,bass,0,6,0);assert(active()==6);
   uint64_t e=0;for(unsigned k=0;k<128;k++){block(k,pcm);if(k==0)assert(c1_chord_count==2);assert(!memcmp(pcm,reference[k],sizeof pcm));for(unsigned j=0;j<2*CTL;j++){e+=(uint64_t)llabs(pcm[j]);assert(pcm[j]>=-32768&&pcm[j]<=32767);}}
   assert(!memcmp(states,eng_state,sizeof states));for(unsigned t=0;t<NPART;t++)assert(!memcmp(voices[t],trk[t].v,sizeof voices[t]));assert(c1_chord_count<=2);energy+=e;cases++;
  }
 }
 assert(energy>0);
 for(unsigned quality=0;quality<2;quality++)for(int rot=-3;rot<=5;rot++){
  clear(ENGI_KR106,1,0);cu_load(&trk[0],ENGI_KR106,1,0);engine_block(&trk[0]);panic_req=0;
  cr_mod(&cr,quality?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);cr.voicing=rot;cr_key(&cr,60,100,1);settle();assert(active()==6);assert(third_present());assert(voices_busy_of(&trk[0])<=VBUDGET);assert(voices_busy_of(&trk[1])<=VBUDGET);cases++;
 }
 /* KR106 Bass must also be independent when chords use CZ or Prophet. */
 for(unsigned e=0;e<2;e++)for(unsigned preset=1;preset<=128;preset+=8){
  unsigned chord=e?ENGI_PROPHET:ENGI_CZ;
  cr_c1_test_serial=1;setup(chord,1,ENGI_KR106,preset,6,0);for(unsigned k=0;k<128;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);
  cr_c1_test_serial=0;setup(chord,1,ENGI_KR106,preset,6,0);for(unsigned k=0;k<128;k++){block(k,pcm);assert(!memcmp(pcm,reference[k],sizeof pcm));}assert(!memcmp(states,eng_state,sizeof states));cases++;
 }

 /* Six-page edit/blob round-trip and native USER save/overwrite/reboot paths. */
 for(unsigned part=0;part<2;part++)for(unsigned preset=0;preset<129;preset+=8){
  track_t *t=&trk[part];cu_load(t,ENGI_KR106,preset,part);engine_block(t);
  for(unsigned pg=0;pg<6;pg++)for(unsigned col=0;col<4;col++)kr106_set(t,pg,col,KR106_PAGES[pg].col[col].max/2);
  uint8_t expected[36],actual[36];kr106_blob_get(t,expected);assert(cb_store(t,0,31,"KR SAVE",0)==0);assert(up_valid(up_rec(31)));
  memset(kr106_patch_of(t),0,36);cu_load_user(t,31,part);engine_block(t);kr106_blob_get(t,actual);assert(!memcmp(expected,actual,36));
  kr106_set(t,2,0,37);kr106_blob_get(t,expected);assert(cb_store(t,0,31,"KR OVERWRITE",0)==0);memset(kr106_ready,0,sizeof kr106_ready);memset(eng_state,0,sizeof eng_state);cu_load_user(t,31,part);engine_block(t);kr106_blob_get(t,actual);assert(!memcmp(expected,actual,36));cases++;
 }
 cu_load(&trk[0],ENGI_KR106,1,0);engine_block(&trk[0]);ce_open(0);
 for(unsigned pg=0;pg<6;pg++){unsigned grp=KR106_SCREENS[pg].sec;cx.grp[0]=grp;cx.scr[0][grp]=(pg==1||pg==3)?1:0;cx.lane[0][grp]=0;kr106_set(&trk[0],pg,0,0);cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(strstr(screen.page,"KR106"));if(pg<2)assert(screen.wide==CR_W_KR106);if(pg==4)assert(screen.wv[3]>0);ce_knob(0,1,0);assert(kr106_get(&trk[0],pg,0)>0);}
 ce_close();
 uint8_t invalid[36];kr106_blob_get(&trk[0],invalid);invalid[29]=127;assert(!kr106_blob_apply(&trk[0],invalid));
 cr_dbg.c1=C1_FAILED;audio_worker_online=0;assert(kr106_cap(&trk[0])==5);assert(kr106_cap(&trk[1])==1);
 pthread_cancel(th);pthread_join(th,0);
 printf("PASS: KR106 %u factory/CPU1/native USER fixtures; serial/concurrent PCM and state exact, six voices with Bass, Morph exclusion, complete overwrite/reload, malformed blob and offline caps\n",cases);
 return 0;
}
