/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#define CR_BACKUP_TEST_HELPERS_ONLY
#include "cr_backup_test.c"
static uint8_t preserved[EMU_FLASH_SIZE];
static uint8_t record[CRL_SLOTS][CRL_REC_MAX];
static unsigned sizes[CRL_SLOTS];
int main(void){
 emu_flash_open();memset(emu_flash,0xFF,sizeof emu_flash);cr_bank_boot();cr_settings_boot();cr_ui_init();usb.config=1;
 unsigned ncheck=0;assert(CRL_SLOTS==30&&CRL_REC_MAX==3792&&sizeof(cr_settings_t)==192);
 /* Every A/B pair is unique, old pairs keep their exact addresses, and no
  * sector can enter patches/settings/app/stub/update/loader/calibration. */
 for(unsigned k=0;k<30;k++)for(unsigned copy=0;copy<2;copy++){
  uint32_t address=crl_fl_sector(k,copy);
  assert(address==(k<10?0xC8000u+(2*k+copy)*4096u:k<20?0xB4000u+(2*(k-10)+copy)*4096u:0xE5000u+(2*(k-20)+copy)*4096u));
  assert((address>=0xB4000u&&address+4096u<=0xDC000u)||(address>=0xE5000u&&address+4096u<=0xF9000u));
  for(unsigned j=0;j<k;j++)for(unsigned q=0;q<2;q++)assert(address!=crl_fl_sector(j,q));ncheck++;
 }
 memcpy(preserved,emu_flash,sizeof preserved);
 for(unsigned k=0;k<30;k++){
  sizes[k]=make_loop(k,1+k);assert(sizes[k]>0);assert(crl_fl_load(k,record[k])==(int)sizes[k]);
  crl_data_t d;assert(cr_loop_unpack(record[k],sizes[k],&d)&&d.nev==k+1);ncheck++;
 }
 for(unsigned i=0;i<EMU_FLASH_SIZE;i++)if(!((i>=0xB4000u&&i<0xDC000u)||(i>=0xE5000u&&i<0xF9000u)))assert(emu_flash[i]==preserved[i]);ncheck++;
 power_on();assert(cs.loop_used==((1u<<30)-1u));assert(t_capture()==0&&nman==48);ncheck++;
 for(unsigned k=0;k<30;k++){
  obj_t *o=find(man,nman,40+k);assert(o&&o->size==sizes[k]&&!memcmp(o->bytes,record[k],sizes[k]));ncheck++;
 }
 /* All 30 objects restore through the actual SysEx writer, then reload. */
 for(unsigned k=0;k<30;k++)assert(crl_fl_delete(k)==0);
 cu_loop_scan();assert(!cs.loop_used);
 for(unsigned k=0;k<30;k++){assert(t_put(40+k,record[k],sizes[k])==0);ncheck++;}
 power_on();assert(cs.loop_used==((1u<<30)-1u));
 for(unsigned k=0;k<30;k++){assert(crl_fl_load(k,cu_loop_buf)==(int)sizes[k]&&!memcmp(cu_loop_buf,record[k],sizes[k]));ncheck++;}
 /* A CRC-invalid newest commit falls back to the previous A/B record. */
 assert(crl_fl_save(29,record[29],sizes[29])==0);st_hdr_t h;int copy=crl_fl_current(29,&h,cu_loop_buf);assert(copy==1);
 emu_flash[crl_fl_sector(29,1)+ST_PAYLOAD_OFF]^=1;assert(crl_fl_load(29,cu_loop_buf)==(int)sizes[29]&&!memcmp(cu_loop_buf,record[29],sizes[29]));ncheck++;
 memcpy(preserved,emu_flash,sizeof preserved);assert(crl_fl_save(30,record[0],sizes[0])<0&&crl_fl_delete(30)<0);
 assert(!memcmp(preserved,emu_flash,sizeof preserved));ncheck++;
 /* UI bank switching is only on the last keyboard key in slot menus. */
 cu.lock=L_LOOP;cu.loop_bank=0;cr_snapshot();
 for(unsigned phase=0;phase<2;phase++){fm1_ms=phase*250u;cr_leds();unsigned led=cu_led_pos[14u+CU_NKEY-1u];assert(!(fm1_led[led>>3]&(1u<<(led&7)))&&!(fm1_led_dim[led>>3]&(1u<<(led&7))));}
 cu_layer_key(L_LOOP,CU_NKEY-1);assert(cu.loop_bank==1);cu.lock=L_SAVE;
 cs.loop_target=0;cu_layer_key(L_SAVE,cu_white_key(9));assert(cs.loop_target==19);
 cu_layer_key(L_SAVE,CU_NKEY-1);assert(cu.loop_bank==2&&cs.loop_target==29);
 for(unsigned phase=0;phase<2;phase++){fm1_ms=phase*250u;cr_snapshot();cr_leds();unsigned led=cu_led_pos[14u+CU_NKEY-1u];assert(fm1_led[led>>3]&(1u<<(led&7)));assert(!(fm1_led_dim[led>>3]&(1u<<(led&7))));}
 cu_layer_key(L_SAVE,CU_NKEY-1);assert(!cu.loop_bank&&cs.loop_target==9);ncheck++;
 cu_layer_key(L_SAVE,CU_NKEY-1);fm1_ms=0;cr_snapshot();cr_leds();unsigned q=cu_led_pos[14u+CU_NKEY-1u];assert(q!=255);
 assert(fm1_led[q>>3]&(1u<<(q&7)));fm1_ms=250;cr_leds();assert(!(fm1_led[q>>3]&(1u<<(q&7))));cs.leds=1;cr_leds();assert(!(fm1_led[q>>3]&(1u<<(q&7))));cs.leds=0;ncheck++;
 /* Slot20 survives settings import; a former 16-bar setting becomes 8. */
 cr_settings_t s;cr_settings_defaults(&s);s.loop_slot=29;s.loop_sync=5;cr_settings_seal(&s);
 assert(cr_settings_import(&s,&s,sizeof s)&&s.loop_slot==29&&s.loop_sync==4);ncheck++;
 /* Actual held SAVE > Delete > OCT+ also clears the currently loaded RAM copy. */
 for(unsigned target=0;target<30;target+=29){
  assert(cr_loop_unpack(record[target],sizes[target],&crl_stage));cr_loop_set(&crl,&cr,&crl_stage);cs.loop_slot=(uint8_t)target;cr_snapshot();
  cs.save_pending=1;cu_advance_pending=1;cu.loop_bank=(uint8_t)(target/10u);cu.lock=L_NONE;cu.page=PG_NONE;
  cu_btn_press(BT_SAVE);cu_opened(BT_SAVE);cu.open=1;cs.loop_target=(uint8_t)target;cu_layer_pick(L_SAVE,2);
  cu_btn_press(B_OCTUP);cu_btn_release(B_OCTUP);cu_btn_release(BT_SAVE);cr_audio_block(CTL);cr_snapshot();
  assert(crl.state==CRL_EMPTY&&!crl.d.nev&&!crl.d.len&&!crl.d.grid_n&&!(cs.loop_used&(1u<<target))&&!cs.save_pending&&!cu_advance_pending);
  assert(crl_fl_load(target,cu_loop_buf)<0);cu_loop_frame();assert(crl_fl_load(target,cu_loop_buf)<0);ncheck++;
 }
 /* Deleting another slot leaves the loaded events intact, and failures change no data. */
 assert(cr_loop_unpack(record[1],sizes[1],&crl_stage));cr_loop_set(&crl,&cr,&crl_stage);cs.loop_slot=1;cr_snapshot();crl_data_t loaded=crl.d;
 cu_loop_delete(2);cr_audio_block(CTL);assert(!memcmp(&loaded,&crl.d,crl_data_size(loaded.nev))&&crl_fl_load(2,cu_loop_buf)<0);ncheck++;
 memcpy(preserved,emu_flash,sizeof preserved);crl.state=CRL_PLAYING;cr_snapshot();cu_loop_delete(1);
 assert(!memcmp(preserved,emu_flash,sizeof preserved)&&crl.d.nev==loaded.nev);crl.state=CRL_STOPPED;cr_snapshot();ncheck++;
 /* Queue pressure, a pending load or flash failure must not erase a loaded slot. */
 while(cr_post(CRE_LOOP,LP_CONF,LC_VOL,70));cu_loop_delete(1);
 assert(!memcmp(preserved,emu_flash,sizeof preserved)&&crl.d.nev==loaded.nev);cr_audio_block(CTL);ncheck++;
 crl_stage_busy=1;cu_loop_delete(1);crl_stage_busy=0;assert(!memcmp(preserved,emu_flash,sizeof preserved));ncheck++;
 flash_ok=0;cu_loop_delete(1);flash_ok=1;assert(!memcmp(preserved,emu_flash,sizeof preserved)&&crl.d.nev==loaded.nev);ncheck++;
 power_on();assert(!(cs.loop_used&((1u<<0)|(1u<<2)|(1u<<29)))&&(cs.loop_used&(1u<<1)));ncheck++;
 printf("PASS: 30-loop storage %u checks; old addresses unchanged, all pairs disjoint/in data-only regions, outside bytes unchanged, 30 saves/reboot/GET/PUT, high slot bits, CRC fallback, invalid-slot no-write, keyboard bank switch/blink, slot30 settings and 16->8-bar migration, held SAVE/Delete loaded RAM clear and reboot, other-slot preservation, playing refusal\n",ncheck);
}
