/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void drain(void){cr_audio_block(CTL);cr_snapshot();}
int main(void){cr_screen_t sc;crl_data_t saved;uint8_t buf[CRL_REC_MAX];unsigned checks=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);drain();cu.page=PG_NONE;cu.lock=L_LOOP;cu.opt_open=0;
 for(unsigned m=0;m<CRL_NMODE;m++){
  cr_loop_clear(&crl,&cr);crl.cap=CRL_CAP_NONE;cr_snapshot();cs.loop_mode=0;
  cu_knob(EN_ALGO,m);drain();assert(cs.loop_mode==m && crl.mode==m);
  cr_build_screen(&sc,cu_now());assert(!strcmp(sc.label,CU_LOOP_MODE[m]));checks++;
 }
 /* Step: playable roots in the menu; modifier changes must not advance. */
 cr_loop_clear(&crl,&cr);crl.sync=0;crl.quant=4;cs.loop_mode=CRL_MODE_STEP;crl.mode=CRL_MODE_STEP;
 cu_tap(BT_REC);drain();assert(crl.cap==CRL_CAP_STEP);assert(!cu_layer_keys(L_LOOP));
 cu_key_press(CU_ROOT0);drain();assert(crl.step==0);
 cu_mod_press(5);drain();assert(crl.step==0);cu_mod_release(5);drain();assert(crl.step==0);
 cu_key_release(CU_ROOT0);drain();assert(crl.step==1 && crl.d.nev>0);
 cu_oct_tap(B_OCTUP);drain();assert(crl.step==2);cu_oct_tap(B_OCTDN);drain();assert(crl.step==1);
 cu_knob(EN_ALGO,-1);drain();assert(cs.loop_mode==CRL_MODE_STEP);
 cu_tap(BT_REC);drain();assert(crl.cap==CRL_CAP_NONE && crl.d.len>0);checks+=7;
 /* Transpose and sidechain keep the existing SEQ knobs. */
 cu.lock=L_METRO;cu_knob(EN_K3,1);drain();assert(cs.sidechain&&cr_sidechain_on);
 cu_knob(EN_K4,12);drain();assert(cs.loop_transpose==12 && cr.loop_transpose==12);checks+=2;
 /* Internal tempo clamps and external ownership. */
 cr_route.clock_in=0;cu_set_tempo(120);drain();cu_knob(EN_K2,1);drain();assert(cs.bpm==121 && cr.bpm==121);
 cu_knob(EN_K2,1000);drain();assert(cs.bpm==300 && cr.bpm==300);
 cu_knob(EN_K2,-1000);drain();assert(cs.bpm==20 && cr.bpm==20);
 cr_route.clock_in=1;cu_knob(EN_K2,10);drain();assert(cs.bpm==20 && cr.bpm==20);
 cr_in_bpm=137;cr_in_bpm_n++;cu_midi_poll();cr_build_screen(&sc,cu_now());
 assert(cs.bpm==137 && !strcmp(sc.cell[0][1].value,"137") && !strcmp(sc.cell[0][1].label,"BPM MIDI"));
 assert(sc.cell[0][1].flags & CR_CF_DIM);cr_route.clock_in=0;checks+=5;
 /* Advance saves current slot then wraps 20 -> 1 and arms a new take. */
 cu.lock=L_LOOP;cr_loop_stop(&crl,&cr);cr_snapshot();cs.loop_slot=19;cs.loop_mode=CRL_MODE_ADVANCE;crl.mode=CRL_MODE_ADVANCE;
 cu_loop_rec();assert(cu_advance_pending);cu_loop_frame();drain();
 assert(!cu_advance_pending && cs.loop_slot==0 && crl.cap==CRL_CAP_ARMED);
 int n=crl_fl_load(19,buf);assert(n>0 && cr_loop_unpack(buf,n,&saved));assert(saved.nev>0);checks+=3;
 /* Failed save: retain the loop and slot, do not arm another take. */
 cr_loop_set(&crl,&cr,&saved);cr_snapshot();cs.loop_slot=2;flash_ok=0;
 cu_loop_rec();cu_loop_frame();drain();assert(cs.loop_slot==2 && crl.cap==CRL_CAP_NONE && crl.d.nev==saved.nev);flash_ok=1;checks++;
 cr_safe=1;cu_loop_rec();assert(!cu_advance_pending);cr_safe=0;checks++;
 printf("Looper UI: %u checks PASS; five modes, Step roots/rest/back, Advance save/wrap/failure, SEQ BPM clamps/external clock, sidechain/transpose\n",checks);return 0;
}
