/* Real UI, loop scheduler and note ownership, no device access. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static void no_notes(cr_t *c) {unsigned s,n;for(s=0;s<CR_NSTREAM;s++)for(n=0;n<128;n++)assert(!c->reg[s][n]);assert(!cr_pending(c));}
int main(void) {
 cr_t c;cr_loop_t lp;crl_ev_t ev={0,96,60,100,CR_Q_MAJ<<4,0};cr_screen_t screen;unsigned i,s,n,mode;int tp;
 const unsigned vi=CR_MAX_VOICES+CR_MAX_PADS;uint8_t record[CRL_REC_MAX],after[CRL_REC_MAX];uint32_t len,off;
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 cu_opened(BT_METRO);assert(cu.lock==L_METRO);
 cu_knob(EN_K4,7);cr_audio_block(CTL);assert(cs.loop_transpose==7&&cr.loop_transpose==7);
 cr_build_screen(&screen,cu_now());assert(!strcmp(screen.cell[0][3].label,"Loop trans"));assert(!strcmp(screen.cell[0][3].value,"+7 st"));assert(screen.cell[0][3].glyph==CR_G_SHIFT);
 cu_knob(EN_K4,100);cr_audio_block(CTL);assert(cr.loop_transpose==12);
 cu_knob(EN_K4,-100);cr_audio_block(CTL);assert(cr.loop_transpose==-12);
 cu_knob(EN_K4,12);cr_audio_block(CTL);cr_build_screen(&screen,cu_now());assert(!strcmp(screen.cell[0][3].value,"0 st"));cu_home_tap();
 for(mode=0;mode<CR_PM_COUNT;mode++)for(tp=-12;tp<=12;tp++) {
  cr_init(&c,0);cr_loop_init(&lp);cr_set_stream(&c,CR_STREAM_RAW,1);cr_set_stream(&c,CR_STREAM_BASS,1);cr_set_bass(&c,1);
  cr_set_perform_mode(&c,(cr_pmode_t)mode);cr_set_perform(&c,1);
  crl_play_ev(&lp,&c,&ev,0);off=lp.pv[0].off;assert(c.v[vi].root==60);
  cr_set_loop_transpose(&c,tp);assert(c.v[vi].root==60+tp);assert(c.v[vi].note_pressed==60);assert(lp.pv[0].off==off);
  assert(c.v[vi].bass.note==36+tp); /* default bass octave */
  for(i=1;i<=300;i++)cr_tick(&c,i);
  lp.t=off;crl_offs(&lp,&c);assert(!c.v[vi].used);no_notes(&c);
 }
 /* Sustained MAIN/RAW shared with a live chord must keep the live references. */
 cr_init(&c,0);cr_set_stream(&c,CR_STREAM_RAW,1);cr_set_transpose(&c,5);cr_mod(&c,CR_MOD_MAJ,1);cr_key(&c,55,100,1);
 cr_loop_event(&c,0,60,CR_Q_MAJ,0,100,1);assert(c.reg[0][60]==2);
 cr_set_loop_transpose(&c,12);assert(c.v[0].root==55&&c.v[0].transpose==5);assert(c.reg[0][60]==1&&c.reg[0][72]==1);
 cr_set_loop_transpose(&c,-12);assert(c.reg[0][60]==1&&c.reg[0][48]==1);
 cr_set_loop_transpose(&c,0);assert(c.reg[0][60]==2);
 cr_loop_event(&c,0,0,0,0,0,0);assert(c.reg[0][60]==1);cr_key(&c,55,0,0);no_notes(&c);
 /* Boundary clipping never becomes cumulative, including a unison bass. */
 cr_init(&c,0);cr_set_bass_mode(&c,CR_BASS_UNISON);cr_set_bass(&c,1);cr_set_stream(&c,CR_STREAM_BASS,1);
 cr_loop_event(&c,0,2,CR_Q_MAJ,0,100,1);cr_set_loop_transpose(&c,-12);assert(c.v[vi].root==0&&c.v[vi].bass.note==0);
 cr_set_loop_transpose(&c,12);assert(c.v[vi].root==14&&c.v[vi].bass.note==14);
 cr_loop_event(&c,1,124,CR_Q_MAJ,0,100,1);assert(c.v[vi+1].root==127);
 cr_set_loop_transpose(&c,-12);assert(c.v[vi+1].root==112);cr_panic(&c);no_notes(&c);
 /* Pack/unpack remain byte-identical, and the actual loop clock ends new notes on time. */
 cr_init(&c,0);cr_loop_init(&lp);lp.d.len=384;lp.d.nev=1;lp.d.nlayers=1;lp.d.ev[0]=ev;
 len=cr_loop_pack(&lp.d,record,sizeof record);assert(len);lp.state=CRL_STOPPED;
 cr_set_loop_transpose(&c,7);assert(cr_loop_play(&lp,&c)==CRL_DID_PLAY);
 for(i=1;i<=100;i++){cr_tick(&c,i);cr_loop_tick(&lp,&c,i);}assert(c.v[vi].used&&c.v[vi].root==67);
 cr_set_loop_transpose(&c,-5);
 for(i=101;i<=650;i++){cr_tick(&c,i);cr_loop_tick(&lp,&c,i);}assert(!c.v[vi].used);no_notes(&c);
 assert(cr_loop_pack(&lp.d,after,sizeof after)==len&&!memcmp(record,after,len));
 cr_loop_stop(&lp,&c);no_notes(&c);
 puts("PASS: SEQ KNOB4/UI, +/-12 clamps, all performance modes, live retuning and bass, shared note ownership, clipping recovery, scheduled offs, unchanged loop records");
 return 0;
}
