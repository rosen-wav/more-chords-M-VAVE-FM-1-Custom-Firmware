#define CR_MIDI_CONTROLS_HELPERS_ONLY
#include "cr_midi_chord_controls_test.c"
static unsigned black_note(unsigned n){switch(n%12){case 1:case 3:case 6:case 8:case 10:return 1;default:return 0;}}
static void oracle(unsigned base,unsigned notes[9]){
 static const unsigned whites[5]={4,5,6,8,7},blacks[4]={0,1,2,3}; /* indices: DIM MIN MAJ SUS 6 m7 M7 9 LOCK */
 unsigned w=0,b=0;for(unsigned n=base;n<128&&(w<5||b<4);n++){
  if(black_note(n)){if(b<4)notes[blacks[b++]]=n;}else if(w<5)notes[whites[w++]]=n;
 }assert(w==5&&b==4);
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);unsigned cases=0;
 assert(cs.midi_chord_base==53&&cr_perform_base==53&&sizeof(cr_settings_t)==192&&O_MAX[O_MIDI_CHORD_BASE]==118);
 const unsigned q[4]={CR_Q_DIM,CR_Q_MIN,CR_Q_MAJ,CR_Q_SUS};
 for(unsigned source=1;source<=2;source++)for(unsigned base=0;base<=118;base++){
  unsigned notes[9];oracle(base,notes);unsigned root=base<=48&&base+10>=48?72:48;
  for(unsigned k=0;k<4;k++){
   reset(0);opt_set(O_MIDI_CHORD_BASE,base);cr_audio_block(CTL);assert(cr_perform_base==base);
   tap(source,notes[8]);tap(source,notes[k]);send(source,0x90,root,100);
   int vi=crx_find_voice(&cr,root);assert(vi>=0&&cr.v[vi].rq==q[k]&&cr.v[vi].nnotes==3&&cr.phys_n==1);
   assert(black_note(notes[k]));send(source,0x80,root,0);assert(!main_count());cases++;
  }
  reset(0);opt_set(O_MIDI_CHORD_BASE,base);cr_audio_block(CTL);tap(source,notes[8]);tap(source,notes[2]);
  tap(source,notes[4]);tap(source,notes[5]);tap(source,notes[7]);send(source,0x90,root,100);
  int vi=crx_find_voice(&cr,root);assert(vi>=0&&cr.v[vi].nnotes==6);
  tap(source,notes[6]);assert((cr.mods_down&(1u<<CR_MOD_MAJ7))&&!(cr.mods_down&(1u<<CR_MOD_M7)));
  tap(source,notes[4]);tap(source,notes[7]);assert(!(cr.mods_down&((1u<<CR_MOD_6)|(1u<<CR_MOD_9))));
  for(unsigned k=4;k<9;k++)assert(!black_note(notes[k]));cases++;
  send(source,0x80,root,0);tap(source,notes[8]);assert(!cr.mods_down&&!cr_mlock);cases++;
  for(unsigned k=0;k<11&&base+k<128;k++){
   reset(1);opt_set(O_MIDI_CHORD_BASE,base);cr_audio_block(CTL);send(source,0x90,base+k,100);
   assert(cr.reg[CR_STREAM_MAIN][base+k]&&!cr_mlock&&!cr.mods_down);send(source,0x80,base+k,0);assert(!main_count());cases++;
  }
  /* Every unassigned gap stays playable in chords mode. */
  reset(0);opt_set(O_MIDI_CHORD_BASE,base);cr_audio_block(CTL);
  for(unsigned k=0;k<11&&base+k<128;k++){
   unsigned used=0;for(unsigned j=0;j<9;j++)used+=notes[j]==base+k;
   if(!used){send(source,0x90,base+k,100);assert(cr.phys[base+k]);send(source,0x80,base+k,0);cases++;}
  }
  cr_settings_t s,r;crs_capture(&s);cr_settings_seal(&s);assert(cr_settings_import(&r,&s,sizeof s)==1&&CRS_MIDI_BASE(&r)==base);cases++;
 }
 /* Exact C/E/F examples, including the spare white C after an E anchor. */
 static const unsigned c[9]={37,39,42,44,36,38,40,43,41},e[9]={42,44,46,49,40,41,43,47,45},f[9]={54,56,58,61,53,55,57,60,59};
 unsigned notes[9];oracle(36,notes);assert(!memcmp(notes,c,sizeof c));oracle(40,notes);assert(!memcmp(notes,e,sizeof e));oracle(53,notes);assert(!memcmp(notes,f,sizeof f));cases+=3;
 reset(0);opt_set(O_MIDI_CHORD_BASE,36);cr_audio_block(CTL);char text[64];opt_text(O_MIDI_CHORD_BASE,text,sizeof text);assert(!strcmp(text,"C2 / MIDI 36"));
 opt_set(O_MIDI_CHORD_BASE,-1);cr_audio_block(CTL);assert(cr_perform_base==0);opt_set(O_MIDI_CHORD_BASE,127);cr_audio_block(CTL);assert(cr_perform_base==118);cases++;
 reset(0);tap(1,59);tap(1,58);send(1,0x90,72,100);send(1,0xb0,64,127);
 cr_ev_in_t ev={0};ev.op=CRE_KEY;ev.a=72;ev.b=100;ev.v=1;cr_apply(&ev);
 opt_set(O_MIDI_CHORD_BASE,36);cr_audio_block(CTL);assert(!cr_mlock&&!cr_mmod_latch&&!cr_mmod_held[0]&&!cr_perform_note[0][72]&&!cr_perform_pedal[0]);
 assert(cr.phys[72]==1&&main_count()==3);ev.v=0;cr_apply(&ev);send(1,0x80,72,0);send(1,0x80,58,0);assert(!main_count()&&!cr.phys_n);cases++;
 for(unsigned version=1;version<=8;version++){
  cr_settings_t s,r;cr_settings_defaults(&s);s.bpm=133;s.scale=37;s.version=version;s.check=crs_fnv(&s,sizeof s);
  assert(cr_settings_import(&r,&s,sizeof s)==2&&CRS_MIDI_BASE(&r)==(version<8?53:36)&&r.bpm==133);cases++;
 }
 cr_settings_t s,r;cr_settings_defaults(&s);s.scale=120;s.version=8;s.check=crs_fnv(&s,sizeof s);
 assert(cr_settings_import(&r,&s,sizeof s)==2&&CRS_MIDI_BASE(&r)==118);s.scale=255;cr_settings_seal(&s);assert(cr_settings_import(&r,&s,sizeof s)==1&&CRS_MIDI_BASE(&r)==53);cases+=2;
 unsigned saved[]={0,36,53,118};
 for(unsigned k=0;k<4;k++){
  reset(0);opt_set(O_MIDI_CHORD_BASE,saved[k]);cr_audio_block(CTL);cr_snapshot();memset(scope_buf,0,sizeof scope_buf);
  for(unsigned p=0;p<NPART;p++){memset(trk[p].v,0,sizeof trk[p].v);trk[p].nheld=trk[p].nmono=0;}
  cr_settings_save();persist_t stored;int bytes=st_load(OBJ_SETTINGS,&stored,sizeof stored);assert(bytes>0&&settings_import(&stored,bytes)&&CRS_MIDI_BASE(&stored.cr)==saved[k]);
  cs.midi_chord_base=cr_perform_base=53;crs_booted=0;cr_settings_boot();cr_settings_load();cr_audio_block(CTL);
  assert(cs.midi_chord_base==saved[k]&&cr_perform_base==saved[k]);oracle(saved[k],notes);tap(1,notes[8]);assert(cr_mlock);cases++;
 }
 cr_panic(&cr);cr_loop_clear(&crl,&cr);cr_snapshot();memset(scope_buf,0,sizeof scope_buf);for(unsigned p=0;p<NPART;p++)memset(trk[p].v,0,sizeof trk[p].v);
 opt_set(O_MIDI_CHORD_BASE,41);cr_audio_block(CTL);cr_snapshot();fm1_ms+=2000;cr_settings_poll();fm1_ms+=2000;cr_settings_poll();
 persist_t automatic;int bytes=st_load(OBJ_SETTINGS,&automatic,sizeof automatic);assert(bytes>0&&settings_import(&automatic,bytes)&&CRS_MIDI_BASE(&automatic.cr)==41);cases++;
 printf("PASS: MIDI black/white base %u cases: all 119 offsets USB/TRS, exact C/E/F maps, four black qualities/five white extensions+LOCK, playable gaps, just-keys, range, migration, shared notes, map rebuild at NOR reboot and autosave\n",cases);
}
