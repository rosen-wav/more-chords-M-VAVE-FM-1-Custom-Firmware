#define CR_MIDI_PERFORM_HELPERS_ONLY
#include "cr_midi_perform_test.c"
static void tap(unsigned src,unsigned note){send(src,0x90,note,100);send(src,0x80,note,0);}
static void quality(unsigned q){int vi=crx_find_voice(&cr,72);assert(vi>=0&&cr.v[vi].rq==q&&cr.v[vi].nnotes>=3);}
#ifndef CR_MIDI_CONTROLS_HELPERS_ONLY
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);unsigned cases=0;
 const unsigned control[4]={54,56,58,61},q[4]={CR_Q_DIM,CR_Q_MIN,CR_Q_MAJ,CR_Q_SUS};
 for(unsigned src=1;src<=2;src++)for(unsigned style=0;style<3;style++)for(unsigned c=0;c<4;c++){
  reset(0);cr_set_playstyle(&cr,(cr_playstyle_t)style);
  send(src,0x90,control[c],100);assert(!main_count()&&!cr.phys_n);
  send(src,0x90,72,100);quality(q[c]);send(src,0x80,72,0);send(src,0x80,control[c],0);
  cr_panic(&cr);assert(!main_count());cases++;
  /* Changing quality while a MIDI root is held immediately revoices it. */
  reset(0);send(src,0x90,72,100);send(src,0x90,control[c],100);quality(q[c]);
  send(src,0x80,control[c],0);send(src,0x80,72,0);assert(!main_count());cases++;
  /* LOCK on: tap quality, lift it, then play roots; top quality replaces the old one. */
  reset(0);tap(src,59);assert(cr_mlock);tap(src,58);tap(src,control[c]);
  send(src,0x90,72,100);quality(q[c]);send(src,0x80,72,0);
  cr_snapshot();assert(cr_snap.midi_chord_lock&&((cr_snap.mods_held>>(q[c]-1u))&1u));
  tap(src,59);assert(!cr_mlock&&!cr_mmod_latch&&!cr.mods_down);cases++;
 }
 for(unsigned src=1;src<=2;src++){
  reset(0);tap(src,59);tap(src,58);tap(src,53);tap(src,55);tap(src,60);
  send(src,0x90,72,100);quality(CR_Q_MAJ);assert(cr.v[crx_find_voice(&cr,72)].nnotes==6);
  tap(src,57);assert(!(cr.mods_down&(1u<<CR_MOD_M7))&&(cr.mods_down&(1u<<CR_MOD_MAJ7)));
  tap(src,53);assert(!(cr.mods_down&(1u<<CR_MOD_6)));tap(src,60);assert(!(cr.mods_down&(1u<<CR_MOD_9)));
  send(src,0x80,72,0);send(src,0xb0,120,0);assert(!main_count()&&!cr.mods_down);cases++;
  /* A repeated Note On must not toggle LOCK twice; velocity-zero ends the press. */
  reset(0);send(src,0x90,59,100);send(src,0x90,59,90);assert(cr_mlock);
  send(src,0x90,59,0);tap(src,59);assert(!cr_mlock);cases++;
  /* Sustain cannot turn a momentary quality into a stuck modifier. */
  reset(0);send(src,0xb0,64,127);send(src,0x90,56,100);send(src,0x90,56,0);assert(!cr.mods_down);cases++;
  /* Just keys: every formerly reserved control including LOCK sounds normally. */
  for(unsigned n=53;n<=61;n++){
   reset(1);send(src,0x90,n,100);assert(cr.reg[CR_STREAM_MAIN][n]&&!cr_mlock&&!cr.mods_down);
   send(src,0x90,n,0);assert(!main_count());cases++;
  }
  /* Simple resets only extensions when the next root is played. */
  reset(0);cr_set_playstyle(&cr,CR_PS_SIMPLE);tap(src,59);tap(src,58);tap(src,53);tap(src,55);tap(src,60);
  send(src,0x90,72,100);assert(cr.v[crx_find_voice(&cr,72)].nnotes==6);send(src,0x80,72,0);
  send(src,0x90,74,100);assert(cr.v[crx_find_voice(&cr,74)].nnotes==3&&!((cr_mmod_latch|cr.mods_down)&240u));cases++;
 }
 /* Two inputs holding a modifier cannot release one another. */
 reset(0);send(1,0x90,56,100);send(2,0x90,56,100);send(1,0x80,56,0);assert(cr.mods_down&(1u<<CR_MOD_MIN));
 send(2,0x80,56,0);assert(!cr.mods_down);cases++;
 /* Physical and MIDI modifier ownership, in both release orders. */
 for(unsigned first=0;first<2;first++){
  reset(0);cr_ev_in_t e={0};e.op=CRE_MOD;e.a=CR_MOD_MAJ;e.v=1;cr_apply(&e);send(1,0x90,58,100);
  if(first){send(1,0x80,58,0);}else{e.v=0;cr_apply(&e);}assert(cr.mods_down&(1u<<CR_MOD_MAJ));
  if(first){e.v=0;cr_apply(&e);}else send(1,0x80,58,0);assert(!cr.mods_down);cases++;
 }
 reset(0);tap(1,59);tap(1,58);cr_route.ch[0]=3;cr_audio_block(CTL);assert(!cr.mods_down&&!cr_mmod_latch);cases++;
 reset(0);tap(1,59);tap(1,58);cr_ev_in_t e={0};e.op=CRE_KEYS_ONLY;e.v=1;cr_apply(&e);assert(!cr_mlock&&!cr.mods_down);cases++;
 reset(0);send(1,0x91,58,100);assert(cr_mnote[1][58]&&!cr.mods_down);send(1,0x81,58,0);cases++;
 /* Modifier then root in one audio block: no one-frame UI race. */
 for(unsigned src=1;src<=2;src++){
  reset(0);
  if(src==1){assert(emu_fw_midi_in(9u|0x90u<<8|56u<<16|100u<<24));assert(emu_fw_midi_in(9u|0x90u<<8|72u<<16|100u<<24));}
  else {um_byte(0x90);um_byte(56);um_byte(100);um_byte(72);um_byte(100);} /* running status */
  cr_audio_block(CTL);quality(CR_Q_MIN);assert(!cr.reg[CR_STREAM_MAIN][56]);cases++;
 }
 /* The actual physical UI can still change qualities on a held MIDI chord. */
 for(unsigned src=1;src<=2;src++){
  reset(0);cs.keys_only=0;cu.kheld=cu.mlatch=cu.mkill=cu.clock=0;
  send(src,0x90,72,100);cu_key_press(3);cr_audio_block(CTL);quality(CR_Q_MIN);
  cu_key_release(3);cr_audio_block(CTL);send(src,0x80,72,0);assert(!main_count());cases++;
 }
 reset(0);tap(1,59);cr_set_bass(&cr,0);cr_snapshot();cs.sticky=0;cu.octave=cu.clock=0;
 cr_screen_t screen={0};cu_header(&screen);assert(!strcmp(screen.right,"lock"));cases++;
 printf("PASS: MIDI chord controls %u USB/TRS/style/quality/LOCK fixtures; extensions, exclusive sevenths, no control notes, live revoice, just-keys bypass, repeat/velocity0, sustain, ownership and cleanup\n",cases);
}

#endif
