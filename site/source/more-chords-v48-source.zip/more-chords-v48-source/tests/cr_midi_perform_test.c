/* Real USB queue / TRS parser to musical engine and selected Bass synth. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned bass_count(void){unsigned n=0;for(unsigned i=0;i<128;i++)n+=cr.reg[CR_STREAM_BASS][i]!=0;return n;}
static unsigned main_count(void){unsigned n=0;for(unsigned i=0;i<128;i++)n+=cr.reg[CR_STREAM_MAIN][i]!=0;return n;}
static void send(unsigned source,unsigned status,unsigned n,unsigned v){
 if(source==2){um_byte(status);um_byte(n);if((status&0xf0)!=0xc0&&(status&0xf0)!=0xd0)um_byte(v);}
 else assert(emu_fw_midi_in((status>>4)|status<<8|n<<16|v<<24));
 cr_audio_block(CTL);
}
static void reset(int keys){
 cr_perform_forget();cr_mlock=cr_mlock_held=cr_phys_mods=cr_phys_held=0;cr_perform_base=53;cr_perform_map_build();cs.midi_chord_base=53;clear(ENGI_FM6,1,0);cr_set_keys_only(&cr,keys);
 memset(cr_mnote,0,sizeof cr_mnote);memset(cr_mch,0,sizeof cr_mch);memset(cr_mheld,0,sizeof cr_mheld);
 memset(&um,0,sizeof um);mi_r=mi_w=0;midi_in_overflow=0;
 cr_route.midi_en[0]=cr_route.midi_en[1]=1;cr_route.ch[0]=0;cr_route.ch[1]=1;
 cr_perform_en=1;cr_perform_ch=0;
 cu_pool_load(1,ENGI_BASS,pool_pos_factory(ENGI_BASS,2));engine_block(&trk[1]);cr_audio_block(CTL);panic_req=0;
}
#ifndef CR_MIDI_PERFORM_HELPERS_ONLY
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);unsigned checks=0;
 for(unsigned source=1;source<=2;source++)for(unsigned minor=0;minor<2;minor++)for(int root=64;root<=88;root+=12)for(int inv=-3;inv<=5;inv++){
  reset(0);cr_mod(&cr,minor?CR_MOD_MIN:CR_MOD_MAJ,1);cr_voicing_step(&cr,inv);
  send(source,0x90,root,100);assert(main_count()==3&&bass_count()==1);
  int vi=crx_find_voice(&cr,root);assert(vi>=0&&cr.v[vi].rq==(minor?CR_Q_MIN:CR_Q_MAJ));
  assert(cr.reg[CR_STREAM_MAIN][cr.v[vi].notes[0]]);assert(cr.reg[CR_STREAM_BASS][36+root%12]);
  send(source,0x90,root,0);assert(!main_count()&&!bass_count()&&!cr.phys_n);checks++;
 }
 for(unsigned source=1;source<=2;source++){
  reset(1);send(source,0x90,64,90);send(source,0x90,67,100);assert(!bass_count());
  send(source,0x90,60,110);assert(main_count()==3&&bass_count()==1&&cr.reg[CR_STREAM_BASS][36]);
  settle();unsigned gates=0;for(unsigned i=0;i<NVOICE;i++)gates+=trk[1].v[i].gate&&trk[1].v[i].note==36;
  assert(gates==1&&trk[1].engine==ENGI_BASS&&trk[1].preset==2);
  /* Capture keyboard MIDI chords as three raw step events; no extra Bass event. */
  cr_loop_clear(&crl,&cr);assert(cr_loop_grid_edit(&crl,&cr,0,-1)>0&&crl.d.nev==3);
  send(source,0xb0,64,127);send(source,0x80,60,0);assert(bass_count()==1);
  send(source,0xb0,64,0);assert(!bass_count()&&main_count()==2);
  send(source,0xb0,123,0);assert(!main_count()&&!cr.phys_n);checks++;
  reset(0);cr_mod(&cr,CR_MOD_MAJ,1);send(source,0x90,72,100);send(source,0xb0,64,127);send(source,0xb0,123,0);
  assert(main_count()==3);send(source,0xb0,121,0);assert(!main_count()&&!bass_count());checks++;
  reset(1);send(source,0x90,60,100);send(source,0xb0,64,127);send(source,0x80,60,0);send(source,0x90,60,90);
  send(source,0xb0,64,0);assert(main_count()==1);send(source,0x80,60,0);assert(!main_count());checks++;
 }
 /* Independent same-pitch owners in both release orders and musical modes. */
 for(unsigned keys=0;keys<2;keys++)for(unsigned first=0;first<3;first++){
  reset(keys);if(!keys)cr_mod(&cr,CR_MOD_MAJ,1);
  cr_ev_in_t e={0};e.op=CRE_KEY;e.a=72;e.b=100;e.v=1;cr_apply(&e);
  send(1,0x90,72,90);send(2,0x90,72,80);assert(cr.phys_n==3);
  if(first==0){e.v=0;cr_apply(&e);}else send(first,0x80,72,0);
  assert(main_count()==(keys?1u:3u)&&cr.phys_n==2);
  for(unsigned s=1;s<=2;s++)if(s!=first)send(s,0x80,72,0);
  if(first!=0){assert(main_count()==(keys?1u:3u));e.v=0;cr_apply(&e);}
  assert(!main_count()&&!bass_count()&&!cr.phys_n);checks++;
 }
 reset(1);send(1,0x90,60,100);send(2,0x90,64,100);send(1,0x90,67,100);assert(bass_count()==1);
 send(2,0xb0,120,0);assert(main_count()==2&&!bass_count());send(1,0xb0,120,0);assert(!main_count());checks++;
 /* Explicit All Sound Off and routing cleanup clear latched MIDI gestures too. */
 for(unsigned keys=0;keys<1;keys++){
  reset(keys);if(!keys)cr_mod(&cr,CR_MOD_MAJ,1);cr_set_sticky(&cr,1);
  send(1,0x90,72,100);send(1,0x90,76,100);send(1,0x90,79,100);
  send(1,0x80,72,0);send(1,0x80,76,0);send(1,0x80,79,0);assert(main_count());
  send(1,0xb0,120,0);assert(!main_count()&&!bass_count());checks++;
 }
 /* Rosen preset loads must not discard the incoming chord owners. */
 for(unsigned source=1;source<=2;source++) {
  reset(0);cr_mod(&cr,CR_MOD_MAJ,1);cr_rosen_mode=1;
  send(source,0x90,72,100);assert(cr_rosen_pending==1&&main_count()==3);
  cu_rosen_service();assert(cr_rosen_pending==2);events_block(CTL);
  assert(!cr_rosen_pending&&main_count()==3&&cr.phys_n==1&&cr_perform_note[source-1][72]);
  send(source,0x80,72,0);assert(!main_count()&&!bass_count());cr_rosen_mode=0;checks++;
 }
 /* Routing changes and queue overflow cannot strand the generated notes/Bass. */
 reset(1);send(1,0x90,60,100);send(1,0x90,64,100);send(1,0x90,67,100);
 cr_route.ch[0]=3;cr_audio_block(CTL);assert(!main_count()&&!bass_count());send(1,0x90,60,100);assert(!main_count());
 send(1,0x93,60,100);assert(main_count()==1);cr_route.midi_en[0]=0;cr_audio_block(CTL);assert(!main_count());checks++;
 reset(1);send(1,0x90,60,100);midi_in_overflow=1;events_block(CTL);assert(!main_count()&&!cr.phys_n);checks++;
 reset(0);send(1,0x91,40,100);assert(!main_count()&&cr_mnote[1][40]);send(1,0x81,40,0);assert(!cr_mnote[1][40]);checks++;
 reset(1);send(1,0xe0,127,127);assert(midi_bend_target[0]==512);send(1,0xb0,1,87);assert(trk[0].mw==87);checks++;
 printf("PASS: MIDI Perform %u USB/TRS chord/voicing/just-keys Bass fixtures; selected synth, Step capture, sustain, retrigger, shared owners, panic/overflow, channels, direct Bass and controls\n",checks);
}

#endif
