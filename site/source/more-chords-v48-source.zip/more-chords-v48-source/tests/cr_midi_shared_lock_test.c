#define CR_MIDI_CONTROLS_HELPERS_ONLY
#include "cr_midi_chord_controls_test.c"
static void flush(void){cr_audio_block(CTL);cr_ui_frame();cr_audio_block(CTL);}
static void ui_tap(unsigned k){cu_key_press(k);flush();cu_key_release(k);flush();}
static void setup(void){reset(0);cs.keys_only=0;cu.kheld=cu.clock=cu.mlatch=cu.mkill=0;cr_mlock=0;cr_snapshot();}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);unsigned n=0;
 for(unsigned src=1;src<=2;src++){
  /* FM1 LOCK holds MIDI qualities and all three extension controls. */
  setup();ui_tap(6);assert(cu.clock&&cr_mlock);
  tap(src,56);tap(src,53);tap(src,55);tap(src,60);send(src,0x90,72,100);quality(CR_Q_MIN);assert(cr.v[crx_find_voice(&cr,72)].nnotes==6);
  send(src,0x80,72,0);ui_tap(6);assert(!cu.clock&&!cr_mlock&&!cr.mods_down);n++;
  /* MIDI LOCK holds physical modifiers, and turning it off releases physical virtual holds. */
  setup();tap(src,59);flush();assert(cu.clock&&cr_mlock);ui_tap(5);assert(cu.mlatch&(1u<<CR_MOD_MAJ));
  send(src,0x90,72,100);quality(CR_Q_MAJ);send(src,0x80,72,0);tap(src,59);flush();assert(!cu.clock&&!cr_mlock&&!cu.mlatch&&!cr.mods_down);n++;
  /* Switching quality between inputs replaces the virtual quality, keeping extensions. */
  setup();ui_tap(6);ui_tap(5);ui_tap(0);tap(src,56);flush();assert(!(cr.mods_down&(1u<<CR_MOD_MAJ))&&(cr.mods_down&(1u<<CR_MOD_MIN))&&(cr.mods_down&(1u<<CR_MOD_6)));
  send(src,0x90,72,100);quality(CR_Q_MIN);send(src,0x80,72,0);ui_tap(5);send(src,0x90,72,100);quality(CR_Q_MAJ);n++;
  /* A physical modifier really held down survives MIDI LOCK off until key-up. */
  setup();tap(src,59);flush();cu_key_press(3);flush();tap(src,59);flush();assert(cr.mods_down&(1u<<CR_MOD_MIN));cu_key_release(3);flush();assert(!cr.mods_down);n++;
  /* MIDI toggle and physical release before the next UI frame: no latch race. */
  setup();cu_key_press(3);flush();tap(src,59);cu_key_release(3);cr_audio_block(CTL);
  assert(cr.mods_down&(1u<<CR_MOD_MIN));cr_ui_frame();assert(cu.clock&&(cu.mlatch&(1u<<CR_MOD_MIN)));ui_tap(6);assert(!cr.mods_down);n++;
  /* An extension latched on MIDI can be toggled off physically and vice versa. */
  setup();ui_tap(6);tap(src,53);flush();ui_tap(0);assert(!(cr.mods_down&(1u<<CR_MOD_6)));
  ui_tap(0);assert(cr.mods_down&(1u<<CR_MOD_6));tap(src,53);flush();assert(!(cr.mods_down&(1u<<CR_MOD_6)));n++;
  /* Panic releases virtual holds while retaining the common LOCK switch. */
  setup();ui_tap(6);tap(src,56);cu_panic();flush();assert(cu.clock&&cr_mlock&&!cr.mods_down);n++;
 }
 puts("PASS: shared FM1/USB/TRS LOCK: both directions, quality replacement, extensions, physically held keys, LEDs/state and panic");
}
