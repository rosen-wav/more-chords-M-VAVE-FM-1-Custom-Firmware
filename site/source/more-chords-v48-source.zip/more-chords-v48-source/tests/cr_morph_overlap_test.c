/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 trk[0].engine=ENGI_MORPH;morph.inside=1;
 morph_history.count=MORPH_HISTORY;
 for(unsigned i=0;i<MORPH_HISTORY;i++)for(unsigned ch=0;ch<2;ch++)morph_history.pcm[i][ch]=(i+ch)&1?INT32_MAX:INT32_MIN;
 morph_history.last[0]=INT32_MAX;morph_history.previous[0]=INT32_MIN;
 morph_history.last[1]=INT32_MIN;morph_history.previous[1]=INT32_MAX;
 int32_t pcm[CTL],side[CTL];
 for(unsigned block=0;block<100;block++){
  for(unsigned k=0;k<CTL;k++){pcm[k]=k&1?INT32_MAX:INT32_MIN;side[k]=~pcm[k];}
  if(!(block%3))morph_history.request=1;
  morph_fade_pcm(&trk[0],pcm,side,CTL);
  assert(morph_history.read<MORPH_HISTORY&&morph_history.write<MORPH_HISTORY);
 }
 printf("PASS: full-width stereo overlap under UBSan, rapid restarts; history %zu bytes\n",sizeof morph_history);
 return 0;
}
