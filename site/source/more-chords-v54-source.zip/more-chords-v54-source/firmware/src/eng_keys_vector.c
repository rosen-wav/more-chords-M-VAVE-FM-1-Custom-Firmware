/* SPDX-License-Identifier: GPL-3.0-only
 * Original more chords! TINES / VECTOR, 2026. No imported DSP code/data.
 * Study, limitations and source licenses: docs/TINES-VECTOR-RESEARCH.md.
 * Mutable state belongs to one voice/core; immutable tables are shared.
 */
#include "vector_tables.h"
typedef struct {
 orbit_bridge_t bridge;
 uint32_t ph[4],slow;
 int32_t body,tine,attack,ic1,ic2,dc,xy[3],filter_env;
 uint8_t filter_stage,initialized;
} kv_voice_t;
typedef struct {kv_voice_t voice[NVOICE];} kv_part_t;
static kv_part_t *kv_part(uint32_t part);
static kv_voice_t *kv_state(track_t *t,voice_t *v){return &kv_part((uint32_t)(t-trk))->voice[v-t->v];}
static void kv_note(track_t *t,voice_t *v){
 kv_voice_t *s=kv_state(t,v);orbit_bridge_note(&s->bridge);
 if(!voice_was){s->ic1=s->ic2=s->dc=s->filter_env=0;s->slow=0;for(unsigned k=0;k<4;k++)s->ph[k]=0;}
 s->body=s->tine=s->attack=1<<24;s->filter_stage=1;
 if(!s->initialized){for(unsigned k=0;k<3;k++)s->xy[k]=clamp(t->p[P_E0+(k==2?3:k)],0,127)*256;s->initialized=1;}
}
/* Exact finite-endpoint slew, ~2.9ms time constant at 44.1kHz. */
static int32_t kv_slew(int32_t a,int32_t b){int32_t d=b-a;return a+(d>0?((d+127)>>7):d<0?-((-d+127)>>7):0);}
/* Independent filter ADSR, same Q24/time tables as the platform amplitude ADSR.
 * Dormant DIGITAL operator 1 fields keep preset/protocol layouts unchanged. */
static int32_t kv_filter_env(track_t *t,voice_t *v,kv_voice_t *s){
 if(!v->gate)s->filter_stage=3;
 if(s->filter_stage==1){s->filter_env+=(int32_t)ENV_LIN[t->p[P_FM1_ATK]&127];if(s->filter_env>=(1<<24)){s->filter_env=1<<24;s->filter_stage=2;}}
 else if(s->filter_stage==2)s->filter_env+=mulq16((int32_t)t->p[P_FM1_SUS]*131072-s->filter_env,ENV_EXP[t->p[P_FM1_DEC]&127]);
 else s->filter_env-=mulq16(s->filter_env,ENV_EXP[t->p[P_FM1_REL]&127]);
 return s->filter_env>>9;
}
static void kv_filter(track_t *t,voice_t *v,kv_voice_t *s,const vmod_t *m,tsvf_t *f){
 int32_t env=kv_filter_env(t,v,s);
 int32_t cut=clamp(t->p[P_E4],0,127)*256+m->cutoff+((env*clamp(t->p[P_E6],-64,63))>>7);
 cut+=(m->pitch16-960)*clamp(t->p[P_E7],0,127)/8;
 tsvf_coef(f,cut,clamp(t->p[P_E5],0,110));
}
static void kv_emit(kv_voice_t *s,const tsvf_t *f,int32_t x,const vmod_t *m,int32_t *out,unsigned i){
 /* Headroom before resonant SVF; bounded soft saturation after it. */
 int32_t y=tsvf_lp(f,x/2,&s->ic1,&s->ic2);
 y=softclip(y);s->dc+=(y-s->dc)>>10;
 out[i]+=voice_amp(y-s->dc,m,i)*2;
}
static void tines_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 if(!n)return;if(n>CTL)n=CTL;
 kv_voice_t *s=kv_state(t,v);int32_t first=out[0],last=out[n-1];tsvf_t f;kv_filter(t,v,s,m,&f);
 int32_t bell=clamp(t->p[P_E0]+((m->shape-16384)>>8),0,127),bark=clamp(t->p[P_E1],0,127),dec=clamp(t->p[P_E2],0,127),trem=clamp(t->p[P_E3],0,127);
 int32_t vel=clamp(v->vel,1,127),hard=vel*vel/127;
 /* Block-rate modal losses, interpolated per sample; no exp/divide in the loop. */
 int32_t b0=s->body,t0=s->tine,a0=s->attack;
 int32_t damp=127-clamp(t->p[P_FM2_SUS],0,127);
 int32_t b1=b0-mulq16(b0,4u+(uint32_t)damp*3u+(uint32_t)(127-dec)*2u);
 int32_t t1=t0-mulq16(t0,24u+(uint32_t)damp*12u+(uint32_t)(127-dec)*6u);
 int32_t a1=a0-mulq16(a0,4500u+(uint32_t)(127-dec)*20u);
 uint32_t inc=m->inc,it=(inc>>8)*1031u,ia=(inc>>8)*2479u;
 /* Suppress high modal partials before Nyquist; unsigned ratios cannot wrap. */
 int32_t tg=clamp((int32_t)(0x78000000u-(it<0x78000000u?it:0x78000000u))>>14,0,32767);
 int32_t ag=clamp((int32_t)(0x78000000u-(ia<0x78000000u?ia:0x78000000u))>>14,0,32767);
 if(inc>0x18000000u)tg=0;if(inc>0x0c000000u)ag=0;
 int32_t bright=bell*(32+hard)*2,drive=bark*hard;
 int32_t body_gain=32768+clamp(t->p[P_FM2_ATK],0,127)*128,hit_gain=32768+clamp(t->p[P_FM2_DEC],0,127)*256;
 uint32_t trem_inc=389566u+(uint32_t)clamp(t->p[P_FM2_REL],0,127)*18405u;
 for(unsigned i=0;i<n;i++){
  int32_t be=(b0+(b1-b0)*(int32_t)i/CTL)>>9,te=(t0+(t1-t0)*(int32_t)i/CTL)>>9,ae=(a0+(a1-a0)*(int32_t)i/CTL)>>9;
  int32_t fundamental=sine_i(s->ph[0]);
  /* Two modal body components plus a tine and a hammer partial, not 2-op FM. */
  int32_t warm=inc<0x28000000u?sine_i(s->ph[0]*2u)/8:0;
  int32_t x=mulq15(fundamental+warm,be);
  int32_t metal=mulq15(mulq15(sine_i(s->ph[1]),te),tg);
  int32_t hit=mulq15(mulq15(sine_i(s->ph[2]),ae),ag);
  x=mulq15(x*3/5,body_gain)+mulq15(metal,bright/3)+mulq15(mulq15(hit,hard*60),hit_gain);
  if(drive){int32_t driven=softclip(x+mulq15(x,drive));x+=mulq15(driven-x,drive);}
  if(trem)x=mulq15(x,32767-mulq15((sine_i(s->slow)+32768)/2,trem*180));
  kv_emit(s,&f,x,m,out,i);s->ph[0]+=inc;s->ph[1]+=it;s->ph[2]+=ia;s->slow+=trem_inc; /* 4Hz */
 }
 s->body=b1;s->tine=t1;s->attack=a1;orbit_bridge_apply(&s->bridge,out,n,first,last);
}
static void vector_weights(int32_t x,int32_t y,int32_t w[4]){
 x=clamp(x,0,32768);y=clamp(y,0,32768);
 w[0]=((32768-x)*y)>>15;w[1]=(x*y)>>15;w[2]=((32768-x)*(32768-y))>>15;w[3]=32768-w[0]-w[1]-w[2];
}
static int32_t vector_read(unsigned corner,unsigned band,uint32_t phase){
 const int16_t *a=vector_tables[corner][band];unsigned j=phase>>26;
 return a[j]+(((a[(j+1u)&63u]-a[j])*(int32_t)((phase>>11)&32767u))>>15);
}
static void vector_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 if(!n)return;if(n>CTL)n=CTL;
 kv_voice_t *s=kv_state(t,v);int32_t first=out[0],last=out[n-1];tsvf_t f;kv_filter(t,v,s,m,&f);
 int32_t motion=clamp(t->p[P_E2],0,127),target[3]={clamp(t->p[P_E0],0,127)*256,clamp(t->p[P_E1],0,127)*256,clamp(t->p[P_E3]+((m->shape-16384)>>8),0,127)*256};
 /* Conservative adjacent mip crossfade. Richer table is used only while its
  * highest partial stays below 0.45*FS. At a boundary both sides agree. */
 static const uint8_t harmonics[5]={1,2,4,8,15};unsigned band=0;
 while(band<4u&&m->inc<0x73000000u/harmonics[band+1u])band++;
 int32_t blend=32768;
 if(band){uint32_t hi=0x73000000u/harmonics[band],lo=hi/2u;blend=m->inc<=lo?32768:(int32_t)(((hi-m->inc)/( (hi-lo)/32768u+1u)));blend=clamp(blend,0,32768);}
 int32_t x=0,y=0;
 int32_t width=clamp(t->p[P_FM2_ATK],0,127),edge=clamp(t->p[P_FM2_DEC],0,127),path=clamp(t->p[P_FM2_REL],0,127);
 uint32_t speed=10000u+(uint32_t)motion*400u+(uint32_t)(127-clamp(t->p[P_FM2_SUS],0,127))*2000u;
 for(unsigned i=0;i<n;i++){
  for(unsigned k=0;k<3;k++)s->xy[k]=kv_slew(s->xy[k],target[k]);
  x=s->xy[0];y=s->xy[1];
  if(motion){x+=(sine_i(s->slow)*motion)>>10;y+=(sine_i(s->slow+0x40000000u+(uint32_t)path*0x800000u)*motion)>>10;s->slow+=speed;}
  x=(clamp(x,0,32512)*16513+8192)>>14;y=(clamp(y,0,32512)*16513+8192)>>14;
  x=clamp(x+((x-16384)*width)/254,0,32768);
  int32_t w[4];vector_weights(x,y,w);int32_t sum=0;
  for(unsigned k=0;k<4;k++){
   int32_t a=vector_read(k,band,s->ph[0]);if(band)a=novel_lerp(vector_read(k,band-1u,s->ph[0]),a,(uint32_t)blend);
   sum+=mulq15(a,w[k]);
  }
  int32_t pure=sine_i(s->ph[0]);int32_t color=s->xy[2];
  sum=novel_lerp(pure,sum,(uint32_t)clamp(color,0,32768));
  if(edge)sum=novel_lerp(sum,softclip(sum+mulq15(sum,edge*128)),(uint32_t)edge*128u);
  kv_emit(s,&f,sum,m,out,i);s->ph[0]+=m->inc;
 }
 /* The spare fourth phase is a UI-only packed position: one store per block. */
 s->ph[3]=(uint32_t)x|((uint32_t)y<<16);
 orbit_bridge_apply(&s->bridge,out,n,first,last);
}
#define KV_PD(l,f,a,b,d) {l,f,a,b,d,0,0}
#define TINES_COLS KV_PD("BELL",F_PCT,0,127,45),KV_PD("BARK",F_PCT,0,127,25),KV_PD("DECAY",F_PCT,0,127,95),KV_PD("TREM",F_PCT,0,127,0)
#define VECTOR_COLS KV_PD("X",F_PCT,0,127,64),KV_PD("Y",F_PCT,0,127,64),KV_PD("MOTION",F_PCT,0,127,0),KV_PD("COLOR",F_PCT,0,127,100)
#define KV_FILTER_COLS KV_PD("CUT",F_CUTOFF,0,127,112),KV_PD("RES",F_PCT,0,110,8),KV_PD("ENV AMT",F_BIPCT,-64,63,0),KV_PD("KEYTRK",F_PCT,0,127,0)
static const char *const KV_LFO_NAMES[]={"SIN","TRI","SAW","SQR","S&H"};
static const char *const KV_SRC[]={"OFF","LFO","ENV","VEL","KEY","RAND","MODW","AT","EXPR"};
static const char *const KV_DST_T[]={"OFF","PITCH","CUT","SHP","AMP","PAN","DIST","CHO","DLY","REV","RATE","VIB","BELL","BARK","DECAY","TREM","CUTOFF","RES","ENV AMT","KEYTRK"};
static const char *const KV_DST_V[]={"OFF","PITCH","CUT","SHP","AMP","PAN","DIST","CHO","DLY","REV","RATE","VIB","X","Y","MOTION","COLOR","CUTOFF","RES","ENV AMT","KEYTRK"};
#define KV_MOD_PAGE(n,d) {"MOD " n,{{"SRC",F_ENUM,0,8,0,KV_SRC,0},{"DST",F_ENUM,0,19,0,d,0},KV_PD("AMT",F_BIPCT,-64,63,0),{0}}}
#define KV_MOD_PAGES(d) KV_MOD_PAGE("1",d),KV_MOD_PAGE("2",d),KV_MOD_PAGE("3",d),KV_MOD_PAGE("4",d)
#define KV_COMMON_PAGES \
 {"FILTER",{KV_FILTER_COLS}}, \
 {"FILT ENV",{KV_PD("ATK",F_TIME,0,127,0),KV_PD("DEC",F_TIME,0,127,70),KV_PD("SUS",F_PCT,0,127,0),KV_PD("REL",F_TIME,0,127,55)}}, \
 {"AMP ENV",{KV_PD("ATK",F_TIME,0,127,0),KV_PD("DEC",F_TIME,0,127,70),KV_PD("SUS",F_PCT,0,127,100),KV_PD("REL",F_TIME,0,127,55)}}, \
 {"LFO",{KV_PD("RATE",F_LFOHZ,0,127,40),{"WAVE",F_ENUM,0,4,0,KV_LFO_NAMES,0},KV_PD("VIBRATO",F_PCT,0,127,0),KV_PD("WAH",F_PCT,0,127,0)}}, \
 {"LFO+",{KV_PD("SHAPE",F_BIPCT,-64,63,0),KV_PD("TREM",F_PCT,0,127,0),KV_PD("FADE",F_TIME,0,127,0),KV_PD("PHASE",F_INT,0,127,0)}}
#define KV_EXTRA_IDS {P_FM2_ATK,P_FM2_DEC,P_FM2_SUS,P_FM2_REL}
#define TINES_EXTRA KV_PD("BODY",F_PCT,0,127,0),KV_PD("STRIKE",F_PCT,0,127,0),KV_PD("DAMP",F_PCT,0,127,0),KV_PD("TREM RATE",F_PCT,0,127,0)
#define VECTOR_EXTRA KV_PD("WIDTH",F_PCT,0,127,0),KV_PD("EDGE",F_PCT,0,127,0),KV_PD("ORBIT RATE",F_PCT,0,127,0),KV_PD("PATH",F_PCT,0,127,0)
static const eng_page_t TINES_PAGES[]={{"SOUND",{TINES_COLS}},KV_COMMON_PAGES,KV_MOD_PAGES(KV_DST_T),{"CHARACTER",{TINES_EXTRA}}};
static const eng_page_t VECTOR_PAGES[]={{"SOUND",{VECTOR_COLS}},KV_COMMON_PAGES,KV_MOD_PAGES(KV_DST_V),{"VECTOR PATH",{VECTOR_EXTRA}}};
static const uint8_t KV_IDS[6][4]={{P_E0,P_E1,P_E2,P_E3},{P_E4,P_E5,P_E6,P_E7},{P_FM1_ATK,P_FM1_DEC,P_FM1_SUS,P_FM1_REL},{P_ATK,P_DEC,P_SUS,P_REL},{P_LRATE,P_LWAVE,P_LD_PIT,P_LD_FLT},{P_LD_SHP,P_LD_AMP,P_LFADE,P_LPHASE}};
static const uint8_t KV_EXTRA[4]=KV_EXTRA_IDS;
static int32_t kv_get(const track_t *t,uint32_t p,uint32_t c){return p==10&&c<4?(c==2?127-t->p[KV_EXTRA[c]]:t->p[KV_EXTRA[c]]):p<6&&c<4?t->p[KV_IDS[p][c]]:p<10&&p>=6&&c<3?t->p[P_M1SRC+(p-6)*3+c]:0;}
static void kv_set(track_t *t,uint32_t p,uint32_t c,int32_t v){if(p<11&&c<(p<6||p==10?4u:3u)){const eng_page_t *pg=t->eng_req==ENGI_TINES?TINES_PAGES:VECTOR_PAGES;const param_desc_t *d=&pg[p].col[c];t->p[p==10?KV_EXTRA[c]:p<6?KV_IDS[p][c]:P_M1SRC+(p-6)*3+c]=(int16_t)(p==10&&c==2?127-clamp(v,d->min,d->max):clamp(v,d->min,d->max));}}
static void kv_defaults(track_t *t){for(unsigned k=0;k<4;k++)t->p[KV_EXTRA[k]]=k==2?127:0;t->p[P_FM1_ATK]=0;t->p[P_FM1_DEC]=70;t->p[P_FM1_SUS]=0;t->p[P_FM1_REL]=55;}
/* Native UI for the existing four-slot modulation matrix; no new storage. */
static const eng_screen_t KV_SCREENS[]={
 {.sec=0,.pg={0,255},.title="SOUND",.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}}},
 {.sec=0,.pg={10,255},.title="CHARACTER",.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}}},
 {.sec=1,.pg={1,255},.title="FILTER",.band=ENG_B_FILTER,.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}}},
 {.sec=1,.pg={2,255},.title="FILTER ENV",.band=ENG_B_ENV},
 {.sec=2,.pg={3,255},.title="AMP ENV",.band=ENG_B_ENV},
 {.sec=3,.pg={4,5},.title="LFO",.cell={{ENG_C_RULE,ENG_C_RULE,ENG_C_BAR,ENG_C_BAR},{ENG_C_BAR,ENG_C_BAR,ENG_C_RULE,ENG_C_RULE}}}
};
static int32_t kv_mod_dst(const track_t *t,uint32_t pg,uint32_t col){(void)t;if(pg==255u)return col>=P_E0&&col<=P_E7?(int32_t)(12+col-P_E0):-1;return pg<2u&&col<4u?(int32_t)(12+pg*4+col):-1;}
static const eng_deep_t TINES_DEEP={.npages=11,.pages=TINES_PAGES,.section={0,1,3,4,6,255,255,255},.get=kv_get,.set=kv_set,.mod_dst=kv_mod_dst,.screens=KV_SCREENS,.nscreens=6};
static const eng_deep_t VECTOR_DEEP={.npages=11,.pages=VECTOR_PAGES,.section={0,1,3,4,6,255,255,255},.get=kv_get,.set=kv_set,.mod_dst=kv_mod_dst,.screens=KV_SCREENS,.nscreens=6};
static const preset_t TINES_PRESETS[]={
 {"SOFT RHODES",{35,20,102,20,105,5,0,20},{0,85,100,55},0,0,FX(0,0,8,22)},
 {"HARD TINES",{90,100,88,0,116,8,15,30},{0,85,90,48},0,0,FX(0,0,5,14)},
 {"GLASS KEYS",{120,10,108,0,120,0,0,10},{0,90,100,68},0,0,FX(0,0,12,35)},
 {"HOUSE EP",{60,70,82,0,100,12,25,15},{0,75,65,40},0,0,FX(0,0,10,18)},
 {"WARM MALLET",{35,40,62,0,85,10,12,25},{0,65,40,40},0,0,FX(0,0,12,24)},
 {"DREAM KEYS",{75,15,127,40,105,6,0,0},{45,100,120,90},0,0,FX(0,20,25,55)}
};
static const preset_t VECTOR_PRESETS[]={
 {"HOUSE STAB",{102,102,0,115,105,12,20,10},{0,60,30,30},0,0,FX(0,0,10,16)},
 {"DIGITAL KEYS",{83,38,6,110,115,6,0,10},{0,75,85,50},0,0,FX(0,12,12,25)},
 {"VINTAGE PAD",{25,102,44,75,95,8,10,0},{60,90,110,85},0,0,FX(0,24,20,45)},
 {"GLASS CHORD",{121,13,15,127,120,4,0,0},{5,80,100,65},0,0,FX(0,0,20,38)},
 {"SOFT VECTOR",{13,114,0,90,106,4,0,0},{10,90,110,65},0,0,FX(0,12,12,28)},
 {"MOVING CHORD",{70,70,57,110,110,10,15,0},{40,95,110,75},0,0,FX(0,20,20,40)}
};
static const engine_t ENG_TINES={.name="TINES",.page_title={"SOUND","FILTER"},.edit={TINES_COLS,KV_FILTER_COLS},.presets=TINES_PRESETS,.npresets=NELEM(TINES_PRESETS),.note_on=kv_note,.render=tines_render,.poly=6,.cap=cloud_cap,.units=cloud_units,.knob={P_E0,P_E1,P_E2,P_E3},.deep=&TINES_DEEP};
static const engine_t ENG_VECTOR={.name="VECTOR",.page_title={"SOUND","FILTER"},.edit={VECTOR_COLS,KV_FILTER_COLS},.presets=VECTOR_PRESETS,.npresets=NELEM(VECTOR_PRESETS),.note_on=kv_note,.render=vector_render,.poly=6,.cap=cloud_cap,.units=cloud_units,.knob={P_E0,P_E1,P_E2,P_E3},.deep=&VECTOR_DEEP};
#undef KV_PD
#undef KV_FILTER_COLS
#undef KV_COMMON_PAGES
#undef TINES_COLS
#undef VECTOR_COLS
