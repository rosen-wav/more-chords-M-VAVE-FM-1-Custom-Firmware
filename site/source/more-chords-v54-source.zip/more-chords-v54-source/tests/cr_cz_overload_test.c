/* Target CPU overload is injected explicitly: host mix_block never asks to shed. */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void) {
 unsigned engine,bass,preset,q,k,checks=0;int rot,tp,fails=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 /* Unowned raw/MIDI notes retain the original overload age policy. */
 clear(ENGI_CZ,0,0);settle();
 {unsigned notes[5]={60,64,67,69,71};for(k=0;k<5;k++)trk_note_on(&trk[0],notes[k],100);}
 settle();shed_voice();settle();checks++;if(held(64))fails++;

 for(engine=0;engine<2;engine++)for(bass=0;bass<2;bass++)
 for(preset=0;preset<(engine?1u:ENG_CZ.npresets);preset++)
 for(q=0;q<2;q++)for(rot=-3;rot<=5;rot++)for(tp=-12;tp<=12;tp+=12) {
  clear(engine?ENGI_PROPHET:ENGI_CZ,bass,tp);
  if(!engine) {cu_load(&trk[0],ENGI_CZ,preset,0);settle();trk[0].p[P_TRANS]=tp;}
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);
  cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
  cr.voicing=rot;cr_key(&cr,60,100,1);settle();
  checks++;if(!complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,60))fails++;
  /* Actual CPU guard, followed by the normal fade/render path. */
  {unsigned before=shed_count;shed_voice();settle();checks++;
   if(shed_count!=before+1u || !third_present()) {
    if(fails<8)printf("FAIL CPU engine=%u bass=%u preset=%u minor=%u voicing=%d tp=%d\n",engine,bass,preset,q,rot,tp);fails++;
   }
  }
  /* A second overload still protects the third; guard remains operational. */
  shed_voice();settle();checks++;if(!third_present())fails++;
  for(k=0;k<cr.v[0].nnotes;k++) {
   uint32_t note=cr.v[0].notes[k],rank=cr_synth_chord_rank(&trk[0],cr_tr_note(0,note));
   uint32_t pc=(note+12u-60u%12u)%12u;
   if(pc==(q?3u:4u)){checks++;if(rank!=6u)fails++;}
  }
  /* Five-note chords containing a sixth exercise the guard's first sacrifice
   * directly, including inversions in which the sixth is the lowest note. */
  clear(engine?ENGI_PROPHET:ENGI_CZ,bass,tp);
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_9,1);
  cr.voicing=rot;cr_key(&cr,60,100,1);settle();
  if(!engine) {
   unsigned sixth=128u;
   for(k=0;k<cr.v[0].nnotes;k++)if((cr.v[0].notes[k]+12u)%12u==9u)sixth=cr_tr_note(0,cr.v[0].notes[k]);
   checks++;if(sixth==128u || !held(sixth))fails++;
   shed_voice();settle();checks++;if(held(sixth) || !third_present())fails++;
  }
 }
 printf("CPU overload chord protection: %u checks, %d failures\n",checks,fails);return !!fails;
}
