#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void) {
 unsigned preset,bengine; int rot,fail=0,checks=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 for(preset=0;preset<ENG_CZ.npresets;preset++)for(bengine=0;bengine<NENGINES;bengine++)for(rot=-3;rot<=5;rot++) {
  clear(ENGI_CZ,0,0);cu_load(&trk[0],ENGI_CZ,preset,0);cu_load(&trk[1],bengine,0,1);settle();
  cr_mod(&cr,CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
  cr.voicing=rot;cr_key(&cr,60,100,1);settle();checks++;
  if(!complete_chord_matches(CR_Q_MAJ,60)) {if(fail++<10)printf("FAIL before preset %u basseng %u rot %d\n",preset,bengine,rot);}
  cr_set_bass(&cr,1);cr_key(&cr,60,0,0);cr_key(&cr,60,100,1);settle();checks++;
  if(!complete_chord_matches(CR_Q_MAJ,60)) {if(fail++<10)printf("FAIL after preset %u basseng %u rot %d\n",preset,bengine,rot);}
 }
 printf("CZ factory/BASS reproduction: %d checks, %d failures\n",checks,fail);return !!fail;
}
