/* SPDX-License-Identifier: GPL-3.0-only
 * Morph: two independently rendered patches, equal-power mix before FX.
 * Uses the otherwise unused third ChoralRoot part for B. Parts 0/1 and
 * CPU1 scheduling stay intact; core1 performs B after its normal bass job.
 */
static const uint8_t MORPH_SOURCE[] = {ENGI_FM6,
#if FELUCCA_QUAD
 ENGI_QUAD,
#endif
#if FELUCCA_VA
 ENGI_VA,
#endif
 2,
#if FELUCCA_ANALOG
 0,
#endif
#if FELUCCA_SAMPLE
 4,
#endif
#if 0 /* GRAIN has one shared A/B source pair: no independent global-Morph instance. */
 8,
#endif
#if FELUCCA_SLICE
 13,
#endif
 ENGI_CLOUD, ENGI_SWARM, ENGI_CLUSTER,
};
static const char *const MORPH_SOURCE_NAMES[] = {"FM6",
#if FELUCCA_QUAD
 "QUAD",
#endif
#if FELUCCA_VA
 "VA",
#endif
 "PHASE",
#if FELUCCA_ANALOG
 "ANALOG",
#endif
#if FELUCCA_SAMPLE
 "SAMPLE",
#endif
#if 0 /* GRAIN has one shared A/B source pair: no independent global-Morph instance. */
 "GRAIN",
#endif
#if FELUCCA_SLICE
 "SLICE",
#endif
 "CLOUD", "SWARM", "CLUSTER",
};
static const char *const MORPH_B_SOURCE_NAMES[] = {"Same as A", "FM6",
#if FELUCCA_QUAD
 "QUAD",
#endif
#if FELUCCA_VA
 "VA",
#endif
 "PHASE",
#if FELUCCA_ANALOG
 "ANALOG",
#endif
#if FELUCCA_SAMPLE
 "SAMPLE",
#endif
#if 0 /* GRAIN has one shared A/B source pair: no independent global-Morph instance. */
 "GRAIN",
#endif
#if FELUCCA_SLICE
 "SLICE",
#endif
 "CLOUD", "SWARM", "CLUSTER",
};
_Static_assert(NELEM(MORPH_B_SOURCE_NAMES)==NELEM(MORPH_SOURCE)+1u,"B source names match append-only source list");
#define P_MORPH_BSOURCE P_FM4_LEVEL /* dormant for Morph; legacy 127 means Same as A */

static const char *const MORPH_SPEED[] = {"100ms","100ms","101ms","104ms","107ms","112ms","117ms","124ms","131ms","139ms","148ms","159ms","170ms","182ms","196ms","210ms","225ms","241ms","258ms","276ms","295ms","316ms","337ms","359ms","382ms","406ms","431ms","457ms","484ms","511ms","540ms","570ms","601ms","633ms","666ms","700ms","734ms","770ms","807ms","844ms","883ms","923ms","964ms","1.0s","1.0s","1.1s","1.1s","1.2s","1.2s","1.3s","1.3s","1.4s","1.4s","1.5s","1.5s","1.6s","1.6s","1.7s","1.7s","1.8s","1.9s","1.9s","2.0s","2.0s","2.1s","2.2s","2.2s","2.3s","2.4s","2.4s","2.5s","2.6s","2.6s","2.7s","2.8s","2.9s","2.9s","3.0s","3.1s","3.2s","3.2s","3.3s","3.4s","3.5s","3.6s","3.6s","3.7s","3.8s","3.9s","4.0s","4.1s","4.2s","4.2s","4.3s","4.4s","4.5s","4.6s","4.7s","4.8s","4.9s","5.0s","5.1s","5.2s","5.3s","5.4s","5.5s","5.6s","5.7s","5.8s","5.9s","6.0s","6.1s","6.2s","6.4s","6.5s","6.6s","6.7s","6.8s","6.9s","7.0s","7.2s","7.3s","7.4s","7.5s","7.6s","7.8s","7.9s","8.0s"};
static const char *const MORPH_MODE[] = {"Manual","Up and Down","Random"};
static const char *const MORPH_TRIGGER[] = {"Free","Chord"};
enum { MP_SOURCE,MP_PRESET,MP_POSITION,MP_MODE,MP_SPEED,MP_AMOUNT,MP_TRIGGER,MP_SEED,MP_PRESET_B,MP_BSOURCE };
#define MORPH_FIELDS 160u
_Static_assert(MORPH_FIELDS>=FP_NAME+7u,"Morph must fit the full FM6 patch plus common/macros");
/* kind0 generic; kind1 deep column; kind2 FM6 byte; kind3 VA; kind4 QUAD. */
typedef struct {int32_t current_q8;int16_t base,a,b,current,lo,hi;uint8_t kind,id,col,discrete,soften;} morph_field_t;
static struct {
 morph_field_t f[MORPH_FIELDS];
 int16_t base_p[P_COUNT], saved[P_COUNT];
 const char *names[256];
 volatile int16_t control[8];
 volatile uint8_t control_valid;
 uint8_t base_blob[ENG_BLOB_MAX];
 uint32_t rng, revision, elapsed, chord_events, ramp, prepare_owner[32];
 int32_t gain,pcm_gain;
 uint16_t source,source_b,preset,preset_b,seed,amount,amount_q8,n,pos,target,motion_from,motion_to;
 uint32_t motion_time;
 uint8_t ready,inside,loaded,mode,trigger,roll_choice,going_up,reroll,discrete_b;
} morph __attribute__((section(".pool")));
/* Part 2 is idle under ChoralRoot (part 0 = chord, part 1 = bass).
 * Its existing voice and native engine state provide patch B at no cost in
 * new track allocation. The pre-FX PCM buffers are CPU1-owned when split. */
static uint8_t morph_dual;
static int32_t morph_b_pcm[CTL] __attribute__((section(".pool")));
static int32_t morph_b_side[CTL] __attribute__((section(".pool")));
static uint8_t morph_b_side_on;
static uint32_t morph_b_nr;
static int32_t morph_gain_a=32767,morph_gain_b;
static const uint16_t morph_power[129] = {
0,2896,4096,5016,5792,6476,7094,7663,8192,8689,9159,9606,10033,10442,10837,11217,11585,11941,12288,12624,12952,13272,13584,13890,14189,14481,14768,15049,15325,15597,15863,16125,16384,16638,16888,17134,17377,17617,17854,18087,18317,18545,18770,18992,19211,19428,19643,19855,20066,20274,20479,20683,20885,21085,21283,21479,21673,21866,22057,22246,22434,22620,22805,22988,23170,23350,23529,23707,23883,24058,24232,24404,24575,24745,24914,25082,25249,25414,25579,25742,25905,26066,26226,26386,26544,26702,26858,27014,27169,27323,27476,27628,27780,27930,28080,28229,28377,28524,28671,28817,28962,29107,29250,29393,29536,29677,29818,29959,30098,30237,30376,30514,30651,30787,30923,31059,31193,31327,31461,31594,31727,31858,31990,32121,32251,32381,32510,32639,32767
};
/* At 0: only A; at 127: only B. Piecewise-linear sqrt preserves the
 * constant-power law without a floating-point sqrt in the audio callback. */
static void morph_coeff(int32_t *a,int32_t *b){
 uint32_t pos=((uint32_t)morph.pos*morph.amount_q8+12800u)/25600u;
 uint32_t index=(pos*128u+16256u)/32512u;
 if(index>128u)index=128u;
 *a=morph_power[128u-index];*b=morph_power[index];
}
static void morph_shadow_install(track_t *t,const engine_t *e,uint32_t preset){
 track_t *b=&trk[2];
 /* Never copy the voice state or the sequencing state of A into B. */
 for(uint32_t i=0;i<P_COUNT;i++)b->p[i]=t->p[i];
 b->engine=b->eng_req=(uint8_t)morph.source;
 b->preset=(uint8_t)preset;
 b->user=0;b->trim=0;b->nmono=b->mono_note=0;b->nheld=0;
 b->xp_n=b->xf=b->xf_on=b->tail=0;b->lfo_ph=0;b->lfo_val=0;b->lfo_fade=32767;
 for(uint32_t i=0;i<NVOICE;i++){
  b->v[i].active=b->v[i].gate=b->v[i].stage=0;
 }
 eng_state_clear(2);
 /* Native FM6/VA/QUAD patches are stored per physical part. */
 fm6_track_loaded(b);
 if(e->deep && e->deep->blob_get && e->deep->blob_set && e->deep->blob_size<=ENG_BLOB_MAX){
  uint8_t blob[ENG_BLOB_MAX];
  e->deep->blob_get(t,blob);e->deep->blob_set(b,blob);
 }
#if FELUCCA_VA
 if(morph.source==ENGI_VA)memcpy(va_patch[2],va_patch[0],sizeof va_patch[0]);
#endif
#if FELUCCA_QUAD
 if(morph.source==ENGI_QUAD)memcpy(quad_patch[2],quad_patch[0],sizeof quad_patch[0]);
#endif
 morph_dual=1;
}
static void trk_note_on(track_t *t,uint32_t note,uint32_t vel);
static uint32_t morph_is_quad(uint32_t src)
{
#if FELUCCA_QUAD
 return src==ENGI_QUAD;
#else
 (void)src;return 0;
#endif
}
static uint32_t morph_rand(void){uint32_t x=morph.rng?morph.rng:0x6c8e9cf5u;x^=x<<13;x^=x>>17;x^=x<<5;return morph.rng=x;}
static uint32_t morph_source_index(const track_t *t){int32_t i=t->p[P_E0];return i>=0&&i<(int32_t)NELEM(MORPH_SOURCE)?(uint32_t)i:0u;}
static void morph_publish(const track_t *t){for(uint32_t i=0;i<8;i++)morph.control[i]=t->p[P_E0+i];morph.control_valid=1;}
static int32_t morph_control(const track_t *t,uint32_t k){return morph.control_valid?morph.control[k]:t->p[P_E0+k];}
static uint32_t morph_ui_source(const track_t *t){int32_t i=morph_control(t,MP_SOURCE);return i>=0&&i<(int32_t)NELEM(MORPH_SOURCE)?(uint32_t)i:0u;}
static uint32_t morph_ui_b_index(const track_t *t){int32_t i=t->p[P_MORPH_BSOURCE];return i>=0&&i<=(int32_t)NELEM(MORPH_SOURCE)?(uint32_t)i:0u;}
static uint32_t morph_ui_b_source(const track_t *t){uint32_t i=morph_ui_b_index(t);return i?MORPH_SOURCE[i-1u]:MORPH_SOURCE[morph_ui_source(t)];}

static const engine_t *eng_audio(const track_t *t)
{
 if(t==&trk[0] && t->engine==ENGI_MORPH){
  uint32_t e=(morph.inside || (morph.ready && t->eng_req!=ENGI_MORPH))?morph.source:MORPH_SOURCE[morph_source_index(t)];
  return ENGINES[e];
 }
 return ENGINES[eng_idx(t->engine)];
}
static int morph_has(const char *s,const char *needle){uint32_t a,b;if(!s)return 0;for(a=0;s[a];a++){for(b=0;needle[b]&&s[a+b]==needle[b];b++);if(!needle[b])return 1;}return 0;}
/* Only topology and table selectors are discrete. A numeric control does
 * not become a switch just because its UI supplies display names (VA FTYPE,
 * QUAD offsets), or because it controls tuning, spread or key tracking. */
static int morph_protected(const param_desc_t *d)
{
 const char *s=d->label;
 return d->fmt==F_ENUM || d->fmt==F_ONOFF ||
  morph_has(s,"ALG") || morph_has(s,"RATIO") || morph_has(s,"WAV#") ||
  (d->names && morph_has(s,"DCY"));
}
static void morph_add(uint32_t kind,uint32_t id,uint32_t col,int32_t base,int32_t lo,int32_t hi,int32_t cap)
{
 if(morph.n>=MORPH_FIELDS || hi<=lo)return;
 morph_field_t *f=&morph.f[morph.n++];
 f->discrete=f->soften=0;f->kind=kind;f->id=id;f->col=col;f->base=f->a=f->b=f->current=clamp(base,lo,hi);
 f->current_q8=f->current*256;f->lo=lo;f->hi=hi;(void)cap;
}
/* E7 stores B (low eight bits) and a six-bit random seed. The marked
 * preset tail encodes this in seven-bit chunks; no storage layout changes. */
static uint32_t morph_b(const track_t *t){return (uint16_t)t->p[P_E7]&255u;}
static void morph_patch_params(track_t *t,const engine_t *e,uint32_t pi)
{
 const preset_t *p=&e->presets[pi];
 for(uint32_t i=0;i<P_COUNT;i++)t->p[i]=TP[i].def;
 for(uint32_t i=0;i<8;i++)t->p[P_E0+i]=p->e[i];
 for(uint32_t i=0;i<4;i++)t->p[P_ATK+i]=p->env[i];
 t->p[P_ED_FLT]=p->fenv;t->eng_req=morph.source;t->preset=(uint8_t)pi;
 if(morph.source==ENGI_CLUSTER)cluster_preset_to(t,pi);

 fm6_track_loaded(t);
}
static void morph_load(track_t *t)
{
 uint32_t src=MORPH_SOURCE[morph_source_index(t)];const engine_t *e=ENGINES[src];
 uint32_t bsrc=morph_ui_b_source(t);const engine_t *eb=ENGINES[bsrc];
 uint32_t pa=clamp(t->p[P_E1],0,e->npresets-1),pb=clamp(morph_b(t),0,eb->npresets-1),pb_same=clamp(pb,0,e->npresets-1);
 const eng_deep_t *deep=e->deep;
 uint8_t old_req=t->eng_req,old_preset=t->preset;int16_t old[P_COUNT];memcpy(old,t->p,sizeof old);
 morph.source=src;morph.source_b=bsrc;morph.preset=pa;morph.preset_b=pb;morph.n=0;
 memset(morph.prepare_owner,0,sizeof morph.prepare_owner);
 morph_patch_params(t,e,pa);memcpy(morph.base_p,t->p,sizeof t->p);
 if(deep && deep->blob_get && deep->blob_set && deep->blob_size<=ENG_BLOB_MAX)deep->blob_get(t,morph.base_blob);
 static const uint8_t common[]={P_ATK,P_DEC,P_SUS,P_REL,P_ED_FLT};
 for(uint32_t i=0;i<NELEM(common);i++){
  uint32_t id=common[i];morph_add(0,id,0,t->p[id],TP[id].min,TP[id].max,0);
 }
 if(src==ENGI_FM6){
  morph_add(0,P_E2,0,t->p[P_E2],-64,63,0);
  morph_add(0,P_E6,0,t->p[P_E6],0,127,0);
  fm6_eff[0].ok=0;fm6_eff_build(t);
  for(uint32_t i=0;i<FP_NAME;i++){
   morph_add(2,i,0,fm6_eff[0].p[i],0,fm6_max(i),0);
   uint32_t op=i%FP_OP;
   morph.f[morph.n-1].discrete=(uint8_t)(i==FP_ALG || i==FP_LFW || i==FP_OKS || i==FP_LKS ||
    (i<126u && (op==FP_MODE || op==FP_FC || op==FP_FF || op==FP_LC || op==FP_RC)));
  }
 }
#if FELUCCA_VA
 else if(src==ENGI_VA){
  for(uint32_t i=0;i<VA_NP;i++){
   va_rng_t range=va_range(i);uint32_t before=morph.n;
   morph_add(3,i,0,va_patch[0][i],range.min,range.max,0);
   if(morph.n==before)continue;
   for(uint32_t pg=0;pg<VA_NPAGES;pg++)for(uint32_t c=0;c<4;c++)if(VA_MAP[pg][c]==i)
    morph.f[before].discrete|=(uint8_t)morph_protected(&VA_PAGES[pg].col[c]);
  }
 }
#endif
#if FELUCCA_QUAD
 else if(src==ENGI_QUAD){
  for(uint32_t i=0;i<QP_NP;i++){
   quad_rng_t range=quad_range(i);uint32_t before=morph.n;
   morph_add(4,i,0,quad_patch[0][i],range.min,range.max,0);
   if(morph.n==before)continue;
   for(uint32_t pg=0;pg<QUAD_NPAGES;pg++)for(uint32_t c=0;c<4;c++)if(QUAD_MAP[pg][c]==i)
    morph.f[before].discrete|=(uint8_t)morph_protected(&QUAD_PAGES[pg].col[c]);
  }
 }
#endif
 else for(uint32_t i=0;i<8;i++){
  const param_desc_t *d=e->desc?e->desc(t,i):0;if(!d)d=&e->edit[i];
  uint32_t before=morph.n;morph_add(0,P_E0+i,0,t->p[P_E0+i],d->min,d->max,0);
  if(morph.n!=before)morph.f[before].discrete=(uint8_t)morph_protected(d);
 }
 morph_patch_params(t,e,pb_same);if(src==ENGI_FM6){fm6_eff[0].ok=0;fm6_eff_build(t);}
 morph_shadow_install(t,e,pb_same);
 for(uint32_t i=0;i<morph.n;i++){
  morph_field_t *f=&morph.f[i];int32_t v=0;if(f->kind==0)v=t->p[f->id];else if(f->kind==1)v=deep->get(t,f->id,f->col);else if(f->kind==2)v=fm6_eff[0].p[f->id];
#if FELUCCA_VA
  if(f->kind==3)v=va_patch[0][f->id];
#endif
#if FELUCCA_QUAD
  if(f->kind==4)v=quad_patch[0][f->id];
#endif
  if(f->kind==0 && f->id>=P_E0 && f->id<=P_E7 && src!=ENGI_FM6){
   const param_desc_t *d=e->desc?e->desc(t,f->id-P_E0):0;
   if(!d)d=&e->edit[f->id-P_E0];
   f->discrete|=(uint8_t)morph_protected(d);
  }
  /* Dynamic pages can widen with another topology; both valid endpoints
   * define the interpolation bounds, rather than clipping B to A's range. */
  if(v<f->lo)f->lo=v;if(v>f->hi)f->hi=v;f->b=(int16_t)v;
 }
 /* Keep FM coarse/fine/mode together: independent interpolation invents
  * unrelated, often inharmonic ratios. Calm only the transition's modulation;
  * output operators (in either endpoint algorithm) keep their full levels. */
 uint32_t changing=0,carriers=0;
 for(uint32_t i=0;i<morph.n;i++){
  morph_field_t *f=&morph.f[i];
  if(f->discrete && f->a!=f->b)changing=1;
  if(f->kind==2 && f->id==FP_ALG)
   carriers=fm6_carriers(f->a)|fm6_carriers(f->b);
 }
 if(changing)for(uint32_t i=0;i<morph.n;i++){
  morph_field_t *f=&morph.f[i];
  if(f->kind==2){
   if(f->id==FP_FB)f->soften=1;
   if(f->id<126u && f->id%FP_OP==FP_OL && !(carriers&(1u<<(f->id/FP_OP))))f->soften=2;
  }
#if FELUCCA_QUAD
  if(f->kind==4 && f->id==QP_FDBK)f->soften=1;
#endif
#if FELUCCA_VA
  if(f->kind==3 && (f->id==VA_RES || f->id==VA_DRIVE))f->soften=1;
#endif
 }
 /* Cross-engine B has its own native state/patch; A's parameter interpolation
  * metadata stays A-local. The audio mix always uses independent endpoints. */
 if(bsrc!=src){morph.source=bsrc;morph_patch_params(t,eb,pb);morph_shadow_install(t,eb,pb);morph.source=src;}
 morph_patch_params(t,e,pa);
 if(deep && deep->blob_set && deep->blob_get && deep->blob_size<=ENG_BLOB_MAX)deep->blob_set(t,morph.base_blob);
 for(uint32_t i=0;i<NVOICE;i++){t->v[i].active=t->v[i].gate=0;t->v[i].stage=0;}t->nmono=t->mono_note=0;eng_state_clear(0);
 memcpy(t->p,old,sizeof old);t->eng_req=old_req;t->preset=old_preset;
 morph.loaded=morph.ready=1;morph.pos=(uint16_t)clamp(t->p[P_E2],0,127)*256u;
 morph.target=morph.motion_from=morph.motion_to=morph.pos;morph.motion_time=0;morph.going_up=1;morph.elapsed=0;morph.ramp=0;morph.gain=morph.pcm_gain=32768;morph.revision++;
 morph_gain_a=32767;morph_gain_b=0;
}
static void morph_apply_position(uint32_t n);
static void morph_sync(track_t *t)
{
 if(t!=&trk[0]||t->engine!=ENGI_MORPH||t->eng_req!=ENGI_MORPH||morph.inside)return;
 t->p[P_E0]=(int16_t)morph_source_index(t);morph_publish(t);
 uint32_t source=MORPH_SOURCE[morph_source_index(t)],pi=(uint32_t)clamp(t->p[P_E1],0,ENGINES[source]->npresets-1);
 uint32_t bsrc=morph_ui_b_source(t),pb=clamp(morph_b(t),0,ENGINES[bsrc]->npresets-1);
 int fresh=!morph.ready||source!=morph.source||bsrc!=morph.source_b||pi!=morph.preset||pb!=morph.preset_b;
 if(fresh)morph_load(t);
 uint16_t amount=clamp(t->p[P_E5],0,100),seed=((uint16_t)t->p[P_E7]>>8)&63u;
 if(fresh||amount!=morph.amount||seed!=morph.seed){
  morph.amount=amount;morph.seed=seed;morph.rng=0x2545f491u^((uint32_t)seed*0x9e3779b9u)^source*131u^pi;
  morph.revision++;
 }
 uint8_t next_mode=(uint8_t)clamp(t->p[P_E3],0,2);
 if(next_mode!=morph.mode){morph.motion_from=morph.motion_to=morph.pos;morph.motion_time=0;}
 morph.mode=next_mode;morph.trigger=(uint8_t)clamp(t->p[P_E6],0,1);
 if(fresh){morph.amount_q8=morph.amount*256u;morph_apply_position(0);}
}
static uint32_t morph_duration(const track_t *t){uint32_t s=clamp(t->p[P_E4],0,127);return FS*(100u+s*s*7900u/16129u)/1000u;}
/* Q15 smoothstep: round only once. Rounding u squared first can make
 * very slow moves backtrack by one unit near their endpoints. */
static int32_t morph_ease(int32_t u){return (int32_t)(((int64_t)u*u*(98304-2*u))>>30);}
static void morph_tick(track_t *t,uint32_t n)
{
 uint32_t duration=morph_duration(t),step=(32512u*n+duration-1u)/duration;if(!step)step=1;
 /* Amount also moves gently: it must not bypass Position's smoothing. */
 int32_t ad=(int32_t)morph.amount*256-morph.amount_q8;
 uint32_t astep=(25600u*n+FS*45u/100u-1u)/(FS*45u/100u);
 morph.amount_q8+=(int16_t)clamp(ad,-(int32_t)astep,(int32_t)astep);
 if(!morph.mode){
  /* The knob controls the AUDIO blend, not a slow interpolation of the patch.
   * Follow manual movements with a short (~20 ms) dezipper; the mixer below
   * also ramps both gains sample-by-sample within every audio block. */
  morph.target=(uint16_t)clamp(t->p[P_E2],0,127)*256u;
  int32_t delta=(int32_t)morph.target-(int32_t)morph.pos;
  uint32_t smooth=FS/50u; /* nominally 20 ms */
  if(!smooth)smooth=1;
  int32_t advance=(int32_t)(((int64_t)delta*(int32_t)n)/(int32_t)smooth);
  if(!advance && delta)advance=delta>0?1:-1;
  if(delta>0 && advance>delta)advance=delta;
  if(delta<0 && advance<delta)advance=delta;
  morph.pos=(uint16_t)((int32_t)morph.pos+advance);
  morph.motion_from=morph.motion_to=morph.pos;morph.motion_time=0;
 }else{
  if(morph.mode==1){
   uint32_t pos=morph.pos;
   if(morph.going_up){pos+=step;if(pos>=32512u){pos=32512u;morph.going_up=0;}}
   else if(pos<=step){pos=0;morph.going_up=1;}else pos-=step;
   morph.pos=morph.target=pos;
   morph.motion_from=morph.motion_to=morph.pos;morph.motion_time=0;
  }else{
   if(!morph.trigger && morph.pos==morph.target)morph.target=(uint16_t)(morph_rand()%32513u);
   if(morph.target!=morph.motion_to){
    morph.motion_from=morph.pos;morph.motion_to=morph.target;morph.motion_time=0;
   }
   /* Random destinations get the same gentle arrival/departure. Speed is
    * the duration of this move, including a retarget on a new chord. */
   if(morph.motion_time<duration){
    morph.motion_time+=n;if(morph.motion_time>duration)morph.motion_time=duration;
    int32_t w=morph_ease((int32_t)((uint64_t)morph.motion_time*32768u/duration));
    int32_t distance=(int32_t)morph.motion_to-morph.motion_from;
    morph.pos=(uint16_t)((int32_t)morph.motion_from+distance*w/32768);
   }else morph.pos=morph.motion_to;
  }
 }
 morph_apply_position(n);
}
static void morph_apply_position(uint32_t n)
{
 /* Smoothstep has zero slope at A/B, so the ping-pong reversals and manual
  * arrivals do not change parameter velocity abruptly. Exact endpoints stay. */
 int32_t u=(int32_t)morph.pos*32768/32512;
 int32_t eased=morph_ease(u);
 int32_t position=((eased*32512)>>15)*morph.amount_q8/25600;
 /* A smooth bell, zero at A/B. The conservative centre reduces feedback
  * and pure modulator levels, never the carriers or the master volume. */
 int32_t x=position*32768/32512;
 int32_t calm=(4*x*(32768-x))>>15;
 calm=(calm*calm)>>15;
 /* 3% hysteresis prevents selector chatter while hovering at halfway. */
 uint32_t side=morph.discrete_b;
 if(!n)side=position>=16256;
 else if(position>=17280)side=1;
 else if(position<=15232)side=0;
 int flip=0;
 for(uint32_t i=0;i<morph.n;i++)if(morph.f[i].discrete && morph.f[i].current!=(side?morph.f[i].b:morph.f[i].a))flip=1;
 (void)flip;
 morph.discrete_b=(uint8_t)side;morph.gain=morph.pcm_gain=32768;
 if(morph_dual)return; /* No parameter interpolation: render both native patches. */
 for(uint32_t i=0;i<morph.n;i++){
  morph_field_t *f=&morph.f[i];
  int32_t sum=f->a*(32512-position)+f->b*position;
  int32_t desired=f->discrete?(side?f->b:f->a)*256:sum*256/32512;
  if(f->soften==1)desired-=desired*calm/131072; /* up to 25% less feedback/resonance */
  else if(f->soften==2){desired-=12*256*calm/32768;if(desired<0)desired=0;}
  if(f->discrete)f->current_q8=desired;
  else if(morph.ramp>n)f->current_q8+=(desired-f->current_q8)*(int32_t)n/(int32_t)morph.ramp;
  else f->current_q8=desired;
  int32_t q=f->current_q8,v=q>=0?(q+128)/256:-((-q+128)/256);
  if(v!=f->current){f->current=v;morph.revision++;}
 }
 if(morph.ramp)morph.ramp=morph.ramp>n?morph.ramp-n:0;

}
static void morph_begin(track_t *t,uint32_t n)
{
 if(t!=&trk[0]||t->engine!=ENGI_MORPH||morph.inside)return;
 /* Sync/tick the UI controls first, then ALWAYS scope source patch A over
  * the render/note-on. The old code did not enter the scope when Morph was
  * selected, which also made morph_fade_pcm silently skip the mix. */
 if(t->eng_req==ENGI_MORPH){morph_sync(t);if(n)morph_tick(t,n);}
 else if(!morph.ready)return;
 memcpy(morph.saved,t->p,sizeof t->p);morph.inside=1;
 for(uint32_t k=0;k<8;k++)t->p[P_E0+k]=morph.base_p[P_E0+k];
 t->p[P_ATK]=morph.base_p[P_ATK];t->p[P_DEC]=morph.base_p[P_DEC];t->p[P_SUS]=morph.base_p[P_SUS];t->p[P_REL]=morph.base_p[P_REL];t->p[P_ED_FLT]=morph.base_p[P_ED_FLT];
 const engine_t *e=ENGINES[morph.source];
 if(morph_dual)return; /* A remains its stored patch throughout the crossfade. */
 for(uint32_t i=0;i<morph.n;i++){
  morph_field_t *f=&morph.f[i];
  if(!f->kind)t->p[f->id]=f->current;
  else if(f->kind==1 && e->deep->get(t,f->id,f->col)!=f->current)e->deep->set(t,f->id,f->col,f->current);
#if FELUCCA_VA
  else if(f->kind==3)va_patch[0][f->id]=(int8_t)f->current;
#endif
#if FELUCCA_QUAD
  else if(f->kind==4)quad_patch[0][f->id]=(int8_t)f->current;
#endif
 }
 /* Mirror native patch macros every block, even if its rounded values stayed
  * unchanged. Source block handlers must never restore the original macros. */
#if FELUCCA_QUAD
 if(morph.source==ENGI_QUAD)quad_macros_out(t);
#endif
#if FELUCCA_VA
 if(morph.source==ENGI_VA)va_macros_out(t);
#endif
}
/* Mix two simultaneously rendered voices before the existing part FX and sends.
 * The gain ramps across a block to prevent zippering during knob movements. */
static void morph_fade_pcm(track_t *t,int32_t *pcm,int32_t *side,uint32_t n){
 if(t!=&trk[0]||t->engine!=ENGI_MORPH||!morph.inside||!morph_dual||!n)return;
 int32_t ga,gb; morph_coeff(&ga,&gb);
 /* A has the ordinary engine-change fade; B must leave with it. */
 if(t->xf_on)gb=gb*(int32_t)t->xf/(int32_t)ENGINE_FADE_BLOCKS;
 for(uint32_t i=0;i<n;i++){
  int32_t a=morph_gain_a+(int32_t)(((int64_t)(ga-morph_gain_a)*(i+1))/n);
  int32_t b=morph_gain_b+(int32_t)(((int64_t)(gb-morph_gain_b)*(i+1))/n);
  pcm[i]=(int32_t)(((int64_t)pcm[i]*a+(int64_t)morph_b_pcm[i]*b)>>15);
  if(side)side[i]=(int32_t)(((int64_t)side[i]*a+(int64_t)morph_b_side[i]*b)>>15);
 }
 morph_gain_a=ga;morph_gain_b=gb;
}
static void morph_end(track_t *t)
{
 if(t==&trk[0]&&morph.inside){memcpy(t->p,morph.saved,sizeof t->p);morph.inside=0;}
}
static uint32_t morph_fm_key(const track_t *t){return t==&trk[0]&&t->engine==ENGI_MORPH&&morph.inside&&morph.source==ENGI_FM6?morph.revision+1u:0;}
static void morph_fm_apply(const track_t *t,uint8_t *p)
{
 if(morph_dual||!morph_fm_key(t))return;
 for(uint32_t i=0;i<morph.n;i++)if(morph.f[i].kind==2)p[morph.f[i].id]=(uint8_t)morph.f[i].current;
}
static void morph_chord(uint32_t slot,uint32_t owner)
{
 track_t *t=&trk[0];if(slot>=NELEM(morph.prepare_owner)||!owner||t->eng_req!=ENGI_MORPH||t->engine!=ENGI_MORPH)return;
 morph_sync(t);if(!morph.trigger)return;
 /* A keyed/pad gesture has a gid; a loop chord a serial. Voicing edits,
  * harmonisation and arp/scatter notes keep that owner: exactly one roll. */
 if(morph.prepare_owner[slot]==owner)return;
 morph.prepare_owner[slot]=owner;
 morph.chord_events++;/* Random moves between the chosen endpoints, without replacing them. */
 if(morph.mode==2)morph.target=(uint16_t)(morph_rand()%32513u);
}
static void morph_invalidate(void){morph_dual=0;morph.ready=0;morph.loaded=0;morph.roll_choice=0;memset(morph.prepare_owner,0,sizeof morph.prepare_owner);}
static void morph_track_loaded(const track_t *t){if(t==&trk[0]&&t->eng_req==ENGI_MORPH){morph_publish(t);morph_invalidate();}}
static const param_desc_t *morph_desc(const track_t *t,uint32_t k)
{
 static param_desc_t d;
 if(k==MP_BSOURCE){d=(param_desc_t){"Engine B",F_ENUM,0,NELEM(MORPH_SOURCE),0,MORPH_B_SOURCE_NAMES,0};return &d;}
 if(k==MP_PRESET || k==MP_PRESET_B){uint32_t e=k==MP_PRESET_B?morph_ui_b_source(t):MORPH_SOURCE[morph_ui_source(t)];
  for(uint32_t i=0;i<256;i++)morph.names[i]=i<ENGINES[e]->npresets?ENGINES[e]->presets[i].name:"-";
  d=(param_desc_t){k==MP_PRESET?"Patch A":"Patch B",F_ENUM,0,ENGINES[e]->npresets-1,0,morph.names,0};return &d;
 }
 return &ENG_MORPH.edit[k];
}
/* The first page must expose audio Position rather than the old mode selector.
 * Preserve P_E2/P_E3 settings storage and backward compatibility. */
static uint32_t morph_column(uint32_t pg,uint32_t col){
 if(pg==2){static const uint8_t k[4]={MP_BSOURCE,MP_PRESET_B,MP_POSITION,MP_MODE};return k[col&3u];}
 if(pg==0&&col==2)return MP_PRESET_B;
 if(pg==0&&col==3)return MP_POSITION;
 if(pg==1&&col==3)return MP_MODE;
 return pg*4+col;
}
static int32_t morph_deep_get(const track_t *t,uint32_t pg,uint32_t col)
{
 if(pg>2||col>3)return 0;
 if(pg==2&&col==0)return morph_ui_b_index(t);
 if(pg==0&&col==0)return morph_ui_source(t);
 uint32_t k=morph_column(pg,col);
 if(k==MP_PRESET_B)return (uint16_t)morph_control(t,MP_SEED)&255u;
 if(k==MP_POSITION&&morph.ready&&morph_control(t,MP_MODE))return (morph.pos+128u)/256u;
 return morph_control(t,k);
}
static void morph_deep_set(track_t *t,uint32_t pg,uint32_t col,int32_t v)
{
 if(t!=&trk[0]||pg>2||col>3)return;
 uint32_t k=morph_column(pg,col);const param_desc_t *d=morph_desc(t,k);v=clamp(v,d->min,d->max);
 if(k==MP_BSOURCE){t->p[P_MORPH_BSOURCE]=(int16_t)v;t->p[P_E7]&=0x3f00;morph.ready=0;}
 else if(k==MP_PRESET_B)t->p[P_E7]=(int16_t)(((uint16_t)t->p[P_E7]&0x3f00u)|(uint16_t)v);
 else t->p[P_E0+k]=(int16_t)v;
 if(k==MP_POSITION)t->p[P_E3]=0;
 if(k==MP_SOURCE){t->p[P_E1]=0;t->p[P_E7]=257;morph.ready=0;}
 if(k==MP_PRESET || k==MP_PRESET_B)morph.ready=0;
 morph_publish(t);
}
static const param_desc_t *morph_deep_desc(const track_t *t,uint32_t pg,uint32_t col){return morph_desc(t,morph_column(pg,col));}
static const eng_page_t MORPH_PAGES[]={
 {"OSCILLATOR",{{"Engine",F_ENUM,0,NELEM(MORPH_SOURCE)-1,0,MORPH_SOURCE_NAMES,0},{"Patch A",F_INT,0,255,0,0,0},{"Patch B",F_INT,0,255,1,0,0},{"Position",F_PCT,0,127,0,0,0}}},
 {"MORPH SETTINGS",{{"Speed",F_ENUM,0,127,62,MORPH_SPEED,0},{"Amount",F_INT,0,100,100,0,"%"},{"Trigger",F_ENUM,0,1,0,MORPH_TRIGGER,0},{"Mode",F_ENUM,0,2,1,MORPH_MODE,0}}},
 {"PATCH B",{{"Engine B",F_ENUM,0,NELEM(MORPH_SOURCE),0,MORPH_B_SOURCE_NAMES,0},{"Patch B",F_INT,0,255,0,0,0},{"Position",F_PCT,0,127,0,0,0},{"Mode",F_ENUM,0,2,1,MORPH_MODE,0}}}
};
static const eng_screen_t MORPH_SCREENS[]={
 {0,{0,0xff},ENG_B_NONE,0,"OSCILLATOR",{{ENG_C_TEXT,ENG_C_TEXT,ENG_C_TEXT,ENG_C_KNOB}},{{"Engine","Patch A","Patch B","Position"}}},
 {3,{1,0xff},ENG_B_NONE,0,"MORPH SETTINGS",{{ENG_C_KNOB,ENG_C_KNOB,ENG_C_TEXT,ENG_C_TEXT}},{{"Speed","Amount","Trigger","Mode"}}},
 {1,{2,0xff},ENG_B_NONE,0,"PATCH B",{{ENG_C_TEXT,ENG_C_TEXT,ENG_C_KNOB,ENG_C_TEXT}},{{"Engine B","Patch B","Position","Mode"}}}
};
static const eng_deep_t MORPH_DEEP={.npages=3,.pages=MORPH_PAGES,.section={0,2,0xff,1,0xff,0xff,0xff,0xff},.get=morph_deep_get,.set=morph_deep_set,.desc=morph_deep_desc,.screens=MORPH_SCREENS,.nscreens=3};
static const preset_t MORPH_PRESETS[]={
 {"INIT MORPH",{0,0,0,1,62,100,0,1},{0,0,127,0},0,0,FX(0,0,0,0),PAT(1)}
};
static void morph_silent_note(track_t *t,voice_t *v){(void)t;(void)v;}
static void morph_silent_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){(void)t;(void)v;(void)out;(void)n;(void)m;}
static const engine_t ENG_MORPH={.name="Morph",.page_title={"OSCILLATOR","MORPH SETTINGS"},
 .edit={{"Engine",F_ENUM,0,NELEM(MORPH_SOURCE)-1,0,MORPH_SOURCE_NAMES,0},{"Preset",F_INT,0,255,0,0,0},{"Position",F_PCT,0,127,0,0,0},{"Mode",F_ENUM,0,2,1,MORPH_MODE,0},
 {"Speed",F_ENUM,0,127,62,MORPH_SPEED,0},{"Amount",F_INT,0,100,100,0,"%"},{"Trigger",F_ENUM,0,1,0,MORPH_TRIGGER,0},{"Pair",F_INT,0,16383,257,0,0}},
 .presets=MORPH_PRESETS,.npresets=1,.poly=6,.deep=&MORPH_DEEP,.desc=morph_desc,.note_on=morph_silent_note,.render=morph_silent_render,
 .knob={P_E2,P_E4,P_CHOR,P_REV}};
