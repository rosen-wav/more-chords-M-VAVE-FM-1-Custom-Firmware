/* Real chord-to-synth integration: thirds must survive capacity and engine switches. */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
static int held(unsigned note) {unsigned k;for(k=0;k<NVOICE;k++)if(trk[0].v[k].active&&trk[0].v[k].gate&&trk[0].v[k].stage!=4&&trk[0].v[k].note==note)return 1;return 0;}
static void clear(unsigned engine,int bass,int transpose) {
 unsigned p;cr_panic(&cr);memset(cr_ono,0,sizeof cr_ono);memset(cr_tr_n,0,sizeof cr_tr_n);memset(vsq,0,sizeof vsq);
 for(p=0;p<NPART;p++){memset(trk[p].v,0,sizeof trk[p].v);trk[p].xf_on=0;trk[p].xp_n=0;trk[p].nmono=0;}
 trk[0].engine=trk[0].eng_req=engine;trk[0].p[P_VOICE]=V_POLY;trk[0].p[P_TRANS]=transpose;
 trk[1].engine=trk[1].eng_req=ENGI_CZ;trk[1].p[P_VOICE]=V_MONO;
 cr_init(&cr,&CR_OUT);cr_set_playstyle(&cr,CR_PS_ADVANCED);cr_set_bass(&cr,bass);cr_set_stream(&cr,CR_STREAM_BASS,1);cr_rosen_mode=0;panic_req=0;
}
static int third_present(void) {
 unsigned i,j,found=0;
 for(i=0;i<CR_NVOICE;i++)if(cr.v[i].used&&cr.v[i].rq){
  const cr_voice_t *v=&cr.v[i];unsigned pc=(v->root+v->transpose+1200)%12;
  unsigned third=(v->rq==CR_Q_MIN||v->rq==CR_Q_DIM||v->rq==CR_Q_MIN4)?3u:4u;
  if(v->rq==CR_Q_SUS||v->rq==CR_Q_POW)continue;
  for(j=0;j<v->nnotes;j++)if((v->notes[j]+12-pc)%12==third){found++;if(!held(cr_tr_note(0,v->notes[j])))return 0;}
 }
 return found!=0;
}
/* Independent gate oracle for a standard six-note (1,3,5,6,7,9) chord.
 * Check every retained/omitted tone and exact count, not only the presence of a third. */
static int complete_chord_matches(unsigned quality, unsigned expected_root) {
 const cr_voice_t *v=&cr.v[0];unsigned j,k,n=0,cap=trk[0].eng_req==ENGI_PROPHET&&cr.bass_on?4u:5u;
 if(!v->used||v->rq!=quality||v->root!=(int)expected_root||v->nnotes!=6)return 0;
 for(j=0;j<v->nnotes;j++){
  unsigned pc=(v->notes[j]+12-(v->root+v->transpose+1200)%12)%12;
  int keep=pc!=9u && !(cap==4u && (pc==10u || pc==11u));
  if(held((unsigned)((int)v->notes[j]+trk[0].p[P_TRANS]))!=keep)return 0;
 }
 for(k=0;k<NVOICE;k++)n+=trk[0].v[k].active&&trk[0].v[k].gate&&trk[0].v[k].stage!=4;
 return n==cap&&third_present();
}
static int all_released(void) {
 unsigned p,k;for(p=0;p<NPART;p++)for(k=0;k<NVOICE;k++)if(trk[p].v[k].gate)return 0;
 return 1;
}
static void settle(void) {unsigned k;int32_t out[CTL*2];for(k=0;k<8;k++)mix_block(out,CTL);}
#ifndef CR_CHORD_TEST_HELPERS_ONLY
int main(void) {
 unsigned engine,bass,root;int rotation,tp,q,checks=0,fails=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 for(engine=0;engine<2;engine++)for(bass=0;bass<2;bass++)for(root=48;root<60;root++)
 for(rotation=-12;rotation<=12;rotation++)for(tp=-24;tp<=24;tp+=12)for(q=0;q<2;q++){
  unsigned third;clear(engine?ENGI_PROPHET:ENGI_CZ,bass,tp);
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
  cr.voicing=rotation;cr_key(&cr,root,100,1);settle();
  assert(cr.v[0].rq==(q?CR_Q_MIN:CR_Q_MAJ));
  for(third=0;third<cr.v[0].nnotes;third++)if((cr.v[0].notes[third]+12-root%12)%12==(q?3u:4u))break;
  assert(third<cr.v[0].nnotes);checks++;
  if(!held(cr.v[0].notes[third]+tp)||!complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,root)){if(fails<8)printf("FAIL third: engine %u bass %u root %u rotation %d trans %d minor %d note %d\n",engine,bass,root,rotation,tp,q,cr.v[0].notes[third]+tp);fails++;}
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,0);cr_mod(&cr,q?CR_MOD_MAJ:CR_MOD_MIN,1);settle();checks++;
  if(!complete_chord_matches(q?CR_Q_MAJ:CR_Q_MIN,root)){if(fails<8)printf("FAIL quality change engine %u bass %u rotation %d trans %d\n",engine,bass,rotation,tp);fails++;}
  cr_voicing_step(&cr,1);settle();checks++;
  if(!complete_chord_matches(q?CR_Q_MAJ:CR_Q_MIN,root)){if(fails<8)printf("FAIL inversion change engine %u bass %u rotation %d trans %d\n",engine,bass,rotation,tp);fails++;}
 }
 clear(ENGI_CZ,0,0);trk[0].eng_req=ENGI_PROPHET;
 cr_mod(&cr,CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
 cr.voicing=3;cr_key(&cr,60,100,1);
 printf("engine-switch queued notes: %u (expected 5)\n",trk[0].xp_n);
 if(trk[0].xp_n!=5)fails++;settle();checks++;if(!third_present())fails++;
 /* Switch while the old engine is actually sounding (the fade path). */
 for(engine=0;engine<2;engine++)for(bass=0;bass<2;bass++)for(root=48;root<60;root++)
 for(rotation=-12;rotation<=12;rotation++)for(tp=-24;tp<=24;tp+=12)for(q=0;q<2;q++) {
  unsigned target=engine?ENGI_PROPHET:ENGI_CZ;
  clear(engine?ENGI_CZ:ENGI_PROPHET,bass,tp);
  trk_note_on(&trk[0],40,100);settle();trk[0].eng_req=target;
  cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);
  cr_mod(&cr,CR_MOD_MAJ7,1);cr_mod(&cr,CR_MOD_9,1);
  cr.voicing=rotation;cr_key(&cr,root,100,1);
  checks++;if(trk[0].xp_n!=(engine&&bass?4u:5u))fails++;
  settle();checks++;if(!complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,root)) {
   if(fails<8)printf("FAIL live switch engine %u bass %u root %u rotation %d trans %d minor %d\n",engine,bass,root,rotation,tp,q);
   fails++;
  }
 }
 /* All chromatic roots and inversions; obsolete settings cannot quantise them. */
 { unsigned tonic,d;
   for(engine=0;engine<2;engine++)for(bass=0;bass<2;bass++)for(tonic=0;tonic<12;tonic++)
   for(d=0;d<2;d++)for(rotation=-12;rotation<=12;rotation++)for(q=0;q<2;q++) {
     unsigned key=60+(tonic+(d?6:1))%12,actual=key;
     clear(engine?ENGI_PROPHET:ENGI_CZ,bass,0);cr_set_key(&cr,1,tonic,CR_SCALE_MAJOR); /* retired API: must be ignored */
     cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
     cr.voicing=rotation;cr_key(&cr,key,100,1);settle();checks++;
     if(!complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,actual))fails++;
     cr_key(&cr,key,0,0);settle();checks++;if(!all_released())fails++;
   }
 }
 /* Free mode and global transpose, separate from part transpose. */
 { int global_tp;
   for(engine=0;engine<2;engine++)for(bass=0;bass<2;bass++)for(rotation=-12;rotation<=12;rotation++)
   for(global_tp=-12;global_tp<=12;global_tp+=12)for(q=0;q<2;q++) {
     clear(engine?ENGI_PROPHET:ENGI_CZ,bass,0);cr_set_playstyle(&cr,CR_PS_FREE);cr_set_transpose(&cr,global_tp);
     cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
     cr.voicing=rotation;cr_key(&cr,60,100,1);settle();checks++;
     if(!complete_chord_matches(q?CR_Q_MIN:CR_Q_MAJ,60))fails++;
     cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,0);cr_mod(&cr,q?CR_MOD_MAJ:CR_MOD_MIN,1);settle();checks++;
     if(!complete_chord_matches(q?CR_Q_MAJ:CR_Q_MIN,60))fails++;
     cr_key(&cr,60,0,0);settle();checks++;if(!all_released())fails++;
   }
 }
 /* Release while the engine-switch queue is pending. */
 clear(ENGI_CZ,0,0);trk[0].eng_req=ENGI_PROPHET;
 cr_mod(&cr,CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
 cr.voicing=3;cr_key(&cr,60,100,1);cr_key(&cr,60,0,0);checks++;
 if(trk[0].xp_n!=0)fails++;settle();checks++;if(!all_released())fails++;
 /* Fixed MIDI fixtures demonstrate the third changing octave with inversion. */
 { const int inv[4]={-5,0,2,8};const unsigned major_third[4]={52,64,76,88};unsigned j;
   for(j=0;j<4;j++)for(q=0;q<2;q++){
     clear(ENGI_PROPHET,1,0);
     cr_mod(&cr,q?CR_MOD_MIN:CR_MOD_MAJ,1);cr_mod(&cr,CR_MOD_6,1);cr_mod(&cr,CR_MOD_M7,1);cr_mod(&cr,CR_MOD_9,1);
     cr.voicing=inv[j];cr_key(&cr,60,100,1);settle();checks++;
     if(!held(major_third[j]-(q?1u:0u)))fails++;
     printf("fixture: Prophet BASS on inversion %+d %s third MIDI %u %s\n",inv[j],q?"minor":"major",major_third[j]-(q?1u:0u),held(major_third[j]-(q?1u:0u))?"PASS":"FAIL");
   }
 }
 printf("Chord integration: %d cases, %d failures\n",checks,fails);
 return !!fails;
}

#endif
