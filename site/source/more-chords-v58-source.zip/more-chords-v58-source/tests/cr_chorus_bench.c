#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include "cr_v23_chorus_reference.h"
#include "cr_v24_chorus_reference.h"
#include <time.h>
static volatile int32_t sink;
/* Equal indirect-call boundaries: otherwise the host inlines a test-only
 * reference but can keep the firmware kernel out of line. */
static int32_t (*volatile bench_current)(int32_t,int32_t*)=chorus_return;
static int32_t (*volatile bench_v24)(int32_t,int32_t*)=v24_return;
static int32_t (*volatile bench_v23)(int32_t,int32_t*,uint32_t,int32_t)=reference_return;
static double bench(int old){
 clock_t t=clock();int32_t side;unsigned seed=7;
 for(unsigned k=0;k<2000000;k++){
  seed=seed*1664525u+1013904223u;int32_t in=(int32_t)(seed>>16)-32768;in*=2;
  unsigned mode=(k/65536u)%3u;
  if(!(k%CTL)){if(old==2)v24_prepare(mode,110);else if(!old)chorus_prepare(mode,110);}
  int32_t out=old==1?bench_v23(in,&side,mode,110):old==2?bench_v24(in,&side):bench_current(in,&side);
  sink=out+side;
 }
 return (double)(clock()-t)/CLOCKS_PER_SEC;
}
int main(void){
 double old[3],v24[3],now[3];for(unsigned i=0;i<3;i++){old[i]=bench(1);v24[i]=bench(2);now[i]=bench(0);}
 for(unsigned i=0;i<3;i++)printf("Host CPU trial%u: V23 %.4fs V24 %.4fs V25 %.4fs V25/V24 %.3f V25/V23 %.3f\n",i+1,old[i],v24[i],now[i],now[i]/v24[i],now[i]/old[i]);
 puts("Host timing only; FM1 deadline/headroom requires device measurement.");return sink==INT32_MIN;
}
