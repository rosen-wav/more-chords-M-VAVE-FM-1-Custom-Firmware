#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);pthread_t th;assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 unsigned cases=0;unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_CZ,ENGI_SWARM,ENGI_CLUSTER};unsigned engines[]={ENGI_CLOUD,ENGI_CLUSTER};
 for(unsigned e=0;e<2;e++)for(unsigned preset=0;preset<ENGINES[engines[e]]->npresets;preset++)for(unsigned b=0;b<NELEM(basses);b++)for(unsigned width=0;width<5;width++){
  cr_c1_test_serial=1;setup(engines[e],preset,basses[b],0,6,width?width==1?64:127:0);if(e)trk[0].p[P_E0]=7*2048;else{trk[0].p[P_CBANK]=width;trk[0].p[P_CSCAN]=width%4;trk[0].p[P_CRATE]=95;trk[0].p[P_CDEPTH]=111;}
  for(unsigned k=0;k<64;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);
  cr_c1_test_serial=0;setup(engines[e],preset,basses[b],0,6,width?width==1?64:127:0);if(e)trk[0].p[P_E0]=7*2048;else{trk[0].p[P_CBANK]=width;trk[0].p[P_CSCAN]=width%4;trk[0].p[P_CRATE]=95;trk[0].p[P_CDEPTH]=111;}
  for(unsigned k=0;k<64;k++){int32_t pcm[2*CTL];block(k,pcm);assert(!memcmp(reference[k],pcm,sizeof pcm));if(!k)assert(c1_chord_count==2);}
  assert(!memcmp(states,eng_state,sizeof states));cases++;
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: %u CLOUD/7-oscillator CLUSTER exact serial/CPU1 PCM+state, all factories, five Bass engines, five banks / scan / Church widths, six voices 4+2\n",cases);
}
