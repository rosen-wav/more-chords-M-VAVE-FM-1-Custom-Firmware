#define main legacy_stress_main
#include "cr_cloud_dsp_test.c"
#undef main
#include "cloud_v45_reference.h"
static legacy_cloud_part_t legacy_arena[NPART];
static legacy_cloud_part_t *legacy_cloud_part(uint32_t p){return &legacy_arena[p%NPART];}
int main(void){
 _Static_assert(sizeof(cloud_grain_t)==sizeof(legacy_cloud_grain_t),"grain size unchanged");
 _Static_assert(sizeof(cloud_part_t)==sizeof(legacy_cloud_part_t),"arena size unchanged");
 unsigned long samples=0,energy[9]={0};
 for(unsigned preset=0;preset<8;preset++)for(unsigned note=0;note<128;note+=7){
  memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);memset(legacy_arena,0,sizeof legacy_arena);
  track_t *t=&trk[0];voice_t *v=&t->v[0];for(unsigned j=0;j<8;j++)t->p[P_E0+j]=CLOUD_PRESETS[preset].e[j];
  v->active=v->gate=1;cloud_note_on(t,v);voice_t ref=*v;
  legacy_cloud_note_on(t,&t->v[1]); /* initialize a correctly indexed voice, then map state to reference */
  legacy_arena[0].voice[0].rng=arena[0].voice[0].rng;
  vmod_t m={0};m.inc=pitch_inc(note*16);m.shape=64<<8;m.amp0=m.amp1=32767;
  for(unsigned b=0;b<192;b++){
   int32_t a[CTL]={0},z[CTL]={0};cloud_render_raw(t,v,a,CTL,&m);
   voice_t now=*v;*v=ref;legacy_cloud_render_raw(t,v,z,CTL,&m);ref=*v;*v=now;
   assert(!memcmp(a,z,sizeof a));assert(!memcmp(v->s,ref.s,sizeof v->s));samples+=CTL;
  }
 }
 for(unsigned bank=0;bank<9;bank++)for(unsigned mode=0;mode<4;mode++)for(unsigned note=0;note<128;note+=7){
  memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);track_t *t=&trk[0];voice_t *v=&t->v[0];v->gate=v->active=1;
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=CLOUD_PRESETS[1].e[j];
  t->p[P_CBANK]=bank;t->p[P_CSCAN]=mode;t->p[P_CDEPTH]=127;t->p[P_CRATE]=127;cloud_note_on(t,v);
  vmod_t m={0};m.inc=pitch_inc(note*16);m.shape=64<<8;m.amp0=m.amp1=32767;
  for(unsigned b=0;b<256;b++){
   if(b%17==0)t->p[P_E0]=(b*17)%128;
   int32_t out[CTL+2]={0};out[0]=1234567;out[CTL+1]=7654321;cloud_render(t,v,out+1,CTL,&m);
   assert(out[0]==1234567 && out[CTL+1]==7654321);
   for(unsigned i=1;i<=CTL;i++){assert(llabs(out[i])<=72000);energy[bank]+=llabs(out[i]);}samples+=CTL;
   for(unsigned g=0;g<CLOUD_NG;g++)if(arena[0].voice[0].g[g].owner)assert(arena[0].voice[0].g[g].bank<=8);
   if(b%31==0)t->p[P_CBANK]=(t->p[P_CBANK]+1)%9;
  }
  v->active=0;cloud_block(t);for(unsigned g=0;g<CLOUD_NG;g++)assert(!arena[0].voice[0].g[g].owner);
 }
 for(unsigned b=0;b<9;b++)assert(energy[b]);
 printf("PASS: %lu CLOUD samples; exact Classic reference PCM, nine banks/four scan modes, MIDI 0..126, rapid live edits, guards, unchanged arena, release cleanup\n",samples);
 return 0;
}
