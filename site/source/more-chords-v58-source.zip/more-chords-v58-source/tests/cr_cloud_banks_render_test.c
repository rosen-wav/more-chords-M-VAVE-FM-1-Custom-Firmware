#include <assert.h>
#define main legacy_draw_main
#include "cr_draw_test.c"
#undef main
static cr_screen_t frames[5];static uint16_t expected[240*240];
int main(int argc,char **argv){assert(argc==2);palette_set(mod_index());rep=stderr;
 for(unsigned k=0;k<5;k++){char path[512],name[32];snprintf(path,sizeof path,"%s/bank-%u.bin",argv[1],k);FILE *f=fopen(path,"rb");assert(f);assert(fread(&frames[k],sizeof frames[k],1,f)==1);fclose(f);render(&frames[k],0);snprintf(name,sizeof name,"cloud-bank-%u",k);lint(name,&frames[k]);write_ppm(argv[1],name);assert(!nfind&&!nfail);}
 for(unsigned a=0;a<5;a++)for(unsigned b=0;b<5;b++){render(&frames[b],0);memcpy(expected,host_screen,sizeof expected);render(&frames[a],0);cr_draw(&frames[b],0);assert(!memcmp(expected,host_screen,sizeof expected));}
 puts("PASS: five CLOUD wavetable screens, text bounds/overlap and 25 cached/full redraw comparisons");return 0;}
