/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../build/gen/felucca_tables.h"
/* This fixture tests DSP only; concurrency has separate real worker tests. */
#define CR_CPU1 0
/* Mach-O has no firmware ELF sections; this is a host-only DSP fixture. */
#if defined(__APPLE__)
#define __attribute__(x)
#endif
#include "../firmware/src/core.h"
#if defined(__APPLE__)
#undef __attribute__
#endif
#include "../firmware/src/dsp.c"
#include "../firmware/src/eng_cloud.c"
static cloud_part_t arena[NPART];
static cloud_part_t *cloud_part(uint32_t p){return &arena[p%NPART];}
int main(void){uint64_t energy=0;unsigned blocks=0,max_grains=0;
 for(unsigned preset=0;preset<8;preset++)for(unsigned stress=0;stress<3;stress++)for(unsigned note=0;note<128;note+=7){
  memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);track_t *t=&trk[0];voice_t *v=&t->v[0];
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=CLOUD_PRESETS[preset].e[j];
  if(stress)for(unsigned j=0;j<8;j++)t->p[P_E0+j]=stress==1?ENG_CLOUD.edit[j].max:ENG_CLOUD.edit[j].min;
  v->active=1;v->env=0;cloud_note_on(t,v);
  vmod_t m={0};m.inc=pitch_inc(note*16);m.shape=stress==1?127*256:64*256;m.cutoff=stress==1?127*256:-127*256;m.amp0=m.amp1=32767;
  unsigned audible=0;
  for(unsigned b=0;b<1024;b++){
   int32_t out[CTL+2]={0};out[0]=123456789;out[CTL+1]=987654321;
   cloud_block(t);cloud_render(t,v,out+1,CTL,&m);
   assert(out[0]==123456789&&out[CTL+1]==987654321);
   for(unsigned j=1;j<=CTL;j++){assert(llabs(out[j])<=72000);energy+=llabs(out[j]);audible+=out[j]!=0;}
   unsigned occupied=0;
   for(unsigned j=0;j<CLOUD_NG;j++){cloud_grain_t *g=&arena[0].voice[0].g[j];assert(g->owner<=NVOICE);if(g->owner){occupied++;assert(g->inc<=CLOUD_INC_MAX);assert(g->left<=18000);}}
   if(occupied>max_grains)max_grains=occupied;
   blocks++;
  }
  assert(audible);v->active=0;cloud_block(t);for(unsigned j=0;j<CLOUD_NG;j++)assert(!arena[0].voice[0].g[j].owner);
 }
 assert(energy && max_grains==CLOUD_NG);printf("PASS: Cloud %u DSP samples, factory/extreme panels, MIDI notes 0..126, window/pool bounds and PCM guards under UBSan\n",blocks*CTL);return 0;
}
