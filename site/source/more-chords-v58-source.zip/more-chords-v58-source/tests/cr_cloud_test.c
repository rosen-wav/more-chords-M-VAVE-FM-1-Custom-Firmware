/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);pthread_t th;unsigned cases=0;
 assert(CLOUD_NG==3);assert(ENGI_CLOUD==22 && NENGINES==23 && !eng_ok(ENGI_CS1));
 assert(sizeof(cloud_part_t)<=sizeof(fm6_part_t));
 assert(MORPH_SOURCE[NELEM(MORPH_SOURCE)-1]==ENGI_CLOUD);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 const unsigned basses[]={ENGI_BASS,ENGI_FM6,ENGI_VA,ENGI_QUAD,ENGI_CZ,ENGI_PROPHET,ENGI_KR106};
 for(unsigned pi=0;pi<8;pi++)for(unsigned b=0;b<NELEM(basses);b++)for(unsigned rev=0;rev<4;rev++){
  cr_c1_test_serial=1;setup(ENGI_CLOUD,pi,basses[b],0,6,rev);
  for(unsigned k=0;k<128;k++)block(k,reference[k]);memcpy(states,eng_state,sizeof states);
  cr_c1_test_serial=0;setup(ENGI_CLOUD,pi,basses[b],0,6,rev);
  unsigned active=0;for(unsigned i=0;i<NVOICE;i++)active+=trk[0].v[i].active&&trk[0].v[i].gate;assert(active==6);
  int32_t pcm[2*CTL];for(unsigned k=0;k<128;k++){block(k,pcm);if(!k)assert(c1_chord_count==2);assert(!memcmp(pcm,reference[k],sizeof pcm));}
  assert(!memcmp(states,eng_state,sizeof states));cases++;
 }
 for(unsigned pi=0;pi<8;pi++){
  setup(ENGI_CLOUD,pi,ENGI_BASS,0,6,0);trk_all_off(&trk[1]);uint64_t energy=0;int32_t pcm[2*CTL];
  for(unsigned k=0;k<512;k++){for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);for(unsigned j=0;j<2*CTL;j++)energy+=llabs(pcm[j]);}
  assert(energy>1000);
  track_t *t=&trk[0];int16_t expected[8];for(unsigned j=0;j<8;j++)expected[j]=t->p[P_E0+j];
  assert(!cb_store(t,0,31,"CLOUD USER",0));cu_load_user(t,31,0);for(unsigned j=0;j<8;j++)assert(t->p[P_E0+j]==expected[j]);
  assert(!cb_store(t,0,31,"CLOUD OVER",pi+1));cu_load_user(t,31,0);for(unsigned j=0;j<8;j++)assert(t->p[P_E0+j]==expected[j]);
  for(unsigned j=0;j<NVOICE;j++)trk_note_off(t,t->v[j].note);
  for(unsigned k=0;k<16000;k++){engine_block(t);mix_block(pcm,CTL);}
  for(unsigned j=0;j<NVOICE;j++)assert(!t->v[j].active);
  cloud_part_t *e=cloud_part(0);for(unsigned j=0;j<NVOICE;j++)for(unsigned g=0;g<CLOUD_NG;g++)assert(!e->voice[j].g[g].owner);
  printf("Cloud %s audible, USER overwrite/reload and release cleanup PASS\n",CLOUD_PRESETS[pi].name);
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: Cloud %u exact serial/CPU1 PCM+state fixtures, six voices 4+2, seven Bass engines, four reverbs; state %zu bytes\n",cases,sizeof(cloud_part_t));return 0;
}
