/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static void dump(const cr_screen_t *s,const char *dir,unsigned index){if(!dir)return;char b[512];snprintf(b,sizeof b,"%s/screen-%u.bin",dir,index);FILE *f=fopen(b,"wb");assert(f);assert(fwrite(s,sizeof *s,1,f)==1);fclose(f);}
int main(int argc,char **argv){emu_fw_options(0,1,0,1);emu_fw_init(0);cu_load(&trk[0],ENGI_CLOUD,0,0);engine_block(&trk[0]);ce_open(0);cr_screen_t s;
 const char *labels[2][4]={{"Wave","Size","Density","Spread"},{"Detune","Chirp","Stack","Tone"}};
 for(unsigned group=0;group<2;group++){
  ce_group(group?CE_FILT:CE_OSC);cr_build_screen(&s,cu_now());assert(!strcmp(s.page,group?"SPECTRUM":"GRAINS"));assert(s.wide==CR_W_CLOUD&&s.wv[8]==group&&s.n_rows==1);
  dump(&s,argc>1?argv[1]:0,group*3);
  for(unsigned j=0;j<4;j++){unsigned idx=group*4+j;assert(!strcmp(s.cell[0][j].label,labels[group][j]));int16_t before=trk[0].p[P_E0+idx];ce_knob(j,1,0);assert(trk[0].p[P_E0+idx]>before);}
  for(unsigned edge=0;edge<2;edge++){for(unsigned j=0;j<4;j++)trk[0].p[P_E0+group*4+j]=edge?ENG_CLOUD.edit[group*4+j].max:ENG_CLOUD.edit[group*4+j].min;cr_build_screen(&s,cu_now());dump(&s,argc>1?argv[1]:0,group*3+edge+1);}
 }
 ce_close();assert(ENGINE_ORDER[eng_rank(ENGI_KR106)+1]==ENGI_CLOUD);puts("PASS: Cloud dedicated band, labels, units, edge states and all eight knob controls");return 0;
}
