#define main original_stress_main
#include "cr_v30_dsp_test.c"
#undef main
#include "cluster_v42_reference.h"
#include <time.h>
int main(void){
 unsigned long samples=0;clock_t before=0,after=0;
 for(unsigned preset=0;preset<16;preset++)for(unsigned note=0;note<128;note+=7){
 memset(trk,0,sizeof trk);memset(arena,0,sizeof arena);track_t *t=&trk[0];voice_t *v=&t->v[0];v->gate=1;
 cluster_preset_to(t,preset);cluster_note_on(t,v);cluster_note_t ref=arena[0].note[0];
 for(unsigned b=0;b<160;b++){
 if(b%13==0){t->p[P_E0]=(1+b%7)*2048;t->p[P_E1]=(b&1)?32767:-32768;t->p[P_E2]=(b%24)*1024;t->p[P_E3]=(b&2)?32767:-32768;}
 if(b==120){cls_release(&ref.state);cls_release(&arena[0].note[0].state);}
 clock_t a=clock();cluster_v42_reference(&ref,pitch_inc(note*16),&t->p[P_E0]);before+=clock()-a;
 a=clock();cluster_light_kernel(&arena[0].note[0],pitch_inc(note*16),&t->p[P_E0]);after+=clock()-a;
 for(unsigned q=0;q<128;q++)assert(arena[0].note[0].pcm[q]>=-16400 && arena[0].note[0].pcm[q]<=16400);
 for(unsigned q=0;q<7;q++)assert(cls_get32(&ref.state,4+8*q)==cls_get32(&arena[0].note[0].state,4+8*q));
 samples+=128;
 }}
 printf("PASS: %lu bounded samples and exact phase advances. Host ticks old %ld new %ld (not FM1).\n",samples,(long)before,(long)after);
 return original_stress_main();}
