/* SPDX-License-Identifier: GPL-3.0-only */
#include <setjmp.h>
static jmp_buf fault;
#define CHORALROOT_DUAL_CORE 1
#define CR_C1_FAULT() longjmp(fault,1)
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
int main(void){int32_t out[CTL*2];voice_t bass[NVOICE];
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 cr_c1_test_nostart=1;cr_c1_boot();assert(cr_dbg.c1==C1_FAILED&&!cr_dualcore_active());
 assert(cz_voice_cap(&trk[0])==5 && p5_live_poly(&trk[0])==5);
 cr_c1_test_nostart=0;cr_c1_boot();assert(cr_dualcore_active());
 clear(ENGI_CZ,1,0);trk_note_on(&trk[1],36,100);memcpy(bass,trk[1].v,sizeof bass);
 cr_c1_test_hang=1;unsigned jobs=cr_dbg.c1_jobs;
 if(!setjmp(fault)){mix_block(out,CTL);assert(0&&"job timeout must invoke reset hook");}
 assert(cr_dbg.c1==C1_GAVE_UP && cr_dbg.c1_jobs==jobs);assert(!memcmp(bass,trk[1].v,sizeof bass));
 cr_c1_test_hang=0;cr_c1_split=0;
 puts("CPU1 fallback: startup failure retains serial caps; job timeout invokes reset without replaying BASS PASS");return 0;}
