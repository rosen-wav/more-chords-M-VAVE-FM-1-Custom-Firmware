/* SPDX-License-Identifier: GPL-3.0-only */
#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static uint64_t audible;
static void drain(void){int32_t pcm[2*CTL];cr_audio_block(CTL);for(unsigned i=0;i<2;i++)engine_block(&trk[i]);mix_block(pcm,CTL);for(unsigned i=0;i<2*CTL;i++)audible+=abs(pcm[i]);cr_snapshot();}
static void pulse(unsigned src){fm1_ms+=21;assert(midi_enqueue(0xF8u<<8|0x0Fu,src));drain();}
static void rt(unsigned status,unsigned src){assert(midi_enqueue(status<<8|0x0Fu,src));drain();}
static void shot(const char *path){cr_screen_t s;cu.pop.until=cu.msg.until=0;cr_build_screen(&s,cu_now());cr_draw(&s,CR_ANIM_SETTLED);FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");for(unsigned i=0;i<240*240;i++){uint16_t c=emu_hal.lcd[i];c=(c>>8)|(c<<8);uint8_t rgb[3]={(uint8_t)(((c>>11)&31)*255/31),(uint8_t)(((c>>5)&63)*255/63),(uint8_t)((c&31)*255/31)};fwrite(rgb,1,3,f);}fclose(f);}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cu_load(&trk[0],ENGI_FM6,0,0);engine_block(&trk[0]);panic_req=0;unsigned notes=0;
 /* Every key still follows the normal Just Keys path in settings and picker,
  * for both saved values of the obsolete root-picker preference. */
 cs.keys_only=1;cr_set_keys_only(&cr,1);cu.octave=0;
 for(unsigned mode=0;mode<3;mode++)for(unsigned saved=0;saved<2;saved++){
  cu.lock=mode==1?L_EDIT:L_NONE;cu.opt_open=mode==0;cu.page=PG_NONE;cs.pick_roots=saved;cu.epk_on=mode==2;
  uint8_t option=cu.opt_sel;uint32_t engine=trk[0].eng_req;
  for(unsigned k=0;k<CU_NKEY;k++){
   cu_key_press(k);drain();assert(cu.key_note[k]==54+k);assert(cu.opt_sel==option&&trk[0].eng_req==engine);
   cu_key_release(k);drain();assert(!cu.key_note[k]);notes++;
  }
 }
 cu.epk_on=cu.opt_open=0;cu.lock=L_EDIT;cs.keys_only=0;cr_set_keys_only(&cr,0);
 cu_key_press(4);drain();cu_key_press(CU_ROOT0);drain();assert(cr.mods_down && cu.key_note[CU_ROOT0]);cu_key_release(CU_ROOT0);cu_key_release(4);drain();
 cu.lock=L_NONE;cr_loop_clear(&crl,&cr);cr_snapshot();cs.loop_len=2;
 /* Seed the existing sequence and remember it, including its dirty flag. */
 crl.d.len=768;crl.d.nev=1;crl.d.nlayers=1;crl.d.ev[0]=(crl_ev_t){0,96,66,100,CR_Q_MIN<<4,0};crl.dirty=1;crl.state=CRL_STOPPED;cr_snapshot();
 crl_data_t original=crl.d;unsigned dirty=crl.dirty;
 cu.step_editor=1;cu.lock=L_METRO;cu.page=PG_NONE;cu_opened(BT_REC);assert(cu.page==PG_IDEAS&&creative_ideas.ready);
 cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(!strcmp(screen.page,"IDEAS"));
 if(getenv("CREATIVE_SCREENSHOTS"))shot("build/creative-tests/ideas-listen.ppm");
 cu_tap(BT_LOOP);drain();assert(cr_idea.armed==1 && !memcmp(&crl.d,&original,sizeof original));
 unsigned n=0;while(!cr_idea.active && n++<3000)drain();assert(cr_idea.active&&cr_idea.voice&&cr_idea.index==0);cr_build_screen(&screen,cu_now());assert(screen.sel==cr_idea.index && screen.n_items==4);
 unsigned seen=1;uint32_t start=crl.t;audible=0;
 while(crl.t-start<crl_stage.len+4){drain();seen|=1u<<cr_idea.index;}
 assert(audible>0);assert(seen==15 && crl.dirty==dirty && !memcmp(&crl.d,&original,sizeof original));
 cu_tap(BT_LOOP);drain();assert(!cr_idea.active&&!cr_idea.voice);
 cu_tap(BT_LOOP);drain();assert(cr_idea.armed);creative_cancel_ideas();drain();assert(!cr_idea.active&&!cr_idea.armed&&!cr_idea.voice);
 /* Old queued PLAY cannot start a newly generated candidate. */
 creative_open_ideas();cu_tap(BT_LOOP);creative_generate();drain();assert(!cr_idea.active&&!cr_idea.armed);
 for(unsigned src=0;src<2;src++){
  cr_route.clock_in=1;drain();creative_generate();cu_tap(BT_LOOP);drain();assert(cr_idea.armed==2);
  for(unsigned i=0;i<30;i++)pulse(src);assert(cr_idea.active);
  rt(0xFC,src);assert(!cr_idea.active&&!cr_idea.voice);
  rt(0xFA,src);assert(cr_idea.active && !memcmp(&crl.d,&original,sizeof original));rt(0xFC,src);
 }
 cr_route.clock_in=1;drain();creative_generate();cu_tap(BT_LOOP);drain();assert(cr_idea.armed==2);cr_route.clock_in=0;drain();assert(!cr_idea.armed&&!cr_idea.active);
 cr_route.clock_in=0;drain();creative_generate();cu_tap(BT_LOOP);drain();while(!cr_idea.active)drain();
 creative_back_ideas();drain();assert(!crl_stage_busy&&!cr_idea.voice&&!memcmp(&crl.d,&original,sizeof original));
 cu_opened(BT_REC);cu_tap(BT_LOOP);drain();while(!cr_idea.active)drain();creative_accept();drain();assert(crl.d.nev==4&&crl.dirty&&crl.state==CRL_STOPPED&&cu.step_editor&&!cr_idea.voice);
 /* Generated text feedback has no counter; Undo, confirm and cancel preserve native state. */
 cu.step_editor=0;cu.page=PG_EDIT;ce.part=0;cu.lock=L_NONE;creative_open_random();
 uint32_t original_crc=cu_snd_crc(&trk[0]);cu_knob(EN_K3,1);assert(creative_random.pending);
 cr_build_screen(&screen,cu_now());assert(!strcmp(screen.label,"Preset generated")&&screen.hot_c==2);
 if(getenv("CREATIVE_SCREENSHOTS"))shot("build/creative-tests/randomizer-feedback.ppm");
 cu_knob(EN_K4,1);assert(!creative_random.pending&&cu_snd_crc(&trk[0])==original_crc);cr_build_screen(&screen,cu_now());assert(!strcmp(screen.label,"Restored"));
 fm1_ms+=501;cr_build_screen(&screen,cu_now());assert(strcmp(screen.label,"Restored"));
 cu_knob(EN_K3,1);assert(creative_random.pending);cu_tap(BT_SAVE);assert(cu.page==PG_RANDOMIZER);cu_home_tap();assert(cu.page==PG_EDIT&&!creative_random.pending&&cu_snd_crc(&trk[0])==original_crc);
 creative_open_random();cu_knob(EN_K3,1);uint32_t accepted_crc=cu_snd_crc(&trk[0]);cu_oct_tap(B_OCTUP);assert(cu.page==PG_EDIT&&!creative_random.pending&&cu_snd_crc(&trk[0])==accepted_crc);
 creative_open_random();cu_knob(EN_K3,1);cu_oct_tap(B_OCTDN);assert(cu.page==PG_EDIT&&cu_snd_crc(&trk[0])==accepted_crc);
 creative_open_random();cu_knob(EN_K3,1);cu_load(&trk[0],ENGI_FM6,3,0);uint32_t incoming_crc=cu_snd_crc(&trk[0]);cu_oct_tap(B_OCTUP);assert(cu.page==PG_EDIT&&!creative_random.pending&&cu_snd_crc(&trk[0])==incoming_crc);
 /* Tap REC stays out of Ideas. HOME hold REC restores real layer Undo;
  * the held SEQ menu and the step editor open Ideas without undoing. */
 cu.page=PG_NONE;cu.combo=0;cu.step_editor=1;cu_tap(BT_REC);assert(cu.page!=PG_IDEAS);
 cu.step_editor=0;cu.lock=L_NONE;
 crl_data_t layers={0};layers.len=768;layers.nev=2;layers.nlayers=2;
 layers.ev[0]=(crl_ev_t){0,96,60,100,0,0};layers.ev[1]=(crl_ev_t){192,96,64,100,0,1};
 cr_loop_set(&crl,&cr,&layers);cu_opened(BT_REC);drain();assert(cu.page!=PG_IDEAS && crl.d.nev==1 && crl.d.nlayers==1);
 cu.lock=L_METRO;cu_opened(BT_REC);assert(cu.page==PG_IDEAS);creative_back_ideas();drain();assert(crl.d.nev==1);
 printf("PASS: %u live menu keys, chord modifiers, hold-REC preview all four chords/wrap, stop/cancel/regenerate/accept, unchanged original sequence, USB/TRS clock + stop and randomizer text feedback/confirm/cancel/SAVE guard\n",notes);
 return 0;
}
