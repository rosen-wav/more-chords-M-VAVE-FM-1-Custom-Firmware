# V59 — installer, emulatore e changelog

Su Mac, dalla cartella estratta:

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v59-grain-level" &&
source "$HOME/.venv/bin/activate" &&
sh web/build_v59_site.sh
)
```

Serve la toolchain firmware già usata e Emscripten in `~/emsdk`.
Il comando ricompila il firmware con dual core e Prophet, esegue i test del pacchetto, compila l'emulatore V59 e prepara `build/site`. L'hash è calcolato dal nuovo firmware; nessun hash delle versioni precedenti viene riutilizzato. Il firmware sul dispositivo continua a identificarsi come ChoralRoot 0.14.

Carica **il contenuto** di `build/site` nella root della repository GitHub Pages, mantenendo la struttura delle sottocartelle: `emulator`, `firmware`, `webapp`, `source`, font e immagini, insieme a index.html, release.json, changelog.json e .nojekyll. Non caricare soltanto index.html. Mantieni il README della repository. Con Pages impostato sul branch principale/root, il deployment parte dopo il commit.

La pagina mostra le modifiche recenti V54–V59. Il link all'emulatore e i download indicano V59. JS, worklet e WASM hanno un identificatore di cache comune basato sui contenuti. La chiave IndexedDB resta invariata per conservare i salvataggi del browser.

Questa consegna contiene sorgenti e strumenti: non include un firmware o un WASM compilato qui e non pubblica automaticamente su GitHub. Il controllo degli export WASM verifica il modulo, ma non sostituisce una prova audio nel browser. Il controllo completo va eseguito sul Mac prima di pubblicare.

La suite storica test_morechords_installer.mjs contiene cinque aspettative obsolete sui 64 USER/CZ-1: non è usata come blocco del nuovo comando. Il preflight release verifica invece il pacchetto reale, l'hash e i controlli dell'installer. Nessun controllo di sicurezza del pacchetto è disattivato.
