# FAVOURITES — experimental source preview

- Hold HOME 1 second to toggle the current chord preset as a favourite (outside SAVE/EDIT/Options).
- OPT + PRESETS now offers a virtual FAVOURITES entry; PRESETS browses the bookmarked sounds.
- Factory and overwritten factory sounds are linked by (engine, factory preset index); additional USER sounds by user slot.
- Uses the existing PER5 favourite bitmap; no changes to the persisted settings structure.
- ChoralRoot splash/idle logo removals from the input source are preserved.

## Status and limitations

**Not validated or installable.** The JieLi AC79 SDK/bootloader files are unavailable in this environment, so the build and emulator verification could not be completed. Do not flash this source without compiling, testing and checking flash/RAM usage.

This is a first implementation to review and test, not a released firmware. Further integration checks are needed for HOME timing and virtual engine navigation in the hardware emulator. The virtual FAVOURITES browser does not add a DSP engine.
