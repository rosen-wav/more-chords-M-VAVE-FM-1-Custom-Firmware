> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](README-V8.md).

# ChoralRoot — Velocity analogica + Dual Morph (sperimentale)

Questa versione modifica **davvero** il firmware, non contiene soltanto codice di riferimento.
È destinata prima ai test dell'emulatore e della toolchain e poi alla prova hardware.
**NON FLASHARE senza build corretta, memory report e verifica real-time.**

## Implementato nei sorgenti

- Stima della velocity della tastiera tramite l'algoritmo di sensing Monk 0.9 (`firmware/src/cr_sense.c`) e campionamento ADC aggiunto alla HAL (`firmware/hal/fm1_input.h`, `fm1_adc.h`); il normale scan digitale resta attivo. Le soglie sono di partenza e richiedono calibrazione su FM1 reale.
- `Dynamic Velocity` ON/OFF persistente nelle impostazioni; la velocity ricevuta viaggia sul bus eventi comune verso Chord/Arp/Loop/Sequencer, e il callback comune impone velocity 100 se disattivata. Il parametro di velocity fissa della tastiera resta nell'interfaccia.
- Morph con **due voci/patch native indipendenti**, A in parte 0 e B nella parte sintetica 2, su sei sorgenti; il mixer PCM applica un crossfade equal-power A/B con ramp per blocco e invia la miscela alla catena FX esistente. I note-on/off sono inoltrati a entrambe.
- Quando CPU1 è disponibile, il suo job esistente continua a renderizzare **Bass/parte 1** e aggiunge in coda il rendering della patch B, senza cambiare l'assegnazione Bass/Chord. Esiste anche percorso seriale di fallback.

## Test eseguiti in questo ambiente

- Test sintetici della macchina velocity di Monk: OK.
- Test host per 6 engine Morph e note-off: OK.
- Sintassi unità firmware con CHORALROOT_DUAL_CORE=0 e =1: OK.
- Non sono stati eseguiti test di latenza ADC reale, benchmark CPU1 realtime, completa regressione audio, build hardware o misure XIP/RAM/POOL.
- Nota: alcuni test preesistenti del vecchio Morph parametrico fanno riferimento ai buffer storici eliminati dal nuovo motore e non sono test validi per questo algoritmo.

## Prova su Mac

```sh
cd ~/Downloads/Choralroot-remix-v2-gentle
sh tools/emu/build.sh
build/host/emu --front
```

Test funzionali portabili:

```sh
sh tests/test_velocity_dual_morph.sh
```

Per il firmware hardware (solo dopo i test), eseguire `sh build.sh` e leggere le dimensioni XIP/RAM/POOL e il carico core reale.

## Limiti conosciuti / aspetti da verificare

- L'emulatore non replica la misura della resistenza fisica dei tasti: lì la velocity usa il valore di ripiego.
- Su Morph+Bass è possibile che l'uso CPU1 cresca significativamente: NON è ancora garantito che mantenga il deadline audio.
- La sonda PA10, la selezione dei drive PA6/PA7/PA8 e l'ADC condiviso vanno verificati sui tasti dell'FM1 vero prima del flash.
- Persistenza testata a livello di layout e percorso in C, ma non ancora con ciclo di riavvio sulla scheda.
- Il crossfade equal-power può causare un lieve aumento di livello al centro su patch fortemente correlate; non è un limitatore di picco.
