# Raccordo BASS sui cambi di nota

Base: more-chords-v61-va3. VA resta a tre oscillatori, due envelope e due LFO; FM6 resta escluso da Morph.

Il motore BASS dedicato ora applica la stessa correzione di continuità usata da VA: 128 campioni, circa 2,9 ms a 44,1 kHz. All'inizio del retrigger, il contributo della voce viene raccordato al suo ultimo campione; la correzione decade linearmente. Un nuovo retrigger durante il raccordo riparte dall'ultimo campione già corretto. Le note nuove partite da silenzio azzerano lo stato del raccordo.

Lo stato occupa quattro slot già disponibili nella voce, senza nuova allocazione RAM/POOL. È privato di ciascuna voce e funziona anche su CPU1. La fase degli oscillatori e lo stato del filtro continuano come prima. Fuori dai raccordi, l'audio è invariato.

Questa modifica riguarda il motore BASS, non qualsiasi motore scelto per la traccia basso. È mirata ai clic al cambio nota; non corregge eventuali overload, discontinuità causate dagli effetti successivi o altri problemi della catena audio. Non è stata collaudata sul tuo hardware, quindi il clic segnalato va ancora verificato con questa build.

## Test

- 800 blocchi sui suoi otto preset; 32 retrigger, anche ravvicinati.
- Continuità esatta al primo campione del retrigger, durata di 128 campioni, corretto reset da silenzio.
- Fasi e stato filtro invariati rispetto al renderer precedente; stesso audio fuori dal raccordo.
- Test mirato con UndefinedBehaviorSanitizer, esclusi gli shift signed preesistenti.
- Confronto BASS seriale/CPU1 e controlli build documentati nei log in `verifiche/`.

Il raccordo modifica intenzionalmente i primi 2,9 ms del cambio nota: i vecchi risultati di equivalenza PCM delle precedenti versioni non vanno interpretati come equivalenza durante questi transitori. `tests/run_lossless_optimization.py` confronta ora CLOUD/CLUSTER mantenendo VA3 e il nuovo BASS in entrambe le versioni.

## Firmware e sito

Firmware: `firmware-installabile/more-chords-v61-va3-bass-smooth.fwsc`.
Identità FM-1_920, versione interna ChoralRoot 0.14; il sito continua a usare v61 e hash nuovi. Nessun file è stato pubblicato su GitHub.

Estrarre in Download e usare lo script consueto (richiede toolchain, Node ed Emscripten):

```sh
(
cd "$HOME/Downloads/more-chords-v61-va3-bass-smooth" &&
source "$HOME/.venv/bin/activate" &&
sh web/build_v61_site.sh
)
```

Caricare il contenuto di `build/site` nella cartella `site` del repository. Questo documento descrive l'ultimo aggiornamento; gli altri LEGGIMI conservano lo storico dei precedenti interventi.
