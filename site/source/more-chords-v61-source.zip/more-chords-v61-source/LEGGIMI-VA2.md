# VA2 — v61

VA: 2 oscillatori (OSC1/OSC2), 2 envelope, 2 LFO. OSC3/4 non vengono renderizzati; rimossi i controlli e le destinazioni PIT3/LVL3/SHP3. SYNC2 resta disponibile. I campi salvati mantengono gli ID originali; OSC3/4 e ring sono ignorati.

MIX ora bilancia OSC1 e OSC2: 0 solo OSC1, 64 entrambi ai livelli impostati, 127 solo OSC2. I preset che usavano OSC3 o MIX diverso dal centro cambiano timbro/bilanciamento; nessuna compensazione automatica di volume. VA mantiene fino a due voci su CPU1. Restano il raccordo BASS di 128 campioni, FM6 escluso da Morph e le precedenti ottimizzazioni.

Verifiche: 3200 confronti PCM mono/side contro il renderer precedente con OSC3/4 spenti e MIX al centro; fasi degli oscillatori rimossi ferme; round-trip UI; Morph e sintassi firmware dual core 0/1; 160 confronti seriale/CPU1 con BASS e cinque motori accordi, incluso VA. Build hardware completata, identità FM-1_920. Nessuna misura di risparmio CPU sull'hardware né prova del clic sul dispositivo.

## Web installer ed emulatore

Estrarre in Downloads, poi:

```sh
(
cd "$HOME/Downloads/more-chords-v61-va2-bass-smooth" &&
source "$HOME/.venv/bin/activate" &&
sh web/build_v61_site.sh
)
```

Lo script usa il firmware VA2 incluso, lo copia in build/choralroot.fwsc, genera l'emulatore e verifica il sito. Caricare il contenuto di build/site nella cartella site del repository. Richiede Emscripten e Node. Per ricompilare anche il firmware dopo modifiche ai sorgenti: REBUILD_FIRMWARE=1 sh web/build_v61_site.sh (richiede la toolchain hardware). La generazione web completa va eseguita sul Mac; qui sono stati verificati la sintassi dello script, l'audio host e la build hardware.

Gli altri LEGGIMI e log sono lo storico delle versioni precedenti. Questo documento descrive la versione corrente.

Firmware SHA256: 410d52b2500d7d79ed1956d425fdc5874c3c7f617df52adb2018e0ece64f06f6
