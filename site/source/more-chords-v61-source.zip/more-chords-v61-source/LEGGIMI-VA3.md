# VA a tre oscillatori

Questa versione parte da more-chords-v61-optimized e rimuove OSC4 da VA.

- Attivi: OSC1, OSC2, OSC3, due envelope e due LFO.
- OSC4 non viene renderizzato; la sua fase non avanza nel rendering. I suoi parametri e le destinazioni PIT4/LVL4/SHP4 non compaiono nell'editor.
- La ring modulation OSC3×OSC4 è disattivata. Il sync OSC2→OSC1 resta disponibile.
- MIX passa fra OSC1+OSC2 e OSC3, senza compensazioni automatiche di volume.
- Gli offset dei blob salvati restano invariati: i dati di OSC4 vengono conservati ma ignorati nel suono. I vecchi preset si caricano, ma quelli che usavano OSC4/ring cambiano timbro e possono avere meno volume.
- Restano le ottimizzazioni CLOUD/CLUSTER/BASS e l'esclusione di FM6 da Morph. Nessun altro motore viene modificato.

## File installabile

`firmware-installabile/more-chords-v61-va3.fwsc`

Identità FM-1_920, versione interna ChoralRoot 0.14. La versione del sito resta v61 con hash aggiornati. Firmware compilato con JieLi 20260730.1; non collaudato sul dispositivo. Nessuna percentuale di risparmio CPU viene promessa.

Build: XIP 570116/573440 B; RAM 93888/98304 B; POOL 335296/344064 B. Controlli hardware di build, HAL e CPU1 superati.

## Test eseguiti

- 3200 confronti PCM mono/side: identici alla versione precedente con OSC4 silenziato e ring disattivata, tutti i 25 preset VA, blocchi di 1–32 campioni, anche in rilascio.
- Vecchi valori OSC4/ring non producono audio e la fase OSC4 rimane ferma.
- Pagine e sezioni dell'editor aggiornate; formato salvato invariato.
- Test VA Lite, Morph e controllo sintattico single/dual core superati.

I risultati lossless dei precedenti documenti descrivono il passaggio alla versione optimized, non la rimozione intenzionale di OSC4. Le note di questo file hanno precedenza. `tests/cr_va3_test.c` contiene il test specifico con sanitizer; `tests/run_va_lite_tests.sh` include i test di compatibilità aggiornati. I log correnti sono in `verifiche/`.

## Generare installer ed emulatore web sul Mac

Con la cartella estratta in Download, la venv e la toolchain già configurate:

```sh
(
cd "$HOME/Downloads/more-chords-v61-va3" &&
source "$HOME/.venv/bin/activate" &&
sh web/build_v61_site.sh
)
```

Lo script richiede Node ed Emscripten. Ricompila il firmware e l'emulatore, prepara e verifica `build/site`. Caricare il contenuto di quella cartella nella cartella `site` del repository; nessun caricamento viene eseguito da questo comando.
