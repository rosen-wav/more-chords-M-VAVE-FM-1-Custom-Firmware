# ChoralRoot Morph — Deep Crossfade (prototipo emulatore)

Questa versione cambia materialmente il crossfade dei selettori discreti:
- Crossfade del segnale pre-FX da 20 a 38 ms.
- Storico da 1024 a 2048 frame, Q5 16 bit stereo al posto di 32 bit: **stessa occupazione statica per lo storico (8192 byte)**.
- Interpolazione dei parametri continui e smoothing manuale della versione Smoother invariati.
- Solo un sintetizzatore: il crossfade riutilizza audio precedente, non è un vero dual-engine (può avere carattere di eco su segnali variabili).
- Nota: la compressione Q5 può saturare segnali interni superiori a circa +/-1.05 milioni; ascoltare i preset forti e verificare con il test WAV.

Mac: `sh tools/emu/build.sh` e `build/host/emu --front`.
Test: `sh tools/emu/test_cr.sh`.

**Non validato su hardware**. Le dimensioni finali XIP/RAM/POOL vanno misurate con `sh build.sh` prima del flash.
