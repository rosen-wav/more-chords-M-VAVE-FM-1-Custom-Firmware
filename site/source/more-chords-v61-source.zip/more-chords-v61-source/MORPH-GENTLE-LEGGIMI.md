# Morph Gentle — 15 ottobre 2026

Questa revisione rende il morph più morbido e riduce alcune cause di dissonanza
intermedia. Conserva l'interpolazione dei parametri, gli estremi A/B, le correzioni
FM6 sulle note tenute e KR106 +2 dB.

## Cosa cambia

- Position in Manual: curva con partenza e arrivo morbidi anche verso posizioni
  intermedie. Una piccola regolazione richiede circa 100 ms; un salto completo
  A/B circa 600 ms. Invertendo la manopola si riparte dalla posizione corrente.
- Amount: passa progressivamente al nuovo valore (fino a circa 300 ms per tutta
  la corsa), evitando che questo controllo aggiri la morbidezza di Position.
- Curva: arrotondamento unico a precisione maggiore per evitare piccoli
  arretramenti vicino agli estremi nei movimenti molto lenti.
- Random: raggiunge ogni destinazione con una curva morbida. Speed indica il
  tempo del singolo movimento, da 100 ms a 8 secondi. Anche un nuovo accordo
  durante il movimento riparte dalla posizione corrente.
- FM6: coarse, fine e modalità degli operatori passano insieme da una patch
  all'altra, con l'isteresi e l'overlap esistenti. Non vengono create combinazioni
  intermedie di coarse/fine che possono produrre rapporti dissonanti.
- Se le patch hanno selettori discreti diversi, il passaggio centrale ammorbidisce
  temporaneamente la modulazione: fino al 25% in meno sul controllo feedback
  FM6/QUAD e su resonance/drive VA; fino a 12 punti in meno sul livello degli
  operatori FM6 che sono esclusivamente modulatori in entrambi gli algoritmi.
  I livelli dei portanti di entrambe le patch e il volume master non ricevono
  questa attenuazione aggiuntiva. Agli estremi l'attenuazione è zero.
- Due patch identiche non ricevono alcuna attenuazione durante il morph.

## Prova nell'emulatore macOS

Dalla cartella estratta:

```sh
sh tools/emu/build.sh && build/host/emu --front
```

Scegli Morph, Engine, Patch A e Patch B; Amount 100%, modalità Manual. Tieni
una nota o un accordo e muovi Position, includendo inversioni e soste al centro.
Per una prova lenta automatica scegli Up and Down con Speed tra 2 e 4 secondi.
Confronta anche Random. Per valutare l'effetto della correzione usa inizialmente
la stessa coppia di patch della versione precedente.

## Limiti musicali

La musicalità dipende dalle patch: una patch rumorosa, percussiva, molto dissonante
o con frequenze fisse rimane tale al proprio estremo. Algoritmi, campioni,
forme d'onda e rapporti FM/QUAD non hanno una vera topologia intermedia e possono
ancora produrre un cambiamento udibile. Il breve overlap di 20 ms attenua lo
stacco ma non equivale a due motori completi in crossfade. La risoluzione dei
parametri rimane quella nativa. Non viene applicato un correttore di scala o
intonazione, e le patch non vengono riscritte.

## Verifiche e build

`sh tests/run_morph_tests.sh` esegue 1960 sweep dei parametri, verifica
la monotonia di tutti i 32769 valori della curva Q15 e controlla
inversioni, Amount, Random a 8 secondi, coerenza dei rapporti FM, conservazione
dei portanti, identità A=A, estremi audio nativi A/B, 81 casi motore/preset,
36 confronti CPU1/seriale, salvataggio, editor e overlap stereo con UBSan.
Il riepilogo dell'esecuzione è in docs/MORPH-GENTLE-TESTS.txt.

La struttura Morph occupa 6632 byte sull'host (648 in più della prima correzione);
la history stereo resta 8220 byte. Nessun secondo motore audio viene aggiunto.
I binari precompilati precedenti sono esclusi dall'archivio; gli header generati
per i test sono inclusi. Per il firmware hardware usare `sh build.sh` con la
propria toolchain JieLi configurata. Build target, budget memoria/timing sul
microcontrollore e ascolto sull'hardware reale non sono stati verificati qui.

File aggiornati in questa revisione: firmware/src/eng_morph.c e
tests/cr_morph_test.c, oltre alla documentazione. Include anche la precedente
correzione di firmware/src/eng_fm6.c.
