> Documento della prima correzione. Per il comportamento aggiornato leggere MORPH-GENTLE-LEGGIMI.md.

# Correzione del morph parametrico — 15 ottobre 2026

Il morph ora interpola anche i controlli numerici che prima venivano commutati
tra A e B: accordatura/coarse/fine, detune, spread, offset e key tracking,
compreso il filtro continuo FTYPE di VA. I nomi visualizzati nell'editor non
rendono più automaticamente discreto un parametro numerico.

In FM6 vengono aggiornati anche gli inviluppi degli operatori portanti e
l'inviluppo di pitch sulle note già tenute. Il sustain segue L3 senza essere
reindirizzato verso il livello di release; la trasposizione durante il morph
non spegne più le note. La fase e il livello corrente non vengono azzerati.
Le normali modifiche alle patch FM6 fuori da Morph conservano il comportamento
precedente.

## Uso

Scegli Engine, Patch A e Patch B, imposta Amount a 100%, Morph su Manual e muovi
Position. All'estremo sinistro ottieni A, a quello destro B; nelle posizioni
intermedie i parametri numerici assumono valori intermedi. La curva smoothstep
e il movimento smussato del controllo già esistenti restano attivi. Con Amount
inferiore al 100% il percorso verso B è limitato intenzionalmente.

Algoritmi, forme d'onda selezionabili, campioni, routing, interruttori e indici
delle tabelle di rapporti QUAD restano scelte discrete: commutano con isteresi
e il breve overlap audio esistente. Non esiste una topologia intermedia in
questi motori. L'interpolazione numerica rispetta la risoluzione nativa dei
parametri: per esempio un parametro in semitoni resta quantizzato in semitoni.
Questa correzione non realizza un crossfade fra due motori audio completi.

## Verifica

Eseguire `sh tests/run_morph_tests.sh` dalla cartella del progetto.
La suite include 2.004 sweep di parametri numerici su 128 posizioni, controlli
sui parametri continui con nomi nell'editor, aggiornamento dei portanti FM6,
pitch envelope e note tenute durante la trasposizione. Sono inclusi i test
esistenti degli estremi audio A/B, 81 casi motore/preset, 36 confronti tra CPU1
e rendering seriale, editor, salvataggio e overlap stereo con UBSan.

## Compilazione per hardware

Questo archivio contiene i sorgenti aggiornati e gli header generati per i test.
I vecchi binari precompilati sono esclusi per evitare di installare per errore
il firmware precedente. Per creare il nuovo `build/choralroot.fwsc`, usare
`./build.sh` nel proprio ambiente JieLi configurato, come descritto in BUILDING.md.
La toolchain JieLi non è disponibile nell'ambiente usato per questa correzione:
non sono stati eseguiti build target, verifica dei limiti di memoria del target
o ascolto/prova sull'hardware reale. La modifica KR106 +2 dB è preservata.

File modificati: firmware/src/eng_morph.c, firmware/src/eng_fm6.c,
tests/cr_morph_test.c. Questo documento e il riepilogo dei test sono aggiunti.
