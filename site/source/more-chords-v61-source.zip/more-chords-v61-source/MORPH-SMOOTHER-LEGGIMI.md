# Morph Smoother — FM1

Questa variante preserva il sistema ibrido presente in Morph Gentle: interpolazione dei parametri continui e crossfade audio stereo con phase matching quando cambiano parametri discreti (algoritmi, modalità, ecc.).

Regolazioni effettuate:
- Position manuale: circa 140 ms per piccoli movimenti e fino a circa 800 ms per un salto A/B completo, con smoothstep e ripartenza dalla posizione corrente quando si inverte la manopola.
- Amount: smoothing esteso da 300 a 450 ms per l'intera corsa.
- Audio: overlap crossfade da 20 ms **mantenuto** per non aumentare l'occupazione POOL e non introdurre un secondo motore audio. Questo non è un vero dual-engine crossfade fra due patch sempre attive.

Usa `sh build.sh` sul Mac con toolchain già configurata. Verifica XIP/RAM/POOL, ascolta le transizioni FM1 e confronta l'output con il firmware precedente. Non è stato verificato qui il firmware su hardware FM1.

I test che assumono una durata fissa di movimento sono stati aggiornati per il nuovo smoothing.
