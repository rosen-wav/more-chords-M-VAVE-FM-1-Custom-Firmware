# ChoralRoot V5 — VERO crossfade A/B (correzione V4)

Questa versione corregge un difetto della V4 che rendeva inattivo il crossfade in riproduzione: `morph_fade_pcm` veniva chiamata in `fx.c`, ma usciva subito perché `morph.inside` era falso quando l'engine Morph era selezionato. `morph_begin` ora esegue prima sync/tick dei controlli e poi **entra sempre** nello scope di Patch A per il rendering e per i note-on; `morph_end` ripristina i parametri di interfaccia.

- La Patch A viene renderizzata nella parte 0, la Patch B nella parte 2, con stato e voci propri.
- Il mix PCM pre-FX è equal-power, e il guadagno viene interpolato campione per campione all'interno di ogni blocco audio.
- In modalità Manual, Position segue la manopola con dezipper di circa 20 ms, invece dell'inseguimento precedente di 800 ms. Le modalità automatiche e Speed restano separate.
- Aggiunta una terza istanza di stato per VA e QUAD (`VA_NPART`, `QUAD_NPART`): la V4 aveva accessi fuori limite con Patch B sulla parte 2.
- Velocity di Monk e Dynamic Velocity ON/OFF conservate dalla V4.
- Assegnazione precedente del core 1 a Bass invariata; il rendering B rimane aggiunto al job esistente, come nella V4.

## Verifiche eseguite

`sh tests/test_velocity_dual_morph.sh` su Linux: OK, test della velocity, sintassi del firmware per entrambi i flag dual-core, sei sorgenti Morph, e nuovi assert sugli effettivi guadagni del mixer a 0%, 50%, 100%. Questi test non simulano il tastierino analogico reale o il carico di tempo reale sull'FM1.

Il test dualcore completo e i sanitizer non sono terminati entro i limiti di esecuzione di questo ambiente. Emulatore macOS, memoria XIP/RAM/POOL e build JieLi **non verificati**. Usare prima l'emulatore; **non flashare** il dispositivo prima dei controlli di dimensioni e di deadline audio.

## Emulatore macOS

```sh
sh tools/emu/build.sh && ./build/host/emu --front
```

## Test specifici

```sh
sh tests/test_velocity_dual_morph.sh
```

## Nota tecnica

Il mixer è un crossfade fra due segnali di due istanze native della **stessa sorgente** scelta in Morph; non implementa un crossfade fra due tipi di engine arbitrariamente diversi. Un crossfade equal-power può aumentare il picco al centro quando le due patch sono molto correlate. 
