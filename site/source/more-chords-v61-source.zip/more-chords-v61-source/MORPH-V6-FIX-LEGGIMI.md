# ChoralRoot V6 — Correzione controllo Morph A/B

La V5 eseguiva un crossfade PCM sulle due patch ma la prima pagina "OSCILLATOR" esponeva un controllo **Morph** che selezionava in realtà la *modalità* (Manual / Up and Down / Random), non la posizione della miscela. Spostarlo non consentiva di raggiungere Patch B.

## Modifica

- Pagina 1 OSCILLATOR: **Engine**, **Patch A**, **Patch B**, **Position** (0–127). Il quarto parametro è adesso il controllo di crossfade diretto. 
- Pagina 2 MORPH SETTINGS: **Speed**, **Amount**, **Trigger**, **Mode** (Manual / Up and Down / Random).
- La memorizzazione interna dei parametri (P_E2=Position, P_E3=Mode) non cambia, quindi le patch salvate conservano i valori.
- L'interpolazione equal-power e il percorso di rendering A/B della V5 non vengono alterati, così come la velocity e l'assegnazione dual-core esistente.

## Prova

Nell'emulatore selezionare **Morph** come engine, poi impostare **Amount = 100** e **Mode = Manual**. Scegliere patch ben diverse (per esempio FM6 TINE EP / FM BELL) e tenere premuto un tasto. La prima pagina ora consente di portare **Position** da 0 (solo A) a 127 (solo B). Un movimento completo viene smussato nel motore audio su alcune decine di millisecondi.

La verifica estesa `sh tests/test_velocity_dual_morph.sh` su host Linux controlla anche che impostare Position dalla prima pagina faccia arrivare il crossfade al 100% di B e che, disattivato il Bass, l'uscita audio non sia muta.

**Questa è ancora una versione sperimentale**: emulatore macOS, utilizzo RAM/POOL, carico CPU e build firmware hardware non sono stati misurati qui. Non flashare sull'FM1 prima di tali verifiche.
