> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](README-V8.md).

# ChoralRoot V7 — correzione grafica Morph (base V6)

## Modifica rispetto alla V6

- Nessuna modifica a engine, audio PCM, dual-core, velocity o preset.
- Rimossa la riga testuale ridondante sotto la schermata OSCILLATOR del Morph: quando `Position` era a zero appariva una frase non pertinente (nome preset ripetuto). I valori A/B restano visibili nelle rispettive colonne.
- Nella schermata MORPH SETTINGS la descrizione `Random: ...` compare **solo** quando Mode = Random, non quando Manual/Up and Down.

## Velocity Monk 0.9 — stato reale della V6/V7

- Il file `firmware/src/cr_sense.c` usa la macchina di sensing di Monk e la HAL fisica legge campioni ADC per i tasti analogici / probe dei tasti superiori. Il normale scanner digitale continua a funzionare.
- In Settings c'è `Dynamic Velocity: On/Off`, salvato nelle impostazioni. `On`: tenta di misurare la pressione iniziale dai tasti reali; `Off`: la tastiera usa il livello fisso, e i note-on del percorso comune (sequencer incluso) vengono normalizzati a 100.
- I dati di velocity vengono propagati lungo le modalità che usano il percorso note comune (Chord, Arp, Sequencer e MIDI); la riproduzione nella relativa modalità richiede verifica sull'hardware.
- Nell'emulatore il sensore fisico è assente: le note suonate dalla tastiera dell'emulatore usano il livello di fallback.
- Calibrazione dei sensori, effettiva risposta dinamica su FM1 e assenza di conflitti ADC su hardware NON verificate. Non flashare senza build e controlli memoria / audio real-time.

## Prova

```
sh tools/emu/build.sh && ./build/host/emu --front --no-flash
```
