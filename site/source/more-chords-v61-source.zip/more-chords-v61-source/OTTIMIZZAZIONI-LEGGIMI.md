# Ottimizzazioni senza modifica dell'audio — v61 VA Lite

Base di confronto: la VA Lite consegnata in questa conversazione (due envelope e due LFO; FM6 escluso da Morph). Il confronto non è con la v61 originale a quattro envelope/LFO.

## Interventi mantenuti

- CLOUD: selezione del banco e del segmento della forma d'onda una volta per grano/blocco, invece che per campione; fase e incremento elaborati in variabili locali. Stesse operazioni in virgola fissa, stesso ordine di arrotondamento, stesse finestre, interpolazione e chirp.
- CLUSTER: consumo del buffer in porzioni contigue; verifica del limite del kernel una volta per porzione, invece che per campione. Kernel di sintesi, numero degli oscillatori, feedback e ricostruzione invariati.
- BASS: a mix zero, il secondo oscillatore non viene calcolato. La sua fase continua ad avanzare esattamente come prima, così i successivi cambi di mix non alterano il suono. La scelta del percorso avviene per blocco.

I tentativi aggiuntivi su VA e sul bus chorus/delay sono stati scartati: non mostravano un vantaggio convincente nei benchmark host. VA resta quello della precedente versione Lite. Nessun ulteriore taglio a voci, effetti, risoluzione, modulazioni o frequenza di campionamento.

## Verifiche

- 420 scenari del mixer: preset di dieci motori, cambi di parametri, note e rilascio, banche e segmenti CLOUD. Confronto binario di 66.453.504 byte di PCM prima/dopo.
- 6.144 confronti diretti prima/dopo: PCM e stato interno identici, blocchi da 1 a 32 campioni, cambi di pitch, forme d'onda, mix, banchi e numero di oscillatori. Eseguiti anche con UndefinedBehaviorSanitizer, esclusi gli shift signed preesistenti.
- 360 confronti seriale/CPU1 su CLOUD/CLUSTER: PCM e stato identici, cinque motori Bass e tre larghezze Church.
- Test Morph con sanitizer: endpoint, posizione, interfaccia e note-off.
- Build hardware completata: controlli di memoria, accessi HAL e codice CPU1 superati.

L'uguaglianza dei campioni è verificata nei casi provati; non sostituisce un collaudo hardware o una prova di tutti i possibili preset personalizzati.

## Prestazioni misurate sul computer

Benchmark isolato, 1.000.000 blocchi per caso, tre preset per motore. Tempo CPU host; non misura il carico totale dell'FM-1.

| Motore | Riduzione del tempo nei casi provati |
|---|---|
| CLOUD | 3,9–6,1% |
| CLUSTER | 5,6–6,1% |
| BASS, preset SUB PURE, mix zero | 14,4% |
| BASS, altri due preset | sostanzialmente invariato (-1,1% / +0,9%) |

I valori sono quelli di una sessione di benchmark e possono variare con il computer e il compilatore. Il primo tentativo generale, poi scartato in parte, non mostrava un guadagno complessivo. Non si promette una percentuale di riduzione della CPU totale né un aumento di polifonia. Serve la misura sul dispositivo, soprattutto per VA.

## Firmware e memoria

File installabile: `firmware-installabile/more-chords-v61-optimized.fwsc`.

- Identità: FM-1_920. Versione interna della base: ChoralRoot 0.14.
- Toolchain: JieLi 20260730.1.
- RAM: 93.888 / 98.304 byte; POOL: 335.296 / 344.064 byte, entrambe invariate rispetto alla VA Lite.
- XIP: 570.784 / 573.440 byte, +832 byte rispetto alla VA Lite.
- Nessun collaudo su hardware FM-1 e nessuna pubblicazione sul sito/repository remoto.

Leggere anche `VA-LITE-LEGGIMI.md` per le modifiche già introdotte e la compatibilità dei vecchi preset. I dati di build più recenti sono quelli di questo documento. `SHA256SUMS` identifica il firmware incluso.

## Riprodurre i controlli

Dopo la generazione degli header (`BUILDING.md`):

```sh
python3 tests/run_lossless_optimization.py
# Opzionale: cinque confronti cronometrici dell'intero mixer host
python3 tests/run_lossless_optimization.py --benchmark
```

Il runner compila separatamente una copia di riferimento senza sovrascrivere i sorgenti. Le versioni precedenti dei file sono in `optimization-reference/`; i test mirati sono `tests/cr_opt_state_test.c` e `tests/cr_opt_kernel_bench.c`. Le patch sono `va-lite.patch` (primo intervento) e `lossless-optimization.patch` (questo intervento). I log e i risultati finali sono nella cartella `verifiche/` dello ZIP.
