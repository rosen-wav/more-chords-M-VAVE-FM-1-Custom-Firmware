# PI32V2 sensor build fix, revision 3

The Mac target link exposed __floatunsisf, __floatsisf and __divsf3 successively. The two earlier cast fixes were incomplete. This revision removes floating-point arithmetic entirely from the driven-velocity calculation, instead of adding unsupported runtime math to an ADC interrupt.

The same Monk curve is calculated in integer fixed point: logarithmic position relative to the calibrated floor/ceiling, raised to d_curve/100, then scaled to vmax. cr_sense_math.h provides Q24 integer logarithms and ratios and a Q31 exponential. Only an 80-byte constant table is added, with no mutable buffers. All division is at most 32-bit; widened multiplication uses uint64_t. The original cr_fastmath.h is restored and is no longer included by cr_sense.c. Other sensing, calibration and aftertouch behavior is unchanged.

Validation (docs/validation-v9/sense-buildfix3.log):
- 4,852,920 original-float versus integer velocity comparisons, including 10-bit ADC and 16-bit calibration/configuration, random full calibration ranges and extreme curve settings. 106 differ by exactly one velocity unit; all others coincide. No larger difference. Monotonic ADC sweeps pass.
- 200,000 independent log/exp/ratio fixtures against libm/64-bit division, under UBSan: max log2 error 6.01048242e-08; max exponential absolute error 1.94289995e-09.
- Existing sensing/state-machine tests pass, also under UBSan without exclusions.
- Both serial and dual-core whole-firmware host syntax checks pass.
- GCC optimized sensor/state-machine code contains no float/double operations (docs/validation-v9/sense-integer-audit.log). This is a host-code check, not a PI32V2 target build.

The original floating reference contains a pre-existing signed negative shift in fm_exp2_nf, so the float compatibility comparison is run without UBSan; UBSan checks the new integer helpers and the sensing state machine separately.

CS-1 +12 dB total and KR106 additional +1.5 dB remain unchanged. Boot/stub/loader, QUAD and legacy goldens are unchanged. Target link, flash/RAM occupancy and interrupt timing must still be verified on Mac/FM1. No flash is performed or implied by these tests.
