# ChoralRoot Remix — Creative build

Complete source folder based on the MIDI shared-lock Remix. Read [docs/CREATIVE-TOOLS.md](docs/CREATIVE-TOOLS.md) for controls, storage migration and verification limits.

- NEW: bounded Preset Randomizer for all installed engines, inside the preset editor (hold REC), with Amount and Undo. Normal SAVE keeps a variation.
- IMPROVED: Chord Ideas via hold REC from HOME/SEQ, PLAY audition before OCT+ confirmation, no automatic slot save: tonic, major/minor, five progression patterns and Surprise. Review chord names and confirm before replacing the sequence.
- IMPROVED: Morph now interpolates between two real factory patches from the same engine; Manual, Up and Down and Random are retained. Two editor pages, one synth renderer.
- IMPROVED: smooth Morph parameter curve and stereo de-click ramps for discrete patch changes; Randomizer “Preset generated” feedback, OCT+ confirmation and cancel-to-original.
- FIX: keyboard plays normally in Settings and engine selection.
- FIX: monophonic USER presets retain mono mode on the chord part.
- PRESERVED: CPU1 default ON, Prophet/CZ/BASS, native preset storage, USB audio019/Clean, MIDI TRS/USB/shared LOCK, gate, step sequencer, 20 slots and existing clock sync.

Extract this folder into Downloads, then test on the Mac:

```sh
cd "$HOME/Downloads/Choralroot-remix-jazz"
source "$HOME/.venv/bin/activate"
sh tests/run_creative_tests.sh && sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh && build/host/emu --no-midi
```

The folder includes generated headers/assets and regression tests. It does not contain a newly linked firmware `.fwsc`; device linking and size/stack checks must be performed on the Mac. No flash has been performed for this build. Boot stub/loader protection is inherited unchanged, not newly validated against hardware power interruption here.
