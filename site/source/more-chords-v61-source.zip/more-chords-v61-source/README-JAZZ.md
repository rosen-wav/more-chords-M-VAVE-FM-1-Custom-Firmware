# Choralroot Remix — Jazz Chord Ideas

Complete source bundle with every previous KR106/UI/Remix change.

Chord Ideas now generate major, minor, diminished and suspended chords with sixths, minor/major sevenths and ninths. Adds the **Jazz** ii–V–I–vi pattern, with a minor-key variant. Existing patterns also receive varied harmonic colors. Sevenths remain exclusive and generated chords contain three to five notes.

Hold REC from HOME/SEQ. SELECT browses the four fully named chords; PLAY auditions the candidate and follows the sounding chord. OCT+ transfers it to the step sequencer in RAM; SAVE remains a separate action. Preset Randomizer confirmation and KR106 UI/order are unchanged.

```sh
cd "$HOME/Downloads/Choralroot-remix-jazz"
source "$HOME/.venv/bin/activate"
sh tests/run_creative_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Host checks include 13,440 generated chord/preview fixtures with an independent interval oracle, complete extension coverage, valid names, exact packing/unpacking and OCT+ transfer. Existing creative-tool/clock preview/confirm tests pass, plus target C syntax with CPU1 disabled/enabled. DSP, engine allocation, boot code and legacy golden files are unchanged; no device link or flash performed here.
