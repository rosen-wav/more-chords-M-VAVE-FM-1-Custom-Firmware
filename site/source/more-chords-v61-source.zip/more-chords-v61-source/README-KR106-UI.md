# KR106 UI and creative workflow update

Complete Remix source bundle, including the KR106 engine and all previous features.

- KR106 appears second in the engine picker, immediately after Prophet. Stored engine IDs are unchanged.
- KR106 editor: illustrative DCO waveform, Saw/Pulse icons, clearer PWM selectors, filter knobs, native ADSR curve/sliders, named HPF modes and Chorus switches. Audio rendering and CPU0/CPU1 allocation are unchanged.
- Preset Randomizer: turn Generate to audition a variation. Feedback is **Preset generated**, without a roll counter. OCT+ confirms and returns to EDIT; OCT-/HOME/EDIT cancels and restores the original sound. SAVE is blocked until a generated candidate is confirmed. Confirmation changes the current sound; saving to a slot remains a separate SAVE action.
- Chord Ideas: hold REC from HOME or SEQ. PLAY auditions/stops the candidate; OCT+ applies it in RAM and enters the step sequencer. No automatic slot save. A short REC tap no longer opens Ideas. Hold REC inside the preset editor still opens Preset Randomizer.

## Mac emulator

```sh
cd "$HOME/Downloads/Choralroot-remix-jazz"
source "$HOME/.venv/bin/activate"
sh tests/run_creative_tests.sh &&
sh tests/run_kr106_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Host native/creative/Morph/sequencer regressions and target C syntax pass. UI previews were rendered and inspected. No device firmware was linked or flashed here; target size guards and hardware behavior still require the Mac build and device testing. QUAD source and legacy golden-related files are unchanged.
