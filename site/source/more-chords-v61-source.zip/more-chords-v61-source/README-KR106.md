# Choralroot Remix — KR106 preview

Complete source bundle including the previous creative tools, two-patch Morph, randomizer, chord ideas and all earlier Remix features. Adds KR106 from FM-106 beta3: 128 factory sounds, six chord voices online (four CPU0 / two CPU1), CPU1 Bass, native DCO/PWM/VCF/ADSR/LFO/Chorus editing and complete USER saves. Excluded from Morph.

Start with the emulator commands and validation limitations in [docs/KR106.md](docs/KR106.md). No newly built device firmware is included. Build and target memory/recovery guards must pass before considering a hardware install.
