# Remix V9 — engine levels

Complete V9/CS-1 source folder, including all preceding changes.

- CS-1: **+12 dB** relative to the first V9 (**another +6 dB** versus the previous levels archive).
- KR106: **+1.5 dB** relative to V9 (additional to its existing makeup gain).

Gain is applied after each native output stage, equally to stereo mid/side, before the shared Remix FX/master chain. Existing preset values and storage formats are unchanged. No new audio buffers were added. No engine outside CS-1/KR106 was changed.

Fixed-point ratios: CS-1 11.9999995 dB; KR106 1.4999991 dB. Widened arithmetic prevents overflow in the gain multiply.

Baseline levels tests passed: CS-1 576 worker/factory/USER fixtures and 1,277,952 native DSP UBSan samples; KR106 471 fixtures and 512,000 native DSP UBSan samples; Python/browser librarian and both firmware syntax configurations. Logs: docs/validation-v9/cs1-levels.log and kr106-levels.log. The complete host-final.log is the preceding V9 baseline, before these two gain changes.

The FM1 target build, target memory report and hardware listening/timing checks remain outstanding. No flash was performed.

The latest CS-1 +12 dB run is recorded in `docs/validation-v9/cs1-plus12.log`; KR106 is byte-identical to the previous levels archive.

## Emulator on Mac

```sh
cd "$HOME/Downloads/Choralroot-remix-v9-buildfix3"
source "$HOME/.venv/bin/activate"
sh tests/run_cs1_tests.sh &&
sh tests/run_kr106_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

See README-V9-CS1.md for the engine and preceding V9 functionality.
