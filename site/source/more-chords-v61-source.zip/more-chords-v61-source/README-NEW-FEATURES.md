# Stage25: Ambient / Church Hall and Gate

Ambient retains the Melodee Hall sound tested in the preceding release. Church
uses that same stereo Hall tail, with additional diffuse early reflections.
The SELECT performance menu now has Gate Off/On on knob 3 and gate rate on knob 4;
Stutter and its capture buffer have been removed. All earlier engine, dual-core,
looper, rosen, swag and keys-only changes remain included.

Extract this complete source project into its own folder. Start with the emulator.
See [details](docs/AMBIENT-CHURCH-GATE.md) and
[validation](docs/CHURCH-GATE-VALIDATION.md). No firmware package is supplied.

## Two chord voices plus BASS on CPU1

This complete tree runs up to two CZ-1/Prophet chord voices plus BASS on CPU1, with six chord voices when CPU1 is online. CPU0 renders the other four and runs effects/master. It retains separate budgets, stack measurement, guarded timeouts, five looper modes and SEQ knob 2 BPM. Hardware timing and stack depth require a fresh build and device test. Read [docs/DUALCORE-EXPERIMENT.md](docs/DUALCORE-EXPERIMENT.md) for controls, limitations and build instructions.

# ChoralRoot: complete combined project

This folder contains the previous Stage30 QUAD work, Prophet fixes, chord intelligence,
rosen mode (Off / Next / Random / Ping Pong), and the new Ambient and Church reverbs, exclusive sevenths and swag voicing mode.
It is a complete source project, not an incremental patch. Extract into its own folder;
do not run an old patch applicator or merge it into an uncertain older checkout.

## SEQ: master sidechain

Hold SEQ to open the metronome/loop menu. KNOB 1 controls click volume, KNOB 2 controls internal BPM (20..300). With MIDI Clock In, BPM follows the received clock and KNOB 2 is read-only. KNOB 3 selects **Sidechain On / Off**;
KNOB 4 retains Loop trans (-12..+12 semitones). The sidechain starts Off at boot
and is session-only. Its icon is a straight line on Off; on On it shows a fast
volume dip followed by recovery. It works with or without a loop, with one volume
pulse per quarter note (four pulses per 4/4 bar).

With MIDI Clock Off or Out, it follows the internal tempo continuously, including
with an empty or stopped loop and with the click off. With MIDI Clock In, it follows
accepted USB/UART MIDI Clock pulses and their beat phase; a MIDI Start rephases it.
Start is not required: clock pulses alone establish sync. Allow at least six pulse
intervals for the existing tempo follower to acquire the external tempo. If the clock
is absent for 300 ms, the master smoothly returns to unity, rather than continuing
on a stale tempo. Clock pulses can drive it even with external transport stopped;
if the source stops sending clock, it bypasses. Returning to internal clock resumes
continuous pumping. The On/Off setting does not change the loop transport. The fixed pulse
ducks to about -24 dB for the first 10% of each beat, then recovers smoothly
by 75% of the beat. This is stronger than the previous -12 dB version.

The master mix includes live instruments, loop notes, BASS and effect tails.
The metronome click is added afterwards and stays unducked. The master encoder
and recorded loop data are unchanged. Switching Off or losing external clock restores unity smoothly.
Stopping a loop does not turn off the internal-clock sidechain. No new audio buffer is allocated. Device CPU cost and exact
flash/RAM totals require a fresh firmware build and hardware test.

## New reverbs

FX > Reverb: KNOB 1 Size, KNOB 2 Damp, KNOB 3 Type, KNOB 4 Amount.
Type offers Room / Spring / Ambient / Church. Ambient has a leaf icon;
Church has a Latin Christian cross. Existing Shimmer is a separate effect and is preserved.
Ambient uses cross-coupled diffusion and a warm tail. Church uses longer delay lines and
pre-delay. Both reuse the existing reverb buffers; no new static RAM or pool buffers.
The new code still adds flash and processing work; exact device usage requires a new build.
Reverb type is a shared global bus setting, as before, rather than an independent reverb per engine.

## Combined previous changes

- Prophet enabled, DSP code included in the executable image, lookup tables loaded into RAM.
- With CPU1 online, CZ-1 and Prophet allow six chord voices, including with BASS. Prophet has six separate DSP states; its native per-voice cost stays three units.
- Serial fallback: CZ-1 five; Prophet five without BASS, four with BASS.
- When a six-note chord needs fewer voices: omit sixth first, then seventh, then fifth. Protect the root and major/minor third across voicings, including swag.
- The CPU overload guard keeps these degree priorities; dual-core scheduling is not a guarantee against overload.
- Engine-switch note queue can hold all voices, avoiding loss of an inverted chord's third.
- SELECT opens the shared swag / rosen menu: KNOB 1 swag, KNOB 2 rosen. GLOBAL retains ordinary Options/shift behavior.
- Ping Pong alternates the current sound A and the following sound B: A / B / A / B.
  Favourites use sounds from the Favourites pool.

## SELECT: swag voicing mode and exclusive sevenths

Tap SELECT (or hold it) to open **swag / rosen**. KNOB 2 independently selects rosen Off / Next / Random / Ping Pong. Automatic rosen changes do not display preset popups, including favourites and user sounds; manual sound selection still does. Turn KNOB 1 or the SELECT
encoder to choose Off / Ping Pong / Random / Tennis. HOME or OCT- closes the menu; the root
keys keep playing while it is open. SELECT is now assigned to this menu, including
from the sound editor. Other sound-editor navigation remains available.

- Off: ordinary manual voicing. Turning automation off keeps the current inversion.
- Ping Pong: range -1..+1; from zero: 0, +1, 0, -1, 0, +1, ...
- Tennis: the previous wider movement, range -3..+5; from zero:
  0, +1, +2, +3, +4, +5, +4, +3, +2, +1, 0, -1, -2, -3, -2, ...
  Both start from the current inversion clamped to their range, initially move
  upwards, and reverse at the endpoints without repeating them.
- Random: a new inversion between -3 and +5 for each live chord, excluding the
  immediately preceding inversion.

A new root press, same-root retrigger, or chord-pad press counts as a live chord.
Single notes, note-offs, modifier edits, individual arp/pattern steps and recorded
loop playback do not advance the cycle. Each already held chord keeps its own
inversion until a manual voicing edit. This mode starts Off at boot and is session
only, like rosen mode. Both automatic modes can operate together independently.

Pressing m7 clears M7; pressing M7 clears m7. This applies to held-chord replacement
in Simple, Advanced and Free, future chords, and LOCK-latched modifiers. Releasing
an older superseded seventh does not turn the newer one off or bring the old one back.
The existing toggle behavior for repeating the same extension is otherwise preserved.

Scale/Key Mode is removed from the UI and from harmonic resolution. Black keys
remain chromatic: no automatic root shifting or diatonic chord assignment. Transpose
is now in the ordinary GLOBAL Options menu; Single Notes and Split Point remain there.
Old settings still load. Their retired scale bytes are zeroed and cannot reactivate
Key Mode. The settings record layout/version is unchanged. Only no-op compatibility
entry points and reserved fields remain for older callers/records; the scale table,
scale selection screen and its processing are removed.

The inherited general engine suite still contains obsolete Key Mode expectations;
use the selected checks below for this revision. No claim is made that those old
expectations or the legacy golden suite pass.

## SEQ held: loop transpose on KNOB 4

Hold SEQ to open the metronome menu. KNOB 1 still controls click level and the
SELECT encoder selects the time signature. KNOB 4 now controls **Loop trans**:
-12..+12 semitones, one semitone per detent, shown as `-12 st`, `0 st`, `+12 st`
with a pitch/staff icon. The edited cell highlights as the knob turns.

This is a session-wide playback offset for loops. It starts at 0 on power-up
and remains in force when stopping/restarting playback or changing loop slots.
It is independent of the live keyboard Transpose setting. It shifts the loop's
MAIN/RAW chord notes and its BASS, including octave changes, and affects active
loop voices immediately. Changing it releases the old notes and re-attacks the
new notes (perform gestures restart); the loop transport and original scheduled
note-off time remain unchanged. Live notes are not transposed by this control.
At MIDI limits roots are clamped to 0..127; returning the control derives the
pitch from the original recorded root, so shifts never accumulate.

Recorded loop data, slots and backups are not rewritten or transposed. New
recording/overdub still captures live chord roots; a loop's own playback does
not record itself. Returning the control to zero restores the original pitch.
The settings and loop record formats remain unchanged.

## Mac: emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage24"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

Tests generate fresh demonstration WAVs in build/new-feature-tests/reverb-demo;
these are not the legacy golden audio files. The legacy golden audio is not regenerated
or validated by these selected checks.

## Compile the actual device firmware

```sh
mkdir -p build/host
FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/reverb-build.log 2>&1
build_status=$?
tail -n 30 build/host/reverb-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Only after exit code 0, check the new package:

```sh
python3 tests/transporter_shim_test.py
shasum -a 256 build/choralroot.fwsc
```

No prebuilt firmware is supplied. This avoids accidentally installing an older package.
No flash operation has been performed. No device CPU timing or hardware audio test has
been performed for Ambient / Church. A successful host test does not prove bootloader
protection, recovery, or safe flashing. Review the new build layout and package first.

QUAD source is unchanged; existing legacy golden files are preserved.

## CZ-1 hardware investigation: overload-aware chord priorities

The uploaded firmware SHA-256 was 3572819126695f27ca4020a6d12045024e4a3b90ad808daad45de402c6016caa; its sources match the previous five-voice CZ build. The existing five-voice filter is retained.

A forced CPU-overload regression reproduces an additional failure: the old audio guard removes the oldest held non-bass note, including the third. Normal host mixing never injects this guard request, so earlier host chord checks did not exercise it.

The CPU guard and shared voice allocator now consult captured chord roots and actual transposed notes for CZ-1/Prophet. CZ and Prophet sacrifice sixth first, seventh next, then other extensions before fifth/root/third. Shared chord tones receive the strongest owner priority. For generated CZ/Prophet chords, the lowest inversion note is no longer automatically exempt from degree-based sacrifice; this avoids protecting a sixth merely because an inversion puts it lowest. The 85% overload threshold and released-tail priority remain unchanged. The guard may still reduce polyphony if the device cannot meet its audio deadline; this change preserves the third preferentially rather than guaranteeing five voices under unlimited overload.

Target CPU overload is a plausible explanation of the observed hardware behavior, not yet confirmed by hardware counter readings. Use the existing serial `status` command to inspect `cpu_pct` and `voices_shed`. This source revision still requires a fresh Mac target build, package tests, and FM1 verification. No prebuilt firmware is distributed.

Validation added for all 65 CZ factory entries (including INIT), every bass engine first preset, inversion -3..+5, bass retrigger; 19,890 checks. Forced CPU guard tests span CZ factory tones and Prophet, major/minor, bass Off/On, inversions -3..+5, and part transpose -12/0/+12; 42,553 checks. These simulate overload decisions rather than measuring target CPU time.

## rosen automatic changes preserve FX

Next, Random and Ping Pong now retain the four current FX amounts (Reverb, Chorus, Delay, Drive) after loading the next sound. Stored amounts are preserved when FX is Off, so re-enabling FX restores the chosen mix. This covers ordinary engine pools and favourites, including user sounds and cross-engine favourites. The shared bus parameters/models and BASS sends remain unchanged. Manual preset selection retains its previous behavior.

The fix uses a four-byte local snapshot, with no new persistent state or audio buffers. Fresh target build size/layout/package validation and hardware confirmation remain required.
