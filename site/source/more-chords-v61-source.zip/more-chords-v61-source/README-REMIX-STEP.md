# Choralroot Remix — 20 loops and global Step sequencer

Complete project: extract `Choralroot-remix-step20-keys-loop-bass` alongside your current folder. All preceding Remix changes, including Prophet USER saves, Simple live editing, bounded Morph variation, dual core, BASS, Gate, reverb and MIDI fixes are included. No obsolete compiled device firmware is included.

## Step sequencer

Hold **SEQ** to open the editor, in any Play mode. The keyboard and PRESET encoder keep their normal functions. The sequencer uses the length selected in the menu opened by holding **PLAY**, up to **8 bars**, always 4/4. The default is **2 bars with 1/4 steps** (8 steps). If live-recording Free is selected, entering Step switches the menu to 2 bars so the grid has a definite length; Free remains available for live recording.

| Control | Action inside the editor |
| --- | --- |
| FX, SEL, ENV, LFO, HOME, SAVE, ARP, SEQ | Eight steps on the displayed page |
| Short press on an empty step | Insert the currently played note/chord, or the last released gesture |
| Short press on an occupied step | Delete it; the cell becomes a rest |
| Hold a step, including SEQ | When stopped, hear its contents until release; while playing, select it for length editing without preview |
| SELECT while holding a step | Extend/shorten that step's **note/chord length only**, without moving the other steps |
| SELECT without a held step | Select a step; moving past a page boundary changes page |
| ALGORITHM | Change the **global step grid** for the whole sequence: 1/16, 1/8, **1/4 default**, 1/2, 1/1 |
| OCT+ / OCT− | Raise / lower the live keyboard octave (−2…+2); keep the current page |
| Hold EDIT or GLOBAL | Leave the editor, keeping the current playback state |
| EDIT / GLOBAL short press | Previous / next page |
| Hold PLAY | Leave the editor and open the Play/loop menu; keep the current playback state |
| PLAY short press | Existing transport: play/stop |
| Knob 1 | Click level; zero Off, turning above zero enables it |
| Knob 2 | BPM; external MIDI clock retains ownership |
| Knob 3 | Sidechain On/Off |
| Knob 4 | Loop transpose, −12…+12 semitones |

Creating or editing a stopped sequence **does not start it**. Use a short **PLAY** press to start or stop. With MIDI Clock set to **IN**, external MIDI **Start / Continue / Stop** use the same transport as ordinary loops, via USB or TRS: Start restarts from the beginning, Continue starts a stopped sequence, and clock pulses alone do not start it. Editing during playback keeps it playing.

The LCD shows page, selected step and global grid duration. During playback, a **small white downward arrow** marks the step currently playing, separately from SELECT and note colours. A compact **PLAY current/total** counter remains visible even when the playing step is on another page. Page selection stays manual; the marker disappears on Stop. It uses the actual loop transport position, including MIDI sync, rather than a separate display timer. **Orange cells contain a note/chord onset; green cells show a note/chord carried from an earlier step.** A green bar links the held duration across the cells, including the next page. If a new occupied step overlaps a sustained note, its cell stays orange with the green bar underneath. Shortening or deleting the source immediately updates the carry indication; green alone does not mean a separately recorded step. While holding a step, `N:` shows the individual note length as a fraction of a whole note. Occupied step LEDs stay lit in either LED theme. Cells beyond the configured sequence length are inactive; they do not extend the sequence. The number of pages follows the chosen length and grid: **8 bars at 1/16 = 128 steps / 16 pages**.

SELECT while holding a step adjusts note length in multiples of the current grid interval, between one interval and the remaining sequence length. Chords and keys-only groups are lengthened together. ALGORITHM changes the grid while **preserving every note/chord onset and gate in musical time**, the bar length and the running transport. For example, quarter-note cells 1, 2, 3, 4 appear in eighth-note cells 1, 3, 5, 7. A coarser grid groups multiple onsets in the same displayed cell; notes between grid boundaries retain their exact original timing and reappear separately on a finer grid. Tapping an occupied coarse cell deletes all onsets inside that interval; held preview auditions them as a group. Only shortening the total loop length can require clearing later notes first.

**Preview is available only while stopped.** Starting playback with local PLAY or MIDI ends any existing audition immediately; stopping again while the step is still held does not retrigger it. Hold/SELECT editing works during playback without adding preview voices.

Preview uses independent temporary owners, with the normal synth voice budget; it does not alter saved pad data, record a gesture, reset Simple extensions, advance Swag, or request Rosen/Morph randomization. Releasing the step, changing page, leaving the editor and panic end it. Its release still clears ownership if the UI event queue fills. REC inside the editor directs you to use the step buttons; legacy live/append recording modes remain outside it.

## Saving sequences and 20 loop slots

Sequences use the **same Save/Load/Delete slots and workflow as loops**:

1. Stop playback with a short PLAY press if you want to save immediately. Saving while playing retains the existing “save at stop” behavior.
2. Leave the editor by holding EDIT, GLOBAL or PLAY.
3. Hold SAVE to open the loop slots. Choose a slot with the first ten white root keys; use the **last keyboard key** to switch **1–10 / 11–20**.
4. Choose Save and press OCT+ while the slot menu is open. The ordinary loop workflow is unchanged.

**Delete:** stop playback/recording, hold SAVE, choose the slot and Delete, then confirm with **OCT+**. Both flash copies are erased. If this is the loaded slot, its RAM sequence is cleared too, so PLAY cannot restart a supposedly deleted loop; any deferred save of that sequence is cancelled. Deleting another slot keeps the loaded sequence intact. A pending load, full control queue or flash error is reported without clearing RAM.

The last keyboard key switches banks only in the Play/loop-slot and Save-slot menus. It **flashes on bank 11–20**, regardless of LED theme. It plays normally in the Step editor and performance view. Advance recording traverses all 20 slots and wraps 20 → 1. The stored last slot can be 1–20 without changing the settings record size.

## Storage and compatibility

| Slots | A/B flash pairs |
| --- | --- |
| 1–10 | **0xC8000–0xDBFFF**, unchanged |
| 11–20 | **0xB4000–0xC7FFF**, formerly unused after the QUAD store |

All 20 slots retain the two-copy CRC/commit scheme. This map is guarded against a SAMPLE-engine build; the retired sample sectors cannot serve both features. The safe-mode Flash Data erase and the firmware/web/Python backup paths include both banks; loop backup IDs are **40–59**. The boot stub, app/update-loader areas, preset-bank addresses and HAL are unchanged.

New global sequences use a **version-3 loop record**, up to **3792 bytes** in the existing **3840-byte** sector payload. V1 loops and V2 variable-duration grids remain readable if they are within the new 8-bar limit. Changing a legacy grid normalizes its layout to the global grid while retaining the original event times and note gates. Older firmware cannot load V3 sequences or access slots 11–20. Existing longer records are **not erased or silently truncated**: loading/restore is refused, and their stored bytes remain available for backup.

## Just-keys chords and sequencer Bass

With **no chords, just keys** and **Bass enabled**, three or more distinct single notes played by the sequencer now generate a Bass on their lowest note, using the current Bass preset and settings. Hold the keyboard notes while inserting an empty step; the saved sequence still contains the original independent notes, not an extra chord-track bass note. Existing saved raw-note sequences work too: no slot conversion or re-recording is required.

Live keyboard and sequencer each have their own aggregate Bass owner and three-note threshold. They never combine notes to trigger a bass accidentally, and releasing one does not release the other's shared pitch. Stop, Clear and Panic end the sequencer bass. Loop transpose, Bass octave/mode, Crystal clock and Bass stream/on-off controls apply normally. Preview notes and chord-type loop events are excluded from this raw-note aggregate. Bass is reconstructed during playback, so **just-keys mode and Bass must remain enabled**; the loop does not store a separate Bass preset.

## Prophet Bass restored

Prophet factory and USER presets can again be added to the Bass collection, selected, edited, overwritten and saved as new USER sounds. Existing Prophet Bass references work again. The old Stage33 prohibition and its message have been removed; Morph remains chords-only. Native Prophet patch loads/edits keep the Bass track mono, while chord allocation remains unchanged.

The existing CPU routing, two chord kernels on CPU1, 192-frame audio buffer, boot stub, update loader and flash layout are unchanged. Host tests compare worker/serial rendering and saved native patch data. They do not prove real FM1 audio deadline headroom: Prophet on both chords and Bass previously produced clicks under load, so that combination still needs device validation. No new target ELF or firmware package is included.

## Previous fixes retained

- Simple has Advanced-style live chord-quality/extension editing, with 6/7/9 cleared on the **next played key gesture**, not on a MAJ/MIN edit of a held chord. LOCK and LEDs follow it; Advanced is unchanged.
- Prophet Overwrite and new USER saves retain the native patch. Older records lacking native data cannot recover already-lost edits: they use their bound factory patch or explicit INIT and should be resaved. Full-bank backup retains native payload; the old generic parameter-only slot protocol is not a full Prophet export.
- Morph has moderately wider variation across its six supported sources while retaining protected carrier envelopes/levels, tuning, algorithms, routing/resonance, tighter QUAD/Lo-Fi limits, 2-second speed and Amount 60 defaults.

## Test on the Mac first

```sh
cd "$HOME/Downloads/Choralroot-remix-step20-keys-loop-bass"
source "$HOME/.venv/bin/activate"
sh tests/run_remix_tests.sh &&
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Additional regressions: `sh tests/run_new_features.sh` and `sh tests/run_dualcore_tests.sh`. The new runner also checks fake-MIDI Python backup/restore and the web backup client when Node is available. These checks do not flash hardware or regenerate legacy golden audio.

The JieLi target build must still be run on the Mac, with its flash/RAM/stack checks inspected before considering installation. Host/emulator tests do not prove device deadlines or interrupted-install recovery.
