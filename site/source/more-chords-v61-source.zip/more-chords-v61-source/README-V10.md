# Choralroot Remix V10 — engine levels and CS-1 editor/voice replacement

Relative to V9 buildfix3:
- CZ-1: -6 dB on the native engine bus, after CPU0/CPU1 voice merge and before shared FX. Both chord and Bass use the trim once.
- CS-1: +6 dB, now +18 dB versus its initial V9 integration. KR106: +2 dB beyond buildfix3. Gains are native-engine trims; master limiting can reduce the audible increase on loud patches.
- CS-1: oscillator/color/touch pages pair channel I and II in two rows, with distinct labels and bar controls. Both VCA ADSRs are drawn side-by-side. Filter response follows native LP controls, or HP while its cutoff/resonance knob is being adjusted. All 102 patch bytes and USER layouts are preserved.
- CS-1: newest generated chord has priority over earlier held chords, including inversions and shared notes. Pending notes wait for fading old voices rather than stealing newly started voices. Raw MIDI/keys allocation replaces the oldest voice instead of permanently protecting the older lowest note. Changes to allocation priority are scoped to CS-1.
- CS-1 added to the existing exact-degree/capacity logic, including offline fallback. Online rendering remains four chord voices on CPU0, two on CPU1, Bass on CPU1. No audio buffer/latency change.

Validation:
- 1,300 overlapping-CS1 fixtures: all 52 presets, major/minor six-note chords, inversions -3/+1/+5, rising/falling roots, rapid queued retriggers, shared-note releases, raw MIDI/keys and Bass. New chord tones all present; release cleanup passes. The regression was reproduced before the fade-slot fix.
- CS1: 576 native factory/worker/USER fixtures, exact serial/worker PCM/state; 1,277,952 native DSP stress samples under UBSan; native record clients pass.
- KR106: 471 factory/worker/USER fixtures; 512,000 native stress samples under UBSan.
- Existing CPU1 tests: 5,638 serial/concurrent comparisons, 160 Bass-worker comparisons, mailbox/stack/fallback tests pass. Voice split policy: 10,368 fixtures pass.
- Measured pre-master output deltas on identical synthetic bus input: CZ-1 -6.00380 dB, CS-1 +6.00060 dB, KR106 +2.00002 dB (small integer rounding error).
- CS1 editor controls/rendered screenshots checked; both channels remain independently editable. Whole-firmware syntax passes with CPU1 enabled/disabled.

Known test limitation: tests/run_dualcore_tests.sh stops at the pre-existing cr_loop_modes_ui_test.c line 35 assertion (advance/record arm). The same assertion fails in unmodified V9 buildfix3; recorded in docs/validation-v9/v10-loop-baseline.log. The subsequent voice-split policy test was run separately and passes. The complete general suite is not claimed as passing.

Protected: QUAD source, all 27 boot/stub/loader/golden inputs and V9 buildfix3 integer sensor path remain unchanged. No device flash or legacy golden regeneration performed.

Target limitations: V9 buildfix3 was at 98.8% XIP. This revision requires a fresh Mac target build to confirm size/link and FM1 timing/audio behavior. Host checks cannot establish those margins. Do not install a stale .fwsc.

## Emulator on Mac

    cd "$HOME/Downloads/Choralroot-remix-v10-levels-cs1"
    source "$HOME/.venv/bin/activate"
    sh tests/run_v10_tests.sh &&
    sh tools/emu/build.sh &&
    build/host/emu --no-midi
