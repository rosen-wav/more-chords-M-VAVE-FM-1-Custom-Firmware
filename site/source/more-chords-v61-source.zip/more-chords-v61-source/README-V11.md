# V11 — physical velocity upward compression

A gentle linear upward compression follows the measured physical key velocity, only when Dynamic Velocity is enabled:

| Measured | Played |
|---:|---:|
| 1 | 25 |
| 16 | 37 |
| 32 | 50 |
| 64 | 76 |
| 96 | 102 |
| 127 | 127 |

The 1..127 response remains monotonic with rounding (some adjacent inputs map to the same output). Zero stays zero. Formula: 24 + round(103*v/127). Both analog and top-row probe keys use the curve once at the physical-key input. No MIDI-received velocity or existing loop velocity is remapped; a newly recorded physical performance captures its compressed velocity. Fixed velocity mode/fallback values remain unchanged. Detection thresholds, debounce, ADC calibration, sensor log curve, aftertouch and note timing are unchanged. If a touch generates no note event at all, this curve does not change the detection threshold; device feedback is needed to distinguish that case from very quiet low-velocity notes.

Only two firmware files differ from V10: choralroot.c and new cr_velocity_curve.h. No float math, table, state buffer, audio buffer, boot/storage or engine changes. V10 levels, CS-1 editor and allocation fixes are retained.

Validation: 6,858 fixtures use the actual physical-key wrapper extracted from choralroot.c with analog/probe sensor stubs, under UBSan and strict compiler warnings. Representative curve points, all velocities, monotonicity, zero/fallback and invalid-key handling pass. Existing sensor tests pass under UBSan; whole-firmware host syntax passes with CPU1 off/on. Logs: docs/validation-v9/v11-velocity.log. The emulator does not reproduce physical pressure, so feel must be checked on the FM1. Target size/link still need a new Mac build (V10 had 6,412 bytes XIP remaining).

See README-V10.md for inherited tests and the known old looper-test failure. Legacy goldens were not regenerated or claimed as validated. No device flash performed.
