# V14 — CS-1 3+3 voices, chords only

This build starts from V11, which the user confirmed was installed during the measured click test. The device accumulated 72 audio_late and 88 voices_shed events over about 28 seconds. The V12/V13 smoothing/tail experiments are not included; V11 native CS1 adapter/state is unchanged.

Requested policy:
- Six CS-1 chord voices: three kernels on CPU0, three on CPU1. Only CS-1 changes from the old four-plus-two policy. CZ-1, Prophet, KR106 remain unchanged.
- Worker reservation is nine native budget units for CS-1 (3 x 3), and CPU0 accounting subtracts the actual min(active voices, 3) offloaded units. Generated-chord capacity also uses the new three-slot allowance. Worker dispatch, accounting and note-cap planning use one helper. Offline fallback remains the established serial limits/protection.
- A CS-1 preset cannot be added to BASS; message: "CS-1 preset can't be saved as bass". Factory, bound and added USER presets are covered. Direct Bass load/engine switch/INIT, native USER load and Bass-editor save are guarded. Saved settings cannot restore CS-1 into the Bass part.
- Legacy collection references to factory/USER CS1 sounds switch Bass safely off when selected. They are not erased automatically; they can still be removed through the collection toggle. CS1 USER sounds/favourites/chord editing remain available. Prophet/CZ/KR106 Bass selection remains allowed. Other Bass engines still render on CPU1 with the three CS1 kernels.

Retained: V11 physical soft velocity, V10 levels/editor/new-chord priority, all six chord voices, shared FX and existing buffers. No boot, updater, flash layout, storage record or QUAD change. No golden audio regeneration. MIDI import stays paused.

Host validation:
- 468 native CS1 factory/worker/USER fixtures with seven permitted Bass engines, serial/worker PCM and private state identical; exactly three chord kernels on CPU1 at six voices.
- 1300 six-note overlapping/rapid chords on all 52 presets, inversions and shared-note releases, raw keys/MIDI, Bass; three CPU1 kernels and all new tones present.
- 67 Bass restriction cases: factories/USER/favourites, guarded factory/USER/INIT/editor/boot loads, stale references safely disabled and removable, unaffected other Bass engines.
- 1,277,952 native CS1 stress samples under UBSan; native record clients and serial/dual firmware syntax pass.
- Prophet Bass regression results in docs/validation-v9/v14-prophet-bass.log.

The removed CS1-Bass fixtures were replaced by restriction tests; the smaller fixture count is due to the intended policy change. General historical looper-test failure remains documented in README-V10.md, not claimed fixed.

Target limit: host PCM correctness does not measure FM1 interrupt deadlines. The new split is a load-balancing attempt, not proof clicks are fixed. Build/link/memory must be checked on Mac, then compare audio_late/voices_shed/cpu1_timeouts with the same BLADE BRASS playing test and Bass conditions. V11 had 6396 bytes XIP free. No device flash performed here.

## Host tests

    cd "$HOME/Downloads/Choralroot-remix-v14-cs1-3x3"
    source "$HOME/.venv/bin/activate"
    sh tests/run_v14_tests.sh
