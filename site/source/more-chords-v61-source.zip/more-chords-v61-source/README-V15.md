# V15 — CS-1 rendering optimization

Based on V14. Six CS-1 voices remain split 3 on CPU0 and 3 on CPU1. CS-1 remains unavailable as Bass. Gains, patches, envelopes, buffers and other engines are unchanged.

- Cache filter coefficients when cutoff and resonance are unchanged.
- Prepare patch-dependent gains and automatic aftertouch constants once per patch change.
- Use exact cached reciprocal division for BLEP edges and automatic aftertouch decay.
- Reuse the saw calculation for the Both waveform.

Native PCM and semantic DSP state match V14 byte for byte in 80,510,976 bytes across all 52 presets, extreme/random parameters, six voices, pressure changes, live edits, releases and retriggers. Exact division/BLEP/filter tests include 9 million division cases and 1 million BLEP cases. Native DSP stress runs under UBSan. Run `sh tests/run_v15_tests.sh` to reproduce.

Host CS-1 runtime grows from 5552 to 6288 bytes but still fits the existing 6884-byte engine union; target memory and code size must be checked in the Mac build. Test-only V14 reference code is not compiled into the firmware.

This is not a measured FM1 speedup: target build and clicks require device testing. Compare audio_late and voices_shed before/after the same rapid-chord test, especially with Bass enabled. V14 had only 6252 bytes of XIP free. Do not install unless the build and transporter tests pass.

Build:

    CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh

No MIDI-file import or other new features are included. No golden audio was regenerated. The known unrelated legacy loop-mode UI test failure is outside this change.
