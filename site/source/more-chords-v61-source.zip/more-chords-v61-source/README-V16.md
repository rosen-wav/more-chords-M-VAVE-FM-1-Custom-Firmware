# V16 — CS-1 Light

Based on V15. CS-1 retains both oscillator channels and six voices, split 3 CPU0 + 3 CPU1. CS-1 cannot be saved as Bass; other engines remain available for Bass.

The per-channel resonant high-pass and low-pass filters now run at half the synthesis sample rate. Input averaging reduces aliasing before decimation; linear output reconstruction avoids abrupt sample holds. Filter cutoff coefficients are adjusted for the reduced rate and capped below its Nyquist limit. Channel soft-knee saturation and its fixed VCF level are also computed at half rate, before reconstruction.

This halves the number of per-voice filter updates and channel saturation evaluations (32 to 16 per control block). It does NOT imply a 50% total CPU reduction. Oscillators, sine component, amplitude ramps, envelope/control timing and shared output effects keep their original rates. The sound is intentionally different: softer high frequencies and some change in high-cutoff/resonant character. Patch storage, gains, buffers and voice budgets are unchanged. V15 coefficient/aftertouch caches remain.

Run `sh tests/run_v16_tests.sh`: all 52 factory presets, serial/CPU1 PCM and state equivalence for the new algorithm, native USER round trips, six-voice overlapping chords with Bass, CS-1 Bass policy, whole-firmware syntax and 20,447,232 DSP stress samples under UBSan. Serial/worker equivalence is not V14/V15 audio equivalence: the new algorithm intentionally changes PCM. Historical V15 comparison scripts/logs are retained for provenance, not current acceptance tests.

Target speed, clicks, actual RAM/code size and voice shedding require testing on FM1. Do not install after a failing build or transporter test. The V15 build had only 5676 bytes of XIP free. No target binary is included in this source archive.

No unrelated engine, golden audio or storage format was changed. No MIDI-file import is included. CS-1 remains unavailable in Morph. The pre-existing unrelated legacy loop-mode UI test failure remains outside scope.
