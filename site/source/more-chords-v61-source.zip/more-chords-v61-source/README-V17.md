# V17 — CS-1 removed

CS-1 is no longer selectable or compiled into the firmware. Its native DSP, patch pool, factory bank and editor descriptor are not linked. Runtime union remains sized by FM6. Existing engine IDs are unchanged: ID21 stays reserved as a retired engine, avoiding reinterpretation of saved presets as another engine.

Old native CS-1 USER records and saved sound references are rejected safely; CS-1 sounds are no longer playable. No storage erase/reset or loop deletion is performed. Backup tools retain legacy record export support, but CS-1 is removed from the available factory-preset table. Other engines, gains, soft velocity, Morph, sequencer and dual-core 4+2 chord policies retain their previous behavior. Earlier CS-1 sources/tests/logs are historical and not current acceptance tests.

Tests: `sh tests/run_v17_tests.sh`. Target build and actual flash/RAM space must be checked on the Mac; no target binary is included. Do not run the old CS-1 rendering test scripts against this removal build. No golden audio is regenerated and eng_quad.c remains unchanged.
