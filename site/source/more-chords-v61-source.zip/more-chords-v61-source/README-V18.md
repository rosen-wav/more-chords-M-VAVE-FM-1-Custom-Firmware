# V18 — Cloud engine

Based on V17 (CS-1 removed). New CLOUD engine from Orbit 0.7.1, placed after KR106. Six chord voices: four CPU0, two CPU1. Cloud cannot be saved or loaded as Bass and is not selectable in Morph.

Eight presets: CIRRUS, SILVER MIST, GLASS RAIN, EMBER, SKY FIFTHS, COMET TAIL, DUST PULSE, LOW STRATUS.

Editor OSC / GRAINS: WAVE (oscillator shape), SIZE (grain length), DENS (start rate), SPRD (timing and phase spread).
Editor FILTER / SPECTRUM: DTUN (pitch spread), CHRP (signed pitch sweep), STCK (fifths/octaves), TONE (brightness).
Common envelopes, LFO, velocity and effects remain available.

To control cost, this version caps overlap at two grains per note, twelve for a full six-note chord. It may sound less dense than Orbit's three-voice engine. Both CPUs render independent voice state; six-voice hardware stability must be tested, not assumed.

Run `sh tests/run_cloud_tests.sh` and optionally `sh tests/run_remix_tests.sh`. See docs/CLOUD-INTEGRATION.md for provenance, architectural differences and validation limits. No firmware binary is bundled; build and review the actual memory limits on Mac before installing. CS-1 remains retired. No prior preset IDs or loop formats are renumbered.

Mac test compatibility fix: the standalone DSP fixture omits firmware ELF section attributes on Apple hosts and disables the unused worker shim. Engine and target firmware code are unchanged.
