# V19 — Cloud UI

Based on V18 with the Mac standalone DSP test fix and optional Node.js web tests included. Only three firmware UI files change: cr_edit.c, cr_screen.h and cr_draw.c. All engine/audio source is identical to V18.

- GRAINS: a parameter-driven cloud illustration, readable oscillator shape names, Size in ms, Density in grains/second, Spread.
- SPECTRUM: harmonic/pitch illustration, Detune, Chirp, Stack, Tone.
- Four colored knob cells along the bottom. Envelope/LFO/effects retain their existing pages and controls.
- Geometry updates when parameters change; no audio sampling, new framebuffer or continuous animation.
- Cloud stays six voices 4 CPU0 + 2 CPU1, two grains per voice, eight presets, blocked from Bass and Morph. CS-1 remains retired.

The charts illustrate parameters; they are not measured audio scopes. No parameter ranges or saved sound format changed.

Run `sh tests/run_cloud_ui_tests.sh`, then `sh tools/emu/build.sh` and `build/host/emu --no-midi`. Full audio tests remain `sh tests/run_cloud_tests.sh`.

Validation: real editor states at default/min/max, all eight knobs, text bounds/overlap, six rendered screens, 36 partial/full redraw comparisons and unchanged-screen bypass. Firmware syntax checked for both dual-core settings. DSP/engine files and protected golden inputs unchanged. Preview: docs/cloud-ui-preview.png.

Mac/device build is still required to verify actual flash/RAM usage and hardware UI cost. No target binary is included.
