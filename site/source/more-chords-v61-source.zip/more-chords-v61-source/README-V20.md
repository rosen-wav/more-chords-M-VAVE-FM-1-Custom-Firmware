# V20 — Cloud, three grains per voice

Based on V19 UI. Cloud increases its fixed private grain slots from two to three per voice: at most 18 grains across a six-note chord. Normalization adds the upstream 1/sqrt(3) Q15 gain (18918), preserving the existing overlap-aware gain law. Three-grain overlap can sound denser, but it is not a master-volume boost. Density and Size must allow sufficient overlap to hear the difference.

Six voices remain split 4 CPU0 + 2 CPU1. At full occupancy the grain loops process up to 50% more grains than V19; this does not mean 50% more total CPU. Fixed allocation, no cross-core shared RNG/grain writes. Cloud remains unavailable as Bass and in Morph. CS-1 stays removed.

The V19 UI, eight presets, all parameter ranges, buffer sizes and USER/loop formats are unchanged. Legacy Cloud presets use the increased cap automatically. No new setting is required.

Run `sh tests/run_cloud_tests.sh` then `sh tools/emu/build.sh` and `build/host/emu --no-midi`. The DSP stress test explicitly reaches three occupied grains per voice. Existing serial/CPU1 PCM/state, six-note overlap, Bass restriction, USER save/reload, editor and storage binding tests remain enabled.

The Cloud runtime is 1600 host bytes (was 1088); it still fits the existing FM6 state union; target build must verify actual memory and code usage. Host tests do not establish FM1 headroom. Compare rapid six-note chords with Bass and effects enabled, and check audio_late/voices_shed deltas if clicks or missing notes occur. No target firmware binary is included.
