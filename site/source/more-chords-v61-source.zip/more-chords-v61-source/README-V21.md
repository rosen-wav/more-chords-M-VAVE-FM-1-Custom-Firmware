# V21 — KR106 chord replacement and three runtime parts

Based on V20: includes Cloud at three grains per voice and the V19 Cloud UI. Six native chord voices remain split 4 CPU0 + 2 CPU1; Bass remains CPU1. Cloud and retired CS-1 cannot be Bass. Prophet, CZ-1 and KR106 remain valid Bass engines.

## KR106 fix

The previous firmware reproduces a loss of new notes when six-note chords overlap with Bass active. The allocator could protect tones from the previous chord and steal/reject incoming tones; a queued fading voice could also cause a newly started tone to be stolen. Extend the already-tested newest-chord priority and fade-queue handling to KR106. Raw keys use oldest-slot replacement instead of protecting the lowest previous note. Native KR106 oscillator/filter/envelope DSP, gain, patch format and preset data are unchanged. This fixes a host-reproduced allocation error; it does not establish hardware timing headroom.

## Three parts

NPART/NTRK now equal three: main chords, Bass, Morph B. The former fourth part was muted and did not supply extra sounding voices. Removing it primarily saves runtime memory and some per-part bookkeeping, rather than directly increasing polyphony. The Morph shadow is still part index2. The existing shared engine union remains intact for each of the three parts.

Host sizes: one eliminated track_t is 2464 bytes; one eliminated native-state union is 6888 bytes. Other per-part arrays also shrink. These are host sizes; the Mac target build must report actual RAM/pool and flash usage. No target binary is bundled.

Current USER records remain 192 bytes; bank3080, settings764 (ChoralRoot block192); loop formats and 48-object backup protocol are unchanged. No reset/erase or preset ID renumbering. Legacy Felucca full-project code in the source tree is not part of ChoralRoot's active persistence path.

## Validation

- V20 baseline reproduced the KR106 overlap failure; log docs/validation-v9/v21-kr-baseline.log.
- 3225 overlap cases across all129 presets with Bass, inversions, major/minor, rapid retriggers, shared releases and raw keys.
- 1641 additional cases: seven Bass engines with chord presets every16 slots, plus all129 raw-key preset cases.
- 471 KR106 factory/worker/USER cases and native DSP stress.
- Three-part size/layout assertions; Morph serial/CPU1+Bass and velocity tests, plus 990 progression audit fixtures.
- Complete Cloud and Remix suites passed; 97 backup checks passed with unchanged object layouts.

Run `sh tests/run_v21_tests.sh` for the integration suites, then `sh tools/emu/build.sh` and `build/host/emu --no-midi`. The extended runner is slower than the focused UI tests. Hardware testing should repeat the same KR106 preset, six-note chord changes, Bass preset and effects; collect audio_late/voices_shed deltas if missing voices remain.

Build warning fix: power-on TRK_DEF and performance mute-gain initializers now contain exactly three entries. Values for the three retained parts are unchanged.
