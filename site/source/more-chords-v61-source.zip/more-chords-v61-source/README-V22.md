# V22 — KR106 lighter DSP and shared Juno chorus

Based on V21, including three runtime parts and Cloud with three grains per voice. Native chord voice split stays 4 CPU0 + 2 CPU1, Bass CPU1. Cloud remains excluded from Bass and Morph.

## KR106

- Remove per-part native chorus processing and its two delay rings. Engine editor has six pages; CHORUS page removed. Other controls remain accessible, including HPF and Level.
- Cache ladder-filter coefficients; recompute at most every four samples when cutoff code changes, immediately on resonance changes. Ladder stages, oscillator, envelope and cutoff slew still run at full sample rate. This reduces repeated reciprocal/coefficient work; fast modulation can differ slightly from V21.
- Refresh envelope parameters only when the four ADSR controls change, instead of repeating conversions for every voice every block.
- Preserve newest-chord allocation and overlapping-note handling from V21. KR106 still supports Bass.

## Shared FX chorus

Select Chorus in FX: knob 1 TYPE (I, II, I+II), knob 2 DEPTH, knob 4 AMOUNT. Replaces the old rate-based chorus for every engine. Stereo antiphase BBD taps use Hermite interpolation and reconstruction filters; depth changes are smoothed. One shared 1024-sample ring replaces the old 2048-sample global ring. The return is wet-only: the existing dry mix is not duplicated. Silent sends drain the tail and then bypass processing.

KR106's old chorus bits remain readable in the unchanged 36-byte patch and USER format, but no longer enable an insert. Raise Chorus AMOUNT in FX to hear it on KR106 or another engine. Existing preset names/IDs, USER storage and loop formats are retained. Native factory chorus settings do not overwrite the user's global FX settings.

## Checks and hardware test

Host tests cover native presets, USER overwrite/reload, CPU1/serial PCM equality, overlapping chords, all three shared chorus modes, stereo output, bounded signal and silent tail cleanup. Cloud and Morph regression suites are included. Protected Quad sources and audio golden fixtures are unchanged.

No target binary or measured FM1 CPU speedup is claimed. Build on your Mac, check target memory limits, then test the same KR106+Bass combination with FX off and on. Compare audio_late and voices_shed deltas; host allocation tests cannot establish target timing headroom.

```
sh tests/run_v22_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```
