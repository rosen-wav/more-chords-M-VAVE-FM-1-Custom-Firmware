# V23 — KR106, Cloud Morph, chorus UI and live nudge

Based on the supplied V22. Three runtime parts, Cloud at three grains per voice, existing engines, USB audio, storage and boot stub are retained.

## KR106

Filter-LFO control values are now calculated once per part/block and reused by its voices. Exact integer scaling replaces three unnecessary divisions. ADSR coefficients are prepared once when the panel changes and copied to voices; immediate note-on edits still take effect before the next block. Flat envelope segments skip interpolation multiplication while retaining envelope tick timing and release ramps. The V22 four-sample filter-coefficient cache remains; no further reduction of filter/audio/envelope sample rate.

A seeded comparison against V22 across all129 factory/INIT patches and live ADSR edits produces the same PCM hash (4379305837765641060). This is an equivalence check, not a hardware performance measurement.

## Cloud in Morph

CLOUD is appended to Morph's source list, preserving earlier source indexes. Select Patch A and Patch B as with the other Morph sources. With CPU1 online, all six A voices render on CPU0 and all six B voices on CPU1, where Bass also renders. Each voice retains three grains: up to18 per patch/36 total. A/B have independent grain state and RNG, use the existing equal-power crossfade, and receive matching notes/controllers. Newest-chord allocation also applies to Cloud inside Morph. No new track/state banks are allocated.

Standalone Cloud is unchanged: six voices split4+2 with CPU1, original parameters and three grains per voice. Cloud is still not a Bass engine. The Morph-only voice budget permits six voices in each private bank; this is not a measured claim of FM1 timing headroom, particularly with expensive Bass/FX. CPU1 is required for the intended two-core workload; the serial fallback shares the normal safety budget.

## Chorus interface

FX > Chorus: knob1 Model (I, II, I+II), knob2 Width, knob4 Amount. Two counter-moving wave symbols identify the stereo chorus. The third cell shows BBD/Stereo as a read-only status. Width/model and amount controls keep their V22 audio behavior; no chorus is reintroduced inside KR106.

## Nudge

Hold PLAY and hold OCT+ to push the clock3% faster, OCT- to pull3% slower. Release OCT or PLAY to return to normal speed while keeping the gained/lost phase. Both OCT buttons cancel the bend while PLAY is held. There is no octave change, panic, start/stop toggle or saved BPM edit from this combination. PLAY's existing held menu remains available. Holding a direction continuously gives a continuous nudge; tap it briefly for fine adjustments. Playback and recording data are not rewritten.

The local musical scheduler, loops, sequencer, arpeggiator, metronome and internally generated MIDI Clock follow the bent time. With external clock, the incoming BPM remains authoritative and the nudge applies locally, including Gate/sidechain phase; a new MIDI Start or clock-source change resets the external phase offset. MIDI input timestamps and audio sample rate are unchanged.

## Validation

- 471 KR106 native factory/USER/CPU1 fixtures;512000 native DSP samples under UBSan;128 static cached-filter reference comparisons.
- 56 Cloud A/B+Bass fixtures covering all8 A presets and seven Bass engines: six voices in both banks, exact serial/parallel PCM/state, actual thread ownership; overlapping generated six-tone chords reach both patches.
- Nudge directions, simultaneous keys, release orders, retained offset, unchanged BPM/transport/octave, external local phase and running-loop data integrity.
- 40 Morph serial/parallel+Bass cases and990 progression fixtures. Full Cloud and Remix suites, including30-loop storage and MIDI transport.
- Six real chorus screen states: text bounds/overlap lint,36 cached/full redraw comparisons and visual inspection.
- Protected Quad sources, golden fixtures and boot-stub files unchanged. Storage layouts and engine IDs unchanged.

First test on Mac:

```sh
sh tests/run_v23_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Compile the firmware on Mac after the emulator test. No target binary is bundled and target flash/RAM/timing must be checked from that build and on-device tests.
