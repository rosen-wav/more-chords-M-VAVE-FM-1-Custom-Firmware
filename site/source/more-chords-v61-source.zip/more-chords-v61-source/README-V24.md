# V24 — lighter shared chorus and finer live nudge

Based on V23; KR106, normal Cloud (3 grains/voice, 4+2 chord split), Cloud Morph (6+6 voices), the chorus UI, presets/loops, USB audio and boot recovery remain included.

## Chorus

The shared FX chorus keeps modes I, II, I+II, their LFO rates/depths, stereo antiphase modulation and the Model/Width/Amount controls.

- Replace Hermite delay reads with bounded 32-bit linear interpolation.
- Calculate model constants and width targets once per block instead of every sample.
- Replace the loud-input rational division with an exact read-only soft-knee table (514 bytes, no extra RAM).
- Use two light RC reconstruction poles per channel, calculated with additions/shifts. This is deliberately a lighter approximation of the prior BBD reconstruction filter; the chorus can sound slightly softer/darker at high frequencies.
- Keep audio-rate LFO, delay taps and width smoothing, avoiding coarse changes of delay position. Silent sends still drain the tail and bypass completely.

The standalone chorus-kernel host benchmark takes about0.65..0.67 times the V23 CPU time in three runs (roughly one third less). This measures this host/compiler only, not total firmware CPU and not the FM1. Device timing and clicks still need testing with KR106+Bass and the same FX settings. No increase to the audio buffer/latency is made.

## Nudge

Hold PLAY, then tap/hold OCT+ to advance or OCT- to retard.

- A brief tap is remembered even if press and release occur between audio blocks. Each tap requests approximately2ms of phase correction, applied over a few milliseconds rather than an abrupt clock jump.
- Held correction starts at1%, rises to3% after300ms and6% after900ms. Small adjustments stay fine; a longer hold catches up more quickly.
- Release ends the held speed bend; any tiny pending tap correction finishes, then the original speed resumes with the accumulated phase retained.
- The saved BPM, audio sample rate, keyboard octave, sequence data and play/stop state are unchanged. Backward nudging never rewinds scheduler time. Release remains safe with a full UI event queue.
- External MIDI tempo remains authoritative. The existing local external-clock phase adjustment and MIDI Start/source-change resets are retained.

## Validation and testing

Run:

```sh
sh tests/run_v24_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Checks include exact input soft-knee equivalence over131072 input values, all three stereo modes,800000 chorus samples and live parameter changes under UBSan, bounded/DC continuity, tail cleanup and exact silent bypass. Nudge tests cover tiny taps, progressive holds, monotonic backward correction, retained phase, release order/full queue, external local phase and playing-loop integrity. KR106 native/USER/worker, Cloud Morph6+6, Morph and sequencer/storage regression suites remain covered. Protected Quad/golden/stub inputs are unchanged.

Optional host-only chorus-kernel benchmark: compile `tests/cr_chorus_bench.c` with the same include/pthread flags as the other host fixtures; `cr_v23_chorus_reference.h` is a test-only copy of the previous kernel and is not included in the firmware.

No target binary is bundled. Build on Mac and review target memory limits before installation, then test KR106 with Bass and Chorus active.
