# V25 — stronger temporary nudge and another chorus reduction

Based on V24, including KR106 optimizations, Cloud3 grains per voice and Cloud Morph6+6.

## Nudge

Hold PLAY and press/hold OCT+ to temporarily accelerate, OCT- to temporarily slow down. The bend is now immediately15% in either direction and becomes25% after500ms held. Release returns to the normal clock speed while retaining the gained/lost phase. The saved BPM is unchanged. Tiny2ms tap capture, safe release, monotonic backwards time, local external-clock correction and original PLAY/menu behavior remain included. The screen says Nudge faster/slower, avoiding a stale numeric rate during the stronger held bend.

## Chorus

Move the two-pole RC reconstruction filter to the mono delay input, instead of running a separate two-pole filter on each stereo output. Two independent antiphase taps remain: this does not collapse the stereo return. It halves the reconstruction stages per sample, removes one filter state (8 bytes) and keeps the V24 modes, levels, full-rate modulation/width smoothing, input knee and silent bypass.

At zero width this filter relocation gives exactly the V24 PCM in the six test conditions. At nonzero width it is an approximation because time-varying delay and filtering do not commute exactly; the controlled tonal fixture has less than1ppm relative squared error in all three modes. This is not a guarantee of identical sound for every signal.

An equal-call-boundary host benchmark measured V25/V24 chorus time ratios0.91,0.91,0.97 in three trials. This is a small further host reduction, not an FM1 CPU/headroom measurement. The benchmark forces equal indirect call boundaries so that an inlined test-only reference is not unfairly compared with an out-of-line firmware kernel.

## Validation and next test

- KR106 factory/USER/worker fixtures and native DSP stress.
- Updated nudge checks:15% immediately,25% held, tiny taps, both directions, retained phase, safe release/full queue, external local phase, running-loop data integrity.
- Cloud Morph56 A/B+Bass fixtures and overlapping six-tone chords, actual CPU0/CPU1 ownership; full Morph audit.
- Chorus800000 stress samples under UBSan, stereo modes, control changes, DC bounds, tail cleanup; V24 exact zero-width/tonal comparison across600000 samples.
- Protected Quad/golden/boot-stub inputs and preset/loop storage formats unchanged.

```sh
sh tests/run_v25_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Build on Mac before installing; no target binary is bundled. On FM1 repeat the same KR106+Bass/Chorus settings and test the stronger PLAY+OCT bend. CPU deadline margin must be confirmed on the device.
