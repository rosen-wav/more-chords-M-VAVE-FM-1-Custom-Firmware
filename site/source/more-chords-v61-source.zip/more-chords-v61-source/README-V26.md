# V26 — KR106 shared controls and parallel chorus

Based on V25. Six KR106 chord voices remain4 on CPU0+2 on CPU1, with Bass on CPU1. V25 nudge15% immediately/25% after500ms, Cloud3 grains, Cloud Morph6+6, chorus modes/UI, USB audio, storage and boot stub remain included.

## KR106

Prepare pulse-width edges and pitch-LFO values once per part/block and reuse them across its voices. Split the exact filter DAC calculation into a shared cutoff/LFO/bend base and a per-voice envelope/key stage. Key tracking is prepared once per voice block. Cache panel constants during preparation and remove intermediate LFO buffers that no longer need storing.

The oscillator/ladder/envelope/CV slew sample rate and the V25 four-sample filter-coefficient cache are retained. One million prepared-DCO samples/state comparisons and one million full-vs-split DAC cases (including overflow/polarity) match exactly. A seeded output comparison covering129 factory/INIT panels,256 blocks each gives2,113,536 identical stereo PCM values versus V25. Voice allocation and patch formats are unchanged.

The KR106-only host workload benchmark is included as a diagnostic; host timings do not establish FM1 savings or deadlines.

## Chorus with KR106

Keep the V25 chorus kernel. When KR106 is the chord engine and CPU1 is online, submit the shared chorus to CPU1 after the native chord/Bass job has completed. CPU0 simultaneously renders delay/reverb, then joins the chorus job and mixes its return into this same audio block. No extra block is queued and no new audio-buffer latency is introduced. A128-byte temporary mono-return buffer is added in the existing pool.

The chorus stays serial for other chord engines, including Morph, or if CPU1 is offline/busy. Silent chorus sends with no tail do not dispatch another job. Existing worker failure handling is preserved. This redistributes the critical CPU0 work; it does not claim fewer total chorus DSP operations than V25. Device timing must be measured, including the extra worker dispatch.

Console `status` now include `cpu1_chorus_jobs`: it should increase with KR106 and an audible Chorus send, helping verify that the worker path is active.

## Validation

- KR106 471 factory/USER/native worker fixtures and512000 native DSP samples under UBSan.
- Exact prepared DCO and filter DAC reference checks; seeded V25 PCM equivalence across all129 panels.
- 756 real serial/CPU1 FX fixtures: nine KR106 panels, seven Bass engines, four reverbs, three chorus models; exact PCM/native/FX states, same-block join, offline/busy/silent fallbacks.
- 1641 additional KR106 overlapping-chord/Bass fixtures, plus the inherited newest-chord allocation coverage.
- Cloud Morph6+6 actual worker ownership, Morph/progression audit and V25 nudge checks retained.
- Protected Quad/golden/boot-stub files and preset/loop layouts unchanged.

```sh
sh tests/run_v26_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Build on Mac and check target memory/CPU1 guards before flashing. Then repeat KR106+Bass+Chorus with your usual FX, verify `cpu1_chorus_jobs`, and compare `audio_late`/`voices_shed` deltas. No target binary or measured on-device click fix is bundled.
