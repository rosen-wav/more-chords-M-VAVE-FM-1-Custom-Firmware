# V27 — MORE CHORDS startup artwork

The supplied artwork replaces the startup stripes on the 240×240 LCD, including
the initial hardware boot screen and the UI startup period. The regular idle
screen and Safe mode recovery screen remain unchanged.

The full square image is resized without cropping. A 16-colour RGB565 palette
and row-indexed RLE take 18,650 bytes in flash; decoding uses the existing strip
canvas, with no extra framebuffer, heap allocation or audio processing cost.
The checked-in header is ready to build. Regenerate with
`python3 tools/gen_boot_image.py` (Pillow required).

All V26 KR106/chorus optimizations are included. Host render and syntax checks
are verified; final flash/RAM sizing requires the FM-1 target build on macOS.

Run `sh tests/run_boot_art_test.sh`, then `sh tools/emu/build.sh` and
`build/host/emu --no-midi` to preview startup.
