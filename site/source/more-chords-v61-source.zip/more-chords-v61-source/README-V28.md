# V28 — KR106 5+1 and startup fix

KR106 now assigns up to one chord voice to CPU1 and the other five to CPU0.
Bass remains on CPU1. Voice allocation, CPU budgets and render dispatch share
this policy. Six-note chords remain available when CPU1 is online; other
engines retain their existing splits. V26 parallel chorus is retained.

The V27 artwork was not reached on hardware: main.c skipped splash(), and the
UI's saved HOME view bypassed the idle-stripes startup branch. Boot now calls
splash() after LCD initialization and completes its DMA transfer. The initial
UI frames explicitly show the artwork regardless of saved HOME view, until
the 1.5-second UI startup period expires or the user interacts. Safe mode and
calibration retain priority. The existing artwork asset is unchanged.

Host checks: tests/run_v28_tests.sh (real worker/serial PCM and state,
overlapping six-note chords with seven Bass engines, 5+1 policy, startup
visibility/expiry/Safe mode, 57600 rendered pixels), plus target syntax checks
with dual core enabled and disabled. Target build and audio timing still need
verification on FM-1. This is a distribution experiment, not a measured CPU
performance improvement.
