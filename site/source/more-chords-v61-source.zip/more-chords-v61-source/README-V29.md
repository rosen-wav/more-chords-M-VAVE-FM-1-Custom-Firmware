# V29 — KR106 light, back to 4+2

KR106 returns to four chord voices on CPU0 and two on CPU1, alongside Bass.
The working V28 startup artwork fix and V26 parallel chorus remain included.

This version changes native DSP arithmetic rather than moving more voices.
The four-pole nonlinear ladder now keeps Q18 integrator states (three fractional
bits below Q15 audio), preserving the original +/-8 audio headroom. Each pole
uses two bounded signed 32-bit products instead of a signed 64-bit product.
The predictor and nonlinear feedback calculations also use bounded 32-bit
products; no 64-bit multiplication remains in the ladder sample kernel.
The split multiply is checked against an int64 reference over a million cases.
The two per-voice coupling/DC filters use bounded 32-bit Q8 states instead of
64-bit states/products. Cutoff/resonance coefficient checks happen every eight
samples instead of four; resonance changes invalidate the cache immediately.
Voice-invariant render parameters are prepared outside the sample loop.

DCO/PolyBLEP, ADSR tick/interpolation, audio-rate modulation and the four audio
filter stages remain at full sample rate. All 129 INIT/factory presets and
native USER editing/storage remain supported. This reduces precision and can
slightly change resonance/quiet tails; it is not bit-identical to V28.
No gain, UI or patch data changes. No added audio block latency or extra voice.

Host validation: tests/run_v29_tests.sh includes actual serial/worker PCM and
state comparisons, seven Bass engines, all chorus/reverb combinations,
overlapping six-note chords, native DSP UBSan stress, startup and renderer checks.
An additional million-sample old/new filter comparison checks state bounds and
reports numerical deviation; it does not establish subjective sound quality.
The tests verify the new implementation is deterministic across both CPUs.

FM-1 build size and the practical improvement to clicks/voice shedding require
the target build and listening test. Host checks cannot establish deadline safety
on the device, and no percentage CPU improvement is claimed.
