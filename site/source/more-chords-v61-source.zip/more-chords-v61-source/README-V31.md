# Remix V31 — SWARM / CLUSTER UI

- SWARM: dedicated layered oscillator illustration, oscillator count indicators, clearer knob names and a harmonic-colour view for Tone. Empty Tone controls are hidden.
- CLUSTER: dedicated orange wave constellation and spectrum views. Oscillator count, wave percentage, curve number and signed spread replace large raw integer readouts. Both views expose its four native controls; no new synthesis parameter is introduced.
- Graphics respond to controls without idle animation or reading the audio stream. Cached redraw regions include the complete illustration.
- Audio engine code, presets, USER encoding, voice routing, Morph, Bass restrictions and original chorus are unchanged from V30.

## Emulator

```sh
cd "$HOME/Downloads/Choralroot-remix-v31-swarm-cluster-ui" &&
source "$HOME/.venv/bin/activate" &&
sh tests/run_v31_ui_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

UI validation uses actual editor screens, visible knob bindings, display-only raw-state preservation, text bounds/overlap checks and 144 full/cached redraw comparisons. Both dual-core configurations are syntax checked. Target compilation and performance still need verification on the Mac/FM1.
