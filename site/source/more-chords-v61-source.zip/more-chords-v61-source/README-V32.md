# Remix V32 — levels, lighter Orbit engines, Bass

## Changes

- CLOUD, SWARM and CLUSTER: +2dB at the engine output, including Morph and Bass where supported. The scale is folded into the existing multiply, without an extra gain pass. Normal master/FX/clean-output limiting still applies.
- SWARM and CLUSTER can be added to the Bass collection. Factory and USER presets, Bass editing/saving and settings restore use the existing paths. CLOUD remains unavailable as Bass.
- CLOUD: computes density/pitch-table division only when starting a grain rather than every control block. Three grains and all grain parameters remain unchanged.
- SWARM: precomputes oscillator Nyquist eligibility and selects the normal harmonic path once per render; zero partial amount avoids the unused second sine lookup. Oscillator count and interpolation remain unchanged.
- CLUSTER: constant-pitch native kernel avoids the 129-word temporary phase array and repeated saturating phase addition per sample. The native 128-sample cadence, feedback, RNG and all eight oscillator state updates remain intact.
- Dedicated V31 UI retained. Standalone six chord voices retain 4+2 scheduling, Bass runs on CPU1. Morph retains six A voices on CPU0 and six B voices on CPU1.

## Validation

```sh
sh tests/run_v32_tests.sh
```

This runs factory/USER Bass tests, settings restore, actual worker-versus-serial PCM/state comparisons (including SWARM/CLUSTER as Bass), overlapping chords, Morph ownership, DSP bounds/UBSan and UI redraw checks. Frozen V31 source references with only the requested output scale provide an independent PCM/state comparison of the optimized DSP.

Host tests cannot establish FM1 deadline headroom. Target build and listening with Bass/FX need testing on the device.

## Emulator

```sh
cd "$HOME/Downloads/Choralroot-remix-v32-orbit-levels-bass" &&
source "$HOME/.venv/bin/activate" &&
sh tests/run_v32_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```
