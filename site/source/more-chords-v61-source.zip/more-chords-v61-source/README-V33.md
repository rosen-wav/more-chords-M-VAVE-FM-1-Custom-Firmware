# Remix V33 — CLOUD two grains

CLOUD uses two grains per voice, including both banks in Morph. Grain overlap normalization automatically follows the two-slot limit. Six chord voices, 4+2 standalone routing and 6+6 Morph routing remain unchanged. The V32 +2dB scale and SWARM/CLUSTER Bass support are retained. CLOUD remains excluded from Bass.

Build on Mac as usual with CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1.

Host validation: Cloud serial/CPU1 PCM and state comparisons with eight Bass engines and four reverbs; both dual-core configurations syntax checked. Device timing/listening still requires FM1 testing.
