# Remix V34 — original CLOUD / SWARM / CLUSTER levels

Removed the V32 +2dB output boost from all three engines, restoring their original output coefficient (VOICE_FS 24000). CLOUD remains at two grains per voice. V32 DSP optimizations, V31 UI and SWARM/CLUSTER Bass support remain intact. CLOUD remains excluded from Bass.

Host validation: optimized/reference PCM+state comparison under UBSan, original-level DSP bounds, and dual-core syntax checks. FM1 build/listening still required; this level correction is not a verified diagnosis of every possible CLUSTER distortion source.
