# Remix V35 — new-engine retrigger continuity and quieter CLUSTER

- CLOUD, SWARM and CLUSTER: Prophet-style last-sample continuity on voice reuse/retrigger. The correction decays over128 samples (2.90ms at44.1kHz), independently of control-block size. Applies to chord, Bass where supported, and Morph A/B voice banks. No second synthesis bank is rendered.
- Existing newest-chord voice allocation is retained and tested across overlapping/generated chords, raw keys and Morph. It was already enabled for these three engines; this release adds the missing PCM correction.
- CLUSTER: another -6dB relative to V34. Output coefficient12028 replaces24000 in the existing multiply, including Bass/Morph. CLOUD and SWARM remain at V34 levels.
- CLOUD retains two grains per voice. Standalone4+2, Morph6+6, SWARM/CLUSTER Bass support and UI are retained.

The correction state lives in the existing per-part engine union and is voice-private; no global shared audio state is added. Correction arithmetic runs only during a retrigger window. Factory synthesis continues unchanged away from retriggers, apart from the requested CLUSTER output level.

```sh
sh tests/run_v35_tests.sh
```

Host checks cover real retrigger adapter continuity, exact128-sample endpoints, other-voice mixing, irregular blocks, rapid retriggers, released/free resets; actual serial/CPU1 PCM/state equivalence, Bass/USER/settings, overlap and Morph tests, plus DSP UBSan and target-config syntax. FM1 target compilation and listening still required.
