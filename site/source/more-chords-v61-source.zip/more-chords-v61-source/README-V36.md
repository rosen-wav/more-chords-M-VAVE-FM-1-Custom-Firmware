# Remix V36 — CLUSTER Light

CLUSTER restores the six dB removed in V35: output multiplier returns from12028 to24000. CLOUD and SWARM are unchanged.

This is an intentionally lighter, gentler CLUSTER synthesis path, not a bit-exact native emulation:

- Maximum4 internal oscillators per note, down from8. Six played chord voices remain, with4 on CPU0 and2 on CPU1. Morph remains6+6 played voices.
- Sample loop uses bounded32-bit table lookup, phase feedback and weighted accumulation. The native signed-wide arithmetic and per-add saturation are removed from the production kernel.
- Feedback is capped to a gentler phase-modulation range. Curve controls the speed of detune drift; Spread controls oscillator separation.
- Smoothed oscillator gains are normalized with native half-scale headroom, including COUNT transitions. Output is not hard clipped in the kernel.
- Original signed16 preset values and USER records remain readable/savable. Legacy COUNT values above4 render/display as4; turning Count edits1..4. Wave/Curve/Spread and patch names remain available. The sound differs from previous releases.
- Per-voice128-sample native buffer cadence,3ms retrigger bridge, newest-chord allocation, Bass support and dedicated UI remain.

## Verification

```sh
sh tests/run_v36_tests.sh
```

Tests cover real worker/serial PCM+state equality, factory/USER and Bass restore, overlapping/generated chords, Morph ownership,3ms bridge, DSP stress under UBSan, gain/headroom invariants, live control changes and UI cache comparisons. Native exact-PCM comparison for CLUSTER has intentionally been retired; CLOUD/SWARM still compare against frozen sources.

The host comparison did not reproduce numerical clipping in the original factory-preset kernel; its saturation operations alone are not a confirmed explanation of the FM1 distortion. The new path reduces both computational work and waveform feedback. Host benchmark timings are recorded as host-only evidence, not an FM1 speed claim. Device compilation, deadline headroom and listening still require testing.

## Emulator

```sh
cd "$HOME/Downloads/Choralroot-remix-v36-cluster-light" &&
source "$HOME/.venv/bin/activate" &&
sh tests/run_v36_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```
