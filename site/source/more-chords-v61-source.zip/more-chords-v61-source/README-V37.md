# Remix V37 — CLUSTER Character

A middle ground between the original native kernel and V36 Light:

- Up to6 internal oscillators per played note (V36 had4; the native path had8). Six played chord voices,4+2 standalone scheduling and6+6 Morph banks remain unchanged.
- Wave again follows the native piecewise response and cubic history, evaluated once per128-sample kernel. History is bounded to +/-8192 and phase feedback to +/-12288, richer than V36's0..8191 without the original unrestricted range.
- Curve uses the native coefficient table to shape evolving detune; Spread drives drift strength and separation. Drift calculations remain at kernel rate.
- Sample synthesis retains32-bit arithmetic, normalized half-scale gain sum,128-sample buffering and the3ms voice-retrigger bridge.
- Output coefficient stays24000: the6dB restored in V36 is retained. No change to CLOUD(two grains), SWARM or Bass availability.
- Signed16 factory/USER records are preserved. Legacy counts7/8 display and render as6; the Count knob edits1..6.

The timbre intentionally differs from both previous paths. Host tests validate bounds, native-state ownership, voice allocation and continuity; listening and real deadline headroom still require the FM1. Host timing comparisons are not an FM1 speed guarantee.

```sh
sh tests/run_v37_tests.sh
```
