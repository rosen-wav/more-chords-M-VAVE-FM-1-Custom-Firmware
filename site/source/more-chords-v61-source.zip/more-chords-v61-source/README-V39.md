# more chords! — V39: DRIFT, WAVE TERRAIN, GRAIN FORMANT + USER64

Experimental source release. **Host tests are not an FM1 compatibility or realtime performance certification.** The PI32V2 build/linker, final memory map and hardware stress tests must pass before installation is recommended.

- NEW: DRIFT — five detuned saw-table oscillators with independent smoothed random drift and small phase displacement. Spread / Drift / Density / Tone.
- NEW: WAVE TERRAIN — four original periodic 16×16 surfaces, bilinear interpolation and a moving elliptical path. Terrain / Orbit / Motion / Depth.
- NEW: GRAIN FORMANT — two overlapping synthetic packets, two vowel resonances each, slow formant movement. Vowel / Density / Grain / Motion. No recorded samples or speech library.
- NEW: 64 USER slots (32 additional), including native FM6/VA/CZ/QUAD patches and Prophet's full saved patch.
- Preserved: existing engine IDs and presets; CLOUD's two grains; SWARM/CLUSTER; original chorus; sequencer/30 loops; current Morph crossfade.
- New engines use the established six-voice 4+2 policy standalone, and two independent six-voice banks in Morph. These policies pass host worker tests; their real hardware deadlines remain unverified. Bass uses the normal one-voice path. Serial fallback follows CLOUD's existing cap.
- All three use the existing approximately 3 ms steal bridge and newest-chord voice allocation.

## Test on the computer

From this folder, with the existing Python environment active:

```sh
sh tests/run_new_engine_tests.sh &&
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Node.js is needed for the JavaScript client tests. The emulator build script targets macOS. The standalone numeric tests support Linux and macOS.

## Build on the Mac

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v39-three-engines" &&
test -f README-V39.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v39-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v39-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```

Inspect the exit code, unresolved symbols and XIP/RAM/POOL results before proceeding. No firmware binary from an earlier version is supplied. A successful host test does not replace this build.

## Storage and backup

U01..U32 keep their original formats and sectors. U33..U64 use compact sound records plus native patches in two logical banks rotated through three spare sectors. No loop slot is removed. The desktop and web clients include the two new backup objects (70/71).

Make a full backup with the updated tools before installing or downgrading. Earlier firmware cannot load the additional slots or new engines. U33..U64 store sounds and factory bindings; they do not carry the obsolete Felucca per-preset pattern format. Unsupported legacy pattern imports are explicitly refused.

See [docs/NEW-ENGINES.md](docs/NEW-ENGINES.md) and [docs/USER64.md](docs/USER64.md) for design, limits and validation.
