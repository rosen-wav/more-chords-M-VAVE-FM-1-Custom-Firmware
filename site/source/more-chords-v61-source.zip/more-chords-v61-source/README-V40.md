# more chords! V40 — dedicated engine screens

UI update on V39. Engine DSP, levels, voice allocation, Morph, USER64 and storage layouts are unchanged.

- DRIFT: five oscillator traces; Spread separates them, Drift bends their paths, Density emphasizes the side oscillators.
- WAVE TERRAIN: surface contours with an elliptical trajectory and a visible reading point. The illustration follows Terrain, Orbit, Motion and Depth.
- GRAIN FORMANT: paired resonance peaks and two grain windows, following the four controls.
- Clear mixed-case control labels and contextual glyphs. All original knob bindings/ranges retained.
- Illustrations update when the parameters change. No idle animation, audio-state access, new frame buffer or floating-point drawing.

The visual bands are parameter illustrations, not real-time oscilloscopes or spectrum analyzers.

```sh
sh tests/run_v40_ui_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

The UI test renders 12 actual firmware screen states (default/minimum/maximum/middle), checks text bounds/overlap, unchanged-screen bypass and every cached/full redraw transition.

PI32V2 build/linker, memory margin and hardware performance remain to be confirmed. See README-V39.md for the engine/USER64 design and earlier host validation.

## Mac build

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v40-engine-ui" &&
test -f README-V40.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v40-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v40-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```
