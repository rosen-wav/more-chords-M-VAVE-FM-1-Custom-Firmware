# more chords! — V42 engines and FX

Changes from the attached V40. This archive contains source and generated assets; no prebuilt FM1 firmware.

## NEW / IMPROVED

- **DRIFT SEL:** Rate changes the speed of independent drift targets/smoothing; Phase deepens phase warping; Round blends the saws toward sine; Tilt balances the two detuned sides. Default zero preserves the earlier patch response. The five separate oscillator lanes distinguish its UI from SWARM.
- **WAVE TERRAIN SEL:** X Shift / Y Shift translate the path across the surface; Skew shears the Y path with X; Smooth softens the output. Four real DSP controls with a dedicated parameter illustration.
- **CLOUD:** two grains per voice retained. Chirp pitch sweep is reduced by a factor of25: the new full scale is the former4%. Fractional exponent interpolation avoids reducing the control to only a few steps. Continuous Wave scan: Sine(0), Triangle(32), Harmonics(64), Saw(96), Square(127), with crossfades between them. Saw/square reuse immutable band-limited tables; no new audio buffers.
- **CLUSTER:** up to seven oscillators. Seven private phase/history/gain lanes; normalized gain sum retains half-scale headroom. COUNT knob/display now reach7. Polyphony remains six voices: oscillator count is a separate control.
- **MORPH:** A/B patch names, source engine, crossfade-position bar and movement mode. INIT now defaults to Up/Down; saved Manual presets retain their mode. Turning Position still selects Manual, as before. All existing dual-patch audio/CPU scheduling is retained.
- **CHURCH:** the only selectable/running reverb algorithm. The old algorithm knob is now Width(0..100%), controlling the stereo difference without changing the mono tail or clearing it. Size, Damp and send remain. Church reuses its Hall tail internally; Hall is no longer a selectable algorithm.
- **Levels:** Prophet, CZ-1 and the BASS engine are2.5dB quieter relative to V40. The trim is applied once to the mixed part level after distortion and before sends; no preset parameter is overwritten.
- **Editor:** empty generic OSC/SEL pages are skipped. Parameterless CLUSTER SEL is removed. Generic one-row screens without a dedicated band receive a normalized parameter overview. All128 selectable editor screens were inspected by an automated editable-control audit.

## FIX / REMOVE

- **GRAIN FORMANT removed** from selectable engines and Morph, and its DSP/factories removed. Engine ID27 remains retired: older records cannot silently become DRIFT/TERRAIN. Other engine IDs and64 USER slots are retained. Client factory-binding tables updated.
- **CZ overlapping chords:** newest generated chord ownership now receives priority, including shared notes, inversion changes, queued steals and releases. This priority is shared by polyphonic engines using the standard allocator. FM6 retains its native allocator; mono engines retain mono behavior. Same-note retriggers still reuse a voice.
- **Startup pop mitigation:** I2S clocks and zero-filled DMA start before releasing the codec control line. DAC audio has200ms settling silence and a20ms fade-in. USB capture is unaffected. The digital envelope is tested, but elimination of the audible hardware pop requires an FM1 test.

DRIFT is not a copy of SWARM: DRIFT uses five band-limited saws, independent random drift targets and phase warping; SWARM uses one to six sine/second-harmonic oscillators with envelope-controlled detune. They share only the host envelope, voice framework and steal bridge.

## Compatibility notes

- No runtime floating-point arithmetic added. DSP uses integers, fixed-point and immutable LUTs.
- Existing project parameter IDs remain fixed. The former reverb algorithm value is now interpreted as Width; projects saved with an old algorithm may open with a narrow/mono Width. Adjust Width and save that project. Older pre-reverb project formats initialize Width to its new default.
- Historical tests for removed Room/Spring/algorithm switching and earlier UI snapshots are superseded by V42 tests; the general source history remains in the archive.
- PI32V2 build, linker, XIP/RAM/POOL margins and real hardware CPU deadlines have **not** been verified here. A host timing result is not an FM1 performance claim.

## Emulator

```sh
cd "$HOME/Downloads/Choralroot-remix-v42-engines-fx" &&
source "$HOME/.venv/bin/activate" &&
sh tests/run_v42_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

## FM1 build

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v42-engines-fx" &&
test -f README-V42.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v42-build.log 2>&1
  build_status=$?
  tail -n45 build/host/v42-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```

Review the build result and memory checks before installation. Host validation details: docs/VALIDATION-V42.md.
