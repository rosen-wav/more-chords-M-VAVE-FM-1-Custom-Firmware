# V44 — Prophet excluded from Bass

Based on V43b (7-oscillator light Cluster, Terrain Smooth, lossless boot RLE).

Prophet factory and USER sounds cannot be added to Bass. Guard factory/USER loading, engine switch/init, editor/save, generic engine setter and settings restore. Existing Prophet Bass references are retained for removal, but selection turns Bass off. Chord Prophet presets and favourites are retained. No storage layout or engine IDs changed.

Test: sh tests/run_v44_tests.sh
Target build/link/memory and hardware checks still required.
