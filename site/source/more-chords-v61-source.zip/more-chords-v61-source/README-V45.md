# V45 — New enlarged boot logo
Based on V44: Prophet excluded from Bass, Cluster light 7 oscillators and Terrain Smooth retained.
New supplied artwork replaces old boot source and compiled image. Main logo enlarged to 216 pixels wide, credits moved closer for 240x240 readability. No old image fallback included.
RGB565 indexed RLE asset: 9125 bytes (+229 vs V43b). No framebuffer or audio change. Boot renderer test: 57600 pixels, row bounds and unchanged-frame cache. Target build/memory and physical boot remain to verify.
