# V46 — Init preset nel menu SAVE

SAVE apre Overwrite / Save as new / Init preset. SELECT o KNOB 1 navigano; OCT+ o SAVE confermano; OCT- annulla. Init preset ripristina il suono iniziale dell’engine e torna all’editor se era aperto. Non modifica i preset salvati. Funziona sui 13 engine visibili, verificati con test host; mantiene le restrizioni dei bassi.

Il nome originale della seconda voce è Save as new (non Save now), mantenuto per chiarezza.

Test: cr_save_init_test.c, tutti gli engine visibili, parametri iniziali, slot salvato intatto e ritorno all’editor. Build PI32V2 e prova FM1 da eseguire sul Mac. Nessun firmware compilato incluso, per evitare di installare il vecchio binario V46.

Build:
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh
