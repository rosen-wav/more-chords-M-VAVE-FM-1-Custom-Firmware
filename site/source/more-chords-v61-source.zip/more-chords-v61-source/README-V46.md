# V46 — CLOUD wavetable banks on ENV

Based on V45: new enlarged boot logo, Prophet excluded from Bass, seven-oscillator light Cluster and Terrain Smooth retained.

## Controls
CLOUD editor -> ENV page 1: Bank (Classic/Warm/Glass/Hollow/Digital), Scan (Off/Up-Down/Forward/Backward), Rate (larger = faster, approximately 0.125..15.9 s/cycle), Depth (bipolar sweep around OSC Wave). ENV page 2 retains the original amp ADSR. OSC Wave is the manual frame position / center of auto scan. Scan Off or Depth zero disables motion. New bank and frame positions are latched at grain creation: existing grains finish their window, so changes crossfade through the grain overlap rather than replacing a live oscillator abruptly. Response depends on grain Size and Density.

## DSP and storage
Classic with Scan Off retains V45 PCM. Four original additive banks, four frames each, 32 samples/frame, six-/two-partial pitch bands. Offline-generated int16 tables, total 2048 bytes. Fixed-point phase and frame interpolation. Pitch band is chosen for the entire grain from both chirp endpoints, preventing mid-grain band jumps. Two grains per voice; unchanged 4+2 standalone and existing six+six Morph policy. New parameters use four per-engine aliases of otherwise inert legacy DIGITAL operator fields; no active CLOUD control or ADSR is overwritten. P_COUNT=91, 192-byte USER records, existing slots, backup/project layouts and engine IDs unchanged. Values save in base and extended USER slots. No extra voice/part arena memory: grain bank/band occupy existing padding, scan phase uses a free voice state word. No floating point in firmware; Python generator is offline only.

Morph regression remains supported; this release does not add new Morph source-selection controls.

## Validation
`sh tests/run_cloud_banks_tests.sh`
- 4,046,848 DSP samples under UBSan: exact Classic PCM, five banks/four scan modes, MIDI notes 0..126, rapid edits, PCM bounds, release cleanup, unchanged state sizes.
- 600 exact actual-worker CPU1 versus serial PCM/state fixtures across Cloud banks/scan and Cluster, factory presets, five Bass engines and Church width.
- ENV knob bindings and navigation; original ADSR preserved; five banks reload through base/extension USER slots; engine-specific descriptors isolated.
- Five real screen states, text bounds/overlap, 25 cached/full redraw comparisons; preview visually checked.
- Existing Morph suite, nine source-engine endpoints and note-off routing passed.
- Dual-core off/on full-firmware host syntax checks and client sound templates passed.
Target PI32V2 build/link/XIP/pool budgets, hardware runtime cost and live transition listening remain to verify. No FM1 performance guarantee from host tests.

## Emulator
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi
