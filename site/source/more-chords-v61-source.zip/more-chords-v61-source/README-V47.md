# V47 — Lossless XIP saving

Base: V46 Init preset. Tutti gli engine, preset, controlli, DSP e funzione Init preset mantenuti.

Il logo di avvio usa ora una codifica RLE con run lunghi e righe condivise. I 57.600 pixel RGB565 restano identici al logo V46 (checksum di riferimento generato prima della modifica). Nessuna decompressione dell'intera immagine in RAM: il renderer scrive ancora nella striscia canvas esistente. Nessuna allocazione aggiunta, nessuna modifica al percorso audio.

Dati logo prima: 9.125 byte. Dopo: 6.151 byte. Riduzione statica: 2.974 byte. Il decoder cambia di poche istruzioni: il guadagno XIP netto va misurato dal linker PI32V2 sul Mac. Non è una promessa di 2.974 byte netti di firmware.

Il progetto usa già -Os e minsize sul codice di interfaccia: queste impostazioni restano invariate. Non sono stati rimossi caratteri, icone, schermate, tabelle sonore o funzioni. Il logo non è ridimensionato né riquantizzato rispetto all'asset V46: solo la codifica cambia.

Validazione host:
- tests/boot_codec_test.py: lunghezze 1..240, righe casuali, alternate e duplicate;
- tests/run_boot_art_test.sh: renderer reale, 57.600 pixel confrontati, checksum della vecchia immagine, bounds e cache; UBSan;
- tools/gen_boot_image.py rigenera esattamente l'asset incluso.

La toolchain PI32V2 e il dispositivo non sono disponibili qui: build/linker e prova FM1 ancora necessari. Nessun binario precedente è incluso.

## Build sul Mac

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v47-xip-lossless" &&
test -f README-V47.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v47-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v47-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```

Solo dopo il successo della build, eseguire i controlli di pacchetto prima del flash. Non utilizzare il vecchio hash V46: la V47 produrrà un hash diverso. Il web installer V46 rimane fissato al precedente firmware e non installerà automaticamente questa versione.
