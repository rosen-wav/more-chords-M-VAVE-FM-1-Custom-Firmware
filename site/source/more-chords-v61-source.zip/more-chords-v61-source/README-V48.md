# V48 — CLOUD: four new wavetable banks

Includes V47 lossless boot-logo compression and V46 Init preset.

CLOUD now has 9 banks on ENV page 1: Classic, Warm, Glass, Hollow, Digital, Silk, Reed, Prism, Pulse.
- Silk: rounded spectra with progressively stronger odd harmonics.
- Reed: shifting third/fifth-harmonic emphasis, for reed-like colours.
- Prism: sparse, bright harmonic peaks. Periodic waveforms, not inharmonic bell synthesis.
- Pulse: changing signed harmonic mixtures, from full to hollow and buzzy.

Each new bank has 4 interpolated frames and 2 pitch bands, matching the existing implementation. Use WAVE to explore the bank or ENV Scan/Rate/Depth for movement. Original banks retain their IDs and exact table samples. Old presets remain compatible; saving a new bank requires this firmware or newer to reproduce it.

Tables grow by 2048 bytes. No change to grain count, render algorithm, voice state size, CPU policy or Morph policy. Actual target CPU time is not measured here. Four new bank names also occupy a few bytes. V47 saves 2974 bytes of image data before decoder differences, so this should fit within that recovery, but only the PI32V2 link can confirm final XIP.

Host tests passed: 6,537,216 DSP samples under UBSan, Classic reference PCM unchanged, all nine banks/four scan modes, live edits, guards, same state size, release cleanup; old table samples compared exactly. UI/USER round-trip tests cover all nine bank IDs and the original ADSR page. Build and physical FM1 testing still required. No compiled firmware included.

## Mac build

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v48-cloud-nine-banks" &&
test -f README-V48.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v48-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v48-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```

After successful build, check the package as usual before installation. The old V46 web installer is pinned to V46 and does not automatically install V48.
