# more chords! V51 — TINES + VECTOR

Progetto sorgente per M-VAVE FM1, basato sullo ZIP V48 pubblicato nella repository rosen-wav, con le modifiche successive qui descritte. ChoralRoot di u/Quixotic7, Felucca e gli autori originali restano accreditati nelle licenze del progetto.

## NEW

- TINES, engine originale electric piano: BODY, TINE e attacco con decadimenti distinti; velocity timbrica, BELL/BARK/DECAY/TREM. Sei preset: SOFT RHODES, HARD TINES, GLASS KEYS, HOUSE EP, WARM MALLET, DREAM KEYS. Nessun campione o istanza FM6.
- VECTOR, quattro famiglie originali di wavetable: SOFT/BRIGHT/HOLLOW/GLASS. Pesi bilineari a somma esatta, smoothing XY/COLOR, tabelle con armoniche limitate e transizione fra bande. X/Y/MOTION/COLOR; MOTION zero ferma la traiettoria.
- Per entrambi: SOUND, FILTER, FILTER ENV indipendente, AMP ENV ADSR, LFO a due righe, matrice MOD a quattro slot. X/Y/COLOR disponibili fra le destinazioni di VECTOR. Filtro SVF e time table condivisi col firmware; nessun framework esterno.
- Sei voci standalone 4+2; in Morph due patch a sei voci ciascuna, anche da engine diversi, CPU0/CPU1. TINES e VECTOR possono essere salvati come basso.

## IMPROVED / FIXED

- Step tenuto fisicamente premuto + KNOB 1: sposta l'intero contenuto nella griglia, anche tra pagine. Scambio con cella occupata; note, accordo, basso, velocity e durata conservati. Senza pressione KNOB 1 mantiene il comportamento precedente.
- CZ-1 non selezionabile, senza DSP/tabelle di fabbrica compilati, escluso da preset e Morph. ID 14 resta riservato; nessun ID successivo rinumerato. Vecchi oggetti di backup preservati opachi; record CZ ritirati ignorati senza perdere gli slot vicini.
- Menu SAVE esplicito a tre scelte: Overwrite / Save as new / Init preset. Init verificato sui 14 engine visibili; non scrive automaticamente sopra uno USER.
- CLOUD mantiene la riduzione di 1,5 dB; wavetable e altri motori preservati.
- Metadati preset e nomi engine aggiornati nei client Python/JavaScript. ID nuovi TINES 28 e VECTOR 29, dopo lo slot GRAIN FORMANT ritirato.

## Verifica e limiti

**NON è una release pronta al flash.** Qui manca la toolchain PI32V2: build.sh termina con `no toolchain`. Nessun linker target eseguito, nessun valore XIP/RAM/POOL target misurato, nessuna prova FM1 o garanzia di deadline CPU. Le misure storiche V48 non sono misure di questa versione. Non viene incluso un vecchio .fwsc rinominato.

I test host passano: DSP con UBSan, estremi, velocity, 66.049 casi XY, 300 accordi sovrapposti con basso, 48 confronti seriale/CPU1, Morph 6+6 concorrente, UI render/layout, USER64, Init, 93 controlli backup, griglia randomizzata e trasportatore. Vedi `docs/V51-VALIDATION.md`.

**Morph:** OSC sceglie engine/preset A e posizione; FILT apre la nuova pagina PATCH B con Engine B, Patch B, Position e Mode. “Same as A” mantiene i vecchi preset; un engine B indipendente permette anche VECTOR + FM6, TINES + CLOUD e le altre combinazioni fra engine già ammessi in Morph. Il valore B usa un campo precedentemente inattivo; layout persistente e indici delle vecchie selezioni sono invariati. Il carico reale delle coppie va misurato su FM1.

**Limite sorgente RF-Tines:** la repository RackForge pubblica esaminata contiene descrizione e control layout, ma non il DSP RF-Tines. Gli altri quattro sorgenti DSP sono stati esaminati. Non è dichiarato un porting di RF-Tines. Analisi e licenze: `docs/TINES-VECTOR-RESEARCH.md`.

## Test host

Dalla cartella del progetto, con compilatore C, Python 3 e header generati inclusi:

```sh
sh tests/run_tines_vector_tests.sh
```

I test concorrenti usano un worker reale e atomiche. UBSan è applicato al percorso DSP nuovo: la suite completa preesistente contiene, fra l'altro, uno shift signed negativo in QUAD; non è stata presentata come integralmente pulita sotto UBSan.

## Build sul Mac

Estrai lo ZIP in Downloads. Incolla il blocco intero:

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v51-tines-vector" &&
test -f README-V51.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v51-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v51-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```

Se termina con codice 0 e tutti i controlli di memoria/linker passano:

```sh
cd "$HOME/Downloads/Choralroot-remix-v51-tines-vector" &&
source "$HOME/.venv/bin/activate" &&
python3 tests/transporter_shim_test.py &&
shasum -a 256 build/choralroot.fwsc &&
python3 tools/fm1_install.py --info
```

Il web installer pubblicato resta V48: questa consegna non lo aggiorna né pubblica modifiche alla repository.
