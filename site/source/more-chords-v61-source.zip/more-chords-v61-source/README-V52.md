# more chords! V52 — VECTOR / TINES UI

Entrambi gli engine TINES e VECTOR sono mantenuti, con gli stessi ID, preset, suono, controlli, dual-core e Morph della V51.

## VECTOR

La pagina SOUND mostra un quadrato XY con SOFT / BRIGHT / HOLLOW / GLASS ai quattro angoli, una griglia discreta, le guide e un puntino centrale. X e Y spostano il puntino; durante il suono il puntino segue la posizione realmente renderizzata dalla voce attiva più recente, inclusi smoothing, MOTION e modulazioni. Senza note mostra la posizione dei controlli. L'orbita tratteggiata indica l'escursione di MOTION.

Non è una finta animazione a tempo: la posizione è copiata dallo stato audio durante lo snapshot UI protetto. Nessun accesso UI allo stato del worker mentre è occupato. Viene riusato un campo di fase inutilizzato della voce: un solo salvataggio di coordinate per blocco da 32 campioni, senza nuove oscillazioni o trigonometriche nel DSP.

## TINES

La pagina SOUND ha tre curve colorate dedicate a BODY, TINE e ATTACK. BELL modifica l'illustrazione metallica, BARK quella del corpo, DECAY le code; l'indicazione TREM OFF / TREM 4Hz chiarisce lo stato del tremolo. Le curve sono illustrazioni dei parametri, non un oscilloscopio audio. BELL / BARK / DECAY / TREM restano sempre leggibili sotto il grafico.

I quattro controlli SOUND di entrambi gli engine mostrano percentuali coerenti. Le altre pagine ENV, FILTER, FILTER ENV, LFO e MOD restano disponibili.

![TINES e VECTOR](docs/v52-test-results/preview.png)

## Verifiche

- Render delle 14 pagine native: zero errori di layout.
- Otto stati dedicati (angoli XY, movimento, estremi TINES) in nove palette: zero sovrapposizioni o testo fuori schermo.
- 64 confronti fra ridisegno parziale e completo; nessun aggiornamento per una schermata invariata.
- 400 snapshot: puntino coincidente con le coordinate audio. MOTION attivo muove il puntino; a zero la posizione si ferma dopo lo smoothing.
- DSP nuovo sotto UBSan: 1.751.040 campioni, preset, velocity ed estremi.
- Rendering audio seriale/CPU1: 48 confronti PCM e stato identici; salvataggio/richiamo e release verificati.
- Sintassi firmware con dual-core disattivato e attivato.

La compatibilità target, XIP/RAM/POOL e prestazioni FM1 richiedono ancora la build PI32V2 sul Mac. Questa consegna non contiene un .fwsc né aggiorna il web installer.

## Emulatore sul Mac

Estrai lo ZIP in Downloads e incolla:

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v52-vector-tines-ui" &&
test -f README-V52.md &&
source "$HOME/.venv/bin/activate" &&
sh tools/emu/build.sh &&
build/host/emu --front
)
```

## Test UI

```sh
sh tests/run_v52_ui_tests.sh
```

I test audio estesi della V51 restano eseguibili con `sh tests/run_tines_vector_tests.sh`.

File principali modificati: firmware/src/cr_screen.h, cr_edit.c, cr_draw.c, cr_out.c, eng_keys_vector.c. Aggiunti tests/cr_v52_ui_test.c, cr_v52_render_test.c, run_v52_ui_tests.sh. Sorgenti e licenze degli engine sono descritti nei documenti V51 inclusi.
