# V53 — Timbre randomizer

Based on V52 (both TINES and VECTOR retained).

## FIXED
- Randomization excludes native LFO and MOD/function pages on every deep engine.
- Shared LFO rate, waveform, phase, fade and all depths remain unchanged.
- Envelope routing/depth and the four modulation-matrix slots remain unchanged.
- FM6 operator AMS sensitivity remains unchanged.
- MORPH keeps modulation speed; only Position and Amount are varied, preserving source/patch choices and mode.
- Corrected the accidental substring match for ON, which excluded TONE and MOTION.
- Variation now scales to each parameter's actual range, including 16-bit controls. It is no longer limited to 24 raw units for those controls.
- Eligible continuous controls choose a different value when an alternative exists. Zero levels/mixes remain protected, and discrete selectors retain their previous policy.

Intrinsic sound controls such as engine Motion/Drift/Trem remain sound controls; dedicated LFO pages and modulation routing are preserved. Randomization remains a bounded variation of the preset captured when the tool opens.

## Unchanged workflow
Hold REC in EDIT. Amount controls strength, Generate previews, Undo restores the captured patch. OCT+ confirms; cancelling restores it. Confirmation does not save to flash: use the normal SAVE menu. FX sends, level and voice mode remain unchanged.

## Validation
Run `sh tests/run_v53_randomizer_tests.sh`.
Host tests cover all 14 visible engines and 2,688 factory/allowed-part/amount combinations, native/shared LFO and MOD preservation, exact parameter/native-blob Undo, cancellation, confirmation and VECTOR USER save/reload. Additional checks cover TONE eligibility and meaningful scaling of 16-bit controls. Existing creative UI/transport tests and firmware syntax checks for both CPU configurations pass.

The PI32V2 target build, linker, XIP/RAM/POOL checks and hardware listening test must still be run on the Mac. No target firmware is bundled. Existing web-installer release metadata has not been repinned; publish only the newly built and validated firmware and matching hash.

## Build on macOS
```sh
(
cd "$HOME/Downloads/Choralroot-remix-v53-timbre-randomizer" &&
test -f README-V53.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
 CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
 PYTHON="$HOME/.venv/bin/python3" sh build.sh \
 > build/host/v53-build.log 2>&1
 build_status=$?
 tail -n 45 build/host/v53-build.log
 printf '\nBuild exit code: %s\n' "$build_status"
}
)
```
