# more chords! V54 — Musical randomizer, VA transitions, TINES/VECTOR Character

Based on the attached V53 source archive. Includes the PI32V2 strcmp correction: firmware code uses direct character checks, without adding a C-library dependency.

## SAVE / Init preset
- SAVE shows Overwrite, Save as new and Init preset together, with Init highlighted.
- SELECT or KNOB 1 chooses the action. Turning KNOB 4 selects Init directly; OCT+ applies it, OCT- cancels.
- Init resets only the working preset of the current engine. It does not overwrite a saved USER slot.
- Tested for all 14 visible engines.

The supplied source already contained Init; its absence on the reported device could not be reproduced from that source alone. V54 makes access explicit and verifies the generated screen and real knob/commit path. Install the newly built V54 package to test the updated menu; an existing website emulator remains a separate build.

## Musical randomization
- Around 8% of parameter range at maximum Amount, instead of around 19%; Spread/Drift variation is reduced further.
- Prioritizes continuous oscillator-shape/mix, filter, feedback and timbral/envelope controls.
- Protects coarse/fine tuning, frequency/ratio offsets, transpose, harmonic tuning, detune, chirp, stack, pitch envelope pages, key/velocity response and discrete algorithm/routing selectors.
- Native LFO and MOD/function pages remain unchanged. Shared LFO speed, waveform, phase, fade and all routes remain unchanged.
- Only an already-active small shared vibrato (depth magnitude 1..8) may vary by one unit, retaining sign and never exceeding 8. No new pitch route is introduced. MORPH speed remains unchanged.
- FX sends, part level and voice mode are preserved. OCT+ confirms, Undo/cancel restores exactly; ordinary SAVE writes to flash.

## VA transitions
- Initial 128-sample fade-in (2.90 ms at 44.1 kHz).
- 128-sample sample-continuity bridge on retrigger/voice replacement, independently on mono/mid and stereo-side output.
- Existing oscillator/filter state is retained on legato retriggers. Other voices already mixed in the output are not faded.
- Dry-prefix copies run only during the initial fade; steady notes do not copy an extra block.
- Voice-private state keeps CPU ownership unchanged. Hardware listening/CPU deadline checks are still required.

## Second SOUND page
In EDIT, tap the OSC section button again to switch between the two SOUND screens.

TINES — CHARACTER:
- BODY: raises the fundamental/body contribution.
- STRIKE: raises the short hammer/attack partial.
- DAMP: increases body/tine damping for shorter modal tails.
- TREM RATE: moves from the original 4 Hz to about 28 Hz; TREM on page 1 controls depth.

VECTOR — VECTOR PATH:
- WIDTH: expands horizontal XY travel around the centre, with bounded edges.
- EDGE: smoothly increases soft-saturated harmonic edge.
- ORBIT RATE: increases the orbit speed when MOTION is active.
- PATH: changes the relative phase of horizontal/vertical orbit movement when MOTION is active.

All four displayed extra controls default to zero, preserving previous factory/USER sound. The third value is stored inversely in dormant OP2 SUS (legacy default 127), so pre-V54 USER records also resolve to zero rather than maximum DAMP/orbit speed. They use existing dormant parameter storage; no preset-format change or engine-ID change. USER saving/reloading and Morph use the same stored parameters. FILTER, FILTER ENV, ENV, LFO and MOD pages remain accessible. Dedicated TINES graphics and the live VECTOR XY display remain on the second page too.

## Validation
`sh tests/run_v54_tests.sh`

Passed host tests:
- 2,688 randomizer factory/allowed-part/Amount combinations across 14 engines, protected native pitch/LFO/MOD values, bounded shared vibrato, exact Undo and USER persistence.
- Init visibility and KNOB4/OCT+ action, all engines; saved USER records remain intact.
- All eight extra DSP controls change rendered PCM; persistence and two SOUND pages verified.
- 243,200 raw DSP samples with all extra controls at maximum across notes 0..126 under UBSan.
- Initial VA zero-delta sample and exact stereo retrigger sample continuity, every VA factory preset.
- UI rendering/layout checks, including Init and both new pages.
- Existing creative UI confirmation/cancel/SAVE guard and internal/USB/TRS transport checks.
- TINES/VECTOR regression suite: 1,751,040 raw DSP samples, DSP UBSan, 48 CPU1 fixtures, 40 Morph cross-engine fixtures, 300 overlapping chords, USER64/native backup and step-grid tests.
- Firmware syntax for single/dual core.

The historical standalone `cr_va_test.c` runner has an unresolved `upx_blob_get` fixture dependency in this source tree; it was not counted as a passing test. The V54 full-firmware VA fixture above is used for the transition checks.

No PI32V2 compiler or FM1 hardware was available here. XIP, RAM, POOL, CPU deadlines and listening must be verified with the Mac target build and FM1. No target firmware is bundled. Web-installer version/hash metadata is not repinned automatically.

## Build on Mac
```bash
(
cd "$HOME/Downloads/Choralroot-remix-v54-musical-randomizer" &&
test -f README-V54.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v54-build.log 2>&1
  build_status=$?
  tail -n 45 build/host/v54-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
}
)
```
