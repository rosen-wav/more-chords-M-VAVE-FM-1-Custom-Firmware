# more chords! V55 — GRAIN Synth Source (development)

Questa versione parte dalla V54 allegata. È destinata prima alle prove nell'emulatore: **non è una release pronta per il flash FM1**. La toolchain PI32V2 non è disponibile nell'ambiente di sviluppo usato per questi test. Come richiesto, canvas, cache grafica, buffer granulari e gli altri engine non sono stati ridotti per rientrare nella memoria hardware.

## Modifiche

- **TINES e VECTOR rimossi dagli engine attivi e da Morph.** CZ-1 rimane già rimosso. Gli ID persistenti restano riservati; nessun riordino degli altri ID.
- **VA: 6 voci, 4 su CPU0 + 2 su CPU1**, con il basso su CPU1. Il rendering stereo, lo spread e il raccordo iniziale esistenti sono conservati. Il fallback senza CPU1 mantiene il suo budget limitato.
- **Basso: velocity aggiornata anche passando da una nota forte a una più debole in legato.** La velocity MIDI e quella già inoltrata dal motore accordi non vengono rimappate una seconda volta.
- **FM6: 64 factory dal file SYX allegato**, esaminando esclusivamente le posizioni 1–64. Non vengono usati suoni successivi per riempire la banca. Il payload contiene 64 record extended VCED decodificabili: non sono stati identificati blob VA. Quattro record hanno valori di inviluppo fuori dal range DX7, limitati al massimo supportato; dettaglio in `docs/FM1-FACTORY-IMPORT.json`. Effetti e dati extra FM1 non sono convertiti. Gli slot USER restano 64.
- **GRAIN dalla ChoralRoot 0.25**, distinto da CLOUD, con le otto famiglie originali, due sorgenti A/B, filtro, inviluppi, LFO e matrice.
- **SOURCE A / SOURCE B** nella sezione OSC: ENGINE = ORIGINAL / PROPHET / FM6, PATCH = RANDOM oppure numero, REGEN girando il terzo knob, VEL con il quarto. Il nome in alto identifica la patch risolta. Stato BUILD / READY / ERROR e percentuale durante la generazione.
- Salvataggio dei parametri granulari e dei riferimenti alle sorgenti nei normali USER, **senza PCM in flash**. Rigenerazione deterministica dopo caricamento.
- Init preset della V54 conservato e verificato nel menu di salvataggio di tutti gli engine attivi.

## Come provarlo su Mac

Dopo aver estratto lo ZIP in Downloads:

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v55-grain-synth-source" &&
source "$HOME/.venv/bin/activate" &&
sh tests/run_v55_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
)
```

Per l'emulatore web (serve Emscripten già installato):

```sh
(
cd "$HOME/Downloads/Choralroot-remix-v55-grain-synth-source" &&
source "$HOME/.venv/bin/activate" &&
source "$HOME/emsdk/emsdk_env.sh" &&
CR_VERSION=55-dev sh tools/emu/web/build_web.sh &&
python3 -m http.server 8000 --directory build/emu-web
)
```

Aprire `http://localhost:8000`. Non pubblicare questa versione al posto del firmware stabile del web installer.

## Limiti espliciti

- **Memoria FM1 ancora da sistemare.** La somma delle allocazioni statiche POOL nella compilazione host supera il budget FM1; non abbiamo cambiato il linker né rimosso altri engine per mascherarlo. XIP/RAM/POOL reali e costo CPU sul dispositivo richiedono la build PI32V2 e la successiva ottimizzazione.
- GRAIN usa una sola coppia globale A/B, come il motore originale. La prima parte GRAIN ne è proprietaria; un'altra parte GRAIN condivide quel materiale. **Non è aggiunto al Morph globale**, per evitare due istanze con sorgenti che si sovrascrivono. Gli altri engine di Morph sono preservati e verificati.
- Le sorgenti SYNTH sono **factory Prophet/FM6**, non patch USER mutabili. Un hash della patch verifica il riferimento; se differisce la sorgente va in ERROR invece di cambiare timbro silenziosamente. Non è promessa identità sonora fra firmware con DSP diverso.
- Cattura mono di una voce nativa C4, MIDI 60 / pitch16 960, senza FX globali e senza impilare ulteriori voci unison. Note-off a circa 557 ms, fine buffer a circa 743 ms. Queste costanti fanno parte del formato di generazione V3.
- A/B si generano in sequenza. La sorgente da aggiornare sfuma a zero prima della scrittura e torna udibile soltanto a buffer completo; può esserci un calo di livello durante REGEN. Nessuna lettura del buffer parzialmente riscritto.
- Le pagine SOURCE e le pagine standard sono presenti; il grafico waveform della UI 0.25 non è stato importato nel vecchio view-model V54.
- I test usano il vero firmware nell'emulatore headless e un worker pthread. Non dimostrano assenza di underrun sull'hardware. Non è stato prodotto un nuovo `.fwsc` né un WASM precompilato.

Risultati e architettura: `docs/V55-TECHNICAL.md`. Log dei test: `docs/V55-TEST-RESULTS.txt`.
