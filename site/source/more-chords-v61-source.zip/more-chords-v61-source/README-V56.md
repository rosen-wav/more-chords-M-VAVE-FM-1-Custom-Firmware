# V56 — Retire DRIFT / TERRAIN and make Init preset visible

Changes relative to the attached V55:
- DRIFT and WAVE TERRAIN DSP and terrain tables removed from the build.
- Both removed from engine selection and Morph. Persistent engine IDs remain reserved; old records cannot become another engine.
- SAVE PRESET contains Overwrite, Save as new, Init preset. SELECT chooses, OCT+ applies; K4 still selects Init.
- Opening SAVE dismisses the toast that could cover Init preset.
- Init changes the working patch; it does not overwrite a stored USER slot automatically.

This package preserves V55 GRAIN behavior. The previously requested larger GRAIN UI redesign and expansion beyond Prophet/FM6 sources are NOT included in this focused revision.

Build on Mac:
```sh
cd "$HOME/Downloads/Choralroot-remix-v56-grain-ui" &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/v56-build.log 2>&1
```

Run `sh tests/run_v55_tests.sh` for host regression checks. Target PI32V2 build, linker budgets and hardware audio remain unverified. No firmware binary is supplied; the existing V55 memory overrun is not resolved by this change.
