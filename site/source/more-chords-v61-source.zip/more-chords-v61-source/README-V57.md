# V57 — POOL optimization and GRAIN UI

Based on the V56 source downloaded from rosen-wav/more-chords-M-VAVE-FM-1-Custom-Firmware. This is a source release, not a validated FM1 firmware binary.

## What changed

- Keeps 64 USER presets, 30 loop slots, all remaining musical engines and six-note chord policies. DRIFT/TERRAIN and the previously retired engines remain retired. SAVE / Init preset remains present.
- Graphics canvas: 240x124 to two 240x8 buffers. One is the rendering canvas, one is DMA staging. DMA completion is awaited before staging is reused, with audio interrupts enabled. One-shot boot/crash/update text is tiled too.
- Glyphs retain their full pixel capacity and 4-bit coverage, packed two pixels per byte. Scaling weights are processed in 16-column chunks. Huffman decoding uses one cache; immutable ring lookup data moves to flash.
- Pixel comparison against V56, including delayed-DMA and partial updates, checks that existing screenshots do not change.
- GRAIN shows actual PCM min/max envelopes for A and B, source engine/preset names, a Position cursor, blend bar and source Ready/Generating/Error state. The envelope is updated while PCM is written, not scanned every frame.
- GRAIN OSC has GRAINS (Position, Size in milliseconds, Density, A/B blend) and TEXTURE (Spread, Random pitch, Pitch, Scan). ORIGINAL A/B detail pages appear only for Original sources.
- GRAIN FILTER is replaced by SOURCE A / SOURCE B: Engine, Preset (0 selects Random), New take, Velocity. Original sources show Family and Tone instead of Preset and Velocity. Turn New take to regenerate. This does not overwrite a USER preset.
- The GRAIN filter DSP is removed. Existing serialized filter fields remain readable but no longer affect audio; old filtered GRAIN presets will sound different. Removed filter destinations are hidden from the modulation picker while stored destination IDs remain stable.
- GRAIN can capture factory presets from Prophet, FM6, SWARM, CLUSTER, CLOUD, VA, FM TONE, PHASE and BASS, plus its eight Original source families. These are dry mono C4 captures, not live engine layering. USER-preset source capture is not added. GRAIN and MORPH cannot be recursive sources.
- Capture uses a separate engine context. VA/FM TONE each have one private offline voice in ordinary RAM rather than another full polyphonic POOL array. Musical voices are unchanged.
- Existing signed-shift undefined behavior in FM TONE and PHASE was replaced with equivalent multiplication, discovered during all-factory source UBSan tests.

## Memory and verification limits

See docs/V57-POOL.json for host-side static allocation measurements. These are GCC sizes for the hardware translation unit, not PI32V2 linker totals. Pointer size, padding and the final linker layout may differ. XIP, final RAM/POOL and hardware audio timing must be measured by the Mac build. Linker limits and stacks have not been increased or reduced. No flashable binary or new web installer is shipped.

The smaller graphics buffers can change drawing throughput. Hardware testing should include rapid parameter changes while playing chords + Bass, USB MIDI/audio and source regeneration.

## Mac build

Extract this folder into Downloads, then run:

```bash
(
cd "$HOME/Downloads/Choralroot-remix-v57-pool-grain-ui" &&
test -f README-V57.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v57-build.log 2>&1
  build_status=$?
  tail -n 60 build/host/v57-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
  exit "$build_status"
}
)
```

## Host tests and emulator

`sh tests/run_v57_tests.sh` runs the existing regressions, current GRAIN UI, native source fixtures, UBSan, drawing/DMA tests and hardware/web syntax checks. It does not invoke PI32V2 or emcc.

On a Mac with SDL2: `sh tools/emu/build.sh && build/host/emu --no-midi`.

All existing copyright and license notices remain in the source.
