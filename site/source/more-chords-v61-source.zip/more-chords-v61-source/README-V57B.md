# V57B — Keep the required POOL headroom

V57 now links physically on PI32V2, but its build guard correctly rejects only 3584 bytes of POOL headroom (minimum 8192).

This revision changes only two production declarations relative to V57:
- `upx_aux[32][144]`: 4608 bytes, moved from `.pool` to ordinary `.bss` RAM.
- `cr_cw[16]`: 576 bytes, moved from `.pool` to ordinary `.bss` RAM.

These are main-loop preset and graphics caches, not DMA transfer buffers. Both RAM regions are zero initialized by the existing startup/linker layout. Their contents, sizes, precision, persistence format and access paths are unchanged. The total RAM usage is redistributed, not compressed. No linker bounds, stack reservations or headroom guards are changed.

The V57 PI32V2 log measured 88704 bytes of RAM and 340480 bytes of POOL. Expected after relocation, subject to the next real build:

| Region | V57 measured | V57B expected | Capacity | Expected free |
|---|---:|---:|---:|---:|
| RAM | 88704 | 93888 | 98304 | 4416 |
| POOL including CPU1 stacks | 340480 | 335296 | 344064 | 8768 |

No extra initialized data or tables are added, so no additional XIP data is expected. The target linker and emitted code must confirm final values. Hardware timing is not validated here.

GRAIN UI, nine factory source engines, all 64 USER slots and 30 loops remain as in V57. See README-V57.md for the feature changes.

Validation: host GCC hardware-unit assembly confirms exactly 5184 bytes leave POOL and the two complete objects appear in BSS. Existing core/USER save-boot-load tests under UBSan pass; all 140 baseline pixel hashes and GRAIN partial/DMA checks pass. No PI32V2 toolchain is present in this environment. No firmware binary is supplied.

## Build on Mac

```bash
(
cd "$HOME/Downloads/Choralroot-remix-v57b-pool-margin" &&
test -f README-V57B.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v57b-build.log 2>&1
  build_status=$?
  tail -n 60 build/host/v57b-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
  exit "$build_status"
}
)
```
