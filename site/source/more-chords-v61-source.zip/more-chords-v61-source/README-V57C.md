# V57C — GRAIN browser order and source preset stepping

Two changes relative to the hardware-tested V57B:
- GRAIN appears immediately after Prophet in the engine browser. Persistent engine IDs and all saved records remain unchanged.
- GRAIN SOURCE A / SOURCE B preset selection moves one entry per encoder detent without FINE, with FINE and with SHIFT. Random remains entry 0. Original-family selection follows the same one-entry rule; other controls keep their usual stepping.

All V57B RAM/POOL placement fixes are retained. There are no new audio buffers, voices or caches. The existing host UI checks pass; PI32V2 code size/linker and the hardware control feel must be checked with the next build.

Build on Mac:
```bash
(
cd "$HOME/Downloads/Choralroot-remix-v57c-grain-order" &&
test -f README-V57C.md &&
source "$HOME/.venv/bin/activate" &&
mkdir -p build/host &&
{
  CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
  PYTHON="$HOME/.venv/bin/python3" sh build.sh \
  > build/host/v57c-build.log 2>&1
  build_status=$?
  tail -n 60 build/host/v57c-build.log
  printf '\nBuild exit code: %s\n' "$build_status"
  exit "$build_status"
}
)
```
