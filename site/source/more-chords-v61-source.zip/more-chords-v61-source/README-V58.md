# V58 — GRAIN chords-only e Init preset

GRAIN resta disponibile come engine per gli accordi e nei Favourites, ma non nei bassi né in Morph. I controlli impediscono l'aggiunta alla collezione Bass, il salvataggio diretto Bass, i caricamenti factory/USER e i riferimenti alle impostazioni precedenti. Un vecchio riferimento nella lista Bass viene spento e resta rimovibile. Morph già escludeva GRAIN: tale esclusione è preservata, senza cambiare gli ID.

SAVE mostra ora un picker a tre azioni: Overwrite, Save as new, Init preset. SELECT o knob 1 scelgono, OCT+ conferma; knob 4 seleziona direttamente Init. Init ripristina il suono di lavoro e non cancella il preset USER salvato. Tenendo HOME, il menu offre FAVOURITES, BASS e Init preset: SELECT sceglie e OCT+ conferma.

Test host: tests/cr_save_init_test.c verifica schermata, selezione e applicazione su tutti gli engine visibili, entrambi i menu e conservazione del record USER. tests/cr_grain_bass_block_test.c verifica factory/USER, riferimenti precedenti, salvataggio diretto, Favourites ed esclusione Morph.

La build PI32V2 e le misure finali XIP/RAM/POOL vanno eseguite sul Mac. Qui non è incluso un firmware compilato. Nessun limite di memoria o controllo pacchetto è stato modificato.

Per firmware + web installer + emulatore: `sh web/build_v58_site.sh` dopo avere attivato la venv. Emscripten richiesto. Output build/site, changelog aggiornato alla V58. Caricare il contenuto nella root GitHub Pages. I salvataggi browser mantengono la stessa chiave IndexedDB.

## GRAIN +3 dB
Output trim 181/128 (+3.009 dB) after the voice envelope, before the common mixer. No floating-point helper, new buffer or preset format change.
