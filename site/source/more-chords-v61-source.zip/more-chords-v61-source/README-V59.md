# V59 — GRAIN +2 dB

GRAIN output trim is now 29135/16384 (+5.00 dB total vs original V58; another +2 dB vs V58 +3 dB). Integer gain after the voice envelope, before the common mixer. No new buffer or preset format change. GRAIN Bass/Morph restrictions and Init preset UI retained.

Build firmware/site/emulator with `sh web/build_v59_site.sh` after activating the venv. Actual PI32V2 build and hardware listening remain to be verified on Mac.
