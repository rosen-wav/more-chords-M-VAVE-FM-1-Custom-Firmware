# V60 — GRAIN Gain / Spray

GRAIN base output +2 dB vs V59 (+7 dB total vs initial V58), integer trim 9170/4096.
TEXTURE: SPREAD varies grain launch timing, GAIN replaces RAND and scales amplitude 0..127 with 64=unity and a block ramp, SPRAY replaces PITCH and varies reading position over the source buffer, SCAN remains unchanged. Grain pitch follows played notes, without the former RAND detuning/reverse or PITCH offset. Modulation destinations are renamed GAIN and SPRAY.

Patch blob version 4, same byte count and engine ID. Older blobs load at unity gain, old RAND amount becomes positional Spray; old RAND/PITCH matrix routes are disabled to avoid accidentally changing gain. Old pitch offsets are intentionally removed. Factory gains are unity. Old saved sounds can therefore sound different. New blobs require V60 or later. Bass/Morph exclusions and Init preset retained.

Build: activate venv then sh web/build_v60_site.sh. Outputs firmware plus build/site with installer, emulator and changelog. PI32V2 build and hardware audio remain to be verified on Mac.

Host tests passed: cr_v55_test (six-note playback, source regeneration, USER storage roundtrip and CPU1 isolation) and cr_v60_grain_controls_test (defaults, old/new blobs, packed USER migration, Spray position/pitch). Run tests/run_v60_tests.sh after build headers are generated.
