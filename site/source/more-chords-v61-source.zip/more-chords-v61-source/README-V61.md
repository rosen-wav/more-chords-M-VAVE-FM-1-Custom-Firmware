# V61 — 64 generic original FM6 presets

The 64 FM6 factory slots now contain original generated parameter recipes, 8 sounds in each family: EP, Bell, Bass, Brass, Pad, Mallet, Organ, Pluck. Three two-operator stacks, velocity-sensitive envelopes, moderate feedback, neutral pitch envelope and no automatic pitch LFO. No external bank/SYX samples or preset data used. Names, native packed voices and menu entries are generated together. GPL-3.0-only, upstream code credits retained.

The previously supplied assets/factory/fm1-user-bank.syx and docs/FM1-FACTORY-IMPORT.json are removed. tools/import_fm1_factory.py is now a compatibility notice only; no bank is imported. Firmware, web emulator and downloadable source use the same original bank. Previous published releases/Git history are not removed by this source archive; replace or remove their downloads separately if desired.

Factory slots/IDs and the 64 USER records retain their layout. Existing USER patches are not rewritten; USER sounds already copied from the old bank remain personal saved data. Favourite/sequence/Morph references to factory slots now select the new sounds at those positions. Old GRAIN FM6 source hashes can become invalid and need source reselection. These new timbres are not reproductions of the old factory sounds. GRAIN Gain/Spray/+7 dB and Bass/Morph guards from V60 retained.

Build firmware, installer, emulator and changelog: activate venv then sh web/build_v61_site.sh. Actual PI32V2 build/memory and hardware audio are not yet verified. Source-level generation and host DSP tests are provided.
