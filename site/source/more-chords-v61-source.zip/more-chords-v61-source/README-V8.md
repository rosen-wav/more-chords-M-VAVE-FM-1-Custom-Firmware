# Choralroot Remix V8 — velocity / dual Morph review, Chord Ideas, 30 loops

Complete source archive, based on `Choralroot-v7-morph-ui-velocity-monk-EMU(1).zip`.
The second attached V2 archive was compared as the older reference. The Monk sensor reference is included under `integration/monk_reference/` (the sensing algorithm matches it apart from the local math include).

## Changes

- **FIX — Morph CPU1:** patch B now uses CPU1's FM6 scratch instead of racing patch A on CPU0. Voice budgets place B alongside Bass on CPU1; A keeps CPU0's budget. Six held notes on each branch are tested with each of FM6, QUAD, VA and PHASE and all eight supported Bass engines.
- **FIX — Morph lifetime/performance:** B follows chord-channel pitch bend, wheel, pressure and expression; B fades out with A on engine changes, and its private voices/queued notes are then freed. Its sample-and-hold LFO has a private RNG. Two native patches continue rendering through the existing equal-power crossfade before FX; moving Position does not reload either patch.
- **FIX — Velocity:** Dynamic Velocity controls the physical FM1 keyboard only. MIDI and recorded notes keep their velocities when that option is off. Fixed FM1 velocity uses the existing Velocity setting. Very short physical taps are no longer discarded while waiting for a sensor reading.
- **REMOVE — VOICE and LOFI:** absent from engine browsing, Morph, and factory import choices; their DSP is not compiled. Stable IDs 3 and 5 remain reserved so other engines and stored formats are not renumbered. Old sounds referring to retired engines use the existing FM6 fallback; their stored bytes are not rewritten automatically. Older Morph source indices referring to removed engines also fall back to FM6.
- **NEW — Chord Ideas / Chromatic:** alongside Major and Minor. Chromatic roots may leave the diatonic scale; Surprise can select every pitch class. Major/minor/sus/diminished and mutually exclusive seventh colors remain supported.
- **NEW — Progressions:** Andalusian, Turnaround, Steps, Tritone, in addition to the seven existing patterns. Tritone includes a bII7/9 substitute for V7.
- **IMPROVED — Live generation:** turning the idea knobs while auditioning preserves transport origin and the currently sounding chord. The next scheduled chord uses the updated candidate. There is no Stop or restart on regeneration. PLAY still explicitly starts/stops audition; OCT+ transfers the candidate to the editor without saving it to flash.
- **NEW — 30 loop/sequence slots:** the last keyboard key in loop/save slot selection cycles banks 1–10 (LED off), 11–20 (blinking), 21–30 (steady). The global LEDs-off preference still takes priority. Python/web backup now expose all 30 loop objects.
- **FIX — Defined arithmetic:** equivalent multiplies replace signed negative left shifts in the FM6 velocity level, DC blocker and chorus interpolation. No sound redesign.

## Flash layout and compatibility

Each loop retains two 4 KiB commit sectors and the same 3792-byte maximum record, with CRC and previous-copy recovery.

| Slots | Sector range | Status |
|---|---|---|
| 1–10 | `0xC8000..0xDBFFF` | unchanged |
| 11–20 | `0xB4000..0xC7FFF` | unchanged |
| 21–30 | `0xE5000..0xF8FFF` | newly assigned, 20 sectors |

The new region begins after updater staging (`0xE0000..0xE4FFF`) and ends before globals/settings (`0xFC000..0xFEFFF`). `0xF9000..0xFBFFF` and key/MAC sector `0xFF000` remain excluded. The application's store allowlist was extended only by this new bounded region; no loader/stub source or bootloader sector was changed. Flash Data erase now also covers the new loop bank. The updater still writes only the existing app slot. New bank availability is established from the supplied firmware/package map, not from a dump of the user's physical flash.

No ten extra loop RAM buffers: the existing buffer and 32-bit occupancy map are reused. Backup object IDs are 40–69; the full backup has 48 objects. Previous 20-slot backups remain usable; old firmware does not expose the ten new slots. Settings record size/CRC version and old sector addresses are preserved.

`firmware/src/eng_quad.c` is byte-identical to the supplied V7 (SHA-256 `0df24850aa4a0c1fb4fe6cf9967347dcc83f613bce1827d4c5caba76b70ec36a`). Boot/stub/loader and legacy audio golden files are unchanged. Legacy golden audio was neither regenerated nor claimed as validated.

## Test first on Mac

After extracting this complete folder under Downloads:

```sh
cd "$HOME/Downloads/Choralroot-remix-v8"
source "$HOME/.venv/bin/activate"
sh tests/run_v8_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Quick checks: Morph held chord A→B→A with Bass and MIDI controllers; generate another Chord Idea during PLAY; save/load/delete slot 30; verify the three bank LED states. The desktop keyboard uses fixed fallback velocity because it has no physical ADC sensor.

The old parameter-morph and PCM-history tests remain historical source references; `run_morph_tests.sh` now runs tests for the actual dual-patch crossfade. Its UBSan run excludes `shift-base`: legacy signed left shifts remain in the protected QUAD source. This is not an unrestricted UBSan claim.

## Still requires target/hardware validation

Host tests cannot certify physical velocity calibration, ADC/LED/battery/master interactions, CPU1 deadlines, or final target XIP/RAM/POOL/stack margins. No executable FM1 firmware or flash action is delivered by this archive. Perform the target build and review its memory/guard results before considering installation. A passing host recovery model is not proof that every interrupted physical installation will recover.
