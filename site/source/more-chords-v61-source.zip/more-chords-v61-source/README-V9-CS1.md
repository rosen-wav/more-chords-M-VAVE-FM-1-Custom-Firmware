# Choralroot Remix V9 — CS-1

Complete standalone source folder, including all V8 changes (Monk physical velocity, dual-patch Morph, retired VOICE/LOFI, live Chord Ideas and 30 loop slots). Extract this folder; do not overlay it onto an older project.

- **NEW: CS-1**, adapted from the supplied CS-1-main CS-80-style FM1 synthesizer by twochannels. It appears after KR106, with 52 factory sounds.
- Two native channels per voice: saw/pulse/PWM/noise, post-filter sine, resonant high-pass and low-pass filters, native filter/VCA envelopes, velocity/pressure, ring modulation, chorus/tremolo, portamento and drift.
- Six chord voices with CPU1 online: four kernels on CPU0, two on CPU1; the Bass part remains on CPU1. Offline fallback is up to five chord voices within the shared serial budget. These are allocation policies, not measured CPU headroom guarantees.
- Native editor pages for both channels; full native patch saves in USER, favourites and bound factory overrides. Delay/reverb use the existing Remix buses, with sends adapted from the factory recipes.
- CS-1 is excluded from Morph. Existing engine IDs, flash sectors, USER slot count and record size remain unchanged.

## Try the emulator first

```sh
cd "$HOME/Downloads/Choralroot-remix-v9-buildfix"
source "$HOME/.venv/bin/activate"
sh tests/run_cs1_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Select **CS-1** in the engine picker. Test held and fast-changing chords, Bass, velocity, the I/II mixer, both filters and USER overwrite/reload. The physical FM1 velocity sensor cannot be calibrated in the desktop emulator.

To rerun all inherited checks as well: `sh tests/run_v8_tests.sh`.

## Validation and remaining work

Host tests cover 576 CS-1 factory/worker/USER fixtures, including exact serial versus concurrent-worker PCM/state, eight Bass engines, CS-1-only audibility, complete overwrite/reload, all 22 native editor screens and offline caps. Native arithmetic stress runs 1,277,952 samples under UBSan, including extreme/random controls. Librarian export/import preserves the native record. Existing V8 regression and recovery models pass; see `docs/validation-v9/`.

The CS-1 runtime fits the existing FM6 state union, so it does not enlarge that union. Native patches add 408 bytes in POOL and eight flag bytes; code, recipes and lookup tables add flash usage. Host structure sizes are not a target linker memory report.

**No target FM1 build or device flash was performed here.** XIP/RAM/POOL limits, CPU0/CPU1 worst-case deadlines, stack usage and sustained hardware audio still require the Mac target build and FM1 measurement. No claim of brick immunity or hardware performance follows from these host tests. The archive deliberately contains no executable firmware package.

QUAD source, boot/stub/loader and legacy golden inputs are byte-identical to V8. Legacy audio goldens were neither regenerated nor validated.

See [the integration notes](docs/CS1-INTEGRATION.md) for provenance, patch compatibility and deliberate differences from standalone CS-1.
