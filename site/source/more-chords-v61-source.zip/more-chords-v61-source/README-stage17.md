# Fase 17 — FM TONE ufficiale + Prophet + Chord-Aware

**Pacchetto di sviluppo, NON firmware installabile.**

Base: ChoralRootFM1prophet.zip. Include l’overlay cumulativo fase 16 (Prophet + Chord-Aware), la versione ufficiale aggiornata di eng_quad.c e quad_tables.h, le modifiche ufficiali a cr_edit.c e params.c sotto forma di patch, e il fix ufficiale per le voci con release infinita integrato nel voice.c Chord-Aware.

I file cr_edit.c e params.c NON sono sovrascritti dall’overlay: applicare le patch alla base originale, usando `patch -p1` dalla radice del progetto. Il file voice.c conserva l’allocatore Chord-Aware della fase 16. Il DSP CZ-1 non viene modificato.

I file originali core.h, engines.c, choralroot.c, cr_settings.c, ui.c vengono dalla fase 16.

**Attenzione**: il firmware ufficiale potrebbe contenere altre modifiche in componenti dell'interfaccia e dei preset; questa integrazione include soltanto il sottosistema FM TONE e la correzione release. Non è stato verificato che l'intera interfaccia ufficiale sia compatibile.

**Procedura**: estrarre questo ZIP nella radice di una COPIA di ChoralRootFM1prophet; poi `patch -p1 < patches/cr_edit.c.patch` e `patch -p1 < patches/params.c.patch`. Verificare GCC host, build JieLi e test emulatore prima del flash.

**Limiti preesistenti**: Prophet non validato in build JieLi; Chord-Aware non conserva ancora tutte le note MIDI silenziate; import UI SysEx non completo.
