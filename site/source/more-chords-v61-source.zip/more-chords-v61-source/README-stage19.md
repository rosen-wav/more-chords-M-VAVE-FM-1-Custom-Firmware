# Stage 19 – Retire NOISE engine and factory presets

This is a **cumulative overlay of stage 17**. It preserves the Prophet and Chord-Aware source changes and FM TONE source/patch files already present in stage 17. It does NOT include the unmerged ANALOG→VA changes from stage 18.

Changes:
- Remove `eng_noise.c` from compilation.
- Keep engine ID 11 reserved as `ENG_GONE`, so no other engine IDs shift.
- Remove NOISE from engine browsing and its factory preset pool.
- Mark ID 11 retired in `eng_ok`, so stale user presets cannot select a non-existent engine. Existing user preset records are **not erased**.
- Decrement the visible engine count.

The original NOISE factory preset data were defined inside `eng_noise.c` and are no longer linked by this source. Any noise generators shared with other engines are unaffected.

**Not done:** creation of extra persistent USER slots; this needs a separate storage layout/capacity audit. No JieLi build, emulator test or hardware validation was run. Do not flash this archive.

To use: apply this source overlay to a copy of the original project, then apply the included `patches/` as documented in stage 17; build/test separately.
