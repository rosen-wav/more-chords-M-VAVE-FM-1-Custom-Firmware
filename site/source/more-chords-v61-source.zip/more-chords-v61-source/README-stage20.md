# ChoralRoot stage 20 — consolidated development overlay

This cumulative overlay builds on stage 19 (itself based on stage 17). It includes Prophet Melodee sources, first-pass Chord-Aware, FM TONE updated sources, NOISE retirement and the ANALOG retirement/USER-preset VA migration extracted from the official updated firmware.

Changes added here:
- FELUCCA_ANALOG=0 in choralroot.c; eng_analog.c no longer included.
- Engine ID 0 remains reserved and hidden; IDs for CZ, FM TONE, Prophet, and other engines remain unchanged.
- Legacy ANALOG USER preset records are mapped to VA with macro conversion in cr_ui.c and upreset.c.
- NOISE engine ID 11 remains reserved, factory presets removed (from stage 19).
- The existing stage 17 FM TONE editor patches remain in patches/ and must be applied separately.

LIMITATIONS / NOT YET DONE:
- Official cr_settings.c version-7 pool migration has NOT been merged; saved engine selection/pool positions need careful versioned migration before release. Do not claim fully compatible settings migration.
- NOISE factory preset positions are NOT extra persistent USER slots. No storage-layout migration is implemented.
- Prophet remains a development integration, not a validated audio engine; complete held-note Chord-Aware logic is pending.
- No JieLi firmware build, emulator test, or hardware test has passed for this combined overlay.
- This is a source overlay, NOT a flashable firmware. Do not install on FM1.

Apply to a COPY of the original ChoralRootFM1prophet project. Files in firmware/src/ replace matching files; patches/ follow README-stage17.md. The original working project must be preserved.
