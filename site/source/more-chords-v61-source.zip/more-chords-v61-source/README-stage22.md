# ChoralRoot stage 22 — retired PHYS, WHEEL, TRIO

Based on stage 21. DSP of PHYS, WHEEL and TRIO is no longer included by engines.c; engine IDs 6, 7 and 9 resolve to the silent retired engine and are absent from ENGINE_ORDER. NOISE and ANALOG remain retired; Prophet, Chord-Aware, FM TONE and CZ-1 remain as in stage 21.

IMPORTANT: Historical engine slots are retained. Old projects/presets referring to the retired engines cannot reproduce their old sound. Persistent pool indices for the surviving FM6/VA/PHASE/CZ/LOFI/VOICE are mapped to legacy positions; settings migration still requires emulator testing.

Run on macOS: `sh stage21/test_mac.sh`, then `./build/host/emu --no-flash`. This package is NOT a validated FM1 firmware. Build and audio tests still required.
