# Stage 23 – Prophet EDIT (experimental)

Adds nine native Prophet deep-edit pages (OSC A, OSC B, OSC B+, MIXER, FILTER, FLT ENV, AMP ENV, LFO, POLYMOD). Values edit Prophet's native patch bytes, not the generic P_E macros. Adds patch blob hooks for USER storage, and retains factory preset loading through p5_preset_loaded.

Includes the three Mac-reported stage22 build fixes: retired preset fallback ENGI_VA, settings count assertion, removal of unresolved p5_update_bend call. **Pitch bend remains unverified.**

Validation: generated headers and hostsim C syntax check passed on Linux. macOS SDL emulator, audio preset differentiation, USER save/load, and JieLi firmware build **not tested**. Check these on Mac before using hardware.

Run `sh stage21/test_mac.sh` then `./build/host/emu --no-flash`.
