# Stage26 — Wah, USB recording fixes and update rescue

Full source project based on the supplied Stage25 Church/Gate archive. No patch application is required. All existing musical features remain included. Engine sources (including QUAD) and legacy golden audio are unchanged.

## Performance menu

SELECT outside the engine editor opens the performance menu:

| Knob | Control |
|---|---|
| 1 | swag: Off / Ping Pong / Random / Tennis |
| 2 | rosen: Off / Next / Random / Ping Pong |
| 3 | Off / Gate / Wah |
| 4 | Gate/Wah cycle rate: 1/8 / 1/16 / 1/32 |

Wah is a stereo resonant filter on the master, with cutoff sweeping up and down. It follows the same internal/external clock phase as Gate, crossfades between modes, and bypasses when MIDI clock disappears. It does not overwrite engine/preset filter parameters. It is after the reverb/sidechain and before USB master capture; individual CHORD/BASS USB stems stay separate. Stutter remains removed.

CPU1 is compiled on by default, both for target and emulator. The existing split of up to two CZ/Prophet chord kernels plus BASS is retained, with six chord voices when CPU1 is online. Explicit CHORALROOT_DUAL_CORE=0 remains available for diagnosis. Host musical regression tests deliberately exercise the serial fallback; the separate dual-core suite tests concurrent six-voice rendering.

## Official 0.16 integrations

- Fixed boot stub (unchanged official v3 source and lock), body at XIP 0x02001000, commit-marker sector 0x91000, first 32 NOINIT bytes reserved for its mailbox.
- Matching loader/packer: erase marker before body updates, keep an unchanged stub sector, commit marker last; keep a whole staged loader after reboot for recovery.
- Software stub test/rescue request supported by installer `--stub`; OCT- at power-on selects rescue. Read docs/BOOT-SAFETY.md, especially “As built”.
- Official USB bandwidth reservation (640 bytes), stream-start hold, rare frame drift corrections, endpoint service between rendering blocks, serialized USB-register access.
- Bounded official CPU1 supply ramp; checkword and stable job snapshot before indirect calls. Bad mailbox or timed-out partial work causes controlled reset, never unsafe replay of an advanced voice state.
- Console `cpu` includes mailbox/rail information, `status` includes USB service and UART counters, `boot` includes stub information.

The custom build already draws continuously and has no idle panel-power shutdown, so the official backlight/input inactivity bug does not apply here. The official default of CPU1 Off was deliberately not imported. Its bass-only fault replay was also not imported: our shared chord jobs must never be rendered a second time after partial execution. The official DEBUG telemetry protocol was ported for installer `--debug` and `--stub test`, with our CPU1 counters. Unrelated device-manager UI features were not ported.

## Try the emulator on Mac first

```sh
cd "$HOME/Downloads/ChoralRoot-stage26-wah-rescue"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tests/run_dualcore_tests.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

The emulator GUI needs the existing Mac SDL2/CoreMIDI setup. The audio/interaction host tests run the emulator firmware directly, without a GUI.

## Target build, after emulator validation

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
PYTHON="$HOME/.venv/bin/python3" sh build.sh \
> build/host/stage26-build.log 2>&1
build_status=$?
tail -n 45 build/host/stage26-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Do not install if the build fails. There is no prebuilt firmware in this source ZIP. Target flash/RAM/POOL sizes and the stub hash must be checked from this new build, not reused from Stage25.

## Verification limits and recovery risk

Host checks are not a guarantee of hardware timing, uninterrupted USB recording or recovery on a physical unit. The portable loader model uses synthetic stub/loader bytes; it exercises decisions, ordering and interruption handling, not execution of target assembly. Its packages in build/host/rescue-fixtures are HOST ONLY and must never be installed.

The first install introducing the stub, and any later install changing its bytes, still have an unprotected window while the stub sector is being rewritten. Updates with the same intact stub recover in the tested interruption model. Bootloader flash below 0x4000 is untouched by the loader model. A real target build and device recovery test remain outstanding.

TRS MIDI IN code is enabled: UART1/PH8 at 31250 baud -> parser -> shared MIDI queue -> clock follower. Parser/routing tests pass. Actual TRS reception on this unit remains unknown; compare `uart_rx_bytes` and `uart_rx_msgs` in `status` before/after sending clock. No hardware cause is assumed.

USB fixes retain the 512-frame recording ring (256-frame prime, approximately 5.8 ms), avoiding an unmeasured RAM increase. Additional latency was authorized, but extra buffering has not been justified by a device test yet.
