> Current routing/diagnostics: see README-stage29.md.

> See README-stage28.md for the current menu locations, Wah and FX selection.

# Stage27 — crystal castles bass mode

Includes all Stage26 features and boot/USB protections.

- SELECT performance effects: Gate/Wah rates now ordered 1/4, 1/8, 1/16, 1/32. Default remains 1/16.
- Open the arpeggiator/performance menu and select `crystal castles bass mode`.
  KNOB 1 selects Off/On; rate is fixed at 1/8. Other chord arpeggiator settings remain unchanged.
- Requires BASS enabled and a bass-producing gesture under the selected Bass Behaviour.
  Alternates the current bass root/register note and its octave on the master eighth-note grid.
  Internal clock runs outside loops too; MIDI Clock In uses accepted USB or TRS MIDI clock pulses.
  On external clock loss, bass holds its last note until release or the next clock pulse.
- Session-only, starts Off after reboot. Off restores the normal bass note immediately.
- CPU1 remains enabled by default. No engine DSP files changed, no legacy golden regeneration.

## Mac emulator

```sh
cd "$HOME/Downloads/ChoralRoot-stage27-crystal-bass"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

## Device build, after emulator validation

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage27-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage27-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Source package only; host tests do not establish target RAM/flash margins or
physical audio quality. Device linking/memory checks and firmware package checks
are required before installation. See Stage26 boot-stub limits and validation.
