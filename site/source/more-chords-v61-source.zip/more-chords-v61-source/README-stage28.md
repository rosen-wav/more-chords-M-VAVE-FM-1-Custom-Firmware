> Current routing/diagnostics: see README-stage29.md.

# Stage28 — deliberate FX selection and deeper Wah

Complete source project based on the tested Stage27 archive. Includes all
previous CPU1, USB audio, recovery stub, reverb, looper, keyboard, rosen and
chord voicing changes.

## Changes

- SELECT menu KNOB 3: three encoder detents per mode change, Off -> Gate -> Wah.
  No SHIFT/GLOBAL modifier. Partial motion resets after an 800 ms pause,
  direction reversal, another knob, or closing/reopening the menu.
- Wah has its own resonant filter peak / sweep arrow icon.
- Wah sweeps approximately 85..1700 Hz with a curved sweep, lower damping and
  stronger resonant band. Sign-symmetric rounding prevents low-cutoff DC bias.
  On/off fades, stereo states, external-clock loss bypass and four rates remain.
- `crystal castles bass mode` is the first Options entry (GLOBAL tap). KNOB 1
  sets Off/On. Removed completely from the performance/arpeggiator menu.
  It remains independent of chord Arp, fixed at 1/8 on the master clock;
  BASS must be enabled. Session-only; Off at reboot, as previously agreed.
- Picker strings extended to show the full option name without truncation.
  No settings serialization/version change and no additional delay buffers.

## Mac emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage28-wah-ui"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

Host verification covers selection thresholds, timeout/reversal/page behavior,
new icon binding and renderer, Crystal first option without changing chord Arp,
internal/TRS MIDI bass grid, Wah response and stress, previous feature suite,
dual-core routing, and target C syntax for both CPU1 configurations.
Captured UI previews and host logs are in docs/validation.

This is a source ZIP, not a device firmware binary. Actual target linking,
flash/RAM margins and physical audio listening remain to be checked on the Mac.
Boot recovery code is unchanged from Stage27. First introduction or replacement
of the rescue stub still has the previously documented interruption window.
No device flash and no legacy golden regeneration were performed.
