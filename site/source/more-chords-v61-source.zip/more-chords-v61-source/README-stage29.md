# Stage29 — Wah on CPU1 and TRS diagnostics

Complete source project with all Stage28 changes and the corrected build-stub
entry check. CPU1 remains enabled by default.

## Wah routing

- The original post-reverb/post-sidechain Wah kernel runs as a second CPU1 job,
  after the bass/chord voice job has joined. Gate and Off stay on CPU0.
- CPU0 prepares the metronome in its own 256-byte buffer while CPU1 runs Wah.
  Join precedes the USB master capture; click is added afterward, as before.
- No extra block of audio latency. No reordering of reverb, sidechain, Wah or
  USB stems. CPU1-offline/refused-before-start paths render once on CPU0.
- An accepted job must finish through the existing join/guard/deadline path;
  partially advanced filter state is never replayed after a timeout.
- Serial/concurrent PCM and filter/click state match exactly in 96 fixtures
  (internal/external clock, four rates, four reverbs, CZ/Prophet/FM6, BASS,
  Off fade and metronome). Host worker completed 11712 Wah jobs, no timeout.
- Moving work between cores does not by itself prove a total timing improvement
  or guarantee removal of the device clicks. The post-FX dependency remains.
  Use device timing and `audio_late` deltas to evaluate the reported clicks.

## Read-only TRS diagnosis

The zero DMA buffer on the device does not establish a parser/count-only bug.
This build intentionally does NOT change pin mapping, baud, parser or DMA
reading algorithm. It adds the console command `uart` and live polling metrics.
No GPIO or peripheral reconfiguration happens when issuing `uart`.

Disable USB Record to expose CDC, open the serial console, and run `uart` once
with the MPC stopped and once while it sends notes and MIDI Clock.

Expected configuration from the existing UART HAL (not new board evidence):

| Field | Expected |
|---|---|
| uart_init_calls | 1 after boot |
| uart_poll_calls | Increases while idle and playing |
| uart_baud_divisor | 383 (48 MHz, 31250 baud) |
| uart_clock bits 11:10 | 1 |
| uart_iomap2 bits 13:8 | 49, PH8 |
| uart_iomap3 bits 6:4 / bit 7 | 5 / 0 |
| PH8 DIR/DIE/PU/PD | 1/1/1/0 |
| uart_dma_start | Equals uart_ring_expected |
| uart_dma_end | start + 128 |
| uart_dma_buffer_size | 128 |

`uart_rx_high_samples`, `uart_rx_low_samples` and `uart_rx_changes` sample the
GPIO at the existing polling cadence. They are not a logic analyzer and may
miss a MIDI pulse. Raw DMA counts and the stored bytes are reported separately.
Host mocked-MMIO tests cover snapshot read-only behavior and truthful counters;
physical TRS reception is still unresolved pending device output.

## Device checks for Wah

With Wah on, `status` / `cpu` include:

- cpu1_wah_jobs: should increase when CPU1 is online.
- wah_max_us / wah_wait_us: worst job and join-wait timings since boot.
- wah_serial_blocks: startup/refused/offline fallback count.
- Existing audio_late, audio_max_us, cpu1_timeouts and stack markers remain.

## Mac emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage29-wah-cpu1-trs"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tests/run_dualcore_tests.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

## Target build after emulator

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage29-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage29-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Actual target linking/memory checks and physical TRS/audio timing tests remain
pending. No device flash or legacy golden regeneration performed here.
All engine DSP sources, including eng_quad.c, and boot stub/loader bytes are
unchanged. First installation/replacement of the rescue stub still has the
previously documented interruption window.
