# Stage30 Wah Lite — exact Stage29 audio

This project contains all Stage29 features. Only the Wah arithmetic in firmware/src/cr_out.c changes; CPU1 routing, clocks, filter curve, damping, wet ramp and IRQ scheduling stay as Stage29.

The fixed damping multiplication uses exact symmetric integer half-rounding, bounded by the filter state limit. At fully wet gain, the final mix returns wet directly. The sweep coefficient is skipped when the filter is dry; its power-of-two divisor is expressed as a shift. No new lookup tables, interpolation, buffers or added latency. Gate's existing arithmetic is retained.

Steady fully wet processing avoids four 64-bit products per stereo frame at the C expression level. Target assembly and actual timing improvement require a JieLi build and measurements on FM1; this is not a measured CPU percentage or a guarantee that clicks disappear.

## Validation

36,000 blocks / 1,152,000 stereo frames match the frozen Stage29 kernel bit for bit, including filter states and gains. Cases cover three FX modes, all four rates, 20..300 BPM, internal/external clock and clock loss/fades. The damping shortcut is exhaustively checked for the entire +/-16,777,216 state range.

Run tests/run_new_features.sh and tests/run_dualcore_tests.sh. The exact comparison is tests/cr_wah_optimization_test.c; its frozen reference is tests/cr_wah_stage29_reference.h (test-only, not included in firmware).

## Mac emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage30-wah-lite"
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi
```

## Target build (no automatic flash)

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage30-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage30-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Check package/memory before installing. No target package was generated in the host validation environment. TRS diagnostics (`uart`) and recovery stub are unchanged. eng_quad.c and legacy goldens are unchanged. Boot recovery does not imply all possible interrupted-write scenarios are safe.
