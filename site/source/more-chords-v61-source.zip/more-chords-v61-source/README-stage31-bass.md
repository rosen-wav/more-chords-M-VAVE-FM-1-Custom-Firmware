# Stage31 — BASS engine

Full Stage30 Wah Lite project with all previous functions, plus the BASS engine. Select BASS in the ordinary engine picker (last in display order). Save a BASS preset to your custom BASS collection to play it as the bass part; when dual core is online that part renders on CPU1 through the existing worker. BASS selected as the main engine remains one monophonic voice on the main routing.

## Controls

- OSC: Wave1 / Wave2 (Sine, Triangle, Saw, Square), Mix, Detune (0..50 cents).
- FILTER: Cutoff, Resonance, Drive (up to approximately 8x before soft saturation), Sub (sine one octave below the played note).
- ENV: Attack, Decay, Sustain, Release; the existing filter envelope amount is available in modulation.
- LFO: Rate, Wave, filter Depth, Fade. Existing Glide and note priority controls apply.

The UI reuses oscillator glyphs, filter response, envelope display and knob/bar cells. SELECT while editing opens the filter. The engine enforces Mono even if a saved track asks for Poly/Unison; releasing the priority note falls back to other held notes. It does not generate a chord: when played in chord mode, the existing mono note priority chooses one note from the generated notes.

Eight dry factory sounds: SUB PURE, ROUND TRI, SAW BASS, SQUARE SUB, ACID BASS, DRIVEN, DARK PLUCK, DETUNE BASS. The sub crossfades the main oscillator pair to preserve headroom. Saw and square reuse the existing band-limited oscillators; triangle and sine reuse the standard oscillator functions. Filter/drive reuse the established fixed-point DSP blocks. Drive is before the low-pass.

## Compatibility and memory

No new private audio buffer, patch blob, flash region or runtime engine-state pool. Parameters live in the existing P_E0..P_E7 plus common envelope/LFO fields; filter/phase state lives in voice_t. Factory data/DSP/UI add code and readonly data; exact target flash/RAM figures require a Mac target build.

Legacy engine IDs and user favourite references remain unchanged: with Prophet enabled, former user reference 17 is reserved and BASS is 18. BASS stars use retired PHYS bitmap row 9; its old retired flags are cleared once, using an unused marker in retired SAMPLE row 4. Existing custom bass references (including user slots) retain their meaning. PER5 and the 192-byte ChoralRoot settings record retain their sizes. Current selected BASS sound persists via the normal sound fields; the last BASS browsing position when switching away is session-only, like the existing Prophet pool exception. Downgrading cannot play new BASS user presets; keep this build for those sounds.

QUAD source, legacy goldens, UART/TRS logic, recovery stub and loader are unchanged. CPU1 remains enabled by default. No firmware was flashed here. Successful host tests do not establish target memory limits or measured DSP timing.

## Emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage31-bass"
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi
```

## Validation

Run `sh tests/run_new_features.sh` and `sh tests/run_dualcore_tests.sh`. New BASS tests cover distinct oscillator/sub/drive output, cutoff response, eight presets across pitches and all requested voice modes, note priority/fallback/release, editor filter, parameter clamps, user preset round trip, legacy favourites/custom bass references and unchanged settings layouts. The worker test compares 160 serial/CPU1 configurations (eight presets, five chord engines, four reverbs), note changes/releases and voice state.

## Device build only, after listening in emulator

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage31-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage31-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Review build/memory and package checks before any installation. No ready-to-flash package is included.
