# Stage33: original CPU split, Prophet chords only

Complete Stage31-based project with all earlier features retained. The experimental Stage32 voice rebalance is reverted exactly: CPU1 renders up to two CZ-1/Prophet chord kernels plus the bass, CPU0 the other chord kernels.

Prophet cannot be added to the BASS collection or selected using the bass editor, factory/user pool or INIT. Attempts show the full text "prophet preset can't be saved as bass", displayed on two lines. Saving a Prophet bass sound is blocked both at dialog entry and at overwrite/naming commit. Prophet chord presets and favourites remain supported.

Previously stored Prophet bass references are not deleted or rewritten. Selecting one turns bass OFF and releases the bass part. Existing entries can still be removed from the collection; their original chord/user records remain intact. CZ-1, BASS and other bass engines retain their previous behaviour.

The message buffers grew from 24 to 48 bytes to retain the entire text. The PER5/settings/flash layout is unchanged. Actual target RAM/flash figures require a new Mac build. QUAD, loader, boot stub and legacy golden audio are unchanged. No ready-to-flash firmware is supplied.

## Test the emulator on Mac

```sh
cd "$HOME/Downloads/ChoralRoot-stage33-no-prophet-bass"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
sh tools/emu/build.sh
build/host/emu --no-midi
```

Choose Prophet on chords, hold the collection save control, choose BASS and try adding it. Check the warning. Try a saved user Prophet preset too. Favourites and chord saves should still work. CZ-1 and BASS should still be addable and usable as bass. To remove old Prophet bass references, select the corresponding chord preset and toggle its existing BASS collection membership.

## Build after emulator verification

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage33-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage33-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

No hardware performance guarantee is inferred from host tests. The removed combination is the one that reproduced overload on the user's FM1.

Validation: full host feature suite and full dual-core suite exit 0; dedicated Prophet bass rejection test exit 0. All 201 factory presets and saved-user paths tested. Serial/parallel PCM and state equivalent across 5638 combinations, 10368 voice-policy cases. See docs/validation/stage33-*.txt.
