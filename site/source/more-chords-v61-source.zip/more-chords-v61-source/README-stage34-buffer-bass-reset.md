# Stage34: modest audio buffer increase and one-time BASS collection reset

Complete Stage33 project. Prophet bass restriction and original CPU1 split (two chord kernels plus bass) remain.

I2S/DAC half-buffer: 128 -> 160 stereo frames (2.902 -> 3.628 ms at 44.1 kHz). Double DMA buffer: 2048 -> 2560 bytes (+512 bytes RAM). Control/render kernels remain 32 samples. The ISR renders five blocks per half instead of four; load meter, overload thresholds, note output timing and console deadline use the new size automatically. This can absorb transient overhead, but does not reduce sustained synth CPU cost or guarantee removal of Scatter clicks. CPU1 timeouts and voice shedding remain enabled. USB recording ring/latency is unchanged.

Emulator uses the same 160-frame firmware halves. SDL device requests the next power-of-two period (256) and its existing FIFO bridges device callbacks and firmware blocks.

Collection reset: existing BASS references (retired favourite bitmap rows 8/10) are erased once when the collection marker migrates from 0x30 to 0x34. BASS starts OFF/0. The new marker and empty list are saved using the existing settings writer. New BASS additions then persist normally; subsequent boots do not erase them. Ordinary favourites, user sound records, other settings and patch banks remain intact. This reset is intentional and cannot reconstruct your old collection automatically.

## Mac emulator first

```sh
cd "$HOME/Downloads/ChoralRoot-stage34-buffer-bass-reset"
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi
```

With existing emulator settings, BASS should be empty/OFF on this first updated launch. Add a CZ-1/BASS sound and check it can be used. Prophet must still show its rejection message.

## Target build after emulator check

```sh
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage34-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage34-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Review target memory/package checks before installing. No flash or target build was performed here. Actual DMA behaviour at the new register length, Scatter clicks and key latency need device confirmation. QUAD source, boot stub/loader and legacy golden audio are unchanged. See docs/validation/stage34-*.txt for host checks.

Validation: full host feature suite and dual-core suite exit 0. The new reset/buffer test checks enlarged halves and output guards, preserved favourites, captured settings marker and retained new entries. The simulated DMA ISR suite checks late reporting, nested timer accounting, overload protection and CPU meter convergence. These are host checks, not hardware DMA timing measurements.
