# Stage35: 192-frame audio halves

Complete Stage34 project, with I2S/DAC half-buffer increased from 160 to 192 stereo frames: 3.628 -> 4.354 ms at 44.1 kHz. Double DMA buffer 2560 -> 3072 bytes, +512 bytes RAM. Each half renders six existing 32-frame control blocks. CPU accounting, overload thresholds and note output timing follow the new size. CPU1 split/timeouts and USB recording buffers are unchanged.

This adds 0.726 ms to each half and approximately 0.73–1.45 ms to the existing input-to-output buffer wait, depending on note arrival. It can improve tolerance to transient work; it does not reduce sustained rendering cost or guarantee removal of all Scatter clicks. Target memory limits and actual audio/latency must be checked on FM1.

BASS marker remains 0x34: upgrading from Stage34 retains new BASS collection entries. Existing Stage33/older collection is still migrated/reset once, as introduced in Stage34. All user sounds/favourites remain intact. Prophet bass restriction remains. QUAD/boot stub/loader/legacy golden audio are unchanged. No flashable binary is supplied.

## Build on Mac

```sh
cd "$HOME/Downloads/ChoralRoot-stage35-buffer192"
source "$HOME/.venv/bin/activate"
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage35-build.log 2>&1
build_status=$?
tail -n 40 build/host/stage35-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

Emulator uses the same 192-frame halves through the existing FIFO and 256-frame SDL period. Build with `sh tools/emu/build.sh` and launch `build/host/emu --no-midi` if desired before device testing.

Validation: `sh tests/run_stage35_buffer_tests.sh` exit 0: 192-frame DMA output/guards and BASS marker persistence, real ISR Gate, sidechain, loop transpose, simulated DMA late/overload/CPU-average checks, target C syntax dual-core 0/1. Full Stage34 suites remain the baseline; only buffer configuration/comments and buffer test expectations changed.
