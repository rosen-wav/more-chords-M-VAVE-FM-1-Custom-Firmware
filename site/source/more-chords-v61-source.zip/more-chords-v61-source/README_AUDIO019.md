# Choralroot Remix — USB 48 kHz + Output Clean

Questa cartella contiene il progetto Remix completo aggiornato a partire da `Choralroot-remix-step20-keys-loop-bass`. Include le due funzioni audio selezionate dalla versione ufficiale 0.19; non è una sostituzione con tutta la release ufficiale.

## MIDI Chord Start: base configurabile e persistente

Nelle impostazioni, dopo i tre canali MIDI, **MIDI Chord Start** sceglie la prima nota
MIDI del blocco accordi. KNOB 1 cambia il valore di un semitono. La schermata mostra
nome e numero assoluto, ad esempio `C2 / MIDI 36`; la convenzione dei nomi è C4=60.
Il range è **0–118**, così tutti i controlli bianchi e neri restano nel range MIDI 0–127.

Dalla base scelta, in ordine crescente:
- **primi quattro tasti neri:** DIM, MIN, MAJ, SUS;
- **primi cinque tasti bianchi:** 6, m7, M7, LOCK, 9.

Se la base è un tasto nero, quel primo tasto seleziona DIM; il primo bianco successivo
controlla 6. Il blocco può occupare nove o dieci semitoni: un eventuale tasto in più
del colore già completo rimane una normale radice suonabile. Per esempio, con base
E, il bianco C rimane suonabile e il successivo C# è SUS. I nomi delle ottave possono
differire da quelli della tastiera esterna: usare il numero MIDI come riferimento.

Esempio con base C2 / MIDI36:

| MIDI | Nota | Funzione |
|---|---|---|
| 36 | C2 | 6 |
| 37 | C#2 | DIM |
| 38 | D2 | m7 |
| 39 | D#2 | MIN |
| 40 | E2 | M7 |
| 41 | F2 | LOCK |
| 42 | F#2 | MAJ |
| 43 | G2 | 9 |
| 44 | G#2 | SUS |

Il default resta **F3 / MIDI53**. Il blocco fisico del FM1 non viene spostato.
In just keys tutti i tasti MIDI restano note normali; il canale MIDI Bass è sempre
un ingresso diretto. Se si cambia la base mentre si suona, le note e i controlli
MIDI precedenti vengono rilasciati e LOCK si disattiva, così gli ultimi
note-off non vengono interpretati con una mappa diversa. Le note fisiche condivise
con quelle MIDI rimangono suonabili e non perdono il proprio owner.

La scelta viene salvata automaticamente dopo il normale intervallo di quiete:
fermare loop/sequenze, rilasciare le note e attendere circa due secondi in silenzio
prima di spegnere. Il record impostazioni resta **192 byte** (persist_t invariato):
versione 9, con base codificata in un byte delle scale ormai ritirate. I record
v1–v7 migrano al default53; i record v8 conservano la base scelta (119 diventa 118
per lasciare spazio ai controlli neri). Gli altri dati restano invariati. Le scale restano disabilitate.
Il byte QUAD e i pool per engine non vengono riutilizzati. CPU1 e buffer invariati.
La dimensione target finale va verificata con la build sul Mac.

## Blocco accordi della tastiera MIDI esterna

Con la base predefinita, in modalità chords le note MIDI **53–61** controllano lo stesso blocco accordi
stampato sulla tastiera FM1. Cambiare ottava sul FM1 non sposta la base MIDI scelta:

| Nota MIDI | Nome (C4 = 60) | Controllo |
|---|---|---|
| 53 | F3 | 6 |
| 54 | F#3 | DIM |
| 55 | G3 | m7 |
| 56 | G#3 | MIN |
| 57 | A3 | M7 |
| 58 | A#3 | MAJ |
| 59 | B3 | LOCK |
| 60 | C4 | 9 |
| 61 | C#4 | SUS |

Alcune tastiere chiamano queste ottave diversamente: i numeri MIDI sono il riferimento.
Le altre note sono radici. Tenere una qualità e suonare una radice genera l'accordo;
con LOCK attivo basta toccare e rilasciare la qualità. Il tap successivo su LOCK
sblocca la selezione MIDI. Cambiare qualità sostituisce quella precedente mantenendo
le estensioni bloccate; queste si possono attivare/disattivare con un tap.
Le settime minore e maggiore restano esclusive. Il LED LOCK e lo stato della qualità
riflettono i controlli MIDI. LOCK è unico per FM1, USB e TRS: un tap sul FM1 blocca anche i modifier MIDI;
un tap MIDI blocca anche i modifier fisici. Spegnerlo da qualsiasi ingresso libera
le selezioni virtuali di entrambi, conservando i tasti realmente tenuti. È possibile
cambiare qualità e attivare/disattivare estensioni passando da una tastiera all'altra.
Il rendering audio e i record dei preset/loop non cambiano.

In **no chords just keys**, anche 53–61 sono normali note suonabili e LOCK non viene
attivato da B3. Il canale MIDI Bass resta un ingresso diretto e non riserva questi tasti.
Sustain agisce sulle radici/note, non trattiene i tasti di controllo. La selezione
si applica nello stesso blocco audio, senza aspettare un aggiornamento della UI.

La mappa usa pochi byte di stato; il costo e il margine finali vanno confermati dalla
build target. Nessuna modifica a CPU1 o buffer DMA.

## Correzione MIDI Perform

USB e ingresso MIDI TRS ora seguono la tastiera integrata: in modalità accordi una nota
MIDI genera l'accordo selezionato, con voicing e performance; in no chords just keys
le note restano singole e, con Bass/ENV attivo, almeno tre note distinte fanno suonare
il preset di basso sulla nota più bassa. Il registro del basso segue le sue impostazioni.
Il canale MIDI Bass rimane un ingresso diretto indipendente.

Impostare MIDI Perform sul canale trasmesso dalla tastiera (ad esempio 1), non Off.
Per il basso automatico abilitare Bass/ENV e selezionare il suo preset: non serve
che la tastiera trasmetta anche sul canale MIDI Bass.

USB, TRS e tastiera integrata hanno proprietari distinti delle note. Sustain,
CC120/121/123, note-on a velocity zero, cambio canale e overflow sono coperti dai test.
La registrazione nel sequencer usa lo stesso percorso delle note fisiche.
La CPU1, la distribuzione delle voci e il buffer DMA non cambiano. Lo stato MIDI aggiunge
260 byte statici prima dell'eventuale padding del linker; memoria e dimensione XIP
vanno confermate dalla build target sul Mac. Nessun flash eseguito qui.

Prima prova:

```sh
cd "$HOME/Downloads/Choralroot-remix-midi-shared-lock"
source "$HOME/.venv/bin/activate"
sh tests/run_midi_perform_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu
```

L'emulatore viene avviato con MIDI attivo: non aggiungere `--no-midi` per questa prova.
Sono inclusi i risultati dei test host; il test fisico della tastiera MIDI sul FM1
rimane da eseguire dopo la normale build e verifica del pacchetto.

## Novità

- **Raccordo del retrigger Prophet.** Una voce riutilizzata riparte dal suo ultimo campione udibile; un offset temporaneo si estingue in 128 campioni (circa 2,90 ms). Oscillatori, filtro e inviluppi proseguono nel rendering nativo; non viene renderizzata una seconda voce e il buffer audio rimane 192 frame. Il raccordo è privato di ogni voce e funziona nei percorsi seriale e CPU1. I preset salvati non cambiano.
- Rendering seriale isolato: prima del fix, 4.824 transizioni factory avevano un salto massimo di 13.216 unità PCM al retrigger, anche a velocity fissa. Dopo il fix, il salto iniziale è zero in tutte le transizioni, a velocity fissa e variabile. Il test controlla anche che il raccordo termini dopo 128 campioni e non modifichi le altre voci già nel mix. È un riscontro sul rendering, **non una prova che ogni click udibile sul FM1 abbia questa causa**: provare il preset che mostrava il problema.

- **Basso delle sequenze just keys indipendente dalla modalità della tastiera.** Le note raw salvate continuano a generare il basso sulla più bassa con almeno tre note simultanee, anche con just keys Off. Cambiare modalità rilascia le voci live e conserva le voci/scheduler del loop; il basso non perde il proprio owner. Le note raw registrate restano assolute durante i cambi di voicing; il transpose del loop rimane operativo. Funziona sui record già salvati, senza migrazione o nuovi eventi bass.
- Fix verificato su **10.080 fixture** nelle due modalità, con salvataggio/rilettura slot20, cambio tramite impostazioni durante playback, condivisione del pitch live/loop e release/stop.

- **PLAY quantizzato al prossimo quarto**, sia per loop sia per sequenze. Con MIDI Clock In attende una frontiera di 24 impulsi accettati dal master USB/TRS; senza clock entrante resta in attesa. Il clock interno segue la griglia del metronomo. PLAY lampeggia in attesa: una seconda pressione annulla; durante la riproduzione ferma subito. MIDI Start/Continue/Stop conserva il controllo del master.
- **USB Record, USB Level e USB Rate persistenti**, verificati con scrittura NOR simulata e rilettura dal percorso di boot. Il salvataggio automatico aspetta circa 1,5 secondi senza modifiche e 1 secondo senza audio, senza eseguire erase durante playback o attesa di PLAY. Dopo avere cambiato queste opzioni, ferma la riproduzione e attendi circa 2 secondi in silenzio prima di spegnere. Clean è già il default; una scelta esplicita Classic viene conservata.

- **Impostazioni → Output → Clean / Classic.** Clean è il default, anche caricando le vecchie impostazioni. Porta il limiter con 32 campioni di look-ahead (circa 0,73 ms), il mantenimento del guadagno e MASTER applicato alla fine con la precisione del DAC. Classic mantiene il precedente stadio di uscita per confrontare i risultati.
- **Impostazioni → USB Rate → 44.1 kHz / 44.1 + 48 kHz.** La prima rimane il default. La seconda offre entrambe le frequenze al computer: è il computer a scegliere quella effettiva. Il synth e l'uscita analogica rimangono a 44,1 kHz. I sei canali USB vengono convertiti quando il computer sceglie 48 kHz.
- Cambio della frequenza offerta con riconnessione USB ritardata e protezione contro la riconnessione durante un trasferimento SysEx. Il cambio interrompe temporaneamente anche la porta MIDI USB: farlo prima di registrare.
- Allineamento a campione dei tre segnali stereo USB quando Clean è attivo; metronomo ritardato di 32 campioni per mantenere il suo allineamento con le note.
- Gate e sidechain conservano anche i bit frazionari dell'uscita Clean. L'effetto disattivato ha bypass esatto.

804 casi aggiuntivi verificano avvio quantizzato a diverse velocità, cancellazione e stop, clock USB/TRS, cambio sorgente, e persistenza delle opzioni audio su NOR simulata.

Le modifiche non cambiano le dimensioni del record delle impostazioni: Output e USB Rate utilizzano due bit prima liberi nel byte del picker. PLAY in attesa è unicamente stato RAM: non modifica i record loop o le durate registrate. Il picker conserva il suo bit e le impostazioni già salvate continuano a essere leggibili. Preset, patch e loop non vengono riscritti per questa integrazione.

La CPU1 rimane attiva di default, con la stessa distribuzione delle voci. Buffer DMA da 192 frame, Morph, Prophet, BASS, riverberi Remix, sequencer a 20 slot e parser MIDI TRS sono conservati, con il nuovo avvio quantizzato. `firmware/src/eng_quad.c` e i golden audio legacy sono identici all'archivio di partenza. Nessun flash eseguito.

## Prima prova sul Mac: test ed emulatore

```sh
cd "$HOME/Downloads/Choralroot-remix-audio019-prophet-declick"
source "$HOME/.venv/bin/activate"
sh tests/run_prophet_retrigger_tests.sh &&
sh tests/run_audio019_tests.sh &&
sh tests/run_remix_tests.sh &&
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Nell'emulatore si possono provare Clean/Classic e le altre funzioni Remix. L'emulatore non presenta una periferica USB audio: il trasferimento a 48 kHz viene verificato nei test host e successivamente sul FM1.

## Build del firmware sul Mac

Richiede la toolchain JieLi e Docker, come le build precedenti:

```sh
cd "$HOME/Downloads/Choralroot-remix-audio019-prophet-declick"
source "$HOME/.venv/bin/activate"
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 \
PYTHON="$HOME/.venv/bin/python3" sh build.sh \
> build/host/remix-audio019-build.log 2>&1
build_status=$?
tail -n 40 build/host/remix-audio019-build.log
printf '\nBuild exit code: %s\n' "$build_status"
```

La cartella consegnata contiene i sorgenti e gli header generati per l'emulatore, **non un firmware già compilato e approvato per il flash**. Prima dell'installazione vanno controllati il risultato del linker, i limiti delle regioni, il pacchetto prodotto e il dispositivo connesso. Un test host passato non garantisce l'assenza di rischi durante un flash.

## Scegliere 48 kHz dopo l'installazione e i controlli

1. Nel FM1: USB Record On, USB Rate `44.1 + 48 kHz`.
2. Attendere la riconnessione USB.
3. Nel Mac aprire **Configurazione MIDI Audio**, selezionare **ChoralRoot In** e impostare **48.000 Hz** nel formato di ingresso. Usare un progetto DAW a 48 kHz.
4. Provare la registrazione sotto carico e controllare contatori audio/USB e perdita di voci. La 0.19 stima circa il 6% di CPU aggiuntiva per la conversione dei sei canali: non è una misura della nostra Remix sul FM1.

Clean non sostituisce una verifica dei ritardi di rendering; la conversione USB può consumare margine di CPU. L'occupazione finale di flash/RAM/POOL e i tempi sotto carico restano da misurare sulla build per il dispositivo.

## Verifiche eseguite

I log sono in `build/host/audio019-*.log`:

- Clean: 34 verifiche, inclusi limiter/look-ahead, MASTER, cambio di modalità e confronto Classic con la precedente aritmetica.
- USB: 55 verifiche a 44,1 kHz, **byte per byte**; 57 a 48 kHz; 32 per selezione della frequenza/descrittori/riconnessione; 6 per tap USB e output.
- Integrazione Remix: 68.119 controlli su opzioni, persistenza dei bit, bypass/precisione di gate e sidechain, allineamento del click; impostazioni: 54 controlli.
- Rendering concorrente/seriale: 5.638 casi con cinque engine e quattro riverberi, più 160 casi dedicati BASS/CPU1; PCM e stato delle voci coincidono.
- Morph: 81 fixture, 239.616 confronti degli inviluppi carrier FM6 e 36 confronti PCM/stato CPU1/seriale.
- Suite Remix: sequencer, Simple, preset Prophet, basso just keys, 20 slot e stress della griglia con 12.000 modifiche. Gate e ottimizzazione Prophet: test passati.
- Bootguard: 91 controlli; transporter shim: fixture passate. **Nessun nuovo `.fwsc` era disponibile per validare un pacchetto finale.**
- Sintassi della unità firmware con CPU1 abilitata e disabilitata: PASS. Compilazione/link pi32v2 e prove hardware non eseguiti perché la toolchain JieLi non è disponibile nell'ambiente di preparazione.

## Provenienza

Codice e fixture USB/Clean da `ChoralRootFM1-0.19.zip`, con adattamenti alla catena Remix. Le intestazioni GPL-3.0-only sono conservate. Il resampler deriva dal lavoro SLOOP/Felucca citato nelle intestazioni upstream. Documentazione originale di riferimento: `docs/UPSTREAM-019-AUDIO-QUALITY.md` e `docs/UPSTREAM-019-USB-AUDIO.md`; descrive la build ufficiale e i suoi risultati, non un collaudo hardware di questa Remix.
