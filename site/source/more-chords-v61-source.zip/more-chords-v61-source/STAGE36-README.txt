Stage36 — Prophet optimization, complete source project

Includes all Stage35 changes. Audio DMA halves remain 192 frames.

Mac checks:
source "$HOME/.venv/bin/activate"
sh tests/run_prophet_optimization_tests.sh
sh tests/run_dualcore_tests.sh

Device build:
mkdir -p build/host
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh > build/host/stage36-build.log 2>&1

Review exit status and memory report before checking the package or installing.
No prebuilt firmware included; build on Mac. Hardware performance improvements
must still be measured: host PCM equivalence does not guarantee click removal.
See docs/STAGE36-PROPHET-OPTIMIZATION.md.
