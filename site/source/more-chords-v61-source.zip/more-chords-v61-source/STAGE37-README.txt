Stage37 — Gate only
Complete Stage36 project with synced master Wah removed.
Knob3 Off/Gate (three-detent threshold), knob4 rate unchanged.
CPU1 remains enabled for voices and bass; DMA halves remain192 frames.
No prebuilt firmware; build on Mac.
Tests: sh tests/run_stage37_tests.sh
See docs/STAGE37-NO-WAH.md.
