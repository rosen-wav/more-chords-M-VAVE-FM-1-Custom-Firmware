Stage38 — Morph, complete source project
Based on the uploaded and hardware-tested Stage37 gate-only.

First test on Mac:
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh
sh tools/emu/build.sh
build/host/emu --no-midi

Hold EDIT and select Morph. EDIT > OSC: Engine / Preset / Position / Morph type.
EDIT > LFO: Speed / Amount / Trigger / Roll. Trigger Chord means each chord.
Begin with Amount15 and Manual; then try Ping Pong, Random and Chord triggering.
Native source preset selector currently includes factory presets; Morph itself can be saved.
No Wah. DMA192. CPU1 retained. Do not flash before reviewing a fresh Mac device build.
Details/limits: docs/STAGE38-MORPH.md; host evidence: docs/STAGE38-HOST-VALIDATION.txt.
