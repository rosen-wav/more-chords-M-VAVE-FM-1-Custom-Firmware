STAGE39 — MORPH UI / FM6 / LOFI

Complete source project including all previous changes. No patch application needed.

Changes from Stage38:
- Morph uses a rosen-style focused value and four compact knob cells.
- Stable engine/preset labels independent of temporary audio parameters.
- BASS removed only from Morph sources; standalone BASS unchanged.
- FM6 preserves carrier envelopes and does not force held voices into sustain on every Morph update.
- LOFI protects discrete wavetable/stepped-envelope controls, sweep, vibrato and crushing; remaining changes are gentle.

Mac emulator:
cd "$HOME/Downloads/ChoralRoot-stage39-morph-refine"
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi

See docs/STAGE39-MORPH.md for controls, scope and limitations.
No firmware package is bundled; target build and memory checks are still required before any install.
