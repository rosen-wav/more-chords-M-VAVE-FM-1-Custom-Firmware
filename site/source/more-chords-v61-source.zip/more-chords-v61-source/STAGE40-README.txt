STAGE40 — GENTLE QUAD / UP AND DOWN / SETTINGS ORDER

Complete source project; all previous changes included.
- Gentler QUAD Morph, with feedback/resonance/drive/harmonic offset/LFO preserved.
- Manual / Up and Down / Random. Up and Down moves A -> B -> A.
- no chords, just keys immediately after Play Style in Settings.
- Standalone QUAD DSP unchanged. No flashing or legacy audio regeneration.

Emulator:
cd "$HOME/Downloads/ChoralRoot-stage40-morph-quad"
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi

Target build and memory checks remain required before installation.
