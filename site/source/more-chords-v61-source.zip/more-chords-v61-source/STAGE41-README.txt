CHORALROOT REMIX — STAGE41

Complete source project, including all previous changes.
Morph INIT defaults: Speed 2.0s (1.982s actual), Amount60.
QUAD Morph: intermediate variation caps (8 units for shared/native continuous controls, 5 for levels/mix), with feedback/resonance/drive/harmonic offset/LFO preserved.
Saved USER Morph configurations keep their stored settings.
Standalone QUAD engine unchanged. No flashing or legacy golden regeneration.

cd "$HOME/Downloads/Choralroot-remix"
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi

Target build and memory checks remain required before installation.
