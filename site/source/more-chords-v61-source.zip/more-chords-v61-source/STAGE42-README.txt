CHORALROOT REMIX — STAGE42

Complete source project including all previous changes.
- Manual follows Position with a 50ms transition; Speed is for automatic motion.
- Distinct A/B variants in separate bands, inside the same bounded depth.
- QUAD/VA native macros persist through source block processing.
- Speed default 2.0s, Amount60 retained.
- QUAD DSP source unchanged.

cd "$HOME/Downloads/Choralroot-remix"
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi

For the audible test choose Trigger Free, Amount60, Speed2.0s; compare Manual Position0/100 and Up and Down over several seconds. Saved USER settings remain saved values. No flashing or legacy golden regeneration. Target build/memory checks remain required before install.
