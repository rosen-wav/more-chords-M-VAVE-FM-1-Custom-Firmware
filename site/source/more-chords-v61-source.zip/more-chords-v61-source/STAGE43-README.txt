CHORALROOT REMIX — STAGE43 KEYS-ONLY BASS

Complete source project including Stage42 Morph and all previous changes.

Enable Settings > no chords, just keys, select a BASS preset and enable BASS with the usual ENV control.
One/two distinct held keys: ordinary keyboard only.
Three or more: one bass follows the lowest actually played note, in the existing BASS register/behavior and octave setting.
Adding/releasing a lower key updates the bass; falling below three keys releases it.
Duplicate note owners do not count twice. Pads and loop playback do not count as held keys.
Main keyboard notes are not removed or turned into generated chords. Bass uses the normal selected preset and routing/CPU1 path. Crystal bass octave alternation still applies when enabled.
BASS/stream off, panic and leaving keys-only release the aggregate bass owner.

No new persistent settings, bank format or flash region. QUAD DSP unchanged. No flashing or legacy golden regeneration.

cd "$HOME/Downloads/Choralroot-remix"
source "$HOME/.venv/bin/activate"
sh tests/run_keys_bass_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi

Existing USER Morph values remain saved. Target build/memory checks remain required before install.
