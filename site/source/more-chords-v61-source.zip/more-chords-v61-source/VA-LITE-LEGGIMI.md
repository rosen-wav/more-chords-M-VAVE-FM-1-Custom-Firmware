# VA Lite / Morph senza FM6 — modifica della v61

Base: more-chords-v61(1).zip, Choralroot-remix-v61-generic-fm6.

## Modifiche

- VA: ENV1 (ampiezza), ENV2 (filtro/modulazione), LFO1 e LFO2 restano attivi.
- ENV3/4 e LFO3/4 non vengono più elaborati. Rimosse le loro pagine, i controlli SYNC3/4 e le voci della matrice, incluse RATE3/4 e DEP3/4.
- Aggiornati navigazione delle sezioni e assegnazione rapida delle modulazioni.
- Il formato binario VA e gli identificatori salvati rimangono invariati. I dati dei modulatori ritirati restano nei blob per compatibilità, ma non contribuiscono al suono. Le vecchie rotte verso AMP non silenziano il suono quando la sorgente è ritirata.
- Morph: FM6 non è più selezionabile né renderizzato come sorgente A o B. Gli indici salvati degli altri motori rimangono invariati.
- Vecchi preset Morph con FM6 su A: fallback a PHASE. FM6 su B: fallback a Same as A. Nessuna modifica al motore FM6 autonomo.

I preset VA che utilizzavano ENV3/4 o LFO3/4 cambiano timbro perché queste modulazioni vengono disattivate. Non viene promessa una percentuale di risparmio CPU: le quattro catene oscillatore e i filtri restano invariati, e serve una misura sul dispositivo.

## Verifiche

Eseguire `sh tests/run_va_lite_tests.sh` dopo la generazione degli header descritta in BUILDING.md.

- Test audio Morph: endpoint A/B, posizione, interfaccia e note-off.
- Controllo sintattico firmware con CHORALROOT_DUAL_CORE=0 e =1.
- Test VA Lite con UndefinedBehaviorSanitizer (esclusi gli shift signed preesistenti): avanzamento assente dei modulatori ritirati, audio attivo, mapping UI/preset e assegnazioni rapide.

Non è stato effettuato un collaudo su hardware FM-1. Nessuna modifica pubblicata sul sito o sul repository remoto.

## Firmware incluso

`firmware-installabile/more-chords-v61-va-lite.fwsc` è stato compilato con la toolchain JieLi 20260730.1. Identità pacchetto FM-1_920; la versione interna resta quella della base v61 (ChoralRoot 0.14).

Controlli build superati: RAM 93888/98304 B; POOL 335296/344064 B; XIP 569952/573440 B; controllo accessi HAL e codice CPU1. Questi sono dati di memoria, non misure del carico CPU.

SHA256SUMS contiene l'hash del pacchetto. Per l'installazione usare il selettore di file locale dell'installer seguendo BUILDING.md e mantenere un backup dei preset.
