> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](README-V8.md).

# ChoralRoot development snapshot — NOT ready to flash

Changes completed:
- Options > Dynamic Velocity: On/Off, independent of existing fixed "Velocity" value.
- Stored via bit 3 of pick_roots in the existing settings record, with older settings defaulting to On.
- When Off, cr_cb_note_on uses velocity 100 for notes routed through the ChoralRoot performance engine, including its sequenced notes.
- Settings record host tests: 55 passed.

NOT completed:
- Actual physical key force sensing from Monk. This requires changing FM1 input HAL analog sampling and matching event timing; this snapshot does not sense physical velocity.
- Velocity handling of every external MIDI path and all edge cases.
- True Morph A/B with two independent patches and parallel render on CPU0/CPU1; this remains the original V3 morph.
- Emulator and hardware tests. Emulator build here fails on unavailable SDK header os/lock.h.

DO NOT flash this experimental snapshot to FM1. This is an intermediate source patch to review, not the requested full implementation.
