#!/usr/bin/env python3
"""Read-only QUAD golden migration audit. Never writes project files."""
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parent
if not (root/'tests/quad_goldens').is_dir():
    root=Path.cwd()
engine=root/'firmware/src/eng_quad.c'
ref=root/'tests/quad_ref.py'
print('ROOT:',root)
if not engine.exists():
    sys.exit('Missing firmware/src/eng_quad.c; run in project root')
s=engine.read_text(errors='replace')
for key in ['QUAD_VER','QP_NP','QUAD_NRCB']:
    m=re.search(r'^\s*#define\s+'+key+r'\s+([^\s/]+)',s,re.M)
    print(key+':',m.group(1) if m else '(defined elsewhere)')
if ref.exists():
    r=ref.read_text(errors='replace')
    print('quad_ref.py: RCB 19:', 'RCB = [0.25, 0.5, 0.75]' in r)
    print('quad_ref.py: legacy BR 6:', 'BR = [0.5, 1.0, 1.5, 2.0, 3.0, 4.0]' in r)
    print('quad_ref.py: writes quad_tables.h:', 'OUT_H' in r and 'quad_tables.h' in r)
print('\nGOLDENS (read-only):')
for name in ['algo1','algo2','algo3','algo4','algo5','algo6','algo7','algo8','ep','bass','glass_pad','wobble']:
    p=root/'tests/quad_goldens'/f'{name}.json'
    if not p.exists():
        print(name,'MISSING');continue
    d=json.loads(p.read_text())
    print(f'{name:12} patch={len(d.get("patch",[])):3} first={len(d.get("first",[])):4} rms={len(d.get("rms",[])):2}')
print('\nNo files were modified. Do not regenerate goldens or flash hardware yet.')
