#!/usr/bin/env python3
"""Read-only, source-level audit of QUAD renderer drift. Never imports quad_ref.py."""
from pathlib import Path
import re, hashlib, sys
root=Path(__file__).resolve().parent
if (root/'firmware/src/eng_quad.c').exists(): base=root
elif (root/'ChoralRoot-stage23/firmware/src/eng_quad.c').exists(): base=root/'ChoralRoot-stage23'
else:
    print('ERROR: extract in ChoralRoot-stage23 root'); sys.exit(2)
c=(base/'firmware/src/eng_quad.c').read_text()
p=(base/'tests/quad_ref.py').read_text()
print('QUAD V3 RENDERER DRIFT AUDIT (READ-ONLY)')
for path in (base/'firmware/src/eng_quad.c',base/'tests/quad_ref.py'):
    print(f'SHA256 {path.relative_to(base)} {hashlib.sha256(path.read_bytes()).hexdigest()}')
macro=re.search(r'#define QUAD_ALGOS\b(.*?)\n\s*/\* the voice',c,re.S)
if not macro:
    print('ERROR: cannot locate QUAD_ALGOS');sys.exit(2)
block=macro.group(1)
comments=re.findall(r'case\s+([0-6]):\s*/\*\s*(.*?)\s*\*/',block)
default=re.search(r'default:\s*/\*\s*(.*?)\s*\*/',block)
pycases=re.findall(r'(?:if|elif) alg == ([1-7]):\s*\n(.*?)(?=\n\s*(?:elif alg ==|else:|fb2, fb1))',p,re.S)
print(f'Firmware routing comments: {len(comments)} explicit + {int(default is not None)} default')
print(f'Python routing branches: {len(pycases)} explicit + default')
for idx,desc in comments:
    alg=int(idx)+1
    print(f'ALGO {alg} C: {desc.strip()}')
    py=next((b for a,b in pycases if int(a)==alg),None)
    if py:
        out=[line.strip() for line in py.splitlines() if re.match(r'\s*(?:X\s*=|X\s*=\s*Y|Y\s*=)',line)]
        print('       PY outputs: '+ (' | '.join(out) if out else '(not found)'))
if default:print('ALGO 8 C: '+default.group(1).strip())
print('ALGO 8 PY: '+next((l.strip() for l in p.split('            else:\n                yf = CW(p3 + FB)')[-1].splitlines() if l.strip().startswith('X =')), 'inspect manually'))
print('DIFFERENCE: C case 0 has X=C and Y=B1, while Python alg 1 has X=Y=C; independent parity fails.')
print('DIFFERENCE: Python still computes B2 using BR[br] multiplied by B1; QUAD v3 uses independent RB2.')
print('No golden audio produced. No files modified. No DSP correctness claim.')
