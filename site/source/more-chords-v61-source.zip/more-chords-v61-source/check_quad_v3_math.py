#!/usr/bin/env python3
"""Read-only structural parity checks for QUAD v3 ratio and LFO formulas.
No firmware writes; this is NOT an independent audio golden validator.
"""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent
for p in [root,*root.parents]:
    if (p/'firmware/src/eng_quad.c').exists():
        root=p; break
else: sys.exit('ERROR: extract script into ChoralRoot project root')
eng=(root/'firmware/src/eng_quad.c').read_text()
tab=(root/'firmware/src/quad_tables.h').read_text()
legacy=(root/'tests/quad_ref.py').read_text()
def macro(name):
    m=re.search(r'^#define\s+'+re.escape(name)+r'\s+(\d+)',tab,re.M)
    if not m: raise ValueError('Missing '+name)
    return int(m.group(1))
def array(name):
    m=re.search(r'\b'+re.escape(name)+r'\s*\[\s*\d+\s*\]\s*=\s*\{([^}]+)\}',tab,re.S)
    if not m: raise ValueError('Missing '+name)
    return [int(x) for x in re.findall(r'-?\d+',m.group(1))]
assert 'QP_RB2' in eng and 'QP_B2KEY' in eng
assert 'QUAD_RCB_Q16[rb / (int32_t)QUAD_NRCB]' in eng
assert 'QUAD_RCB_Q16[rb % (int32_t)QUAD_NRCB]' in eng
assert 'bpm * QUAD_LFO_K' in eng
assert 'q16(RCB[rb1i]) * q16(BR[br])' in legacy
n=macro('QUAD_NRCB'); total=macro('QUAD_NRB'); k=macro('QUAD_LFO_K'); r=array('QUAD_RCB_Q16')
assert n==19 and total==n*n and len(r)==n
print('QUAD V3 MATH PARITY — read only')
print(f'RCB steps={n}, pair combinations={total}, LFO_K={k}')
for b1,b2 in [(3,3),(3,16),(6,6),(0,18),(18,0)]:
    combined=b1*n+b2
    assert (combined//n,combined%n)==(b1,b2)
    print(f'PAIR b1={b1:2} b2={b2:2} combined={combined:3} ratios_Q16=({r[b1]},{r[b2]})')
print('LFO engine: integer tick increment = (speed * mult * bpm * K) >> 16')
for speed,mult,bpm in [(16,8,120),(32,16,120),(-20,32,120)]:
    tick=(speed*mult*bpm*k)>>16
    print(f'LFO speed={speed:3} mult={mult:4} bpm={bpm} tick_increment={tick}')
print('CONFIRMED: old Python ratio model couples B2 to B1; firmware v3 uses independent steps.')
print('NOT VALIDATED: audio waveforms, modulation timing, envelopes, filters, SNR/RMS.')
print('NO FILES MODIFIED.')
