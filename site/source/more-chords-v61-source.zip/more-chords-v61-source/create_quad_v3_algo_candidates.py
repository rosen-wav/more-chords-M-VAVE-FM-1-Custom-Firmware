#!/usr/bin/env python3
"""Create 8 provisional QUAD v3 algorithm patch candidates; never audio goldens."""
import json, pathlib, hashlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT/'tests'/'quad_goldens'
DST=ROOT/'quad_v3_algo_candidates'

def main():
    output={}
    for a in range(1,9):
        name=f'algo{a}'
        src=SRC/f'{name}.json'
        raw=src.read_bytes()
        old=json.loads(raw)
        p=old['patch']
        if len(p)!=71 or not all(isinstance(v,int) and -128<=v<=127 for v in p):
            raise ValueError(f'{name}: legacy patch invalid; refusing to write')
        if p[0]!=a:
            raise ValueError(f'{name}: algorithm index {p[0]} differs from expected {a}')
        output[name]={
            'name':name,
            'patch':p+[3,0],
            'status':'PROVISIONAL PATCH ONLY - NOT AUDIO GOLDEN',
            'audio_validated':False,
            'v3_tail':{'QP_RB2':3,'QP_B2KEY':0},
            'tail_source':'provisional defaults used by earlier probe; NOT an independent specification',
            'legacy_sha256':hashlib.sha256(raw).hexdigest(),
            'legacy_audio_fields_excluded':['first','rms'],
        }
    DST.mkdir(exist_ok=True)
    for name,obj in output.items():
        (DST/f'{name}.patch.json').write_text(json.dumps(obj,indent=2)+'\n')
        print(f'ALGO_CANDIDATE {name}: 73 parameters, provisional tail [3,0], audio NOT validated')
    print('No firmware, official tests, golden audio, or tables modified.')
if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('ABORT:',exc,file=sys.stderr)
        sys.exit(1)
