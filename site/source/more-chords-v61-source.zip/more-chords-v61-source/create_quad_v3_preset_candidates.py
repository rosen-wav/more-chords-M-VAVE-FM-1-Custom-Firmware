#!/usr/bin/env python3
"""Create patch-only QUAD v3 candidates; NEVER write golden audio or firmware."""
import json, pathlib, sys, hashlib
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT/'tests'/'quad_goldens'
DST=ROOT/'quad_v3_preset_candidates'
# Values verified by user's PATCHDIFF against firmware presets.
CHANGES={
 'ep':{3:(35,3),5:(10,12),7:(0,-30),13:(80,78),14:(24,20),15:(72,66),17:(46,52),19:(44,62),28:(0,40),29:(40,30),36:(0,1)},
 'bass':{3:(22,3),6:(30,24),7:(0,-64),14:(30,34),15:(86,88),19:(40,0),36:(0,1)},
 'glass_pad':{3:(25,6),15:(60,36),19:(40,50),23:(1,0),36:(0,1),46:(92,88),50:(1,11)},
 'wobble':{3:(22,3),6:(20,10),7:(0,-64),19:(30,0),36:(0,3),50:(11,15),58:(7,25)}
}
TAIL={'ep':[16,30],'bass':[3,0],'glass_pad':[6,0],'wobble':[3,0]}

def main():
    prepared={}
    for name,changes in CHANGES.items():
        path=SRC/(name+'.json')
        obj=json.loads(path.read_text())
        patch=obj['patch']
        if len(patch)!=71: raise ValueError(f'{name}: expected legacy length 71, got {len(patch)}')
        p=list(patch)
        for i,(old,new) in changes.items():
            if p[i]!=old: raise ValueError(f'{name} index {i}: legacy {p[i]} != verified {old}; refusing output')
            p[i]=new
        p+=TAIL[name]
        assert len(p)==73
        prepared[name]={
            'name':obj.get('name',name),
            'patch':p,
            'source_legacy_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'status':'PATCH ONLY / NOT AN AUDIO GOLDEN',
            'provenance':'firmware values from PATCHDIFF supplied by user',
            'audio_validated':False,
        }
    DST.mkdir(exist_ok=True)
    for name,obj in prepared.items():
        (DST/(name+'.patch.json')).write_text(json.dumps(obj,indent=2)+'\n')
        print(f'PATCHV3 {name}: {len(obj["patch"])} parameters, audio NOT validated')
    print('Created patch-only candidates in:',DST)
    print('Official tests/quad_goldens, eng_quad.c and quad_tables.h NOT modified.')
if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('ABORT:',exc,file=sys.stderr)
        sys.exit(1)
