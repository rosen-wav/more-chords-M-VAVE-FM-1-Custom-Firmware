# Ambient, Church and Gate

## Reverb

Ambient is unchanged from the user's approved Stage25 Melodee Hall release.
Church now calls that same half-rate stereo Hall render, with the same SIZE/DAMP
controls, input low cut, modulation, normalized feedback matrix and decay gains.
Its additional feed-forward reflection paths use the already high-passed and
diffused input. Different left/right taps at approximately 7, 13, 20, 28 and 40 ms
create a denser early field without introducing another feedback loop.
The old Church comb network is removed. The cross icon remains; Ambient keeps
its leaf icon. Room and Spring retain their existing algorithms.

Church adds a 1,024-sample int16 delay (2,048 bytes in POOL) and a few indices/states.
Ambient and Church share the existing Hall buffers/states, not two Hall networks.
Model changes fade both mid and side, then reset the reflection buffer and Hall.
The early reflection mix is bounded and unmodulated; only the Hall's original
feedback network contributes to the long decay.

## SELECT performance menu

| Knob | Function | Values |
| --- | --- | --- |
| 1 | swag voicing | Off / Ping Pong / Random / Tennis |
| 2 | rosen mode | Off / Next / Random / Ping Pong |
| 3 | Gate | Off / On |
| 4 | Gate rate | 1/8 / 1/16 / 1/32 |

Gate retains the prior stereo gain smoothing, 50% duty cycle, internal/MIDI sync,
300 ms external clock dropout bypass, and position after FX/master and sidechain,
before USB master capture and metronome. It starts Off at 1/16 and is session-only.
SELECT inside engine Edit still opens the filter section.

The performance Stutter, capture/replay state, dry/send capture hook and 18,432-byte
capture buffer are removed. The net POOL saving is 16,384 bytes after adding
Church's 2,048-byte reflection delay. The 384-byte CPU0 pre-verb stack scratch is
also gone. Exact linked flash/RAM totals and real-time cost still need a Mac/JL build.
Other existing native engine/track effects are preserved.

## Mac preview

```sh
cd "$HOME/Downloads/ChoralRoot-stage25-church-gate"
source "$HOME/.venv/bin/activate"
sh tests/run_new_features.sh
CHORALROOT_DUAL_CORE=1 sh tools/emu/build.sh
build/host/emu --no-midi
```

Compare Ambient and Church at the same send, SIZE and DAMP. Test a short bright
note and sustained low notes, then switch models while the tail rings. Check Gate
at all three rates, including MIDI sync if available. Host tests cannot establish
subjective sound quality or target timing. No flashing or legacy golden regeneration
is performed for this source release.
