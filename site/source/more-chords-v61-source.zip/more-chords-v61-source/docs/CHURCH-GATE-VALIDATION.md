# Church / Gate validation

## Passed

- `sh tests/run_new_features.sh`: exit 0 (fresh compile and execution).
- `sh tests/run_dualcore_tests.sh`: exit 0.
- Additional final Gate fixture: exit 0; Panic preserves the current Gate gain
  instead of forcing it open. Target dual-core C syntax repeated after this change.
- Ambient: 30,000 blocks bit-identical to the Melodee Hall reference, mid and side.
- Church: stereo early reflection output precedes the Hall's first arrival;
  bounded output and correct stereo reset on model changes.
- All four reverbs: distinct impulse responses, decay controls, stress corners,
  silence after tails, all model transitions and UI icons.
- Room remains bit-identical to its original bus algorithm; Spring regressions pass.
- Gate: actual emulator ISR path, menu Off/On only, knob clamps/rates,
  20/120/300 BPM, exact Off, stereo smoothing, real queued MIDI clock/dropout.
- SELECT in engine Edit still opens FILT on tap/hold/encoder gestures.
- Concurrent/serial audio: 5,638 cases, identical PCM and engine/voice state;
  stack-marker, timeout/fallback and 10,368 voice-policy fixtures pass.
- Chords: 71,411 integration cases, 19,890 CZ preset/BASS checks and
  42,553 overload checks, no failures. Other selected feature/safety tests pass.

## Memory and limits

Removed Stutter capture: 18,432 bytes in POOL. New Church reflection delay:
2,048 bytes. Net reduction of those allocations: 16,384 bytes. The previous
384-byte CPU0 pre-verb scratch is removed, along with capture bookkeeping.
Host compilation shows a 16,448-byte BSS reduction versus the preceding build
(host merges POOL objects into BSS). These are not linked FM1 memory totals.

The approved Ambient render is source-identical. Working engine sources,
HAL, loader, boot-safety document and existing golden files are unchanged.
No device flash and no legacy golden regeneration were performed.
The macOS SDL/CoreMIDI graphical app and the JL target cannot be linked here;
the shared emulator firmware/audio ISR and target C syntax are checked instead.
Final target flash/RAM, stack depth and timing need the Mac build and measurements.
Reverb preference still requires listening. No firmware package is supplied.

## Feature suite output

```text
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
edit: open part 0
edit: group OSC screen 1 lane 1 part 0
edit: group FILT screen 1 lane 1 part 0
edit: group FILT screen 1 lane 2 part 0
edit: close
PASS: SELECT opens engine filter, stays in editor on hold/knob gestures, retains performance menu outside EDIT
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: Ambient bit-exact Melodee 30000 blocks; Church stereo reflections (early energy 94530680 vs 0), bounded output/model clear; Church delay 2048 B
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: actual emulator ISR Gate silence/Off recovery, live sound
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: keys-only 231 key/style fixtures, ordinary note ownership, release, BASS/performance/latch/voicing bypass, mode-switch cleanup, v7 persistence and old-settings migration
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: Gate UI Off/On only, knob clamps/rates, 9 tempo/rate fixtures, exact bypass, stereo/smoothing, queued MIDI sync/dropout and panic
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
layer: open 6 (locked)
metro: cells Click BPM Sidechain Loop trans
PASS: SEQ KNOB3 On/Off, exact bypass, beat duck/recovery, stereo smoothing, all signatures, free-loop wraps, EMPTY/STOPPED internal pumping, real queued USB/UART clock at 20/120/300, phase restart, duplicate filtering, dropout bypass, master unchanged
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
layer: open 6 (locked)
loop transpose: +7 semitones
metro: cells Click BPM Sidechain Loop trans
loop transpose: +12 semitones
loop transpose: -12 semitones
loop transpose: +0 semitones
PASS: SEQ KNOB4/UI, +/-12 clamps, all performance modes, live retuning and bass, shared note ownership, clipping recovery, scheduled offs, unchanged loop records
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
lock: latched MAJ
lock: latched MAJ m7
lock: latched MAJ M7
lock: latched MAJ M7
lock: latched none
PASS: SELECT menu, retired scales/settings, exclusive sevenths in Simple/Advanced/Free and LOCK, exact Ping Pong/Tennis, Random, release/retrigger/pads, third protection on CZ/Prophet with BASS
Host structure sizes: chord engine 7368, chord voice 172; target sizes require device build
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: SELECT knob 2, CZ / Prophet sixth-first priority and restoration, ROSEN queue, harmony dedup, Next/Random/Ping Pong
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
popup: part 0 65 / FX TEST / CZ-1 · 65/66
rosen FX: 578 checks PASS (Next/Random/Ping Pong, On/Off, four reverb models, factory/user/cross-engine favourites, globals, BASS, manual load, automatic popup suppression/manual popup retained)
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
engine-switch queued notes: 5 (expected 5)
fixture: Prophet BASS on inversion -5 major third MIDI 52 PASS
fixture: Prophet BASS on inversion -5 minor third MIDI 51 PASS
fixture: Prophet BASS on inversion +0 major third MIDI 64 PASS
fixture: Prophet BASS on inversion +0 minor third MIDI 63 PASS
fixture: Prophet BASS on inversion +2 major third MIDI 76 PASS
fixture: Prophet BASS on inversion +2 minor third MIDI 75 PASS
fixture: Prophet BASS on inversion +8 major third MIDI 88 PASS
fixture: Prophet BASS on inversion +8 minor third MIDI 87 PASS
Chord integration: 71411 cases, 0 failures
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
CZ factory/BASS reproduction: 19890 checks, 0 failures
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
CPU overload chord protection: 42553 checks, 0 failures
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
mode 0 impulse energy 275886182
mode 1 impulse energy 123643424
mode 2 impulse energy 69353928
mode 3 impulse energy 90487344
PASS: four models, distinct impulses, size decay, bounded stress, tail silence, all model transitions, UI icons
va: load slot 3 patch crc 4292
fm6: load slot 5 patch crc bb3d
va: load slot 3 patch crc 4292
fm6: load slot 5 patch crc bb3d
va: load slot 5 patch crc 4292
cz: load slot 20 tone crc f025
quad: load slot 7 patch crc 3a02
quad: load slot 7 patch crc 3a02
va: load slot 5 patch crc 4292
objects: settings 764 (PER4 572), bank 3080, FM6 3612, VA 3536, FM6 patches 2 x 2064, QUAD 2576, loop <= 3664 bytes
cr backup tests passed: 94 checks, 0 failed
cr_trans_test: 24 checks, 0 failed
reverb: ROOM: the buses bit for bit as before SPRING (30 s of noise sends, settings changing)        ok
reverb: SPRING decay rises with SIZE: RT60 0.30 s (SIZE 0), 0.81 (64), 3.08 (127)                    ok
reverb: SPRING chirp: 1st arrival's group delay 10 8 10 16 36 137 samples (0.5 1 2 3 4 5 kHz)        ok
reverb:   the next pass more spread: 2nd arrival 0.5 -> 5 kHz 5.8 ms (1st 2.9)                       ok
reverb: SPRING at SIZE 127 DAMP 0: 2 s of full-scale noise: peak 196608, the last second 0           ok
reverb: SPRING at SIZE 127 DAMP 127: 2 s of full-scale noise: peak 196608, the last second 0         ok
reverb: SPRING at SIZE 127 DAMP 0: 2 s of a full-scale 3.2 kHz square: peak 196608, the last second 0 ok
reverb: SPRING at SIZE 127 DAMP 127: 2 s of a 416 Hz square: peak 196608, the last second 0          ok
reverb: level: SPRING's tail -2.7 dB from ROOM's (the same burst, SIZE 90 DAMP 60)                   ok
reverb: ROOM -> SPRING while the tail rings: largest step 18 (the tail's own 501), silent after: 0   ok
reverb:   and back to ROOM                                                                           ok
reverb: cost: no instruction counter on this host
reverb test passed
cr_settings: 53 passed, 0 failed
  clock: garbage range 38..300
cr_midi_test: 26 passed, 0 failed
cr_bootguard_test: 0 of 91 checks failed
cr_bootguard_test passed
ok   overwrite: a 1-bar take of 3 events plays
ok   overwrite: REC while playing stops and arms; the loop is still there
ok   overwrite: armed, the loop silent
ok   overwrite: REC again before the first chord cancels, the loop intact
ok   overwrite: armed again (stopped, a loop)
ok   overwrite: the first chord starts the take: the loop goes now
ok   overwrite: the new take replaced it (Em alone, 1 layer, playing)
ok   overwrite, 1 bar synced: REC starts the count-in, the loop kept
ok   overwrite: halfway through the count-in, still kept
ok   overwrite: the count-in's end starts the take, the loop cleared (cap 3 nev 0)
ok   overwrite: the synced take committed by itself (D, 1 bar)
ok   advance: slot 3 -> 4, 10 wraps to 1
ok   advance: over a loop (the slot jumped to), as Overwrite
ok   advance: LOOP during the count-in cancels, the loop kept
ok   overwrite: a panic while armed keeps the loop
ok   overwrite: no stuck, double or stray note
ok   replace: the take D G Ab (G at 96 for 192, A at 288)
ok   replace: REC while playing arms it
ok   replace: the chord opened the layer, G (sounding) hidden
ok   replace: G cut at 144 (a copy in the new layer, ending there)
ok   replace: A, starting inside the held span, hidden by layer 2
ok   replace: D, before the span, untouched
ok   replace: released, nothing more is erased
ok   replace: REC ends it: 2 layers
ok   replace: the record holds the live events only (D, G cut, F)
ok   replace: the next cycle plays D, G (cut), F; not Ab (1 1 1 0)
ok   undo: the layer goes, G (whole) and Ab come back
ok   undo: Ab plays again, F no longer
ok   replace again: D and G hidden while C is held
ok   undo while replacing: the layer in progress goes, D and G back
ok   replace: no stuck, double or stray note
ok   step: REC while playing stops the loop, step entry at step 1 (1/16)
ok   step: the loop stopped
ok   step: D written at step 1 (one step long), the cursor on 2
ok   step: keys up again with nothing written: the cursor stays
ok   step: Em at step 2, Ab at step 3
ok   step: OCT+ a rest, the cursor on 5
ok   step: OCT- back to 4 (nothing erased)
ok   step: REC commits the steps as the loop (the old one gone), stopped
ok   step: Free, 4 steps used: one bar (len 384)
ok   step: playback D, Em 125 ms later, Ab 250 ms (1/16s at 120)
ok   step: REC REC with nothing entered keeps the loop
ok   step, 1 bar at 1/8: 8 steps
ok   step: two presses before every key is up: both at step 1
ok   step, synced: back past step 1 wraps to the bar's last step
ok   step, synced: the cursor wraps at the length
ok   step: LOOP leaves step entry and plays the steps (2 events, the bar)
ok   step: no stuck, double or stray note
ok   free: REC arms (nothing runs until a chord)
ok   free: still armed after 100 ms of silence
ok   free: the first chord started the take
ok   free: REC again commits
ok   free: playing, 1 layer, 2 events
ok   free: 2 s at 120 BPM = one 4/4 bar (len 384 ticks)
ok   free: events D at 0, Em at beat 3 (resolved roots and qualities)
ok   free: a 500 ms chord lasts a beat (96 ticks)
ok   playback: D re-triggers every 2 s (2 ons: 3100 5099)
ok   playback: Em 1 s after each D
ok   the ring position is a fraction of the cycle
ok   voicing +1 at playback: D's lowest note moved up (D5, no D4)
ok   240 BPM: the loop cycles in 1 s (3 ons)
ok   overdub: REC while playing arms it
ok   overdub: the chord opened a layer
ok   overdub: REC ends it: 2 layers, 3 events
ok   overdub: C plays in the next cycle
ok   undo: the overdub layer is gone
ok   undo: C no longer plays, D still does
ok   undo: the first layer stays (CLEAR empties)
ok   LOOP tap: stop
ok   stop: nothing left sounding
ok   LOOP tap: play again from the start
ok   play: the event at 0 sounds at once
ok   clear: empty
ok   clear: no stuck, double or stray note
ok   sync: REC starts a one-bar count-in
ok   sync: half-way through the count-in, 2 beats left
ok   sync: recording after one bar
ok   sync: the count-in clicked 4 beats, the first accented (1 + 3)
ok   sync: still recording in bar 2
ok   sync: committed by itself after 2 bars (768 ticks), playing
ok   sync: no quantize: D 30 ms (5.76 ticks) late as played
ok   sync: D plays once per 4 s cycle
ok   quantize 1/16: a chord 6 ticks late lands on 0
ok   quantize: its note-off kept (the length grows by the shift)
ok   panic: stopped, loop kept, silence
ok   after panic: plays again
ok   stop after panic: silence
ok   panic during a take: dropped
ok   pack: header + 2 layer counts + 2 x 7 bytes
ok   unpack: the same loop back (layers kept)
ok   unpack: a bad event: refused, empty
ok   unpack: short: refused
ok   queue while playing: waits for the cycle's end
ok   the next cycle is the queued slot's (C plays)
ok   set when stopped: loaded at once, not dirty
ok   set(0): empty
ok   slots: no stuck, double or stray note
ok   a take and an overdub: dirty (the UI saves it on leaving)
ok   queued, then an overdub armed: the switch cancelled
ok   cancelled: the loop stays (no load)
ok   queued, then an undo: the switch cancelled, the undo done
ok   queued, then a stop: cancelled, kept
ok   queued, the cycle's end: taken (loads + 1), not dirty, playing on
ok   set: a load (loads + 1)
ok   switches: no stuck, double or stray note
ok   the event cap ends the take by itself (512 events)
ok   a full loop played and stopped: silence
ok   determinism: the same take, the same loop
ok   loop level 50%: velocity 100 plays at 50
ok   loop level 0: silent

cr_loop: 110 passed, 0 failed

```

## Dual-core output

```text
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
BASS CPU1: 5638 concurrent/serial cases PASS; PCM and voice/engine state identical, five engines, four reverbs, CZ and Prophet six voices with BASS and fallback; jobs=719504
audio worker: busy/offline, bounded stall, wrapping deadline and no unsafe rerun ok
CPU1 stack marker: empty, partial/full use and damaged guard PASS
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
CPU1 fallback: startup failure retains serial caps; job timeout invokes reset without replaying BASS PASS
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
loop: mode Overwrite
loop: cells Sync Quantize Count-in Level
loop: mode Advance
loop: mode Overdub
loop: mode Replace
loop: mode Step
loop transpose: +12 semitones
bpm: 137 (clock in)
metro: cells Click BPM MIDI Sidechain Loop trans
loop: save slot 10 25 bytes rc 0
loop: steps recorded (state 1 layers 1 events 1 len 384)
loop: save slot 3 25 bytes rc -1
loop: rec: play to start (state 1 layers 1 events 1 len 384)
Looper UI: 24 checks PASS; five modes, Step roots/rest/back, Advance save/wrap/failure, SEQ BPM clamps/external clock, sidechain/transpose
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
Voice split policy: 10368 fixtures PASS; 6 online, 5/4 fallback, exact tones, sixth then seventh, thirds, roots/inversions/transpose, note-offs and both budgets
PASS: target C syntax, dual-core disabled/enabled (assembly/linking still require JL toolchain)

```

## Final Gate check

```text
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: Gate UI Off/On only, knob clamps/rates, 9 tempo/rate fixtures, exact bypass, stereo/smoothing, queued MIDI sync/dropout and panic

```
