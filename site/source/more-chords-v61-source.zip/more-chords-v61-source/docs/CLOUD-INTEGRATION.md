# Cloud integration — Orbit 0.7.1

Source: user-supplied orbit-0.7.1.zip, archive commit c07bd1d87dcb1e90180d1765d96b834c3dc68479. Imported firmware/src/eng_cloud.c and the fixed-point pitch-ratio helper from eng_sample.c, both GPL-3.0-only. Existing GPL license and source distribution apply; no Orbit assets, samples, CLUSTER/Teenage Engineering tables, fonts or icons imported.

Upstream Cloud is oscillator-source granular synthesis, not recorded audio. Eight original factory patches and eight controls are retained. Remix uses the shared sine table to evaluate its Hann window, instead of pulling in the retired sample-grain engine's separate window table.

Original allocation: 12 grains shared across at most three voices. Remix: two private grains per voice, six chord voices, at most 12 grains total. This deliberately reduces the maximum per-note overlap versus upstream (which could allocate four grains per note with three notes, or twelve for one note). It is not an acoustically identical port. Voice-private RNG and grain slots prevent CPU0/CPU1 data races and preserve deterministic serial/worker PCM/state. Four chord kernels run on CPU0, two on CPU1. Each voice reserves three budget units conservatively. Bass remains on CPU1 using another engine. Cloud is blocked from Bass and excluded from Morph.

Runtime cloud_part_t is 1088 host bytes and fits within the existing FM6 state union (6884 bytes), so no separate DSP pool is allocated. No heap, floating-point DSP or new audio sample buffer. Native envelope, velocity, common effects, MIDI and sequencer use Remix's existing path. The new engine is stable ID22; retired CS-1 ID21 stays reserved. Presets use the ordinary 192-byte USER record, without a new storage format.

Six-note chords, overlapping chord changes, raw keys, USER saves and direct/collection/Bass restrictions have dedicated host fixtures. Target CPU timing, flash/RAM budget and real audio require a fresh Mac/device build. Host tests do not establish hardware timing or click-free operation.

Original engine SHA256: 7088deb6e4c195be7b68fe28acdc237536c5635d55b4d6dc00b0cd07ffafa3aa

## Completed host validation

- 224 serial/CPU1 PCM and state comparisons: eight Cloud presets, seven other Bass engines, four reverb modes; six chord voices and two dispatched worker kernels.
- 200 overlapping chord fixtures across all presets, major/minor, inversions, rapid retriggers, shared-note releases and raw keys.
- 23 Cloud Bass restriction cases covering factory, USER, favourites, collection, load/init/switch/editor and stale saved references.
- 14,942,208 native DSP samples under UBSan: all presets plus min/max panels, MIDI notes 0..126 in seven-semitone increments, output canaries and grain bounds.
- Editor page labels and all eight knobs, engine order, retired CS-1 policy.
- Existing 5,638 dual-core PCM/state fixtures and Remix step/USER/keys-loop/Bass/30-loop storage tests passed.
- Web/Python factory binding matches the firmware; web sounds tests passed. Whole firmware syntax checked with dual core both off and on.

No target compiler/device run was available here. These are host results, not CPU budget measurements.

## V20 update

The per-voice limit is now three (18 total for six notes); normalization includes 18918 Q15 for three-way overlap. The two-grain description above documents the V18/V19 baseline. The private-state and 4+2 architecture is unchanged.
