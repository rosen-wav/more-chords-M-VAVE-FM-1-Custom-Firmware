# ChoralRoot Remix — Creative tools

This complete source build extends the MIDI shared-lock Remix build. CPU1 remains enabled by default, Prophet/CZ rendering and the gate-only effects menu are preserved. It contains no newly built FM1 firmware package: test in the emulator, then build on the Mac before considering installation.

## Preset Randomizer

While editing a preset, **hold REC** to open Preset Randomizer. This hold was unused in the engine editor; a short REC tap still opens MIX. The tool opens for the edited Chords/Bass part and leaves the current editor section, screen and lane intact. It is no longer listed in global Settings.

| Control | Action |
| --- | --- |
| Knob 1 | Amount, 0–100%; default 40% |
| Knob 2 | Current edited part, read-only |
| Knob 3 | Generate and audition another variation |
| OCT+ | Confirm the variation and return to EDIT |
| Knob 4 | Undo to the original sound |
| SAVE | Available after OCT+ confirmation; ordinary Overwrite / Save as new |
| OCT- / HOME / EDIT | Cancel the candidate and return to the same editor page |

Turning Generate flashes **Preset generated**, with no roll numbers. Audition the sound and press OCT+ to confirm. Leaving without confirmation restores the original patch; no save dialog can write an unconfirmed candidate. Undo shows **Restored**.

Each roll starts from the original captured patch, rather than accumulating changes. Changing the loaded sound starts a new baseline. Amount zero preserves every patch parameter. Variations are bounded and preserve oscillator/pitch selectors, routing, release targets and disabled level controls. FX sends, part volume and voice mode stay unchanged. Rolls stop the selected part's current notes; play a new note/chord to audition the result. No preset is written until you save it.

All engines in this build are supported, including native FM6, VA, QUAD, CZ-1, Prophet and BASS. For Morph itself the randomizer varies Position, Speed and Amount, keeping its two chosen patches. USER patches use the existing native storage paths. Monophonic engines now retain their mono setting when a USER preset is loaded on the chord part.

## Chord Ideas: hold REC

**Hold REC** in the SEQ menu or step sequencer to open Chord Ideas. Outside SEQ, holding REC restores the previous Undo-layer action. A short REC tap does not open it. In the preset editor, REC hold retains its separate Preset Randomizer action. PLAY auditions the candidate, OCT+ applies it in RAM and opens the step editor; nothing is automatically saved. SEQ controls for Click, BPM, Sidechain and Loop Transpose stay in their existing menu.

| Control | Action |
| --- | --- |
| Knob 1 | Tonic C–B |
| Knob 2 | Major / Minor |
| Knob 3 | Pop, Classic, Journey, Circle, Dream, Surprise or Jazz |
| Knob 4 | Generate another idea |
| SELECT wheel | Browse the four generated chords, with full quality/extension names |
| PLAY | Audition / stop the candidate, before replacing the current sequence |
| OCT+ | Use the idea and enter the step editor immediately |
| REC / OCT- / HOME | Cancel and return to the previous HOME/SEQ context |

The screen previews all four chord names and brackets the chord currently auditioned. Structured patterns retain their degree order; Surprise randomizes the other three degrees after the tonic. Generated ideas use the selected 1/2/4/8-bar length (Free falls back to two), equally spaced sustained chords and the quarter-note grid in 4/4.

Audition pauses the existing loop transport but preserves its contents and dirty flag. It uses the selected chord/bass presets and current performance/FX, and repeats on the master clock. Internal PLAY starts at the next quarter; MIDI clock waits for a valid boundary, with USB/TRS Start/Stop handled for the candidate. PLAY cancels a pending audition too. Changing the idea or leaving the page stops its notes. Recording, a pending loop load or a queued SAVE prevent opening a conflicting candidate.

OCT+ stops audition, transfers the candidate into the editable sequence in RAM and leaves playback stopped. **Nothing is saved to a loop slot automatically.** Use PLAY to hear the edited sequence and ordinary SAVE when you decide to keep it. Cancel keeps the old sequence in RAM; press PLAY on page 1 to resume it.

## Morph between two patches

Morph remains chord-only and uses a single source renderer. Choose two **factory** patches from the same eligible engine. The selectors refer to the original compiled factory patches; USER sounds and saved factory overrides are not endpoint sources in this version.

| OSCILLATOR control | Action |
| --- | --- |
| Knob 1 | Source engine |
| Knob 2 | Patch A |
| Knob 3 | Patch B |
| Knob 4 | Manual / Up and Down / Random |

| MORPH SETTINGS control (LFO page) | Action |
| --- | --- |
| Knob 1 | Travel time, 100 ms–8 s; default about 2 s |
| Knob 2 | Amount, 0–100%; default 100% |
| Knob 3 | Random trigger: Free / Chord |
| Knob 4 | Position, A at 0% / B at 100%; turning it selects Manual |

Eligible sources in the standard build: FM6, QUAD, VA, PHASE, LOFI and VOICE. BASS, CZ-1 and Prophet remain excluded from Morph.

Manual takes about 100 ms for a full traversal. A smoothstep interpolation curve reduces parameter velocity at both endpoints. Up and Down travels continuously between the endpoints. Random chooses new positions continuously in Free mode, or once for each new semantic chord in Chord mode; arpeggio subdivisions and voicing edits do not retrigger it. Speed controls one complete traversal, not a whole up/down cycle.

Amount scales distance from A. At Amount 100, both endpoints reproduce the corresponding native factory patch; at Amount zero, the result stays exactly A. Continuous parameters interpolate. Discrete modes, algorithms, wave selectors and tuning choices switch near the midpoint with a small hysteresis band. The renderer blends a short fragment of its previous stereo output into the new output over 20 ms, with a smoothstep curve and an initial value/slope matching search. Manual position changes travel over 200 ms. There is no deliberate volume dip to zero. This is a short audio-history overlap, not simultaneous sustained rendering of both patches: strongly different algorithms or oscillator modes can still sound different around the transition. Exact settled endpoints and zero Amount retain their native PCM. History occupies 8220 bytes in the pool on the host; device memory and realtime timing must be checked in the Mac build. Reverb/delay tails remain outside this overlap. FX sends/master settings are not copied from the endpoint presets.

The complete native VA/QUAD patches, including parameters hidden by dynamic editor pages, are used without editing QUAD's DSP source. There is one renderer and one voice state per note, rather than twice the voices. Morph configurations retain A/B, amount, speed and mode in the existing 192-byte USER records. Old single-patch Morph presets migrate with B initially equal to A: choose a second patch to get movement. The former randomized endpoint sound is not preserved by this migration.

## Keyboard in menus

Settings and the engine picker now leave the keyboard in its normal performance mode, including chord modifiers and Just Keys. White-key menu shortcuts no longer consume those notes; use the encoders to navigate. The legacy root-picker preference is ignored for key routing, without changing the settings record layout. Existing loop-slot, naming and performance-pad keyboard actions elsewhere are unchanged.

## Verification and limits

Run on the Mac:

```sh
cd "$HOME/Downloads/Choralroot-remix-creative-listen"
source "$HOME/.venv/bin/activate"
sh tests/run_creative_tests.sh && sh tests/run_morph_tests.sh &&
sh tools/emu/build.sh && build/host/emu --no-midi
```

Host checks cover all factory A/B native PCM endpoints, bounded moving morphs, CPU1/serial audio and state equality, randomizer/Undo fixtures, native USER save/reboot, tonal ideas, packed loop records and apply/cancel/transport guards. Existing Remix, MIDI, audio019 and CPU1 regression scripts are included.

No flash operation was run. `firmware/src/eng_quad.c` and legacy golden audio are unchanged. The new host structural state adds approximately 284 bytes of pool storage and 32 bytes of control state over the preceding build: the progression generator reuses the existing loop staging buffer. This is a source-level comparison, not a target linker result. New code size, target stack use and timing under maximum hardware load remain to be measured by the Mac device build and FM1 tests.

The previous Mac build had XIP 503784/573440 bytes, RAM 88472/98304 (guard 88484), pool 319296/344064. These are baseline numbers, not validation of the new image. Existing DSP arithmetic sanitizer findings outside these changes are recorded in the validation notes; no general sanitizer-clean or brick-free claim is made.

### Jazz harmony

All progression patterns now use bounded harmonic colors: major/minor, suspended dominant and diminished chords with 6, minor 7, major 7 and 9. Typical results include C6, C6/9, Cmaj7, Cmaj9, Dm7/Dm9, G7/G9, Gsus7/Gsus9 and Bm7b5. Diminished triads are also possible. Minor tonic colors include m6 and m(maj7)/m(maj9); the minor-key V borrows its major third for a dominant resolution. Major-key iii avoids a non-diatonic natural ninth.

The **Jazz** pattern follows ii–V–I–vi (ii half-diminished / V dominant / i / VI in minor). Each generation varies the chord colors while retaining the pattern's roots. Minor and major sevenths are mutually exclusive and at most two extension notes are added: three to five notes per chord. Existing full-chord recording, voicing, audition, Bass, OCT+ apply and SAVE behavior are preserved.

The Ideas picker displays complete chord names individually, avoiding truncation of a four-chord extended-name string. SELECT browses the candidate while stopped; during PLAY the selected chord follows the sounding step.
