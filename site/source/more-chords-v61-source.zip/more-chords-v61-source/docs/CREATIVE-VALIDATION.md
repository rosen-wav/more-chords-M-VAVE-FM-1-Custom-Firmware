# Creative build validation

Editor placement update: REC hold opens Randomizer for the current edited part; REC tap MIX is preserved. Host checks cover actual scanned hold/release, same-page return by OCT-/HOME/EDIT, and SAVE returning to the editor. Global Settings no longer contains the randomizer.

Validation applies to the source build in this folder. Hardware flash, target linking and real-time performance were not tested here.

## Passed host checks

- `run_creative_tests.sh`: 3555 engine/preset/part/Amount fixtures, exact parameter/native Undo, 720 tonic/mode/pattern/length progressions, native USER save and simulated reboot for FM6/VA/QUAD/CZ/Prophet/BASS/Morph, screen/control routing, staging, cancel/apply, recording/transport guards.
- `run_morph_tests.sh`: 81 native factory fixtures, bit-exact A at zero Amount and B at full Amount from the first note, full native parameter endpoints, moving parameter bounds and PCM guards, releases, Manual and Up/Down audible differences, new-chord deduplication, 36 concurrent CPU1/serial PCM/native-state comparisons, packed B/seed roundtrips and old single-patch migration, two editor pages and Bass rejection.
- `run_remix_tests.sh`: step entry/transport/sustain/playhead/timing/delete, Simple quality/extensions, Prophet USER 1212 fixtures, Prophet Bass 819 fixtures, keys-loop Bass 10080 fixtures, 20-loop storage 135 fixtures, 12000 grid edits, Python/web 38-object backups.
- `run_audio019_tests.sh`: sync/persistence 804 fixtures, 68119 output/USB/gate/sidechain fixtures, 54 settings checks, clocked pending PLAY and existing record migration.
- `run_midi_perform_tests.sh`: original Perform cases, 109 chord-control fixtures, 4776 black/white base cases and shared FM1/USB/TRS LOCK.
- `run_dualcore_tests.sh`: 5638 concurrent/serial engine cases, 160 Bass combinations, mailbox/deadline and private stack tests, 24 looper/BPM UI checks, 10368 voice-split policy fixtures, target C syntax with CPU1 disabled/enabled.
- QUAD DSP source is byte-identical to the supplied shared-lock archive (SHA256 `4b3dc4767fa974b75474f7a2b3bde509f89a3958f8c8a1415ec782ec6a6fca3d`). All 17 archive files whose paths include `golden` are unchanged; no golden regeneration was performed.

## Memory evidence

Host `sizeof` measurements: preceding Morph runtime 6064 bytes, new Morph runtime 5976 bytes, new randomizer pool state 372 bytes, progression control 12 bytes and audition control about 20 bytes. Thus static pool state changes by about +284 bytes, with about +32 bytes of controls outside the pool. Progression data reuses the existing loop staging buffer; there is no additional sequence buffer or second synth renderer.

These measurements support the design estimate only. JieLi ELF/map size and stack/timing checks must be rerun on the Mac. The preceding target build's pool/flash/RAM results are not a pass for this new build.

## Sanitizer limitations

A full undefined-behavior diagnostic run reaches the Morph test PASS but reports existing signed shifts in FX/QUAD/PHASE/LOFI/VOICE/FM6 and signed multiply overflow in `dsp.c`. Those unrelated DSP paths were not rewritten. An AddressSanitizer run could not complete because LeakSanitizer cannot inspect process threads in this execution environment. The focused creative-tools undefined-behavior check with signed-shift/overflow checks excluded also reaches PASS without other runtime findings. This build is not described as generally sanitizer-clean.

## Next checks on the Mac / FM1

1. Run the two new scripts and the emulator as shown in `docs/CREATIVE-TOOLS.md`.
2. Build using `CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh`, and inspect all image/RAM/pool/stub/CPU1 guards.
3. Run the existing transporter shim, hash the exact new package and query the device before any installation.
4. On hardware, audition contrasting Morph patches and rapid transitions under maximum FX/Bass load. Check audio lateness, shedding, CPU1 timeouts and stack watermark deltas. Successful host rendering does not establish the target's worst-case deadline margin.

## Menu / listen update

- 162 live key-routing fixtures across Settings and both engine-selector contexts, including both legacy root-picker values; modifier ownership/release also verified.
- Real PCM audition of all four candidate chords through a complete cycle; original sequence/dirty flag preservation, PLAY toggle/pending cancel, new generation, apply/cancel and stale queued requests.
- USB/TRS clock boundary, MIDI Stop and Start handling for audition.
- 26 discrete Morph switches verified at zero rendered gain, sample-by-sample stereo ramp bounds and exact settled A/B endpoints. All 81 endpoint fixtures and 36 CPU1/serial comparisons still pass.
- Randomizer text feedback without a counter, green highlight, OCT+ confirmation, cancel restoration, blocked unconfirmed SAVE, Undo and timeout verified; UI rendered for inspection.
- Remix, MIDI, Audio019 and CPU1 regression scripts pass. Target C syntax passes with CPU1 disabled/enabled; no JieLi link or hardware flash was performed.

Randomizer state is now 368 bytes on the host (four fewer than the preceding build); the roll counter has been removed. Morph and audition state are unchanged. The candidate reuses the existing staging buffer. These are source/host structure measurements; actual target sizes and deadlines require a fresh Mac build.
