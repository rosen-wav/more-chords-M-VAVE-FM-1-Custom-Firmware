# Native CS-1 integration

## Provenance and scope

Source: the user-supplied CS-1-main.zip. Native voice/application author: twochannels. Fixed-point building blocks derive from Felucca, Copyright (C) 2026 Leo Kuroshita / Hügelton Instruments. GPL-3.0-only; upstream licence, attribution and exact reference inputs are retained under `integration/cs1/`. `SOURCE.json` records their hashes.

The port reuses the native voice model and 52 factory recipes assembled from 24 panel tones. It does not replace Remix hardware support, USB, MIDI, CPU worker, looper, settings, updater or recovery code.

## Audio and controls

`cs1_native.h` contains the prefixed fixed-point DSP. `eng_cs1.c` adapts note/gate/velocity/pressure and control-rate pitch to Remix. Both channels have independent resonant 12 dB high-pass/low-pass filters, filter and amplitude envelopes; the native LFO, ring modulator, drift, automatic aftertouch, chorus and tremolo remain available.

The default native tone rolloff is fixed to the upstream default 100. Native delay, phaser, reverb/shimmer DSP and ribbon/split/standalone clock controls are not imported: use Remix's existing effects, MIDI bend and performance controls instead. Factory delay/reverb mix values initialise the corresponding Remix sends; timings and reverberation algorithms therefore differ from the standalone instrument. Unused standalone patch fields are retained in the native blob but do not run DSP. The native I/II editor, rather than generic FM envelopes/filter macros, controls the voice.

Remix invokes 32-frame control blocks at its existing engine rate. The source render's eight-tick block becomes one tick; automatic-aftertouch ramps, initial pitch-bend decay and drift rates are adapted accordingly. The chorus delay ring is 1024 samples (still larger than its maximum approximately 22 ms tap), versus 2048 upstream. Signed-shift arithmetic and potentially overflowing multiply accumulations in the imported DSP use defined/widened arithmetic. Mid/side conversion follows Remix's left-minus-right convention.

## Scheduling and memory

CS-1 is appended as stable engine ID 21 in the full Remix configuration. It is outside `MORPH_SOURCE`. Its heavy-engine allocation follows CZ/Prophet/KR106: reserve two independent chord voice slots on CPU1, then render Bass there; render the other chord slots on CPU0. Prepared modulation/noise arrays and the patch are read-only during the job; each voice state belongs to one renderer. Chord post-processing happens after the worker completes. Bass has a separate part context and post-processing state.

A compile-time assertion requires `cs1_part_t` to fit `fm6_part_t`. Measured host sizes are 5552 versus 6884 bytes; the union's allocation is unchanged. Four 102-byte patch copies add 408 bytes in POOL. Two four-byte flag arrays add eight bytes. This is not a target XIP/RAM/POOL/stack report. Native six-voice timing, especially with CS-1 or another heavy Bass plus effects, must be measured on FM1 before concluding it meets deadlines.

## USER format

Existing USER records stay 192 bytes and banks stay 3080 bytes; there are no new flash objects or erase regions. CS-1 uses record version 6:

| Record region | Contents |
| --- | --- |
| Header and name, bytes 0–15 | Existing header, engine 21, current parameter count, name |
| Packed bytes 0–101 | Complete native 102-byte patch |
| Packed bytes 102–142 | 41 common controls, order in `UP_CS1_COMMON`, encoded value + 64 |
| Packed byte 143 | Original factory recipe index, 0–51 |
| Note/flag tail | Existing patterns or factory binding metadata |

The common controls cover level/voice/glide/allocation/pan, shared LFO and matrix, FX sends, slicer/transpose/envelope modulation. Native envelopes live in the patch. Track-owned arp, chord/voicing and pattern controls remain the destination track's, as on an ordinary Remix sound load.

Both firmware and Python/browser librarians validate the new format and preserve its bytes in sound-file export/import. USER overwrite, bound factory override, rename and reload retain the native patch. Other engines retain their existing versions. Older firmware/librarians do not understand version 6: CS-1 records appear unavailable there. Do not use an older client to edit a CS-1 sound.

## Verification boundaries

`tests/run_cs1_tests.sh`: 52 recipes across eight Bass engines, real concurrent-worker versus serial PCM/state, CS-1 Bass with other native engines/Morph, CS-1-only audibility, 104 native USER overwrite/reload fixtures, all native UI screens, malformed patch rejection, offline caps and both firmware syntax configurations. `cr_cs1_dsp_test.c`: full native voice plus output stages, factory and extreme/random controls, unrestricted UBSan for these imported DSP routines. Librarian tests exercise version 6 import/export and invalid enums.

The inherited Morph audit also includes CS-1 Bass (36 total source/Bass cases); its UBSan configuration still excludes legacy QUAD `shift-base`, without changing QUAD. Host recovery tests are models, not a test of physical interrupted installation. The actual FM1 target build, hardware audio deadline/stack/USB/MIDI checks and listening tests remain outstanding.
