# Stage24: chord voices and BASS on CPU1

This complete tree includes the preceding custom features: Prophet, QUAD v3, rosen with preserved FX, swag Ping Pong/Random/Tennis, exclusive sevenths, retired scales, four reverbs, loop transpose and clocked sidechain. It extends whole-BASS rendering adapted from the supplied ChoralRoot FM1 0.14 sources with two CZ-1/Prophet chord kernels on the same worker. No new target firmware has been built or flashed here.

## Build

CPU1 is opt-in: `CHORALROOT_DUAL_CORE=0` by default. On the Mac with the JL toolchain:

```sh
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh
```

A failed build may leave an older package: never install it. Review the successful build's memory and CPU1 checks first. Rebuild with `CHORALROOT_DUAL_CORE=0` to return to serial scheduling and the previous voice limits.

## What runs where

CPU0 handles events, voice allocation, modulation setup, part-wide engine work and shared LFO random draws. For CHORD on CZ-1 or Prophet it prepares all voice modulation before dispatch. CPU1 renders the first up to two prepared voices into separate PCM buffers, then the BASS track. CPU0 renders the remaining voices simultaneously. Join precedes summing PCM in the original voice order and mixing parts; effects/master remain on CPU0. Each kernel owns one distinct voice/DSP state; track and patch values remain read-only. FM6 and QUAD main tracks retain whole-BASS scheduling; their main voices are not split. Engine crossfades temporarily retain whole-BASS scheduling so old parameter restoration remains serial.

CZ-1 and Prophet support six chord voices when CPU1 is online. Prophet reserves six distinct states in a dual-core build; offline its cap remains five. Its voice charge stays three units. CHORD CPU0 accounting subtracts up to two rendered voices, and BASS CPU1 accounting conservatively reserves two main voice charges before allocation (six units for Prophet, four for CZ). Parts 2/3 remain on the CPU0 budget. Both budgets are still 16 units. Serial CZ-1 remains five voices; serial Prophet five without BASS/four with BASS. Reducing a generated chord drops sixth, then seventh, then fifth, preserving root/third and degrees across inversions. CPU overload shedding stays enabled. These units are allocation estimates, not measured CPU time.

The per-voice plan (modulation and private PCM) adds POOL storage; target totals must be checked in the new build. No delay/reverb buffers or larger stacks are introduced. The console `cpu` and `status` include `cpu1_chord_kernels`: a rising count while CZ-1/Prophet plays confirms submitted chord kernels completed on CPU1. Job/timeout/stack and audio late/shedding counters remain available.

## Stack measurement and fault handling

The existing 8192-byte POOL reservation is retained: 4096 bytes user stack plus 4096 bytes exception/supervisor stack. Both are filled with C1MK before launch. The console `cpu`/`status` reports `cpu1_stack_bytes` and `cpu1_exception_stack_bytes`; GEEK OUT shows CPU1 state and user-stack usage. Values estimate the deepest touched word since launch, not current stack occupancy. A write identical to the marker can escape this estimate. Host runs cannot measure target stack depth.

The bottom marker guards of both stack regions are checked after each completed job. A damaged guard triggers a reboot. Hardware stack bounds retain the combined-stack protection. The high-water scan runs with the audio IRQ disabled and the worker idle; the UI samples it at most once per second.

Startup: CPU1 stopped before initialization, RAM polling code copied before release, mailbox written before top-of-RAM lock, PC range guard armed after ROM handshake. SAFE MODE skips CPU1 launch. The new `BS_CPU1` breadcrumb identifies startup failures. No handshake within 10 ms: hold CPU1, continue serially. A running job exceeding 10 ms: stop CPU1 and reboot, never replay partially modified state. CPU1 is held before reset, updater and ROM bootloader entry. Only one outstanding job is permitted; the mixer joins before effects, events or flash access.

Linker assertions and target build checks keep polling code in RAM, reserve exactly 8192 bytes for stacks, and prevent overlap with CPU0 stacks. They do not establish brick immunity. The upstream boot stub is a design, not an implemented recovery mechanism; it is not introduced here. Hardware boot, stack depth, worst-case load, flash saving and update/recovery remain unverified.

## Looper controls

Hold LOOP. ALGORITHM selects Overwrite / Advance / Overdub / Replace / Step. PRESETS selects the slot when not recording. The four knobs retain Sync / Quantize / Count-in / Level. SELECT retains the previous length/action picker; the stopped menu's roots still select slots. During Step the roots play chords instead.

- Overwrite: REC arms a replacement; cancelling before the take starts keeps the old loop.
- Advance: REC over an existing loop stops it, saves its current slot, wraps to the next slot (10 -> 1), then arms a fresh take. A failed save keeps the current loop and slot; SAFE MODE refuses this save operation. Existing contents of the next slot remain in flash until the new take is saved. A cancelled fresh take does not erase that slot's stored record.
- Overdub: add a layer; undo removes the latest layer.
- Replace: replace the span you play; undo restores the hidden previous events.
- Step: one chord per quantize step; last root release advances, modifier edits do not. OCT+ inserts a rest, OCT- moves back, REC or LOOP commits. MIDI roots use the same event path.

The record mode is a session setting, defaulting to Overwrite at boot. Existing settings and loop record layouts remain readable; no new settings format is introduced. Slot saving otherwise retains the previous explicit SAVE workflow. SEQ hold has internal BPM (20..300, one BPM per encoder step) on knob 2. With MIDI Clock In this cell shows the received BPM as "BPM MIDI" and is read-only; the existing USB/UART follower owns tempo. Knob 1 retains click volume; SEQ has sidechain on knob 3 and loop transpose +/-12 on knob 4. SELECT opens a shared swag / rosen menu: KNOB 1 selects swag Off/Ping Pong/Random/Tennis; KNOB 2 selects rosen Off/Next/Random/Ping Pong. HOME/OCT- returns. GLOBAL no longer opens rosen. Automatic rosen sound changes preserve the current overlay and do not display a preset popup; manual selection keeps its popup.

## Validation

`sh tests/run_dualcore_tests.sh`: actual pthread-concurrent chord/BASS rendering through the mixer, serial/concurrent PCM and state comparisons, five engine combinations, four reverbs, all CZ/Prophet chord presets, one-to-six chord voice counts, release/retrigger, six-tone chords with BASS through inversions, serial fallback, worker counter wrap and partial-job timeout, stack marker/guard checks, target C syntax with the option off/on. Host timing uses a relaxed timeout to tolerate OS scheduling; it does not prove the target 10 ms deadline or memory coherency.

`sh tests/run_new_features.sh`: existing serial feature regressions and upstream extended looper tests. `tests/cr_loop_modes_ui_test.c` checks actual UI binding, Step and Advance failure behavior. No runner flashes or regenerates golden audio. Target assembly/linking requires the unavailable JL toolchain.

`firmware/src/eng_quad.c` and legacy golden assets remain unchanged. The detailed test results are in VALIDATION-VOICESPLIT.txt.
