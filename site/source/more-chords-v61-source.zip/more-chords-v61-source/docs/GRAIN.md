# GRAIN in more chords! V55

See [V55-TECHNICAL.md](V55-TECHNICAL.md) for this integration and its limits, and [GRAIN-UPSTREAM-025.md](GRAIN-UPSTREAM-025.md) for the attributed upstream design/history. Upstream resource statistics and hardware validation describe upstream versions, not this remix.
