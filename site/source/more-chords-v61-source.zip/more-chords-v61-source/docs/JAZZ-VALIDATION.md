# Jazz ideas validation

- 840 progression/loop-length/tonality/tonic fixtures, exact event preservation through loop packing.
- 13,440 actual semantic chord/preview fixtures: independent 1/3/5 interval oracle, 6/7/M7/9 extensions, all generated qualities, suspended ninth coverage, minor-major seventh and diminished triad coverage, three-to-five-note cap, exclusive sevenths, native chord names and exact OCT+ application into the step sequencer.
- 4,845 randomizer fixtures, native USER/Undo/confirmation safeguards, live menu keys, internal/USB/TRS audition clock/transport, unchanged original sequence on cancellation.
- Target C syntax passes with CPU1 disabled/enabled.
- Full extended names use a four-item picker with SELECT browsing and live PLAY selection; rendered UI inspected.
- Ideas control state remains 12 host bytes: the browsing byte occupies existing padding. No new audio buffer or renderer.
- Native DSP, voice allocation, boot/recovery, QUAD and golden-related files remain byte-identical to the preceding ZIP.

Logs: build/host/jazz-creative.log and jazz-harmony.log. Target linking, memory guards and device behavior remain to be checked on the Mac/device.
