# no chords, just keys

Options > no chords, just keys (after Split Point): Off / On. Default Off, saved across restarts.

On makes every physical keyboard key play its chromatic note, including the former quality/extension and LOCK keys. LOCK is a momentary note, not a latch. Live chord inversion (including swag), automatic BASS, performance generators and note latching are bypassed; their settings are retained for returning to chord mode. Transpose, velocity, preset selection and master effects remain available. rosen does not change the preset for single-key gestures in this mode.

Changing the mode releases current note owners and scheduled notes. Lift and press keys again after switching. Turning Off restores chord operation; press the chord modifiers again. Existing recorded loops and chord pads retain their stored musical content.

Persistence uses settings v7 with the same 192-byte record size, repurposing a retired scale byte. Versions 1–6 migrate to Off, so an old scale switch cannot activate this mode.

Validation covers all three play styles across MIDI notes 24–100, concurrent key ownership, note release, modifier inhibition, automatic BASS/performance/latch/voicing bypass, mode-switch cleanup, persistence and legacy migration. FM1 target memory and timing still require a device build.

The physical-key regression now covers every keyboard key, including all former modifiers and LOCK, on both press and release. Entering this mode clears the LOCK indicator/latch.
