# KR106 UI/workflow validation

- 471 native KR106 fixtures and 512,000 standalone UBSan DSP samples pass.
- Prophet/KR106 display order, all seven native editor pages, native ADSR sustain data and DCO band checked.
- Creative suite: 4,845 randomizer and 720 progression/storage fixtures pass; native Undo and USER save/reload preserved.
- Confirm/cancel tests verify text feedback without roll numbers, blocked unconfirmed SAVE, OCT+ acceptance, HOME/OCT- restoration, incoming preset changes, short REC versus hold REC for HOME Undo and SEQ Ideas, PLAY audition and OCT+ apply.
- Morph and Remix sequencer/storage/timing regression scripts pass. Target C syntax passes with CPU1 enabled and disabled.
- OSC, ADSR and Randomizer screen previews rendered and visually inspected.
- Native KR106 DSP, mixer, voice allocator, QUAD source and 17 golden-related files are unchanged from the previous KR106 ZIP. No firmware linking, device flash or golden regeneration performed.

Evidence: build/host/kr106-ui-*.log. Hardware timing, target image/RAM checks and device UI behavior still need the Mac build and device trial.
