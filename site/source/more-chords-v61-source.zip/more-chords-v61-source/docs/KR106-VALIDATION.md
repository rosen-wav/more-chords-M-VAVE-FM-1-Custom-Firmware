# KR106 host validation

- 471 KR106 factory/concurrent-render/native USER fixtures: serial and CPU1 PCM/native state identical; all 129 selectable sounds; BASS, Prophet and KR106 Bass; reverse CZ/Prophet chords with KR106 Bass; generated major/minor six-note chords across -3..+5 voicings; native overwrite/reload and both parts; invalid patch rejection and offline caps.
- All seven native editor pages build and their first knob reaches the native parameter. VCF page was rendered and visually inspected.
- Native DSP alone: 512,000 samples under UBSan with no reported undefined behavior after fixing signed shifts and the peak-follower multiplication overflow. This is scoped to imported native DSP, not legacy engines or the full firmware.
- Creative tools: 4,845 randomizer fixtures, 720 progression/storage fixtures, native USER saves, 162 live menu-key cases and candidate audition transport.
- Morph: unchanged eligible source list; 81 patch-pair/source fixtures and concurrent/serial comparisons pass.
- Sequencer, Simple playstyle, Prophet USER, keys-loop Bass, 20-loop storage and 12,000 timing-edit stress cases pass.
- Audio settings and clock transport: 804 sync/persist cases, 68,119 audio integration checks and 54 settings checks pass.
- External MIDI perform/base/shared LOCK suites pass.
- Existing dual-core rendering, private stacks, worker deadline/fallback and split-policy tests pass.
- Native sound catalogs in the Python and web clients match firmware factory names and indices.
- Transporter shim unit tests pass; no new fwsc exists here, so this does not validate a KR106 device package.
- Target C syntax passes with dual core both disabled and enabled, including incompatible-function-pointer checks for the enabled build. Target assembly, linking, memory guards and hardware timing have not been run here.
- QUAD source and 17 golden-related files are byte-identical to the base ZIP. No hardware flash or legacy golden regeneration performed.

Evidence: `build/host/kr106-*.log`. The target build and physical device remain the authority for image layout and realtime performance.
