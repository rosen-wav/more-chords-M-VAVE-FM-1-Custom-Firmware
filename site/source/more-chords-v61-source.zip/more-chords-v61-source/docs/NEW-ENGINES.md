> Current V42: GRAIN FORMANT is retired. DRIFT and WAVE TERRAIN have additional SEL controls; see README-V42.md. The design history below describes V39.

# Original embedded engines: design and limits

These are original C implementations in `firmware/src/eng_novel.c`, not compatible ports of the reference projects. Existing project licenses/notices are retained. The new implementations and tables are GPL-3.0-only, consistent with the project. No reference code, phoneme data, binary waves or audio samples were copied.

## DRIFT (stable engine ID 25)

Five phase accumulators read 128-point harmonic-limited saw tables. Six spectral bands contain 1/2/4/8/16/32 harmonics; band selection follows each oscillator's frequency. Shared tables occupy 1536 bytes. A central oscillator stays present; Density blends four side oscillators with normalized gain. Spread controls their asymmetric separation. Drift drives five independent random targets, smoothed in Q16 at control rate, and small phase offsets. Tone is one bounded low-pass per voice. No oscillator allocation or per-sample random generation.

Reference concepts: supersaw, detune lookup and phase drift in Graham James Keane's UberSaw (Korg NTS-1/logue-sdk, MIT):
https://github.com/GrahamJamesKeane/UberSaw

Also studied: house-of-houses/ubersaw (Daisy, MIT), a different seven-saw fixed-point implementation:
https://github.com/house-of-houses/ubersaw

Neither project establishes PI32V2/FM1 compatibility. DRIFT is not claimed to reproduce a JP-8000 or either reference instrument.

## WAVE TERRAIN (stable engine ID 26)

Four original periodic surfaces are stored as 16×16 signed16 grids: 2048 bytes total. A note advances a 2D circular/elliptical trajectory; Orbit changes its geometry, Motion advances a separate slow orbit, and Depth sets translation. Surface lookup uses four samples and bilinear interpolation. A one-pole DC estimate removes trajectory-dependent offsets. Higher notes transition to the fundamental sine to reduce aliasing while preserving played pitch. Terrain selection is discrete in this first version.

Concept reference: Aaron Anderson's Terrain, GPL-3.0, a JUCE-based wave-terrain synthesizer:
https://github.com/aaronaanderson/Terrain

No JUCE, glm, Perlin Noise, surface formulas or code from that project are embedded. The surfaces here are simple original trigonometric combinations generated offline by `tools/enginegen/generate.py`; runtime never computes trigonometric functions.

## GRAIN FORMANT (stable engine ID 27)

Two raised-cosine packets repeat at played pitch, half a cycle apart. Density blends the second packet; Grain smoothly changes packet width, with a fixed maximum of two. Each has **two** sine formants. Vowel interpolates independently specified approximate resonances; Motion slowly shifts their frequencies. The design intentionally omits a third formant to keep the initial implementation smaller and cheaper. Higher notes gradually transition to a fundamental sine to reduce sideband aliasing. It is an oscillator-packet texture, not a recorded-sample granulator or complete speech synthesizer.

Concept references, Emilie Gillet / Mutable Instruments Plaits, with MIT notices in the cited files:
- https://github.com/pichenettes/eurorack/blob/master/plaits/dsp/oscillator/z_oscillator.h
- https://github.com/pichenettes/eurorack/blob/master/plaits/resources/wavetables.py
- https://github.com/pichenettes/eurorack/blob/master/plaits/dsp/speech/sam_speech_synth.cc

No SAM phoneme tables or imported wavetable assets are used. The reference scripts' licenses should not be treated as blanket permission for unrelated binary wave assets.

## Integration and bounded cost

New IDs append after CLUSTER; no persisted ID is reordered. New Morph sources append after existing sources. Engine callbacks, velocity, common envelopes/FX, randomizer, USER presets and the 128-sample continuity bridge are reused. Runtime arithmetic is integer/fixed-point; the offline Python generator may use floating-point. Render loops have no heap, floating-point operations, transcendental calculations, 64-bit multiplies or variable division. Scalar variable divisions occur at control rate. State is voice-private in the existing per-part union (132 bytes per slot; 2112 bytes per part, inside its existing arena); it adds no larger engine arena or audio buffer. The new waveform/surface tables total 3584 bytes, excluding code/presets.

Standalone scheduling follows CLOUD/SWARM/CLUSTER's 4 CPU0 + 2 CPU1 policy; Morph renders A on CPU0 and B on CPU1 (6 voices each), with Bass on CPU1. Voice budgets are policies, not measured CPU load. CPU1 state/PCM parity does not establish that every combination meets real deadlines.

Required target checks: PI32V2 build/link, absence of new soft-float helpers, map/stack budgets, and hardware audio deadline counters under fast overlapping six-note chords, Bass, Morph, chorus/reverb/delay and USB audio 48 kHz. Listen for aliasing, level differences and transition artifacts. The source is experimental until these checks pass; no target cycle or free-memory figures are claimed here.
