# Smooth Morph / KR106 level / REC context

- IMPROVED: Morph continuous parameters retain smoothstep interpolation. Manual position travel is now 200 ms. Discrete routing/wave/algorithm changes use 20 ms smoothstep stereo audio-history overlap, rather than fading to zero. A small midpoint hysteresis band prevents repeated A/B selector changes when hovering near 50%.
- IMPROVED: KR106 adapter output has sixfold makeup gain after its native chorus/limiter. Factory timbre, envelopes and relative patch levels are preserved.
- FIX: Hold REC outside SEQ restores layer Undo. Hold REC in the SEQ controls menu or step editor opens Chord Ideas. Preset-editor hold REC retains Preset Randomizer.
- FIX: INIT MORPH now explicitly stores seed 1, matching the previously compiled int8 value of the overflowing literal 257. The full runtime packed pair remains unchanged.

## Preview on Mac

```sh
cd "$HOME/Downloads/Choralroot-remix-smooth-morph"
source "$HOME/.venv/bin/activate"
sh tests/run_morph_tests.sh &&
sh tests/run_kr106_tests.sh &&
sh tests/run_creative_tests.sh &&
sh tools/emu/build.sh &&
build/host/emu --no-midi
```

Compare Morph across 45–55% in both directions, with very different A/B algorithms, Manual and Up and Down. History is a short reuse of previous audio, not a second sustained synth renderer; large topology differences can remain audible. No new engine voices or CPU1 jobs are introduced. Check KR106 pads/resonant sounds and quick chord changes, then REC Undo outside SEQ and Ideas inside it.

## Evidence and limits

Host Morph checks pass all 81 source/preset fixtures and 36 actual worker-versus-serial PCM/native-state combinations. 26 discrete changes remain valid endpoint values, settle exactly to B, and use the overlap without a deliberate mute. Synthetic opposite-polarity stereo checks bound the transition slope and verify the exact final output. Midpoint hovering preserves its selected side. A dedicated UBSan test covers full signed 32-bit stereo values and rapid overlap restarts.

History is 8220 bytes on the host, plus a small runtime-state increment. It is allocated in `.pool`, not on the worker stack. The target link must confirm exact pool alignment and image size. This changes the Morph audio hot path: hardware deadline/timing measurements remain necessary, particularly under maximum FX load. Previously measured device headroom does not certify this new build.

KR106 passes 471 factory/CPU1/native-USER fixtures with exact worker/serial PCM and native state. Its unchanged native DSP also passes 512000 stress samples under UBSan. Normalized six-voice factory-bank master PCM RMS medians, with generic FX sends off and part level 100:

| Engine | Before | After |
| --- | ---: | ---: |
| KR106 | 372.4 | 2189.8 |
| FM6 | 2082.3 | 2082.3 |
| VA | 2551.4 | 2551.4 |
| Prophet | 2892.2 | 2892.2 |

This compares factory banks, not perceptual loudness normalization; the master clean output can limit hotter presets.

Creative-tools tests pass 4845 randomizer fixtures, 840 progression/storage fixtures, 162 menu-key/preview/context checks and 13440 jazz chord/preview fixtures. The REC test exercises a real two-layer loop and verifies the last layer is removed outside SEQ; opening Ideas in SEQ leaves the remaining sequence intact.

The Remix regression suite also passes step controls/transport, Simple mode, Prophet USER/Bass storage, Just Keys recorded Bass, 20-slot loop storage, 12000 grid edits, and Python/web backup clients.

No target firmware package has been built here. No device was flashed. Boot/recovery, flash layout, storage records, `eng_quad.c` and legacy golden audio are unchanged. Build on the Mac and review flash/RAM/pool/stub guards and transporter compatibility before any later installation.
