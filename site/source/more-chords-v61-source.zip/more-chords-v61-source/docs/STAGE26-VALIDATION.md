# Stage26 validation

Validated against the supplied Stage25 Church/Gate source. No device flashed.

- Wah: real UI/event queue/emulator-firmware path; three rates, stereo sweep, bounded output, internal/external clock, dropout and exact bypass.
- Selected musical suite: PASS, including editor SELECT, unchanged Melodee Ambient (30,000 blocks bit exact), Church reflections, Gate, keys-only, swag/rosen/FX preservation, sidechain/transpose and settings/storage/looper checks.
- Chord integration: 71,411 cases, zero failures. CZ factory+BASS: 19,890 checks, zero failures.
- Dual-core: 5,638 concurrent/serial cases, PCM and voice state identical; 10,368 split-policy fixtures; stack markers and timeout/no-replay policy pass.
- CPU1 corrupt mailbox: no callback execution; CPU0 reset path receives published fault. Official power ramp verified on mock P33 registers.
- USB: 54 checks pass; 30 seconds, 1,323,273 six-channel frames, no wrong frame or packet lengths in host model.
- Stub decisions: 16,143 checks pass. Packer/layout: 265 checks pass.
- Loader interruption model: same stub, 1,361 cut points, 1,360 rescues plus completed boot, zero unprotected points. Introducing/changing stub still leaves 16 unprotected cut points in this fixture. Flash below 0x4000 unchanged. Synthetic target code is not executed by this model.
- OTA: staged loader retained, stale record removed, incomplete/foreign loader rejected, refusal before erase retains recovery; stub/OTA decisions agree on 20,000 damaged copies.
- Backup/DEBUG/STUB protocol: 97 checks, zero failures.
- UART/TRS parser, realtime messages and source/timestamp routing pass. Physical TRS reception remains unverified.
- Target C syntax with CPU1 disabled/enabled and HAL-only register audit pass. All engine source files, including eng_quad.c, and legacy golden files are unchanged.

## Still unverified

A fresh JieLi target link, final flash/RAM/POOL sizes, generated stub hash, target assembly execution, USB recording without clicks on the real Mac/FM1, and physical interrupted-install recovery. Mac GUI emulator cannot be launched in this Linux environment (Mac SDL2/CoreMIDI/clang build dependencies unavailable); tests execute its firmware directly.

USB recording retains a 512-frame ring / 256-frame prime (~5.8 ms). Extra latency was permitted but not added without a measured need. The official packet reservation and service fixes were integrated first. CPU1 defaults on; its existing six-voice chord/BASS split is preserved. CPU1 faults still reset the unit instead of replaying partially advanced shared states.

The recovery stub checks loader framing/headers and its own-loader signature, not every compressed payload byte after staging. In the damage model, 10,822/20,000 modified copies still pass those structural checks; this is an additional limit for later flash corruption. Install-time CRC validation remains in the OTA path.
