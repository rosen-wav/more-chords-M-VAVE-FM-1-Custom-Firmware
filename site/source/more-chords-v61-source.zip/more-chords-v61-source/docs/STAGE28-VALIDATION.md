# Stage28 validation

- Full `run_new_features.sh`: PASS, exit 0. Includes three-detent FX selection,
  Crystal first option, stereo Wah/four rates, editor behavior, ambient/church,
  Gate actual audio ISR, keys-only, sidechain, transpose, swag, rosen, chord
  integration (71411), CZ factory (19890), overload policy (42553), backups,
  settings/MIDI/boot guard, and loop (110).
- Deeper Wah response/stress: PASS. 1 kHz open/closed energy ratio about 307;
  twelve rate/tempo stress fixtures; bounded states and Off clears resonance.
  This is a response measurement, not a subjective sound quality rating.
- `run_dualcore_tests.sh`: PASS, exit 0. 5638 concurrent/serial PCM/state cases,
  10368 voice split fixtures, private stacks, timeout and startup fallback.
- Target C syntax checked after final Wah rounding fix, CPU1 flags 0 and 1: PASS.
  Actual JieLi assembly/linking, device memory report and physical audio are pending.
- Actual firmware screen capture -> actual `cr_draw.c` host render inspected for
  Gate, Wah and Crystal option. Complete names and distinct icons visible.
- Compared against uploaded Stage27 bytes: all engine DSP sources (including
  eng_quad.c), legacy goldens, stub and loader unchanged. No flashing performed.
- New Settings entry remains session-only. Settings storage version unchanged.
- Picker name slots grow from 24 to 32 bytes so the full mode name is visible;
  actual device RAM size must still be measured by the target build.

See `docs/validation/stage28-*` for host output and captured screens.
