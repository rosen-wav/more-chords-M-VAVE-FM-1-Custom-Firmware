# Stage36 Prophet optimization

Based on the supplied Stage35 buffer192 archive.

- Skip oscillator waveform calculation when all its waveform switches are off; preserve phase, noise and triangle state.
- Compute envelope contributions once per output sample rather than once per oversampling pass, retaining fixed-point rounding.
- Replace hard-sync 64-bit phase multiplication with an exact split 32-bit product. For fraction <=32768 and capped increments, neither partial product overflows.
- Keep 192-frame DMA halves, two chord voices on CPU1, Prophet bass restrictions, all presets, effects and boot recovery unchanged.

Validation: frozen Stage35 waveform/sample kernel compared against optimized code, all factory programs plus 1000 randomized raw patches, 64 consecutive blocks each. Full PCM and voice-state comparisons, including filter state, cached coefficients, phases, triangle, noise and hard-sync tails. This is a new regression reference, not regenerated legacy golden audio.

Host checks cannot quantify JieLi CPU savings or prove that hardware clicks disappear. Target assembly/link checks and worst-case rapid-note testing remain necessary. No firmware flash performed here.

Mac: sh tests/run_prophet_optimization_tests.sh
Build with CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 using your Python environment.
