# Stage37 Gate only

Removed master Wah DSP/state, CPU1 job/click scratch buffer, menu option/icon and console counters. Gate now runs directly in the common mixer; the metronome click remains after the gate and after USB master capture. CPU1 chord/bass rendering and Stage36 Prophet optimization are unchanged. Gate selection still requires three detents; all four rates are retained.

Removed obsolete Wah-only tests and updated UI tests for the two supported modes. A legacy CRE_GATE mode2 request falls back to Off. Performance Gate is session-only and was already reset to Off on boot; no persistent settings layout change or flash data deletion is needed.

The existing per-engine modulation page labelled Wah refers to filter LFO depth; it is independent of the removed master effect and is preserved.

Host checks cover Gate UI/thresholds, internal/external clock, bypass/smoothing, full ISR path, DMA192, sidechain, loop transpose and Prophet PCM equivalence. JieLi image size/RAM and hardware audio still need the Mac build/device test.
