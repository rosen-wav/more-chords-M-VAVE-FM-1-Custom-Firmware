# Stage39 — Morph refinement

Complete Stage37 gate-only source project plus a refined chord-only engine, Morph (appended ID19). Existing engine IDs remain unchanged. CPU1, DMA192, Prophet optimization, gates, bass collection and interrupted-install boot stub are retained. No Wah.

## Controls

Select Morph with the engine picker (hold EDIT, choose Morph), then open EDIT.

OSC opens OSCILLATOR:

| Knob | Function |
| --- | --- |
|1|Source engine: FM6, QUAD, VA, PHASE, LOFI, VOICE|
|2|Factory preset, including its initial patch|
|3|Position A–B; turning it takes over manually|
|4|Manual / Ping Pong / Random|

LFO opens MORPH SETTINGS (the only other engine screen):

| Knob | Function |
| --- | --- |
|1|Speed: 100ms–8s for a full A-to-B traversal|
|2|Amount: 0–100%; safety caps remain active|
|3|Trigger: Free / Chord (each newly played chord)|
|4|Roll: - / Roll A / Roll B / Both; selecting an action regenerates those ends|

Manual follows Position. Ping Pong moves between A and B. Random + Free regenerates bounded variants at each completed move, chooses a new position and glides toward it. Random + Chord does this when a new chord is played, holding the target between chords. With Chord enabled, Manual and Ping Pong also refresh their variants at each new chord. New variants enter through a 50ms transition; Speed governs the position movement. Partial Random moves take a proportionally shorter time.

Trigger uses the chord's gesture identity, not individual note-ons. Keyed chords, same-root restrikes, pads and loop chord starts can trigger. Inversions/voicing edits, held-harmony rebuilds and individual arp/scatter steps do not. Single notes without a chord quality do not trigger. rosen preset switching is suspended while Morph is selected and remains available after changing engines.

No filter/envelope/modulation/editor FX screens for Morph. Global effects remain accessible through the normal performance controls. Bass stays independent. Morph cannot be assigned/saved in the BASS collection. BASS is excluded as a Morph source; the standalone BASS engine remains unchanged. Every supported source keeps its original voice cap and envelope model.

## Scope and smart rules

The source selector uses the engines compiled in this ChoralRoot build. CZ-1, Prophet and BASS are excluded, as requested; retired engines are not resurrected. This version selects factory source presets, not custom USER source patches. Morph configurations themselves can be saved as USER sounds.

Only one source engine is rendered. This is parameter morphing, not two synths crossfaded together. Continuous controls move; structural choices, algorithms, oscillator selection/ratios/tuning, samples, modulation routes and tempo/harmony are protected. Levels and envelope ranges have conservative caps; disabled oscillator/operator levels stay disabled. Native VA/QUAD parameters use their existing public deep interfaces. QUAD DSP source is unchanged.

FM6 interpolates an effective patch copy after its original macros, leaving stored source bytes intact. Only active modulator rates/levels/output and LFO speed/delay/amplitude depth can move; complete carrier envelopes/output levels, pitch envelope, operator tuning, algorithm and release end levels remain protected. Continuous FM6 patch changes preserve the current envelope segment and remaining static wait instead of forcing held voices into sustain. Native FM6 editor behavior is unchanged. This keeps Amount0 bit-identical even on presets with nonzero original macros.

Seeds for A/B are reproducible and independent. Regenerating A preserves B. The seed uses four unused bytes140–143 of the existing packed USER record, tagged M/0x38. P_COUNT<128; no parameter or pattern bytes overlap. Record size192, bank layout and settings size764 are unchanged. No new flash region, settings version, erased bass collection or install behavior.

LOFI resolves preset-dependent parameter descriptors: wavetable and stepped-envelope selectors stay fixed. Sweep, vibrato and crushing stay fixed too. Duty/tone and shared continuous controls have a four-unit variation cap, even at Amount100.

The editor uses a focused value above four compact knob cells, like rosen mode. GUI controls are published separately from the temporary source parameter render scope, preventing source-name flicker. Only the GUI builds the preset-name list. Invalid old BASS source indices fall back to FM6 without indexing outside the source list.

## Verification and limits

Host tests compare all81 compiled source factory presets with their originals at Amount0:64 blocks of PCM per preset, bit-for-bit, with the same mix/effect settings. They exercise bounded variants, note release, configuration restoration, deterministic seeds, A/B isolation, USER encoding, editor groups and BASS rejection. Actual threaded CPU1 comparisons cover36 source/bass combinations, including VOICE/VOICE serialization. The emulator's real ISR verifies chord/restrike triggering and no extra roll for voicing/arp steps. An additional239616 carrier-envelope comparisons cover all26 FM6 factory presets at full Amount while moving, including held notes and release. LOFI selector/cap checks and GUI reads during a temporary render scope pass. Existing feature/backup/bootguard/loop/MIDI/audio and dual-core regressions passed. Prophet's76864-block Stage35 comparison passed.

No legacy golden audio regenerated. No device flashed. Host equivalence does not measure JieLi cost or guarantee a click-free target. Morph adds bookkeeping and cached variant fields; it does not double audio rendering. Exact target RAM/POOL/XIP usage must be checked from the Mac build before installation. Runtime storage is approximately5KiB in .pool on a32-bit target (host structure size is larger because of pointers); linker results are authoritative.

## Provenance

Inspired by the smart continuous/protected-parameter rules in the supplied DUELL0.1beta archive (commit22671953b397f5130cf66999b8761ac7f804e6f3), by OSCILL/R, GPL-3.0-only. This is a ChoralRoot adaptation, not an official DUELL build; DUELL branding/artwork is not reused. See the project's existing LICENSE and third-party notices.
