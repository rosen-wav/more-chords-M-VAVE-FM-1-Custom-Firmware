# Stage43 — keys-only aggregate bass

When keys-only is enabled, three or more distinct held, playable keyboard pitches trigger a single aggregate BASS owner. The lowest sounding pitch selects the root using the existing BASS pitch mapping and octave controls. Inversion recognition is unnecessary: this is lowest-note following, not harmonic-root inference. UNISON behavior retains its existing absolute pitch semantics. The selected BASS preset/routing is unchanged.

The threshold counts independent playable pitches, including shared note-owner handling. Pads, latched/free voices and loop voices are excluded. A new lower key changes the bass while the other ordinary keyboard notes remain independent. Dropping below three releases it. Keys-only bypasses chord generation and performance transformations as before.

The aggregate owner uses the normal bass registry, respecting shared notes. It is updated on key events, BASS/stream/behavior changes, octave changes and crystal-bass clock phase. Panic and mode changes clear it. Runtime adds a three-byte owner plus structure alignment; no persistent settings/bank changes. Detection scans the bounded live-key voice array, not an audio-rate chord-recognition algorithm. Exact target memory/cost remains a build/device check.

Tests cover41160 root/order/register/transpose/bass-mode combinations, threshold, changing lowest note, repeated note owners, disable/re-enable, shared bass ownership, crystal phase, panic and the real queued-key path to the selected BASS synth. Keys-only, Morph, CPU1 and general feature regressions are retained.

The legacy cr_engine_test suite has162 failures both before and after this change, with byte-identical output (1629 passes). These are pre-existing and are not counted as a passing suite. See the host validation report for selected regression results.

No device flashed; no legacy golden audio regenerated; eng_quad.c is byte-identical to Stage42.
