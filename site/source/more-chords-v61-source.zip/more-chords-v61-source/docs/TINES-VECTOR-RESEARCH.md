# Source review before implementation — 18 October 2026

No third-party source code, samples, patches or external runtime libraries are imported for these two engines. Implementations and generated harmonic tables are original GPL-3.0-only additions, using the existing firmware sine, envelope, filter, modulation and transition primitives.

| Reference | Actual source inspected | License / dependency | Embedded decision |
|---|---|---|---|
| kalexis1994/rackforge | README, complete recursive source tree, RF-Tines control layout | Repository GPL v2; host Rust/portable-plugin architecture | RF-Tines is advertised and mapped in the host, but its DSP is absent from this public tree. Cannot claim its physical model was inspected or ported. No host or plugin dependency imported. |
| MikeMorenoDSP/EP-MK1 | tutorial/01-Hammer.pd, 02-Tone_Bar.pd, 03-Tine_Layer.pd, 04-Pickup_Layer.pd, EP-MK2/abs/voice.pd | GPL v3; Miguel Moreno 2019; Pure Data/Camomile | Hammer excitation, body resonator, higher tine resonances, nonlinear pickup. Replace signal graph and transcendental operators with original bounded sine modes and independent decays; reuse firmware filter. |
| danielpodrazka/piano | generators/generate_rhodes_fm.py | MIT; Daniel Podrazka 2025–2026; Python/NumPy/offline IR convolution | Actual implementation uses body FM 1:1, tine FM 9:1, velocity-dependent brightness/decay and pickup asymmetry. It describes tonebar coupling, but is not a directly reusable coupled-oscillator embedded C implementation. No FM generator, fitted phases or IR data imported. |
| dr-schlange/LISA | src/voices.h, src/wavetable_streaming.h, LISA.ino | GPL-3.0; Arduino/RP2040/Braids | LIVE has four phases, fixed-point interpolation and bilinear mixing, but compresses/squares XY first. VECTOR uses the requested linear XY coordinates and exact constant-sum integer weights, four immutable internal sources; no streaming, scanned synthesis, Arduino or Braids import. |
| surge-synthesizer/surge | src/common/dsp/oscillators/WavetableOscillator.cpp | GPL-3.0-or-later; Surge Synth Team, Claes Johanson; desktop C++, floating point/SIMD/storage | Study table interpolation, mip levels and previous/current morph interpolation. Replace with original compact harmonic-limited tables and sample-slewed controls. No oscillator class or framework imported. |

Licenses downloaded from each repository are retained alongside this report for reference; they do not imply code import. The RF-Tines missing DSP limits that part of the requested study.

Design comparison: TINES costs a few sine modes plus one shared SVF per voice, with modal decays updated once per control block and interpolated over the block. VECTOR costs four short-table linear interpolations and three bilinear mixes plus the same SVF. Both keep voice-private mutable state in the existing engine arena. A shared rewritten composite wavetable was rejected: per-voice velocity/modulation, pitches and independent CPU ownership would require additional tables and synchronization; four read-only sources avoid that risk.

Target CPU/XIP/RAM/POOL are not inferred from host timings. PI32V2 build and physical device tests remain required.

## Pinned public snapshots

- [kalexis1994/rackforge](https://github.com/kalexis1994/rackforge/tree/f7f1b0c9e074eb8ff08054c6c1d2fe3a8939b9b0), commit `f7f1b0c9e074eb8ff08054c6c1d2fe3a8939b9b0`.
- [MikeMorenoDSP/EP-MK1](https://github.com/MikeMorenoDSP/EP-MK1/tree/f389ac69dbaa1013ad176680f23612a66dcabae6), commit `f389ac69dbaa1013ad176680f23612a66dcabae6`.
- [danielpodrazka/piano](https://github.com/danielpodrazka/piano/tree/ce03f932aeee91d4e4ce835d3083279314b57fd5), commit `ce03f932aeee91d4e4ce835d3083279314b57fd5`.
- [dr-schlange/LISA](https://github.com/dr-schlange/LISA/tree/605c7e5376147df2ca94d3dea3a332150cea73c6), commit `605c7e5376147df2ca94d3dea3a332150cea73c6`.
- [surge-synthesizer/surge](https://github.com/surge-synthesizer/surge/tree/4f0da4e423a675cb9c2c3e34ca3d381b43875324), commit `4f0da4e423a675cb9c2c3e34ca3d381b43875324`.

The piano repository also contains separately licensed sample directories (including CC BY-NC Rhodes samples); none are used. Its synthesis code is MIT, as stated in the first section of its LICENSE.
