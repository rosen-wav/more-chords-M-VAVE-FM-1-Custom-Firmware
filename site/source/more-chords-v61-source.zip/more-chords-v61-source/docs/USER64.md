# USER64 storage extension

U01..U32 and native patch stores retain their original formats/locations. U33..U64 use two 3840-byte logical banks, each 16×240-byte records. The three sectors F9000/FA000/FB000 form a shared-spare journal: erase only the sector that is not the current committed sector of either bank, write payload then CRC-protected header last. Boot scans all three and selects each bank's newest valid sequence. The other bank's current sector is never erased. Flash bounds remain enforced by HAL. Settings FC000/FD000, FM6 bank FE000, reserved FF000, OTA staging and all 30 loops remain separate.

Layout 1 stores the 83 common controls with their exact descriptor widths (470 bits), eight signed16 macros, name/engine/factory binding, and up to 144 native patch bytes. Prophet stores its 53-byte native tail. CLUSTER's raw signed macros and Morph's wide pair/seed value round-trip. The mirrors/scratch live in POOL; check the actual PI32V2 map because this extension consumes most of the remaining pool margin. No claim of target fit is made before building.

Backup protocol object 70 = U33..U48; 71 = U49..U64. Both updated clients implement the same codec; the old native stores stay at 32 slots. Restore staging holds the full 3840-byte payload. The common schema is fixed at P_COUNT=91/P_E0=83; changes to order/ranges need a new codec version, not reinterpretation.

The high USER favourite bits occupy unused bytes in the retired VOICE favourite bitmap, retaining the existing settings size. Obsolete Felucca preset patterns cannot be stored in the extension and are refused, rather than silently truncated; current loops/sequences use their own storage.

Host tests cover 64 records across twelve engines, full native blobs/Prophet tail, reload, overwrite, deletion, favourites, 48 journal rotations, 7778 byte-level interrupted writes, and SysEx GET/PUT/LIST/invalid data/bank deletion. Python/JS codecs are compared byte-for-byte against firmware-generated fixtures. Existing backup and installer suites are also run. These tests do not replace a target build or real flash validation.

Prophet's 201 factory entries plus 64 added sounds can exceed pool position 255. Runtime pool/save positions are 16-bit. The unchanged settings record uses a reserved 0x8000|slot marker for a selected USER above position 255; legacy engine/position words keep their original encoding. The high-slot restore is tested explicitly.
