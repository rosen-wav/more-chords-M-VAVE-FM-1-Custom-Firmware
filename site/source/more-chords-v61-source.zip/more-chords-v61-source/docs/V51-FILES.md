# Files changed / added in V51 delivery

DSP and registration:
- firmware/src/eng_keys_vector.c (new original TINES/VECTOR DSP and native pages)
- firmware/src/vector_tables.h (new original generated harmonic tables)
- tools/gen_vector_tables.py (new offline reproducible generator)
- firmware/src/core.h, engines.c, params.c, voice.c, fx.c, eng_morph.c

Step hold/move and preset UI:
- firmware/src/cr_loop.h, cr_loop.c, cr_out.c, cr_ui.c, cr_edit.c
- firmware/src/eng_cloud.c (retained -1.5 dB balance)

CZ retirement and persistent compatibility:
- firmware/src/choralroot.c, cr_settings.c, storage.c, cr_backup.c, upreset.c, user_ext.c
- tools/emu/emu_firmware.h, tools/build.py, tools/emu/build.sh, tools/emu/web/build_web.sh
- Generated legacy build/gen/melodee_cz1.h no longer required or shipped. Legacy CZ codec/DSP source and original notices remain for historical reference, but default firmware builds no CZ DSP or factory data.

Clients:
- web/fm1sounds.js, tools/fm1_install.py (names, factories, CZ retirement)

Host verification:
- tests/cr_tines_vector_test.c, cr_tines_vector_character_test.c, cr_tines_vector_overlap_test.c, cr_tines_vector_morph_test.c, cr_tines_vector_ui_test.c, cr_tines_vector_render_test.c
- tests/run_tines_vector_tests.sh
- tests/cr_v50_move_retire_test.c, cr_v50_grid_property_test.c
- tests/cr_backup_test.c, cr_v39_user64_test.c, cr_dual_morph_test.c, sound_templates.c

Documentation:
- README-V51.md
- docs/TINES-VECTOR-RESEARCH.md, V51-VALIDATION.md, V51-FILES.md
- docs/research-tines-vector/*-LICENSE.txt
- docs/v51-test-results/*.txt, UI contact sheet

No memory-region enlargement, P_COUNT change, old engine renumbering, external framework or sample import. Public GitHub repository and published web installer are not modified by this ZIP delivery.
