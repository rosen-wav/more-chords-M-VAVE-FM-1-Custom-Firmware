# V51 validation — 18 October 2026

## Result

Host integration checks passed. Target compatibility is UNVERIFIED: build.sh exits 1 because the PI32V2 toolchain is absent. No target ELF/FWSC, linker result, target memory report, FM1 CPU deadline or hardware listening test is claimed.

| Check | Observed result |
|---|---|
| C syntax, firmware dual-core=0 and =1, Prophet enabled | PASS |
| New DSP UBSan, factory presets/extremes/velocity/MIDI 0..126 | 1,751,040 samples, PASS |
| XY weights | 66,049 cases, exact constant sum and all corners, PASS |
| MOTION=0 and XY smoothing | Orbit frozen; monotonic finite endpoint slew, PASS |
| TINES velocity timbre | Normalized first-difference energy: soft .0014700, hard .0020721; amplitude fixed in fixture |
| VECTOR corners | Spectral roughness .0014717 / .0051903 / .0064272 / .0045745; COLOR changes spectral content |
| Standalone CPU1 | 48 serial/concurrent exact PCM+state fixtures, six chord voices 4+2 and four Bass engines |
| Voice stealing / overlap | 300 cases, all 12 presets, six-note chords, Bass, inversions, major/minor/extensions, shared-note releases, queued retriggers, raw keys/MIDI |
| Global Morph | All 11 supported sources endpoint/note-off regression; TINES and VECTOR 6+6 exact serial/concurrent PCM+state, plus 40 cross-engine combinations |
| Save/reload | All new parameters, 64 USER slots, native payloads of other engines, reboot/journal/favourites preserved |
| Init | 14 visible engines; saved slot not overwritten |
| Backup | 93 checks; legacy CZ objects remain byte-identical after transport restore |
| Step movement | Physical-hold UI gate, swap/page boundary/hidden events/metadata preservation; 10,000 randomized reversible swaps and existing 12,000-edit grid checks |
| UI | 14 real page snapshots (12 engine pages + 2 Morph B states); render text-bound/overlap lint 0 findings, 0 failures; visually inspected 240x240 renders |
| Clients | Python syntax, JS IDs/factories/record checks, firmware-generated factory metadata matches both clients |
| Transporter | Existing shim tests pass; no newly built package available |
| Retired CZ | No cz_native/CZ_FACTORY/cz_patch/cz_bank/cz_store symbols in the integrated host executable |

## Memory / timing: what was actually measured

- VECTOR immutable tables: **2,560 bytes**, four families x five harmonic bands x 64 signed 16-bit samples.
- New mutable state per voice: **76 bytes**, per 16-slot part: **1,216 bytes** on this host.
- Existing shared engine arena per part: **6,884 bytes**; new state fits it by static assertion. Arena count and allocation are unchanged (3 parts; host total 20,652 bytes). Pointer/ABI-related target values must still be checked on PI32V2.
- No new heap allocations or mutable per-part wavetable buffers in audio code.
- Illustrative x86 host timing at -O1, 50,000 blocks: TINES ~0.925 us and VECTOR ~1.285 us per voice per 32 samples. These are NOT PI32V2 timings or a CPU budget guarantee.
- XIP/RAM/POOL target: **not measured**. No linker memory regions changed. No extrapolation from the old V48 numbers.

## Scope and known limits

- RF-Tines DSP was not found in the supplied RackForge public source tree. README/control mapping are reviewed; no RF-Tines port is claimed.
- Global Morph now permits an independent source B through the FILT / PATCH B page; Same as A is backward compatible. 40 cross-engine combinations with TINES/VECTOR on either A or B and all supported counterparts pass exact PCM/state comparison and USER persistence. Hardware CPU cost of each pairing remains unmeasured.
- Matrix destinations X/Y/COLOR use the existing per-track control-rate modulation convention; a voice-derived source uses the latest note's value, as other engine macro destinations do.
- The filter ADSR reuses dormant DIGITAL operator-1 parameter IDs only for TINES/VECTOR. No disk layout or P_COUNT change.
- New-engine raw DSP passes UBSan. Running the full legacy mixer with UBSan also reveals pre-existing signed negative shifts in QUAD; that unrelated path has not been described as UBSan-clean.
- Existing published installer/web emulator files are not repinned to an unbuilt firmware. Build the native emulator from source on Mac using tools/emu/build.sh.

## Reproduce

`sh tests/run_tines_vector_tests.sh`

All source-study details and reference license copies are in TINES-VECTOR-RESEARCH.md and research-tines-vector/. Raw host results are supplied in docs/v51-test-results/.
