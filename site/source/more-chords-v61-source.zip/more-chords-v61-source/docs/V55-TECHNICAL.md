# V55 technical notes

## Sources and attribution

Base: user-supplied more chords! V54, a remix of **ChoralRoot by u/Quixotic7**, retaining the existing Felucca/Melodee/other contributors' credits and licenses.

Imported from the attached ChoralRootFM1 0.25: `grain_src.c`, the grain player and scheduler in `eng_grain.c`, and `va_common.c` primitives. Existing GPL-3.0-only notices remain. The identifiers of the shared VA primitives are prefixed `gsync_` to avoid collisions with V54's VA implementation. The upstream design document is retained as `docs/GRAIN-UPSTREAM-025.md`; its historical build results do not apply to V55.

Original more chords! additions: `grain_synth.c`, SOURCE controls/scheduler, V3 metadata packing, factory importer, VA stereo worker planning, Bass legato velocity fix and V55 tests.

## Capture architecture

Three musical parts remain: chord 0, Bass 1, global Morph B 2. A fourth *isolated context*, outside NPART/NTRK musical loops and storage, provides a private track, native state, Prophet patch, FM6 patch/function/controller data, and private FM6 DSP scratch. It is not an additional musical track.

Capture calls the actual Prophet/FM6 DSP, not DAC recording. It submits no note events to active parts. C4 is MIDI 60 and pitch16 960. It renders 32 output samples per poll (64 input frames at 44.1 kHz) with a seven-tap integer FIR decimator to 22.05 kHz. Two source buffers remain 16,384 signed 16-bit samples each: 65,536 bytes total, 743.039 ms each. The gate drops after 24,576 input frames (557.279 ms).

PCM conversion reserves 18 dB of headroom before int16 quantization. Incremental DC/high-pass measurement and gain application follow, with up to 8x recovery. Thus loud multi-carrier patches are not intentionally clipped before normalization; low-level sources can remain below the 28,000 peak target. Fixed-point DSP only; no new floating-point helpers or desktop DSP dependency.

GRAIN's audio-block tick requests work; the main loop performs it with interrupts enabled. Only small snapshots/commit metadata use critical sections. The desktop emulator likewise polls outside its CPU/UI lock. A private FM6 scratch slot prevents overlap with the CPU0 and CPU1 renderers. A canceled job clears the isolated voice. Factory references are verified before capture.

A buffer is first marked unavailable; its playback gain falls to zero by 256 Q15 units per 32-frame block (about 93 ms). Only then may generation overwrite it. Playback conditionally skips buffer reads at zero gain. Complete generation commits the root/configuration and marks READY; gain rises again. Existing grains keep advancing. This preserves the *other* source, but does not provide uninterrupted old/new audio for the same source; that would require another buffer.

ORIGINAL source synthesis is still the upstream deterministic two-pass generator. All eight families have exact PCM comparisons against the whole-buffer generator. Global Morph intentionally does not offer GRAIN: independent instances would require separate ownership/buffer sets. Its nine existing source choices keep their indices after removing the trailing TINES/VECTOR choices.

## Presets / persistence

GRAIN native blob V3: 80 bytes. Native values occupy the existing first 63 bytes; bytes 64–79 hold two 8-byte source records: stable engine ID + RANDOM flag, resolved factory index, deterministic seed, capture velocity, and 32-bit FNV-1a fingerprint of the factory patch. C4, duration, release point and rendering recipe are fixed by V3. Unknown engines, invalid indices or mismatched fingerprints cannot generate audio.

PATCH=0 means RANDOM. It resolves only on explicit configuration or REGEN, never note-on. Saved engine/patch/seed are reloaded without drawing a new random choice. The capture engine and factory PCM are reproducible for the same DSP/version. Future changes to the recipe must bump/migrate V3 rather than claim cross-version identity.

The 61 native GRAIN values fit seven bits each after subtracting their descriptor minimum. Together with the 128 metadata bits and a 3-bit tag they occupy 558 bits. V54's 20 DIGITAL-only controls (unused by GRAIN) supply 140 bits in a saved USER record; its existing 53-byte unused tail supplies 424 more. Live GRAIN does not use those DIGITAL controls. This preserves the old record size and other engines' records. U33–U64's existing extended bank carries the same 53-byte tail. No new flash object or PCM write is introduced.

V1/V2 native GRAIN blobs still decode using the upstream rules. An original 0.25 full project/storage image is a different storage architecture: importing that entire image into V54's USER banks is not implemented or claimed. Old eight-macro records lacking a V3 tag cannot recover unprovided native metadata.

## FM6 import

`assets/factory/fm1-user-bank.syx` is the exact attached bank. `tools/import_fm1_factory.py` examines only records 1–64, checks the observed extended-VCED framing/checksum convention, and extracts the 155-byte voice payload. All 64 in this attachment are decodable FM data; an analog-sounding patch name is not proof of a VA engine. Unknown header/length records are skipped; no later records are substituted. The tool is specific to this observed FM1 export format, not a general decoder for arbitrary VA exports.

Four records have out-of-range DX envelope fields, clamped to the supported limits in the import report. Extra FM1 effects/settings bytes are not interpreted. Existing saved USER native FM6 blobs remain supported; selecting a *factory* now deliberately addresses the replacement bank. The original SYX remains included so the conversion is reproducible.

## Verification and resources

`tests/run_v55_tests.sh` builds the firmware headlessly, uses a real concurrent CPU1 worker, checks UI layout, runs UBSan, and performs hardware-unit syntax checks with dual core disabled/enabled plus web-unit syntax checking. This is not a PI32V2 linker/build or a WebAssembly build.

Verified: all VA factories exact serial/worker stereo PCM/state with six planned chord voices (two worker + four main) and Bass; quieter legato Bass velocity; offline Prophet/FM6 isolation from active FM6+Prophet PCM/state; deterministic source regeneration; actual USER save / storage reboot / reload in slots 1 and 64; upper-bank serialization; RANDOM persistence; cancellation; bad reference refusal; 64 FM6 factories non-silent for full 743 ms; all original families exact PCM; six-note GRAIN playback, octave transposition and exact internal A/B endpoints; Init menu and nonempty GRAIN screens; 3,108 musical randomizer factory/part/amount cases; all nine existing Morph sources across three Bass engines (27 serial/worker fixtures).

**Hardware resource gate remains open by explicit request.** The native x86 compiler's static allocation listing totals approximately 399 KB in `.pool` before target-specific alignment/CPU1 stacks; this already exceeds the device's 344,064-byte POOL. This is diagnostic host data, not a PI32V2 measurement. No target XIP/RAM/POOL/stack/CPU figures are asserted. Buffers alone add 64 KiB; source state/context and VA stereo plans add further space. TINES/VECTOR runtime state is removed, but graphical caches retain V54's original size. The linker regions and budget checks are unchanged.

For a later *diagnostic* Mac target build (expected to need the planned memory work first):

```sh
CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1 PYTHON="$HOME/.venv/bin/python3" sh build.sh
```

Do not flash or update the web installer until target build, linker, checks, transporter tests and hardware listening/timing tests pass. No stable installer manifest is changed by this source delivery.

The external desktop/web sound-bank editor schema has not been extended for the GRAIN V3 native state. Use the firmware's own Save/Load menu for these presets; full 0.25 project conversion and external GRAIN preset interchange remain outside this delivery.
