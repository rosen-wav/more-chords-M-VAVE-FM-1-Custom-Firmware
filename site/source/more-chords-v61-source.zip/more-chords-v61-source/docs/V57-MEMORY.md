# V57 static memory diagnostic

GCC host sizes for the hardware translation unit (`CHORALROOT_DUAL_CORE=1 FELUCCA_PROPHET=1`), before and after. This is not a PI32V2 build/linker result. The sum excludes section alignment/padding and uses host pointer sizes.

| POOL object | Before bytes | After bytes | Saved bytes |
|---|---:|---:|---:|
| Canvas and LCD staging | 59520 | 7680 | 51840 |
| Scaled glyph column weights | 9216 | 576 | 8640 |
| Glyph coverage cache | 8192 | 4096 | 4096 |
| Huffman cache | 1040 | 520 | 520 |
| Ring cache (constant tables moved to XIP) | 6102 | 5796 | 306 |
| Additional source parameter/control arrays | — | +311 | -311 |
| **Total static POOL allocation delta** | **398905** | **333814** | **65091** |

The PCM sources remain 65536 bytes. Delay, chorus, reverb, USER slot counts, loop slot counts and musical voice counts are not reduced. Stacks and linker limits are unchanged.

Ordinary RAM additionally holds a 192-byte waveform envelope cache, one 136-byte VA source voice and one 152-byte FM TONE source voice (host sizes), plus small per-source controls. That private context is sequential main-loop work, not a fourth musical track. Musical runtime states remain separate; the test suite checks PCM/state isolation with CPU1 active.

The user's V56 PI32V2 build reported 61536 bytes of overflow. The measured allocation reduction exceeds that figure, but it is not proof that V57 fits: only the real target linker can confirm final POOL, XIP and RAM. The remaining expected margin is modest. No target timing or flash compatibility claim is made.

Rendering uses 30 strips instead of 6 and one DMA staging buffer instead of two. LCD staging is synchronized before reuse without disabling audio IRQs. This reduces memory substantially and preserves tested pixels, but hardware GUI throughput needs observation under audio/MIDI load.
