# V8 validation report

Base: attached V7 Morph/UI/Monk source. The attached smoother V2 is an older comparison, not the working base. All tests below run on host; no FM1 connected or flashed.

## Audited and corrected

1. FM6 scratch for Morph B was still mapped to CPU0; B now uses CPU1 scratch, serially after Bass within the same worker.
2. Shared voice budgets assigned Morph B to CPU0; B now shares CPU1's budget with Bass. Six held notes on both A and B are asserted, rather than merely testing that some audio exists.
3. B's private voices and pending steals were not cleared on leaving Morph; cleanup now occurs after the ordinary engine transition, with B fading alongside A. Source changes do not leave dormant held allocations.
4. Pitch bend, wheel, aftertouch, breath, foot and expression are published to B before starting the worker. The B sample-and-hold LFO uses a private random generator.
5. Dynamic Velocity Off previously forced the common performance callback to velocity 100, including external MIDI and recorded notes; this normalization was removed. Physical keys still use the selected fixed level when Off. A tap released while sensing now produces the pending tap instead of vanishing.

## Evidence

- Real pthread CPU1 worker versus serial mixer: **32 configurations**, all four Morph sources x eight Bass engines; six held notes per patch, note releases/retrigger, Position sweeps, controllers, engine exit. PCM compared block by block; endpoint/UI tests also pass.
- Monk sensor state-machine tests: hard/soft strikes, driven readings, calibration, probe response, grazing and release bounce. The included Monk reference algorithm differs only in its local math include. This is synthetic sensing evidence, not an ADC measurement.
- **990** regenerated Chord Ideas: all three scales, 11 patterns, 30 seeds; transport origin, active audition and current voice preserved. All 12 pitch classes observed in Chromatic. Next scheduled chord changes, and cancel/stop still work.
- 30-slot NOR/backup integration: **195 checks**; all 60 sectors unique, old addresses preserved, all 30 save/reboot/GET/PUT, 30-bit occupancy, newest-copy corruption fallback in slot 30, invalid-index no-write, bank cycling/blink/steady, saved high slot, delete of loaded slot 30 and old slots, unrelated-slot preservation, refusal during playback.
- Actual HAL store range macros: **32 checks**, all 20 new sectors accepted, boot/app/updater/unassigned boundaries and wrapping requests refused. New loop bank is 0xE5000..0xF8FFF, with no enlargement into updater staging or globals.
- Python and web clients: 30 names, 48 backup objects, full mocked backup/restore, highest ID 69, size/CRC checks. Web sounds/import tests also pass; obsolete assertions that Prophet ID16 was invalid were updated for the existing 21 stable IDs.
- Existing Step editor: 88 checks; Simple: 582; Prophet USER: 1212; Prophet Bass: 819; Just Keys recorded Bass: 10080; grid editing stress: 12000.
- Creative tools: 4755 randomizer/Undo fixtures and 840 tonal progression fixtures; jazz preview: 13440 interval/name/quality fixtures.
- Settings: 55 passed; boot guard: 91 passed; stub model: 16143 passed; package/stub: 265 passed; USB audio model: 55 passed; power, UART parser, mailbox corruption, loader interruption and OTA models pass.
- C syntax checked with dual core disabled and enabled. This is not target assembly or a linked target image.

The combined reproducible command is `sh tests/run_v8_tests.sh`. Release logs are included under `build/validation/`.

## Scope and limits

The Morph regression runs UBSan with legacy `shift-base` excluded: the unchanged QUAD engine contains signed negative shifts. This is not a clean unrestricted UBSan result. Equivalent multiplications replaced the signed shifts encountered in the FM6 velocity calculation, DC blocker and chorus helper; reference QUAD code was not edited.

`docs/V8-UNCHANGED-INPUTS.json` records hashes of the protected QUAD source, loader/stub and golden/reference files that were byte-compared against V7. Legacy golden audio was not regenerated or validated.

Unknown until target build/hardware tests: exact target XIP/RAM/POOL usage, CPU0/CPU1 peak execution time and stack margin with two heavy patches plus Bass/FX, real physical velocity/calibration, ADC ownership/timing with master and battery sampling, and real USB/LED behavior. The new loop area is unallocated by the supplied source/package map; no physical flash dump was available to independently inspect its prior contents.

No `.fwsc` suitable for installation is included. Host recovery models and an unchanged boot stub do not prove that a real interrupted installation is risk-free. Build on Mac and inspect the target memory/guard report before considering flash.
