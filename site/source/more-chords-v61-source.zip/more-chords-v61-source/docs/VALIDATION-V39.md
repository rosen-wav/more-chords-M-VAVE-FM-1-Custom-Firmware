# V39 host validation

The following host checks passed. The main suite and affected components were rerun after corrections; no existing engine DSP or loop implementation was replaced.

| Check | Result |
|---|---|
| New-engine standalone serial/actual worker comparisons | 50 preset/Bass/FX cases, exact PCM and private state; six voices, 4+2 scheduling |
| Overlapping chords | 250 cases, every new factory, six-note major/minor/inversions, raw keys/MIDI, Bass, rapid retriggers and releases |
| New-engine Morph | 9 six-plus-six/Bass serial/worker PCM/state fixtures |
| Existing Morph regression | 70 real worker cases; endpoint routing/velocity, 990 regenerated ideas and all 12 chromatic roots |
| Integer DSP stress | 72,512,000 samples under UBSan; every MIDI note, factories and all 16 parameter corners; long slow motion and counter wrap |
| USER64 | Twelve engines; native FM6/VA/CZ/QUAD data, Prophet tail, signed CLUSTER and wide Morph controls; reboot, overwrite, delete, favourites and journal rotation |
| Large preset pools | Prophet positions above 255 and CZ position 128, selection and settings encoding |
| NOR interrupted writes | 7,778 payload/header byte cuts; both banks remain recoverable, other sectors unchanged |
| USER extension SysEx | Full 3840-byte GET/PUT/LIST; invalid record refused; isolated deletion |
| Existing full backup | 97 checks, zero failures |
| Desktop/web sounds | Codec bytes match firmware fixtures; import/export/rename/delete and legacy stores |
| Installer / web sound suites | Passed |
| Loop backup clients | 30 loop labels and 50-object archives, including new sound-bank objects |
| Dual-core on/off C syntax | Passed |
| Original engines / loop source | Protected QUAD, Prophet, CLOUD, SWARM, CLUSTER and cr_loop.c byte-identical to V37 |

The isolated x86 host DSP object was also inspected for floating-point arithmetic/conversion instructions: none found. This is not a substitute for checking PI32V2 output. New metadata and backup functions use the project's existing main-loop size optimization; audio render functions are excluded from that optimization.

## Still required

- PI32V2 compilation and final linker success.
- Actual XIP/RAM/POOL/stack map and target helper-symbol inspection.
- Hardware timing and sound tests, including rapid six-note chords, Bass, both Morph banks, FX and USB audio at 48 kHz.
- Real-device saving, power-cycle loading and backup/restore of the new slots.

No FM1 compatibility, target memory margin or realtime CPU percentage is claimed from host results. The ZIP contains source and generated tables, not an installable firmware binary.
