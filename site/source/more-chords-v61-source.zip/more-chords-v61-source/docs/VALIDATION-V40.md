# V40 validation

- 12 real firmware screens: three engines, default/min/max/middle values; all four parameter bindings verified.
- Render checks: text bounds/overlap, chromatic graph coverage, unchanged-screen bypass and 144 cached/full redraw comparisons passed.
- Firmware syntax checks passed with dual core disabled and enabled.
- Default and maximum parameter renders inspected visually.
- Engine DSP, tables, voice allocation, Morph, FX and storage sources byte-identical to V39.

No PI32V2 compiler is available here. Target build, linker, XIP/RAM/POOL limits and hardware performance remain unverified. Illustrations are parameter driven, not live audio analysis.
