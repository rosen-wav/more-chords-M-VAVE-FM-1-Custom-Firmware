# V42 validation

Executed here with GCC host fixtures. No PI32V2 toolchain or FM1 hardware was available.

- DRIFT/TERRAIN:35 exact serial/actual CPU1 PCM+state fixtures;175 overlapping-chord cases;6 Morph6+6+Bass fixtures.
- 90,344,448 integer DSP samples, every factory/MIDI note and all256 macro-panel corners, age wrap and PCM sentinels under UBSan. All eight new SEL controls independently alter deterministic PCM.
- 360 exact serial/CPU1 CLOUD/CLUSTER PCM+state cases, all factories, five Bass engines and three Church widths; Cluster forced to seven oscillators.
- CLOUD:14,942,208 DSP samples under UBSan, factory/extreme panels, window/grain bounds and PCM guards; two grains retained.
- CLUSTER:2,621,440 kernel samples, all16 factories/five pitches and live COUNT/wave/spread/curve changes, normalized gain bounds with seven lanes;4,669,440 additional SWARM/CLUSTER samples under UBSan. No saturated Cluster endpoints in this fixture. This does not guarantee no clipping in a full mix with effects.
- CZ:1,625 overlapping six-note chord cases across all factories, major/minor, inversions, rapid queued retriggers, shared-note releases, raw keys/MIDI, Bass and two CPU1 chord voices.
- Morph:all9 available source-engine A/B endpoints, front-page knob routing, note-offs;63 actual serial/CPU1 Morph+Bass cases and990 live progression regenerations. Manual endpoint fixtures explicitly select Manual; separate fixture verifies Up/Down factory default.
- UI:40 real screens including DRIFT/TERRAIN OSC+SEL, all Morph modes/both pages and four existing-engine examples; text bounds/overlap, unchanged-screen bypass and1,600 cached/full redraw comparisons. Rendered defaults/extremes visually inspected.128 selectable editor screens contain editable controls.
- Church Width:mono return invariant across widths, stereo return changes, width change preserves tail state. Engine level trims tested at the mixer output. Seventh Cluster lane is active. Both legacy and extension USER banks retain all eight DRIFT/TERRAIN controls at signed minimum/maximum corners. Startup envelope has bounded, monotonic gain and the expected silence/ramp duration.
- USER64:64 slots/native blobs, reboot, journal rotation, favourites, deletion, original32 retained;7,778 byte-level interrupted writes;97 backup checks. Python/JavaScript clients pass and factory-binding tables match current firmware, excluding retired ID27.
- Existing just-keys loop Bass regression:10,080 fixtures pass.
- Firmware syntax checks with dual core disabled/enabled pass. Syntax checking does not link PI32V2 helper routines or establish target memory/CPU compatibility.

Remaining: Mac SDL emulator audition, target build/linker/memory checks, hardware stress with Bass/effects/USB, power-on pop test. The codec sequencing change is a mitigation to test, not a verified hardware fix.
