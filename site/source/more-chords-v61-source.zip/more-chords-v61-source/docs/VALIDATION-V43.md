# V43 — Cluster light 7 + Terrain Smooth

Based on the attached V42. Seven CLUSTER oscillators, six voices, 4+2 CPU scheduling, Bass eligibility, output gain and 3 ms replacement bridge preserved. No persistent DSP state or buffers added.

CLUSTER evaluates its seven feedback/waveform lanes once per two output samples, with linear reconstruction. Phase advances retain the original pitch increments. This intentionally softens the upper spectrum and changes feedback timbre; it is not bit-identical to V42. Per-block modulation/history/gain updates remain at their previous rate. Gain division is hoisted out of the lane loop.

Terrain Smooth is included: fractional X/Y slews and interpolated Terrain changes, no phase reset, no added voice state. The narrow ROM-check exception for Terrain's -4194304 immediate is included.

Host validation: 6,225,920 CLUSTER samples with bounds and exact phase-advance comparisons against retained V42 reference; 4,669,440 Swarm/Cluster samples under UBSan; 360 exact serial/actual-worker CPU1 PCM+state cases, all factories, five Bass engines, three Church widths; 4,969,664 Terrain samples under UBSan and unchanged static PCM. Dual-core off/on full-firmware syntax checks passed.

One optimized host run: old CLUSTER kernel 80458 ticks, new 46076 ticks (about 43% less). This is a host microbenchmark, not an FM1 timing guarantee. Target build/link/memory and hardware overload counters must still be checked. Do not infer click elimination from host tests.

## Emulator
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi

## Host regression tests
sh tests/run_v43_tests.sh

The extracted folder is named Choralroot-remix-v43-cluster-light-smooth.

## Morph regression log
```
  hard 127  normal 115  gentle 13
  driven: hard 127  soft 65
  log scale: 410 -> 124, 550 -> 89, 800 -> 43, 950 -> 16
  calibrated: floor 548 ceiling 839 (from 600 / 1000)
sense: ok
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
src=0 A=64 B=64 shadow=1
src=1 A=64 B=64 shadow=1
src=2 A=64 B=64 shadow=1
src=3 A=64 B=64 shadow=1
src=4 A=64 B=64 shadow=1
src=5 A=64 B=64 shadow=1
src=6 A=64 B=64 shadow=1
src=7 A=64 B=64 shadow=1
src=8 A=64 B=64 shadow=1
PASS: front-page Position reaches audible Patch B, pcm=653623 out=271698
PASS: clean Morph Position=0 display and A/B overview and contextual mode
PASS: 9 dual audio morph engine endpoints and note-off routing
PASS: sensor, available dual Morph engines, and both firmware C configurations (syntax only)
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
PASS: 63 real serial/CPU1 Morph+Bass PCM cases; 990 live regenerated ideas, chromatic all 12 roots, retired engines, MIDI velocity preserved

```
