# V46 — CLOUD wavetable banks on ENV

Based on V45: new enlarged boot logo, Prophet excluded from Bass, seven-oscillator light Cluster and Terrain Smooth retained.

## Controls
CLOUD editor -> ENV page 1: Bank (Classic/Warm/Glass/Hollow/Digital), Scan (Off/Up-Down/Forward/Backward), Rate (larger = faster, approximately 0.125..15.9 s/cycle), Depth (bipolar sweep around OSC Wave). ENV page 2 retains the original amp ADSR. OSC Wave is the manual frame position / center of auto scan. Scan Off or Depth zero disables motion. New bank and frame positions are latched at grain creation: existing grains finish their window, so changes crossfade through the grain overlap rather than replacing a live oscillator abruptly. Response depends on grain Size and Density.

## DSP and storage
Classic with Scan Off retains V45 PCM. Four original additive banks, four frames each, 32 samples/frame, six-/two-partial pitch bands. Offline-generated int16 tables, total 2048 bytes. Fixed-point phase and frame interpolation. Pitch band is chosen for the entire grain from both chirp endpoints, preventing mid-grain band jumps. Two grains per voice; unchanged 4+2 standalone and existing six+six Morph policy. New parameters use four per-engine aliases of otherwise inert legacy DIGITAL operator fields; no active CLOUD control or ADSR is overwritten. P_COUNT=91, 192-byte USER records, existing slots, backup/project layouts and engine IDs unchanged. Values save in base and extended USER slots. No extra voice/part arena memory: grain bank/band occupy existing padding, scan phase uses a free voice state word. No floating point in firmware; Python generator is offline only.

Morph regression remains supported; this release does not add new Morph source-selection controls.

## Validation
`sh tests/run_cloud_banks_tests.sh`
- 4,046,848 DSP samples under UBSan: exact Classic PCM, five banks/four scan modes, MIDI notes 0..126, rapid edits, PCM bounds, release cleanup, unchanged state sizes.
- 600 exact actual-worker CPU1 versus serial PCM/state fixtures across Cloud banks/scan and Cluster, factory presets, five Bass engines and Church width.
- ENV knob bindings and navigation; original ADSR preserved; five banks reload through base/extension USER slots; engine-specific descriptors isolated.
- Five real screen states, text bounds/overlap, 25 cached/full redraw comparisons; preview visually checked.
- Existing Morph suite, nine source-engine endpoints and note-off routing passed.
- Dual-core off/on full-firmware host syntax checks and client sound templates passed.
Target PI32V2 build/link/XIP/pool budgets, hardware runtime cost and live transition listening remain to verify. No FM1 performance guarantee from host tests.

## Emulator
source "$HOME/.venv/bin/activate"
sh tools/emu/build.sh
build/host/emu --no-midi

## Host log
```
PASS: 4046848 CLOUD samples; exact Classic reference PCM, five banks/four scan modes, MIDI 0..126, rapid live edits, guards, unchanged arena, release cleanup
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
edit: open part 0
edit: group OSC screen 1 lane 1 part 0
edit: group ENV screen 1 lane 1 part 0
param: part 0 ENV Bank 0 -> 1 (Warm)
param: part 0 ENV Scan 0 -> 1 (Up/Do)
param: part 0 ENV Rate 0 -> 1 (1%)
param: part 0 ENV Depth 0 -> 1 (1%)
param: part 0 ENV ATK 37 -> 38 (16ms)
PASS: CLOUD ENV knobs, two-page navigation, unchanged ADSR, five bank presets base/extension USER reload, descriptors isolated, 192-byte layout unchanged
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
PASS: 600 CLOUD/7-oscillator CLUSTER exact serial/CPU1 PCM+state, all factories, five Bass engines, five banks / scan / Church widths, six voices 4+2
PASS: five CLOUD wavetable screens, text bounds/overlap and 25 cached/full redraw comparisons
  hard 127  normal 115  gentle 13
  driven: hard 127  soft 65
  log scale: 410 -> 124, 550 -> 89, 800 -> 43, 950 -> 16
  calibrated: floor 548 ceiling 839 (from 600 / 1000)
sense: ok
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
src=0 A=64 B=64 shadow=1
src=1 A=64 B=64 shadow=1
src=2 A=64 B=64 shadow=1
src=3 A=64 B=64 shadow=1
src=4 A=64 B=64 shadow=1
src=5 A=64 B=64 shadow=1
src=6 A=64 B=64 shadow=1
src=7 A=64 B=64 shadow=1
src=8 A=64 B=64 shadow=1
PASS: front-page Position reaches audible Patch B, pcm=653623 out=271698
PASS: clean Morph Position=0 display and A/B overview and contextual mode
PASS: 9 dual audio morph engine endpoints and note-off routing
PASS: sensor, available dual Morph engines, and both firmware C configurations (syntax only)
boot: normal reset power-on failed 0 pending 1 counted 0 prev_stage 0 (none)
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
engine: part 0 -> FM6
PASS: 63 real serial/CPU1 Morph+Bass PCM cases; 990 live regenerated ideas, chromatic all 12 roots, retired engines, MIDI velocity preserved

```
