#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);cr_c1_test_serial=1;uint64_t hash=1469598103934665603ull;int32_t pcm[2*CTL];
 for(unsigned pi=0;pi<129;pi++){
  setup(ENGI_KR106,pi,ENGI_FM6,0,6,0);
  for(unsigned j=0;j<NVOICE;j++)kr106_part(0)->voice[j].vcf.noise_seed=12345+j;
  for(unsigned k=0;k<128;k++){
   if(k==16){kr106_patch_of(&trk[0])[16]=19;kr106_patch_of(&trk[0])[18]=79;}
   for(unsigned j=0;j<NPART;j++)engine_block(&trk[j]);mix_block(pcm,CTL);for(unsigned j=0;j<2*CTL;j++)hash=(hash^(uint32_t)pcm[j])*1099511628211ull;
  }
 }
 printf("HASH %llu\n",(unsigned long long)hash);return 0;}
