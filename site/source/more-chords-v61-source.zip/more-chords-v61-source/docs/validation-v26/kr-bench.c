#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include <time.h>
int main(void){emu_fw_options(0,1,0,1);emu_fw_init(0);cr_c1_test_serial=1;cr_dbg.c1=C1_OK;int32_t pcm[2*CTL];double total=0;uint64_t energy=0;
 for(unsigned pi=0;pi<129;pi+=8){setup(ENGI_KR106,pi,ENGI_BASS,0,6,0);trk_all_off(&trk[1]);
  for(unsigned p=0;p<NPART;p++)trk[p].p[P_CHOR]=trk[p].p[P_DLY]=trk[p].p[P_REV]=0;
  unsigned held=0;for(unsigned v=0;v<NVOICE;v++)held+=trk[0].v[v].active&&trk[0].v[v].gate;assert(held==6);
  clock_t t=clock();for(unsigned k=0;k<1500;k++){for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);for(unsigned i=0;i<2*CTL;i++)energy+=llabs(pcm[i]);}
  total+=(double)(clock()-t)/CLOCKS_PER_SEC;
 }
 assert(energy);printf("KR106 six voices,17 panels,25500 blocks: host CPU %.6fs energy %llu\n",total,(unsigned long long)energy);return 0;}
