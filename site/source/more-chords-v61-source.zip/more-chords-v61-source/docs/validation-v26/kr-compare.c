#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
int main(int argc,char **argv){assert(argc==2);FILE *f=fopen(argv[1],"wb");assert(f);emu_fw_options(0,1,0,1);emu_fw_init(0);cr_c1_test_serial=1;cr_dbg.c1=C1_OK;int32_t pcm[2*CTL];
 for(unsigned pi=0;pi<129;pi++){
  setup(ENGI_KR106,pi,ENGI_BASS,0,6,0);trk_all_off(&trk[1]);for(unsigned j=0;j<NVOICE;j++)kr106_part(0)->voice[j].vcf.noise_seed=12345+j;
  for(unsigned p=0;p<NPART;p++)trk[p].p[P_CHOR]=trk[p].p[P_DLY]=trk[p].p[P_REV]=0;
  for(unsigned k=0;k<256;k++){if(k==200)trk_all_off(&trk[0]);for(unsigned p=0;p<NPART;p++)engine_block(&trk[p]);mix_block(pcm,CTL);assert(fwrite(pcm,sizeof pcm,1,f)==1);}
 }
 fclose(f);return 0;}
