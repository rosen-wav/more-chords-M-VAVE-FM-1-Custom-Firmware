#pragma once
/* CZ/Prophet+BASS split: CPU1 on by default; explicit 0 selects serial fallback. */
#ifndef CHORALROOT_DUAL_CORE
#define CHORALROOT_DUAL_CORE 1
#endif

#ifndef CR_CPU1
#define CR_CPU1 CHORALROOT_DUAL_CORE
#endif

/* Stage35: another modest I2S increase; synth control blocks remain 32 frames. */
#ifndef CR_AUDIO_HALF_FRAMES
#define CR_AUDIO_HALF_FRAMES 192u
#endif
