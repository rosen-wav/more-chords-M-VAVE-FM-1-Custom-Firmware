/* SPDX-License-Identifier: GPL-3.0-only
 * Main-loop creative tools. Native setters run with the audio IRQ stopped;
 * no flash writes occur until the ordinary SAVE workflow is used. */
static struct {
 int16_t p[P_COUNT];uint8_t blob[ENG_BLOB_MAX];
 uint32_t rng,observed_crc,feedback_until;uint8_t feedback_undo,pending;uint8_t part,amount,valid,engine,preset,user,edited,focus;
} creative_random __attribute__((section(".pool")));
static struct {uint32_t rng;uint8_t tonic,minor,pattern,focus,ready,peek;} creative_ideas;
static const char *const IDEA_NAMES[]={"Pop","Classic","Journey","Circle","Dream","Surprise","Jazz","Andalusian","Turnaround","Steps","Tritone"};
static const char *const IDEA_NOTES[]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
static uint32_t creative_rand(uint32_t *seed){uint32_t x=*seed?*seed:0x70a519e3u;x^=x<<13;x^=x>>17;x^=x<<5;return *seed=x;}
static const eng_deep_t *creative_deep(track_t *t){return ENGINES[eng_idx(t->eng_req)]->deep;}
static void creative_capture(void)
{
 track_t *t=&trk[creative_random.part];const eng_deep_t *d=creative_deep(t);
 memcpy(creative_random.p,t->p,sizeof t->p);
 if(d && d->blob_get && d->blob_set && d->blob_size<=ENG_BLOB_MAX)d->blob_get(t,creative_random.blob);
 creative_random.engine=t->eng_req;creative_random.preset=t->preset;creative_random.user=t->user;
 creative_random.edited=psnd[creative_random.part].edited;creative_random.valid=1;creative_random.observed_crc=cu_snd_crc(t);
}
static void creative_restore(void)
{
 track_t *t=&trk[creative_random.part];const eng_deep_t *d=creative_deep(t);
 if(d && d->blob_get && d->blob_set && d->blob_size<=ENG_BLOB_MAX)d->blob_set(t,creative_random.blob);
 memcpy(t->p,creative_random.p,sizeof t->p);t->user=creative_random.user;
 psnd[creative_random.part].edited=creative_random.edited;
 if(t->eng_req==ENGI_MORPH)morph_track_loaded(t);
}
static int creative_protected(const param_desc_t *d)
{
 /* Routing, pitch, discrete oscillator selectors and release target levels
  * retain musical identity; amount controls continuous, bounded variation. */
 return d->fmt==F_SEMI || d->fmt==F_OCT || d->fmt==F_NOTE || d->fmt==F_FMNOTE || d->fmt==F_FMFRQ ||
 (d->fmt!=F_CUTOFF && morph_has(d->label,"FREQ")) || morph_has(d->label,"OFS") || morph_has(d->label,"HARM") || morph_has(d->label,"COARSE") || morph_has(d->label,"FINE") || morph_has(d->label,"DET") || morph_has(d->label,"TUN") || morph_has(d->label,"DTN") || morph_has(d->label,"STCK") || morph_has(d->label,"PITCH") || morph_has(d->label,"TRNS") || morph_has(d->label,"TRANS") || morph_has(d->label,"RATIO") || morph_has(d->label,"CHRP") || morph_has(d->label,"CHIRP") || morph_has(d->label,"RATE") || morph_has(d->label,"KEY") || morph_has(d->label,"VSENS") || morph_has(d->label,"RSCL") || morph_has(d->label,"OCT") || morph_has(d->label,"SEMI") || morph_protected(d) || morph_has(d->label,"L4") || morph_has(d->label,"EGL4") || morph_has(d->label,"PORT") || (d->label[0]=='O' && d->label[1]=='N' && !d->label[2]) || (d->label[0]=='A' && d->label[1]=='M' && d->label[2]=='S' && !d->label[3]);
}
static int32_t creative_value(int32_t base,const param_desc_t *d)
{
 int32_t range=d->max-d->min;
 int32_t span=range*creative_random.amount/1000;
 /* Scale in parameter units: 16-bit controls need more than 24 raw steps. */
 int32_t limit=(range*10+126)/127;
 if(span>limit)span=limit;
 if(morph_has(d->label,"SPREAD") || morph_has(d->label,"SPRD") || morph_has(d->label,"DRIFT"))span/=4;
 if(!span && creative_random.amount && range>0)span=1;
 if(!span)return base;
 int32_t lo=clamp(base-span,d->min,d->max),hi=clamp(base+span,d->min,d->max);
 if(morph_has(d->label,"LEV") || morph_has(d->label,"LEVEL") || morph_has(d->label,"SUS") || morph_has(d->label,"MIX") || morph_has(d->label,"GAIN")){
  if(!base)return base;
  if(base>0 && lo<base/2)lo=base/2;
 }
 if(lo>hi)return clamp(base,d->min,d->max);
 /* Exclude the original value whenever a real alternative exists. */
 if(hi>lo && base>=lo && base<=hi){
  int32_t v=lo+(int32_t)(creative_rand(&creative_random.rng)%(uint32_t)(hi-lo));
  return v>=base?v+1:v;
 }
 return lo;
}
static void creative_random_action(int undo)
{
 track_t *t=&trk[creative_random.part];const engine_t *e=ENGINES[eng_idx(t->eng_req)];const eng_deep_t *d=e->deep;
 fm1_irq_off();
 if(!creative_random.valid || creative_random.engine!=t->eng_req || creative_random.preset!=t->preset || cu_snd_crc(t)!=creative_random.observed_crc || (t->user && t->user!=creative_random.user))creative_capture();
 creative_restore();
 if(!undo && creative_random.amount){
  if(t->eng_req==ENGI_MORPH){
   static const uint8_t id[]={P_E2,P_E5};
   for(uint32_t i=0;i<NELEM(id);i++){const param_desc_t *pd=&ENG_MORPH.edit[id[i]-P_E0];t->p[id[i]]=(int16_t)creative_value(t->p[id[i]],pd);}
   morph_track_loaded(t);
  }else if(d && d->get && d->set){
   /* Sections 3+ contain native LFO and modulation/function settings. */
   uint32_t end=d->section[3]<d->npages?d->section[3]:d->npages;
   for(uint32_t pg=0;pg<d->npages;pg++)for(uint32_t c=0;c<4;c++){
    if(pg>=end)continue;
    if(morph_has(d->pages[pg].title,"PITCH"))continue;
    const param_desc_t *pd=d->desc?d->desc(t,pg,c):0;if(!pd)pd=&d->pages[pg].col[c];
    if(pd->max<=pd->min || creative_protected(pd))continue;
    int32_t value=d->get(t,pg,c);d->set(t,pg,c,creative_value(value,pd));
   }
  }else for(uint32_t k=0;k<8;k++){
   const param_desc_t *pd=e->desc?e->desc(t,k):0;if(!pd)pd=&e->edit[k];
   if(pd->max>pd->min && !creative_protected(pd))t->p[P_E0+k]=(int16_t)creative_value(t->p[P_E0+k],pd);
  }
  if(t->eng_req!=ENGI_MORPH){
   static const uint8_t id[]={P_ATK,P_DEC,P_SUS,P_REL};
   for(uint32_t i=0;i<NELEM(id);i++)t->p[id[i]]=(int16_t)creative_value(t->p[id[i]],&TP[id[i]]);
  }
  /* Native macro mirrors may also touch the generic send controls. Keep the
   * current effect mix, master/part level and voice mode exactly as before. */
  static const uint8_t keep[]={P_CHOR,P_REV,P_DLY,P_DIST,P_LEVEL,P_VOICE};
  for(uint32_t i=0;i<NELEM(keep);i++)t->p[keep[i]]=creative_random.p[keep[i]];
  /* Preserve shared LFO, envelope routing and the complete mod matrix,
   * including any generic mirrors updated by native setters. */
  for(uint32_t i=P_ED_FLT;i<=P_LD_AMP;i++)t->p[i]=creative_random.p[i];
  for(uint32_t i=P_M1SRC;i<=P_M4AMT;i++)t->p[i]=creative_random.p[i];
  /* Existing subtle vibrato only; never introduce a new pitch route. */
  int32_t vib=creative_random.p[P_LD_PIT];
  if(t->eng_req!=ENGI_MORPH && vib && vib>=-8 && vib<=8)
   t->p[P_LD_PIT]=(int16_t)clamp(vib+(creative_rand(&creative_random.rng)&1u?1:-1),vib<0?-8:1,vib<0?-1:8);
  cu_edited(creative_random.part);
 }
 creative_random.observed_crc=cu_snd_crc(t);panic_req|=(uint8_t)(1u<<creative_random.part);fm1_irq_on();
 creative_random.pending=(uint8_t)!undo;
 creative_random.feedback_until=cu_now()+500u;creative_random.feedback_undo=(uint8_t)undo;
 cu_message(undo?"original restored":"Preset generated",CR_COL_GREEN);
}
static void creative_open_random(void)
{
 if(cu.page!=PG_EDIT)return;
 creative_random.part=ce.part&1u;cu.lock=L_NONE;cu.opt_open=0;cu.pop.until=0;cu.page=PG_RANDOMIZER;
 if(!creative_random.amount)creative_random.amount=40;
 creative_random.valid=0;creative_random.focus=0;creative_random.pending=0;
 fm1_irq_off();creative_capture();fm1_irq_on();
}
static void creative_close_random(void){
 if(creative_random.pending && trk[creative_random.part].eng_req==creative_random.engine && cu_snd_crc(&trk[creative_random.part])==creative_random.observed_crc){fm1_irq_off();creative_restore();creative_random.observed_crc=cu_snd_crc(&trk[creative_random.part]);panic_req|=(uint8_t)(1u<<creative_random.part);fm1_irq_on();}
 creative_random.pending=0;creative_random.feedback_until=0;cu.page=PG_EDIT;cu.lock=L_NONE;cu.pop.until=0;
}
static int creative_random_pending(void){return creative_random.pending;}
static void creative_confirm_random(void){
 if(!creative_random.pending){cu_message("turn Generate first",CR_COL_WHITE);return;}
 if(trk[creative_random.part].eng_req!=creative_random.engine || cu_snd_crc(&trk[creative_random.part])!=creative_random.observed_crc){creative_close_random();cu_message("preset changed: generate again",CR_COL_ORANGE);return;}
 creative_random.pending=0;creative_random.valid=0;creative_close_random();cu_message("Preset confirmed",CR_COL_GREEN);
}
static void creative_cancel_ideas(void)
{
 fm1_irq_off();cr_idea_stop();cr_idea.token++;
 if(creative_ideas.ready && crl_stage_busy==3u)crl_stage_busy=0;fm1_irq_on();
 creative_ideas.ready=0;
}
/* Tonal color: at most two extension notes, exclusive minor/major sevenths.
 * The V chord is dominant (also in minor, borrowing harmonic minor).
 * Suspensions occur on V; diminished ii/vii use the actual half-diminished 7. */
static uint8_t creative_harmony(uint32_t degree){
 static const uint8_t major_q[]={CR_Q_MAJ,CR_Q_MIN,CR_Q_MIN,CR_Q_MAJ,CR_Q_MAJ,CR_Q_MIN,CR_Q_DIM};
 static const uint8_t minor_q[]={CR_Q_MIN,CR_Q_DIM,CR_Q_MAJ,CR_Q_MIN,CR_Q_MAJ,CR_Q_MAJ,CR_Q_MAJ};
 uint32_t pick=creative_rand(&creative_ideas.rng)%6u;uint8_t q=creative_ideas.minor==1u?minor_q[degree]:major_q[degree],ext=0;
 if(creative_ideas.minor==2u){
  static const uint8_t qualities[]={CR_Q_MAJ,CR_Q_MIN,CR_Q_SUS,CR_Q_DIM};
  static const uint8_t colors[]={0,CR_EXT_6,CR_EXT_M7,CR_EXT_MAJ7,CR_EXT_M7|CR_EXT_9,CR_EXT_MAJ7|CR_EXT_9};
  q=qualities[creative_rand(&creative_ideas.rng)%4u];ext=colors[pick];
  if(q==CR_Q_DIM)ext=CR_EXT_M7;
  return (uint8_t)((q<<4)|ext);
 }
 if(degree==4u){q=(pick==0||pick==5)?CR_Q_SUS:CR_Q_MAJ;ext=CR_EXT_M7;if(pick>=3)ext|=CR_EXT_9;}
 else if(q==CR_Q_DIM)ext=pick==0 && creative_ideas.pattern!=6u?0:CR_EXT_M7;
 else if(q==CR_Q_MAJ){static const uint8_t colors[]={CR_EXT_6,CR_EXT_MAJ7,CR_EXT_MAJ7|CR_EXT_9,CR_EXT_6|CR_EXT_9,CR_EXT_MAJ7,CR_EXT_MAJ7|CR_EXT_9};ext=colors[pick];if(creative_ideas.minor && degree==6u)ext=CR_EXT_M7|(pick>=3?CR_EXT_9:0);}
 else {ext=CR_EXT_M7;if(pick>=3 && (creative_ideas.minor || degree!=2u))ext|=CR_EXT_9;if(creative_ideas.minor && degree==0u){if(pick==0)ext=CR_EXT_6;else if(pick==1)ext=CR_EXT_MAJ7;else if(pick==4)ext=CR_EXT_M7;else if(pick==2)ext=CR_EXT_MAJ7|CR_EXT_9;}}
 return (uint8_t)((q<<4)|ext);
}
static void creative_chord_label(const crl_ev_t *ev,char *out,uint32_t size){
 uint32_t q=ev->qx>>4,ext=ev->qx&15u;const char *suffix="";
 if(q==CR_Q_DIM)suffix=ext&CR_EXT_M7?"m7b5":"dim";
 else if(q==CR_Q_SUS)suffix=ext&CR_EXT_9?"sus9":ext&CR_EXT_M7?"sus7":"sus";
 else if(q==CR_Q_MIN){suffix=ext&CR_EXT_MAJ7?(ext&CR_EXT_9?"mM9":"mM7"):ext&CR_EXT_M7?(ext&CR_EXT_9?"m9":"m7"):ext&CR_EXT_6?(ext&CR_EXT_9?"m6/9":"m6"):ext&CR_EXT_9?"madd9":"m";}
 else suffix=ext&CR_EXT_MAJ7?(ext&CR_EXT_9?"maj9":"maj7"):ext&CR_EXT_M7?(ext&CR_EXT_9?"9":"7"):ext&CR_EXT_6?(ext&CR_EXT_9?"6/9":"6"):ext&CR_EXT_9?"add9":"";
 cu_cpy(out,IDEA_NOTES[ev->root%12u],size);cu_cat(out,suffix,size);
}
static void creative_generate(void)
{
 if(crl_stage_busy && crl_stage_busy!=3u){cu_message("loop load pending",CR_COL_RED);return;}
 if(cr_snap.lcap!=CRL_CAP_NONE){cu_message("finish recording first",CR_COL_RED);return;}
 static const uint8_t prog[11][4]={{0,4,5,3},{0,3,4,0},{0,5,1,4},{5,1,4,0},{0,2,3,4},{0,0,0,0},{1,4,0,5},{0,6,5,4},{2,5,1,4},{0,1,2,3},{1,4,0,5}};
 static const uint8_t major[]={0,2,4,5,7,9,11},minor[]={0,2,3,5,7,8,10};
 static const uint8_t bars[]={2,1,2,4,8};
 uint32_t len=bars[cs.loop_len<5u?cs.loop_len:2u]*4u*CRL_PPQN;
 crl_ev_t next[4];
 for(uint32_t i=0;i<4u;i++){
  uint32_t pattern=creative_ideas.pattern<NELEM(IDEA_NAMES)?creative_ideas.pattern:0u;
  uint32_t deg=pattern!=5u?prog[pattern][i]:creative_rand(&creative_ideas.rng)%7u;
  if(pattern==5u && !i)deg=0;
  static const uint8_t chromatic[11][4]={
   {0,7,10,5},{0,5,7,1},{0,8,2,7},{9,2,7,0},{0,4,6,8},
   {0,0,0,0},{2,7,0,9},{0,10,8,7},{4,9,2,7},{0,1,2,3},{2,1,0,9}};
  uint32_t interval=creative_ideas.minor==2u?(pattern==5u?(i?creative_rand(&creative_ideas.rng)%12u:0u):chromatic[pattern][i]):creative_ideas.minor==1u?minor[deg]:major[deg];
  if(pattern==10u && i==1u)interval=1u; /* bII7 substitutes V7 */
  next[i]=(crl_ev_t){0};next[i].t=(uint16_t)(i*len/4u);next[i].dur=(uint16_t)(len/4u);
  next[i].root=(uint8_t)(48u+creative_ideas.tonic+interval);next[i].vel=100;next[i].qx=creative_harmony(deg);
  if(pattern==10u && i==1u)next[i].qx=(CR_Q_MAJ<<4)|CR_EXT_M7|CR_EXT_9;
 }
 fm1_irq_off();
 /* Keep the running chord and transport phase; replacement is atomic to audio.
  * The next scheduled chord uses the new idea, without a stop or retrigger. */
 if(!creative_ideas.ready){cr_idea_stop();memset(&crl_stage,0,sizeof crl_stage);}
 cr_idea.token++;crl_stage_busy=3;
 crl_stage.len=len;crl_stage.sig=CRL_SIG_44;crl_stage.grid_global=1;
 /* Ideas use the editor's quarter-note grid and selected loop length. */
 crl_stage.grid_n=(uint8_t)(len/CRL_PPQN);
 for(uint32_t i=0;i<crl_stage.grid_n;i++)crl_stage.grid_dur[i]=2;crl_stage.nlayers=1;crl_stage.nev=4;
 memcpy(crl_stage.ev,next,sizeof next);
 creative_ideas.peek=0;creative_ideas.ready=1;RING_PUBLISH();fm1_irq_on();
}
static void creative_open_ideas(void)
{
 if(cs.save_pending){cu_message("finish pending save first",CR_COL_RED);return;}
 if(crl_stage_busy){cu_message("loop load pending",CR_COL_RED);return;}
 cu_grid_preview_stop();cu.pop.until=0;cu.opt_open=0;cu.page=PG_IDEAS;cu.lock=L_NONE;
 creative_ideas.focus=0;creative_generate();
}
static void creative_preview_play(void){
 if(creative_ideas.ready && crl_stage_busy==3u)cr_post(CRE_LOOP,LP_IDEA,0,cr_idea.token);
}
static void creative_back_ideas(void){creative_cancel_ideas();cu.page=PG_NONE;if(cu.step_editor)cu.lock=L_METRO;}
static void creative_accept(void)
{
 if(!creative_ideas.ready)return;
 if(crl_stage_busy!=3u){creative_ideas.ready=0;cu_message("preview expired: turn New idea",CR_COL_RED);return;}
 if(cr_snap.lcap!=CRL_CAP_NONE){cu_message("stop PLAY before applying",CR_COL_RED);return;}
 fm1_irq_off();cr_idea_stop();cr_idea.token++;fm1_irq_on();
 if(cr_post(CRE_LOOP,LP_SET,0,1)){
  crl_stage_busy=1;creative_ideas.ready=0;cu.page=PG_NONE;
  cu.step_editor=1;cu.grid_sel=0;cu.lock=L_METRO;cr_post(CRE_LOOP,LP_CONF,LC_GRID_OPEN,1);
  cu_message("new idea: PLAY / SAVE",CR_COL_GREEN);
 }
}
static int creative_knob(uint32_t role,int32_t delta)
{
 if(cu.page==PG_RANDOMIZER){
  if(role==EN_PRESET){creative_close_random();return 0;}
  if(role>=EN_K1 && role<=EN_K4)creative_random.focus=(uint8_t)(role-EN_K1);
  if(role==EN_K1)creative_random.amount=(uint8_t)clamp((int32_t)creative_random.amount+delta,0,100);
  /* Part is informational: randomize only the preset opened in EDIT. */
  if(role==EN_K3 && delta)creative_random_action(0);
  if(role==EN_K4 && delta)creative_random_action(1);
  return role!=EN_PRESET;
 }
 if(cu.page==PG_IDEAS){
  if(role==EN_SELECT){creative_ideas.peek=(uint8_t)clamp((int32_t)creative_ideas.peek+delta,0,3);return 1;}
  if(role>=EN_K1 && role<=EN_K4)creative_ideas.focus=(uint8_t)(role-EN_K1);
  if(role==EN_K1)creative_ideas.tonic=(uint8_t)clamp((int32_t)creative_ideas.tonic+delta,0,11);
  if(role==EN_K2)creative_ideas.minor=(uint8_t)clamp((int32_t)creative_ideas.minor+delta,0,2);
  if(role==EN_K3)creative_ideas.pattern=(uint8_t)clamp((int32_t)creative_ideas.pattern+delta,0,(int32_t)NELEM(IDEA_NAMES)-1);
  if(role>=EN_K1 && role<=EN_K4 && delta)creative_generate();
  return role!=EN_PRESET;
 }
 return 0;
}
static void creative_screen(cr_screen_t *s)
{
 if(creative_ideas.ready && crl_stage_busy!=3u)creative_ideas.ready=0;
 const int ideas=cu.page==PG_IDEAS;uint32_t focus=ideas?creative_ideas.focus:creative_random.focus;
 s->kind=CR_K_KNOBROW;s->orient=1;s->n_items=1;s->header=0;s->ring_on=0;s->hot_r=1;s->hot_c=(uint8_t)focus;
 s->col=ideas?CR_COL_BLUE:CR_COL_ORANGE;
 const char *labels[4]={ideas?"Tonic":"Amount",ideas?"Scale":"Part",ideas?"Pattern":"Generate",ideas?"New idea":"Undo"};
 char amount[8];cu_int(amount,creative_random.amount,0,sizeof amount);cu_cat(amount,"%",sizeof amount);
 const char *values[4]={ideas?IDEA_NOTES[creative_ideas.tonic]:amount,ideas?(creative_ideas.minor==2u?"Chromatic":creative_ideas.minor==1u?"Minor":"Major"):(creative_random.part?"Bass":"Chords"),ideas?IDEA_NAMES[creative_ideas.pattern]:"Turn",ideas?"Turn":"Turn"};
 cu_cpy(s->page,ideas?"IDEAS":"EDIT",sizeof s->page);
 cu_cpy(s->title,ideas?"Chord Ideas":"Preset Randomizer",sizeof s->title);
 cu_cpy(s->label,"",sizeof s->label);cu_cat(s->label,labels[focus],sizeof s->label);cu_cpy(s->item[0],values[focus],sizeof s->item[0]);
 for(uint32_t k=0;k<4;k++){
  cr_cell_t *c=&s->cell[0][k];c->flags=CR_CF_ON;c->glyph=k?CR_G_DOTS:CR_G_KNOB;
  if(!ideas && k==1u)c->glyph=CR_G_NONE;
  cu_cpy(c->label,labels[k],sizeof c->label);cu_cpy(c->value,values[k],sizeof c->value);
  c->pct=ideas?(k==0?creative_ideas.tonic*255u/11u:k==1?creative_ideas.minor*255u/2u:k==2?creative_ideas.pattern*255u/(NELEM(IDEA_NAMES)-1u):0u):k==0?creative_random.amount*255u/100u:0u;
 }
 if(ideas && creative_ideas.ready){
  s->n_items=4;s->sel=cr_idea.active?cr_idea.index:creative_ideas.peek;
  cu_cpy(s->label,cr_idea.active?"Playing":"Generated chords",sizeof s->label);
  for(uint32_t i=0;i<4;i++)creative_chord_label(&crl_stage.ev[i],s->item[i],sizeof s->item[i]);
  cu_cpy(s->value,cr_idea.active?"Playing ":"Chord ",sizeof s->value);
  char pos[4];cu_int(pos,(int32_t)s->sel+1,0,sizeof pos);cu_cat(s->value,pos,sizeof s->value);cu_cat(s->value," / 4",sizeof s->value);
 }else if(!ideas)cu_cpy(s->value,psnd[creative_random.part].name,sizeof s->value);
 if(!ideas){
  if(creative_random.pending)cu_cpy(s->cell[0][2].value,"Ready",sizeof s->cell[0][2].value);
  if((int32_t)(creative_random.feedback_until-cu_now())>0){
   s->hot_r=1;s->hot_c=creative_random.feedback_undo?3:2;s->col=CR_COL_GREEN;
   cu_cpy(s->label,creative_random.feedback_undo?"Restored":"Preset generated",sizeof s->label);
   cu_cpy(s->item[0],"",sizeof s->item[0]);
  }
 }
 cu_cpy(s->footer,ideas?(cr_idea.active?"PLAY: stop  OCT+: edit  REC: back":cr_idea.armed?"Waiting clock  PLAY: cancel":"PLAY: listen  OCT+: edit  REC: back"):"OCT+: confirm  OCT-: cancel",sizeof s->footer);
}
