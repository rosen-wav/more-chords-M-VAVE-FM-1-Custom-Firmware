/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the semantic looper (cr_loop.h, docs/LOOPER.md). The grid version's d_cr_loop.lua and
 * design.md section 14, with bar sync, the count-in, quantize on commit and beat-relative time added.
 *
 * Time: lp->t counts ticks (CRL_PPQN per quarter) of the engine's tempo, derived from the ms clock with the
 * remainder kept (no drift). Recording stores, per gesture, its on tick relative to the loop start and its length
 * in ticks; playback compares positions in the cycle, so a BPM change moves the loop's speed at once.
 * Capture: the engine's gesture hook (cr_out_t.gesture) says when a chord gesture begins and ends, with its final
 * resolved chord at the end; an event is written when the gesture ends (or when the capture ends with it held). */
#include <stddef.h>
#ifndef CR_LOOP_H
#include "cr_loop.h"
#endif

static const uint8_t CRL_BARS[CRL_NSYNC] = {0, 1, 2, 4, 8};
static const uint8_t CRL_QGRID[CRL_NQUANT] = {0, 96, 48, 32, 24, 16, 12};

static void crl_zero(void *p, uint32_t n)
{
    uint8_t *b = (uint8_t *)p;
    while (n--) *b++ = 0;
}
static void crl_copy(void *d, const void *s, uint32_t n)
{
    uint8_t *a = (uint8_t *)d;
    const uint8_t *b = (const uint8_t *)s;
    while (n--) *a++ = *b++;
}
static uint32_t crl_data_size(uint32_t nev) { return (uint32_t)(offsetof(crl_data_t,ev) + sizeof(crl_ev_t)*nev); }

uint32_t cr_loop_bar(const cr_loop_t *lp) { return lp->sig == CRL_SIG_44 ? 4u * CRL_PPQN : 3u * CRL_PPQN; }
uint32_t cr_loop_beat(const cr_loop_t *lp) { return lp->sig == CRL_SIG_68 ? CRL_PPQN / 2u : CRL_PPQN; }
int cr_loop_layers(const cr_loop_t *lp) { return lp->d.nlayers; }

void cr_loop_init(cr_loop_t *lp)
{
    crl_zero(lp, sizeof *lp);
    lp->count_in = 1;
    lp->level = 100;
    lp->metro_vol = 70;
    lp->state = CRL_EMPTY;
}

/* ------------------------------------------------------------ playback --- */
static void crl_voices_off(cr_loop_t *lp, cr_t *c)
{
    int lv;
    for (lv = 0; lv < CR_MAX_LOOPV; lv++)
        if (lp->pv[lv].used) {
            cr_loop_event(c, lv, 0, 0, 0, 0, 0);
            lp->pv[lv].used = 0;
        }
}

static void crl_play_ev(cr_loop_t *lp, cr_t *c, const crl_ev_t *e, uint32_t idx)
{
    int lv, best = -1;
    uint32_t vel = (uint32_t)e->vel * lp->level / 100u;
    if (!vel) return;
    for (lv = 0; lv < CR_MAX_LOOPV; lv++)
        if (!lp->pv[lv].used) { best = lv; break; }
    if (best < 0)                                   /* all busy: the one that would end first */
        for (lv = 0; lv < CR_MAX_LOOPV; lv++)
            if (best < 0 || (int32_t)(lp->pv[lv].off - lp->pv[best].off) < 0) best = lv;
    cr_loop_event(c, best, e->root, (uint8_t)(e->qx >> 4), (uint8_t)(e->qx & 15u), (uint8_t)vel, 1);
    lp->pv[best].used = 1;
    lp->pv[best].ev = (uint16_t)idx;
    lp->pv[best].off = lp->t + (e->dur ? e->dur : 1u);
    lp->played++;
}

static void crl_hide(cr_loop_t *lp, uint32_t i)    /* Replace: event i hidden by the layer being recorded */
{
    lp->d.ev[i].layer = (uint8_t)(CRL_HID | lp->d.nlayers);
    lp->gen++;
}

static void crl_fire(cr_loop_t *lp, cr_t *c, uint32_t lo, uint32_t hi)   /* events at positions lo..hi */
{
    uint32_t i;
    int hiding = lp->cap == CRL_CAP_OD && lp->rep && lp->rep_n;   /* Replace, a gesture held: what starts is erased */
    for (i = 0; i < lp->d.nev; i++) {
        const crl_ev_t *e = &lp->d.ev[i];
        if ((e->layer & CRL_HID) || e->t < lo || e->t > hi) continue;
        if (hiding && i < lp->layer_ev0) crl_hide(lp, i);
        else crl_play_ev(lp, c, e, i);
    }
}

/* each layer's first event, from the layers of a loop with no hidden events (a load) */
static void crl_lev0_scan(cr_loop_t *lp)
{
    uint32_t l, i = 0;
    for (l = 0; l < CRL_MAX_LAYERS; l++) {
        while (i < lp->d.nev && (lp->d.ev[i].layer & 0x1Fu) < l) i++;
        lp->lev0[l] = (uint16_t)i;
    }
}

/* undo of layer L: the events it hid come back, in their own layers (by their place: the array is in layer order) */
static void crl_restore(cr_loop_t *lp, uint32_t L)
{
    uint32_t i, l;
    for (i = 0; i < lp->d.nev; i++)
        if (lp->d.ev[i].layer == (uint8_t)(CRL_HID | L)) {
            for (l = L ? L - 1u : 0u; l && lp->lev0[l] > i; l--) {}
            lp->d.ev[i].layer = (uint8_t)l;
            lp->gen++;
        }
}

static void crl_offs(cr_loop_t *lp, cr_t *c)
{
    int lv;
    for (lv = 0; lv < CR_MAX_LOOPV; lv++) {
        if (!lp->pv[lv].used) continue;
        if (!cr_loop_busy(c, lv)) lp->pv[lv].used = 0;            /* (a panic took it) */
        else if ((int32_t)(lp->t - lp->pv[lv].off) >= 0) {
            cr_loop_event(c, lv, 0, 0, 0, 0, 0);
            lp->pv[lv].used = 0;
        }
    }
}

static void crl_take_next(cr_loop_t *lp)            /* a queued slot replaces the loop at the cycle's end */
{
    const crl_data_t *n = lp->next;
    lp->next = 0;
    if (n && n->len && n->nev) crl_copy(&lp->d, n, crl_data_size(n->nev));
    else crl_zero(&lp->d, crl_data_size(0));
    if(lp->d.grid_global){uint32_t bars=lp->d.len/(4u*CRL_PPQN);lp->sync=(uint8_t)(bars==1?1u:bars==2?2u:bars==4?3u:4u);}
    crl_lev0_scan(lp);
    lp->gen++;
    lp->dirty = 0;
    lp->loads++;
    if (!lp->d.len) lp->state = CRL_EMPTY;
}

static void crl_play_upto(cr_loop_t *lp, cr_t *c)
{
    uint32_t pos;
    if (lp->state != CRL_PLAYING || !lp->d.len) return;
    pos = lp->t - lp->cyc0;
    while (pos >= lp->d.len) {
        if (lp->scan < lp->d.len) crl_fire(lp, c, lp->scan, lp->d.len - 1u);
        pos -= lp->d.len;
        lp->cyc0 += lp->d.len;
        lp->scan = 0;
        if (lp->next_on) {
            lp->next_on = 0;
            crl_take_next(lp);
            if (lp->state != CRL_PLAYING || !lp->d.len) return;
            if (pos >= lp->d.len) pos %= lp->d.len;
        }
    }
    if (lp->scan <= pos) {
        crl_fire(lp, c, lp->scan, pos);
        lp->scan = pos + 1u;
    }
}

static void crl_start(cr_loop_t *lp, cr_t *c)
{
    lp->play_armed = 0;
    lp->state = CRL_PLAYING;
    lp->cyc0 = lp->t;
    lp->scan = 0;
    crl_play_upto(lp, c);
    if (lp->metro) lp->click = 2;                    /* the grid restarts here: its first beat now */
}

/* ------------------------------------------------------------- capture --- */
static void crl_write(cr_loop_t *lp, uint32_t t0, int16_t root, uint8_t q, uint8_t ext, uint8_t vel)
{
    crl_ev_t *e;
    uint32_t start = t0, rel, dur;
    if (lp->cap == CRL_CAP_REC) {
        if ((int32_t)(lp->t - lp->rec0) < 0) return;                   /* ended in the count-in */
        if ((int32_t)(start - lp->rec0) < 0) start = lp->rec0;        /* held into the take: from its start */
        rel = start - lp->rec0;
        if ((lp->rec_len && rel >= lp->rec_len) || rel >= CRL_MAX_LEN) return;
    } else if (lp->cap == CRL_CAP_OD && lp->d.len) {
        int32_t r;
        if ((int32_t)(start - lp->od0) < 0) start = lp->od0;
        r = (int32_t)(start - lp->cyc0) % (int32_t)lp->d.len;
        rel = (uint32_t)(r < 0 ? r + (int32_t)lp->d.len : r);
    } else if (lp->cap == CRL_CAP_STEP) {                              /* at the cursor, one step long */
        rel = (uint32_t)lp->step * lp->step_g;
        start = lp->t - lp->step_g;
    } else {
        return;
    }
    if (lp->d.nev >= CRL_MAX_EV) { lp->full = 1; return; }
    dur = lp->t - start;
    dur = dur < 1u ? 1u : dur > CRL_MAX_LEN ? CRL_MAX_LEN : dur;
    if (lp->cap == CRL_CAP_STEP) {
        lp->step_w = 1;
        if (lp->step + 1u > lp->step_end) lp->step_end = (uint16_t)(lp->step + 1u);
    }
    lp->gen++;
    e = &lp->d.ev[lp->d.nev++];
    e->t = (uint16_t)rel;
    e->dur = (uint16_t)dur;
    e->root = (uint8_t)(root < 0 ? 0 : root > 127 ? 127 : root);
    e->vel = (uint8_t)(vel ? vel : 1u);
    e->qx = (uint8_t)((q < CR_Q_COUNT ? q : 0u) << 4 | (ext & 15u));
    e->layer = lp->d.nlayers;
    if (lp->d.nev >= CRL_MAX_EV) lp->full = 1;
}

/* a fresh take starts: Overwrite's loop goes now (not on arming: REC again before this keeps it) */
static void crl_take_start(cr_loop_t *lp)
{
    if (!lp->ow) return;
    lp->ow = 0;
    lp->d.grid_global = 0; lp->d.grid_n = 0;
    lp->d.nev = 0;
    lp->d.len = 0;
    lp->d.nlayers = 0;
    lp->state = CRL_EMPTY;
    lp->next_on = 0;
    lp->dirty = 1;
    lp->gen++;
}

/* Replace: a gesture begins at cycle position p: an older event sounding there is cut at p (it is hidden, and a copy
 * ending at p goes into the new layer: undo brings the whole one back) and its voice ends */
static void crl_cut(cr_loop_t *lp)
{
    uint32_t p = (lp->t - lp->cyc0) % lp->d.len, i, lv, n = lp->layer_ev0;
    for (i = 0; i < n; i++) {
        crl_ev_t *e = &lp->d.ev[i];
        uint32_t rel;
        if (e->layer & CRL_HID) continue;
        rel = (p + lp->d.len - e->t) % lp->d.len;
        if (!rel || rel >= e->dur) continue;
        if (lp->d.nev >= CRL_MAX_EV) { lp->full = 1; return; }
        lp->d.ev[lp->d.nev] = *e;
        lp->d.ev[lp->d.nev].dur = (uint16_t)rel;
        lp->d.ev[lp->d.nev].layer = lp->d.nlayers;
        lp->d.nev++;
        crl_hide(lp, i);
        for (lv = 0; lv < CR_MAX_LOOPV; lv++)
            if (lp->pv[lv].used && lp->pv[lv].ev == i) lp->pv[lv].off = lp->t;   /* (crl_offs ends it) */
    }
}

void cr_loop_gesture(cr_loop_t *lp, uint32_t gid, int16_t root, uint8_t q, uint8_t ext, uint8_t vel, int on)
{
    uint32_t i, k = CRL_OPEN;
    /* Only manual/pad gestures reach this hook, never loop replay. The release
     * carries the final live-edited quality/extensions as well. */
    if (root >= 0 && root <= 127 && q < CR_Q_COUNT && vel) {
        lp->grid_last_valid = 1; lp->grid_last_root = (uint8_t)root;
        lp->grid_last_qx = (uint8_t)((q << 4) | (ext & 15u)); lp->grid_last_vel = vel;
    }
    if (lp->grid_editor && lp->cap == CRL_CAP_STEP) return;
    if (on) {
        for (i = 0; i < CRL_OPEN; i++)
            if (!lp->open[i].used) { k = i; break; }
        if (k == CRL_OPEN)                                             /* full: the oldest goes */
            for (i = k = 0; i < CRL_OPEN; i++)
                if ((int32_t)(lp->open[i].t0 - lp->open[k].t0) < 0) k = i;
        lp->open[k].used = 1;
        lp->open[k].gid = gid;
        lp->open[k].t0 = lp->t;
        lp->open[k].root = root;                                       /* (for a capture ending while held) */
        lp->open[k].q = q;
        lp->open[k].ext = ext;
        lp->open[k].vel = vel;
        lp->open[k].rep = 0;
        if (lp->cap == CRL_CAP_ARMED) {                                /* Free: the first chord starts the take */
            crl_take_start(lp);
            lp->cap = CRL_CAP_REC;
            lp->rec0 = lp->t;
            lp->rec_len = 0;
            lp->layer_ev0 = 0;
            lp->open[k].t0 = lp->t;
        } else if (lp->cap == CRL_CAP_OD_ARMED) {                      /* the first chord opens the layer */
            lp->cap = CRL_CAP_OD;
            lp->od0 = lp->t;
            lp->layer_ev0 = lp->d.nev;
        }
        if (lp->cap == CRL_CAP_OD && lp->rep && lp->state == CRL_PLAYING && lp->d.len) {   /* Replace: a held span */
            lp->open[k].rep = 1;
            if (!lp->rep_n++) lp->rep0 = (lp->t - lp->cyc0) % lp->d.len;
            crl_cut(lp);
        }
        if (lp->cap != CRL_CAP_NONE) lp->gen++;
        return;
    }
    for (i = 0; i < CRL_OPEN; i++)
        if (lp->open[i].used && lp->open[i].gid == gid) {
            lp->open[i].used = 0;
            if (lp->open[i].rep && lp->rep_n) lp->rep_n--;
            crl_write(lp, lp->open[i].t0, root, q, ext, vel);
            return;
        }
}

static void crl_close_open(cr_loop_t *lp)          /* gestures held at the capture's end: closed now */
{
    uint32_t i;
    for (i = 0; i < CRL_OPEN; i++)
        if (lp->open[i].used) {
            crl_write(lp, lp->open[i].t0, lp->open[i].root, lp->open[i].q, lp->open[i].ext, lp->open[i].vel);
            lp->open[i].t0 = lp->t;                                    /* (a later capture starts it here) */
        }
}

static void crl_quantize(cr_loop_t *lp, uint32_t i0)   /* note-ons to the grid; offs kept (>= 1 tick) */
{
    uint32_t g = CRL_QGRID[lp->quant < CRL_NQUANT ? lp->quant : 0], i;
    if (!g || !lp->d.len) return;
    for (i = i0; i < lp->d.nev; i++) {
        crl_ev_t *e = &lp->d.ev[i];
        uint32_t nt = (e->t + g / 2u) / g * g, off = (uint32_t)e->t + e->dur, dur;
        if (nt >= lp->d.len) { e->t = 0; continue; }   /* past the end: the loop's start, its length kept */
        dur = off > nt ? off - nt : 1u;
        e->t = (uint16_t)nt;
        e->dur = (uint16_t)(dur > CRL_MAX_LEN ? CRL_MAX_LEN : dur);
    }
}

static void crl_drop_take(cr_loop_t *lp)
{
    crl_zero(&lp->d,crl_data_size(0));
    lp->state = CRL_EMPTY;
}

/* step entry ends (REC; LOOP: play = 1): the steps entered become the loop (the one there before goes), its length
 * synced, or (Free) the bars the steps used; nothing entered: the loop as it was */
static int crl_step_commit(cr_loop_t *lp, cr_t *c, int play)
{
    uint32_t i, n, bar = cr_loop_bar(lp), len;
    crl_close_open(lp);
    lp->cap = CRL_CAP_NONE;
    lp->full = 0;
    n = lp->d.nev > lp->layer_ev0 ? (uint32_t)(lp->d.nev - lp->layer_ev0) : 0u;
    lp->gen++;
    if (!n) {
        lp->d.nev = lp->layer_ev0;
        if (play && lp->state == CRL_STOPPED) crl_start(lp, c);
        return CRL_DID_EMPTY_TAKE;
    }
    for (i = 0; i < n; i++) {
        lp->d.ev[i] = lp->d.ev[lp->layer_ev0 + i];
        lp->d.ev[i].layer = 0;
    }
    lp->d.nev = (uint16_t)n;
    lp->d.nlayers = 1;
    lp->lev0[0] = 0;
    lp->layer_ev0 = 0;
    if (lp->step_len) len = lp->step_len;
    else {
        len = (uint32_t)(lp->step_end ? lp->step_end : 1u) * lp->step_g;
        len = (len + bar - 1u) / bar * bar;
        if (len > CRL_MAX_LEN) len = CRL_MAX_LEN / bar * bar;
    }
    lp->d.grid_global = 0; lp->d.grid_n = 0; lp->d.len = len;
    lp->d.sig = lp->sig;
    lp->dirty = 1;
    lp->next_on = 0;
    lp->state = CRL_STOPPED;
    if (play) crl_start(lp, c);
    return CRL_DID_STEP_DONE;
}

static int crl_commit(cr_loop_t *lp, cr_t *c)      /* the capture ends */
{
    uint32_t elapsed, bar = cr_loop_bar(lp), len;
    int cap = lp->cap;
    if (cap == CRL_CAP_REC) {
        crl_close_open(lp);
        lp->cap = CRL_CAP_NONE;
        lp->full = 0;
        if (!lp->d.nev) {
            crl_drop_take(lp);
            return CRL_DID_EMPTY_TAKE;
        }
        elapsed = lp->t - lp->rec0;
        if (lp->rec_len) {
            len = elapsed >= lp->rec_len ? lp->rec_len : (elapsed + bar - 1u) / bar * bar;
            if (len < bar) len = bar;
        } else {
            len = elapsed < CRL_MIN_LEN ? CRL_MIN_LEN : elapsed > CRL_MAX_LEN ? CRL_MAX_LEN : elapsed;
        }
        lp->d.len = len;
        lp->d.nlayers = 1;
        lp->lev0[0] = 0;
        lp->d.sig = lp->sig;
        crl_quantize(lp, 0);
        lp->gen++;
        lp->dirty = 1;
        lp->state = CRL_PLAYING;                     /* the take was the first cycle: playback goes on from here */
        lp->cyc0 = lp->rec0;
        lp->scan = elapsed + 1u;
        crl_play_upto(lp, c);
        return CRL_DID_COMMIT;
    }
    if (cap == CRL_CAP_OD) {
        crl_close_open(lp);
        lp->cap = CRL_CAP_NONE;
        lp->full = 0;
        lp->rep = lp->rep_n = 0;
        if (lp->d.nev > lp->layer_ev0) {
            crl_quantize(lp, lp->layer_ev0);
            lp->lev0[lp->d.nlayers] = lp->layer_ev0;
            lp->d.nlayers++;
            lp->dirty = 1;
        } else {
            crl_restore(lp, lp->d.nlayers);
        }
        lp->gen++;
        return CRL_DID_OD_END;
    }
    if (cap == CRL_CAP_STEP) return crl_step_commit(lp, c, 0);
    lp->cap = CRL_CAP_NONE;
    lp->ow = 0;
    return CRL_DID_CANCEL;
}

/* ----------------------------------------------------------- the clock --- */
static void crl_tick1(cr_loop_t *lp, cr_t *c)
{
    uint32_t bar = cr_loop_bar(lp), beat = cr_loop_beat(lp), anchor = 0, rel;
    if (lp->play_armed == 1u && lp->state == CRL_STOPPED && (lp->t - lp->met0) % beat == 0u)
        crl_start(lp, c);
    int on = 0;
    if (lp->cap == CRL_CAP_COUNTIN && lp->t - lp->cin0 >= bar) {
        crl_take_start(lp);
        lp->cap = CRL_CAP_REC;
        lp->rec0 = lp->cin0 + bar;
        lp->layer_ev0 = 0;
    }
    if (lp->cap == CRL_CAP_REC && ((lp->rec_len && lp->t - lp->rec0 >= lp->rec_len) ||
                                   (!lp->rec_len && lp->t - lp->rec0 >= CRL_MAX_LEN) || lp->full))
        crl_commit(lp, c);
    if (lp->cap == CRL_CAP_OD && lp->full) crl_commit(lp, c);
    crl_offs(lp, c);
    crl_play_upto(lp, c);
    /* the click: the count-in always (it is on), else the metronome on the take's / the loop's / its own grid */
    if (lp->cap == CRL_CAP_COUNTIN) { anchor = lp->cin0; on = 1; }
    else if (lp->metro) {
        on = 1;
        anchor = lp->cap == CRL_CAP_REC ? lp->rec0 : lp->state == CRL_PLAYING ? lp->cyc0 : lp->met0;
    }
    if (on) {
        rel = lp->t - anchor;
        if (rel % beat == 0u) lp->click = rel % bar == 0u ? 2u : 1u;
    }
}

void cr_loop_tick(cr_loop_t *lp, cr_t *c, uint32_t now_ms)
{
    uint32_t dms, bpm = c->bpm ? c->bpm : 120u;
    if (!lp->clk_on) {
        lp->clk_on = 1;
        lp->last_ms = now_ms;
        crl_tick1(lp, c);                            /* tick 0 */
        return;
    }
    dms = now_ms - lp->last_ms;
    lp->last_ms = now_ms;
    if (dms > 1000u) dms = 1000u;
    lp->acc += dms * bpm * CRL_PPQN;
    while (lp->acc >= 60000u) {
        lp->acc -= 60000u;
        lp->t++;
        crl_tick1(lp, c);
    }
}

/* ----------------------------------------------------------- transport --- */
void cr_loop_stop(cr_loop_t *lp, cr_t *c)
{
    lp->play_armed = 0;
    if (lp->cap == CRL_CAP_REC || lp->cap == CRL_CAP_OD || lp->cap == CRL_CAP_STEP) crl_commit(lp, c);
    lp->cap = CRL_CAP_NONE;
    lp->ow = 0;
    crl_voices_off(lp, c);
    lp->next_on = 0;
    lp->state = lp->d.len ? CRL_STOPPED : CRL_EMPTY;
}

int cr_loop_rec(cr_loop_t *lp, cr_t *c)
{
    lp->play_armed = 0;
    int mode = lp->mode < CRL_NMODE ? lp->mode : CRL_MODE_OVERWRITE;
    switch (lp->cap) {
    case CRL_CAP_NONE:
        if (mode == CRL_MODE_STEP) {                 /* step entry: the loop stops, the cursor on the first step */
            if (lp->state == CRL_PLAYING) {
                crl_voices_off(lp, c);
                lp->state = CRL_STOPPED;
            }
            lp->next_on = 0;
            lp->cap = CRL_CAP_STEP;
            lp->layer_ev0 = lp->d.nev;               /* (entered after the loop's events: it stays until the commit) */
            lp->step = lp->step_end = 0;
            lp->step_w = 0;
            lp->step_g = CRL_QGRID[lp->quant < CRL_NQUANT ? lp->quant : 0];
            if (!lp->step_g) lp->step_g = 24;        /* none: 1/16 */
            lp->step_len = lp->sync ? CRL_BARS[lp->sync < CRL_NSYNC ? lp->sync : 1] * cr_loop_bar(lp) : 0u;
            lp->full = lp->d.nev >= CRL_MAX_EV;
            lp->gen++;
            return CRL_DID_STEP;
        }
        if (lp->state == CRL_EMPTY || mode == CRL_MODE_OVERWRITE || mode == CRL_MODE_ADVANCE) {
            if (lp->state == CRL_EMPTY) {
                crl_drop_take(lp);
                lp->ow = 0;
            } else {                                 /* Overwrite: stopped; the loop goes when the take starts */
                crl_voices_off(lp, c);
                lp->state = CRL_STOPPED;
                lp->next_on = 0;
                lp->ow = 1;
            }
            lp->full = 0;
            lp->layer_ev0 = 0;
            if (!lp->sync) {
                lp->cap = CRL_CAP_ARMED;
                return CRL_DID_ARM;
            }
            lp->rec_len = CRL_BARS[lp->sync < CRL_NSYNC ? lp->sync : 1] * cr_loop_bar(lp);
            if (lp->count_in) {
                lp->cap = CRL_CAP_COUNTIN;
                lp->cin0 = lp->t;
                lp->click = 2;                       /* the count-in's first beat now */
                return CRL_DID_COUNTIN;
            }
            crl_take_start(lp);
            lp->cap = CRL_CAP_REC;
            lp->rec0 = lp->t;
            if (lp->metro) lp->click = 2;
            return CRL_DID_REC;
        }
        if (lp->d.nlayers >= CRL_MAX_LAYERS || lp->d.nev >= CRL_MAX_EV) {
            lp->full = 1;
            return CRL_DID_NOTHING;
        }
        if (lp->state == CRL_STOPPED) crl_start(lp, c);
        lp->next_on = 0;                             /* a queued switch: cancelled, this loop is being edited */
        lp->cap = CRL_CAP_OD_ARMED;
        lp->rep = mode == CRL_MODE_REPLACE;
        lp->rep_n = 0;
        return lp->rep ? CRL_DID_REP_ARM : CRL_DID_OD_ARM;
    case CRL_CAP_REC:
    case CRL_CAP_OD:
    case CRL_CAP_STEP:
        return crl_commit(lp, c);
    default:                                         /* armed / counting in: cancelled (Overwrite: the loop kept) */
        lp->cap = CRL_CAP_NONE;
        lp->ow = 0;
        lp->rep = 0;
        return CRL_DID_CANCEL;
    }
}

int cr_loop_play(cr_loop_t *lp, cr_t *c)
{
    lp->play_armed = 0;
    int r;
    switch (lp->cap) {
    case CRL_CAP_ARMED:
    case CRL_CAP_COUNTIN:
        lp->cap = CRL_CAP_NONE;
        lp->ow = 0;
        return CRL_DID_CANCEL;
    case CRL_CAP_REC:
        return crl_commit(lp, c);
    case CRL_CAP_STEP:                               /* step entry ends, the loop plays */
        r = crl_step_commit(lp, c, 1);
        return lp->state == CRL_PLAYING ? CRL_DID_PLAY : r;
    case CRL_CAP_OD:
    case CRL_CAP_OD_ARMED:
        r = crl_commit(lp, c);
        (void)r;
        cr_loop_stop(lp, c);
        return CRL_DID_STOP;
    default:
        break;
    }
    if (lp->state == CRL_PLAYING) {
        cr_loop_stop(lp, c);
        return CRL_DID_STOP;
    }
    if (lp->state == CRL_STOPPED) {
        crl_start(lp, c);
        return CRL_DID_PLAY;
    }
    return CRL_DID_NOTHING;
}

/* Manual PLAY: start at the next quarter; STOP and cancellation never wait.
 * The immediate transport API remains available for MIDI Start/Continue. */
int cr_loop_play_synced(cr_loop_t *lp, cr_t *c, int external)
{
    if (lp->play_armed) { lp->play_armed = 0; return CRL_DID_CANCEL; }
    if (lp->cap == CRL_CAP_STEP) crl_step_commit(lp, c, 0);
    if (lp->cap != CRL_CAP_NONE || lp->state != CRL_STOPPED) return cr_loop_play(lp, c);
    if (!external && (lp->t - lp->met0) % cr_loop_beat(lp) == 0u && lp->acc == 0u)
        return cr_loop_play(lp, c);
    lp->play_armed = (uint8_t)(external ? 2u : 1u);
    return CRL_DID_PLAY_ARMED;
}
void cr_loop_play_boundary(cr_loop_t *lp, cr_t *c)
{
    if (lp->play_armed == 2u && lp->state == CRL_STOPPED && lp->cap == CRL_CAP_NONE)
        crl_start(lp, c);
}

int cr_loop_undo(cr_loop_t *lp, cr_t *c)
{
    uint32_t i;
    (void)c;
    if (lp->cap == CRL_CAP_OD || lp->cap == CRL_CAP_OD_ARMED) {     /* the layer in progress goes */
        int had = lp->cap == CRL_CAP_OD && lp->d.nev > lp->layer_ev0;
        lp->d.nev = lp->layer_ev0;
        crl_restore(lp, lp->d.nlayers);              /* (Replace: what it erased comes back) */
        lp->cap = CRL_CAP_NONE;
        lp->rep = lp->rep_n = 0;
        lp->full = 0;
        lp->gen++;
        return had ? CRL_DID_UNDO : CRL_DID_CANCEL;
    }
    if (lp->cap != CRL_CAP_NONE || lp->d.nlayers <= 1u) return CRL_DID_NOTHING;
    i = lp->lev0[lp->d.nlayers - 1u];
    lp->d.nev = (uint16_t)(i < lp->d.nev ? i : lp->d.nev);   /* (its sounding notes finish) */
    lp->d.nlayers--;
    crl_restore(lp, lp->d.nlayers);                  /* the events a Replace layer hid come back */
    lp->gen++;
    lp->full = 0;
    lp->dirty = 1;
    lp->next_on = 0;                                 /* a queued switch: cancelled, this loop is being edited */
    return CRL_DID_UNDO;
}

int cr_loop_clear(cr_loop_t *lp, cr_t *c)
{
    lp->play_armed = 0;
    lp->cap = CRL_CAP_NONE;
    lp->ow = lp->rep = lp->rep_n = 0;
    crl_voices_off(lp, c);
    crl_drop_take(lp);
    lp->gen++;
    lp->full = 0;
    lp->next_on = 0;
    lp->dirty = 1;
    return CRL_DID_CLEAR;
}

void cr_loop_panic(cr_loop_t *lp)
{
    lp->play_armed = 0;
    uint32_t i;
    for (i = 0; i < CR_MAX_LOOPV; i++) lp->pv[i].used = 0;          /* cr_panic ended the voices */
    if (lp->cap == CRL_CAP_REC) {
        crl_drop_take(lp);                                          /* a fresh take is dropped */
    } else if (lp->cap == CRL_CAP_OD && lp->d.nev > lp->layer_ev0) {
        crl_quantize(lp, lp->layer_ev0);                            /* a partial overdub is kept */
        lp->lev0[lp->d.nlayers] = lp->layer_ev0;
        lp->d.nlayers++;
        lp->dirty = 1;
    } else if (lp->cap == CRL_CAP_OD || lp->cap == CRL_CAP_OD_ARMED || lp->cap == CRL_CAP_STEP) {
        lp->d.nev = lp->layer_ev0;                                  /* (armed / counting in: the loop is kept) */
        if (lp->cap != CRL_CAP_STEP) crl_restore(lp, lp->d.nlayers);
    }
    lp->ow = lp->rep = lp->rep_n = 0;
    lp->gen++;
    for (i = 0; i < CRL_OPEN; i++) lp->open[i].used = 0;
    lp->cap = CRL_CAP_NONE;
    lp->full = 0;
    lp->next_on = 0;
    lp->state = lp->d.len ? CRL_STOPPED : CRL_EMPTY;
}

void cr_loop_set(cr_loop_t *lp, cr_t *c, const crl_data_t *d)
{
    lp->play_armed = 0;
    lp->cap = CRL_CAP_NONE;
    lp->ow = lp->rep = lp->rep_n = 0;
    crl_voices_off(lp, c);
    lp->next = d;
    lp->next_on = 0;
    crl_take_next(lp);
    lp->full = 0;
    lp->state = lp->d.len ? CRL_STOPPED : CRL_EMPTY;
}

void cr_loop_queue(cr_loop_t *lp, cr_t *c, const crl_data_t *d)
{
    if (lp->state != CRL_PLAYING) {
        cr_loop_set(lp, c, d);
        return;
    }
    if (lp->cap == CRL_CAP_OD) crl_commit(lp, c);
    lp->cap = CRL_CAP_NONE;
    lp->ow = lp->rep = lp->rep_n = 0;
    lp->next = d;
    lp->next_on = 1;
}

void cr_loop_step(cr_loop_t *lp, int op)
{
    uint32_t nst, s;
    if (lp->cap != CRL_CAP_STEP || !lp->step_g) return;
    nst = lp->step_len ? lp->step_len / lp->step_g : CRL_MAX_LEN / lp->step_g;
    s = lp->step;
    if (op == CRL_STEP_KEYSUP && !lp->step_w) return;    /* (no chord written here yet) */
    if (op == CRL_STEP_BACK) {
        s = s ? s - 1u : lp->step_len ? nst - 1u : 0u;
    } else {
        if (s + 1u > lp->step_end) lp->step_end = (uint16_t)(s + 1u);   /* (a rest is a step used) */
        s = s + 1u < nst ? s + 1u : lp->step_len ? 0u : s;
    }
    lp->step = (uint16_t)s;
    lp->step_w = 0;
    lp->gen++;
}

uint32_t cr_loop_pos(const cr_loop_t *lp)
{
    if (lp->cap == CRL_CAP_REC) return lp->t - lp->rec0;
    if (lp->state == CRL_PLAYING && lp->d.len) return (lp->t - lp->cyc0) % lp->d.len;
    return 0;
}

void cr_loop_metro(cr_loop_t *lp, int on)
{
    lp->metro = (uint8_t)(on != 0);
    lp->met0 = lp->t;
    lp->click = lp->metro ? 2u : 0u;
}

/* ------------------------------------------------------------- queries --- */
uint16_t cr_loop_ring(const cr_loop_t *lp)
{
    uint32_t bar = cr_loop_bar(lp), r = 0;
    if (lp->cap == CRL_CAP_COUNTIN) r = (lp->t - lp->cin0) * 256u / bar;
    else if (lp->cap == CRL_CAP_REC)
        r = lp->rec_len ? (lp->t - lp->rec0) * 256u / lp->rec_len : (lp->t - lp->rec0) % bar * 256u / bar;
    else if (lp->state == CRL_PLAYING && lp->d.len) r = (lp->t - lp->cyc0) % lp->d.len * 256u / lp->d.len;
    return (uint16_t)(r > 256u ? 256u : r);
}

void cr_loop_where(const cr_loop_t *lp, uint32_t *bar, uint32_t *beat)
{
    uint32_t bt = cr_loop_bar(lp), be = cr_loop_beat(lp), rel = 0;
    if (lp->cap == CRL_CAP_COUNTIN) {
        rel = lp->t - lp->cin0;
        *bar = 0;
        *beat = rel >= bt ? 0u : (bt - rel + be - 1u) / be;
        return;
    }
    if (lp->cap == CRL_CAP_REC) rel = lp->t - lp->rec0;
    else if (lp->state == CRL_PLAYING && lp->d.len) rel = (lp->t - lp->cyc0) % lp->d.len;
    *bar = rel / bt + 1u;
    *beat = rel % bt / be + 1u;
}

/* -------------------------------------------------------- the slot record --- */
static void crl_put16(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void crl_put32(uint8_t *p, uint32_t v) { crl_put16(p, v); crl_put16(p + 2, v >> 16); }
static uint32_t crl_get16(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8; }
static uint32_t crl_get32(const uint8_t *p) { return crl_get16(p) | crl_get16(p + 2) << 16; }

uint32_t cr_loop_pack(const crl_data_t *d, uint8_t *buf, uint32_t max)
{
    uint32_t i, live = 0, n, o;
    for (i = 0; i < d->nev && i < CRL_MAX_EV; i++) live += !(d->ev[i].layer & CRL_HID);   /* (hidden: not stored) */
    n = CRL_REC_HDR + 2u * d->nlayers + 7u * live + d->grid_n;
    if(d->grid_n){
        if(d->grid_n>CRL_GRID_MAX)return 0;
        for(i=0;i<d->grid_n;i++)if(d->grid_dur[i]>=CRL_GRID_RATES || (d->grid_global && d->grid_dur[i]!=d->grid_dur[0]))return 0;
        if(d->grid_global){
            if(cr_loop_grid_tick(d,d->grid_n)<d->len || cr_loop_grid_tick(d,d->grid_n-1u)>=d->len)return 0;
        }else if(d->grid_n%8u || cr_loop_grid_tick(d,d->grid_n)!=d->len)return 0;
    }
    if (d->len>CRL_MAX_LEN || !d->len || !live || !d->nlayers || d->nlayers > CRL_MAX_LAYERS || d->nev > CRL_MAX_EV || n > max) return 0;
    crl_put32(buf, CRL_REC_MAGIC);
    buf[4] = d->grid_n ? (d->grid_global?3u:2u) : 1u;                                      /* record version */
    buf[5] = d->sig;
    buf[6] = d->nlayers;
    buf[7] = d->grid_n;
    crl_put32(buf + 8, d->len);
    crl_put16(buf + 12, live);
    crl_put16(buf + 14, CRL_PPQN);
    for (i = 0; i < d->nlayers; i++) crl_put16(buf + CRL_REC_HDR + 2u * i, 0);
    for (i = 0; i < d->nev; i++) {                   /* events per layer */
        uint32_t l;
        uint8_t *p;
        if (d->ev[i].layer & CRL_HID) continue;
        l = d->ev[i].layer < d->nlayers ? d->ev[i].layer : d->nlayers - 1u;
        p = buf + CRL_REC_HDR + 2u * l;
        crl_put16(p, crl_get16(p) + 1u);
    }
    o = CRL_REC_HDR + 2u * d->nlayers;
    for (i = 0; i < d->nev; i++) {
        const crl_ev_t *e = &d->ev[i];
        if (e->layer & CRL_HID) continue;
        crl_put16(buf + o, e->t);
        crl_put16(buf + o + 2, e->dur);
        buf[o + 4] = e->root;
        buf[o + 5] = e->vel;
        buf[o + 6] = e->qx;
        o += 7u;
    }
    for (i = 0; i < d->grid_n; i++) { if (d->grid_dur[i] >= CRL_GRID_RATES) return 0; buf[o++] = d->grid_dur[i]; }
    return n;
}

int cr_loop_unpack(const uint8_t *buf, uint32_t n, crl_data_t *d)
{
    uint32_t i, l, k, nl, nev, len, o, cnt;
    crl_zero(d, crl_data_size(0));
    if (!buf || n < CRL_REC_HDR || crl_get32(buf) != CRL_REC_MAGIC || (buf[4] != 1u && buf[4] != 2u && buf[4] != 3u) || buf[5] >= CRL_NSIG ||
        crl_get16(buf + 14) != CRL_PPQN)
        return 0;
    if(buf[4]>=2u){
        if(!buf[7] || buf[7]>CRL_GRID_MAX || (buf[4]==2u && buf[7]%8u))return 0;
        d->grid_n=buf[7];d->grid_global=(uint8_t)(buf[4]==3u);
    }
    nl = buf[6];
    len = crl_get32(buf + 8);
    nev = crl_get16(buf + 12);
    if (!nl || nl > CRL_MAX_LAYERS || !nev || nev > CRL_MAX_EV || !len || len > CRL_MAX_LEN ||
        n < CRL_REC_HDR + 2u * nl + 7u * nev + d->grid_n)
        return 0;
    for (l = cnt = 0; l < nl; l++) cnt += crl_get16(buf + CRL_REC_HDR + 2u * l);
    if (cnt != nev) return 0;
    o = CRL_REC_HDR + 2u * nl;
    for (l = k = 0; l < nl; l++)
        for (i = crl_get16(buf + CRL_REC_HDR + 2u * l); i; i--, k++, o += 7u) {
            crl_ev_t *e = &d->ev[k];
            e->t = (uint16_t)crl_get16(buf + o);
            e->dur = (uint16_t)crl_get16(buf + o + 2);
            e->root = buf[o + 4];
            e->vel = buf[o + 5];
            e->qx = buf[o + 6];
            e->layer = (uint8_t)l;
            if (e->t >= len || !e->dur || e->root > 127u || !e->vel || e->vel > 127u || (e->qx >> 4) >= CR_Q_COUNT) {
                crl_zero(d, crl_data_size(0));
                return 0;
            }
        }
    for (i = 0; i < d->grid_n; i++) {
        if (buf[o+i] >= CRL_GRID_RATES) { crl_zero(d,crl_data_size(0)); return 0; }
        d->grid_dur[i] = buf[o+i];
    }
    if(d->grid_global && len!=384u && len!=768u && len!=1536u && len!=3072u){crl_zero(d,crl_data_size(0));return 0;}
    if(d->grid_global)for(i=1;i<d->grid_n;i++)if(d->grid_dur[i]!=d->grid_dur[0]){crl_zero(d,crl_data_size(0));return 0;}
    if (d->grid_n && (buf[5] != CRL_SIG_44 ||
        (d->grid_global?(cr_loop_grid_tick(d,d->grid_n)<len || cr_loop_grid_tick(d,d->grid_n-1u)>=len):cr_loop_grid_tick(d,d->grid_n)!=len))) {
        crl_zero(d,crl_data_size(0)); return 0;
    }
    d->len = len;
    d->nev = (uint16_t)nev;
    d->nlayers = (uint8_t)nl;
    d->sig = buf[5];
    return 1;
}

/* Paged editing uses the same event stream as playback and the slot codec.
 * No duplicate notes or patch storage, no modification on opening/closing. */
static uint32_t crl_grid_ticks(uint32_t rate){return 24u<<(rate<CRL_GRID_RATES?rate:2u);}
static uint32_t crl_grid_len(const cr_loop_t *lp){
    uint32_t bars=lp->sync && lp->sync<CRL_NSYNC?CRL_BARS[lp->sync]:2u;
    return bars*4u*CRL_PPQN;
}
uint32_t cr_loop_grid_rate(const cr_loop_t *lp,uint32_t step){
    return lp->d.grid_n && step<lp->d.grid_n?lp->d.grid_dur[step]:lp->d.grid_n?lp->d.grid_dur[0]:2u;
}
uint32_t cr_loop_grid_tick(const crl_data_t *d,uint32_t step){
    uint32_t i,t=0;if(step>CRL_GRID_MAX)step=CRL_GRID_MAX;
    for(i=0;i<step;i++)t+=crl_grid_ticks(d->grid_n?d->grid_dur[i<d->grid_n?i:0]:2u);
    return t;
}
uint32_t cr_loop_grid_count(const cr_loop_t *lp){
    uint32_t ticks=crl_grid_ticks(cr_loop_grid_rate(lp,0)),len=crl_grid_len(lp);
    return (len+ticks-1u)/ticks;
}
void cr_loop_grid_snapshot_ex(const cr_loop_t *lp,uint8_t masks[CRL_GRID_MAX/8u],uint16_t gates[CRL_GRID_MAX],uint8_t *carry,uint8_t *outgoing){
    uint32_t starts[CRL_GRID_MAX+1u],i,k,t=0;uint16_t ends[CRL_GRID_MAX]={0};
    for(i=0;i<CRL_GRID_MAX/8u;i++){masks[i]=0;if(carry)carry[i]=0;if(outgoing)outgoing[i]=0;}
    for(i=0;i<CRL_GRID_MAX;i++){starts[i]=t;t+=crl_grid_ticks(cr_loop_grid_rate(lp,i));}
    starts[CRL_GRID_MAX]=t;
    if(gates)for(i=0;i<CRL_GRID_MAX;i++)gates[i]=0;
    for(i=0;i<lp->d.nev;i++){
        uint32_t lo=0,hi=CRL_GRID_MAX;
        if(lp->d.ev[i].layer&CRL_HID || lp->d.ev[i].t>=t)continue;
        while(lo+1u<hi){k=(lo+hi)/2u;if(starts[k]<=lp->d.ev[i].t)lo=k;else hi=k;}
        masks[lo/8u]|=(uint8_t)(1u<<(lo%8u));
        if(gates && lp->d.ev[i].dur>gates[lo])gates[lo]=lp->d.ev[i].dur;
        if(carry || outgoing){
            uint32_t end=(uint32_t)lp->d.ev[i].t+lp->d.ev[i].dur;
            if(end>lp->d.len)end=lp->d.len;
            if(end>ends[lo])ends[lo]=(uint16_t)end;
        }
    }
    if(carry || outgoing){
        uint32_t until=0,count=cr_loop_grid_count(lp);
        for(i=0;i<count;i++){
            if(carry && until>starts[i])carry[i/8u]|=(uint8_t)(1u<<(i%8u));
            if(ends[i]>until)until=ends[i];
            if(outgoing && until>starts[i+1u])outgoing[i/8u]|=(uint8_t)(1u<<(i%8u));
        }
    }
}
void cr_loop_grid_snapshot(const cr_loop_t *lp,uint8_t masks[CRL_GRID_MAX/8u],uint16_t gates[CRL_GRID_MAX]){
    cr_loop_grid_snapshot_ex(lp,masks,gates,0,0);
}
void cr_loop_grid_masks(const cr_loop_t *lp,uint8_t masks[CRL_GRID_MAX/8u]){cr_loop_grid_snapshot(lp,masks,0);}
uint32_t cr_loop_grid_mask(const cr_loop_t *lp,uint32_t page){
    uint8_t masks[CRL_GRID_MAX/8u];if(page>=CRL_GRID_MAX/8u)return 0;
    cr_loop_grid_masks(lp,masks);return masks[page];
}
/* Rate/length changes are atomic on the audio owner. Refuse any change
 * that would discard a populated cell, instead of silently losing notes. */
static void crl_grid_changed(cr_loop_t *lp,cr_t *c,uint32_t len){
    uint32_t pos=cr_loop_pos(lp);uint8_t was=lp->state;
    crl_voices_off(lp,c);lp->d.len=len;lp->d.sig=lp->sig=CRL_SIG_44;
    crl_lev0_scan(lp);lp->dirty=1;lp->gen++;
    if(!lp->d.nev)lp->state=CRL_EMPTY;
    else if(was==CRL_EMPTY){lp->state=CRL_STOPPED;lp->cyc0=lp->t;lp->scan=0;}
    else{lp->state=was;pos%=len;lp->cyc0=lp->t-pos;lp->scan=pos+1u;}
}
int cr_loop_grid_resize(cr_loop_t *lp,cr_t *c,uint32_t sync){
    uint32_t len,n,ticks=crl_grid_ticks(cr_loop_grid_rate(lp,0)),i;
    if(sync>=CRL_NSYNC || lp->cap!=CRL_CAP_NONE || lp->next_on)return -1;
    len=(sync?CRL_BARS[sync]:2u)*4u*CRL_PPQN;n=(len+ticks-1u)/ticks;
    for(i=0;i<lp->d.nev;i++)if(!(lp->d.ev[i].layer&CRL_HID) && lp->d.ev[i].t>=len)return -4;
    lp->sync=(uint8_t)sync;
    if(lp->d.grid_global){
        uint8_t rate=(uint8_t)cr_loop_grid_rate(lp,0);
        for(i=0;i<n;i++)lp->d.grid_dur[i]=rate;
        lp->d.grid_n=(uint8_t)n;
        for(i=0;i<lp->d.nev;i++)if(lp->d.ev[i].dur>len-lp->d.ev[i].t)lp->d.ev[i].dur=(uint16_t)(len-lp->d.ev[i].t);
        crl_grid_changed(lp,c,len);
    }
    return 1;
}
int cr_loop_grid_edit(cr_loop_t *lp,cr_t *c,uint32_t step,int rate){
    uint32_t len=crl_grid_len(lp),oldticks=crl_grid_ticks(cr_loop_grid_rate(lp,0));
    uint32_t ticks=rate>=0?crl_grid_ticks((uint32_t)rate):oldticks,n=(len+ticks-1u)/ticks;
    uint32_t a,b,i,k,add=0,occupied=0,starts[CRL_GRID_MAX+1u],t=0;
    if(step>=CRL_GRID_MAX || rate>=(int)CRL_GRID_RATES || rate < -1 || lp->cap!=CRL_CAP_NONE || lp->next_on)return -1;
    if(len>CRL_MAX_LEN || n>CRL_GRID_MAX)return -2;
    if(rate<0 && step>=n)return -5;
    if(rate>=0 && lp->d.grid_global && rate==(int)cr_loop_grid_rate(lp,0))return 1;
    for(i=0;i<CRL_GRID_MAX;i++){starts[i]=t;t+=crl_grid_ticks(cr_loop_grid_rate(lp,i));}starts[CRL_GRID_MAX]=t;
    a=starts[step];b=starts[step+1u];
    /* A shorter configured loop must not discard notes; grid changes do not move them. */
    for(i=0;i<lp->d.nev;i++){
        const crl_ev_t *e=&lp->d.ev[i];
        if(e->layer&CRL_HID)continue;
        if(e->t>=a && e->t<b)occupied=1;
        if(e->t>=len)return -4;
    }
    if(rate>=0){
        /* A view/grid change: preserve event timestamps, gates, layers, voices and transport phase. */
        for(i=0;i<n;i++)lp->d.grid_dur[i]=(uint8_t)rate;
        lp->d.grid_n=(uint8_t)n;lp->d.grid_global=1;lp->d.len=len;
        lp->d.sig=lp->sig=CRL_SIG_44;lp->dirty=1;lp->gen++;return 1;
    }
    if(rate<0 && !occupied){
        for(i=0;i<CR_MAX_VOICES+CR_MAX_PADS;i++)if(c->v[i].used && !c->v[i].loop && c->v[i].root+c->v[i].transpose>=0 && c->v[i].root+c->v[i].transpose<=127 && c->v[i].vel)add++;
        if(!add)add=lp->grid_last_valid?1u:0u;
        if(!add)return 0;
        if(lp->d.nev+add>CRL_MAX_EV)return -1;
    }
    /* Toggle this cell only; other events retain exact timing, including off-grid notes. */
    for(i=k=0;i<lp->d.nev;i++){
        crl_ev_t e=lp->d.ev[i];
        if(e.layer&CRL_HID)continue;
        if(rate<0 && occupied && e.t>=a && e.t<b)continue;
        e.layer=0;lp->d.ev[k++]=e;
    }
    lp->d.nev=(uint16_t)k;lp->d.nlayers=k?1u:0u;
    for(i=0;i<n;i++)lp->d.grid_dur[i]=(uint8_t)(rate>=0?(uint32_t)rate:cr_loop_grid_rate(lp,0));
    lp->d.grid_n=(uint8_t)n;lp->d.grid_global=1;
    if(rate<0 && !occupied){
        uint32_t held=0;
        for(i=0;i<CR_MAX_VOICES+CR_MAX_PADS;i++){
            const cr_voice_t *v=&c->v[i];int root=v->root+v->transpose;
            if(!v->used || v->loop || root<0 || root>127 || !v->vel)continue;
            crl_ev_t *e=&lp->d.ev[lp->d.nev++];held++;
            e->t=(uint16_t)(step*ticks);e->dur=(uint16_t)(ticks>len-e->t?len-e->t:ticks);
            e->root=(uint8_t)root;e->vel=v->vel;e->qx=(uint8_t)((v->rq<<4)|(v->sx&15u));e->layer=0;
        }
        if(!held){
            crl_ev_t *e=&lp->d.ev[lp->d.nev++];e->t=(uint16_t)(step*ticks);e->dur=(uint16_t)(ticks>len-e->t?len-e->t:ticks);
            e->root=lp->grid_last_root;e->vel=lp->grid_last_vel;e->qx=lp->grid_last_qx;e->layer=0;
        }
        lp->d.nlayers=1;
    }
    crl_grid_changed(lp,c,len);return 1;
}
/* Swap cell event groups, retaining intra-cell timing, gates and all musical metadata.
 * Layer order remains intact, including hidden undo events. No temporary event arena. */
int cr_loop_grid_move(cr_loop_t *lp,cr_t *c,uint32_t from,uint32_t to){
    uint32_t count=cr_loop_grid_count(lp),a,b,x,y,i,live=0;
    if(from>=count || to>=count)return -5;
    if(lp->cap!=CRL_CAP_NONE || lp->next_on)return -1;
    if(from==to)return 0;
    a=cr_loop_grid_tick(&lp->d,from);b=cr_loop_grid_tick(&lp->d,from+1u);
    x=cr_loop_grid_tick(&lp->d,to);y=cr_loop_grid_tick(&lp->d,to+1u);
    for(i=0;i<lp->d.nev;i++){
        const crl_ev_t *e=&lp->d.ev[i];
        if(e->t>=a && e->t<b && !(e->layer&CRL_HID))live=1;
        uint32_t t=e->t>=a&&e->t<b?x+e->t-a:e->t>=x&&e->t<y?a+e->t-x:e->t;
        if(t>=lp->d.len)return -5;
    }
    if(!live)return 0;
    for(i=0;i<lp->d.nev;i++){
        crl_ev_t *e=&lp->d.ev[i];
        if(e->t>=a && e->t<b)e->t=(uint16_t)(x+e->t-a);
        else if(e->t>=x && e->t<y)e->t=(uint16_t)(a+e->t-x);
    }
    crl_grid_changed(lp,c,lp->d.len);return 1;
}
uint32_t cr_loop_grid_gate(const cr_loop_t *lp,uint32_t step){
    uint32_t i,a=cr_loop_grid_tick(&lp->d,step),b=cr_loop_grid_tick(&lp->d,step+1u),dur=0;
    for(i=0;i<lp->d.nev;i++)if(!(lp->d.ev[i].layer&CRL_HID) && lp->d.ev[i].t>=a && lp->d.ev[i].t<b && lp->d.ev[i].dur>dur)dur=lp->d.ev[i].dur;
    return dur;
}
int cr_loop_grid_gate_edit(cr_loop_t *lp,cr_t *c,uint32_t step,int delta){
    uint32_t i,lv,a,b,ticks=crl_grid_ticks(cr_loop_grid_rate(lp,0)),changed=0;(void)c;
    if(step>=cr_loop_grid_count(lp) || lp->cap!=CRL_CAP_NONE || lp->next_on)return -1;
    a=cr_loop_grid_tick(&lp->d,step);b=cr_loop_grid_tick(&lp->d,step+1u);
    for(i=0;i<lp->d.nev;i++){
        crl_ev_t *e=&lp->d.ev[i];if(e->layer&CRL_HID || e->t<a || e->t>=b)continue;
        int32_t dur=(int32_t)e->dur+delta*(int32_t)ticks;
        uint32_t min=ticks<lp->d.len-e->t?ticks:lp->d.len-e->t;
        if(dur<(int32_t)min)dur=(int32_t)min;
        if(dur>(int32_t)(lp->d.len-e->t))dur=(int32_t)(lp->d.len-e->t);
        int32_t shift=dur-(int32_t)e->dur;e->dur=(uint16_t)dur;
        for(lv=0;lv<CR_MAX_LOOPV;lv++)if(lp->pv[lv].used && lp->pv[lv].ev==i)lp->pv[lv].off+=(uint32_t)shift;
        changed=1;
    }
    if(changed){lp->dirty=1;lp->gen++;}return (int)changed;
}

int cr_loop_grid_preview(const cr_loop_t *lp,cr_t *c,uint32_t step,int on)
{
    uint32_t i,a,b,n=0,free=0;cr_preview_clear(c);
    if(!on || lp->state==CRL_PLAYING || step>=CRL_GRID_MAX)return 0;
    a=cr_loop_grid_tick(&lp->d,step);b=cr_loop_grid_tick(&lp->d,step+1u);
    for(i=CR_MAX_VOICES;i<CR_MAX_VOICES+CR_MAX_PADS;i++)free+=!c->v[i].used;
    for(i=0;i<lp->d.nev;i++)if(!(lp->d.ev[i].layer&CRL_HID) && lp->d.ev[i].t>=a && lp->d.ev[i].t<b)n++;
    if(n>free)return -1;
    for(i=0;i<lp->d.nev;i++){
        const crl_ev_t *e=&lp->d.ev[i];
        if(!(e->layer&CRL_HID) && e->t>=a && e->t<b)
            cr_preview_add(c,e->root,e->qx>>4,e->qx&15u,e->vel);
    }
    return (int)n;
}
