/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the semantic looper (PLAN.md section 8 M6, docs/INTEGRATION.md section 8, docs/LOOPER.md).
 * Portable C99, integer only, no allocation, no libc (stdint.h + cr_engine.h). One cr_loop_t the caller allocates;
 * it runs where the engine runs (the audio ISR): cr_loop_tick after cr_tick, the gesture hook from cr_out_t.
 *
 * What it records: chord gestures as the engine resolved them (absolute root, quality, extension mask, velocity)
 * with their on time and duration in ticks of a beat clock (CRL_PPQN per quarter note at the engine's BPM), in
 * layers. What it plays: those chords back through cr_loop_event (loop voices), so voicing, performance and bass
 * apply live, and BPM changes the loop's speed, never its pitch. */
#ifndef CR_LOOP_H
#define CR_LOOP_H

#include <stdint.h>
#include "cr_engine.h"

#define CRL_PPQN 96u             /* ticks per quarter note: 1/8T = 32, 1/16T = 16, 1/32 = 12 */
#ifndef CRL_MAX_EV
#define CRL_MAX_EV 512u          /* events per loop (all layers): 8 bytes each in RAM, 7 in flash */
#endif
#define CRL_MAX_LAYERS 32u       /* the first recording + 31 overdubs */
#define CRL_OPEN 16u             /* gestures tracked while open (one per held root is plenty) */
#define CRL_MIN_LEN 24u          /* a free loop is at least a 1/16 at the tempo it was made */
#define CRL_MAX_LEN (8u * 4u * CRL_PPQN)       /* eight bars of 4/4; new capture/grid/record cap */
#define CRL_GRID_MAX 128u
#define CRL_GRID_RATES 5u
#define CRL_SLOTS 30u
#define CRL_BANK_SLOTS 10u
#define CRL_NSYNC 5u             /* Free, 1, 2, 4, 8 bars */
#define CRL_NQUANT 7u            /* none, 1/4, 1/8, 1/8T, 1/16, 1/16T, 1/32 */
#define CRL_NEXT_SLOT(k) (((k) + 1u) % CRL_SLOTS)   /* Advance: the slot after k (30 wraps to 1) */

enum { CRL_EMPTY, CRL_STOPPED, CRL_PLAYING };                  /* the loop */
enum { CRL_CAP_NONE,                                            /* capture */
       CRL_CAP_ARMED,       /* Free, a new loop: the first chord starts it (REC lit) */
       CRL_CAP_COUNTIN,     /* synced: the one-bar count-in (REC blinks, the click counts) */
       CRL_CAP_REC,         /* recording the first layer (REC blinks) */
       CRL_CAP_OD_ARMED,    /* playing, overdub armed: the next chord opens a layer (REC lit) */
       CRL_CAP_OD,          /* overdubbing a layer (REC blinks); Replace: the same with lp->rep */
       CRL_CAP_STEP };      /* step entry (docs/LOOPER-MODES.md): the loop stopped, chords written at a cursor (REC lit) */
enum { CRL_MODE_OVERWRITE, CRL_MODE_ADVANCE, CRL_MODE_OVERDUB, CRL_MODE_REPLACE, CRL_MODE_STEP, CRL_NMODE };
#define CRL_HID 0x80u            /* crl_ev_t.layer: hidden by a Replace layer (| that layer's index); RAM only */
#define CRL_LAYER(e) ((e)->layer & CRL_HID ? 0xFFu : (e)->layer)   /* a live event's layer (0xFF: hidden) */
enum { CRL_SIG_44, CRL_SIG_34, CRL_SIG_68, CRL_NSIG };

typedef struct { uint16_t t, dur; uint8_t root, vel, qx, layer; } crl_ev_t;   /* qx = quality << 4 | ext; layer: its
                                                                                 * layer, or CRL_HID | the Replace layer
                                                                                 * that hid it (undoing that layer brings
                                                                                 * it back; the flash record has only
                                                                                 * the live events) */

typedef struct {                 /* a loop's content: what a slot stores */
    uint32_t len;                /* ticks, 0 = empty */
    uint16_t nev;
    uint8_t nlayers, sig;        /* sig: the time signature it was made in (CRL_SIG_*) */
    uint8_t grid_n, grid_global, grid_dur[CRL_GRID_MAX]; /* optional paged grid; events remain semantic chords */
    crl_ev_t ev[CRL_MAX_EV];     /* in layer order (a layer's events follow the previous layer's) */
} crl_data_t;

typedef struct {
    /* settings (the UI's, posted) */
    uint8_t sync, quant, count_in, level;      /* 0..5, 0..6, 0/1, 0..100 (loop velocity %) */
    uint8_t sig, metro, metro_vol;             /* CRL_SIG_*, click on, click level 0..100 */
    uint8_t mode;                              /* CRL_MODE_*: what REC does with no capture (Advance: the UI's slot jump,
                                                * then as Overwrite) */
    /* the loop */
    crl_data_t d;
    uint8_t state, cap, full;
    uint16_t layer_ev0;                        /* the capture layer's first event */
    /* the clock: ticks at the engine's BPM, from the ms clock */
    uint32_t t, acc, last_ms;
    uint8_t clk_on;
    uint32_t cyc0, scan;                       /* the current cycle's start (abs ticks); next position to play */
    uint32_t rec0, rec_len, cin0, od0, met0;
    struct { uint32_t gid, t0; int16_t root; uint8_t used, q, ext, vel, rep; } open[CRL_OPEN];   /* held gestures
                                                * (rep: opened while replacing) */
    struct { uint32_t off; uint16_t ev; uint8_t used; } pv[CR_MAX_LOOPV];   /* ev: the event it plays */
    uint16_t lev0[CRL_MAX_LAYERS];             /* each layer's first event (a hidden event's layer, back on undo) */
    uint8_t ow;                                /* Overwrite armed over a loop: it is cleared when the take starts */
    uint8_t rep, rep_n;                        /* the overdub replaces (Replace); gestures of it held */
    uint32_t rep0;                             /* the cycle position the held span began at (ticks) */
    uint16_t step, step_end;                   /* step entry: the cursor; the steps used (Free: the length) */
    uint8_t step_g, step_w;                    /* the grid (ticks a step); a chord written at the cursor */
    uint32_t step_len;                         /* synced: the length the cursor wraps at (0: Free) */
    uint16_t gen;                              /* + 1 whenever the events change (the UI's timeline cache) */
    const crl_data_t *next;                    /* a slot switch waiting for the end of the cycle (0: empty) */
    uint8_t next_on, dirty;                    /* a switch is queued; the content changed since loaded / saved */
    uint8_t loads;                             /* + 1 whenever a slot's data replaces the loop: the UI tells a queued
                                                * switch taken from one cancelled (a stop, a clear, a panic, or an edit
                                                * of the loop still playing: an overdub armed, an undo) */
    /* out: the click (the audio side takes it), diagnostics */
    uint8_t play_armed;                        /* RAM only: 1 next internal quarter, 2 next MIDI quarter */
    uint8_t click;                             /* 0 none, 1 beat, 2 the bar's first beat */
    uint8_t grid_editor, grid_last_valid, grid_last_root, grid_last_qx, grid_last_vel;
    uint32_t played;                           /* events played (diagnostics) */
} cr_loop_t;

void cr_loop_init(cr_loop_t *lp);
void cr_loop_tick(cr_loop_t *lp, cr_t *c, uint32_t now_ms);
/* cr_out_t.gesture's body */
void cr_loop_gesture(cr_loop_t *lp, uint32_t gid, int16_t root, uint8_t q, uint8_t ext, uint8_t vel, int on);

/* transport (PLAN.md section 3). Each returns what it did (CRL_DID_*) for the UI's message */
enum { CRL_DID_NOTHING, CRL_DID_ARM, CRL_DID_COUNTIN, CRL_DID_REC, CRL_DID_CANCEL, CRL_DID_COMMIT, CRL_DID_OD_ARM,
       CRL_DID_OD_END, CRL_DID_PLAY, CRL_DID_STOP, CRL_DID_UNDO, CRL_DID_CLEAR, CRL_DID_EMPTY_TAKE, CRL_DID_REP_ARM,
       CRL_DID_STEP, CRL_DID_STEP_DONE, CRL_DID_PLAY_ARMED };
int  cr_loop_rec(cr_loop_t *lp, cr_t *c);      /* REC tap */
int cr_loop_play_synced(cr_loop_t *lp, cr_t *c, int external);
void cr_loop_play_boundary(cr_loop_t *lp, cr_t *c);
int  cr_loop_play(cr_loop_t *lp, cr_t *c);     /* LOOP tap */
int  cr_loop_undo(cr_loop_t *lp, cr_t *c);     /* REC hold, F#4: the last layer (an overdub in progress first) */
int  cr_loop_clear(cr_loop_t *lp, cr_t *c);    /* D#4 held 1 s */
enum { CRL_STEP_KEYSUP, CRL_STEP_REST, CRL_STEP_BACK };
void cr_loop_step(cr_loop_t *lp, int op);      /* step entry: every key up (advances after a chord), OCT+, OCT- */
uint32_t cr_loop_pos(const cr_loop_t *lp);     /* the playhead: ticks into the take / the cycle (0 idle) */
void cr_loop_stop(cr_loop_t *lp, cr_t *c);     /* stop playing (loop voices end), capture ends */
void cr_loop_panic(cr_loop_t *lp);             /* after cr_panic: stopped, content kept (a fresh take dropped) */
void cr_loop_set(cr_loop_t *lp, cr_t *c, const crl_data_t *d);    /* load now (stops): d = 0 empties */
void cr_loop_queue(cr_loop_t *lp, cr_t *c, const crl_data_t *d);  /* playing: at the end of the cycle; else now.
                                                * An overdub armed or an undo before then cancels it (the loop
                                                * being edited stays), as a stop or a clear does */
void cr_loop_metro(cr_loop_t *lp, int on);     /* the click on / off (its grid restarts) */

/* queries */
uint32_t cr_loop_bar(const cr_loop_t *lp);     /* ticks per bar, per beat (the click) */
uint32_t cr_loop_beat(const cr_loop_t *lp);
uint16_t cr_loop_ring(const cr_loop_t *lp);    /* Q8 position on the ring (0 when idle) */
void cr_loop_where(const cr_loop_t *lp, uint32_t *bar, uint32_t *beat);   /* 1-based; count-in: beats left */
int  cr_loop_layers(const cr_loop_t *lp);

/* the slot record (docs/LOOPER.md): little-endian bytes, CRL_REC_MAX at most. pack returns its length; unpack
 * returns 1 for a valid record (*d filled), 0 otherwise (*d emptied) */
#define CRL_REC_MAGIC 0x314C5243u              /* "CRL1" */
#define CRL_REC_HDR 16u
#define CRL_REC_MAX (CRL_REC_HDR + 2u * CRL_MAX_LAYERS + 7u * CRL_MAX_EV + CRL_GRID_MAX)
uint32_t cr_loop_pack(const crl_data_t *d, uint8_t *buf, uint32_t max);
int  cr_loop_unpack(const uint8_t *buf, uint32_t n, crl_data_t *d);

uint32_t cr_loop_grid_tick(const crl_data_t *d, uint32_t step);
void cr_loop_grid_masks(const cr_loop_t *lp, uint8_t masks[CRL_GRID_MAX/8u]);
void cr_loop_grid_snapshot_ex(const cr_loop_t *lp,uint8_t masks[CRL_GRID_MAX/8u],uint16_t gates[CRL_GRID_MAX],uint8_t *carry,uint8_t *outgoing);
void cr_loop_grid_snapshot(const cr_loop_t *lp,uint8_t masks[CRL_GRID_MAX/8u],uint16_t gates[CRL_GRID_MAX]);
uint32_t cr_loop_grid_mask(const cr_loop_t *lp, uint32_t page);
uint32_t cr_loop_grid_rate(const cr_loop_t *lp, uint32_t step);
/* Mutations run on the audio owner; 1 success, 0 no chord, -1 busy/too long. */
/* rate >=0 changes the global grid; -1 toggles a cell. Refusals preserve data. */
int cr_loop_grid_edit(cr_loop_t *lp, cr_t *c, uint32_t step, int rate);
uint32_t cr_loop_grid_count(const cr_loop_t *lp);
int cr_loop_grid_resize(cr_loop_t *lp,cr_t *c,uint32_t sync);
int cr_loop_grid_gate_edit(cr_loop_t *lp,cr_t *c,uint32_t step,int delta);
uint32_t cr_loop_grid_gate(const cr_loop_t *lp,uint32_t step);
int cr_loop_grid_preview(const cr_loop_t *lp, cr_t *c, uint32_t step, int on);

#endif

int cr_loop_grid_move(cr_loop_t *lp,cr_t *c,uint32_t from,uint32_t to);
