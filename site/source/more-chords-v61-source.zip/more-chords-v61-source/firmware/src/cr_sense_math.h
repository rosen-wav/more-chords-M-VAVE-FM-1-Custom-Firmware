/* SPDX-License-Identifier: GPL-3.0-only */
/* Integer-only logarithmic velocity support. No float, libm, 64-bit division,
 * dynamic allocation or mutable tables in the ADC interrupt path. */
#pragma once
#include <stdint.h>
#define SN_LOG_ONE 16777216u

/* log2(x) in Q24, x >= 1. Repeated squaring of a Q31 mantissa. */
static uint32_t sense_log2_q24(uint32_t x)
{
    uint32_t n = x, exponent = 0, y, result, bit;
    if (!x) return 0;
    while (n >>= 1) ++exponent;
    y = x << (31u - exponent);
    result = exponent << 24;
    for (bit = 1u << 23; bit; bit >>= 1) {
        uint64_t square = ((uint64_t)y * y) >> 31;
        if (square >= ((uint64_t)1u << 32)) {
            square >>= 1;
            result |= bit;
        }
        y = (uint32_t)square;
    }
    return result;
}

/* floor(a / b * 2^24), 0 <= a < b <= 32 * 2^24. */
static uint32_t sense_ratio_q24(uint32_t a, uint32_t b)
{
    uint32_t result = 0, i;
    for (i = 0; i < 24u; ++i) {
        a <<= 1;
        result <<= 1;
        if (a >= b) { a -= b; result |= 1u; }
    }
    return result;
}

/* 2^(-x), x in unsigned Q20; return unsigned Q31. */
static uint32_t sense_exp2_neg_q31(uint32_t x)
{
    static const uint32_t factors[20] = {1518500250u, 1805811301u, 1969251188u, 2056437387u, 2101467502u, 2124350982u, 2135885998u, 2141676973u, 2144578345u, 2146030505u, 2146756953u, 2147120270u, 2147301951u, 2147392798u, 2147438222u, 2147460935u, 2147472292u, 2147477970u, 2147480809u, 2147482228u};
    uint32_t result = 0x80000000u, i, whole = x >> 20;
    if (whole >= 32u) return 0;
    for (i = 0; i < 20u; ++i)
        if (x & (1u << (19u - i)))
            result = (uint32_t)(((uint64_t)result * factors[i] + 0x40000000u) >> 31);
    return result >> whole;
}
