/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the persisted settings record (docs/SETTINGS.md). Standalone (stdint only): Felucca's
 * settings_persist.c includes it for the layout of its ChoralRoot block, so the block survives a build that
 * does not know it.
 *
 * One fixed-layout record, versioned and append-only: a newer field always goes into the reserve at the end
 * (rsv shrinks, the size stays CRS_SIZE), CRS_VERSION goes up, and cr_settings_import() gives it its default
 * when an older record (whose version is lower) is read. Every field is checked on import: a value out of range
 * takes its default; a bad magic / checksum gives all defaults. */
#ifndef CR_SETTINGS_H
#define CR_SETTINGS_H
#include <stdint.h>

#define CRS_MAGIC 0x31535243u           /* "CRS1" */
#define CRS_VERSION 9u
#define CRS_MIDI_BASE(s) ((uint8_t)((s)->scale && (s)->scale <= 119u ? (s)->scale - 1u : 53u))
#define CRS_SIZE 192u                   /* bytes, header included; never changes (fields come out of rsv) */
#define CRS_NPM 5                       /* perform modes (cr_engine.h CR_PM_COUNT) */
#define CRS_NPAR 11                     /* parameters per mode (CR_P_COUNT) */
#define CRS_SOUND_DEFAULT 0xFFFFu       /* chord_sound / bass_sound: the UI's own default (FM6 TINE EP, ANALOG SUB BASS) */
#define CRS_NENG 11                     /* the engines shown (core.h NENG_SHOWN: cr_settings.c checks) */
#define CRS_POOL_DEFAULT 1u             /* pool_pos: an engine not played yet lands on its first preset */
#define CRS_PALETTE_MOD 0xFFu           /* palette: MOD, ChoralRoot's (gfx.c: the last palette) */
enum { CRS_CLOCK_OFF, CRS_CLOCK_OUT, CRS_CLOCK_IN };
enum { CRS_NONE = 0xFF };               /* out part: no part */
enum { CRS_USB_MASTER, CRS_USB_FIXED };  /* usb_level: USB audio follows MASTER / takes the full level (docs/USB-AUDIO.md) */

#define CRS_OUT_CLASSIC 0x02u
#define CRS_OUT_CLEAN(s) (((unsigned)(s)->pick_roots & CRS_OUT_CLASSIC) ? 0u : 1u)
/* Options > USB Rate (0.19, the owner 2026-10-12: "Make 48 kHz opt-in for now"; docs/USB-AUDIO.md "48 kHz") rides in
 * bit 2 of the same byte: set = ChoralRoot In offers 44.1 and 48 kHz, clear = 44.1 kHz only (0.18's device, the
 * default). The same reasoning as Output's bit: every older record has 0 there and 0 is the default, so there is no
 * version and nothing to migrate; a firmware up to 0.18 finds 4..7 out of range and takes its own default for the
 * byte, a 0.19 build of before the option finds them out of range too and reads Output as Clean until it is set */
#define CRS_USB_48K 0x04u
/* Bit set means dynamics disabled; older records default to enabled. */
#define CRS_VELOCITY_OFF 0x08u
#define CRS_USB48(s) (((unsigned)(s)->pick_roots & CRS_USB_48K) ? 1u : 0u)
#define CRS_PICK_AUTO (CRS_OUT_CLASSIC | CRS_USB_48K)   /* the byte's automatic bits (cr_settings_auto) */

typedef struct {
    /* header (12 bytes) */
    uint32_t magic;                     /* CRS_MAGIC */
    uint16_t version;                   /* CRS_VERSION of the writer */
    uint16_t size;                      /* CRS_SIZE of the writer */
    uint32_t check;                     /* FNV-1a over bytes [12, size) */
    /* version 1 */
    uint8_t playstyle, extadd, secret, key_on;       /* cr_playstyle_t, cr_extadd_t, cr_secret_t; key_on stores keys-only in v7; older records migrate Off */
    uint8_t tonic, scale;                            /* tonic retired; v8 scale stores MIDI chord base+1,
                                                       * 0=default53; scales remain disabled */
    int8_t transpose;                                /* -24..24 */
    uint8_t single;                                  /* cr_single_t: Full Octave / Split */
    uint8_t split_pc, vel, bass_on, bass_mode;       /* 0..11; key velocity 1..127; (0 at power-on); cr_bassmode_t */
    int8_t bass_voicing;                             /* bass register, octaves -2..4 */
    uint8_t perform_on, perform_mode, perf_sel;      /* on, cr_pmode_t, the PERF layer's entry 0..6 (Strum 2 ...) */
    uint8_t sticky, pool_pos10_chord;                /* latch; v6: pool_pos of engine rank 10 for the chord part
                                                      * (crs_pool_get; was rsv0) */
    uint16_t bpm;                                    /* 20..300 */
    int16_t par[CRS_NPM][CRS_NPAR];                  /* per-mode perform parameters (cr_engine.h cr_param_t) */
    uint8_t loop_sync, loop_quant, loop_count_in, loop_level;   /* 0..4 (Free, 1..8 bars), 0..6, 0/1, 0..100 */
    uint8_t midi_en[3], midi_ch[3];                  /* per stream (MAIN BASS RAW): MIDI out on, channel 0..15 */
    uint8_t clock_mode, raw_sound, view, motion;     /* CRS_CLOCK_*, RAW also plays part 0, View 0..4, Motion 0..2 */
    uint8_t palette, leds, fx_on, pool_pos10_bass;   /* palette index (CRS_PALETTE_MOD), LEDs Glow / Stock, FX on; v6: the
                                                      * bass part's pool_pos of engine rank 10 (was rsv1) */
    uint16_t chord_sound, bass_sound;                /* v6: the chord part's sound and the bass part's (what BASS tap
                                                      * brings) as (engine << 8) | pool position (docs/PRESETS.md);
                                                      * CRS_SOUND_DEFAULT the UI's. v1..5: positions in the old bank
                                                      * list, read as CRS_SOUND_DEFAULT */
    /* version 2 */
    uint8_t metro_on, metro_sig, metro_vol, loop_slot;   /* the click, 4/4 3/4 6/8, its level 0..100, slot 0..29 */
    /* version 3 */
    uint8_t pick_roots;                              /* bit 0: picker roots; bit 1: Classic; bit 2: offer USB 48 kHz */
    /* version 4 (rsv_usb: v4's usb_out, Options > USB Audio Out, the playback removed in v5: always 0 since) */
    uint8_t rsv_usb, usb_in, usb_level;              /* -, Options > USB Record (on), USB Level (CRS_USB_*) */
    /* version 6 */
    uint8_t pool_pos[2][10];                         /* per part (chord, bass), per engine (ENGINE_ORDER rank 0..9; rank
                                                      * 10's: pool_pos10_*): the pool position last played there, where
                                                      * OPT + PRESETS lands (CRS_POOL_DEFAULT before). The reserve is
                                                      * used up: a new field needs a longer record (docs/SETTINGS.md) */
} cr_settings_t;

/* what cr_out.c's routing takes (cr_route_t, written field by field by the unit's glue) */
typedef struct {
    uint8_t part[3];                    /* 0 = CHORD part, CRS_NONE: none (RAW only: Raw Chord Sound) */
    uint8_t midi_en[3], ch[3];
    uint8_t clock_out;
    uint8_t clock_in;                   /* Options > MIDI Clock = In (clock_out is then 0) */
} cr_settings_out_t;

void cr_settings_defaults(cr_settings_t *s);
/* a stored block (n bytes) -> *s, defaults for what is absent or invalid. 1: current, 2: migrated (older or newer
 * version: the fields it has are kept), 0: invalid (all defaults) */
int  cr_settings_import(cr_settings_t *s, const void *blk, uint32_t n);
void cr_settings_seal(cr_settings_t *s);         /* header + checksum, before it is stored */
int  cr_settings_equal(const cr_settings_t *a, const cr_settings_t *b);   /* the payloads */
/* the pool position of part (0 chord, 1 bass) on the engine of ENGINE_ORDER rank r (0..CRS_NENG-1) */
static inline uint8_t crs_pool_get(const cr_settings_t *s, unsigned part, unsigned r)
{
    part &= 1u;
    if (r < 10u)
        return s->pool_pos[part][r];
    return part ? s->pool_pos10_bass : s->pool_pos10_chord;
}
static inline void crs_pool_set(cr_settings_t *s, unsigned part, unsigned r, uint8_t v)
{
    part &= 1u;
    if (r < 10u)
        s->pool_pos[part][r] = v;
    else if (part)
        s->pool_pos10_bass = v;
    else
        s->pool_pos10_chord = v;
}

#ifdef CR_ENGINE_H
/* the record -> the engine's setters (call with the engine idle / the audio IRQ off) and the routing */
void cr_settings_apply(const cr_settings_t *s, cr_t *c, cr_settings_out_t *o);
/* the reverse: the engine's and the routing's fields of *s (the UI's own fields are left as they are) */
void cr_settings_capture(cr_settings_t *s, const cr_t *c, const cr_settings_out_t *o);
#endif

#endif
