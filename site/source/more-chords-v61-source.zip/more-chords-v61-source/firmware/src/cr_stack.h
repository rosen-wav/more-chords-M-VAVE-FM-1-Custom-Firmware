/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#define CR_STACK_MARK 0x43314D4Bu
/* Read only while the worker is idle. A marker high-water estimate, not a proof
 * of stack safety: a write equal to the marker could hide a touched word. */
static inline uint32_t cr_stack_used(const uint32_t *p,uint32_t words) {
    uint32_t i=0;while(i<words && p[i]==CR_STACK_MARK)i++;
    return (words-i)*4u;
}
static inline int cr_stack_guard_ok(const uint32_t *p,uint32_t words) {
    if(words<2u)return 0;
    return p[0]==CR_STACK_MARK && p[1]==CR_STACK_MARK;
}
