/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
/* Mild upward compression for measured physical key velocity only.
 * Preserve zero (no measured press), full scale and monotonic dynamics.
 * 24 + 103*v/127 maps 1..127 to 25..127, with integer rounding. */
static uint8_t cr_velocity_soft(uint8_t v)
{
    if(!v)return 0;
    if(v>=127u)return 127;
    return (uint8_t)(24u+(103u*v+63u)/127u);
}
