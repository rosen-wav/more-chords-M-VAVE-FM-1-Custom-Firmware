/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
/* Exact unsigned division by a cached divisor: ceil(2^32/d) gives a
 * quotient at most one too high; a full-width product corrects it.
 * No 64-bit division/runtime helper. d must be nonzero. */
typedef struct {uint32_t d, reciprocal;} csn_div_t;
static inline void csn_div_prepare(csn_div_t *c,uint32_t d)
{
    if(c->d!=d){c->d=d;c->reciprocal=d>1u?UINT32_MAX/d+1u:0u;}
}
static inline uint32_t csn_div_exact(const csn_div_t *c,uint32_t n)
{
    if(c->d==1u)return n;
    uint32_t q=(uint32_t)(((uint64_t)n*c->reciprocal)>>32);
    return q-((uint64_t)q*c->d>n);
}
