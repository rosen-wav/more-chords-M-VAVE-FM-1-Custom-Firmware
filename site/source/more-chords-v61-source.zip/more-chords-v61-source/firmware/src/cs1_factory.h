typedef struct { uint8_t ch, off, val; } tweak_t;      /* ch 0 / 1 (2: both), offsetof(csn_chan_patch_t, ..), the value */
#define TW(c, f, v) {c, (uint8_t)offsetof(csn_chan_patch_t, f), v}
#define TWEND {3, 0, 0}
typedef struct {
    const char *name;
    uint8_t tone[2], feet1[2], level[2];              /* levels: 0 = 110 */
    uint8_t brill, reso, detune, mix;                 /* 0 = 64 (centre) */
    uint8_t porta, gliss, at_vco, at_brill, at_vcf, pbend;
    uint8_t lfo_wave, lfo_spd, lfo_vco, lfo_vcf;      /* lfo_spd 0 = 60 */
    uint8_t cho_mode, cho_spd, cho_depth;             /* cho_spd 0 = 30, cho_depth 0 = 60 */
    uint8_t rm_mod, rm_spd, rm_depth, rm_d;           /* rm_spd 0 = 64, rm_d 0 = 60 */
    uint8_t v_a, v_r;                                 /* 0: the tones' own VCA attack / release, else these on both */
    uint8_t aat_delay, aat_rise, aat_level, aat_fall; /* aat_rise 0 = 60, aat_fall 0 = 40 */
    uint8_t rv_mix, rv_size, rv_damp, rv_shim;        /* rv_size 0 = 80, rv_damp 0 = 50 */
    uint8_t rv_shift;                                 /* the shimmer's interval in semitones, 0 = 12 */
    uint8_t dly_time, dly_fb, dly_mix, dly_ping;      /* dly_time 0 = 70, dly_fb 0 = 50 */
    uint8_t dly_sync, vintage;                        /* the delay's clock division (0 free); vintage 0 = 30 */
    uint8_t dly_tape;                                 /* the delay's tape character */
    uint8_t ph_rate, ph_depth, ph_fb, ph_mix;         /* the phaser (ph_rate 0 = 40, ph_depth 0 = 64, ph_fb 0 = 40; mix 0 = off) */
    tweak_t tw[12];
} sound_t;
enum { T_STR1 = 0, T_STR2, T_STR3, T_STR4, T_BRS1, T_BRS2, T_FLUTE, T_BRS3, T_EPIANO, T_BASS, T_CLAV1, T_CLAV2,
       /* (the rest in order) */
       T_HARP1, T_HARP2, T_ORG1, T_ORG2, T_GTR1, T_GTR2, T_FNK1, T_FNK2, T_FNK3, T_FNK4, T_GLASS1, T_GLASS2 };
#define F16 (csn_FT_16 + 1)
#define F8 (csn_FT_8 + 1)
#define F4 (csn_FT_4 + 1)
#define F2 (csn_FT_2 + 1)
#define F53 (csn_FT_53 + 1)
#define F27 (csn_FT_27 + 1)
static const sound_t CS1_SOUNDS[] = {
    /* ---- Vangelis */
    {.name = "BLADE BRASS", .rv_mix = 56, .tone = {T_BRS1, T_BRS2}, .level = {115, 115}, .brill = 60, .reso = 70, .detune = 70,
     .porta = 18, .at_vco = 30, .at_brill = 90, .cho_mode = csn_CHO_CHORUS, .cho_spd = 22, .cho_depth = 70, .v_a = 62,
     .aat_delay = 50, .aat_rise = 70, .aat_level = 100, .rv_size = 100, .tw = {TWEND}},
    {.name = "BR BLUES", .rv_mix = 68, .tone = {T_STR3, T_BRS3}, .feet1 = {F4, F8}, .level = {110, 95}, .brill = 70, .reso = 68, .detune = 72,
     .porta = 30, .at_vco = 34, .at_brill = 70, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18, .cho_depth = 75, .v_a = 40, .v_r = 80,
     .aat_delay = 45, .aat_rise = 65, .aat_level = 110, .aat_fall = 60, .rv_size = 115, .rv_shim = 25,
     .dly_time = 84, .dly_fb = 45, .dly_mix = 30, .dly_tape = 50, .dly_ping = 1, .dly_sync = 6, .tw = {TW(0, lp_cut, 100), TW(1, lp_cut, 90), TWEND}},
    {.name = "BR FLUTE", .rv_mix = 56, .tone = {T_FLUTE, T_ORG2}, .feet1 = {F8, F16}, .level = {115, 60}, .brill = 60, .detune = 68,
     .porta = 60, .at_vco = 22, .at_brill = 40, .cho_mode = csn_CHO_CHORUS, .cho_spd = 16, .cho_depth = 70, .v_a = 48,
     .aat_delay = 60, .aat_rise = 75, .aat_level = 70, .aat_fall = 50, .rv_size = 100,
     .dly_time = 90, .dly_fb = 50, .dly_mix = 45, .dly_tape = 50, .dly_ping = 1, .dly_sync = 4, .tw = {TWEND}},
    {.name = "BR STRINGS", .rv_mix = 68, .ph_rate = 20, .ph_depth = 60, .ph_fb = 30, .ph_mix = 40, .tone = {T_STR1, T_STR2}, .feet1 = {F8, F16}, .level = {115, 90}, .brill = 56, .reso = 66, .detune = 72,
     .porta = 22, .at_vco = 19, .at_brill = 50, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18, .cho_depth = 85, .v_a = 85, .v_r = 95,
     .aat_delay = 55, .aat_rise = 80, .aat_level = 90, .aat_fall = 60, .rv_size = 118, .rv_shim = 30, .tw = {TWEND}},
    {.name = "CHARIOTS", .rv_mix = 44, .tone = {T_BRS1, T_BRS3}, .level = {115, 105}, .brill = 72, .reso = 66, .detune = 70,
     .porta = 10, .at_vco = 32, .at_brill = 80, .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 55, .v_a = 30,
     .aat_delay = 40, .aat_rise = 55, .aat_level = 95, .rv_size = 95,
     .dly_time = 96, .dly_fb = 55, .dly_mix = 50, .dly_tape = 50, .dly_ping = 1, .dly_sync = 4, .tw = {TWEND}},
    {.name = "UNKNOWN MAN", .rv_mix = 52, .tone = {T_BRS1, T_STR2}, .level = {115, 80}, .brill = 66, .reso = 64, .detune = 69,
     .porta = 26, .at_vco = 36, .at_brill = 60, .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 60, .v_a = 36,
     .aat_delay = 40, .aat_rise = 60, .aat_level = 100, .rv_size = 100, .dly_time = 100, .dly_fb = 40, .dly_mix = 35, .dly_tape = 50, .dly_sync = 3, .tw = {TWEND}},
    /* Syntorial's Blade Runner brass: two 50 % pulses an octave apart, 6 cents off, PWM at ~4 Hz, a 650 ms filter
     * swell that takes 10 s to fall, the amplifier at 250 ms / 1.9 s / 40 % / 750 ms, a big reverb at 10 % */
    {.name = "BR BRASS 2", .rv_mix = 28, .tone = {T_BRS1, T_BRS2}, .feet1 = {F8, F4}, .level = {115, 85}, .brill = 64, .reso = 64, .detune = 56,
     .at_vco = 26, .at_brill = 70, .rv_size = 100, .aat_delay = 50, .aat_rise = 70, .aat_level = 80,
     .tw = {TW(2, wave, csn_W_PULSE), TW(2, pw, 0), TW(2, pwm, 100), TW(2, pwm_spd, 78), TW(2, lp_cut, 95), TW(2, lp_res, 19),
            TW(2, f_il, 64), TW(2, f_al, 82), TW(2, f_a, 88), TW(2, f_d, 124), TW(2, f_r, 124), TW(2, v_a, 75)}},
    /* the brass swell as MusicTech builds it: two saws 60 / 40 a couple of cents apart, the filter envelope a third
     * of the range over a second, long decay and release; a tape delay with high feedback and a 10 s reverb */
    {.name = "BRASS SWELL", .rv_mix = 48, .tone = {T_BRS1, T_BRS2}, .level = {118, 95}, .brill = 60, .reso = 62, .detune = 67,
     .at_vco = 19, .at_brill = 60, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18, .cho_depth = 40, .v_a = 55, .v_r = 100,
     .aat_delay = 40, .aat_rise = 80, .aat_level = 90, .rv_size = 100,
     .dly_time = 95, .dly_fb = 70, .dly_mix = 35, .dly_tape = 50, .dly_ping = 1,
     .dly_sync = 4, .tw = {TW(2, f_il, 64), TW(2, f_al, 104), TW(2, f_a, 94), TW(2, f_d, 120), TW(2, f_r, 120), TW(2, v_s, 120)}},
    /* Blade Runner Blues as a forum player had it on the Arturia: Brass 1 + 2 with the performance side up */
    {.name = "BR BLUES 2", .rv_mix = 68, .tone = {T_BRS1, T_BRS2}, .level = {115, 110}, .brill = 66, .reso = 66, .detune = 70,
     .porta = 24, .at_vco = 34, .at_brill = 110, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18, .cho_depth = 70, .v_a = 36, .v_r = 85,
     .aat_delay = 40, .aat_rise = 60, .aat_level = 115, .aat_fall = 60, .rv_size = 115,
     .dly_time = 84, .dly_fb = 45, .dly_mix = 30, .dly_tape = 50, .dly_ping = 1, .dly_sync = 6, .tw = {TWEND}},
    /* the End Titles' sequenced bass: two saws an octave apart, the filter under an envelope; no csn_chorus */
    {.name = "END TITLES", .rv_mix = 20, .tone = {T_BRS1, T_BRS2}, .feet1 = {F16, F8}, .level = {118, 100}, .brill = 60, .reso = 72, .detune = 66,
     .rv_size = 70, .dly_time = 80, .dly_fb = 40, .dly_mix = 25, .dly_tape = 50, .dly_ping = 1,
     .dly_sync = 4, .tw = {TW(2, f_il, 64), TW(2, f_al, 100), TW(2, f_a, 0), TW(2, f_d, 70), TW(2, v_a, 0), TW(2, v_r, 40)}},
    {.name = "CHIMES", .rv_mix = 60, .tone = {T_FLUTE, T_BASS}, .feet1 = {F4, F4}, .level = {110, 90}, .brill = 70,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 40, .rm_mod = 115, .rm_spd = 78, .rm_depth = 60, .rm_d = 85,
     .rv_size = 105, .rv_shim = 30, .tw = {TWEND}},
    /* ---- Toto, Thriller */
    {.name = "AFRICA", .rv_mix = 32, .tone = {T_STR1, T_STR4}, .level = {120, 80}, .brill = 56, .reso = 76, .mix = 48,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 40, .rv_size = 80, .tw = {TWEND}},
    {.name = "AFRICA 2", .rv_mix = 20, .tone = {T_STR3, T_STR4}, .level = {115, 110}, .brill = 60, .reso = 64, .detune = 66,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 50, .rv_size = 70,
     .tw = {TW(2, lp_cut, 70), TW(2, f_al, 76), TW(2, f_a, 59), TW(2, f_d, 116), TW(2, v_d, 124), TW(2, v_s, 0)}},
    {.name = "ROSANNA", .rv_mix = 28, .tone = {T_BRS1, T_BRS2}, .level = {115, 110}, .brill = 62, .reso = 68, .detune = 67,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 50, .v_a = 20, .rv_size = 70, .tw = {TWEND}},
    {.name = "HUMAN NATURE", .rv_mix = 32, .tone = {T_STR1, T_BRS2}, .level = {110, 110}, .brill = 58, .reso = 80, .detune = 66,
     .porta = 22, .gliss = 1, .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 75, .rv_size = 85,
     .tw = {TW(0, v_r, 95), TWEND}},
    {.name = "BILLIE JEAN", .rv_mix = 32, .tone = {T_STR1, T_BRS2}, .level = {110, 110}, .brill = 58, .reso = 64, .detune = 66,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 75, .rv_size = 85, .tw = {TW(0, v_r, 90), TWEND}},
    /* Syntorial's Billie Jean keys recipe: a narrow pulse, PWM at a quarter note, a short filter blip, fast csn_chorus */
    {.name = "BILLIE KEYS", .rv_mix = 32, .tone = {T_HARP1, T_HARP2}, .level = {118, 0}, .mix = 0, .brill = 62, .reso = 60,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 60, .cho_depth = 45, .rv_size = 75,
     .tw = {TW(0, pw, 113), TW(0, pwm, 76), TW(0, pwm_spd, 63), TW(0, lp_cut, 83), TW(0, f_al, 70), TW(0, f_d, 83)}},
    /* ---- the eighties */
    {.name = "BORN USA", .rv_mix = 36, .tone = {T_BRS1, T_STR2}, .level = {118, 100}, .brill = 74, .reso = 62, .detune = 68,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 26, .cho_depth = 45, .v_a = 12, .rv_size = 90, .tw = {TW(1, lp_cut, 100), TWEND}},
    {.name = "XMAS BASS", .rv_mix = 16, .tone = {T_STR1, T_BASS}, .level = {0, 120}, .mix = 127, .brill = 84, .reso = 118,
     .lfo_wave = csn_LW_SAWDN, .lfo_spd = 70, .lfo_vcf = 60, .rv_size = 50, .tw = {TW(1, v_r, 40), TWEND}},
    {.name = "WHO BASS", .rv_mix = 20, .tone = {T_BASS, T_BASS}, .feet1 = {F16, F8}, .level = {120, 90}, .brill = 70, .reso = 90, .detune = 66,
     .rv_size = 60, .tw = {TW(2, lp_res, 90), TW(2, f_al, 100), TW(2, f_d, 60), TWEND}},
    {.name = "BABOOSHKA", .rv_mix = 32, .tone = {T_FLUTE, T_ORG2}, .level = {118, 55}, .brill = 66, .detune = 67,
     .porta = 40, .at_vco = 26, .at_brill = 30, .lfo_spd = 66, .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 50,
     .v_a = 20, .aat_delay = 45, .aat_rise = 60, .aat_level = 80, .rv_size = 80, .dly_time = 80, .dly_fb = 35, .dly_mix = 25, .dly_tape = 50, .dly_sync = 3, .tw = {TWEND}},
    {.name = "DUCHESS", .rv_mix = 48, .tone = {T_STR3, T_STR4}, .level = {115, 110}, .brill = 60, .reso = 64, .detune = 70,
     .porta = 45, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18, .cho_depth = 80, .v_a = 70, .v_r = 85, .rv_size = 100, .tw = {TWEND}},
    {.name = "TURN IT ON", .rv_mix = 24, .tone = {T_BRS1, T_BRS3}, .level = {118, 110}, .brill = 70, .reso = 70, .detune = 68,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 26, .cho_depth = 45, .v_a = 8, .rv_size = 70, .tw = {TW(2, f_a, 20), TWEND}},
    {.name = "TIME STRINGS", .rv_mix = 52, .ph_rate = 28, .ph_depth = 70, .ph_fb = 35, .ph_mix = 55, .tone = {T_STR1, T_STR2}, .level = {115, 115}, .brill = 58, .reso = 64, .detune = 71,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 16, .cho_depth = 90, .v_a = 80, .v_r = 100, .rv_size = 110, .tw = {TWEND}},
    {.name = "VIENNA", .rv_mix = 56, .ph_rate = 30, .ph_depth = 50, .ph_fb = 20, .ph_mix = 35, .tone = {T_STR1, T_BRS3}, .level = {115, 95}, .brill = 54, .reso = 72, .detune = 69,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 65, .v_a = 55, .v_r = 90, .rv_size = 110,
     .dly_time = 100, .dly_fb = 50, .dly_mix = 35, .dly_tape = 50, .dly_ping = 1, .dly_sync = 4, .tw = {TWEND}},
    {.name = "OXYGENE", .rv_mix = 64, .tone = {T_STR3, T_STR4}, .feet1 = {F8, F16}, .level = {115, 100}, .brill = 56, .detune = 72,
     .lfo_spd = 50, .lfo_vcf = 25, .cho_mode = csn_CHO_CHORUS, .cho_spd = 14, .cho_depth = 95, .v_a = 90, .v_r = 110,
     .rv_size = 120, .rv_shim = 20, .tw = {TW(0, pwm, 60), TW(0, pwm_spd, 36), TW(0, wave, csn_W_BOTH), TWEND}},
    {.name = "ENO WASH", .rv_mix = 76, .ph_rate = 12, .ph_depth = 90, .ph_fb = 50, .ph_mix = 50, .tone = {T_STR3, T_ORG2}, .feet1 = {F8, F16}, .level = {110, 80}, .brill = 48, .detune = 70,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 12, .cho_depth = 85, .v_a = 110, .v_r = 115, .rv_size = 125, .rv_damp = 70,
     .rv_shim = 35, .tw = {TWEND}},
    {.name = "WALKING", .rv_mix = 28, .tone = {T_STR3, T_FNK2}, .level = {110, 110}, .brill = 72, .reso = 84, .detune = 68,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 44, .cho_depth = 95, .v_a = 15, .rv_size = 75,
     .tw = {TW(1, wave, csn_W_PULSE), TW(1, pw, 40), TW(1, pwm, 70), TW(1, hp_cut, 55), TW(0, hp_cut, 50), TWEND}},
    {.name = "4001 PLUCK", .rv_mix = 36, .tone = {T_STR3, T_STR4}, .level = {118, 0}, .mix = 0, .brill = 58, .reso = 100,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 50, .v_r = 100, .rv_size = 90,
     .tw = {TW(0, hp_cut, 55), TW(0, lp_cut, 35), TW(0, lp_res, 120), TW(0, f_al, 110), TW(0, f_d, 45), TW(0, f_a, 0)}},
    {.name = "4001 STRINGS", .rv_mix = 40, .ph_rate = 22, .ph_depth = 60, .ph_fb = 30, .ph_mix = 45, .tone = {T_STR1, T_STR2}, .feet1 = {F8, F16}, .level = {115, 110}, .brill = 110, .reso = 64, .detune = 68,
     .lfo_spd = 78, .lfo_vco = 20, .cho_mode = csn_CHO_CHORUS, .cho_spd = 22, .cho_depth = 60, .v_a = 64, .v_r = 90,
     .rv_size = 95, .tw = {TW(2, lp_cut, 127), TW(2, hp_cut, 0), TWEND}},
    {.name = "LONG BRASS", .rv_mix = 60, .tone = {T_BRS2, T_BRS3}, .level = {112, 112}, .brill = 60, .reso = 66, .detune = 70,
     .at_vco = 22, .at_brill = 100, .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 60, .v_a = 95, .v_r = 90,
     .aat_delay = 70, .aat_rise = 100, .aat_level = 110, .aat_fall = 70, .rv_size = 110,
     .dly_time = 104, .dly_fb = 55, .dly_mix = 40, .dly_tape = 50, .dly_ping = 1, .dly_sync = 5, .tw = {TWEND}},
    {.name = "SHRIEK LEAD", .rv_mix = 48, .tone = {T_FNK3, T_FNK1}, .feet1 = {F2, F4}, .level = {115, 90}, .brill = 80, .reso = 96, .detune = 70,
     .porta = 20, .at_vco = 34, .at_brill = 60, .cho_mode = csn_CHO_CHORUS, .cho_spd = 30, .cho_depth = 50,
     .rv_size = 100, .dly_time = 90, .dly_fb = 50, .dly_mix = 35, .dly_tape = 50, .tw = {TWEND}},
    {.name = "SQUELCH BASS", .rv_mix = 12, .tone = {T_FNK1, T_BASS}, .feet1 = {F16, F16}, .level = {110, 110}, .brill = 60, .reso = 100, .detune = 66,
     .rv_size = 50, .tw = {TW(2, f_a, 0), TW(2, f_d, 50), TW(2, v_r, 35), TWEND}},
    /* ---- the manual's own examples and the plain pairs */
    {.name = "TRUMPET", .rv_mix = 28, .tone = {T_BRS1, T_BRS2}, .level = {115, 60}, .brill = 70, .reso = 64, .detune = 66,
     .lfo_spd = 64, .lfo_vco = 30, .v_a = 25, .v_r = 45, .rv_size = 75,
     .tw = {TW(0, f_il, 16), TW(0, f_al, 112), TW(0, lp_cut, 80), TWEND}},
    {.name = "CLARINET", .rv_mix = 28, .tone = {T_CLAV1, T_EPIANO}, .level = {118, 0}, .mix = 0, .brill = 58, .lfo_spd = 62, .lfo_vco = 22,
     .v_a = 40, .v_r = 50, .rv_size = 80,
     .tw = {TW(0, pw, 0), TW(0, pwm, 0), TW(0, lp_cut, 72), TW(0, f_al, 76), TW(0, f_d, 70), TW(0, lp_res, 20)}},
    {.name = "OBOE", .rv_mix = 28, .tone = {T_HARP1, T_HARP2}, .level = {118, 0}, .mix = 0, .brill = 64, .lfo_spd = 64, .lfo_vco = 20,
     .v_a = 35, .v_r = 50, .rv_size = 80,
     .tw = {TW(0, pw, 113), TW(0, hp_cut, 60), TW(0, lp_cut, 90), TW(0, f_al, 84), TW(0, f_d, 65), TW(0, v_s, 110)}},
    {.name = "TIMPANI", .rv_mix = 36, .tone = {T_GTR1, T_BASS}, .feet1 = {F8, F16}, .level = {100, 118}, .brill = 56, .reso = 76, .detune = 64,
     .lfo_spd = 40, .rv_size = 85,
     .tw = {TW(0, wave, csn_W_SAW), TW(0, noise, 120), TW(0, vcf_lv, 100), TW(0, f_r, 60), TW(1, sine, 100), TW(1, pwm, 40)}},
    {.name = "STRINGS 1+2", .rv_mix = 28, .tone = {T_STR1, T_STR2}, .cho_mode = csn_CHO_OFF, .rv_size = 80, .tw = {TWEND}},
    {.name = "BRASS 1+2", .rv_mix = 20, .tone = {T_BRS1, T_BRS2}, .cho_mode = csn_CHO_OFF, .rv_size = 60, .tw = {TWEND}},
    {.name = "FLUTE+BASS", .rv_mix = 24, .tone = {T_FLUTE, T_BASS}, .level = {110, 100}, .cho_mode = csn_CHO_OFF, .rv_size = 70, .tw = {TWEND}},
    {.name = "ORGANS", .rv_mix = 32, .ph_rate = 60, .ph_depth = 50, .ph_fb = 20, .ph_mix = 60, .tone = {T_ORG1, T_ORG2}, .feet1 = {F8, F4}, .level = {110, 100}, .brill = 72, .reso = 76,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 40, .cho_depth = 60, .rv_size = 90, .tw = {TWEND}},
    {.name = "CLAVS", .rv_mix = 12, .tone = {T_CLAV1, T_CLAV2}, .level = {110, 100}, .cho_mode = csn_CHO_OFF, .rv_size = 50, .tw = {TWEND}},
    {.name = "HARPSI", .rv_mix = 20, .tone = {T_HARP1, T_HARP2}, .cho_mode = csn_CHO_OFF, .rv_size = 60, .tw = {TWEND}},
    {.name = "E.PIANO", .rv_mix = 24, .tone = {T_EPIANO, T_STR4}, .level = {120, 50}, .cho_mode = csn_CHO_CHORUS, .cho_spd = 30, .cho_depth = 50,
     .rv_size = 70, .dly_mix = 20, .dly_tape = 50, .tw = {TWEND}},
    {.name = "FUNKY 1+2", .rv_mix = 12, .tone = {T_FNK1, T_FNK2}, .cho_mode = csn_CHO_OFF, .rv_size = 50, .tw = {TWEND}},
    /* ---- with the effects */
    {.name = "TAPE PAD", .tone = {T_STR1, T_STR4}, .level = {110, 100}, .brill = 58, .reso = 60, .detune = 72, .cho_mode = csn_CHO_CHORUS, .cho_spd = 18,
     .cho_depth = 70, .v_a = 85, .v_r = 95, .aat_delay = 60, .aat_rise = 80, .aat_level = 70, .rv_mix = 55, .rv_size = 105, .rv_damp = 60,
     .dly_time = 95, .dly_fb = 60, .dly_mix = 40, .dly_ping = 1, .dly_sync = 4, .dly_tape = 90, .ph_rate = 15, .ph_depth = 60, .ph_fb = 25, .ph_mix = 35,
     .vintage = 50, .tw = {TWEND}},
    {.name = "SHIMMER CHOIR", .tone = {T_FLUTE, T_STR4}, .feet1 = {F8, F4}, .level = {115, 95}, .brill = 62, .cho_mode = csn_CHO_CHORUS, .cho_spd = 22,
     .cho_depth = 65, .v_a = 100, .v_r = 110, .aat_delay = 70, .aat_rise = 90, .aat_level = 60, .rv_mix = 85, .rv_size = 122, .rv_damp = 35, .rv_shim = 65,
     .vintage = 40, .tw = {TW(2, sine, 60), TWEND}},
    {.name = "PHASE STRINGS", .tone = {T_STR1, T_STR2}, .detune = 70, .cho_mode = csn_CHO_CHORUS, .cho_spd = 24, .cho_depth = 60, .v_a = 50, .v_r = 80,
     .rv_mix = 40, .rv_size = 90, .ph_rate = 32, .ph_depth = 95, .ph_fb = 70, .ph_mix = 100, .vintage = 35, .tw = {TWEND}},
    {.name = "ECHO KEYS", .tone = {T_EPIANO, T_CLAV2}, .mix = 50, .brill = 66, .cho_mode = csn_CHO_CHORUS, .cho_spd = 40, .cho_depth = 45, .v_r = 60,
     .rv_mix = 30, .rv_size = 75, .dly_time = 88, .dly_fb = 55, .dly_mix = 45, .dly_ping = 1, .dly_sync = 5, .dly_tape = 75, .tw = {TWEND}},
    {.name = "TAPE BRASS", .tone = {T_BRS1, T_BRS3}, .level = {115, 105}, .brill = 60, .reso = 66, .detune = 71, .porta = 20, .at_vco = 30, .at_brill = 80,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 20, .cho_depth = 70, .v_a = 60, .aat_delay = 45, .aat_rise = 70, .aat_level = 95, .rv_mix = 50, .rv_size = 100,
     .dly_time = 100, .dly_fb = 50, .dly_mix = 40, .dly_ping = 1, .dly_sync = 3, .dly_tape = 65, .vintage = 40, .tw = {TWEND}},
    {.name = "DEEP DRIFT", .tone = {T_STR3, T_BASS}, .feet1 = {F8, F16}, .level = {105, 115}, .brill = 50, .reso = 70, .detune = 75, .lfo_wave = csn_LW_SINE,
     .lfo_spd = 30, .lfo_vcf = 25, .cho_mode = csn_CHO_CHORUS, .cho_spd = 14, .cho_depth = 80, .v_a = 90, .v_r = 100, .aat_delay = 50, .aat_rise = 80,
     .aat_level = 80, .rv_mix = 60, .rv_size = 110, .rv_damp = 65, .rv_shim = 25, .ph_rate = 8, .ph_depth = 100, .ph_fb = 55, .ph_mix = 70, .vintage = 70,
     .tw = {TWEND}},
    {.name = "GLASS PIPES", .tone = {T_GLASS1, T_GLASS2}, .feet1 = {F8, F53}, .level = {36, 36}, .brill = 59, .reso = 76, .lfo_spd = 85, .at_vco = 13, .rv_shift = 7,
     .cho_mode = csn_CHO_CHORUS, .cho_spd = 25, .cho_depth = 70, .rv_mix = 70, .rv_size = 85, .rv_damp = 55, .rv_shim = 100,
     .dly_fb = 45, .dly_mix = 45, .dly_ping = 1, .dly_sync = 3, .dly_tape = 30, .tw = {TWEND}},   /* after Arturia's "Glass Pipes": the panels read off its screen */
};
#define CS1_NSOUND (sizeof CS1_SOUNDS / sizeof CS1_SOUNDS[0])


#define DEF(v, d) ((v) ? (v) : (d))
static void cs1_factory(csn_patch_t *p,uint32_t i)
{
    const sound_t *sd = &CS1_SOUNDS[i % CS1_NSOUND];
    uint32_t ch;
    for (ch = 0; ch < CS1_NCH; ch++) {
        p->ch[ch] = csn_TONES[sd->tone[ch] % csn_NTONE];
        p->ch[ch].feet = sd->feet1[ch] ? (uint8_t)(sd->feet1[ch] - 1u) : (uint8_t)csn_FT_8;
        p->ch[ch].level = DEF(sd->level[ch], 110);
    }
    p->brill = DEF(sd->brill, 64);
    p->reso = DEF(sd->reso, 64);
    p->detune = DEF(sd->detune, 64);
    p->mix = DEF(sd->mix, 64);
    p->porta = sd->porta;
    p->gliss = sd->gliss;
    p->pbend = sd->pbend;
    p->at_spd = 0;
    p->at_vco = DEF(sd->at_vco, 30);
    p->at_vcf = sd->at_vcf;
    p->lfo_wave = sd->lfo_wave;
    p->lfo_spd = DEF(sd->lfo_spd, 60);
    p->lfo_vco = sd->lfo_vco;
    p->lfo_vcf = sd->lfo_vcf;
    p->lfo_vca = 0;
    p->cho_mode = sd->cho_mode;
    p->cho_spd = DEF(sd->cho_spd, 30);
    p->cho_depth = DEF(sd->cho_depth, 60);
    p->rm_mod = sd->rm_mod;
    p->rm_spd = DEF(sd->rm_spd, 64);
    p->rm_depth = sd->rm_depth;
    p->rm_a = 10;
    p->rm_d = DEF(sd->rm_d, 60);
    p->aat_delay = sd->aat_delay;
    p->aat_rise = DEF(sd->aat_rise, 60);
    p->aat_level = sd->aat_level;
    p->aat_fall = DEF(sd->aat_fall, 40);
    p->rv_mix = sd->rv_mix;
    p->rv_size = DEF(sd->rv_size, 80);
    p->rv_damp = DEF(sd->rv_damp, 50);
    p->rv_shim = sd->rv_shim;
    p->rv_shift = DEF(sd->rv_shift, 12);
    p->dly_time = DEF(sd->dly_time, 70);
    p->dly_fb = DEF(sd->dly_fb, 50);
    p->dly_mix = sd->dly_mix;
    p->dly_ping = sd->dly_ping;
    p->dly_damp = 40;
    p->dly_sync = sd->dly_sync;
    p->dly_tape = sd->dly_tape;
    p->ph_rate = DEF(sd->ph_rate, 40); p->ph_depth = DEF(sd->ph_depth, 64); p->ph_fb = DEF(sd->ph_fb, 40); p->ph_mix = sd->ph_mix;
    p->lfo_sync = 0;
    p->vintage = DEF(sd->vintage, 30);
    p->kb_bl = p->kb_bh = p->kb_ll = p->kb_lh = 64;
    for (ch = 0; ch < CS1_NCH; ch++) {
        if (sd->at_brill) p->ch[ch].at_brill = sd->at_brill;
        if (sd->v_a) p->ch[ch].v_a = sd->v_a;
        if (sd->v_r) p->ch[ch].v_r = sd->v_r;
    }
    for (i = 0; i < 12u && sd->tw[i].ch < 3u; i++) {  /* the tweaks to the channels' own parameters */
        if (sd->tw[i].ch != 1u) ((uint8_t *)&p->ch[0])[sd->tw[i].off] = sd->tw[i].val;
        if (sd->tw[i].ch != 0u) ((uint8_t *)&p->ch[1])[sd->tw[i].off] = sd->tw[i].val;
    }
    p->volume=100;
}


#undef DEF
#undef TW
#undef TWEND
#undef F16
#undef F8
#undef F4
#undef F2
#undef F53
#undef F27
