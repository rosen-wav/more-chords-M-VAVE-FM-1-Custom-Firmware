#define CS1_NCH 2u
/* SPDX-License-Identifier: GPL-3.0-only */
/* Native CS-1 voice port. Upstream CS-1-main supplied by the user; see docs/CS1-INTEGRATION.md. */
/* SPDX-License-Identifier: GPL-3.0-only */
/* Fixed-point DSP building blocks for the CS-1 voice (the chip has no FPU: docs/RULES.md). The polyBLEP
 * oscillators, the soft clip and the trapezoidal SVF follow Felucca's dsp.c (Copyright (C) 2026 Leo Kuroshita,
 * Hügelton Instruments, GPL-3.0-only); the tables are firmware/gen/cs1_tables.h (tools/gen_tables.py).
 * Conventions: audio is Q15 (+-32767 full scale); a phase is 32 bits, a cycle wraps; pitch is in 1/16 semitone
 * (pitch16: MIDI note x 16, 0..2047) or 1/256 semitone (pitch256) where it glides. */
#include "cs1_tables.h"
#include "cs1_div.h"

static inline int32_t csn_mulq15(int32_t a, int32_t b) { return (int32_t)(((int64_t)a * b) >> 15); }
/* a leaky integrator's leak that always moves the state at least a step toward 0 (a plain shift parks it a few LSB off) */
static inline int32_t csn_leak10(int32_t y) { return y > 0 ? (y + 1023) >> 10 : y >> 10; }
static inline int32_t csn_mulq15r(int32_t a, int32_t b) { return (int32_t)(((int64_t)a * b) / 32768); }   /* toward zero, either sign: no bias, and a feedback loop's gain is below one at the last bit, so it decays to 0 (a shift floors, and holds -1 for ever) */
static inline int32_t csn_clamp(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }

/* a sine of the phase, linearly interpolated between the 1024 table points */
static inline int32_t csn_sine_i(uint32_t ph)
{
    uint32_t i = ph >> 22;
    int32_t a = csn_SINE[i], b = csn_SINE[(i + 1u) & 1023u];
    return a + (((b - a) * (int32_t)((ph >> 7) & 0x7FFFu)) >> 15);
}

/* polyBLEP residual (Q15) around a wrap of a phase accumulator */
static inline int32_t csn_blep(uint32_t ph, uint32_t inc)
{
    uint32_t d = inc >> 15;
    int32_t x;
    if (!d)
        return 0;
    if (ph < inc) {
        x = (int32_t)(ph / d);                       /* 0..32767 */
        return x + x - ((x * x) >> 15) - 32768;
    }
    if (ph > 0xFFFFFFFFu - inc) {
        x = -(int32_t)((0xFFFFFFFFu - ph) / d);       /* -32767..0 */
        return ((x * x) >> 15) + x + x + 32768;
    }
    return 0;
}
static inline int32_t csn_osc_saw(uint32_t ph, uint32_t inc) { return ((int32_t)(ph >> 16) - 32768) - csn_blep(ph, inc); }
/* a pulse of width pw (the phase offset of the falling edge: 2^31 = square) */
static inline int32_t csn_osc_pulse(uint32_t ph, uint32_t inc, uint32_t pw) { return (csn_osc_saw(ph, inc) - csn_osc_saw(ph + pw, inc)) >> 1; }

/* Cache only when an edge needs BLEP; low saw notes need no extra divide
 * on blocks with no edge. The divisor may stay equal across pitch updates. */
static inline int32_t csn_blep_cached(uint32_t ph,uint32_t inc,csn_div_t *c)
{
    uint32_t d=inc>>15;
    if(!d)return 0;
    if(ph<inc){
        csn_div_prepare(c,d);int32_t x=(int32_t)csn_div_exact(c,ph);
        return x+x-((x*x)>>15)-32768;
    }
    if(ph>UINT32_MAX-inc){
        csn_div_prepare(c,d);int32_t x=-(int32_t)csn_div_exact(c,UINT32_MAX-ph);
        return ((x*x)>>15)+x+x+32768;
    }
    return 0;
}
static inline int32_t csn_saw_cached(uint32_t ph,uint32_t inc,csn_div_t *c)
{return ((int32_t)(ph>>16)-32768)-csn_blep_cached(ph,inc,c);}

/* tanh(x / 32768) * 32767, linearly interpolated */
static inline int32_t csn_softclip(int32_t x)
{
    int32_t a = x < 0 ? -x : x, i = a >> 8, y;
    if (i >= 256)
        y = csn_TANH_Q15[256];
    else
        y = csn_TANH_Q15[i] + (((csn_TANH_Q15[i + 1] - csn_TANH_Q15[i]) * (a & 255)) >> 8);
    return x < 0 ? -y : y;
}
/* linear up to k, then a soft knee: only the peaks above k saturate */
static inline int32_t csn_soft_knee(int32_t y, int32_t k)
{
    int32_t a = y < 0 ? -y : y;
    if (a <= k)
        return y;
    a = k + (csn_softclip((a - k) * 2) >> 1);
    return y < 0 ? -a : a;
}

static inline uint32_t csn_noise32(uint32_t *st)        /* xorshift32 */
{
    uint32_t s = *st;
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    *st = s;
    return s;
}

/* the phase increment of a pitch: whole 1/16 semitones from the top octave's table, shifted down */
static inline uint32_t csn_pitch_inc(int32_t pitch16)
{
    uint32_t p = (uint32_t)csn_clamp(pitch16, 0, 2047), oct = p / 192u;
    return csn_PITCH16[p - oct * 192u] >> (10u - oct);
}
/* in 1/256 semitone: the rest as a factor 2^(r / 3072) ~ 1 + r x 14.8 / 65536 */
static inline uint32_t csn_pitch_inc256(int32_t pitch256)
{
    int32_t p = csn_clamp(pitch256, 0, 2047 * 16 + 15);
    uint32_t inc = csn_pitch_inc(p >> 4);
    return inc + (inc >> 16) * (uint32_t)((p & 15) * 15);
}

/* Trapezoidal SVF (A. Simper), unconditionally stable. Coefficients per control tick in Q13; the states stay
 * within +-150000 so the products fit in 32 bits. cut16: the cutoff as a pitch (1/16 semitone, MIDI 0..135),
 * k: the damping in Q12 (8192 = 2.0, no resonance; ~600 = 0.15, near self-oscillation). */
typedef struct { int32_t a1, a2, a3, k, cut16; } csn_svf_t;
static inline void csn_svf_coef(csn_svf_t *c, int32_t cut16, int32_t k)
{
    int32_t i, g, den;
    cut16 = csn_clamp(cut16, 0, 135 * 16);
    if(c->a1 && c->cut16==cut16 && c->k==k)return;
    c->cut16=cut16;
    i = cut16 >> 4;
    g = csn_SVF_G[i] + (((csn_SVF_G[i + 1] - csn_SVF_G[i]) * (cut16 & 15)) >> 4);
    den = 4096 + ((g * (g + k)) >> 12);
    c->a1 = (int32_t)((4096u << 13) / (uint32_t)den);
    c->a2 = (c->a1 * g) >> 12;
    c->a3 = (c->a2 * g) >> 12;
    c->k = k;
}
#define csn_SVF_K(res) ((int32_t)csn_SVF_KT[(res)])        /* resonance 0..127 -> damping Q12 (cs1_tables.h): 2.0 .. 0.32, the peak
                                                     * rising fast then levelling near +10 dB; the CS-80's filters never self-oscillate */
/* one sample: lp, bp and hp of in; the states ic1, ic2 */
static inline void csn_svf_step(const csn_svf_t *c, int32_t in, int32_t *ic1, int32_t *ic2, int32_t *lp, int32_t *hp)
{
    int32_t v3 = in - *ic2;
    int32_t v1 = ((int64_t)c->a1 * *ic1 + (int64_t)c->a2 * v3 + 4096) >> 13;       /* rounded: the state settles at 0, not a few LSB below */
    int32_t v2 = *ic2 + (((int64_t)c->a2 * *ic1 + (int64_t)c->a3 * v3 + 4096) >> 13);
    *ic1 = csn_clamp(2 * v1 - *ic1, -150000, 150000);
    *ic2 = csn_clamp(2 * v2 - *ic2, -150000, 150000);
    *lp = v2;
    *hp = in - ((c->k * v1) >> 12) - v2;
}

enum { csn_FT_16 = 0, csn_FT_8, csn_FT_53, csn_FT_4, csn_FT_27, csn_FT_2 };  /* feet: the octave of a channel, with the fifths (5 1/3', 2 2/3') between */
enum { csn_W_SAW = 0, csn_W_PULSE, csn_W_BOTH };                 /* the VCO's wave */
enum { csn_LW_SINE = 0, csn_LW_TRI, csn_LW_SAW, csn_LW_SAWDN, csn_LW_SQR };   /* the sub oscillator's: sine, triangle, sawtooth, inverted sawtooth, square */

typedef struct {                  /* a channel's panel: 0..127 unless said; the order is the settings' and
                                   * tools/gen_presets.py's */
    uint8_t feet, wave, pw, pwm;                      /* VCO: feet (0..5), wave (0..2), pulse width, PWM depth */
    uint8_t pwm_spd, noise, sine, vcf_lv, level;      /* PWM speed, noise; the sine after the filters, the filtered
                                                       * signal and the channel's level (the VCA section) */
    uint8_t hp_cut, hp_res, lp_cut, lp_res;           /* the filters */
    uint8_t f_il, f_al, f_a, f_d, f_r;                /* VCF envelope: initial level, attack level (64 = 0), A, D, R */
    uint8_t v_a, v_d, v_s, v_r;                       /* VCA envelope */
    uint8_t it_brill, it_level, at_brill, at_level;   /* touch response: initial (velocity), after (pressure) */
} csn_chan_patch_t;
typedef struct {
    csn_chan_patch_t ch[CS1_NCH];
    uint8_t lfo_spd, lfo_wave, lfo_vco, lfo_vcf, lfo_vca;   /* the sub oscillator and its depths */
    uint8_t brill, reso, volume;                      /* brilliance (64 = 0), resonance (64 = 0), the output level */
    uint8_t detune, porta, gliss, pbend;              /* channel II's detune (64 = 0), portamento time, glissando
                                                       * (0 / 1), the initial pitch bend (velocity: starts below) */
    uint8_t at_spd, at_vco, at_vcf;                   /* pressure: faster sub oscillator, more of it to pitch, filter */
    uint8_t rm_mod, rm_spd, rm_depth, rm_a, rm_d;     /* the ring modulator: mix, rate, the envelope on the rate */
    uint8_t cho_mode, cho_spd, cho_depth;             /* 0 off, 1 csn_chorus, 2 tremolo; speed; depth */
    uint8_t aat_delay, aat_rise, aat_level, aat_fall; /* auto after touch: a pressure curve every note plays by
                                                       * itself (a sequencer has no hands): the wait, the rise to
                                                       * the level, the fall after the key goes */
    uint8_t dly_time, dly_fb, dly_mix, dly_ping, dly_damp;   /* the delay (cs1_fx.h) */
    uint8_t rv_mix, rv_size, rv_damp, rv_shim;        /* the reverb and its shimmer */
    uint8_t rv_shift;                                 /* the shimmer's interval, semitones (12 = the octave) */
    uint8_t mix;                                      /* the MIX lever: I (0) .. both (64) .. II (127) */
    uint8_t vintage;                                  /* the voices' drift: each wanders a few cents on its own */
    uint8_t dly_sync, lfo_sync;                       /* MIDI clock: the delay's and the sub oscillator's divisions, 0 free */
    uint8_t kb_bl, kb_bh, kb_ll, kb_lh;               /* KEYBOARD CONTROL: brilliance and level, LOW and HIGH (64 = flat) */
    uint8_t dly_tape;                                 /* TAPE: wow and flutter, saturation and darkening in the delay's loop */
    uint8_t ph_rate, ph_depth, ph_fb, ph_mix;         /* the phaser */
} csn_patch_t;
_Static_assert(sizeof(csn_patch_t) <= 104, "the patch fits the settings and a bank slot");
enum { csn_CHO_OFF = 0, csn_CHO_CHORUS, csn_CHO_TREMOLO };

typedef struct {
    uint32_t ph;                  /* the VCO */
    int32_t h1, h2, l1, l2;       /* the filters' states */
    int32_t fenv, fenv_inc;       /* VCF envelope: semitones in 1/4096; the attack's step a tick */
    int32_t venv;                 /* VCA envelope, Q24 */
    int32_t amp;                  /* the level at the last tick (Q15): the ramp's start */
    int32_t at16;                 /* the pressure the last block ended on (Q15): a step in it ramps over the block */
    uint8_t fstage, vstage;       /* 0 attack 1 decay 2 rest 3 release; 0 off 1 attack 2 decay 3 sustain 4 release */
    csn_svf_t hp, lp;
    csn_div_t blep_div;
    int32_t filter_input, filter_output; /* half-rate filter reconstruction */
} csn_chan_state_t;
typedef struct {
    volatile uint8_t note, vel, gate;   /* the main loop's: the note, its velocity, held (0: released) */
    volatile uint8_t at;                /* the main loop's: the pressure on it (after touch), 0..127 */
    volatile uint16_t at_eff;           /* the render's: the pressure in effect (the key's or the auto curve's), Q15 */
    uint32_t aat_t;                     /* the render's: ticks since the note started (the auto curve's clock) */
    int32_t aat;                        /* the render's: the auto curve, Q24 */
    volatile uint32_t trig;             /* the main loop's: counts up on every note-on */
    volatile uint8_t active;            /* the render's: sounding (any channel's VCA envelope running) */
    uint32_t seen;                      /* the render's: the trig it last started */
    uint32_t age;                       /* the main loop's: allocation order */
    int32_t pitch256;                   /* the render's: the pitch now (1/256 semitone), the glide's position */
    int32_t pb256;                      /* the render's: the initial pitch bend left (negative, decays to 0) */
    int32_t drift, drift_to;            /* the render's: this voice's tuning drift (1/256 semitone) and where it wanders */
    uint32_t drift_rng;                 /* its own random numbers */
    volatile int32_t from256;           /* the main loop's: where a glide starts (the note played before) */
    csn_chan_state_t c[CS1_NCH];
} csn_voice_t;


typedef struct {
 csn_patch_t patch;
 uint32_t valid,aat_wait;
 int32_t aat_rise_step;
 csn_div_t aat_fall;
 int32_t level[2],noise[2],sine[2],vcf[2],hp_base[2],lp_base[2],hp_k[2],lp_k[2];
 int32_t it_level[2],at_level[2],at_brill[2],brill,vca_depth;
} csn_prepared_t;
typedef struct {
 csn_voice_t voices[NVOICE];
 csn_prepared_t prepared;
 int32_t g_lfo[1],g_pwm[2][1];int16_t g_noise[CTL];int32_t g_at;
 uint32_t lfo_ph,pwm_ph[2],noise_st,rm_ph,rm_seen,rm_trig;
 int32_t rm_env;uint8_t rm_stage;
 int16_t cho_line[1024];uint32_t cho_w,cho_ph;
 csn_svf_t tone_c;int32_t tone_s1,tone_s2,dc_x,dc_y;
 int32_t last256;uint8_t ready;
 /* Native patch is external to the state union, so an engine transition can clear DSP without losing edits. */
 const csn_patch_t *patch_ptr;
} cs1_part_t;
static int32_t csn_lfo_shape(uint32_t ph, uint32_t wave)
{
    int32_t s;
    switch (wave) {
    default: return csn_sine_i(ph);
    case csn_LW_TRI: s = (int32_t)(ph >> 15); return s < 65536 ? s - 32768 : 98303 - s;
    case csn_LW_SAW: return (int32_t)(ph >> 16) - 32768;
    case csn_LW_SAWDN: return 32767 - (int32_t)(ph >> 16);
    case csn_LW_SQR: return ph < 0x80000000u ? 32767 : -32767;
    }
}

static void csn_prepare_patch(cs1_part_t *e)
{
 csn_prepared_t *q=&e->prepared;const csn_patch_t *p=e->patch_ptr;
 if(q->valid && !memcmp(&q->patch,p,sizeof *p))return;
 memcpy(&q->patch,p,sizeof *p);q->valid=1;
 q->aat_wait=(uint32_t)p->aat_delay*p->aat_delay*5512u>>14;
 uint32_t rise=2u+((uint32_t)p->aat_rise*p->aat_rise*881u>>14);
 q->aat_rise_step=((int32_t)p->aat_level<<17)/(int32_t)(rise*8u);
 uint32_t fall=1u+((uint32_t)p->aat_fall*p->aat_fall*881u>>14);
 csn_div_prepare(&q->aat_fall,fall*8u);
 q->brill=((int32_t)p->brill-64)*12;q->vca_depth=p->lfo_vca*258;
 for(uint32_t ch=0;ch<2u;ch++){
  const csn_chan_patch_t *c=&p->ch[ch];
  int32_t bal=ch?(p->mix<64u?p->mix*2:127):(p->mix>64u?(127-p->mix)*2:127);
  q->level[ch]=csn_mulq15(c->level*258,bal*258);
  q->noise[ch]=c->noise*258;q->sine[ch]=c->sine*258;q->vcf[ch]=c->vcf_lv*258;
  q->hp_base[ch]=128+c->hp_cut*15;q->lp_base[ch]=256+c->lp_cut*15;
  int32_t reso=(int32_t)p->reso-64;
  q->hp_k[ch]=csn_SVF_K(csn_clamp(c->hp_res+reso,0,127));
  q->lp_k[ch]=csn_SVF_K(csn_clamp(c->lp_res+reso,0,127));
  q->it_level[ch]=c->it_level*258;q->at_level[ch]=c->at_level*129;q->at_brill[ch]=c->at_brill*258;
 }
}

static void csn_block_prepare(cs1_part_t *e)
{
    uint32_t t, i, ch, spd;
    csn_prepare_patch(e);
    /* Ribbon is the shared Remix MIDI bend. */ (void)0; //        /* the ribbon glides between detents */
    e->g_at = 0;
    for (i = 0; i < NVOICE; i++)
        if (e->voices[i].active && (e->voices[i].at_eff >> 8) > e->g_at) e->g_at = e->voices[i].at_eff >> 8;
    spd = (*e->patch_ptr).lfo_spd + ((127u - (*e->patch_ptr).lfo_spd) * (uint32_t)e->g_at * (*e->patch_ptr).at_spd >> 14);   /* AFTER SPEED */

    for (t = 0; t < 1u; t++) {
        e->lfo_ph += csn_LFO_INC[spd > 127u ? 127u : spd];
        e->g_lfo[t] = csn_lfo_shape(e->lfo_ph, (*e->patch_ptr).lfo_wave);
        for (ch = 0; ch < CS1_NCH; ch++) {
            e->pwm_ph[ch] += csn_LFO_INC[(*e->patch_ptr).ch[ch].pwm_spd];
            e->g_pwm[ch][t] = csn_lfo_shape(e->pwm_ph[ch], csn_LW_TRI);
        }
    }
    for (i = 0; i < CTL; i++)
        e->g_noise[i] = (int16_t)((int32_t)(csn_noise32(&e->noise_st) >> 17) - 16384);
}

/* ---- envelopes, once a control tick */
static inline void csn_venv_tick(csn_chan_state_t *s, const csn_chan_patch_t *p, uint32_t gate)
{
    int32_t target, diff;
    if (!gate && s->vstage && s->vstage < 4)
        s->vstage = 4;
    switch (s->vstage) {
    case 1:                                            /* attack: linear to full */
        s->venv += ((1 << 15) * (int32_t)csn_ATT_Q16[p->v_a]) >> 7;
        if (s->venv >= (1 << 24)) { s->venv = 1 << 24; s->vstage = 2; }
        break;
    case 2:                                            /* decay: exponential to the sustain level */
        target = (int32_t)p->v_s << 17;
        diff = target - s->venv;
        s->venv += ((diff >> 9) * (int32_t)csn_DEC_Q16[p->v_d]) >> 7;
        if (s->venv - target < 2048 && s->venv - target > -2048) { s->venv = target; s->vstage = 3; }
        break;
    case 4:                                            /* release: exponential to silence */
        s->venv -= ((s->venv >> 9) * (int32_t)csn_DEC_Q16[p->v_r]) >> 7;
        if (s->venv < 4096) { s->venv = 0; s->vstage = 0; }
        break;
    default:
        break;
    }
}
static inline void csn_fenv_tick(csn_chan_state_t *s, const csn_chan_patch_t *p, uint32_t gate)
{
    int32_t al = ((int32_t)p->f_al - 64) * 4096;        /* +-64 semitones, in 1/4096 */
    int32_t il = ((int32_t)p->f_il - 64) * 4096;
    if (!gate && s->fstage < 3)
        s->fstage = 3;
    switch (s->fstage) {
    case 0:                                            /* attack: linear from IL to AL */
        s->fenv += s->fenv_inc;
        if ((s->fenv_inc >= 0 && s->fenv >= al) || (s->fenv_inc < 0 && s->fenv <= al)) { s->fenv = al; s->fstage = 1; }
        break;
    case 1:                                            /* decay: exponential back to 0 */
        s->fenv -= ((s->fenv >> 6) * (int32_t)csn_DEC_Q16[p->f_d]) >> 10;
        if (s->fenv < 64 && s->fenv > -64) { s->fenv = 0; s->fstage = 2; }
        break;
    case 3:                                            /* released: exponential back to IL */
        s->fenv += (((il - s->fenv) >> 6) * (int32_t)csn_DEC_Q16[p->f_r]) >> 10;
        break;
    default:
        break;
    }
}
static void csn_chan_trigger(csn_chan_state_t *s, const csn_chan_patch_t *p)
{
    int32_t il = ((int32_t)p->f_il - 64) * 4096, al = ((int32_t)p->f_al - 64) * 4096;
    s->fenv = il;
    s->fenv_inc = (((al - il) >> 4) * (int32_t)csn_ATT_Q16[p->f_a]) >> 12;
    if (!s->fenv_inc) s->fenv_inc = al >= il ? 1 : -1;
    s->fstage = 0;
    s->vstage = 1;                                     /* a retrigger continues from the level it had: no click */
}

/* ---- one channel of one voice, one block */
static const int8_t csn_FEET_SEMIS[6] = {-12, 0, 7, 12, 19, 24};
static void csn_chan_render(cs1_part_t *e, csn_voice_t *v, uint32_t ch, int32_t *mix)
{
    csn_chan_state_t *s = &v->c[ch];
    const csn_chan_patch_t *p = &(*e->patch_ptr).ch[ch];
    uint32_t t, i, wave = p->wave, ph = s->ph;
    int32_t h1 = s->h1, h2 = s->h2, l1 = s->l1, l2 = s->l2;
    int32_t lo_w = v->note < 60u ? 60 - (int32_t)v->note : 0, hi_w = v->note > 60u ? (int32_t)v->note - 60 : 0;   /* 0 .. 36 */
    int32_t kbc16 = (((int32_t)(*e->patch_ptr).kb_bl - 64) * lo_w + ((int32_t)(*e->patch_ptr).kb_bh - 64) * hi_w) / 6;   /* +-24 semitones at the ends */
    int32_t kbc_lv = csn_clamp(32767 + (((int32_t)(*e->patch_ptr).kb_ll - 64) * lo_w + ((int32_t)(*e->patch_ptr).kb_lh - 64) * hi_w) * 14, 0, 32767);
    const csn_prepared_t *q=&e->prepared;
    int32_t level=csn_mulq15(q->level[ch],kbc_lv),sine_lv=q->sine[ch],noise_lv=q->noise[ch],vcf_lv=q->vcf[ch];
    int32_t vel = v->vel, at_to = v->at_eff, at_from = s->at16;    /* the pressure: ramped over the block (Q15) */
    int32_t vel_q15 = 32767 - csn_mulq15(q->it_level[ch], (127 - vel) * 258);     /* INITIAL LEVEL: 0 = no velocity */
    int32_t itouch16 = ((vel - 64) * p->it_brill * 6) >> 7;                     /* INITIAL BRILLIANCE: +-24 semitones */
    int32_t kbd16 = ((int32_t)v->note - 60) * 16;      /* the filters track the keyboard 1:1 (as the CS-80 V does) */
    int32_t brill16 = q->brill;
    int32_t pitch256 = v->pitch256 + v->pb256 + csn_FEET_SEMIS[p->feet] * 256 + (ch ? ((int32_t)(*e->patch_ptr).detune - 64) * 2 : 0);
    int32_t vca_depth = q->vca_depth;
    s->at16 = at_to;
    for (t = 0; t < 1u; t++) {
        int32_t lfo = e->g_lfo[t], amp0 = s->amp, amp1, cut16, hp_k, lp_k, pw_d;
        int32_t at = at_from + (((at_to - at_from) * (int32_t)(t + 1u)) / 1);   /* this tick's pressure, Q15 */
        int32_t at_q15 = 32767 - csn_mulq15(q->at_level[ch], 32767 - at);          /* AFTER LEVEL: -6 dB until pressed */
        int32_t touch16 = itouch16 + ((csn_mulq15(at, q->at_brill[ch]) * 576) >> 15);   /* AFTER BRILLIANCE: +36 semitones */
        int32_t vco_k = csn_clamp((int32_t)(*e->patch_ptr).lfo_vco + (csn_mulq15(at, (*e->patch_ptr).at_vco * 258) >> 8), 0, 127);   /* AFTER VCO: vibrato */
        int32_t vcf_k = csn_clamp((int32_t)(*e->patch_ptr).lfo_vcf + (csn_mulq15(at, (*e->patch_ptr).at_vcf * 258) >> 8), 0, 127);   /* AFTER VCF */
        int32_t vco_depth = vco_k * vco_k / 504;       /* up to +-2 semitones (1/16) */
        int32_t vcf_depth = vcf_k * vcf_k / 42;        /* up to +-24 semitones */
        uint32_t inc, pw;
        csn_venv_tick(s, p, v->gate);
        csn_fenv_tick(s, p, v->gate);
        if (!s->vstage && !amp0) {                     /* silent: this channel is done for the block */
            s->amp = 0;
            goto done;
        }
        /* the level this tick, ramped over its CTL frames from the last */
        amp1 = csn_mulq15(csn_mulq15(csn_mulq15(s->venv >> 9, vel_q15), at_q15), level);
        if (vca_depth)
            amp1 = csn_mulq15(amp1, 32767 - csn_mulq15(vca_depth, (32767 - lfo) >> 1));
        if (!s->vstage) amp1 = 0;
        s->amp = amp1;
        /* the pitch: feet, vibrato */
        inc = csn_pitch_inc256(pitch256 + ((lfo * vco_depth) >> 11));
        /* the pulse width: 50 % .. 95 % and the PWM triangle, kept within 5 .. 95 % */
        pw_d = p->pw * 7598415 + csn_mulq15(e->g_pwm[ch][t], p->pwm) * 7598415;
        pw = 0x80000000u + (uint32_t)csn_clamp(pw_d, -966367641, 966367641);
        /* the filters: the knobs as a pitch, then the envelope, brilliance, the LFO and the keyboard */
        cut16 = (s->fenv >> 8) + brill16 + ((lfo * vcf_depth) >> 11) + kbd16 + kbc16 + touch16;
        hp_k = q->hp_k[ch];
        lp_k = q->lp_k[ch];
        csn_svf_coef(&s->hp, csn_clamp(q->hp_base[ch] + cut16,0,123*16) + 192, hp_k);   /* knob: MIDI 8 .. 127 (13 Hz .. 12.5 kHz) */
        csn_svf_coef(&s->lp, csn_clamp(q->lp_base[ch] + cut16,0,123*16) + 192, lp_k);   /* knob: MIDI 16 .. 135 (20 Hz .. 19 kHz) */
        for (i = 0; i < CTL; i++) {
            int32_t x, lp, hp, amp = amp0 + (((amp1 - amp0) * (int32_t)i) >> 5);
            int32_t saw=csn_saw_cached(ph,inc,&s->blep_div);
            x=saw;
            if(wave!=csn_W_SAW){
                int32_t pulse=(saw-csn_saw_cached(ph+pw,inc,&s->blep_div))>>1;
                x=wave==csn_W_PULSE?pulse:(saw+pulse)>>1;
            }
            if (noise_lv)
                x += csn_mulq15(e->g_noise[t * CTL + i], noise_lv);
#ifndef csn_CH_KNEE
#define csn_CH_KNEE 24000
#endif
            /* Run the dual resonant filters at FS/2. Average input pairs
             * before decimation and linearly reconstruct the output; oscillators,
             * sine, VCA and all control timing remain at the native rate.
             * State survives blocks/retriggers to avoid reconstruction jumps. */
            if (!(i & 1u)) {
                int32_t filtered;
                csn_svf_step(&s->hp, (x + s->filter_input) / 2, &h1, &h2, &lp, &hp);
                csn_svf_step(&s->lp, csn_clamp(hp, -65535, 65535), &l1, &l2, &filtered, &hp);
                filtered = csn_mulq15(csn_soft_knee(filtered, csn_CH_KNEE), vcf_lv);
                lp = (s->filter_output + filtered) / 2;
                s->filter_output = filtered;
            } else lp = s->filter_output;
            s->filter_input = x;
            x = lp;
            if (sine_lv)
                x -= csn_mulq15(csn_sine_i(ph), sine_lv);   /* the rising saw's fundamental is -sin: in phase with it */
            ph += inc;
            mix[t * CTL + i] += csn_mulq15(x, amp);
        }
    }
done:
    s->ph = ph;
    s->h1 = h1; s->h2 = h2; s->l1 = l1; s->l2 = l2;
}

/* auto after touch, once a block: after the wait, the curve rises to its level (both times 0 .. ~4 s, squared
 * knobs); when the key goes it falls. The pressure in effect is the larger of the key's and the curve's */
static void csn_auto_at_block(cs1_part_t *e, csn_voice_t *w)
{
    uint32_t lvl = (*e->patch_ptr).aat_level, wait = e->prepared.aat_wait;   /* blocks... */
    int32_t target = (int32_t)lvl << 17, cur = w->aat, at;
    if (lvl && w->gate) {
        if (w->aat_t < 0xFFFFu) w->aat_t++;
        if (w->aat_t * 1u > wait) {                 /* (wait is in ticks: a block is 1u of them) */
            int32_t step = e->prepared.aat_rise_step;
            cur = cur + step > target ? target : cur + step;
        }
    } else {
        cur -= (int32_t)csn_div_exact(&e->prepared.aat_fall,(uint32_t)cur) + 1;
        if (cur < 0) cur = 0;
    }
    w->aat = cur;
    at = cur >> 9;                                     /* Q15 */
    w->at_eff = (uint16_t)(at > (int32_t)w->at * 258 ? at : (int32_t)w->at * 258);
}


static void cs1_kernel(cs1_part_t *e,csn_voice_t *w,int32_t pitch256,int32_t *mix){
        uint32_t trig = w->trig, any = 0, ch;
        int32_t target = pitch256 + (((w->drift >> 8) * (int32_t)(*e->patch_ptr).vintage) >> 7);
        if (trig != w->seen) {                         /* a new note: pitch, envelopes */
            w->seen = trig;
            w->pitch256 = (*e->patch_ptr).porta ? w->from256 : target;
            w->pb256 = -(((int32_t)w->vel * (*e->patch_ptr).pbend) >> 5);   /* INITIAL PITCHBEND: up to -2 semitones, velocity */
            w->aat_t = 0;                              /* the auto after touch curve starts over (keeping its level) */
            for (ch = 0; ch < CS1_NCH; ch++)
                csn_chan_trigger(&w->c[ch], &(*e->patch_ptr).ch[ch]);
        }
        if ((*e->patch_ptr).porta) {                             /* portamento: 2 s an octave at the longest, per block */
            int32_t step = (12 * 256 * (int32_t)CTL) / (int32_t)(2u * FS * (*e->patch_ptr).porta * (*e->patch_ptr).porta / 16129u + 1u);
            int32_t d = target - w->pitch256;
            if (d > step) w->pitch256 += step;
            else if (d < -step) w->pitch256 -= step;
            else w->pitch256 = target;
            if ((*e->patch_ptr).gliss && w->pitch256 != target)  /* glissando: the glide in semitone steps */
                w->pitch256 = ((w->pitch256 + 128) & ~255) ;
        } else
            w->pitch256 = target;
        w->pb256 -= w->pb256 >> 7;                     /* the initial bend slides up to pitch: a block a block, ~300 ms */
        csn_auto_at_block(e,w);
        if ((*e->patch_ptr).vintage) {                           /* the drift: towards a point a few cents off, picked afresh now
                                                        * and then; VINTAGE 127 is +-12 cents. In 1/65536 semitone */
            uint32_t r = csn_noise32(&w->drift_rng);
            if ((r & 2047u) < 2u)                       /* a new destination every ~0.75 s on average */
                w->drift_to = ((int32_t)((r >> 8) & 63u) - 32) * 256;
            w->drift += (w->drift_to - w->drift) >> 9;   /* reached in ~0.4 s */
        } else
            w->drift = w->drift_to = 0;
        for (ch = 0; ch < CS1_NCH; ch++) {
            csn_chan_render(e,w, ch, mix);
            any |= w->c[ch].vstage;
        }
        w->active = any != 0;

}

static void csn_ring_mod(cs1_part_t *e,int32_t *mix, uint32_t n)
{
    int32_t mod = (*e->patch_ptr).rm_mod * 258, dry = 32767 - mod;
    uint32_t t, i;
    if (e->rm_seen != e->rm_trig) { e->rm_seen = e->rm_trig; e->rm_stage = 1; }
    for (t = 0; t < n / CTL; t++) {
        uint32_t idx;
        uint32_t inc;
        if (e->rm_stage == 1) {
            e->rm_env += ((1 << 15) * (int32_t)csn_ATT_Q16[(*e->patch_ptr).rm_a]) >> 16;
            if (e->rm_env >= 32767) { e->rm_env = 32767; e->rm_stage = 2; }
        } else if (e->rm_stage == 2) {
            e->rm_env -= (e->rm_env * (int32_t)csn_DEC_Q16[(*e->patch_ptr).rm_d]) >> 16;
            if (e->rm_env < 64) { e->rm_env = 0; e->rm_stage = 0; }
        }
        idx = (*e->patch_ptr).rm_spd + ((uint32_t)e->rm_env * (*e->patch_ptr).rm_depth >> 15);
        inc = csn_RM_INC[idx > 127u ? 127u : idx];
        if (!mod) { e->rm_ph += inc * CTL; continue; }
        for (i = t * CTL; i < (t + 1u) * CTL; i++) {
            int32_t x = mix[i];
            mix[i] = csn_mulq15(x, dry) + csn_mulq15(csn_mulq15(x, csn_sine_i(e->rm_ph)), mod);
            e->rm_ph += inc;
        }
    }
}

/* ---- the csn_chorus / tremolo: the CS-80's "phasing-type tremolo" between LEFT and RIGHT, as a short delay
 * swept by a sine (opposite ways for the two sides) with a touch of amplitude modulation; TREMOLO is the same
 * faster and deeper in level. CS-1's liberty: the real one is mono-ish; this one is stereo */
#define CS1_CHO_LEN 1024u                    /* 46 ms of delay line */


static void csn_chorus(cs1_part_t *e,const int32_t *mix, int32_t *out, uint32_t n)
{
    uint32_t mode = (*e->patch_ptr).cho_mode, i;
    uint32_t spd = (*e->patch_ptr).cho_spd * 100u / 127u;          /* 0.1 .. ~11 Hz of the LFO table */
    int32_t depth = (*e->patch_ptr).cho_depth * 258, base, swing, trem;
    if (!mode) {
        for (i = 0; i < n; i++) { out[2u * i] += mix[i]; out[2u * i + 1u] += mix[i]; }
        return;
    }
    base = 14 << 8;                                      /* 14 ms, in 1/256 frames of 44.1 kHz... as frames << 8 */
    base = (14 * 441 / 10) << 8;
    swing = mode == csn_CHO_CHORUS ? csn_mulq15(depth, (8 * 441 / 10) << 8) : csn_mulq15(depth >> 2, (8 * 441 / 10) << 8);
    trem = mode == csn_CHO_TREMOLO ? depth >> 1 : depth >> 4;
    for (i = 0; i < n; i++) {
        int32_t l, r, lf, d, dl, dr;
        uint32_t ip, fr;
        e->cho_line[e->cho_w % CS1_CHO_LEN] = (int16_t)csn_clamp(mix[i], -32767, 32767);
        if ((i & 7u) == 0u) e->cho_ph += csn_LFO_INC[spd] * 8u / CTL;  /* the LFO, advanced every 8 frames */
        lf = csn_sine_i(e->cho_ph);
        d = base + csn_mulq15(swing, lf);                    /* the left side's delay, frames << 8 */
        ip = (uint32_t)(d >> 8); fr = (uint32_t)d & 255u;
        dl = e->cho_line[(e->cho_w - ip) % CS1_CHO_LEN]; dl += ((e->cho_line[(e->cho_w - ip - 1u) % CS1_CHO_LEN] - dl) * (int32_t)fr) >> 8;
        d = base - csn_mulq15(swing, lf);                    /* the right side's, the other way */
        ip = (uint32_t)(d >> 8); fr = (uint32_t)d & 255u;
        dr = e->cho_line[(e->cho_w - ip) % CS1_CHO_LEN]; dr += ((e->cho_line[(e->cho_w - ip - 1u) % CS1_CHO_LEN] - dr) * (int32_t)fr) >> 8;
        e->cho_w++;
        l = (mix[i] + dl) >> 1;
        r = (mix[i] + dr) >> 1;
        l = csn_mulq15(l, 32767 - csn_mulq15(trem, (32767 - lf) >> 1));
        r = csn_mulq15(r, 32767 - csn_mulq15(trem, (32767 + lf) >> 1));
        out[2u * i] += l;
        out[2u * i + 1u] += r;
    }
}


/* Native output color, DC removal, ring modulation and stereo ensemble. */
static void csn_output(cs1_part_t *e,int32_t *mix,int32_t *stereo,uint32_t n){
 csn_svf_coef(&e->tone_c,135*16-100*6,4551);
 for(uint32_t i=0;i<n;i++){
  int32_t lp,hp;csn_svf_step(&e->tone_c,mix[i],&e->tone_s1,&e->tone_s2,&lp,&hp);
  int32_t y=(lp-e->dc_x)*64+e->dc_y-csn_leak10(e->dc_y);e->dc_x=lp;e->dc_y=y;
  mix[i]=csn_mulq15(csn_soft_knee(y>>6,14000),e->patch_ptr->volume*258);
 }
 csn_ring_mod(e,mix,n);csn_chorus(e,mix,stereo,n);
}
