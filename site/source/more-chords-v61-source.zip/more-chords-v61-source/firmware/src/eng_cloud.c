#include "new_engine_tables.h"
#include "orbit_bridge.h"
#include "cloud_wavetables.h"
/* SPDX-License-Identifier: GPL-3.0-only */
/* Original engine output level restored: V32 +2dB boost removed. */
/* CLOUD: original oscillator-source grains, not sample playback or recorded audio.
 * WAVE morphs sine -> triangle -> a three-harmonic sine spectrum. SIZE is 10..390 ms;
 * DENS is 1..98 starts/s/voice; SPRD jitters timing and starting phase; DTUN spreads
 * pitch by up to two semitones. CHRP uses 1/25 of the original sweep range.
 * STCK adds fifths and octaves probabilistically. TONE follows the shared FLT modulation.
 * Remix: two grains per voice, six chord voices (4 CPU0 + 2 CPU1).
 * Grain slots and RNG are voice-private; no mutable pool crosses cores. All divides and pitch ratios are
 * computed at grain/block boundaries; the sample loop only advances fixed-point ramps.
 */
static uint32_t cloud_pow2_q16(int32_t d16)
{
    uint32_t u = (uint32_t)(d16 + 192 * 16), oct = u / 192u;     /* no loop for negative d16 */
    uint32_t r = pitch_inc(1600 + u % 192u) / (pitch_inc(1600) >> 16);   /* 2^(d/192) via the pitch table */
    return oct >= 16u ? r << (oct - 16u) : r >> (16u - oct);
}
#define CLOUD_VOICE_FS 20193 /* retain V49 -1.5 dB output balance */
#define CLOUD_NG 2u
#define CLOUD_INC_MAX 0x18000000u  /* bound all three harmonics below Nyquist */
typedef struct {
    uint32_t ph, inc, wph, winc, left;
    int32_t chirp, gain;
    uint8_t owner, wave, bank, table_band; /* bank uses pre-existing structure padding */
} cloud_grain_t;
typedef struct {
    cloud_grain_t g[CLOUD_NG];
    int32_t rng;
    orbit_bridge_t bridge;
} cloud_voice_t;
typedef struct {cloud_voice_t voice[NVOICE];} cloud_part_t;
static cloud_part_t *cloud_part(uint32_t part);
static cloud_voice_t *cloud_state(track_t *t,voice_t *v){return &cloud_part((uint32_t)(t-trk))->voice[(uint32_t)(v-t->v)];}
static const int16_t CLOUD_NORM[4]={32767,32767,23170,18918};
static inline uint32_t cloud_scale(uint32_t n,uint32_t f16){return (n>>16)*f16+(((n&65535u)*f16)>>16);}
static inline int32_t cloud_win(uint32_t ph){return (32767-osc_sine(ph+0x40000000u))/2;}

static const char *const CLOUD_BANK_NAMES[]={"Classic","Warm","Glass","Hollow","Digital","Silk","Reed","Prism","Pulse"};
#define CLOUD_BANK_MAX 8
static const char *const CLOUD_SCAN_NAMES[]={"Off","Up/Down","Forward","Backward"};
static const uint8_t CLOUD_EXTRA_IDS[]={P_CBANK,P_CSCAN,P_CRATE,P_CDEPTH};
static const param_desc_t CLOUD_EXTRA_DESC[]={
 {"Bank",F_ENUM,0,CLOUD_BANK_MAX,0,CLOUD_BANK_NAMES,0},
 {"Scan",F_ENUM,0,3,0,CLOUD_SCAN_NAMES,0},
 {"Rate",F_PCT,0,127,0,0,0},
 {"Depth",F_PCT,0,127,0,0,0}
};
static const param_desc_t *cloud_extra_desc(uint32_t id){
 for(uint32_t i=0;i<4;i++)if(CLOUD_EXTRA_IDS[i]==id)return &CLOUD_EXTRA_DESC[i];
 return 0;
}
/* 0.125..15.9 seconds per cycle; all divisions are at block/grain rate. */
static uint32_t cloud_scan_period(int32_t rate){
 uint32_t slow=127u-(uint32_t)clamp(rate,0,127);
 return FS/8u+(slow*slow*(FS/32u))/32u;
}
static int32_t cloud_table(uint32_t ph,const int16_t *a,const int16_t *b,uint32_t blend){
 uint32_t x=ph>>27,next=(x+1u)&31u,f=(ph>>12)&32767u;
 int32_t left=a[x]+mulq15(a[next]-a[x],f);
 if(!blend)return left;
 int32_t right=b[x]+mulq15(b[next]-b[x],f);
 return left+mulq15(right-left,blend);
}

static void cloud_note_on(track_t *t, voice_t *v)
{
    cloud_voice_t *p = cloud_state(t,v);
    orbit_bridge_note(&p->bridge);
    uint32_t i, owner = (uint32_t)(v - t->v) + 1u;
    if (!p->rng)
        p->rng = (int32_t)(0x2545F491u ^ ((uint32_t)(t - trk) * 0x9E3779B9u) ^ (owner * 0x85EBCA6Bu));
    v->s[1] = 0;
    if(!v->env)v->s[3]=0;
    if (!v->env) {
        v->s[2] = 0;
        for (i = 0; i < CLOUD_NG; i++)
            if (p->g[i].owner == owner)
                p->g[i].owner = 0;
    }
}

static void cloud_block(track_t *t)
{
 cloud_part_t *p=cloud_part((uint32_t)(t-trk));
 for(uint32_t vi=0;vi<NVOICE;vi++)if(!t->v[vi].active)
  for(uint32_t k=0;k<CLOUD_NG;k++)p->voice[vi].g[k].owner=0;
}
/* Morph: two independent six-voice banks, one per core. Standalone
 * Cloud retains its native 3-unit accounting and 4+2 scheduling. */
static uint32_t cloud_morph_part(const track_t *t){return trk[0].engine==ENGI_MORPH&&(t==&trk[0]||t==&trk[2]);}
static uint32_t cloud_units(const track_t *t){return cloud_morph_part(t)?2u:3u;}
static uint32_t cloud_cap(const track_t *t){
 if(cloud_morph_part(t))return 6u;
#if CHORALROOT_DUAL_CORE
 if(cr_dualcore_active()&&t==&trk[0])return 6u;
#endif
 return t==&trk[1]?1u:5u;
}

/* Saw/square share DRIFT's immutable band-limited tables. */
static int32_t cloud_saw(uint32_t ph,unsigned band){
 const int16_t *a=novel_saw[band];unsigned j=ph>>25;int32_t f=(ph>>10)&32767u;
 return a[j]+((a[(j+1u)&127u]-a[j])*f>>15);
}
/* Exponent in 1/25 of a native chirp unit, interpolated at grain creation. */
static uint32_t cloud_pow2_fine(int32_t x){
 int32_t q=x/25,r=x%25;if(r<0){r+=25;q--;}
 uint32_t a=cloud_pow2_q16(q),b=cloud_pow2_q16(q+1);
 return a+(b-a)*(uint32_t)r/25u;
}
static void cloud_render_raw(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
#ifdef CLOUD_RENDER_OBSERVER
    CLOUD_RENDER_OBSERVER(t);
#endif
    cloud_voice_t *p = cloud_state(t,v);
    uint32_t i, k, owner = (uint32_t)(v - t->v) + 1u, mine = 0;
    int32_t acc[CTL] = {0}, y = v->s[2];
    int32_t lp = 4000 + ((clamp((t->p[P_E7] * 256) + m->cutoff, 0, 127 << 8) * 28767) >> 15);
    if (n > CTL)
        n = CTL;
    int32_t scan=0;uint32_t mode=(uint32_t)clamp(t->p[P_CSCAN],0,3);
    if(mode && t->p[P_CDEPTH]>0){
        uint32_t ph=(uint32_t)v->s[3];
        scan=mode==1u?osc_tri(ph):mode==2u?(int32_t)(ph>>16)-32768:32767-(int32_t)(ph>>16);
        scan=mulq15(scan,clamp(t->p[P_CDEPTH],0,127));
        uint32_t step=0xffffffffu/cloud_scan_period(t->p[P_CRATE]);
        v->s[3]=(int32_t)(ph+step*n);
    }
    for (k = 0; k < CLOUD_NG; k++) {
        cloud_grain_t *g = &p->g[k];
        uint32_t count;
        int32_t w0, w1, wq, dq;
        if (g->owner != owner)
            continue;
        count = n < g->left ? n : g->left;
        w0 = mulq15(cloud_win(g->wph), g->gain);
        g->wph += g->winc * count;
        g->left -= count;
        w1 = g->left ? mulq15(cloud_win(g->wph), g->gain) : 0;
        wq = w0 * 1024;
        dq = count == CTL ? ((w1 - w0) * 1024) >> CTL_LOG2 :
             count ? (w1 - w0) * 1024 / (int32_t)count : 0;
        /* Choose the immutable grain waveform once, not once per sample.
         * Keep every fixed-point operation and rounding in its original order. */
        uint32_t ph=g->ph, inc=g->inc;
        int32_t chirp=g->chirp;
#define CLOUD_ACCUM(EXPR) do { \
        for (i=0;i<count;i++) { \
            int32_t sample=(EXPR); \
            acc[i]+=mulq15(sample,wq>>10); wq+=dq; \
            ph+=inc; inc=(uint32_t)((int32_t)inc+chirp); \
        } \
    } while (0)
        if(g->bank) {
            uint32_t frame_pos=(uint32_t)g->wave*3u;
            uint32_t frame=frame_pos/127u, blend=(frame_pos%127u)*258u;
            const int16_t *ta=CLOUD_TABLES[g->bank-1u][g->table_band][frame];
            const int16_t *tb=CLOUD_TABLES[g->bank-1u][g->table_band][frame<3u?frame+1u:3u];
            CLOUD_ACCUM(cloud_table(ph,ta,tb,blend));
        } else if(g->wave<=32u) {
            int32_t blend=g->wave*1024;
            CLOUD_ACCUM(osc_sine(ph)+mulq15(osc_tri(ph)-osc_sine(ph),blend));
        } else if(g->wave<=64u) {
            int32_t blend=(g->wave-32u)*1024;
            CLOUD_ACCUM(osc_tri(ph)+mulq15((osc_sine(ph)>>1)+(osc_sine(ph*2u)>>2)+(osc_sine(ph*3u)>>2)-osc_tri(ph),blend));
        } else {
            unsigned band=5;uint32_t top=inc;
            if(chirp>0)top+=(uint32_t)chirp*count;
            while(band && top>(0x60000000u>>band))band--;
            if(g->wave<=96u) {
                int32_t blend=(g->wave-64u)*1024;
                for(i=0;i<count;i++) {
                    int32_t a=(osc_sine(ph)>>1)+(osc_sine(ph*2u)>>2)+(osc_sine(ph*3u)>>2);
                    a+=mulq15(cloud_saw(ph,band)-a,blend);
                    acc[i]+=mulq15(a,wq>>10);wq+=dq;
                    ph+=inc;inc=(uint32_t)((int32_t)inc+chirp);
                }
            } else {
                int32_t blend=(g->wave-96u)*1057;
                for(i=0;i<count;i++) {
                    int32_t a=cloud_saw(ph,band),b=(a-cloud_saw(ph+0x80000000u,band))/2;
                    a+=mulq15(b-a,blend);
                    acc[i]+=mulq15(a,wq>>10);wq+=dq;
                    ph+=inc;inc=(uint32_t)((int32_t)inc+chirp);
                }
            }
        }
#undef CLOUD_ACCUM
        g->ph=ph;g->inc=inc;
        if (!g->left)
            g->owner = 0;
        else
            mine++;
    }
    v->s[1] -= (int32_t)n;
    if (v->s[1] <= 0) {
        uint32_t iv = (FS * cloud_pow2_q16(-t->p[P_E2] * 10)) >> 16;
        uint32_t r = noise32(&p->rng), share = CLOUD_NG;
        int32_t jitter = (((int32_t)(r & 65535u) - 32768) * t->p[P_E3]) / 254;
        v->s[1] += (int32_t)iv + mulq15((int32_t)iv, jitter);
        if (v->s[1] < 0)
            v->s[1] = 0;
        for (k = 0; k < CLOUD_NG && mine < share; k++) {
            cloud_grain_t *g = &p->g[k];
            uint32_t len, overlap, end;
            uint64_t start64, end64;
            int32_t detune, stack = 0, sweep = t->p[P_E5] * 3;
            if (g->owner)
                continue;
            len = (441u * cloud_pow2_q16(t->p[P_E1] * 8)) >> 16;
            detune = (((int32_t)((r >> 16) & 65535u) - 32768) * t->p[P_E4] * 32) /
                     (127 * 32768);
            if ((r & 127u) < (uint32_t)t->p[P_E6])
                stack = (r & 128u) ? 192 : 112;
            start64 = ((uint64_t)m->inc * cloud_pow2_fine((detune + stack)*25 - sweep)) >> 16;
            end64 = ((uint64_t)m->inc * cloud_pow2_fine((detune + stack)*25 + sweep)) >> 16;
            g->inc = start64 > CLOUD_INC_MAX ? CLOUD_INC_MAX : (uint32_t)start64;
            end = end64 > CLOUD_INC_MAX ? CLOUD_INC_MAX : (uint32_t)end64;
            g->chirp = ((int32_t)end - (int32_t)g->inc) / (int32_t)len;
            g->ph = cloud_scale(r, (uint32_t)t->p[P_E3] * 516u);
            g->wph = 0;
            g->winc = 0xFFFFFFFFu / len;
            g->left = len;
            overlap = len / iv + 1u;
            if (overlap > share)
                overlap = share;
            g->gain = CLOUD_NORM[overlap];
            g->wave = (uint8_t)clamp(t->p[P_E0] + scan + ((m->shape - (64 << 8)) >> 8), 0, 127);
            g->bank = (uint8_t)clamp(t->p[P_CBANK],0,CLOUD_BANK_MAX);
            g->table_band=(uint8_t)((g->inc>end?g->inc:end)>0x15555555u);
            g->owner = (uint8_t)owner;
            break;
        }
    }
    for (i = 0; i < n; i++) {
        y += mulq15(clamp(acc[i] - y, -65535, 65535), lp);
        out[i] += mulq15(mulq15(soft_knee(y, 32767), amp_at(m, i)), CLOUD_VOICE_FS) * 2;
    }
    v->s[2] = y;
}

static void cloud_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m)
{
    if(!n)return;
    if(n>CTL)n=CTL;
    int32_t first=out[0],last=out[n-1u];
    cloud_render_raw(t,v,out,n,m);
    orbit_bridge_apply(&cloud_state(t,v)->bridge,out,n,first,last);
}

static const preset_t CLOUD_PRESETS[] = {
    /* WAVE SIZE DENS SPRD DTUN CHRP STCK TONE; original oscillator-only sounds. */
    {"CIRRUS",      {0, 100, 100, 55, 18, 0, 0, 100}, {45, 90, 120, 70}, 0, 0, FX(0, 20, 20, 50)},
    {"SILVER MIST", {42, 110, 110, 90, 40, 4, 30, 105}, {65, 90, 120, 80}, 0, 0, FX(0, 30, 25, 60)},
    {"GLASS RAIN",  {110, 24, 95, 100, 65, -22, 75, 120}, {0, 70, 100, 45}, 0, 0, FX(0, 15, 30, 45)},
    {"EMBER",       {70, 90, 115, 45, 12, 0, 0, 40}, {25, 90, 127, 60}, 0, 0, FX(0, 10, 10, 35)},
    {"SKY FIFTHS",  {20, 100, 108, 70, 15, 0, 110, 110}, {40, 90, 120, 65}, 0, 0, FX(0, 15, 25, 50)},
    {"COMET TAIL",  {100, 75, 100, 60, 35, 40, 40, 115}, {5, 90, 110, 65}, 0, 0, FX(0, 10, 35, 55)},
    {"DUST PULSE",  {64, 8, 55, 25, 5, -8, 0, 100}, {0, 60, 127, 30}, 0, 0, FX(0, 0, 15, 20)},
    {"LOW STRATUS", {35, 120, 115, 100, 22, -3, 10, 65}, {55, 100, 127, 80}, 0, 0, FX(0, 20, 15, 45)},
};
static const engine_t ENG_CLOUD = {
    .name = "CLOUD", .page_title = {"GRAINS", "SPECTRUM"},
    .edit = {
        {"WAVE", F_PCT, 0, 127, 0, 0, 0},
        {"SIZE", F_PCT, 0, 127, 100, 0, 0},
        {"DENS", F_PCT, 0, 127, 100, 0, 0},
        {"SPRD", F_PCT, 0, 127, 55, 0, 0},
        {"DTUN", F_PCT, 0, 127, 18, 0, 0},
        {"CHRP", F_BIPCT, -64, 63, 0, 0, 0},
        {"STCK", F_PCT, 0, 127, 0, 0, 0},
        {"TONE", F_PCT, 0, 127, 100, 0, 0},
    },
    .presets = CLOUD_PRESETS, .npresets = NELEM(CLOUD_PRESETS),
    .note_on = cloud_note_on, .render = cloud_render,
    .knob={P_E0,P_E1,P_E2,P_E7}, .keep=1u<<2, .poly = 6, .block = cloud_block, .cap = cloud_cap, .units = cloud_units,
};
