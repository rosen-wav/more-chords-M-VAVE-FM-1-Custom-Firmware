#include "orbit_bridge.h"
/* SPDX-License-Identifier: GPL-3.0-only
 * ORBIT adapter for the official OP-1 #246 oscillator translation.
 * Pitch/ADSR/velocity/FX are ORBIT's, not a complete original-patch audio port.
 */
/* Original output coefficient restored; lightweight normalized synthesis below. */
#include "op1_cluster_core.c"
#include "felucca_op1_cluster.h"

typedef struct {
    cls_voice state;
    cls_global global;
    int16_t pcm[128];
    uint16_t cursor;
    orbit_bridge_t bridge;
} cluster_note_t;
typedef struct {
    cluster_note_t note[NVOICE];

} cluster_part_t;

static cluster_part_t *cluster_part(uint32_t part);

static void cluster_preset_to(track_t *t, uint32_t pi)
{
    uint32_t k;
    for (k = 0; k < 8u; k++)
        t->p[P_E0 + k] = OP1_CLUSTER_KNOBS[pi][k];
}

static void cluster_note_on(track_t *t, voice_t *v)
{
    cluster_part_t *p = cluster_part((uint32_t)(t-trk));
    cluster_note_t *s = &p->note[v - t->v];
    orbit_bridge_note(&s->bridge);
    if (!s->global.seed) {
        s->global.seed = (1u ^ ((uint32_t)(t-trk)*0x9e3779b9u) ^ ((uint32_t)(v-t->v)*0x85ebca6bu)) | 1u;
        cls_global_init(&s->global);
    }
    cls_construct(&s->state);
    cls_note_init(&s->state, &s->global, &OP1_CLUSTER_TABLES, &t->p[P_E0]);
    s->cursor = 128;
}

/* Lightweight cluster: max7 oscillators, bounded phase feedback, normalized
 * 32-bit sum. No per-oscillator clipping or signed-wide math in sample loops.
 * Preserve signed16 stored patch values; legacy COUNT above7 renders as7. */
static void cluster_light_kernel(cluster_note_t *s,uint32_t inc,const int16_t *k)
{
    cls_voice *v=&s->state;cls_global *g=&s->global;
    uint32_t count=(uint32_t)clamp(k[0]>>11,1,7), phase[7],step[7];
    int32_t gain[7],previous[7],sumgain=0;
    /* Recover the native piecewise Wave response and evolving history at
     * kernel boundaries, with feedback capped below the original half-scale. */
    int32_t u=(k[1]*0x5000)>>15,hi,lo;
    if(u<0x1000){hi=-32768;lo=clamp(u*8,-32768,32767);}
    else if(u<0x3000){hi=clamp((u-0x2000)*8,-32768,32767);lo=32767;}
    else if(u<0x4000){hi=32767;lo=clamp(32767-clamp((u-0x3000)*8,-32768,32767),-32768,32767);}
    else {hi=clamp(32767-clamp((u-0x4000)*8,-32768,32767),-32768,32767);lo=0;}
    int32_t square=clamp((hi*hi)>>15,-32768,32767);
    hi=((((square*hi)>>15)*0x01a3)>>15); /* native cubic Wave history, block-rate only */
    int32_t history=cls_get16(v,0x54);
    history=clamp(history+hi,-8192,8192);
    cls_put16(v,0x54,(int16_t)history);
    int32_t feedback=clamp((lo+history)/2,-12288,12288);
    int32_t curve=(int32_t)((uint32_t)OP1_CLUSTER_TABLES.curve[(uint32_t)clamp(k[2]>>10,0,23)]>>16);
    int32_t strength=k[3]/2;
    if(v->bytes[0x6a])strength/=8;
    int32_t active_gain=16384/(int32_t)count;
    for(uint32_t j=0;j<7;j++){
        int32_t target=j<count?active_gain:0;
        gain[j]=cls_get16(v,0x5a+2*j);
        gain[j]+=(target-gain[j])/8;
        cls_put16(v,0x5a+2*j,(int16_t)gain[j]);sumgain+=gain[j];
        g->seed=cls_next(g->seed);
        int32_t drift=cls_get16(v,0x44+2*j);
        int32_t r=cls_s16(g->seed>>16);
        drift=clamp(((drift*curve)>>15)+((r*strength)>>15),-32768,32767);
        cls_put16(v,0x44+2*j,(int16_t)drift);
        int32_t lane=(int32_t)(j*2u)-(int32_t)count+1;
        int32_t spread=clamp(((int32_t)k[3]+drift)/16,-3072,3072);
        int32_t delta=(((int32_t)(inc>>16)*spread)*lane)>>4;
        phase[j]=cls_get32(v,4+8*j);step[j]=inc+(uint32_t)delta;
        previous[j]=cls_get16(v,8+8*j);
    }
    /* Gain sum never exceeds half scale (native steady-state headroom), including COUNT transitions. */
    int32_t norm=sumgain>16384?536870912/sumgain:32768;
    for(uint32_t j=0;j<7;j++)gain[j]=(gain[j]*norm)>>15;
    /* Seven lanes, one feedback/table evaluation per two output frames.
     * Linear reconstruction softens the upper spectrum; phase still advances
     * by exactly 128 full-rate increments per kernel. No new persistent state. */
    int32_t left=0;
    for(uint32_t j=0;j<7;j++)left+=(previous[j]*gain[j])>>15;
    for(uint32_t i=0;i<128;i+=2){
        int32_t right=0;
        for(uint32_t j=0;j<7;j++){
            uint32_t index=((phase[j]>>16)+(uint32_t)((previous[j]*feedback)>>15)+32768u)&65535u;
            int32_t wave=OP1_CLUSTER_TABLES.wave[index>>3];
            right+=(wave*gain[j])>>15;
            previous[j]=wave;phase[j]+=step[j]+step[j];
        }
        s->pcm[i]=(int16_t)left;
        s->pcm[i+1]=(int16_t)((left+right)>>1);
        left=right;
    }

    for(uint32_t j=0;j<7;j++){
        cls_put32(v,4+8*j,phase[j]);cls_put16(v,8+8*j,(int16_t)previous[j]);
        g->gain[j]=(int16_t)gain[j];g->control[j]=cls_get16(v,0x44+2*j);
    }
}

static void cluster_render_raw(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
#ifdef CLUSTER_RENDER_OBSERVER
    CLUSTER_RENDER_OBSERVER(t);
#endif
    cluster_part_t *p = cluster_part((uint32_t)(t-trk));
    cluster_note_t *s = &p->note[v - t->v];
    uint32_t i;
    if (!v->gate && !s->state.bytes[0x6a])
        cls_release(&s->state);
    /* Consume each contiguous kernel span without a boundary branch per sample. */
    i=0;
    while(i<n) {
        if(s->cursor==128u) {
            cluster_light_kernel(s,m->inc,&t->p[P_E0]);s->cursor=0;
        }
        uint32_t count=128u-s->cursor;
        if(count>n-i)count=n-i;
        const int16_t *pcm=s->pcm+s->cursor;
        for(uint32_t j=0;j<count;j++)
            out[i+j]+=mulq15(mulq15(pcm[j],amp_at(m,i+j)),VOICE_FS)*2;
        s->cursor+=(uint16_t)count;i+=count;
    }
}

/* The int8 factory format holds only the row index; values load from the signed16 table.
 * The common envelope is an explicit ORBIT default, not the original ADSR timing formula. */
#define CLUSTER_PRESET(i) {OP1_CLUSTER_NAMES[i], {(i)}, {0, 70, 127, 40}, 0, 0, FX(0, 0, 0, 0)}
static void cluster_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m)
{
    if(!n)return;
    if(n>CTL)n=CTL;
    int32_t first=out[0],last=out[n-1u];
    cluster_render_raw(t,v,out,n,m);
    orbit_bridge_apply(&cluster_part((uint32_t)(t-trk))->note[v-t->v].bridge,out,n,first,last);
}

static const preset_t CLUSTER_PRESETS[] = {
    CLUSTER_PRESET(0), CLUSTER_PRESET(1), CLUSTER_PRESET(2), CLUSTER_PRESET(3),
    CLUSTER_PRESET(4), CLUSTER_PRESET(5), CLUSTER_PRESET(6), CLUSTER_PRESET(7),
    CLUSTER_PRESET(8), CLUSTER_PRESET(9), CLUSTER_PRESET(10), CLUSTER_PRESET(11),
    CLUSTER_PRESET(12), CLUSTER_PRESET(13), CLUSTER_PRESET(14), CLUSTER_PRESET(15),
};
#undef CLUSTER_PRESET
static const engine_t ENG_CLUSTER = {
    .name = "CLUSTER",
    .page_title = {"CLUSTER OSC", "CLUSTER"},
    .edit = {
        {"COUNT", F_INT, 2048, 18431, 4000, 0, 0},
        {"WAVE", F_INT, -32768, 32767, 4000, 0, 0},
        {"CURVE", F_INT, 0, 24575, 8000, 0, 0},
        {"SPREAD", F_INT, -32768, 32767, 100, 0, 0},
        {"--", F_INT, 0, 0, 0, 0, 0}, {"--", F_INT, 0, 0, 0, 0, 0},
        {"--", F_INT, 0, 0, 0, 0, 0}, {"--", F_INT, 0, 0, 0, 0, 0},
    },
    .presets = CLUSTER_PRESETS,
    .npresets = NELEM(CLUSTER_PRESETS),
    .note_on = cluster_note_on,
    .render = cluster_render,
    .knob = {P_E0, P_E1, P_E2, P_E3},
    .poly = 6, .cap=cloud_cap, .units=cloud_units,
};
