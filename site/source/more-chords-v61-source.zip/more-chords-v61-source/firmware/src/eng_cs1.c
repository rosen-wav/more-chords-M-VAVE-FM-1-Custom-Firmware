/* SPDX-License-Identifier: GPL-3.0-only */
/* CS-1 native voice adaptation. Remix owns notes, worker, MIDI, storage and effect buses. */
#include <stddef.h>
#include "cs1_native.h"
#include "cs1_tones.h"
#include "cs1_factory.h"
static cs1_part_t *cs1_part(uint32_t part);
static csn_patch_t cs1_patch[NPART] __attribute__((section(".pool")));
static uint8_t cs1_ready[NPART],cs1_restore_pending[NPART];
_Static_assert(sizeof(csn_patch_t)==102u && sizeof(csn_chan_patch_t)==26u,"CS-1 native USER layout");
_Static_assert(offsetof(csn_patch_t,lfo_wave)==53 && offsetof(csn_patch_t,gliss)==62 && offsetof(csn_patch_t,cho_mode)==72,"CS-1 USER enum offsets");
static csn_patch_t *cs1_patch_of(const track_t *t){
 uint32_t tr=(uint32_t)(t-trk)%NPART;
 if(!cs1_ready[tr]){memset(&cs1_patch[tr],0,sizeof cs1_patch[tr]);cs1_factory(&cs1_patch[tr],0);cs1_ready[tr]=1;}
 return &cs1_patch[tr];
}
static void cs1_track_loaded(const track_t *ct){
 track_t *t=(track_t*)ct;if(t->eng_req!=ENGI_CS1)return;
 uint32_t tr=(uint32_t)(t-trk)%NPART;
 if(cs1_restore_pending[tr])cs1_restore_pending[tr]=0;
 else cs1_factory(cs1_patch_of(t),clamp(t->preset,0,CS1_NSOUND-1));
 t->p[P_VOICE]=tr==1u?V_MONO:V_POLY;
}
static uint32_t cs1_units(const track_t *t){(void)t;return 3u;}
static uint32_t cs1_cap(const track_t *t){
#if CHORALROOT_DUAL_CORE
 if(cr_dualcore_active() && t==&trk[0])return 6;
#endif
 return t==&trk[1]?1u:5u;
}
static void cs1_block(track_t *t){
 cs1_part_t *e=cs1_part((uint32_t)(t-trk));
 if(!e->ready){memset(e,0,sizeof *e);e->noise_st=0x12345678u^((uint32_t)(t-trk)*0x9e3779b9u);e->last256=60*256;e->ready=1;}
 e->patch_ptr=cs1_patch_of(t);
 csn_block_prepare(e);
}
static void cs1_note_on(track_t *t,voice_t *v){
 cs1_part_t *e=cs1_part((uint32_t)(t-trk));if(!e->ready)cs1_block(t);
 uint32_t idx=(uint32_t)(v-t->v);csn_voice_t *w=&e->voices[idx];
 if(!voice_was)memset(w,0,sizeof *w);
 w->note=v->note;w->vel=v->vel;w->gate=1;w->at=t->at;
 w->from256=e->last256;e->last256=(int32_t)v->note*256;
 if(!w->drift_rng)w->drift_rng=0x9e3779b9u*(idx+1u);
 w->trig++;w->active=1;e->rm_trig++;
}
static int cs1_done(track_t *t,voice_t *v){
 csn_voice_t *w=&cs1_part((uint32_t)(t-trk))->voices[(uint32_t)(v-t->v)];
 return !v->gate && w->seen==w->trig && !w->active;
}
static void cs1_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 if(n!=CTL)return; /* Remix always invokes native kernels in CTL quanta. */
 cs1_part_t *e=cs1_part((uint32_t)(t-trk));csn_voice_t *w=&e->voices[(uint32_t)(v-t->v)];
 w->gate=v->gate;w->note=v->note;w->at=t->at;int32_t tmp[CTL]={0};
 cs1_kernel(e,w,m->pitch16*16+(m->fine*277)/256,tmp);
 for(uint32_t i=0;i<n;i++)out[i]+=voice_amp(tmp[i]/4,m,i);
}
static int cs1_post(track_t *t,int32_t *out,int32_t *side,uint32_t n,uint32_t nr){
 (void)nr;cs1_part_t *e=cs1_part((uint32_t)(t-trk));const csn_patch_t *p=cs1_patch_of(t);
 int32_t stereo[CTL*2]={0};
 csn_output(e,out,stereo,n);
 /* +18 dB total after native output processing; preserve mid/side balance.
  * Additional +6 dB: round(2087228 * 10^(6/20)) = 4164567. Widen before summing. */
 for(uint32_t i=0;i<n;i++){out[i]=(int32_t)((((int64_t)stereo[2*i]+stereo[2*i+1])*4164567)/1048576);side[i]=(int32_t)((((int64_t)stereo[2*i]-stereo[2*i+1])*4164567)/1048576);}
 return p->cho_mode!=0;
}

static const char *const CS1_FEET[]={"16 ft","8 ft","5 1/3","4 ft","2 2/3","2 ft"};
static const char *const CS1_WAVES[]={"Saw","Pulse","Both"};
static const char *const CS1_LFO[]={"Sine","Triangle","Saw up","Saw down","Square"};
static const char *const CS1_ON[]={"Off","On"};
static const char *const CS1_CHO[]={"Off","Chorus","Tremolo"};
static const eng_page_t CS1_PAGES[]={
 {"I OSC",{{"Range",F_ENUM,0,5,0,CS1_FEET,0},{"Wave",F_ENUM,0,2,0,CS1_WAVES,0},{"Width",F_PCT,0,127,0,0,0},{"PWM",F_PCT,0,127,0,0,0}}},
 {"I COLOR",{{"PWM rate",F_INT,0,127,0,0,0},{"Noise",F_PCT,0,127,0,0,0},{"Sine",F_PCT,0,127,0,0,0},{"Level",F_PCT,0,127,0,0,0}}},
 {"II OSC",{{"Range",F_ENUM,0,5,0,CS1_FEET,0},{"Wave",F_ENUM,0,2,0,CS1_WAVES,0},{"Width",F_PCT,0,127,0,0,0},{"PWM",F_PCT,0,127,0,0,0}}},
 {"II COLOR",{{"PWM rate",F_INT,0,127,0,0,0},{"Noise",F_PCT,0,127,0,0,0},{"Sine",F_PCT,0,127,0,0,0},{"Level",F_PCT,0,127,0,0,0}}},
 {"I FILTER",{{"HP cutoff",F_INT,0,127,0,0,0},{"HP res",F_INT,0,127,0,0,0},{"LP cutoff",F_INT,0,127,0,0,0},{"LP res",F_INT,0,127,0,0,0}}},
 {"II FILTER",{{"HP cutoff",F_INT,0,127,0,0,0},{"HP res",F_INT,0,127,0,0,0},{"LP cutoff",F_INT,0,127,0,0,0},{"LP res",F_INT,0,127,0,0,0}}},
 {"I VCF ENV",{{"Initial",F_INT,0,127,0,0,0},{"Attack level",F_INT,0,127,0,0,0},{"Attack",F_INT,0,127,0,0,0},{"Decay",F_INT,0,127,0,0,0}}},
 {"II VCF ENV",{{"Initial",F_INT,0,127,0,0,0},{"Attack level",F_INT,0,127,0,0,0},{"Attack",F_INT,0,127,0,0,0},{"Decay",F_INT,0,127,0,0,0}}},
 {"VCF TAIL",{{"I release",F_INT,0,127,0,0,0},{"II release",F_INT,0,127,0,0,0},{"I VCF level",F_INT,0,127,0,0,0},{"II VCF level",F_INT,0,127,0,0,0}}},
 {"I VCA",{{"Attack",F_INT,0,127,0,0,0},{"Decay",F_INT,0,127,0,0,0},{"Sustain",F_INT,0,127,0,0,0},{"Release",F_INT,0,127,0,0,0}}},
 {"II VCA",{{"Attack",F_INT,0,127,0,0,0},{"Decay",F_INT,0,127,0,0,0},{"Sustain",F_INT,0,127,0,0,0},{"Release",F_INT,0,127,0,0,0}}},
 {"I TOUCH",{{"Vel bright",F_INT,0,127,0,0,0},{"Vel level",F_INT,0,127,0,0,0},{"AT bright",F_INT,0,127,0,0,0},{"AT level",F_INT,0,127,0,0,0}}},
 {"II TOUCH",{{"Vel bright",F_INT,0,127,0,0,0},{"Vel level",F_INT,0,127,0,0,0},{"AT bright",F_INT,0,127,0,0,0},{"AT level",F_INT,0,127,0,0,0}}},
 {"SUB OSC",{{"Speed",F_INT,0,127,0,0,0},{"Wave",F_ENUM,0,4,0,CS1_LFO,0},{"Pitch",F_INT,0,127,0,0,0},{"Filter",F_INT,0,127,0,0,0}}},
 {"TOUCH MOD",{{"Tremolo",F_INT,0,127,0,0,0},{"AT speed",F_INT,0,127,0,0,0},{"AT pitch",F_INT,0,127,0,0,0},{"AT filter",F_INT,0,127,0,0,0}}},
 {"RING MOD",{{"Mix",F_INT,0,127,0,0,0},{"Rate",F_INT,0,127,0,0,0},{"Depth",F_INT,0,127,0,0,0},{"Attack",F_INT,0,127,0,0,0}}},
 {"PERFORM",{{"I / II",F_INT,0,127,0,0,0},{"II detune",F_INT,0,127,0,0,0},{"Glide",F_INT,0,127,0,0,0},{"Glissando",F_ENUM,0,1,0,CS1_ON,0}}},
 {"AUTO TOUCH",{{"Delay",F_INT,0,127,0,0,0},{"Rise",F_INT,0,127,0,0,0},{"Level",F_INT,0,127,0,0,0},{"Fall",F_INT,0,127,0,0,0}}},
 {"CHORUS",{{"Mode",F_ENUM,0,2,0,CS1_CHO,0},{"Speed",F_INT,0,127,0,0,0},{"Depth",F_INT,0,127,0,0,0},{"Ring decay",F_INT,0,127,0,0,0}}},
 {"TONE",{{"Brilliance",F_INT,0,127,0,0,0},{"Resonance",F_INT,0,127,0,0,0},{"Level",F_INT,0,127,0,0,0},{"Initial bend",F_INT,0,127,0,0,0}}},
 {"KEY CONTROL",{{"Low bright",F_INT,0,127,0,0,0},{"High bright",F_INT,0,127,0,0,0},{"Low level",F_INT,0,127,0,0,0},{"High level",F_INT,0,127,0,0,0}}},
 {"VINTAGE",{{"Drift",F_INT,0,127,0,0,0},{"II detune",F_INT,0,127,0,0,0},{"Level",F_INT,0,127,0,0,0},{"I / II",F_INT,0,127,0,0,0}}},
};
static const uint8_t CS1_IDS[][4]={
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,feet)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,wave)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pw)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pwm))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pwm_spd)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,noise)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,sine)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,level))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,feet)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,wave)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pw)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pwm))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,pwm_spd)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,noise)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,sine)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,level))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,hp_cut)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,hp_res)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,lp_cut)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,lp_res))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,hp_cut)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,hp_res)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,lp_cut)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,lp_res))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_il)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_al)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_a)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_d))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_il)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_al)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_a)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_d))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_r)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,f_r)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,vcf_lv)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,vcf_lv))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_a)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_d)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_s)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_r))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_a)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_d)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_s)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,v_r))},
 {(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,it_brill)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,it_level)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,at_brill)),(offsetof(csn_patch_t,ch)+0u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,at_level))},
 {(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,it_brill)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,it_level)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,at_brill)),(offsetof(csn_patch_t,ch)+1u*sizeof(csn_chan_patch_t)+offsetof(csn_chan_patch_t,at_level))},
 {offsetof(csn_patch_t,lfo_spd),offsetof(csn_patch_t,lfo_wave),offsetof(csn_patch_t,lfo_vco),offsetof(csn_patch_t,lfo_vcf)},
 {offsetof(csn_patch_t,lfo_vca),offsetof(csn_patch_t,at_spd),offsetof(csn_patch_t,at_vco),offsetof(csn_patch_t,at_vcf)},
 {offsetof(csn_patch_t,rm_mod),offsetof(csn_patch_t,rm_spd),offsetof(csn_patch_t,rm_depth),offsetof(csn_patch_t,rm_a)},
 {offsetof(csn_patch_t,mix),offsetof(csn_patch_t,detune),offsetof(csn_patch_t,porta),offsetof(csn_patch_t,gliss)},
 {offsetof(csn_patch_t,aat_delay),offsetof(csn_patch_t,aat_rise),offsetof(csn_patch_t,aat_level),offsetof(csn_patch_t,aat_fall)},
 {offsetof(csn_patch_t,cho_mode),offsetof(csn_patch_t,cho_spd),offsetof(csn_patch_t,cho_depth),offsetof(csn_patch_t,rm_d)},
 {offsetof(csn_patch_t,brill),offsetof(csn_patch_t,reso),offsetof(csn_patch_t,volume),offsetof(csn_patch_t,pbend)},
 {offsetof(csn_patch_t,kb_bl),offsetof(csn_patch_t,kb_bh),offsetof(csn_patch_t,kb_ll),offsetof(csn_patch_t,kb_lh)},
 {offsetof(csn_patch_t,vintage),offsetof(csn_patch_t,detune),offsetof(csn_patch_t,volume),offsetof(csn_patch_t,mix)},
};
static int32_t cs1_get(const track_t *t,uint32_t pg,uint32_t col){return pg<NELEM(CS1_PAGES)&&col<4?((uint8_t*)cs1_patch_of(t))[CS1_IDS[pg][col]]:0;}
static void cs1_set(track_t *t,uint32_t pg,uint32_t col,int32_t value){if(pg<NELEM(CS1_PAGES)&&col<4)((uint8_t*)cs1_patch_of(t))[CS1_IDS[pg][col]]=(uint8_t)clamp(value,0,CS1_PAGES[pg].col[col].max);}
static int cs1_blob_valid(const uint8_t *b){
 if(!b)return 0;for(uint32_t i=0;i<102;i++)if(b[i]>127)return 0;
 for(uint32_t pg=0;pg<NELEM(CS1_PAGES);pg++)for(uint32_t c=0;c<4;c++)if(b[CS1_IDS[pg][c]]>CS1_PAGES[pg].col[c].max)return 0;
 return 1;
}
static int cs1_blob_apply(track_t *t,const uint8_t *b){if(!cs1_blob_valid(b))return 0;memcpy(cs1_patch_of(t),b,102);return 1;}
static void cs1_blob_get(const track_t *t,uint8_t *b){memcpy(b,cs1_patch_of(t),102);}
static void cs1_blob_set(track_t *t,const uint8_t *b){if(!cs1_blob_apply(t,b))cs1_factory(cs1_patch_of(t),0);}
static void cs1_blob_preset(track_t *t,uint32_t preset){cs1_factory(cs1_patch_of(t),preset);}
static const eng_screen_t CS1_SCREENS[]={
 {.sec=0,.pg={0,2},.cell={{ENG_C_TEXT,ENG_C_TEXT,ENG_C_BAR,ENG_C_BAR},{ENG_C_TEXT,ENG_C_TEXT,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_NONE,.title="CS-1 DUAL OSC",.label={{"Range I","Wave I","Width","PWM"},{"Range II","Wave II","Width","PWM"}}},
 {.sec=0,.pg={1,3},.cell={{ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR},{ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_NONE,.title="CS-1 COLOR",.label={{"Rate I","Noise I","Sine I","Level I"},{"Rate II","Noise II","Sine II","Level II"}}},
 {.sec=1,.pg={4,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_FILTER,.title="CS-1 I FILTER"},
 {.sec=1,.pg={5,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_FILTER,.title="CS-1 II FILTER"},
 {.sec=1,.pg={6,0xff},.cell={{ENG_C_KNOB,ENG_C_BAR,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 I VCF ENV"},
 {.sec=1,.pg={7,0xff},.cell={{ENG_C_KNOB,ENG_C_BAR,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 II VCF ENV"},
 {.sec=1,.pg={8,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_NONE,.title="CS-1 VCF TAIL"},
 {.sec=2,.pg={9,10},.cell={{ENG_C_BAR,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR},{ENG_C_BAR,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_ADE2,.title="CS-1 DUAL VCA"},
 {.sec=2,.pg={11,12},.cell={{ENG_C_BAR,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR},{ENG_C_BAR,ENG_C_BAR,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_NONE,.title="CS-1 TOUCH",.label={{"Vel tone I","Vel amp I","AT tone I","AT amp I"},{"Vel tone II","Vel amp II","AT tone II","AT amp II"}}},
 {.sec=3,.pg={13,0xff},.cell={{ENG_C_KNOB,ENG_C_TEXT,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 SUB OSC"},
 {.sec=3,.pg={14,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 TOUCH MOD"},
 {.sec=3,.pg={15,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 RING MOD"},
 {.sec=4,.pg={16,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB,ENG_C_TEXT}},.band=ENG_B_NONE,.title="CS-1 PERFORM"},
 {.sec=4,.pg={17,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 AUTO TOUCH"},
 {.sec=4,.pg={18,0xff},.cell={{ENG_C_TEXT,ENG_C_KNOB,ENG_C_KNOB,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 CHORUS"},
 {.sec=4,.pg={19,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 TONE"},
 {.sec=4,.pg={20,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}},.band=ENG_B_NONE,.title="CS-1 KEY CONTROL"},
 {.sec=4,.pg={21,0xff},.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_KNOB}},.band=ENG_B_NONE,.title="CS-1 VINTAGE"},
};
static const eng_deep_t CS1_DEEP={.npages=NELEM(CS1_PAGES),.pages=CS1_PAGES,.section={0,4,9,13,16,0xff,0xff,0xff},.get=cs1_get,.set=cs1_set,.blob_size=102,.blob_get=cs1_blob_get,.blob_set=cs1_blob_set,.blob_preset=cs1_blob_preset,.screens=CS1_SCREENS,.nscreens=NELEM(CS1_SCREENS)};
#include "cs1_preset_list.h"
static const engine_t ENG_CS1={.name="CS-1",.page_title={"DUAL OSC","HP / LP"},.edit={{"-",F_INT,0,0,0,0,0}},.presets=CS1_PRESETS,.npresets=NELEM(CS1_PRESETS),.poly=6,.ownenv=1,.note_on=cs1_note_on,.render=cs1_render,.done=cs1_done,.block=cs1_block,.post2=cs1_post,.cap=cs1_cap,.units=cs1_units,.deep=&CS1_DEEP};
