#include "orbit_bridge.h"
/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ORBIT contributors
 * Independently written synthesis, inspired by publicly documented synthesis
 * families. No OP-1 code, patches, samples or parameter mappings are used.
 * The host supplies sine lookup, amplitude ramps and the voice/FX framework.
 * All state fits existing voice_t; no allocation or additional RAM buffers.
 */
/* Original engine output level restored: V32 +2dB boost removed. */
typedef struct { orbit_bridge_t voice[NVOICE]; } swarm_part_t;
static swarm_part_t *swarm_part(uint32_t part);
static void orbit_osc_note_on(track_t *t, voice_t *v)
{
    uint32_t k;
    orbit_bridge_note(&swarm_part((uint32_t)(t-trk))->voice[v-t->v]);
    for (k = 0; k < 3; k++) v->ph[k] = k * 0x34567890u;
    for (k = 0; k < 8; k++) v->s[k] = 0;
}

/* A bounded one-pole tone control, Q15. No division in the sample loop. */
static int32_t orbit_tone(int32_t x, int32_t *z, int32_t a)
{
    *z += ((x - *z) * a) >> 15;
    return *z;
}
static int32_t orbit_tone_coef(const track_t *t, const vmod_t *m)
{
    int32_t c = clamp(t->p[P_E4] + (m->cutoff >> 8), 0, 127);
    return 128 + c * c * 2; /* 128..32386; stable even at the extremes */
}
static void orbit_emit(int32_t *out, uint32_t i, int32_t s, const vmod_t *m)
{
    out[i] += mulq15(mulq15(s, amp_at(m, i)), VOICE_FS) * 2;
}

/* SWARM: 1..6 independently detuned sine/harmonic oscillators. It is not a
 * renamed TRIO/ANALOG engine. Spread is a linear frequency offset, not cents.
 * Higher partials are omitted above Nyquist. Envelope can contract the spread.
 */
static void swarm_render_raw(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
#ifdef SWARM_RENDER_OBSERVER
    SWARM_RENDER_OBSERVER(t);
#endif
    uint32_t i, k, count = (uint32_t)clamp(t->p[P_E0],1,6), ph[6], inc[6];
    uint8_t partial[6];
    uint32_t allpartial = 1;
    static const int32_t norm[7]={0,32768,16384,10922,8192,6553,5461};
    int32_t spread = t->p[P_E1];
    int32_t harmonic = clamp(t->p[P_E2] * 128 + ((m->shape - (64 << 8)) >> 1), 0, 32767);
    int32_t a = orbit_tone_coef(t, m), z = v->s[6];
    spread = spread * (32767 - t->p[P_E3] * (32767 - m->envq15) / 127) / 32767;
    for (k = 0; k < count; k++) {
        int32_t offset = (int32_t)(2 * k) - (int32_t)count + 1;
        ph[k] = (uint32_t)v->s[k];
        inc[k] = m->inc + (uint32_t)((int32_t)(m->inc >> 16) * spread * offset);
        partial[k] = inc[k] < 0x40000000u;
        allpartial &= partial[k];
    }
    /* Normal pitched notes: decide Nyquist/partial path once per render, not per oscillator/sample. */
    if (allpartial && harmonic) {
        for (i = 0; i < n; i++) {
            int32_t sum = 0;
            for (k = 0; k < count; k++) {
                sum += mulq15(sine_i(ph[k]), 32767-harmonic) + mulq15(sine_i(ph[k]*2u), harmonic);
                ph[k] += inc[k];
            }
            orbit_emit(out, i, orbit_tone((sum * norm[count]) >> 15, &z, a), m);
        }
    } else {
        for (i = 0; i < n; i++) {
            int32_t sum = 0;
            for (k = 0; k < count; k++) {
                int32_t s = sine_i(ph[k]);
                if (partial[k]) {
                    s = mulq15(s, 32767 - harmonic) + (harmonic ? mulq15(sine_i(ph[k] * 2u), harmonic) : 0);
                }
                sum += s;
                ph[k] += inc[k];
            }
            orbit_emit(out, i, orbit_tone((sum * norm[count]) >> 15, &z, a), m);
        }
    }
    for (k = 0; k < count; k++) v->s[k] = (int32_t)ph[k];
    v->s[6] = z;
}

static void swarm_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m)
{
    if(!n)return;
    if(n>CTL)n=CTL;
    int32_t first=out[0],last=out[n-1u];
    swarm_render_raw(t,v,out,n,m);
    orbit_bridge_apply(&swarm_part((uint32_t)(t-trk))->voice[v-t->v],out,n,first,last);
}

static const preset_t SWARM_PRESETS[] = {
    {"ORBIT HAZE", {6, 32, 12, 30, 100, 0, 0, 0}, {35, 85, 110, 75}, 0, 0, FX(0, 20, 15, 35)},
    {"ORBIT GLASS", {3, 9, 75, 90, 127, 0, 0, 0}, {0, 75, 20, 65}, 0, 0, FX(0, 0, 30, 25)},
    {"ORBIT REED", {2, 6, 65, 10, 105, 0, 0, 0}, {6, 70, 95, 28}, 0, 1, FX(0, 8, 12, 10)},
    {"ORBIT CHOIR", {6, 50, 50, 20, 72, 0, 0, 0}, {55, 90, 110, 90}, 0, 0, FX(0, 25, 10, 40)},
};
/* Same standalone 4+2 and Morph 6+6 policies as CLOUD. */
static const engine_t ENG_SWARM = {
 .name="SWARM", .page_title={"SWARM OSC","SWARM TONE"},
 .edit={
  {"COUNT",F_INT,1,6,6,0,0},{"SPREAD",F_PCT,0,100,32,0,0},
  {"PARTIAL",F_PCT,0,127,12,0,0},{"ENV",F_PCT,0,127,30,0,0},
  {"TONE",F_PCT,0,127,100,0,0},{"--",F_INT,0,0,0,0,0},
  {"--",F_INT,0,0,0,0,0},{"--",F_INT,0,0,0,0,0}},
 .presets=SWARM_PRESETS,.npresets=NELEM(SWARM_PRESETS),
 .note_on=orbit_osc_note_on,.render=swarm_render,
 .poly=6,.cap=cloud_cap,.units=cloud_units,
 .knob={P_E0,P_E1,P_E2,P_E3}
};
