/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef CR_ORBIT_BRIDGE_H
#define CR_ORBIT_BRIDGE_H
/* Prophet-style sample-continuity correction: 128 samples = 2.90ms at 44.1kHz.
 * Voice-private state lives in the existing engine union, including Morph B/Bass.
 * No second oscillator bank, extra audio block or idle correction loop. */
typedef struct { int32_t last, offset; uint16_t left; uint8_t pending; } orbit_bridge_t;
static void orbit_bridge_note(orbit_bridge_t *b)
{
    if (voice_was) b->pending=1;
    else { b->last=b->offset=0; b->left=0; b->pending=0; }
}
static void orbit_bridge_apply(orbit_bridge_t *b,int32_t *out,uint32_t n,int32_t first_before,int32_t last_before)
{
    if (!n) return;
    int32_t last=out[n-1u]-last_before, correction=0;
    if (b->pending) {
        b->offset=b->last-(out[0]-first_before);
        b->left=128u; b->pending=0;
    }
    uint32_t count=n<b->left?n:b->left;
    for(uint32_t i=0;i<count;i++){
        correction=(b->offset*(int32_t)b->left)>>7;
        out[i]+=correction; b->left--;
    }
    b->last=last+(count==n?correction:0);
    if(!b->left)b->offset=0;
}
#endif
