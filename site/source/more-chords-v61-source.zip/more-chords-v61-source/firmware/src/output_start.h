/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
static int32_t output_start_gain(uint32_t *frames){
    uint32_t x=*frames;if(x>=9702u)return 32768;
    *frames=x+1u;return x<8820u?0:(int32_t)(x-8820u)*32768/882;
}
