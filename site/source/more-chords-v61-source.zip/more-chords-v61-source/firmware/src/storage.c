/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Persistent storage on the SPI NOR.
 *
 * Every object has an A/B sector pair. A save goes to the copy that is not
 * the current one: erase the sector, program the payload pages (from offset
 * 256), then the 32-byte header at offset 0 LAST. The header is the commit
 * record (magic, seq, length, payload CRC, header CRC); on load the valid
 * copy with the newest seq wins (including wrap), so a write torn at any point leaves the
 * previous copy in charge.
 *
 * Flash access goes through three hooks (also used by the host test):
 *   st_read(off, dst, n)   st_erase(off)   st_prog(off, src, n)
 */
#define ST_MAGIC 0x554C4546u                   /* "FELU" */
#define ST_SECTOR 4096u
#define ST_PAYLOAD_OFF 256u
#define ST_PAYLOAD_MAX (ST_SECTOR - ST_PAYLOAD_OFF)

/* flash map (FL_DATA 0x97000..0xDFFFF, FL_GLOB 0xFC000..): settings 0xFC000, projects 0x97000..0x9EFFF,
 * user sample slots 0xA0000..0xDBFFF (eng_sample.c; ChoralRoot, FELUCCA_SAMPLE 0: slots 1-2, 0xA0000..0xC7FFF, stay
 * reserved and unused, slot 3's 0xC8000..0xDBFFF holds the loops, cr_ui.c CRL_FL_BASE), user preset banks 0xDC000..0xDFFFF (upreset.c), the FM6
 * patch bank (fm6_bank.c): copy A 0x9F000, copy B 0xFE000 (the two free sectors).
 * ChoralRoot's project pairs: 0x97000 the VA patch store (va_store.c), 0x99000 / 0x9B000 the FM6 patch store
 * (fm6_ustore.c), 0x9D000 the CZ-1 tone store's slots 1..16 (cz_ustore.c, OBJ_PROJECT0 + 3). FELUCCA_CZ: on the user
 * sample slot 1's flash (unused since the all-synth change, FELUCCA_SAMPLE 0): 0xA0000 / 0xA1000 the CZ-1 tone store's
 * slots 17..32 (OBJ_CZSTORE1), 0xA2000..0xB1FFF the eight CZ-1 banks A..H (cz_bank.c, OBJ_CZBANK0 + k: an A/B pair
 * each). FELUCCA_QUAD: 0xB2000 / 0xB3000 the QUAD patch store (quad_store.c, OBJ_QUADSTORE: the user sample slot 2's
 * flash); 0xB4000..0xC7FFF holds loop slots 11..20; 0xE5000..0xF8FFF holds
 * slots 21..30 (after updater staging 0xE0000..0xE4FFF; before globals 0xFC000) */
enum { OBJ_SETTINGS, OBJ_PROJECT0, OBJ_UPRESET0 = OBJ_PROJECT0 + 4, OBJ_FM6BANK = OBJ_UPRESET0 + 2,
#if FELUCCA_CZ_SLOT && FELUCCA_QUAD
       OBJ_CZSTORE1, OBJ_CZBANK0, OBJ_QUADSTORE = OBJ_CZBANK0 + 8, OBJ_OLD_COUNT
#elif FELUCCA_CZ_SLOT
       OBJ_CZSTORE1, OBJ_CZBANK0, OBJ_OLD_COUNT = OBJ_CZBANK0 + 8
#else
       OBJ_OLD_COUNT
#endif
};
enum { OBJ_UPEXT0=OBJ_OLD_COUNT, OBJ_UPEXT1, OBJ_COUNT };
static uint8_t st_ext_ready,st_ext_page[2]={255,255};
static void st_ext_scan(void);


typedef struct {
    uint32_t magic;
    uint16_t type, slot;
    uint32_t seq, len, crc, rsv[2];
    uint32_t hcrc;
} st_hdr_t;
_Static_assert(sizeof(st_hdr_t) == 32u, "storage commit record layout");

static int st_read(uint32_t off, void *dst, uint32_t n);
#ifndef ST_BLOCKED
#define ST_BLOCKED() 0                         /* (core.h: SAFE MODE, the objects neither loaded nor saved) */
#endif
static int st_erase(uint32_t off);
static int st_prog(uint32_t off, const void *src, uint32_t n);

static uint32_t st_crc32(const void *p, uint32_t n)   /* zlib CRC-32, 4 bits per step */
{
    static const uint32_t T[16] = {
        0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
        0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
    const uint8_t *b = p;
    uint32_t c = 0xFFFFFFFFu;
    while (n--) {
        c ^= *b++;
        c = (c >> 4) ^ T[c & 15u];
        c = (c >> 4) ^ T[c & 15u];
    }
    return ~c;
}

static uint32_t st_sector(uint32_t obj, uint32_t copy)  /* flash offset of copy A (0) / B (1) */
{
    if(obj==OBJ_UPEXT0 || obj==OBJ_UPEXT1){
        if(!st_ext_ready)st_ext_scan();
        uint32_t bank=obj-OBJ_UPEXT0;
        return 0xF9000u+(copy?((bank+1u)%3u):(st_ext_page[bank]<3u?st_ext_page[bank]:bank))*ST_SECTOR;
    }
    if (obj == OBJ_SETTINGS)
        return 0xFC000u + copy * ST_SECTOR;
    if (obj == OBJ_FM6BANK)
        return copy ? 0xFE000u : 0x9F000u;
#if FELUCCA_CZ_SLOT && FELUCCA_QUAD
    if (obj == OBJ_QUADSTORE)
        return 0xB2000u + copy * ST_SECTOR;
#endif
#if FELUCCA_CZ_SLOT
    if (obj == OBJ_CZSTORE1)
        return 0xA0000u + copy * ST_SECTOR;
    if (obj >= OBJ_CZBANK0)
        return 0xA2000u + (obj - OBJ_CZBANK0) * 2u * ST_SECTOR + copy * ST_SECTOR;
#endif
    if (obj >= OBJ_UPRESET0)
        return 0xDC000u + (obj - OBJ_UPRESET0) * 2u * ST_SECTOR + copy * ST_SECTOR;
    return 0x97000u + (obj - OBJ_PROJECT0) * 2u * ST_SECTOR + copy * ST_SECTOR;
}

static uint8_t st_buf[ST_PAYLOAD_MAX] __attribute__((aligned(4)));

static int st_head(uint32_t obj, uint32_t copy, st_hdr_t *h)   /* commit record valid: 0 */
{
    if (obj >= OBJ_COUNT || copy > 1u)
        return -1;
    if (st_read(st_sector(obj, copy), h, sizeof *h))
        return -1;
    if (h->magic != ST_MAGIC || h->type != obj || h->slot != copy || h->len > ST_PAYLOAD_MAX ||
        h->hcrc != st_crc32(h, sizeof *h - 4u))
        return -1;
    return 0;
}

static int st_body(uint32_t obj, uint32_t copy, const st_hdr_t *h)   /* payload -> st_buf, CRC ok: 0 */
{
    if (st_read(st_sector(obj, copy) + ST_PAYLOAD_OFF, st_buf, h->len) || st_crc32(st_buf, h->len) != h->crc)
        return -1;
    return 0;
}

/* the current copy: the newest valid sequence (A on a tie), -1 when
 * neither is valid. Headers first, so only the winner's payload is read (it
 * is left in st_buf); *h gets its header. */
static int st_current(uint32_t obj, st_hdr_t *h)
{
    st_hdr_t a, b;
    int va = st_head(obj, 0, &a) == 0, vb = st_head(obj, 1, &b) == 0;
    if (vb && (!va || (b.seq != a.seq && b.seq - a.seq < 0x80000000u))) {
        if (st_body(obj, 1, &b) == 0) {
            *h = b;
            return 1;
        }
        vb = 0;
    }
    if (va && st_body(obj, 0, &a) == 0) {
        *h = a;
        return 0;
    }
    if (vb && st_body(obj, 1, &b) == 0) {
        *h = b;
        return 1;
    }
    return -1;
}

/* Two logical extension banks rotate through three previously unused sectors.
 * Write only the page that is not the newest committed page of either bank.
 * Commit header last; boot scans payload CRCs before choosing sequence numbers. */
static void st_ext_scan(void)
{
    uint32_t seq[2]={0,0};st_ext_page[0]=st_ext_page[1]=255;
    for(uint32_t page=0;page<3;page++){
        st_hdr_t h;uint32_t base=0xF9000u+page*ST_SECTOR;
        if(st_read(base,&h,sizeof h)||h.magic!=ST_MAGIC||h.type<OBJ_UPEXT0||h.type>OBJ_UPEXT1||h.slot||h.len>ST_PAYLOAD_MAX||h.hcrc!=st_crc32(&h,sizeof h-4))continue;
        if(st_read(base+ST_PAYLOAD_OFF,st_buf,h.len)||h.crc!=st_crc32(st_buf,h.len))continue;
        uint32_t b=h.type-OBJ_UPEXT0;
        if(st_ext_page[b]==255||(h.seq!=seq[b]&&h.seq-seq[b]<0x80000000u)){st_ext_page[b]=(uint8_t)page;seq[b]=h.seq;}
    }
    st_ext_ready=1;
}
static int st_ext_save(uint32_t obj,const void *src,uint32_t len)
{
    if(!st_ext_ready)st_ext_scan();
    uint32_t b=obj-OBJ_UPEXT0,page=0,off;st_hdr_t old,h;uint32_t seq=st_current(obj,&old)<0?0:old.seq;
    while(page<3&&(page==st_ext_page[0]||page==st_ext_page[1]))page++;
    if(page==3)return -1;
    uint32_t base=0xF9000u+page*ST_SECTOR;
    memcpy(st_buf,src,len);int rc=st_erase(base);if(rc)return rc;
    for(off=0;off<len;off+=256){uint32_t n=len-off>256?256:len-off;if((rc=st_prog(base+ST_PAYLOAD_OFF+off,st_buf+off,n)))return rc;}
    h.magic=ST_MAGIC;h.type=(uint16_t)obj;h.slot=0;h.seq=seq+1;h.len=len;h.crc=st_crc32(st_buf,len);h.rsv[0]=h.rsv[1]=0xffffffffu;h.hcrc=st_crc32(&h,sizeof h-4);
    if((rc=st_prog(base,&h,sizeof h)))return rc;
    uint8_t previous=st_ext_page[b];st_ext_page[b]=(uint8_t)page;
    st_hdr_t check;
    if(st_head(obj,0,&check)||memcmp(&check,&h,sizeof h)||st_body(obj,0,&check)){st_ext_page[b]=previous;return -7;}
    return 0;
}

/* load the whole object into dst; returns its length, or -1 if it does not fit */
static int st_load(uint32_t obj, void *dst, uint32_t max)
{
    uint32_t i;
    st_hdr_t h;
    if (ST_BLOCKED() || obj >= OBJ_COUNT || st_current(obj, &h) < 0 || h.len > max)
        return -1;
    for (i = 0; i < h.len; i++)
        ((uint8_t *)dst)[i] = st_buf[i];
    return (int)h.len;
}

static int st_save(uint32_t obj, const void *src, uint32_t len)
{
    uint32_t seq, base, off;
    int cur, rc;
    st_hdr_t h;
    if (ST_BLOCKED() || obj >= OBJ_COUNT || len > ST_PAYLOAD_MAX)
        return -1;
    if(obj==OBJ_UPEXT0 || obj==OBJ_UPEXT1)return st_ext_save(obj,src,len);
    cur = st_current(obj, &h);
    seq = cur < 0 ? 0u : h.seq;
    base = st_sector(obj, cur == 0 ? 1u : 0u);       /* write the other copy */
    for (off = 0; off < len; off++)
        st_buf[off] = ((const uint8_t *)src)[off];    /* the driver wants RAM sources */
    if ((rc = st_erase(base)) != 0)
        return rc;
    for (off = 0; off < len; off += 256u) {
        uint32_t n = len - off > 256u ? 256u : len - off;
        if ((rc = st_prog(base + ST_PAYLOAD_OFF + off, st_buf + off, n)) != 0)
            return rc;
    }
    h.magic = ST_MAGIC;
    h.type = (uint16_t)obj;
    h.slot = (uint16_t)(cur == 0 ? 1 : 0);
    h.seq = seq + 1u;
    h.len = len;
    h.crc = st_crc32(st_buf, len);
    h.rsv[0] = h.rsv[1] = 0xFFFFFFFFu;
    h.hcrc = st_crc32(&h, sizeof h - 4u);
    if ((rc = st_prog(base, &h, sizeof h)) != 0)       /* the commit record, last */
        return rc;
    {   /* read back: a write-protected or failing part must not report SAVED */
        st_hdr_t chk;
        uint32_t c = cur == 0 ? 1u : 0u;
        if (st_head(obj, c, &chk) || memcmp(&chk, &h, sizeof h) || st_body(obj, c, &chk))
            return -7;
    }
    return 0;
}
