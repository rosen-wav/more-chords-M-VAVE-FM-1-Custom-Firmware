#!/usr/bin/env python3
"""Install test-only QUAD v3 legacy-golden gate, fail closed on unexpected project."""
import hashlib
from pathlib import Path
import shutil
import sys
root = Path(__file__).resolve().parent
project = Path.cwd()
engine = project / 'firmware/src/eng_quad.c'
target = project / 'tests/cr_quad_test.c'
source = root / 'tests/cr_quad_test.c'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected_engine = '4b3dc4767fa974b75474f7a2b3bde509f89a3958f8c8a1415ec782ec6a6fca3d'
expected_test = 'ab6dab36b62afda96caa702a3159b2802533b542ca97fff64118704e2c50291b'
if not engine.is_file() or sha(engine) != expected_engine:
    sys.exit('STOP: eng_quad.c differs from the validated v3 source. No files modified.')
if not target.is_file():
    sys.exit('STOP: tests/cr_quad_test.c missing. No files modified.')
if sha(target) == sha(source):
    print('ALREADY INSTALLED: no files modified.')
    sys.exit(0)
if sha(target) != expected_test:
    sys.exit('STOP: existing test differs from the expected baseline. No files modified.')
backup = target.with_suffix('.c.before_v3_gate')
if backup.exists():
    sys.exit('STOP: backup already exists. No files modified.')
shutil.copy2(target, backup)
shutil.copy2(source, target)
assert sha(engine) == expected_engine
print('INSTALLED: tests/cr_quad_test.c only; backup:', backup)
print('Run: sh test_quad_safe.sh')
print('Strict mode: QUAD_REQUIRE_V3_GOLDENS=1 sh test_quad_safe.sh')
