> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](../README-V8.md).

# Stato integrazione (15 ottobre 2026)

Questa e' una base di lavoro **NON FLASHARE**.

## Implementato nei sorgenti firmware
- Interruttore Dynamic Velocity ON/OFF, persistente, nel menu impostazioni (dalla precedente revisione).
- Disattivando l'opzione, velocity di output del motore ChoralRoot fissata a 100 (dalla precedente revisione).
- Morph V3 storico/interpolazione; NON dual-patch.

## Importato come riferimento, NON collegato al firmware
- `integration/monk_reference/sense.c`: algoritmo di sensing della velocity dal firmware Monk 0.9.
- `integration/monk_reference/sense_test.c`: relativo test di riferimento.

## Da integrare per soddisfare la richiesta
- Adattamento della HAL del firmware Monk alla scansione FM1 di ChoralRoot, mapping tasti, ADC e calibrazione.
- Collegamento della velocity fisica a note-on, chord, arp, sequencer, MIDI e suoi valori registrati.
- Due stati patch indipendenti e due renderer per il Morph con mixing equal-power (senza alterare la schedulazione degli altri engine/core).
- Build host e target, test regressione e misure RAM/XIP/POOL e carico CPU.

Non e' una implementazione completa. I file Monk sono inclusi a scopo di porting e confronto. Rispettare i termini GPL applicabili.
