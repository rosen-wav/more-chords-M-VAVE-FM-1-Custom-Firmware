# Prophet integration — staging, NON INSTALLABILE

Questo archivio conserva il progetto ChoralRoot Favourites/no-logo come base e include, in `integration/melodee-prophet`, i sorgenti Prophet estratti da Melodee 0.13 per il porting.

**Il motore Prophet NON e ancora collegato alla compilazione, ai preset, al selettore o al pool audio.** Nessun firmware e stato compilato o testato.

## Blocchi da risolvere

1. Melodee usa `resources.c` con allocazione dinamica per gli stati delle parti; ChoralRoot usa `eng_state` statico. Non importare `eng_prophet_test.c` senza adattare `p5_part()` e le chiamate di preparazione/rilascio.
2. Preservare gli ID storici 6 TRIO, 7 WHEEL, 9 PHYS e i dati USER; sostituire i loro engine con `ENG_GONE`, rimuovendo il DSP solo dopo aver isolato le dipendenze di conversione e UI (`upreset.c`, `ui_graph.c`).
3. Conservare la tabella `ENGINE_ORDER` e adeguare `NENG_SHOWN`, `CRS_NENG` e la serializzazione di `pool_pos`, che usa gli indici visibili.
4. Assegnare un ID Prophet libero senza alterare gli ID 0–15 e aggiungere il formato patch nativo, i preset e le tabelle in flash.
5. Mantenere HOME lungo, Favourites e no-logo della base; testare BASS + CZ e BASS + Prophet separatamente.
6. Misurare XIP, RAM, pool e CPU, compilare ed emulare prima di generare `.fwsc`.

Questo e un pacchetto di lavoro verificabile, non una build completata.
