> **V8 update:** these are historical upstream/V7 notes. Current behavior, tests and limitations: [README-V8.md](../README-V8.md).

# Stato integrazione

Ora nei sorgenti: velocity analogica Monk con scanner ADC, Dynamic Velocity persistente, Morph a due patch reali con crossfade PCM equal-power e supporto al job CPU1 (aggiunto dopo Bass).

NON validato sull'FM1: tasti analogici, latenza ADC, headroom/CPU1, memoria XIP/RAM/POOL, crossfade stereo e test completi. Per dettagli vedere `INTEGRAZIONE-VELOCITY-MORPH-LEGGIMI.md` nella radice.
