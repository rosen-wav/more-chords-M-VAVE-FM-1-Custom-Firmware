/* SPDX-License-Identifier: GPL-3.0-only
 * Reference only: not wired to audio renderer. Input gain coeffs Q15.
 * A real dual patch requires separate voice/patch states and safe CPU1 scheduling.
 */
#ifndef CR_MORPH_EQUAL_POWER_REFERENCE_H
#define CR_MORPH_EQUAL_POWER_REFERENCE_H
#include <stdint.h>
/* Smooth approximation of sin/cos equal-power for x in [0, 32768].
 * The actual gain law should use an audited LUT or DSP trig implementation.
 * This linear reference is intentionally NOT used as an equal-power mix. */
static inline int32_t cr_morph_linear_ref(int32_t a, int32_t b, uint32_t pos_q15)
{
    if (pos_q15 > 32768u) pos_q15 = 32768u;
    return (int32_t)(((int64_t)a * (32768u - pos_q15) + (int64_t)b * pos_q15) / 32768);
}
#endif
