/* SPDX-License-Identifier: GPL-3.0-only
 * BASS: one held voice, two simple oscillators and a sine sub, pre-filter
 * drive and resonant TPT low-pass. Uses voice_t only: no private audio pool. */
static const char *const N_BASS_WAVE[] = {"SIN", "TRI", "SAW", "SQR"};
static const char *const N_BASS_VOICE[] = {"MONO", "MONO", "MONO", "MONO"};
static const char *const N_BASS_LFO[] = {"SIN", "TRI", "SAW", "SQR", "S&H"};
static const param_desc_t BASS_MONO_DESC = {"VCE", F_ENUM, V_MONO, V_MONO, V_MONO, N_BASS_VOICE, 0};
static int32_t bass_wave(uint32_t wave, uint32_t ph, uint32_t inc)
{
    switch (wave) {
    case 0: return osc_sine(ph);
    case 1: return osc_tri(ph);
    case 2: return osc_saw(ph, inc);
    default: return osc_pulse(ph, inc, 0x80000000u);
    }
}
static void bass_note_on(track_t *t, voice_t *v)
{
    (void)t;
    v->ph[1] = v->ph[0] + 0x40000000u;
    v->ph[2] = v->ph[0] >> 1;
    /* Preserve a sounding filter on retrigger: amplitude ramp handles attack. */
    v->s[0] = v->s[1] = 0; /* voice_start restores kept states on retrigger */
}
static void bass_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const int16_t *p=t->p;
    uint32_t w1=(uint32_t)clamp(p[P_E0],0,3), w2=(uint32_t)clamp(p[P_E1],0,3);
    int32_t mix=clamp(p[P_E2],0,127)*258, sub=clamp(p[P_E7],0,127)*258;
    int32_t drive=clamp(p[P_E6],0,127), gain=32768+drive*1792;
    uint32_t inc1=m->inc, inc2=p[P_E3] ? cents_inc(m->pitch16,clamp(p[P_E3],0,50),0) : inc1;
    uint32_t ph0=v->ph[0],ph1=v->ph[1],ph2=v->ph[2];
    int32_t ic1=v->s[0],ic2=v->s[1];tsvf_t f;
    tsvf_coef(&f,(clamp(p[P_E4],0,127)<<8)+m->cutoff,clamp(p[P_E5],0,127));
    for(uint32_t i=0;i<n;i++){
        int32_t a=bass_wave(w1,ph0,inc1),b=bass_wave(w2,ph1,inc2);
        int32_t s=mulq15(a,32767-mix)+mulq15(b,mix);
        if(sub) s=mulq15(s,32767-sub)+mulq15(osc_sine(ph2),sub);
        ph0+=inc1;ph1+=inc2;ph2+=inc1>>1;
        if(drive) s=softclip(((s>>2)*(gain>>2))>>11); /* <= 8x, product < 2^29 */
        int32_t y=tsvf_lp(&f,s>>1,&ic1,&ic2),mag=y<0?-y:y;
        if(mag>16000){mag=16000+(softclip((mag-16000)*2)>>1);y=y<0?-mag:mag;}
        out[i]+=voice_amp(y*2,m,i)*2;
    }
    v->ph[0]=ph0;v->ph[1]=ph1;v->ph[2]=ph2;v->s[0]=ic1;v->s[1]=ic2;
}
#define BASS_OSC_COLS \
 {"WAVE1",F_ENUM,0,3,2,N_BASS_WAVE,0}, {"WAVE2",F_ENUM,0,3,3,N_BASS_WAVE,0}, \
 {"MIX",F_PCT,0,127,32,0,0}, {"DTN",F_INT,0,50,0,0,"ct"}
#define BASS_FILTER_COLS \
 {"CUT",F_CUTOFF,0,127,58,0,0}, {"RES",F_PCT,0,127,24,0,0}, \
 {"DRIVE",F_PCT,0,127,0,0,0}, {"SUB",F_PCT,0,127,32,0,0}
static const eng_page_t BASS_PAGES[]={
 {"OSC",{BASS_OSC_COLS}}, {"FILTER",{BASS_FILTER_COLS}},
 {"ENV",{{"ATK",F_TIME,0,127,0,0,0},{"DEC",F_TIME,0,127,60,0,0},{"SUS",F_PCT,0,127,100,0,0},{"REL",F_TIME,0,127,25,0,0}}},
 {"LFO",{{"RATE",F_LFOHZ,0,127,40,0,0},{"WAVE",F_ENUM,0,4,0,N_BASS_LFO,0},{"DEPTH",F_PCT,0,127,0,0,0},{"FADE",F_TIME,0,127,0,0,0}}}
};
static const uint8_t BASS_PAGE_ID[4][4]={
 {P_E0,P_E1,P_E2,P_E3},{P_E4,P_E5,P_E6,P_E7},
 {P_ATK,P_DEC,P_SUS,P_REL},{P_LRATE,P_LWAVE,P_LD_FLT,P_LFADE}
};
static int32_t bass_edit_get(const track_t *t,uint32_t page,uint32_t col)
{ return page<4u && col<4u ? t->p[BASS_PAGE_ID[page][col]] : 0; }
static void bass_edit_set(track_t *t,uint32_t page,uint32_t col,int32_t value)
{
    if(page>=4u||col>=4u)return;
    const param_desc_t *d=&BASS_PAGES[page].col[col];
    t->p[BASS_PAGE_ID[page][col]]=(int16_t)clamp(value,d->min,d->max);
}
static const eng_screen_t BASS_SCREENS[]={
 {.sec=0,.pg={0,0xff},.band=ENG_B_NONE,.title="BASS OSC",.cell={{ENG_C_RULE,ENG_C_RULE,ENG_C_BAR,ENG_C_DETUNE}}},
 {.sec=1,.pg={1,0xff},.band=ENG_B_FILTER,.title="BASS FILTER",.cell={{ENG_C_KNOB,ENG_C_KNOB,ENG_C_BAR,ENG_C_BAR}}},
 {.sec=2,.pg={2,0xff},.band=ENG_B_ENV,.title="BASS ENV",.cell={{ENG_C_RULE,ENG_C_RULE,ENG_C_RULE,ENG_C_RULE}}},
 {.sec=3,.pg={3,0xff},.band=ENG_B_NONE,.title="BASS LFO",.cell={{ENG_C_RULE,ENG_C_RULE,ENG_C_BAR,ENG_C_RULE}}}
};
static const eng_deep_t BASS_DEEP={.npages=4,.pages=BASS_PAGES,.section={0,1,2,3,0xff,0xff,0xff,0xff},
 .get=bass_edit_get,.set=bass_edit_set,.screens=BASS_SCREENS,.nscreens=4};
static const preset_t BASS_PRESETS[]={
 {"SUB PURE",{0,0,0,0,70,0,0,0},{0,55,110,24},0,1,FX(0,0,0,0),PAT(8)},
 {"ROUND TRI",{1,0,28,0,64,12,8,30},{0,65,105,30},8,1,FX(0,0,0,0),PAT(8)},
 {"SAW BASS",{2,3,25,0,55,25,20,28},{0,55,85,25},20,1,FX(0,0,0,0),PAT(2)},
 {"SQUARE SUB",{3,0,12,0,48,30,15,50},{0,55,95,24},12,1,FX(0,0,0,0),PAT(2)},
 {"ACID BASS",{2,3,0,0,38,94,38,12},{0,48,25,22},50,1,FX(0,0,0,0),PAT(1)},
 {"DRIVEN",{2,3,40,5,66,32,90,25},{0,58,100,25},12,1,FX(0,0,0,0),PAT(2)},
 {"DARK PLUCK",{2,1,35,0,34,38,25,32},{0,50,15,38},42,1,FX(0,0,0,0),PAT(3)},
 {"DETUNE BASS",{2,2,64,12,58,20,28,25},{0,65,105,35},8,1,FX(0,0,0,0),PAT(8)}
};
static const engine_t ENG_BASS={.name="BASS",.page_title={"OSC","FILTER"},
 .edit={BASS_OSC_COLS,BASS_FILTER_COLS},.presets=BASS_PRESETS,.npresets=NELEM(BASS_PRESETS),
 .poly=1,.mono=1,.keep=3,.note_on=bass_note_on,.render=bass_render,
 .knob={P_E4,P_E5,P_E6,P_E7},.deep=&BASS_DEEP};
#undef BASS_OSC_COLS
#undef BASS_FILTER_COLS
