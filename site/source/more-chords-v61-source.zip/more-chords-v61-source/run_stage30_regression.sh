#!/bin/sh
# Stage30 non-flashing host regression. No source or golden modification.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
[ -f firmware/src/eng_quad.c ] && [ -f tests/run_cr_tests.sh ] || { echo 'ERROR: extract this script into the project root'; exit 2; }
mkdir -p build/host
LOG="build/host/stage30-final-regression-$(date +%Y%m%d-%H%M%S).log"
ENGINE_EXPECTED=4b3dc4767fa974b75474f7a2b3bde509f89a3958f8c8a1415ec782ec6a6fca3d
engine_hash() { shasum -a 256 firmware/src/eng_quad.c | awk '{print $1}'; }
if [ "$(engine_hash)" != "$ENGINE_EXPECTED" ]; then echo 'STOP: eng_quad.c differs from the approved v3 hash'; exit 3; fi
printf 'Stage30 regression started; log: %s\n' "$LOG" | tee "$LOG"
run() {
 label=$1; shift
 printf '\n=== %s ===\n' "$label" | tee -a "$LOG"
 if "$@" >> "$LOG" 2>&1; then printf 'PASS: %s\n' "$label" | tee -a "$LOG";
 else printf 'FAIL: %s (see %s)\n' "$label" "$LOG" | tee -a "$LOG"; tail -45 "$LOG"; exit 1; fi
 [ "$(engine_hash)" = "$ENGINE_EXPECTED" ] || { echo 'STOP: engine hash changed'; exit 4; }
}
run 'Emulator build and stage21 checks' sh stage21/test_mac.sh
run 'Full ChoralRoot host suite (QUAD legacy audio skipped)' sh tests/run_cr_tests.sh
if ! grep -q 'SKIP: 12 legacy QUAD audio goldens' "$LOG"; then
 echo 'STOP: expected explicit QUAD v3 legacy-golden SKIP not found'; exit 5
fi
run 'Emulator headless acceptance' sh tools/emu/test_cr.sh
run 'Emulator generic persistence' sh tools/emu/test_persist.sh
printf '\nPASS: available host regressions. QUAD v3 audio SNR/RMS remains SKIPPED.\n' | tee -a "$LOG"
printf 'NOT VERIFIED: dedicated FAVORITES+BASS persistence, hardware build, FM1 flash.\n' | tee -a "$LOG"
printf 'DO NOT FLASH. Log: %s\n' "$LOG" | tee -a "$LOG"
