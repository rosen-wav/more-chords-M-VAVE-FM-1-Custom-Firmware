# ChoralRoot fase 21 — progetto completo per prove emulatore (sperimentale)

Contiene una **copia completa** dei sorgenti ChoralRoot con l'overlay cumulativo fase 20 già applicato e le due patch FM TONE `cr_edit.c` e `params.c` già applicate. Corrette due incompatibilità emerse durante la compilazione host: `F_TIMEI` e callback `engine_t.endless` in `core.h`. Adattati `tests/hostsim.c` e `tools/emu/emu_firmware.h` per compilare il ramo Prophet con le tabelle DSP, disattivando ANALOG e NOISE nel percorso emulatore.

## Mac Apple Silicon

Prerequisiti: Xcode Command Line Tools (`xcode-select --install`), Homebrew SDL2 e libraqm (`brew install sdl2 libraqm`), Python3 + Pillow/fonttools (`python3 -m pip install pillow fonttools`).

Dalla cartella estratta:

```sh
sh stage21/test_mac.sh
./build/host/emu --no-flash
```

L'opzione `--no-flash` usa memoria volatile e non modifica gli slot USER del tuo dispositivo. Per testare la persistenza dell'emulatore, consulta `tools/emu/README.md` e usa un file flash di prova separato.

## Cosa provare

- Avvio, navigazione menu e FAVOURITES.
- Prophet: selezione motore, cinque note, rilascio, cambi rapidi di accordi e preset di fabbrica.
- CZ-1: INIT a sei note e Brass1 a quattro/sei note; non assumere che il problema CPU sia risolto.
- FM TONE: algoritmi, editor e release INF.
- ANALOG/NOISE non selezionabili; preset ANALOG precedenti caricati via VA (migrazione dei salvataggi non ancora completa).

## Limiti verificati

- Controllo sintattico GCC Linux del lato sonoro con Prophet attivo: **PASS**.
- Suite ChoralRoot Linux: avviata, primi test passati, ma interrotta da un warning `-Werror=enum-compare` di `eng_va.c` (non è un test completo superato).
- Compilazione SDL/CoreMIDI su Mac: **non eseguita qui**; script pronto da lanciare sul Mac.
- Emulazione audio Prophet e Chord-Aware: **non validata**. Il Chord-Aware non conserva ancora tutte le note MIDI tenute quando vengono silenziate.
- Editor e importazione SysEx esterna: non completamente collegati alla UI.
- Slot NOISE trasformati in USER: non implementati; migrazione impostazioni v7: non completata.
- Nessuna build JieLi né test su FM1 fisica. **Non installare questo pacchetto come firmware**.

La fase 21 non contiene un `.fwsc` installabile. Conserva intatta la cartella ChoralRoot 0.14 funzionante.
