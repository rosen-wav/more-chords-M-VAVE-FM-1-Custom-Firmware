#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
export DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib${DYLD_FALLBACK_LIBRARY_PATH:+:$DYLD_FALLBACK_LIBRARY_PATH}
command -v cc >/dev/null || { echo 'Compilatore C mancante: installa Xcode Command Line Tools'; exit 1; }
python3 -c 'from PIL import Image; import fontTools' || { echo 'Installa: python3 -m pip install pillow fonttools'; exit 1; }
python3 -c 'import sys; sys.path.insert(0,"tools"); import build; build.generate()'
mkdir -p build/host
cc -std=gnu11 -fsyntax-only -w -DFELUCCA_PROPHET=1 -DFELUCCA_ANALOG=0 -DFELUCCA_NOISE=0 -Ibuild/gen -Ifirmware/src tests/hostsim.c
echo 'Sintassi host Prophet/Chord-Aware/FM TONE: OK'
sh tools/emu/build.sh
printf '\nEmulatore compilato: build/host/emu\nAvvio: ./build/host/emu --no-flash\n'
