#!/usr/bin/env python3
"""Sync generated factory tables into web/installer without touching firmware."""
import json, pathlib, re, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
if not (root/'tests/sound_templates.c').exists():
    sys.exit('ERRORE: copia questo script nella radice del progetto ChoralRoot-stage23.')
binary = root/'build/host/sound_templates'
if not binary.is_file():
    sys.exit('ERRORE: build/host/sound_templates non trovato. Esegui prima sh test_stage30_remaining_mac.sh (che lo compila).')
try:
    data = json.loads(subprocess.check_output([str(binary)], cwd=root, text=True))
except Exception as e:
    sys.exit(f'ERRORE: generatore non eseguibile: {e}')
for key in ('factory', 'factory_first'):
    if not isinstance(data.get(key), dict) or not data[key]:
        sys.exit(f'ERRORE: output generatore senza {key}')
for rel, prefix in [('web/fm1sounds.js','export const '),('tools/fm1_install.py','')]:
    path = root/rel
    src = path.read_text(encoding='utf-8')
    out = src
    for name, key, ending in [('FACTORY_PRESETS','factory',';' if prefix else ''),('FACTORY_FIRST','factory_first',';' if prefix else '')]:
        pattern = r'(?m)^' + re.escape(prefix+name) + r'\s*=\s*\{[^\n]*\}' + re.escape(ending) + r'(?=\s*$)'
        val = json.dumps(data[key], ensure_ascii=False, separators=(',',':'))
        repl = prefix + name + ' = ' + val + ending
        out, n = re.subn(pattern, lambda _: repl, out)
        if n != 1:
            sys.exit(f'ERRORE: attesa una sola definizione di {name} in {rel}, trovate {n}. Nessun file scritto.')
    if out != src:
        path.with_suffix(path.suffix+'.stage30.bak').write_text(src, encoding='utf-8')
        path.write_text(out, encoding='utf-8')
        print(f'AGGIORNATO: {rel}')
    else:
        print(f'GIA ALLINEATO: {rel}')
check = subprocess.run([str(binary),'--check','web/fm1sounds.js','tools/fm1_install.py'],cwd=root)
sys.exit(check.returncode)
