#!/bin/sh
# Run QUAD without regenerating the tables from the obsolete reference generator.
set -eu
cd "$(dirname "$0")"
export QUAD_NOREF=1
sh tests/run_quad_test.sh
