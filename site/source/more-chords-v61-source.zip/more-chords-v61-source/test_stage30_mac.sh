#!/bin/sh
set -eu
cd "$(dirname "$0")"
ROOT=${1:-.}
cd "$ROOT"
[ -f stage21/test_mac.sh ] || { echo 'ERRORE: esegui dalla cartella principale del progetto o passa il percorso'; exit 2; }
mkdir -p build/host
LOG=build/host/stage30-preflash.log
: > "$LOG"
echo '=== Stage30 Mac preflash ===' | tee -a "$LOG"
echo '=== Build emulatore ===' | tee -a "$LOG"
if sh stage21/test_mac.sh >> "$LOG" 2>&1; then echo 'PASS: build emulatore'; else echo 'FAIL: build emulatore'; tail -35 "$LOG"; exit 1; fi
echo '=== Test automatici ChoralRoot ===' | tee -a "$LOG"
if sh tests/run_cr_tests.sh >> "$LOG" 2>&1; then echo 'PASS: suite ChoralRoot'; else echo 'FAIL: suite ChoralRoot (consultare log; non flashare)'; tail -45 "$LOG"; exit 1; fi
echo '=== Verifica compilazione host ===' | tee -a "$LOG"
[ -x build/host/emu ] || { echo 'FAIL: emulatore mancante'; exit 1; }
echo 'PASS: emulatore e test. Esegui i test manuali della checklist; NON FLASHARE.' | tee -a "$LOG"
echo "Log: $(pwd)/$LOG"
