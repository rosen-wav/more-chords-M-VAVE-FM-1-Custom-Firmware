#!/bin/sh
# Diagnostica pre-flash: esegue tutti i test ufficiali TRANNE cr_quad_test,
# incompatibile con la revisione attuale del motore. Non autorizza il flash.
set -eu
cd "$(dirname "$0")"
[ -f tests/run_cr_tests.sh ] || { echo 'Eseguire dalla radice del progetto ChoralRoot'; exit 2; }
mkdir -p build/host
LOG=build/host/stage30-remaining-tests.log
TMP=build/host/stage30-run-without-quad.sh
# Conserva lo script originale; omette solo compilazione e avvio del test QUAD.
awk '!/^-?cc .*build\/host\/cr_quad_test tests\/cr_quad_test.c/ && !/^\.\/build\/host\/cr_quad_test$/ { print }' tests/run_cr_tests.sh > "$TMP"
# Lo script originale cambia directory in base alla propria posizione: lo script temporaneo
# si trova in build/host, quindi rimpiazziamo solo quella riga con cd alla radice.
python3 - "$TMP" "$(pwd)" <<'PY'
import sys
p,root=sys.argv[1:]
s=open(p).read().replace('cd "$(dirname "$0")/.."', 'cd "'+root.replace('"','\\"')+'"')
open(p,'w').write(s)
PY
printf '%s\n' '=== Suite senza QUAD (diagnostica, NON pre-flash completo) ===' | tee "$LOG"
if sh "$TMP" >> "$LOG" 2>&1; then
  echo 'PASS: test rimanenti. QUAD NON TESTATO. NON FLASHARE.' | tee -a "$LOG"
else
  echo 'FAIL: almeno un altro test non superato. NON FLASHARE.' | tee -a "$LOG"
  tail -45 "$LOG"
  exit 1
fi
printf 'Log: %s/%s\n' "$(pwd)" "$LOG"
