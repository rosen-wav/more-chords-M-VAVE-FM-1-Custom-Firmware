"""Lossless codec fixtures, including all supported run lengths."""
from pathlib import Path
import random
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from boot_codec import encode_rows
rng=random.Random(46)
rows=[[0]*240,[15]*240,list(range(16))*15]
rows += [[3]*n+[4]*(240-n) for n in range(1,241)]
rows += [[rng.randrange(16) for _ in range(240)] for _ in range(100)]
data,offsets=encode_rows(rows+rows)
assert offsets[:len(rows)]==offsets[len(rows):]
for expected,off in zip(rows+rows,offsets):
    got=[]
    while len(got)<240:
        b=data[off];off+=1;n=(b>>4)+1
        if n==16:n+=data[off];off+=1
        got.extend([b&15]*n)
    assert got==expected
print('PASS: run lengths 1..240, random/alternating rows, duplicate sharing')
