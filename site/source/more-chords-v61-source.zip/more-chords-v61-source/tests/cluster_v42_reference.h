static void cluster_v42_reference(cluster_note_t *s,uint32_t inc,const int16_t *k)
{
    cls_voice *v=&s->state;cls_global *g=&s->global;
    uint32_t count=(uint32_t)clamp(k[0]>>11,1,7), phase[7],step[7];
    int32_t gain[7],previous[7],sumgain=0;
    /* Recover the native piecewise Wave response and evolving history at
     * kernel boundaries, with feedback capped below the original half-scale. */
    int32_t u=(k[1]*0x5000)>>15,hi,lo;
    if(u<0x1000){hi=-32768;lo=clamp(u*8,-32768,32767);}
    else if(u<0x3000){hi=clamp((u-0x2000)*8,-32768,32767);lo=32767;}
    else if(u<0x4000){hi=32767;lo=clamp(32767-clamp((u-0x3000)*8,-32768,32767),-32768,32767);}
    else {hi=clamp(32767-clamp((u-0x4000)*8,-32768,32767),-32768,32767);lo=0;}
    int32_t square=clamp((hi*hi)>>15,-32768,32767);
    hi=((((square*hi)>>15)*0x01a3)>>15); /* native cubic Wave history, block-rate only */
    int32_t history=cls_get16(v,0x54);
    history=clamp(history+hi,-8192,8192);
    cls_put16(v,0x54,(int16_t)history);
    int32_t feedback=clamp((lo+history)/2,-12288,12288);
    int32_t curve=(int32_t)((uint32_t)OP1_CLUSTER_TABLES.curve[(uint32_t)clamp(k[2]>>10,0,23)]>>16);
    int32_t strength=k[3]/2;
    if(v->bytes[0x6a])strength/=8;
    for(uint32_t j=0;j<7;j++){
        int32_t target=j<count?16384/(int32_t)count:0;
        gain[j]=cls_get16(v,0x5a+2*j);
        gain[j]+=(target-gain[j])/8;
        cls_put16(v,0x5a+2*j,(int16_t)gain[j]);sumgain+=gain[j];
        g->seed=cls_next(g->seed);
        int32_t drift=cls_get16(v,0x44+2*j);
        int32_t r=cls_s16(g->seed>>16);
        drift=clamp(((drift*curve)>>15)+((r*strength)>>15),-32768,32767);
        cls_put16(v,0x44+2*j,(int16_t)drift);
        int32_t lane=(int32_t)(j*2u)-(int32_t)count+1;
        int32_t spread=clamp(((int32_t)k[3]+drift)/16,-3072,3072);
        int32_t delta=(((int32_t)(inc>>16)*spread)*lane)>>4;
        phase[j]=cls_get32(v,4+8*j);step[j]=inc+(uint32_t)delta;
        previous[j]=cls_get16(v,8+8*j);
    }
    /* Gain sum never exceeds half scale (native steady-state headroom), including COUNT transitions. */
    int32_t norm=sumgain>16384?536870912/sumgain:32768;
    for(uint32_t j=0;j<7;j++)gain[j]=(gain[j]*norm)>>15;
    for(uint32_t i=0;i<128;i++){
        int32_t sum=0;
        for(uint32_t j=0;j<7;j++){
            uint32_t index=((phase[j]>>16)+(uint32_t)((previous[j]*feedback)>>15)+32768u)&65535u;
            int32_t wave=OP1_CLUSTER_TABLES.wave[index>>3];
            sum+=(wave*gain[j])>>15;
            previous[j]=wave;phase[j]+=step[j];
        }
        s->pcm[i]=(int16_t)sum;
    }
    for(uint32_t j=0;j<7;j++){
        cls_put32(v,4+8*j,phase[j]);cls_put16(v,8+8*j,(int16_t)previous[j]);
        g->gain[j]=(int16_t)gain[j];g->control[j]=cls_get16(v,0x44+2*j);
    }
}

