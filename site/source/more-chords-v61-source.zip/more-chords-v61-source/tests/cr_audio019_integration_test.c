/* SPDX-License-Identifier: GPL-3.0-only */
/* The Remix integration: saved options, post-master effects' low bits and click alignment. */
#include "../tools/emu/emu_fw.c"
#include <assert.h>
int main(void)
{
    cr_settings_t s, loaded;
    unsigned checks = 0;
    int32_t out[2u * CTL];
    emu_fw_options(0, 1, 0, 1); emu_fw_init(0);
    assert(cs.out_clean == 1 && cs.usb48 == 0);
    assert(O_MAX[O_OUTPUT] == 1 && O_MAX[O_USB_RATE] == 1);
    for (unsigned bits = 0; bits < 8; bits++) {
        cr_settings_defaults(&s); s.pick_roots = (uint8_t)bits; cr_settings_seal(&s);
        assert(cr_settings_import(&loaded, &s, sizeof s) == 1);
        assert(loaded.pick_roots == bits);
        assert(CRS_OUT_CLEAN(&loaded) == !(bits & 2));
        assert(CRS_USB48(&loaded) == !!(bits & 4)); checks++;
    }
    for (unsigned pick=0; pick<2; pick++) for(unsigned clean=0; clean<2; clean++) for(unsigned rate=0;rate<2;rate++) {
        cs.pick_roots=(uint8_t)pick;cs.out_clean=(uint8_t)clean;cs.usb48=(uint8_t)rate;
        crs_capture(&s);
        assert((s.pick_roots & 1) == pick && CRS_OUT_CLEAN(&s) == clean && CRS_USB48(&s) == rate);
        checks++;
    }
    /* A gain of one is exact, including all seven DAC bits and Fixed's two pending bits. */
    for(unsigned fixed=0;fixed<2;fixed++) {
        unsigned sh=fixed?2:7;
        fx_usb_fixed=(uint8_t)fixed;fx_out_blk=1;
        for(int x=-32768;x<=32767;x+=257) for(unsigned f=0;f<(1u<<sh);f++) {
            out[0]=x;out[1]=-x;out_frac[0]=(uint8_t)f;out_frac[1]=(uint8_t)f;
            cr_output_gain(out,0,32768);
            assert(out[0]==x && out[1]==-x && out_frac[0]==f && out_frac[1]==f);checks++;
            cr_output_gain(out,0,0);
            assert(!out[0] && !out[1] && !out_frac[0] && !out_frac[1]);checks++;
        }
    }
    for(int x=-32768;x<=32767;x+=127) {
        out[0]=x;out[1]=-x;fx_out_blk=0;
        cr_output_gain(out,0,12345);
        assert(out[0]==mulq15(x,12345) && out[1]==mulq15(-x,12345));checks++;
    }
    for(unsigned mode=0;mode<2;mode++) {
        memset(out,0,sizeof out);cr_ck_n=cr_ck_wait=0;crl.click=1;crl.metro_vol=50;fx_out_blk=(uint8_t)mode;
        cr_click_mix(out,CTL);
        if(mode) {for(unsigned i=0;i<2u*CTL;i++)assert(!out[i]);memset(out,0,sizeof out);cr_click_mix(out,CTL);}
        int audible=0;for(unsigned i=0;i<2u*CTL;i++)audible|=out[i]!=0;assert(audible);checks++;
    }
    /* Switching is requested, not an asynchronous reset of a sounding chain. */
    fx_out_pin=0;fx_output_set(1,1);assert(fx_out_mode==1);
    fx_output_set(0,0);assert(fx_out_mode==1 && fx_out_want==0);
    printf("PASS: audio019 Remix %u checks: old/new settings bits, roots picker, Clean/Classic options, full-resolution Gate/Sidechain gain and bypass, metronome alignment, deferred mode switch\n",checks);
    return 0;
}
