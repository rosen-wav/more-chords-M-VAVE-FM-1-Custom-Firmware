#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
#include "opt_reference_kernels.h"
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_c1_test_serial=1;
 unsigned changes=0,blocks=0;
 for(unsigned preset=0;preset<ENG_BASS.npresets;preset++){
  setup(ENGI_VA,0,ENGI_BASS,preset,6,64);track_t *t=&trk[1];voice_t *v=&t->v[0];
  for(unsigned k=0;k<100;k++){
   unsigned n=1+k%CTL;int retrig=k==12||k==13||k==14||k==50;
   int32_t previous=v->s[2];
   if(retrig){voice_start(t,v,36+(k%3)*12,80+k%40,0);assert(v->s[5]);}
   vmod_t m={0};m.amp0=20000;m.amp1=25000;m.pitch16=v->note*16;m.inc=pitch_inc(m.pitch16);m.shape=64<<8;
   int32_t pcm[CTL],raw[CTL];for(unsigned i=0;i<CTL;i++)pcm[i]=raw[i]=500+i*17;
   voice_t before=*v;
   ref_bass_render(t,v,raw,n,&m);voice_t ref=*v;*v=before;
   bass_render(t,v,pcm,n,&m);
   assert(!memcmp(v->ph,ref.ph,sizeof v->ph));assert(v->s[0]==ref.s[0]&&v->s[1]==ref.s[1]);
   if(retrig){assert(pcm[0]-500==previous);changes++;}
   if(!before.s[4]&&!before.s[5])assert(!memcmp(pcm,raw,sizeof pcm));
   assert(v->s[4]==(before.s[5]?128:(unsigned)before.s[4])-(n<(before.s[5]?128:(unsigned)before.s[4])?n:(before.s[5]?128:(unsigned)before.s[4])));
   assert(v->s[2]==pcm[n-1]-(500+(n-1)*17));blocks++;
  }
  v->active=0;v->stage=0;voice_start(t,v,48,100,0);
  assert(!v->s[2]&&!v->s[3]&&!v->s[4]&&!v->s[5]);
 }
 printf("PASS: %u bass blocks, %u retriggers with exact sample continuity, 128-sample decay, unchanged oscillator/filter state and steady audio\n",blocks,changes);
}
