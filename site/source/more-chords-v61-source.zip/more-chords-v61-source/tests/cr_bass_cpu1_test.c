#define CR_C1_HELPERS_ONLY
#include "cr_dualcore_test.c"
static int32_t wanted[128][CTL*2];
int main(void){
 pthread_t th;int32_t out[CTL*2];unsigned cases=0;
 emu_fw_options(0,1,0,1);emu_fw_init(0);cr_audio_block(CTL);
 assert(!pthread_create(&th,0,worker,0));while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;cr_dbg.c1=C1_OK;
 for(unsigned e=0;e<5;e++)for(unsigned preset=0;preset<ENG_BASS.npresets;preset++)for(unsigned rev=0;rev<4;rev++){
  cr_c1_test_serial=1;setup(engines[e],0,ENGI_BASS,preset,6,rev);
  for(unsigned k=0;k<128;k++)block(k,wanted[k]);voice_t saved[NVOICE];memcpy(saved,trk[1].v,sizeof saved);
  cr_c1_test_serial=0;setup(engines[e],0,ENGI_BASS,preset,6,rev);uint32_t before=cr_dbg.c1_jobs;
  for(unsigned k=0;k<128;k++){block(k,out);assert(!memcmp(out,wanted[k],sizeof out));}
  assert(!memcmp(saved,trk[1].v,sizeof saved)&&cr_dbg.c1_jobs>before&&!audio_worker.timeouts);cases++;
 }
 pthread_cancel(th);pthread_join(th,0);printf("PASS: BASS CPU1 %u serial/worker PCM and voice-state cases, eight presets, five chord engines, four reverbs, note retrigger/release, no timeout\n",cases);
}
