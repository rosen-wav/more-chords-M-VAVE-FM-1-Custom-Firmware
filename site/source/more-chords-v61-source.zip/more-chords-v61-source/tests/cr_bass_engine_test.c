#define CR_CHORD_TEST_HELPERS_ONLY
#include "cr_chord_intelligence_test.c"
static unsigned gated(track_t *t){unsigned n=0;for(unsigned i=0;i<NVOICE;i++)n+=t->v[i].active&&t->v[i].gate;return n;}
static uint64_t render_energy(unsigned w,unsigned sub,unsigned drive,unsigned cut,int32_t *capture){
 track_t t;voice_t v;memset(&t,0,sizeof t);memset(&v,0,sizeof v);
 for(unsigned i=0;i<8;i++)t.p[P_E0+i]=ENG_BASS.edit[i].def;
 t.p[P_E0]=w;t.p[P_E1]=w;t.p[P_E2]=0;t.p[P_E6]=drive;t.p[P_E7]=sub;t.p[P_E4]=cut;t.p[P_E5]=0;
 v.age=1;bass_note_on(&t,&v);vmod_t m={.inc=cents_inc(36*16,0,0),.pitch16=36*16,.amp0=12000,.amp1=12000};
 uint64_t energy=0;
 for(unsigned k=0;k<300;k++){
  int32_t out[CTL]={0};bass_render(&t,&v,out,CTL,&m);
  for(unsigned i=0;i<CTL;i++){assert(out[i]>-100000&&out[i]<100000);if(k>100)energy+=(int64_t)out[i]*out[i];}
  if(capture&&k==299)memcpy(capture,out,sizeof out);
 }
 return energy;
}
int main(void){
 emu_fw_options(0,1,0,1);emu_fw_init(0);
 assert(ENGI_FM6==12&&ENGI_VA==13&&ENGI_CZ==14&&ENGI_QUAD==15&&ENGI_PROPHET==16&&ENG_USER_REF==17&&ENGI_BASS==18);
 assert(eng_ok(ENGI_BASS)&&!eng_ok(ENG_USER_REF)&&eng_vis(NENG_SHOWN-2)==ENGI_BASS && eng_vis(NENG_SHOWN-1)==ENGI_MORPH);
 unsigned checks=0;int32_t waves[4][CTL],sub[CTL],drive[CTL];
 for(unsigned w=0;w<4;w++){assert(render_energy(w,0,0,100,waves[w])>100000);checks++;}
 for(unsigned a=0;a<4;a++)for(unsigned b=a+1;b<4;b++)assert(memcmp(waves[a],waves[b],sizeof waves[a]));
 render_energy(2,127,0,100,sub);render_energy(2,0,127,100,drive);
 assert(memcmp(waves[2],sub,sizeof sub)&&memcmp(waves[2],drive,sizeof drive));
 assert(render_energy(2,0,0,110,0)>render_energy(2,0,0,10,0)*4);
 for(unsigned p=0;p<ENG_BASS.npresets;p++)for(unsigned note=24;note<=72;note+=12)for(unsigned mode=0;mode<4;mode++){
  clear(ENGI_BASS,0,0);cu_load(&trk[0],ENGI_BASS,p,0);settle();assert(trk[0].p[P_VOICE]==V_MONO);
  trk[0].p[P_VOICE]=mode;trk[0].p[P_PRIO]=0;panic_req=0;
  trk_note_on(&trk[0],note,100);trk_note_on(&trk[0],note+7,100);settle();
  assert(gated(&trk[0])==1&&trk[0].v[0].note==note+7&&trk_nvoice(&trk[0])==1);
  trk_note_off(&trk[0],note+7);settle();assert(gated(&trk[0])==1&&trk[0].v[0].note==note);
  trk_note_off(&trk[0],note);settle();assert(!gated(&trk[0]));
  int32_t out[CTL*2];for(unsigned k=0;k<2000;k++)mix_block(out,CTL);assert(!trk[0].v[0].active);checks++;
 }
 clear(ENGI_BASS,0,0);cu_init_load(0,ENGI_BASS);settle();assert(ce_deep(&trk[0])==&BASS_DEEP);
 cu.armed=NB;cu.lock=L_NONE;cu.opt_open=0;cu_edit_open(0);cu_tap(BT_SWAG);
 cr_screen_t screen;cr_build_screen(&screen,cu_now());assert(cu.page==PG_EDIT&&cx.grp[0]==CE_FILT);
 ce_view_t view;ce_view(&trk[0],0,&view);assert(view.wide==CR_W_FILTER);
 bass_edit_set(&trk[0],1,2,99);assert(trk[0].p[P_E6]==99&&bass_edit_get(&trk[0],1,2)==99);
 bass_edit_set(&trk[0],0,3,100);assert(trk[0].p[P_E3]==50);
 song.sel=0;assert(up_store(31,"MY BASS")==0);cu_load(&trk[0],ENGI_FM6,0,0);cu_load_user(&trk[0],31,0);settle();
 assert(trk[0].eng_req==ENGI_BASS&&trk[0].p[P_E6]==99&&trk[0].p[P_E3]==50&&trk_vmode(&trk[0])==V_MONO);
 memset(&favorites,0,sizeof favorites);favorites.factory[4][0]=0xB3;favorites.factory[4][1]=CU_BASS_MARK;
 cu_bass_ref(0)[0]=17;cu_bass_ref(0)[1]=31;cu_bass_ref(1)[0]=cu_bass_ref(1)[1]=255;
 assert(favorite_set(ENGI_BASS,0,1));assert(favorite_has(ENGI_BASS,0));assert(favorite_set(17,31,1));assert(favorite_has(ENG_USER_REF,31));
 cu_bass_pick(0);assert(trk[1].eng_req==ENGI_BASS);
 assert(sizeof(persist_t)==764&&sizeof(cr_settings_t)==192&&sizeof(favorites_t)==520);
 printf("PASS: BASS %u preset/note/mode fixtures; distinct oscillators/sub/drive, cutoff response, mono priority/fallback/release, filter UI, user save/load, stable IDs/legacy user bass references and unchanged settings layout\n",checks);
}
