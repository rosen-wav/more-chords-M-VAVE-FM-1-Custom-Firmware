#define main original_draw_main
#include "cr_draw_test.c"
#undef main
#include <assert.h>
#include "boot_pixel_checksum.h"
int main(void)
{
    cr_screen_t s;
    uint32_t y, x, k, before, hash = 2166136261u;
    palette_set(mod_index());
    cr_screen_clear(&s);
    s.kind = CR_K_BOOT;
    cr_draw_invalidate();
    cr_draw(&s, 65535u);
    for (y = 0; y < 240; ++y) {
        x = 0;
        k = cr_boot_rows[y];
        while (x < 240u) {
            assert(k < sizeof cr_boot_rle);
            uint32_t b = cr_boot_rle[k++], n = (b >> 4) + 1;
            if (n == 16) { assert(k < sizeof cr_boot_rle); n += cr_boot_rle[k++]; }
            while (n--) {
                assert(x < 240);
                hash = (hash ^ cr_boot_palette[b&15]) * 16777619u;
                assert(host_screen[y*240+x++] == swap16(cr_boot_palette[b&15]));
            }
        }
        assert(x == 240);
    }
    assert(hash == BOOT_PIXEL_FNV);
    before = host_blits;
    cr_draw(&s, 65535u);
    assert(before == host_blits);
    write_ppm("build/boot-art", "startup");
    puts("PASS: 57600 startup pixels, row bounds and unchanged-frame cache");
    return nfail ? 1 : 0;
}
